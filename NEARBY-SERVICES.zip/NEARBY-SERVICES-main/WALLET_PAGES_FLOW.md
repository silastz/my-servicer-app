# Wallet pages: Withdraw and History

Screens (opened from the wallet page, `pocket_fund_screen.dart`):
- `lib/screens/withdraw_screen.dart`
- `lib/screens/wallet_history_screen.dart`

## Endpoints

Already used by the app:
- `POST /wallet/withdraw` `{amount, phone}`

New, must exist on the backend:
- `GET /wallet/transactions` -> `[{id, type, amount, status, title, reference, createdAt, direction?}]`
  `type` is one of: DEPOSIT, WITHDRAWAL, BOOKING, REFUND.
  `direction` is IN or OUT (optional; otherwise the sign of `amount` and the type decide).
  Until this exists the History page falls back to the buyer's booking payments.

The server must enforce every limit and balance check; the app checks are only for the user's convenience.
