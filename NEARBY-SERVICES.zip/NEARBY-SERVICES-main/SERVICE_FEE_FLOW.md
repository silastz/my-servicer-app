# Per-service fee

The provider's registration fee covers the first **2** services. Every service after that needs its own fee.

## App flow
1. Provider taps **Publish** on a NEW service (drafts included; editing an existing service is free).
2. The app calls `GET /payments/service-fee`.
3. If `needsPayment` is true, the **Service fee** page opens (mobile money or card, same gateways as the registration fee).
4. After the gateway says paid, the app asks `GET /payments/service-fee` again; only when `needsPayment` is false does it publish.
5. If the status call could not be loaded and `POST /services` answers **402**, the app opens the same page; the provider taps Publish again after paying.

## Backend needs
| Call | Answer |
|---|---|
| `GET /payments/service-fee` | `{freeLimit: 2, used: <services posted>, credits: <paid fees not yet used>, amount: <TSh>, needsPayment: bool}` where `needsPayment = used >= freeLimit && credits <= 0` |
| `POST /payments/mobile/request` and the card checkout | accept `purpose: "SERVICE_FEE"`; on PAID, add **one credit** to the provider |
| `POST /services` | answer **HTTP 402** when `needsPayment` is true; otherwise create the service and spend one credit if `used >= freeLimit` |

## Rules the server must enforce (the app cannot)
- The limit and the credit are checked on the server, not trusted from the app.
- One paid fee = one credit = one extra service. A payment reference can be credited once.
- Deleting a service does not give back a free slot (decide this rule on the server).
- The fee amount lives on the server. `SessionManager.serviceFee` (TSh 5,000) is only a fallback shown if the server sends no amount; set the real price on the server.

## Registration fee first
If `POST /services` answers **402 `REGISTRATION_FEE_REQUIRED`**, the one-time registration fee is unpaid: the app opens
the **Registration fee** page (not the Service fee page). After paying, the provider taps Publish again.
