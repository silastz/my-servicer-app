# Ad SDKs (ADS.md). Release builds are minified, so keep what the ad networks load by name.
-keep class com.ironsource.** { *; }
-keep class com.unity3d.mediation.** { *; }
-keep class com.unity3d.ads.** { *; }
-keepclassmembers class com.ironsource.sdk.controller.IronSourceWebView$JSInterface { public *; }
-keep class com.facebook.ads.** { *; }
-keep class com.google.android.gms.ads.** { *; }
-dontwarn com.ironsource.**
-dontwarn com.unity3d.**
-dontwarn com.facebook.ads.**
