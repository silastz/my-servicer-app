package com.unganalink.app

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.google.android.play.core.integrity.IntegrityManagerFactory
import com.google.android.play.core.integrity.IntegrityTokenRequest
import java.security.MessageDigest
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import java.nio.ByteBuffer
import android.os.Debug
import android.view.WindowManager
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugins.googlemobileads.GoogleMobileAdsPlugin
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.security.KeyStore

// local_auth (biometrics) needs a FragmentActivity.
class MainActivity : FlutterFragmentActivity() {

    private val isDebuggableBuild: Boolean
        get() = (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0

    override fun cleanUpFlutterEngine(flutterEngine: FlutterEngine) {
        GoogleMobileAdsPlugin.unregisterNativeAdFactory(flutterEngine, "serviceCard")
        super.cleanUpFlutterEngine(flutterEngine)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applySecureFlag(true)
    }

    // Blocks screenshots, screen recording and the recent-apps thumbnail.
    // On by default (all builds); the app turns it off when the user allows captures in Settings.
    private fun applySecureFlag(on: Boolean) {
        if (on) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        // Card-sized native ads for the Home feed (id must match AdService.cardFactoryId).
        GoogleMobileAdsPlugin.registerNativeAdFactory(
            flutterEngine, "serviceCard", ServiceCardNativeAdFactory(this)
        )
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "ungana/video")
            .setMethodCallHandler { call, result ->
                if (call.method != "trim") { result.notImplemented(); return@setMethodCallHandler }
                val path = call.argument<String>("path")
                val maxMs = (call.argument<Number>("maxMs"))?.toLong()
                if (path == null || maxMs == null) { result.success(null); return@setMethodCallHandler }
                val main = Handler(Looper.getMainLooper())
                Thread {
                    val out = try { trimVideo(path, maxMs) } catch (_: Throwable) { null }
                    main.post { result.success(out) }
                }.start()
            }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "ungana/security")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "scan" -> result.success(scan())
                    "signer" -> result.success(signerHashes())
                    "integrityToken" -> requestIntegrityToken(call.arguments as? String, result)
                    "setSecure" -> {
                        applySecureFlag(call.arguments as? Boolean ?: true)
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    // Keeps the first [maxMs] of a video without re-encoding. The cut falls on the key frame at or
    // before the limit, so the result can be a little shorter, never longer. Returns the new file or null.
    private fun trimVideo(path: String, maxMs: Long): String? {
        val out = File(cacheDir, "trim_${System.currentTimeMillis()}.mp4")
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        var started = false
        try {
            extractor.setDataSource(path)
            muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val tracks = HashMap<Int, Int>()
            var bufferSize = 1 shl 20
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                if (!mime.startsWith("video/") && !mime.startsWith("audio/")) continue
                extractor.selectTrack(i)
                tracks[i] = muxer.addTrack(format)
                if (format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                    bufferSize = maxOf(bufferSize, format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE))
                }
            }
            if (tracks.isEmpty()) return null
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(path)
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
                    ?.toIntOrNull()?.let { muxer.setOrientationHint(it) }
            } finally { retriever.release() }
            muxer.start()
            started = true
            val buffer = ByteBuffer.allocate(bufferSize)
            val info = MediaCodec.BufferInfo()
            val limitUs = maxMs * 1000
            while (true) {
                buffer.clear()
                val size = extractor.readSampleData(buffer, 0)
                if (size < 0) break
                val time = extractor.sampleTime
                if (time > limitUs) break
                val track = tracks[extractor.sampleTrackIndex]
                if (track != null) {
                    info.set(0, size, time, extractor.sampleFlags)
                    muxer.writeSampleData(track, buffer, info)
                }
                extractor.advance()
            }
            muxer.stop()
            started = false
            return out.absolutePath
        } catch (_: Throwable) {
            return null
        } finally {
            try { if (started) muxer?.stop() } catch (_: Throwable) {}
            try { muxer?.release() } catch (_: Throwable) {}
            extractor.release()
        }
    }

    // SHA-256 (hex, lowercase) of the certificate(s) this APK is signed with.
    // With Play App Signing this is Google's app-signing key (Play Console > App integrity).
    @Suppress("DEPRECATION")
    private fun signerHashes(): List<String> = try {
        val sigs = if (Build.VERSION.SDK_INT >= 28) {
            val info = packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNING_CERTIFICATES).signingInfo
            if (info.hasMultipleSigners()) info.apkContentsSigners else info.signingCertificateHistory
        } else {
            packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES).signatures
        }
        sigs.map { sig -> MessageDigest.getInstance("SHA-256").digest(sig.toByteArray()).joinToString("") { "%02x".format(it) } }
    } catch (_: Throwable) { emptyList() }

    // Google Play Integrity. Returns null (never an error) when Play Services is missing or fails,
    // so users without Google services are never locked out by the client; the server decides.
    private fun requestIntegrityToken(nonce: String?, result: MethodChannel.Result) {
        if (nonce.isNullOrBlank()) { result.success(null); return }
        try {
            IntegrityManagerFactory.create(applicationContext)
                .requestIntegrityToken(IntegrityTokenRequest.builder().setNonce(nonce).build())
                .addOnSuccessListener { result.success(it.token()) }
                .addOnFailureListener { result.success(null) }
        } catch (_: Throwable) { result.success(null) }
    }

    private fun scan(): Map<String, Boolean> = mapOf(
        "rooted" to safe { isRooted() },
        "debugger" to safe { isDebugged() },
        "hooking" to safe { hasHooking() },
        "proxy" to safe { hasProxy() },
        "vpn" to safe { hasVpn() },
        "userCa" to safe { hasUserCa() },
    )

    private inline fun safe(block: () -> Boolean): Boolean = try { block() } catch (_: Throwable) { false }

    private fun isRooted(): Boolean {
        if (Build.TAGS?.contains("test-keys") == true) return true
        val paths = arrayOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/su", "/vendor/bin/su",
            "/su/bin/su", "/data/local/su", "/data/local/bin/su", "/data/local/xbin/su",
            "/system/app/Superuser.apk", "/sbin/.magisk", "/data/adb/magisk", "/data/adb/modules",
        )
        return paths.any { File(it).exists() }
    }

    private fun isDebugged(): Boolean {
        if (isDebuggableBuild) return true
        if (Debug.isDebuggerConnected() || Debug.waitingForDebugger()) return true
        // A non-zero TracerPid means another process (gdb, strace, frida...) is attached.
        File("/proc/self/status").useLines { lines ->
            lines.firstOrNull { it.startsWith("TracerPid:") }?.let {
                if (it.substringAfter(":").trim() != "0") return true
            }
        }
        return false
    }

    private fun hasHooking(): Boolean {
        try {
            Class.forName("de.robv.android.xposed.XposedBridge")
            return true
        } catch (_: Throwable) { }
        val needles = listOf("frida", "gum-js-loop", "xposed", "substrate", "lsposed")
        File("/proc/self/maps").useLines { lines ->
            if (lines.any { l -> needles.any { n -> l.contains(n, ignoreCase = true) } }) return true
        }
        // frida-server default port
        return try {
            Socket().use { it.connect(InetSocketAddress("127.0.0.1", 27042), 120); true }
        } catch (_: Throwable) { false }
    }

    private fun hasProxy(): Boolean {
        val h = System.getProperty("http.proxyHost") ?: System.getProperty("https.proxyHost")
        return !h.isNullOrBlank()
    }

    private fun hasVpn(): Boolean {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
    }

    // User-installed CA certificates are how sniffers (HttpCanary, mitmproxy...) decrypt HTTPS.
    private fun hasUserCa(): Boolean {
        val ks = KeyStore.getInstance("AndroidCAStore").apply { load(null, null) }
        val aliases = ks.aliases()
        while (aliases.hasMoreElements()) if (aliases.nextElement().startsWith("user:")) return true
        return false
    }
}
