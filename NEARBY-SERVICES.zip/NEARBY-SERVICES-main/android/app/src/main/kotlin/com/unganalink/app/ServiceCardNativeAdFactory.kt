package com.unganalink.app

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView
import io.flutter.plugins.googlemobileads.GoogleMobileAdsPlugin

/**
 * Native ad laid out like a Home service card: media on top (with the required
 * "Ad" label), then headline, body, a call-to-action button and an advertiser strip.
 * Registered in MainActivity under the id "serviceCard" (AdService.cardFactoryId).
 * The height is set from Dart (NativeAdRow cell mode); the media area takes what is left.
 */
class ServiceCardNativeAdFactory(private val context: Context) : GoogleMobileAdsPlugin.NativeAdFactory {

    private fun dp(v: Int): Int = (v * context.resources.displayMetrics.density).toInt()

    private fun text(sizeSp: Float, color: Int, bold: Boolean = false, lines: Int = 1): TextView =
        TextView(context).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            maxLines = lines
            ellipsize = TextUtils.TruncateAt.END
        }

    override fun createNativeAd(nativeAd: NativeAd, customOptions: MutableMap<String, Any>?): NativeAdView {
        val navy = Color.parseColor("#14307A")
        val muted = Color.parseColor("#64748B")
        val primary = Color.parseColor("#0D6EFD")
        val border = Color.parseColor("#F1F5F9")

        val adView = NativeAdView(context)
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setBackgroundColor(Color.WHITE)
        }

        // Media area (fills the space above the text) with the "Ad" label.
        val mediaBox = FrameLayout(context).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            setBackgroundColor(Color.parseColor("#E2E8F0"))
        }
        val media = MediaView(context).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        val label = text(10f, Color.parseColor("#1E293B"), bold = true).apply {
            text = "Ad"
            setPadding(dp(7), dp(2), dp(7), dp(2))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F59E0B"))
                cornerRadius = 0f
            }
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.TOP or Gravity.START
                setMargins(dp(8), dp(8), 0, 0)
            }
        }
        mediaBox.addView(media)
        mediaBox.addView(label)

        // Text block.
        val body = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(8))
        }
        val headline = text(13.5f, navy, bold = true, lines = 2)
        val bodyText = text(11.5f, muted)
        val cta = Button(context).apply {
            isAllCaps = false
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            minHeight = 0
            minimumHeight = 0
            background = GradientDrawable().apply {
                setColor(primary)
                cornerRadius = dp(8).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(32)).apply { topMargin = dp(8) }
        }
        body.addView(headline)
        body.addView(bodyText)
        body.addView(cta)

        // Advertiser strip (same position as the provider strip on a service card).
        val strip = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        val divider = View(context).apply {
            setBackgroundColor(border)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1))
        }
        val icon = ImageView(context).apply {
            layoutParams = LinearLayout.LayoutParams(dp(22), dp(22)).apply { marginEnd = dp(7) }
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        val advertiser = text(11.5f, muted, bold = true)
        strip.addView(icon)
        strip.addView(advertiser)

        root.addView(mediaBox)
        root.addView(body)
        root.addView(divider)
        root.addView(strip)
        adView.addView(root)

        // Fill the assets from the ad, hiding the ones it does not have.
        headline.text = nativeAd.headline
        adView.headlineView = headline
        adView.mediaView = media

        if (nativeAd.body.isNullOrEmpty()) bodyText.visibility = View.GONE else { bodyText.text = nativeAd.body; bodyText.visibility = View.VISIBLE }
        adView.bodyView = bodyText

        if (nativeAd.callToAction.isNullOrEmpty()) cta.visibility = View.GONE else { cta.text = nativeAd.callToAction; cta.visibility = View.VISIBLE }
        adView.callToActionView = cta

        val iconDrawable = nativeAd.icon?.drawable
        if (iconDrawable == null) icon.visibility = View.GONE else { icon.setImageDrawable(iconDrawable); icon.visibility = View.VISIBLE }
        adView.iconView = icon

        val name = nativeAd.advertiser ?: nativeAd.store ?: ""
        if (name.isEmpty()) advertiser.visibility = View.GONE else { advertiser.text = name; advertiser.visibility = View.VISIBLE }
        adView.advertiserView = advertiser

        adView.setNativeAd(nativeAd)
        return adView
    }
}
