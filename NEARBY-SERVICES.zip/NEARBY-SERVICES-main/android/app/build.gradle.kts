import java.util.Properties
import java.io.FileInputStream

plugins {
    id("com.android.application")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
    id("com.google.gms.google-services")
}

val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(FileInputStream(keystorePropertiesFile))
}

android {
    namespace = "com.unganalink.app"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    defaultConfig {
        // TODO: Specify your own unique Application ID (https://developer.android.com/studio/build/application-id.html).
        applicationId = "com.unganalink.app"
        // You can update the following values to match your application needs.
        // For more information, see: https://flutter.dev/to/review-gradle-config.
        minSdk = flutter.minSdkVersion
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
        // AdMob app ID: -PADMOB_APP_ID=..., or the ADMOB_APP_ID env var (tool/build_release.sh).
        // Falls back to Google's public TEST id so debug runs work; release builds refuse it (below).
        val admobTestId = "ca-app-pub-3940256099942544~3347511713"
        val admobId = (project.findProperty("ADMOB_APP_ID") as String?)
            ?: System.getenv("ADMOB_APP_ID")
            ?: admobTestId
        manifestPlaceholders["admobAppId"] = admobId
    }

    signingConfigs {
        create("release") {
            if (keystorePropertiesFile.exists()) {
                keyAlias = keystoreProperties["keyAlias"] as String
                keyPassword = keystoreProperties["keyPassword"] as String
                storeFile = file(keystoreProperties["storeFile"] as String)
                storePassword = keystoreProperties["storePassword"] as String
            }
        }
    }

    buildTypes {
        release {
            // Release builds are signed with your own key (android/key.properties).
            // Without that file it falls back to the debug key so local runs still work -
            // NEVER publish a build signed that way.
            signingConfig = if (keystorePropertiesFile.exists())
                signingConfigs.getByName("release") else signingConfigs.getByName("debug")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
    }
}

// Block release builds that would ship Google's demo AdMob ID.
gradle.taskGraph.whenReady {
    val releaseRequested = allTasks.any { it.name.contains("Release", ignoreCase = true) && it.project == project }
    val id = (project.findProperty("ADMOB_APP_ID") as String?) ?: System.getenv("ADMOB_APP_ID")
    if (releaseRequested && (id == null || id.startsWith("ca-app-pub-3940256099942544"))) {
        throw GradleException("Release build needs a real ADMOB_APP_ID (env var or -PADMOB_APP_ID).")
    }
}

dependencies {
    // Play Integrity API (proves the request comes from the genuine app on a genuine device)
    implementation("com.google.android.play:integrity:1.4.0")

    // ---- ironSource / Unity LevelPlay mediation (unity_levelplay_mediation plugin) ----
    // Play Services pieces LevelPlay needs (versions from the plugin's README / example app)
    implementation("com.google.android.gms:play-services-appset:16.1.0")
    implementation("com.google.android.gms:play-services-ads-identifier:18.2.0")
    implementation("com.google.android.gms:play-services-basement:18.3.0")
    // Mediation adapters so LevelPlay can also fill with Meta and AdMob demand. The Meta SDK
    // itself comes from packages/easy_audience_network, the AdMob SDK from google_mobile_ads.
    // CHECK these two lines against the LevelPlay "Meta Audience Network" and "AdMob" Android
    // guides: the adapter version must match LevelPlay SDK 9.6.1 (see ADS.md).
    implementation("com.unity3d.ads-mediation:facebook-adapter:5.+")
    implementation("com.unity3d.ads-mediation:admob-adapter:5.+")
}

flutter {
    source = "../.."
}
