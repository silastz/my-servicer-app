# Wallet top up (Pocket Fund)

Screen: `lib/screens/top_up_screen.dart` (opened from the wallet page's Top Up button).

1. User enters an amount (min TSh 1,000, max TSh 5,000,000) and picks Mobile Money or Card.
2. Mobile Money: `POST /payments/mobile/request` with `purpose: WALLET_TOPUP`, then the
   usual waiting dialog polls `GET /payments/status/{reference}`.
   Card: `POST /payments/card/checkout` with `purpose: WALLET_TOPUP` (hosted page).
3. When the payment is PAID the app calls `POST /wallet/deposit` with
   `{amount, reference, method}`.

Backend must:
- Credit the wallet at most once per `reference` (idempotent). If the server already credits
  the wallet itself when a `WALLET_TOPUP` payment is confirmed, `/wallet/deposit` must return
  the wallet as it is for that reference and not add the amount again.
- Accept the extra `reference` and `method` fields (older servers can ignore them).
