import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/security_settings.dart';
import '../services/session_manager.dart';
import '../widgets/app_ui.dart';
import 'nida_verification_screen.dart';

/// "Verify My Legal Name": the user types their legal name in Identity Verification and the server
/// checks it against the ID. Only a legal name is shown. Providers see it on this user's requests only while
/// Hide My ID is OFF.
class VerifyNameScreen extends StatefulWidget {
  const VerifyNameScreen({super.key});

  /// Short label for the profile menu, or null when nothing has been sent yet.
  static String? statusLabel(bool en) {
    switch (SessionManager.getVerifiedNameStatus()) {
      case 'VERIFIED':
        return en ? 'Verified' : 'Imethibitishwa';
      case 'PENDING':
        return en ? 'In review' : 'Inakaguliwa';
      case 'REJECTED':
        return en ? 'Rejected' : 'Imekataliwa';
    }
    if (SessionManager.isLegalNameConfirming()) return en ? 'Confirming' : 'Inathibitishwa';
    return null;
  }

  @override
  State<VerifyNameScreen> createState() => _VerifyNameScreenState();
}

class _VerifyNameScreenState extends State<VerifyNameScreen> {
  bool _loading = true;
  String? _reason;

  bool get _en => AppStrings.isEnglish;
  String get _status => SessionManager.getVerifiedNameStatus();
  String get _name => SessionManager.getVerifiedName();

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final r = await ApiService.fetchVerifiedName();
    if (!mounted) return;
    setState(() {
      _loading = false;
      _reason = r?.reason;
    });
  }

  Future<void> _openId() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => const NidaVerificationScreen()));
    if (!mounted) return;
    setState(() => _loading = true);
    await _refresh();
  }

  (String, Color) get _pill {
    switch (_status) {
      case 'VERIFIED':
        return (_en ? 'Verified' : 'Imethibitishwa', AppColors.successDark);
      case 'PENDING':
        return (_en ? 'In review' : 'Inakaguliwa', AppColors.warningDark);
      case 'REJECTED':
        return (_en ? 'Rejected' : 'Imekataliwa', AppColors.danger);
    }
    if (SessionManager.isLegalNameConfirming()) {
      return (_en ? 'Confirming with your ID' : 'Inathibitishwa na kitambulisho', AppColors.warningDark);
    }
    return (_en ? 'Not verified' : 'Haijathibitishwa', AppColors.textSecondary);
  }

  Widget _note(IconData icon, Color color, Color bg, String text) => Container(
        margin: const EdgeInsets.only(top: 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(16)),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 20, color: color),
            const SizedBox(width: 10),
            Expanded(child: Text(text, style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textPrimary))),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    final (pillText, pillColor) = _pill;
    final verified = _status == 'VERIFIED' && _name.isNotEmpty;
    final hidden = SecuritySettings.hideMyId;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Text(_en ? 'Verify My Legal Name' : 'Thibitisha Jina Langu la Kisheria',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
        iconTheme: const IconThemeData(color: AppColors.textPrimary),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(16, 22, 16, 18),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.border),
            ),
            child: Column(
              children: [
                const Icon(Icons.badge_outlined, size: 40, color: AppColors.primary),
                const SizedBox(height: 10),
                if (_loading)
                  const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2))
                else if (verified) ...[
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Flexible(
                        child: Text(_name,
                            textAlign: TextAlign.center,
                            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                      ),
                      const SizedBox(width: 6),
                      const Icon(Icons.verified_rounded, size: 20, color: AppColors.primary),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(_en ? 'Verified against your ID' : 'Limethibitishwa dhidi ya kitambulisho chako',
                      style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                ] else
                  Text(
                    SessionManager.isLegalNameConfirming()
                        ? (_en ? 'Taking your legal name from your ID' : 'Inachukua jina lako la kisheria kutoka kitambulisho')
                        : (_en ? 'Add your legal name as on your ID' : 'Weka jina lako la kisheria kama kwenye kitambulisho'),
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                  ),
                const SizedBox(height: 10),
                StatusPill(text: pillText, color: pillColor),
              ],
            ),
          ),
          if (_status == 'REJECTED')
            _note(
              Icons.error_outline_rounded,
              AppColors.danger,
              AppColors.dangerLight,
              (_reason ?? (_en ? 'The name you typed does not match your ID.' : 'Jina ulilolandika halilingani na kitambulisho chako.')) +
                  (_en ? ' Check the spelling or upload a clearer ID.' : ' Angalia herufi au pakia kitambulisho kilicho wazi zaidi.'),
            ),
          if (_status == 'PENDING')
            _note(
              Icons.hourglass_top_rounded,
              AppColors.warningDark,
              AppColors.warningLight,
              _en ? 'Your ID is being reviewed. Your name will appear here once it is verified.' : 'Kitambulisho chako kinakaguliwa. Jina lako litaonekana hapa likishathibitishwa.',
            ),
          if (verified && hidden)
            _note(
              Icons.visibility_off_outlined,
              AppColors.primary,
              AppColors.primaryLight,
              _en
                  ? 'Hide My ID is ON, so providers see your stage name, not this name. Turn it off in Settings to show it.'
                  : 'Ficha Utambulisho kimewashwa, kwa hiyo watoa huduma wanaona jina lako la kikazi, si jina hili. Kizime kwenye Mipangilio ili lionekane.',
            ),
          if (verified && !hidden)
            _note(
              Icons.verified_rounded,
              AppColors.successDark,
              AppColors.successLight,
              _en ? 'Providers see this legal name on your requests.' : 'Watoa huduma wanaona jina hili la kisheria kwenye maombi yako.',
            ),
          if (!verified && SessionManager.isLegalNameConfirming())
            _note(
              Icons.sync_rounded,
              AppColors.warningDark,
              AppColors.warningLight,
              _en
                  ? 'Your ID is verified, so your legal name is taken from your ID automatically. You do not need to type it.'
                  : 'Kitambulisho chako kimethibitishwa, kwa hiyo jina lako la kisheria linachukuliwa kutoka kitambulisho chako moja kwa moja. Huhitaji kuliandika.',
            )
          else if (!verified)
            _note(
              Icons.info_outline_rounded,
              AppColors.primary,
              AppColors.primaryLight,
              _en
                  ? 'Type your legal name as on your ID in Identity Verification. The server checks it against your ID. Once verified, providers see it on your requests while Hide My ID is off. Your ID number is never shown.'
                  : 'Andika jina lako la kisheria kama kwenye kitambulisho ndani ya Uthibitisho wa Utambulisho. Seva inalihakiki dhidi ya kitambulisho chako. Likishathibitishwa, watoa huduma hulione kwenye maombi yako Ficha Utambulisho kikizimwa. Namba ya kitambulisho haionyeshwi kamwe.',
            ),
          const SizedBox(height: 20),
          AppButton.primary(
            label: verified
                ? (_en ? 'View my ID verification' : 'Angalia uthibitisho wa kitambulisho')
                : (_en ? 'Verify with my ID' : 'Thibitisha kwa kitambulisho'),
            onPressed: _openId,
          ),
        ],
      ),
    );
  }
}
