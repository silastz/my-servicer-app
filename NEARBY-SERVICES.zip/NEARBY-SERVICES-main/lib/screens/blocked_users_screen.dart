import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/block_service.dart';
import '../widgets/block_user_dialog.dart';

/// Profile > Blocked Users: everyone the signed-in user has blocked, with Unblock.
class BlockedUsersScreen extends StatefulWidget {
  const BlockedUsersScreen({super.key});

  @override
  State<BlockedUsersScreen> createState() => _BlockedUsersScreenState();
}

class _BlockedUsersScreenState extends State<BlockedUsersScreen> {
  bool _syncing = true;

  bool get _en => AppStrings.isEnglish;

  @override
  void initState() {
    super.initState();
    BlockService.changed.addListener(_refresh);
    _sync();
  }

  @override
  void dispose() {
    BlockService.changed.removeListener(_refresh);
    super.dispose();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  Future<void> _sync() async {
    await BlockService.sync();
    if (mounted) setState(() => _syncing = false);
  }

  String _date(DateTime? d) {
    if (d == null) return '';
    final l = d.toLocal();
    const m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return '${l.day} ${m[l.month - 1]} ${l.year}';
  }

  @override
  Widget build(BuildContext context) {
    final users = BlockService.blocked;
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _en ? 'Blocked Users' : 'Watumiaji Walizuiwa',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: RefreshIndicator(
        color: AppColors.primary,
        onRefresh: _sync,
        child: users.isEmpty
            ? ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                children: [
                  SizedBox(height: MediaQuery.of(context).size.height * 0.2),
                  if (_syncing)
                    const Center(child: CircularProgressIndicator(color: AppColors.primary))
                  else
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 36),
                      child: Column(
                        children: [
                          Container(
                            width: 72,
                            height: 72,
                            decoration: const BoxDecoration(color: AppColors.primaryLight, shape: BoxShape.circle),
                            child: const Icon(Icons.block_rounded, size: 34, color: AppColors.primary),
                          ),
                          const SizedBox(height: 16),
                          Text(
                            _en ? 'No blocked users' : 'Hakuna watumiaji walizuiwa',
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            _en
                                ? 'People you block will appear here. You can block someone from their profile or from a chat.'
                                : 'Watu unaowazuia wataonekana hapa. Unaweza kumzuia mtu kupitia wasifu wake au mazungumzo.',
                            textAlign: TextAlign.center,
                            style: const TextStyle(fontSize: 13, height: 1.45, color: AppColors.textSecondary),
                          ),
                        ],
                      ),
                    ),
                ],
              )
            : ListView.separated(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                itemCount: users.length + 1,
                separatorBuilder: (_, _) => const SizedBox(height: 10),
                itemBuilder: (_, i) {
                  if (i == 0) {
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 2),
                      child: Text(
                        _en
                            ? "Blocked users can't message you, and you won't see their services or chats."
                            : 'Watumiaji walizuiwa hawawezi kukutumia ujumbe, na hutaona huduma wala mazungumzo yao.',
                        style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textSecondary),
                      ),
                    );
                  }
                  final u = users[i - 1];
                  return Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 22,
                          backgroundColor: AppColors.primaryLight,
                          child: Text(
                            u.name.isNotEmpty ? u.name.substring(0, 1).toUpperCase() : '?',
                            style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary, fontSize: 16),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                u.name,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                              ),
                              if (u.blockedAt != null)
                                Text(
                                  '${_en ? 'Blocked' : 'Amezuiwa'} ${_date(u.blockedAt)}',
                                  style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                                ),
                              if (BlockReasons.label(u.reason, en: _en).isNotEmpty)
                                Text(
                                  '${_en ? 'Reason' : 'Sababu'}: ${BlockReasons.label(u.reason, en: _en)}',
                                  style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                                ),
                            ],
                          ),
                        ),
                        OutlinedButton(
                          onPressed: () => BlockUserDialog.confirmUnblock(context, userId: u.id, name: u.name),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: AppColors.primary,
                            side: const BorderSide(color: AppColors.primary),
                            padding: const EdgeInsets.symmetric(horizontal: 14),
                            minimumSize: const Size(0, 34),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          ),
                          child: Text(_en ? 'Unblock' : 'Fungulia', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                        ),
                      ],
                    ),
                  );
                },
              ),
      ),
    );
  }
}
