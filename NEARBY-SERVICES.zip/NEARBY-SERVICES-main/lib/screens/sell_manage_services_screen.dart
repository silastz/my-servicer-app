import 'package:flutter/material.dart';
import '../services/load_guard.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/draft_service.dart';
import '../services/session_manager.dart';
import '../services/share_service.dart';
import '../models/boost.dart';
import '../widgets/boost_badge.dart';
import '../widgets/boost_service_sheet.dart';
import '../widgets/skeleton_loader.dart';
import 'add_edit_service_screen.dart';
import 'service_details_screen.dart';
import 'register_provider_screen.dart';
import '../services/data_sync.dart';
import '../services/currency_service.dart';

class SellManageServicesScreen extends StatefulWidget {
  final VoidCallback? onBackToHome;

  const SellManageServicesScreen({super.key, this.onBackToHome});

  @override
  State<SellManageServicesScreen> createState() => _SellManageServicesScreenState();
}

class _SellManageServicesScreenState extends State<SellManageServicesScreen> {
  String _activeTab = 'Active'; // 'Active', 'Pending', 'Inactive', 'Drafts'
  bool _isLoading = true;
  List<dynamic> _services = [];
  List<Map<String, dynamic>> _drafts = [];

  // Something was written to the server elsewhere (booking, accept, wallet, review...): re-fetch.
  void _onDataChanged() {
    if (mounted) _loadSellerServices(silent: true);
  }

  @override
  void dispose() {
    DataSync.changed.removeListener(_onDataChanged);
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    DataSync.changed.addListener(_onDataChanged);
    _loadSellerServices();
    _loadDrafts();
  }

  Future<void> _loadDrafts() async {
    final list = await DraftService.list();
    if (mounted) setState(() => _drafts = list);
  }

  /// Opens a draft in the form. [publish] jumps to the last step, ready to publish.
  Future<void> _openDraft(Map<String, dynamic> draft, {bool publish = false}) async {
    final changed = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => AddEditServiceScreen(draft: draft, startStep: publish ? 2 : 0)),
    );
    if (!mounted) return;
    await _loadDrafts();
    if (changed == true) _loadSellerServices(silent: true);
  }

  Future<void> _deleteDraft(Map<String, dynamic> draft) async {
    final en = AppStrings.isEnglish;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(en ? 'Delete draft?' : 'Futa rasimu?'),
        content: Text(en ? 'This draft will be removed. It can\'t be undone.' : 'Rasimu hii itaondolewa. Haiwezi kurudishwa.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(en ? 'Cancel' : 'Ghairi')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(en ? 'Delete' : 'Futa', style: const TextStyle(color: AppColors.danger)),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await DraftService.delete(draft['draftId']?.toString() ?? '');
    await _loadDrafts();
  }

  Widget _buildDraftsList() {
    final en = AppStrings.isEnglish;
    if (_drafts.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.edit_note_rounded, size: 48, color: Colors.grey.shade400),
            const SizedBox(height: 12),
            Text(
              en ? 'No drafts yet. Tap "Save draft" while posting a service.' : 'Hakuna rasimu bado. Bonyeza "Hifadhi rasimu" ukiwa unaweka huduma.',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
            ),
          ],
        ),
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: _drafts.length,
      separatorBuilder: (_, _) => const SizedBox(height: 14),
      itemBuilder: (context, index) {
        final d = _drafts[index];
        final title = (d['title'] ?? '').toString();
        final category = (d['category'] ?? 'General').toString();
        final price = (d['price'] as num?)?.toInt() ?? 0;
        final priceText = price > 0
            ? CurrencyService.format(price)
            : (en ? 'No price yet' : 'Bei bado');
        final images = (d['imageUrls'] as List?) ?? const [];
        final cover = images.isNotEmpty ? images.first.toString() : '';
        final saved = DateTime.tryParse('${d['savedAt']}')?.toLocal();
        final savedText = saved == null
            ? ''
            : '${saved.day.toString().padLeft(2, '0')}/${saved.month.toString().padLeft(2, '0')}/${saved.year}';

        return Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              InkWell(
                onTap: () => _openDraft(d),
                borderRadius: BorderRadius.circular(10),
                child: Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        width: 52,
                        height: 52,
                        color: AppColors.primaryLight,
                        child: cover.startsWith('http')
                            ? Image.network(
                                cover,
                                fit: BoxFit.cover,
                                errorBuilder: (_, _, _) =>
                                    const Icon(Icons.design_services_rounded, color: AppColors.primary, size: 24),
                              )
                            : const Icon(Icons.design_services_rounded, color: AppColors.primary, size: 24),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            title.isEmpty ? (en ? 'Untitled draft' : 'Rasimu bila jina') : title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            '$priceText • $category',
                            style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              const Icon(Icons.edit_note_rounded, size: 14, color: AppColors.warningDark),
                              const SizedBox(width: 3),
                              Text(
                                savedText.isEmpty ? (en ? 'Draft' : 'Rasimu') : '${en ? 'Draft' : 'Rasimu'} • $savedText',
                                style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.warningDark),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => _openDraft(d),
                      icon: const Icon(Icons.edit_outlined, size: 16),
                      label: Text(en ? 'Edit' : 'Hariri'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => _deleteDraft(d),
                      icon: const Icon(Icons.delete_outline_rounded, size: 16, color: AppColors.danger),
                      label: Text(en ? 'Delete' : 'Futa', style: const TextStyle(color: AppColors.danger)),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () => _openDraft(d, publish: true),
                      icon: const Icon(Icons.publish_rounded, size: 16),
                      label: Text(en ? 'Publish' : 'Chapisha'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        foregroundColor: Colors.white,
                        elevation: 0,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  final _guard = LoadGuard();
  bool _servicesLoaded = false;

  Future<void> _loadSellerServices({bool silent = false, bool refresh = false}) async {
    final id = _guard.next();
    if (!(silent || refresh) || !_servicesLoaded) setState(() => _isLoading = true);
    final list = await ApiService.fetchSellerServicesOrNull();
    if (!mounted || !_guard.isLatest(id)) return; // a newer load is running
    if (list == null) {
      // No answer from the server: keep the services already on screen.
      setState(() => _isLoading = false);
      if (!silent || !_servicesLoaded) showLoadFailed(context, _loadSellerServices);
      return;
    }
    setState(() {
      _services = list;
      _servicesLoaded = true;
      _isLoading = false;
    });
  }

  /// Opens the full-page Add / Edit Service flow (no more modal).
  Future<void> _openAddEditService({Map<String, dynamic>? existing}) async {
    final saved = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => AddEditServiceScreen(existing: existing)),
    );
    if (saved == true && mounted) {
      _loadSellerServices(silent: true);
    }
  }

  /// Opens the public service page, exactly as clients see it.
  Future<void> _openViewService(Map<String, dynamic> item) async {
    final id = item['id']?.toString() ?? '';
    if (id.isEmpty) return;
    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);
    final service = await ApiService.fetchServiceById(id);
    if (!mounted) return;
    if (service == null) {
      messenger.showSnackBar(
        SnackBar(
          backgroundColor: AppColors.danger,
          content: Text(AppStrings.isEnglish ? 'Could not open the service. Try again.' : 'Imeshindwa kufungua huduma. Jaribu tena.'),
        ),
      );
      return;
    }
    navigator.push(MaterialPageRoute(builder: (_) => ServiceDetailsScreen(service: service)));
  }

  /// Opens the Boost page for one of the provider's services.
  /// (A successful boost bumps DataSync, which re-fetches this list.)
  Future<void> _openBoost(Map<String, dynamic> item) async {
    final id = item['id']?.toString() ?? '';
    if (id.isEmpty) return;
    final info = BoostInfo.fromJson(item);
    await BoostServiceSheet.show(
      context,
      serviceId: id,
      title: (item['title'] ?? 'Huduma').toString(),
      boostedUntil: info.active ? info.until : null,
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppLanguage>(
      valueListenable: AppStrings.currentLanguage,
      builder: (context, _, _) {
        final bool isProvider = SessionManager.isLoggedIn() && SessionManager.getRole() == 'ROLE_SELLER';
        return Scaffold(
          backgroundColor: AppColors.surface,
          appBar: AppBar(
            backgroundColor: AppColors.surface,
            elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () {
            if (widget.onBackToHome != null) {
              widget.onBackToHome!();
            } else if (Navigator.canPop(context)) {
              Navigator.pop(context);
            }
          },
        ),
        title: Text(
          // Guests & buyers are NOT on a services page: they see the registration page.
          // Only providers (sellers) see "My Services".
          isProvider
              ? AppStrings.sellMyServicesTitle
              : (AppStrings.isEnglish ? 'Register as Provider' : 'Jisajili kama Mtoa Huduma'),
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        actions: [
          // "Add Service" is for providers only (hidden for guests & buyers)
          if (isProvider)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            child: SizedBox(
              height: 36,
              child: ElevatedButton.icon(
                onPressed: () => _openAddEditService(),
                icon: const Icon(Icons.add, size: 16),
                label: Text(AppStrings.sellAddService),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                ),
              ),
            ),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: (!SessionManager.isLoggedIn() || SessionManager.getRole() != 'ROLE_SELLER')
          ? SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      color: AppColors.primaryLight,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.primary.withValues(alpha: 0.15),
                          blurRadius: 16,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: const Icon(Icons.storefront_rounded, size: 40, color: AppColors.primary),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    AppStrings.profileBecomeSeller,
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppColors.textPrimary),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    AppStrings.isEnglish
                        ? 'Start selling and offering your services to clients right near you. Join thousands of trusted service providers across ${CurrencyService.countryName}!'
                        : 'Anza kuuza na kutoa huduma zako kwa wateja waliokaribu nawe. Jiunge na maelfu ya watoa huduma wanaoaminika ${CurrencyService.countryName} nzima!',
                    style: const TextStyle(fontSize: 13, height: 1.5, color: AppColors.textSecondary),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 24),

                  // Benefits checklist
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppColors.background,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          AppStrings.isEnglish ? 'Benefits of Becoming a Provider:' : 'Faida za Kuwa Mtoa Huduma:',
                          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                        ),
                        const SizedBox(height: 12),
                        _buildBenefitRow(
                          Icons.near_me_rounded,
                          AppStrings.isEnglish ? 'Nearby Clients' : 'Wateja Waliokaribu',
                          AppStrings.isEnglish ? 'Get service requests from customers located in your neighborhood or local area.' : 'Pata maombi ya kazi kutoka kwa wateja waliopo mtaa au eneo lako.',
                        ),
                        const SizedBox(height: 10),
                        _buildBenefitRow(
                          Icons.security_rounded,
                          AppStrings.isEnglish ? 'Safe Escrow Payments' : 'Malipo Salama ya Escrow',
                          AppStrings.isEnglish ? 'Job payments are held securely until the task is marked completed.' : 'Fedha za kazi zinashikiliwa kwa usalama hadi kazi inapokamilika.',
                        ),
                        const SizedBox(height: 10),
                        _buildBenefitRow(
                          Icons.verified_rounded,
                          AppStrings.isEnglish ? 'Verified Badge (Green)' : 'Beji ya Uhakiki (Green)',
                          AppStrings.isEnglish ? 'Verify your NIDA identity and build great trust with customers.' : 'Thibitisha NIDA yako na ujenge uaminifu mkubwa kwa wateja.',
                        ),
                        const SizedBox(height: 10),
                        _buildBenefitRow(
                          Icons.lock_clock_rounded,
                          AppStrings.isEnglish ? 'Contact Privacy' : 'Faragha ya Mawasiliano',
                          AppStrings.isEnglish ? 'It is your choice to keep direct contacts locked until the client confirms the booking.' : 'Uamuzi ni wako kufunga mawasiliano yako mpaka mteja athibitishe oda.',
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Action Button
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: () async {
                        final res = await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => RegisterProviderScreen(
                              isUpgradeFromBuyer: SessionManager.isLoggedIn(),
                            ),
                          ),
                        );
                        if (res == true && mounted) {
                          _loadSellerServices(silent: true);
                          setState(() {});
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        elevation: 0,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: Text(
                        AppStrings.regProviderTitle,
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            )
              : Column(
              children: [
                // Filter Tabs (Active, Pending, Inactive)
          Container(
            color: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: Row(
              children: ['Active', 'Pending', 'Inactive', 'Drafts'].map((tab) {
                final isSelected = _activeTab == tab;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: GestureDetector(
                    onTap: () => setState(() => _activeTab = tab),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                      decoration: BoxDecoration(
                        color: isSelected ? AppColors.primary : AppColors.borderLight,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Text(
                        tab == 'Drafts' && _drafts.isNotEmpty ? 'Drafts (${_drafts.length})' : tab,
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: isSelected ? Colors.white : AppColors.textSecondary,
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
          const Divider(height: 1, color: AppColors.borderLight),

          // Managed Services List or Shimmer
          Expanded(
            child: _activeTab == 'Drafts'
                ? _buildDraftsList()
                : _isLoading
                ? ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: 3,
                    separatorBuilder: (_, _) => const SizedBox(height: 14),
                    itemBuilder: (_, _) => const VerticalListCardSkeleton(),
                  )
                : _services.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.storefront_outlined, size: 48, color: Colors.grey.shade400),
                            const SizedBox(height: 12),
                            Text(
                              AppStrings.sellNoServicesTitle,
                              style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
                            ),
                            const SizedBox(height: 12),
                            ElevatedButton.icon(
                              onPressed: () => _openAddEditService(),
                              icon: const Icon(Icons.add, size: 16),
                              label: Text(AppStrings.sellAddService),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.primary,
                                foregroundColor: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      )
                    : RefreshIndicator(
                        onRefresh: () => _loadSellerServices(refresh: true),
                        child: ListView.separated(
                          padding: const EdgeInsets.all(16),
                          itemCount: _services.length,
                          separatorBuilder: (_, _) => const SizedBox(height: 14),
                          itemBuilder: (context, index) {
                            final item = _services[index] as Map<String, dynamic>;
                            final title = item['title'] ?? 'Huduma';
                            final category = item['category'] ?? 'General';
                            final price = (item['price'] as num?)?.toDouble() ?? 0.0;
                            final rateFormatted = CurrencyService.format(price);
                            final isLocked = item['isInfoLocked'] == true;
                            final boost = BoostInfo.fromJson(item);

                            return Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: AppColors.border),
                              ),
                              child: Row(
                                children: [
                                  // Category Avatar Icon Box
                                  InkWell(
                                    onTap: () => _openViewService(item),
                                    borderRadius: BorderRadius.circular(10),
                                    child: Container(
                                      width: 52,
                                      height: 52,
                                      decoration: BoxDecoration(
                                        color: AppColors.primaryLight,
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: const Icon(Icons.design_services_rounded, color: AppColors.primary, size: 24),
                                    ),
                                  ),
                                  const SizedBox(width: 12),

                                  // Title, Rate & Active badge
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        GestureDetector(
                                          behavior: HitTestBehavior.opaque,
                                          onTap: () => _openViewService(item),
                                          child: Text(
                                            title,
                                            style: const TextStyle(
                                              fontSize: 13,
                                              fontWeight: FontWeight.w800,
                                              color: AppColors.textPrimary,
                                            ),
                                          ),
                                        ),
                                        if ((item['shortDescription'] ?? '').toString().trim().isNotEmpty) ...[
                                          const SizedBox(height: 2),
                                          Text(
                                            item['shortDescription'].toString().trim(),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                                          ),
                                        ],
                                        const SizedBox(height: 2),
                                        Text(
                                          '$rateFormatted • $category',
                                          style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                                        ),
                                        const SizedBox(height: 4),
                                        Row(
                                          children: [
                                            const Icon(Icons.check_circle_rounded, size: 12, color: AppColors.success),
                                            const SizedBox(width: 3),
                                            const Text(
                                              'Active',
                                              style: TextStyle(
                                                fontSize: 11,
                                                fontWeight: FontWeight.w700,
                                                color: AppColors.success,
                                              ),
                                            ),
                                            if (boost.active) ...[
                                              const SizedBox(width: 8),
                                              const BoostBadge(compact: true),
                                              if (boost.left(AppStrings.isEnglish).isNotEmpty) ...[
                                                const SizedBox(width: 4),
                                                Text(
                                                  boost.left(AppStrings.isEnglish),
                                                  style: const TextStyle(fontSize: 9, color: AppColors.textSecondary),
                                                ),
                                              ],
                                            ],
                                            if (isLocked) ...[
                                              const SizedBox(width: 8),
                                              Container(
                                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                                                decoration: BoxDecoration(
                                                  color: AppColors.borderLight,
                                                  borderRadius: BorderRadius.circular(4),
                                                ),
                                                child: Row(
                                                  children: [
                                                    const Icon(Icons.lock_rounded, size: 10, color: AppColors.textSecondary),
                                                    const SizedBox(width: 2),
                                                    Text(AppStrings.sellContactsLockedBadge, style: const TextStyle(fontSize: 9, color: AppColors.textSecondary)),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                  IconButton(
                                    tooltip: AppStrings.isEnglish ? 'Share' : 'Shiriki',
                                    icon: const Icon(Icons.share_outlined, color: AppColors.primary, size: 20),
                                    visualDensity: VisualDensity.compact,
                                    onPressed: () => ShareService.showServiceSheet(
                                      context,
                                      title: title.toString(),
                                      priceText: rateFormatted,
                                      providerName: SessionManager.getStageName(),
                                      category: category.toString(),
                                          serviceId: item['id']?.toString(),
                                    ),
                                  ),
                                  IconButton(
                                    tooltip: AppStrings.isEnglish ? 'Boost service' : 'Tangaza huduma',
                                    icon: const Icon(Icons.bolt_rounded, color: AppColors.warningDark, size: 22),
                                    visualDensity: VisualDensity.compact,
                                    onPressed: () => _openBoost(item),
                                  ),
                                  // 3-dots action menu
                                  PopupMenuButton<String>(
                                    icon: const Icon(Icons.more_vert_rounded, color: AppColors.textMuted, size: 20),
                                    onSelected: (value) {
                                      if (value == 'view') _openViewService(item);
                                      if (value == 'edit') _openAddEditService(existing: item);
                                      if (value == 'boost') _openBoost(item);
                                      if (value == 'share') {
                                        ShareService.showServiceSheet(
                                          context,
                                          title: title.toString(),
                                          priceText: rateFormatted,
                                          providerName: SessionManager.getStageName(),
                                          category: category.toString(),
                                          serviceId: item['id']?.toString(),
                                        );
                                      }
                                    },
                                    itemBuilder: (_) => [
                                      PopupMenuItem(
                                        value: 'view',
                                        child: Row(
                                          children: [
                                            const Icon(Icons.visibility_outlined, size: 18, color: AppColors.textPrimary),
                                            const SizedBox(width: 10),
                                            Text(AppStrings.isEnglish ? 'View Service' : 'Angalia Huduma'),
                                          ],
                                        ),
                                      ),
                                      PopupMenuItem(
                                        value: 'share',
                                        child: Row(
                                          children: [
                                            const Icon(Icons.share_outlined, size: 18, color: AppColors.textPrimary),
                                            const SizedBox(width: 10),
                                            Text(AppStrings.isEnglish ? 'Share Service' : 'Shiriki Huduma'),
                                          ],
                                        ),
                                      ),
                                      PopupMenuItem(
                                        value: 'boost',
                                        child: Row(
                                          children: [
                                            const Icon(Icons.bolt_rounded, size: 18, color: AppColors.warningDark),
                                            const SizedBox(width: 10),
                                            Text(AppStrings.isEnglish ? 'Boost Service' : 'Tangaza Huduma'),
                                          ],
                                        ),
                                      ),
                                      PopupMenuItem(
                                        value: 'edit',
                                        child: Row(
                                          children: [
                                            const Icon(Icons.edit_outlined, size: 18, color: AppColors.textPrimary),
                                            const SizedBox(width: 10),
                                            Text(AppStrings.isEnglish ? 'Edit Service' : 'Hariri Huduma'),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ),
          ),
        ],
      ),
    );
      },
    );
  }

  Widget _buildBenefitRow(IconData icon, String title, String description) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: AppColors.primaryLight,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, size: 16, color: AppColors.primary),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
              ),
              const SizedBox(height: 1),
              Text(
                description,
                style: const TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.3),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
