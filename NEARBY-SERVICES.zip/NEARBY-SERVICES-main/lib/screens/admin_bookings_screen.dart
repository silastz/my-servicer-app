import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../services/api_service.dart';
import '../widgets/admin_common.dart';
import '../widgets/app_ui.dart';

/// Admin: every booking, with the dispute evidence and the two override buttons.
/// Server: GET /escrow/admin/all, GET /admin/escrow/{ref}/evidence,
/// POST /escrow/admin/release/{ref} (pay the provider) and /escrow/admin/refund/{ref} (pay the buyer back).
class AdminBookingsScreen extends StatefulWidget {
  const AdminBookingsScreen({super.key});

  @override
  State<AdminBookingsScreen> createState() => _AdminBookingsScreenState();
}

class _AdminBookingsScreenState extends State<AdminBookingsScreen> {
  bool _loading = true;
  bool _forbidden = false;
  bool _failed = false;
  List<Map<String, dynamic>> _all = [];
  String _q = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _failed = false;
    });
    final r = await ApiService.adminGetList('/escrow/admin/all');
    if (!mounted) return;
    setState(() {
      _loading = false;
      _forbidden = r.forbidden;
      _failed = !r.forbidden && r.items == null;
      _all = r.items ?? [];
    });
  }

  String _name(dynamic u) {
    if (u is Map) return '${u['stageName'] ?? u['name'] ?? ''}'.trim().isEmpty ? '#${u['id']}' : '${u['stageName'] ?? u['name']}';
    return '';
  }

  List<Map<String, dynamic>> get _shown {
    final q = _q.trim().toLowerCase();
    if (q.isEmpty) return _all;
    return _all.where((m) {
      final hay = '${m['transactionRef']} ${m['serviceTitle']} ${m['status']} ${m['paymentStatus']} ${_name(m['buyer'])} ${_name(m['seller'])}'.toLowerCase();
      return hay.contains(q);
    }).toList();
  }

  Future<void> _openDetail(Map<String, dynamic> m) async {
    final ref = '${m['transactionRef']}';
    final changed = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => _BookingSheet(tx: m, ref: ref, buyer: _name(m['buyer']), seller: _name(m['seller'])),
    );
    if (changed == true && mounted) _load();
  }

  @override
  Widget build(BuildContext context) {
    final list = _shown;
    final state = adminStateOrNull(
      loading: _loading,
      forbidden: _forbidden,
      failed: _failed,
      empty: list.isEmpty,
      onRetry: _load,
      emptyText: adminT('No bookings found.', 'Hakuna maombi yaliyopatikana.'),
    );
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text(adminT('All bookings', 'Maombi yote'))),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
          child: TextField(
            onChanged: (v) => setState(() => _q = v),
            decoration: InputDecoration(
              prefixIcon: const Icon(Icons.search_rounded),
              hintText: adminT('Search reference, service, name, status', 'Tafuta namba, huduma, jina, hali'),
              isDense: true,
            ),
          ),
        ),
        Expanded(
          child: RefreshIndicator(
            onRefresh: _load,
            child: state != null
                ? ListView(children: [SizedBox(height: 400, child: state)])
                : ListView.builder(
                    padding: const EdgeInsets.only(bottom: 24),
                    itemCount: list.length,
                    itemBuilder: (_, i) {
                      final m = list[i];
                      return GestureDetector(
                        onTap: () => _openDetail(m),
                        child: Container(
                          margin: const EdgeInsets.fromLTRB(16, 10, 16, 0),
                          padding: const EdgeInsets.all(14),
                          decoration: adminCardDecoration(),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Row(children: [
                              Expanded(child: Text('${m['serviceTitle'] ?? adminT('Booking', 'Ombi')}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15))),
                              Text('${m['status']}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12, color: AppColors.primary)),
                            ]),
                            adminInfoLine(adminT('Ref', 'Namba'), m['transactionRef']),
                            adminInfoLine(adminT('Buyer', 'Mnunuzi'), _name(m['buyer'])),
                            adminInfoLine(adminT('Provider', 'Mtoa huduma'), _name(m['seller'])),
                            adminInfoLine(adminT('Amount', 'Kiasi'), m['amount']),
                            adminInfoLine(adminT('Payment', 'Malipo'), m['paymentStatus']),
                          ]),
                        ),
                      );
                    },
                  ),
          ),
        ),
      ]),
    );
  }
}

class _BookingSheet extends StatefulWidget {
  final Map<String, dynamic> tx;
  final String ref;
  final String buyer;
  final String seller;
  const _BookingSheet({required this.tx, required this.ref, required this.buyer, required this.seller});

  @override
  State<_BookingSheet> createState() => _BookingSheetState();
}

class _BookingSheetState extends State<_BookingSheet> {
  Map<String, dynamic>? _evidence;
  bool _loadingEvidence = true;
  bool _evidenceFailed = false;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _loadEvidence();
  }

  Future<void> _loadEvidence() async {
    final r = await ApiService.adminGetObject('/admin/escrow/${Uri.encodeComponent(widget.ref)}/evidence');
    if (!mounted) return;
    setState(() {
      _loadingEvidence = false;
      _evidence = r.data;
      _evidenceFailed = r.data == null;
    });
  }

  Future<void> _override(bool release) async {
    final ok = await AppDialog.confirm(
      context,
      icon: release ? Icons.payments_rounded : Icons.undo_rounded,
      title: release ? adminT('Release money to provider?', 'Mlipe mtoa huduma?') : adminT('Refund the buyer?', 'Mrudishie mnunuzi pesa?'),
      message: adminT(
        'This moves the money now and cannot be undone. Booking ${widget.ref}.',
        'Hii inahamisha pesa sasa na haiwezi kutenguliwa. Ombi ${widget.ref}.',
      ),
      confirmLabel: release ? adminT('Release', 'Lipa') : adminT('Refund', 'Rudisha'),
      color: release ? AppColors.success : AppColors.danger,
    );
    if (!ok || !mounted) return;
    setState(() => _busy = true);
    final res = await ApiService.adminSend('POST', '/escrow/admin/${release ? 'release' : 'refund'}/${Uri.encodeComponent(widget.ref)}');
    if (!mounted) return;
    setState(() => _busy = false);
    if (res.error != null) {
      adminSnack(context, res.error!);
      return;
    }
    adminSnack(context, release ? adminT('Released to provider', 'Mtoa huduma amelipwa') : adminT('Refunded to buyer', 'Mnunuzi amerudishiwa'));
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final e = _evidence;
    return SafeArea(
      child: SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(20, 0, 20, 20 + MediaQuery.of(context).viewInsets.bottom),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${widget.tx['serviceTitle'] ?? adminT('Booking', 'Ombi')}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
          adminInfoLine(adminT('Ref', 'Namba'), widget.ref),
          adminInfoLine(adminT('Status', 'Hali'), widget.tx['status']),
          adminInfoLine(adminT('Buyer', 'Mnunuzi'), widget.buyer),
          adminInfoLine(adminT('Provider', 'Mtoa huduma'), widget.seller),
          adminInfoLine(adminT('Amount', 'Kiasi'), widget.tx['amount']),
          const SizedBox(height: 14),
          Text(adminT('Evidence', 'Ushahidi'), style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          if (_loadingEvidence)
            const Padding(padding: EdgeInsets.all(12), child: Center(child: CircularProgressIndicator()))
          else if (_evidenceFailed || e == null)
            Text(adminT('Could not load the evidence.', 'Imeshindwa kupakia ushahidi.'), style: const TextStyle(color: AppColors.textSecondary))
          else ...[
            adminInfoLine(adminT('Buyer phone', 'Simu ya mnunuzi'), e['buyerPhone']),
            adminInfoLine(adminT('Provider phone', 'Simu ya mtoa huduma'), e['sellerPhone']),
            adminInfoLine(adminT('Mode', 'Aina'), e['serviceMode']),
            adminInfoLine(adminT('Place', 'Mahali'), e['place']),
            adminInfoLine(adminT('Customer address', 'Anwani ya mteja'), e['customerAddress']),
            adminInfoLine(adminT('Buyer GPS', 'GPS ya mnunuzi'),
                (e['buyerLatitude'] != null && e['buyerLongitude'] != null) ? '${e['buyerLatitude']}, ${e['buyerLongitude']}' : null),
            adminInfoLine(adminT('GPS accuracy (m)', 'Usahihi wa GPS (m)'), e['buyerLocationAccuracyM']),
            adminInfoLine(adminT('GPS captured', 'GPS ilichukuliwa'), e['buyerLocationCapturedAt']),
            adminInfoLine(adminT('Scheduled', 'Imepangwa'), e['scheduledAt']),
            adminInfoLine(adminT('Created', 'Imeundwa'), e['createdAt']),
            adminInfoLine(adminT('Notes', 'Maelezo'), e['notes']),
            adminInfoLine(adminT('Payment dispute', 'Mgogoro wa malipo'), e['paymentDisputeReason']),
          ],
          const SizedBox(height: 18),
          Row(children: [
            Expanded(
              child: OutlinedButton(
                onPressed: _busy ? null : () => _override(false),
                style: OutlinedButton.styleFrom(foregroundColor: AppColors.danger),
                child: Text(adminT('Refund buyer', 'Mrudishie mnunuzi')),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: ElevatedButton(
                onPressed: _busy ? null : () => _override(true),
                child: _busy
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : Text(adminT('Release to provider', 'Mlipe mtoa huduma')),
              ),
            ),
          ]),
        ]),
      ),
    );
  }
}
