import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/payment_gateway.dart';
import '../services/api_service.dart';
import '../services/app_policy_service.dart';
import '../widgets/app_ui.dart';

/// Admin: choose which payment gateway the whole app uses (DPO, Snippe, ClickPesa, Selcom,
/// PesaPal). Snippe is the default until the admin picks another.
///
/// This screen is only a remote control. The server checks every call (403 for anyone who
/// is not an admin) and is the one that really decides which gateway creates a payment.
class AdminPaymentGatewayScreen extends StatefulWidget {
  const AdminPaymentGatewayScreen({super.key});

  @override
  State<AdminPaymentGatewayScreen> createState() => _AdminPaymentGatewayScreenState();
}

class _AdminPaymentGatewayScreenState extends State<AdminPaymentGatewayScreen> {
  bool _loading = true;
  bool _forbidden = false;
  bool _loadFailed = false;
  PaymentGateway? _active; // what the server uses now
  Set<PaymentGateway>? _available; // gateways the server really has; null = unknown, show all
  PaymentGateway _selected = PaymentGateway.defaultGateway; // what the admin tapped
  bool _cardEnabled = false; // card payments are off until the admin switches them on
  bool _cardBusy = false;

  bool get _isEn => AppStrings.isEnglish;
  bool get _changed => _active != null && _selected != _active;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _loadFailed = false;
    });
    final r = await ApiService.getAdminPaymentGateway();
    final card = await ApiService.getAdminCardEnabled();
    if (!mounted) return;
    _cardEnabled = card ?? false;
    setState(() {
      _loading = false;
      _forbidden = r.forbidden;
      _loadFailed = !r.forbidden && r.gateway == null;
      _active = r.gateway;
      _available = (r.available != null && r.available!.isNotEmpty) ? r.available : null;
      if (r.gateway != null) _selected = r.gateway!;
    });
  }

  Future<void> _save() async {
    final ok = await AppDialog.confirm(
      context,
      icon: Icons.account_balance_rounded,
      title: _isEn ? 'Switch to ${_selected.label}?' : 'Badilisha kuwa ${_selected.label}?',
      message: _isEn
          ? 'All new card and mobile money payments will go through ${_selected.label}. Payments already started finish on their own gateway.'
          : 'Malipo yote mapya ya kadi na pesa za simu yatapitia ${_selected.label}. Malipo yaliyokwisha anza yataisha kwenye gateway yake.',
      confirmLabel: _isEn ? 'Switch' : 'Badilisha',
    );
    if (!ok || !mounted) return;

    final messenger = ScaffoldMessenger.of(context);
    final saved = await ApiService.setAdminPaymentGateway(_selected);
    if (!mounted) return;
    if (saved == null) {
      final err = ApiService.lastAdminError;
      messenger.showSnackBar(SnackBar(
        content: Text(err == 'forbidden'
            ? (_isEn ? 'Only an admin can change this.' : 'Ni msimamizi pekee anayeweza kubadilisha hili.')
            : err == 'network'
                ? (_isEn ? 'No connection. Nothing was changed.' : 'Hakuna mtandao. Hakuna kilichobadilishwa.')
                : (_isEn ? 'Could not save. Nothing was changed.' : 'Imeshindwa kuhifadhi. Hakuna kilichobadilishwa.')),
      ));
      return;
    }
    setState(() {
      _active = saved;
      _selected = saved;
    });
    AppPolicyService.refresh(force: true); // this phone picks up the new value right away
    messenger.showSnackBar(SnackBar(
      content: Text(_isEn ? 'Payment gateway is now ${saved.label}.' : 'Gateway ya malipo sasa ni ${saved.label}.'),
    ));
  }

  Future<void> _setCard(bool on) async {
    final messenger = ScaffoldMessenger.of(context);
    setState(() => _cardBusy = true);
    final saved = await ApiService.setAdminCardEnabled(on);
    if (!mounted) return;
    setState(() {
      _cardBusy = false;
      if (saved != null) _cardEnabled = saved;
    });
    if (saved == null) {
      messenger.showSnackBar(SnackBar(
        content: Text(_isEn ? 'Could not save. Nothing was changed.' : 'Imeshindwa kuhifadhi. Hakuna kilichobadilishwa.'),
      ));
      return;
    }
    AppPolicyService.refresh(force: true);
  }

  Widget _info(String text, {Color color = AppColors.primary, IconData icon = Icons.info_outline_rounded}) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.2)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 12.5, height: 1.4, color: AppColors.textPrimary))),
        ],
      ),
    );
  }

  /// Brand-ish color for each gateway's letter chip.
  Color _gatewayColor(PaymentGateway g) {
    switch (g) {
      case PaymentGateway.dpo:
        return AppColors.primaryDark;
      case PaymentGateway.snippe:
        return AppColors.successDark;
      case PaymentGateway.clickPesa:
        return AppColors.warningDark;
      case PaymentGateway.selcom:
        return const Color(0xFF7E22CE);
      case PaymentGateway.pesaPal:
        return AppColors.textPrimary;
    }
  }

  Widget _option(PaymentGateway g) {
    final selected = g == _selected;
    final isActive = g == _active;
    final isDefault = g == PaymentGateway.defaultGateway;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: selected ? AppColors.primaryLight : AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () => setState(() => _selected = g),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: selected ? AppColors.primary : AppColors.border, width: selected ? 1.6 : 1),
            ),
            child: Row(
              children: [
                Icon(selected ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded,
                    color: selected ? AppColors.primary : AppColors.textDisabled),
                const SizedBox(width: 12),
                Container(
                  width: 38,
                  height: 38,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(color: _gatewayColor(g), borderRadius: BorderRadius.circular(11)),
                  child: Text(g.label.substring(0, 1),
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: Colors.white)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(g.label,
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                ),
                if (isActive || isDefault)
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      if (isActive) StatusPill(text: _isEn ? 'Active' : 'Inatumika', color: AppColors.success),
                      if (isActive && isDefault) const SizedBox(height: 5),
                      if (isDefault) StatusPill(text: _isEn ? 'Default' : 'Chaguo-msingi', color: AppColors.primary),
                    ],
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _body() {
    if (_loading) return const Center(child: CircularProgressIndicator(color: AppColors.primary));
    if (_forbidden) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 30),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(color: AppColors.dangerLight, borderRadius: BorderRadius.circular(20)),
                child: const Icon(Icons.lock_outline_rounded, size: 30, color: AppColors.danger),
              ),
              const SizedBox(height: 14),
              Text(
                _isEn
                    ? 'This account is not an admin, so it cannot change payment settings.'
                    : 'Akaunti hii si ya msimamizi, kwa hiyo haiwezi kubadilisha mipangilio ya malipo.',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 13.5, height: 1.5, color: AppColors.textSecondary),
              ),
            ],
          ),
        ),
      );
    }
    if (_loadFailed) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(_isEn ? 'Could not load the current gateway.' : 'Imeshindwa kupakia gateway ya sasa.',
                  textAlign: TextAlign.center, style: const TextStyle(fontSize: 14, color: AppColors.textSecondary)),
              const SizedBox(height: 16),
              AppButton.primary(label: _isEn ? 'Try again' : 'Jaribu tena', onPressed: _load),
            ],
          ),
        ),
      );
    }
    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _info(_isEn
                  ? 'Choose the gateway for all card and mobile money payments. Snippe is used unless you pick another one.'
                  : 'Chagua gateway kwa malipo yote ya kadi na pesa za simu. Snippe hutumika isipokuwa uchague nyingine.'),
              const SizedBox(height: 18),
              Padding(
                padding: const EdgeInsets.only(left: 4, bottom: 10),
                child: Text(_isEn ? 'GATEWAY' : 'GATEWAY',
                    style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 0.7, color: AppColors.textSecondary)),
              ),
              for (final g in PaymentGateway.values)
                if (_available == null || _available!.contains(g)) _option(g),
              const SizedBox(height: 8),
              Container(
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppColors.border),
                ),
                child: SwitchListTile(
                  value: _cardEnabled,
                  onChanged: _cardBusy ? null : _setCard,
                  activeThumbColor: AppColors.primary,
                  title: Text(_isEn ? 'Card payments' : 'Malipo ya kadi',
                      style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                  subtitle: Text(
                    _isEn
                        ? 'Off by default. When on, Visa / Mastercard shows at checkout.'
                        : 'Imezimwa awali. Ikiwashwa, Visa / Mastercard huonekana wakati wa kulipa.',
                    style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                  ),
                ),
              ),
            ],
          ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: SizedBox(
              width: double.infinity,
              child: AppButton.primary(
                label: _isEn ? 'Save' : 'Hifadhi',
                onPressed: _changed ? _save : null,
              ),
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _isEn ? 'Payment Gateway' : 'Gateway ya Malipo',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: _body(),
    );
  }
}
