import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/session_manager.dart';
import '../widgets/skeleton_loader.dart';
import '../widgets/guest_state_placeholder.dart';
import '../widgets/cancel_booking_sheet.dart';
import 'booking_details_screen.dart';
import 'chat_thread_screen.dart';
import 'buyer_profile_screen.dart';
import '../services/data_sync.dart';
import '../services/load_guard.dart';
import '../services/payment_flow.dart';
import '../widgets/payment_flow_widgets.dart';
import '../widgets/offer_flow_widgets.dart';
import '../services/currency_service.dart';
import '../widgets/app_image.dart';

class RequestsScreen extends StatefulWidget {
  const RequestsScreen({super.key});

  @override
  State<RequestsScreen> createState() => _RequestsScreenState();
}

class _RequestsScreenState extends State<RequestsScreen> {
  // Navigation tabs: 'My Requests' (Buyer) vs 'Incoming' (Seller) vs 'Outgoing' (Seller Outgoing)
  String _activeTab = 'My Requests'; 
  String _statusFilter = 'All'; // 'All', 'Pending', 'Accepted', 'Completed'
  // Offers tab: 'Received' (price offers on my services) or 'Sent' (offers I made as a buyer).
  String _offerView = SessionManager.getRole() == 'ROLE_SELLER' ? 'Received' : 'Sent';
  bool _isLoading = true;
  List<dynamic> _transactions = [];
  final _guard = LoadGuard();
  String _dataKey = ''; // which tab/view _transactions belongs to

  // Something was written to the server elsewhere (booking, accept, wallet, review...): re-fetch.
  void _onDataChanged() {
    if (mounted) _loadData(silent: true);
  }

  @override
  void dispose() {
    DataSync.changed.removeListener(_onDataChanged);
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    DataSync.changed.addListener(_onDataChanged);
    final role = SessionManager.getRole();
    if (role == 'ROLE_SELLER') {
      _activeTab = 'Incoming';
    } else {
      _activeTab = 'My Requests';
    }
    _loadData(silent: true);
  }

  Future<void> _loadData({bool silent = false, bool refresh = false}) async {
    final id = _guard.next();
    final key = '$_activeTab|$_offerView';
    final sameView = _dataKey == key;
    // Sync reloads of the view already on screen are silent: the list stays visible.
    if (!(silent || refresh) || !sameView) setState(() => _isLoading = true);
    List<dynamic>? list;
    if (_activeTab == 'Offers') {
      list = _offerView == 'Received' ? await ApiService.fetchIncomingOffersOrNull() : await ApiService.fetchMyOffersOrNull();
    } else if (_activeTab == 'Incoming') {
      list = await ApiService.fetchSellerOrdersOrNull();
    } else {
      list = await ApiService.fetchBuyerTransactionsOrNull();
    }
    if (!mounted || !_guard.isLatest(id)) return; // an older response must not overwrite a newer one
    if (list == null) {
      // No answer from the server: keep this view's list; never show another tab's list here.
      setState(() {
        if (!sameView) _transactions = [];
        _isLoading = false;
      });
      if (!silent || !sameView) showLoadFailed(context, _loadData);
      return;
    }
    setState(() {
      _transactions = list!;
      _dataKey = key;
      _isLoading = false;
    });
  }

  static String _filterLabel(String f) {
    final en = AppStrings.isEnglish;
    switch (f) {
      case 'All':
        return en ? 'All' : 'Zote';
      case 'Pending':
        return en ? 'Pending' : 'Zinasubiri';
      case 'Accepted':
        return en ? 'Accepted' : 'Zilizokubaliwa';
      case 'Completed':
        return en ? 'Completed' : 'Zilizokamilika';
      case 'Cancelled':
        return en ? 'Cancelled' : 'Zilizoghairiwa';
    }
    return f;
  }

  /// 'accept:REF' / 'reject:REF' while that call runs (spinner on that button only).
  String _acting = '';

  Future<void> _acceptOrder(String ref) async {
    if (_acting.isNotEmpty) return;
    setState(() => _acting = 'accept:$ref');
    final res = await ApiService.acceptEscrowRequest(ref);
    if (mounted) setState(() => _acting = '');
    if (res != null && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(AppStrings.requestsAcceptedNotice),
          backgroundColor: AppColors.success,
        ),
      );
      _loadData(silent: true);
    }
  }

  Future<void> _cancelBooking(String ref, String serviceTitle, String status) async {
    if (ref.isEmpty) return;
    final done = await CancelBookingSheet.show(
      context,
      transactionRef: ref,
      serviceTitle: serviceTitle,
      status: status,
    );
    if (done == true && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(AppStrings.isEnglish ? 'Booking cancelled' : 'Oda imeghairiwa'),
          backgroundColor: AppColors.danger,
        ),
      );
      _loadData(silent: true);
    }
  }

  Future<void> _rejectOrder(String ref) async {
    if (_acting.isNotEmpty) return;
    setState(() => _acting = 'reject:$ref');
    final res = await ApiService.rejectEscrowRequest(ref);
    if (mounted) setState(() => _acting = '');
    if (res != null && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(AppStrings.requestsRejectedNotice),
          backgroundColor: AppColors.danger,
        ),
      );
      _loadData(silent: true);
    }
  }



  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppLanguage>(
      valueListenable: AppStrings.currentLanguage,
      builder: (context, _, _) {
        final isSeller = SessionManager.getRole() == 'ROLE_SELLER';

        return Scaffold(
          backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        title: Text(
          _activeTab == 'Offers'
              ? (AppStrings.isEnglish ? 'Price Offers' : 'Ofa za Bei')
              : isSeller && _activeTab == 'Incoming'
              ? (AppStrings.isEnglish ? 'Incoming Requests' : 'Maombi Yanayoingia')
              : (isSeller && _activeTab == 'Outgoing'
                  ? (AppStrings.isEnglish ? 'Outgoing Requests' : 'Maombi Yanayotoka')
                  : AppStrings.requestsTitle),
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: !SessionManager.isLoggedIn()
          ? GuestStatePlaceholder(
              icon: Icons.receipt_long_outlined,
              title: AppStrings.guestTitle,
              description: AppStrings.guestRequestsDesc,
              onLoginSuccess: () {
                _loadData(silent: true);
                setState(() {});
              },
            )
          : Column(
              children: [
                // 1. Primary Segmented Tabs
                Container(
                  color: AppColors.surface,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  child: Row(
                    children: isSeller
                        ? [
                            Expanded(
                              child: _buildTopTab(
                                label: AppStrings.isEnglish ? 'Incoming' : 'Yanayoingia',
                                isSelected: _activeTab == 'Incoming',
                                onTap: () {
                                  if (_activeTab != 'Incoming') {
                                    setState(() => _activeTab = 'Incoming');
                                    _loadData();
                                  }
                                },
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _buildTopTab(
                                label: AppStrings.isEnglish ? 'Outgoing' : 'Yanayotoka',
                                isSelected: _activeTab == 'Outgoing',
                                onTap: () {
                                  if (_activeTab != 'Outgoing') {
                                    setState(() => _activeTab = 'Outgoing');
                                    _loadData();
                                  }
                                },
                              ),
                            ),
                            const SizedBox(width: 12),
                            _offersTabButton(),
                          ]
                        : [
                            Expanded(
                              child: _buildTopTab(
                                label: AppStrings.isEnglish ? 'My Requests' : 'Maombi Yangu',
                                isSelected: _activeTab == 'My Requests',
                                onTap: () {
                                  if (_activeTab != 'My Requests') {
                                    setState(() => _activeTab = 'My Requests');
                                    _loadData();
                                  }
                                },
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _buildTopTab(
                                label: AppStrings.isEnglish ? 'Incoming' : 'Yanayoingia',
                                isSelected: _activeTab == 'Incoming',
                                onTap: () {
                                  if (_activeTab != 'Incoming') {
                                    setState(() => _activeTab = 'Incoming');
                                    _loadData();
                                  }
                                },
                              ),
                            ),
                            const SizedBox(width: 12),
                            _offersTabButton(),
                          ],
                  ),
                ),

                // 2. Status Filter Pills Bar (Buyer 'My Requests' mode - matches Screen 1)
                if (_activeTab == 'My Requests')
                  Container(
                    color: AppColors.surface,
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: ['All', 'Pending', 'Accepted', 'Completed', 'Cancelled'].map((filter) {
                          final isSelected = _statusFilter == filter;
                          return Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: GestureDetector(
                              onTap: () => setState(() => _statusFilter = filter),
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                                decoration: BoxDecoration(
                                  color: isSelected ? AppColors.primary : AppColors.borderLight,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: Text(
                                  _filterLabel(filter),
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                    color: isSelected ? Colors.white : AppColors.textSecondary,
                                  ),
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ),

                if (_activeTab == 'Offers')
                  Container(
                    color: AppColors.surface,
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                    child: Row(
                      children: ['Received', 'Sent'].map((view) {
                        final isSelected = _offerView == view;
                        return Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: GestureDetector(
                            onTap: () {
                              if (_offerView == view) return;
                              setState(() => _offerView = view);
                              _loadData();
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                              decoration: BoxDecoration(
                                color: isSelected ? AppColors.primary : AppColors.borderLight,
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: Text(
                                view == 'Received'
                                    ? (AppStrings.isEnglish ? 'Received' : 'Zilizopokelewa')
                                    : (AppStrings.isEnglish ? 'Sent' : 'Zilizotumwa'),
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: isSelected ? Colors.white : AppColors.textSecondary,
                                ),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),

                const Divider(height: 1, color: AppColors.borderLight),

                // 3. Requests List
                Expanded(
                  child: _isLoading
                      ? ListView.separated(
                          padding: const EdgeInsets.all(16),
                          itemCount: 3,
                          separatorBuilder: (_, _) => const SizedBox(height: 14),
                          itemBuilder: (_, _) => const VerticalListCardSkeleton(),
                        )
                      : _filteredTransactions.isEmpty
                          ? Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Icon(Icons.inbox_outlined, size: 48, color: AppColors.textMuted),
                                  const SizedBox(height: 12),
                                  Text(
                                    _activeTab == 'Offers'
                                        ? (AppStrings.isEnglish ? 'No price offers yet' : 'Hakuna ofa za bei bado')
                                        : AppStrings.requestsNoRequests,
                                    style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
                                  ),
                                  const SizedBox(height: 12),
                                  OutlinedButton.icon(
                                    onPressed: _loadData,
                                    icon: const Icon(Icons.refresh_rounded, size: 16),
                                    label: Text(AppStrings.retry),
                                    style: OutlinedButton.styleFrom(
                                      foregroundColor: AppColors.primary,
                                      side: const BorderSide(color: AppColors.primary),
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : RefreshIndicator(
                              onRefresh: () => _loadData(refresh: true),
                              child: ListView.separated(
                                padding: const EdgeInsets.all(16),
                                itemCount: _filteredTransactions.length,
                                separatorBuilder: (_, _) => const SizedBox(height: 14),
                                itemBuilder: (context, index) {
                                  final tx = _filteredTransactions[index] as Map<String, dynamic>;
                                  if (_activeTab == 'Offers') {
                                    return OfferCard(
                                      key: ValueKey('offer-${tx['id']}-${tx['status']}'),
                                      offer: tx,
                                      isSeller: _offerView == 'Received',
                                      onChanged: () => _loadData(silent: true),
                                    );
                                  } else if (_activeTab == 'My Requests') {
                                    return _buildBuyerRequestCard(tx, index);
                                  } else if (_activeTab == 'Incoming') {
                                    return _buildSellerIncomingCard(tx, index);
                                  } else {
                                    return _buildSellerOutgoingCard(tx, index);
                                  }
                                },
                              ),
                            ),
                ),
              ],
            ),
    );
      },
    );
  }

  Widget _offersTabButton() {
    return Expanded(
      child: _buildTopTab(
        label: AppStrings.isEnglish ? 'Offers' : 'Ofa',
        isSelected: _activeTab == 'Offers',
        onTap: () {
          if (_activeTab != 'Offers') {
            setState(() => _activeTab = 'Offers');
            _loadData();
          }
        },
      ),
    );
  }

  List<dynamic> get _filteredTransactions {
    if (_activeTab != 'My Requests' || _statusFilter == 'All') {
      return _transactions;
    }
    return _transactions.where((tx) {
      final status = (tx['status'] ?? '').toString().toUpperCase();
      if (_statusFilter == 'Pending') return status.contains('PENDING') || PaymentFlow.isOpen(status);
      if (_statusFilter == 'Accepted') return status.contains('ACCEPTED');
      if (_statusFilter == 'Completed') return status.contains('COMPLETED');
      if (_statusFilter == 'Cancelled') return status.contains('CANCEL');
      return true;
    }).toList();
  }

  Widget _buildTopTab({
    required String label,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.primary : AppColors.borderLight,
          borderRadius: BorderRadius.circular(20),
        ),
        alignment: Alignment.center,
        child: Text(
          label,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w700,
            color: isSelected ? Colors.white : AppColors.textSecondary,
          ),
        ),
      ),
    );
  }

  // ---- Real values only: no made-up names, times or prices on request cards ----
  String get _anonProvider => AppStrings.isEnglish ? 'Provider' : 'Mtoa huduma';
  String get _anonService => AppStrings.isEnglish ? 'Service' : 'Huduma';

  /// When the booking is for (or was made), taken from the server data; '' when unknown.
  String _txWhen(Map<String, dynamic> tx) {
    String two(int v) => v.toString().padLeft(2, '0');
    final sched = DateTime.tryParse((tx['scheduledAt'] ?? '').toString());
    if (sched != null) {
      return '${sched.day}/${sched.month}/${sched.year}, ${two(sched.hour)}:${two(sched.minute)}';
    }
    // Bookings made before scheduledAt existed carry the date and time in the notes ("Date: d/m/yyyy, Time: HH:MM.").
    final n = (tx['notes'] ?? tx['customerNote'] ?? '').toString();
    final nd = RegExp(r'Date:\s*(\d{1,2}/\d{1,2}/\d{4})').firstMatch(n)?.group(1);
    final nt = RegExp(r'Time:\s*(\d{1,2}:\d{2})').firstMatch(n)?.group(1);
    if (nd != null) return nt != null ? '$nd, $nt' : nd;
    for (final k in const ['bookingDate', 'startTime', 'createdAt']) {
      final raw = tx[k];
      if (raw == null) continue;
      final d = DateTime.tryParse(raw.toString());
      if (d == null) continue;
      final l = d.toLocal();
      return '${l.day}/${l.month}/${l.year}, ${two(l.hour)}:${two(l.minute)}';
    }
    return '';
  }

  /// Only what the customer typed: the app-written Date / Time / Place / Payment lines are removed.
  String _customerText(Map<String, dynamic> tx) {
    final raw = (tx['customerNote'] ?? tx['notes'] ?? '').toString().trim();
    return raw
        .replaceFirst(RegExp(r'^Date:\s*[^,]*,\s*Time:\s*\d{1,2}:\d{2}\.\s*'), '')
        .replaceFirst(RegExp(r'^Place:\s*[^.]+\.\s*'), '')
        .replaceFirst(RegExp(r'^Payment:\s*[^.]+\.\s*'), '')
        .trim();
  }

  /// The booked service's real photo from the server (absolute URL); '' when it has none.
  String _txImage(Map<String, dynamic> tx) {
    final raw = (tx['serviceImage'] ?? '').toString().trim();
    return raw.isEmpty ? '' : ApiService.absoluteUrl(raw);
  }

  /// ' • 60 min' when the server sends a duration, else ''.
  String _txDuration(Map<String, dynamic> tx) {
    final m = tx['durationMinutes'] ?? tx['duration'];
    final n = m is num ? m.toInt() : int.tryParse('${m ?? ''}');
    final t = ApiService.formatDuration(n);
    return t.isEmpty ? '' : ' • $t';
  }

  /// (label, background, colour) for a raw transaction status.
  (String, Color, Color) _statusStyle(String status) {
    final payState = PaymentFlow.stateOf(status);
    if (payState != PayState.none) {
      final c = PaymentFlow.color(status);
      return (PaymentFlow.label(status), c.withValues(alpha: 0.12), c);
    }
    if (status.contains('ACCEPTED')) return ('Accepted', const Color(0xFFF0FDF4), AppColors.success);
    if (status.contains('COMPLETED')) return ('Completed', const Color(0xFFEFF6FF), AppColors.primary);
    if (status.contains('CANCEL')) return ('Cancelled', const Color(0xFFFEF2F2), AppColors.danger);
    if (status.contains('REJECT')) return ('Rejected', const Color(0xFFFEF2F2), AppColors.danger);
    // PAYMENT_DISPUTED was already handled above (pay-first flow); this is a booking dispute.
    if (status.contains('DISPUTE')) return ('Disputed', const Color(0xFFFEF2F2), AppColors.danger);
    if (status.contains('REFUND')) return ('Refunded', const Color(0xFFF1F5F9), AppColors.textSecondary);
    return ('Pending', const Color(0xFFFFF7ED), const Color(0xFFF97316));
  }

  // SCREEN 1: Buyer Request Card (Matches Photo 1)
  /// Message icon on a request card: opens the chat with the other person in this request.
  Widget _msgIcon(dynamic otherId, String name) {
    return Padding(
      padding: const EdgeInsets.only(right: 6),
      child: Tooltip(
        message: AppStrings.isEnglish ? 'Message' : 'Ujumbe',
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: () => ChatThreadScreen.open(
            context,
            recipientId: int.tryParse('${otherId ?? ''}'),
            name: name,
          ),
          child: Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: 0.1), shape: BoxShape.circle),
            child: const Icon(Icons.chat_bubble_outline_rounded, size: 17, color: AppColors.primary),
          ),
        ),
      ),
    );
  }

  Widget _buildBuyerRequestCard(Map<String, dynamic> tx, int index) {
    final seller = tx['seller'] ?? {};
    final providerName = seller['stageName'] ?? _anonProvider;
    final serviceTitle = tx['serviceTitle'] ?? _anonService;
    final status = (tx['status'] ?? 'PENDING_ACCEPTANCE').toString().toUpperCase();
    final amount = (tx['amount'] as num?)?.toDouble() ?? 0.0;
    final amountFormatted = CurrencyService.format(amount);
    final image = _txImage(tx);

    final payState = PaymentFlow.stateOf(status);
    final (statusLabel, statusBg, statusColor) = _statusStyle(status);
    final bookingRef = (tx['transactionRef'] ?? '').toString();
    final canCancel = BookingCancel.canCancel(status) && bookingRef.isNotEmpty;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: image.isEmpty
                    ? Container(
                        width: 60,
                        height: 60,
                        color: AppColors.borderLight,
                        child: const Icon(Icons.spa_rounded, color: AppColors.textMuted),
                      )
                    : AppImage(
                        image,
                        width: 60,
                        height: 60,
                        fit: BoxFit.cover,
                        errorBuilder: (ctx, err, stack) => Container(
                          width: 60,
                          height: 60,
                          color: AppColors.borderLight,
                          child: const Icon(Icons.spa_rounded, color: AppColors.textMuted),
                        ),
                      ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      serviceTitle,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      providerName,
                      style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '$amountFormatted${_txDuration(tx)}',
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    if (_txWhen(tx).isNotEmpty)
                  Row(children: [
                      Icon(Icons.calendar_today_outlined, size: 12, color: AppColors.textMuted),
                      const SizedBox(width: 4),
                      Flexible(child: Text(_txWhen(tx), style: const TextStyle(fontSize: 11, color: AppColors.textMuted))),
                  ]),
                  ],
                ),
              ),
              _msgIcon((tx['seller'] is Map ? tx['seller']['id'] : null) ?? tx['sellerId'], providerName.toString()),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: statusBg,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  statusLabel,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: statusColor,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (PaymentFlow.payPreference(tx).isNotEmpty) ...[
            PaymentPreferenceBadge(tx: tx, isBuyer: true),
            const SizedBox(height: 12),
          ],
          RequestProgress(tx: tx),
          if (payState != PayState.none || PaymentFlow.awaitingPayAfterAccept(tx) || PaymentFlow.canRelease(tx)) ...[
            const SizedBox(height: 12),
            PaymentFlowPanel(tx: tx, isBuyer: true, onChanged: () => _loadData(silent: true)),
          ],
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: SizedBox(
                  height: 36,
                  child: OutlinedButton(
                    onPressed: () async {
                      final changed = await Navigator.push<bool>(
                        context,
                        MaterialPageRoute(
                          builder: (_) => BookingDetailsScreen(
                            bookingData: {
                              'serviceTitle': serviceTitle,
                              'providerName': providerName,
                              'price': amountFormatted,
                              'status': statusLabel,
                              'rawStatus': status,
                              'tx': tx,
                              'isBuyer': true,
                              'ref': bookingRef,
                              'image': image,
                              'providerId': seller['id'] ?? tx['sellerId'],
                              // Backend sends the provider's pin as sellerLatitude/sellerLongitude (top level).
                              'providerLat': seller['latitude'] ?? tx['sellerLatitude'] ?? tx['latitude'],
                              'providerLng': seller['longitude'] ?? tx['sellerLongitude'] ?? tx['longitude'],
                            },
                          ),
                        ),
                      );
                      if (changed == true && mounted) _loadData(silent: true);
                    },
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.primary,
                      side: const BorderSide(color: AppColors.primary),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                    child: const Text('View', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: SizedBox(
                  height: 36,
                  child: OutlinedButton(
                    onPressed: canCancel ? () => _cancelBooking(bookingRef, serviceTitle, status) : null,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.danger,
                      disabledForegroundColor: AppColors.textDisabled,
                      side: BorderSide(color: canCancel ? AppColors.danger : AppColors.border),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                    child: const Text('Cancel', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// Provider taps the customer's photo / name: show who booked them.
  void _openBuyer(Map<String, dynamic> tx, String amountFormatted) {
    final (label, _, color) = _statusStyle((tx['status'] ?? 'PENDING_ACCEPTANCE').toString().toUpperCase());
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => BuyerProfileScreen(
          buyer: BuyerInfo.fromTx(tx),
          serviceTitle: (tx['serviceTitle'] ?? '').toString(),
          amount: amountFormatted,
          when: _txWhen(tx),
          statusLabel: label,
          statusColor: color,
        ),
      ),
    );
  }

  // SCREEN 2: Seller Incoming Request Card (Matches Photo 2)
  Widget _buildSellerIncomingCard(Map<String, dynamic> tx, int index) {
    final buyerInfo = BuyerInfo.fromTx(tx);
    final buyerName = buyerInfo.listName; // stage name on the card; the ID name is only in the details
    final serviceTitle = tx['serviceTitle'] ?? _anonService;
    final amount = (tx['amount'] as num?)?.toDouble() ?? 0.0;
    final amountFormatted = CurrencyService.format(amount);
    final ref = (tx['transactionRef'] ?? '').toString();
    final incomingStatus = (tx['status'] ?? 'PENDING_ACCEPTANCE').toString().toUpperCase();
    final message = _customerText(tx);

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () => _openBuyer(tx, amountFormatted),
                child: BuyerAvatar(buyer: BuyerInfo.fromTx(tx), size: 40, safeTick: true),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: GestureDetector(
                            onTap: () => _openBuyer(tx, amountFormatted),
                            child: Text(
                              buyerName,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w800,
                                color: AppColors.textPrimary,
                              ),
                            ),
                          ),
                        ),
                        BuyerNameMark(buyer: buyerInfo),
                        const SizedBox(width: 4),
                        Container(
                          width: 6,
                          height: 6,
                          decoration: const BoxDecoration(
                            color: AppColors.success,
                            shape: BoxShape.circle,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Wants: $serviceTitle',
                      style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                    ),
                    if (buyerInfo.contactsAndIdHidden) ...[
                      const SizedBox(height: 2),
                      Row(children: [
                        const Icon(Icons.lock_outline_rounded, size: 11, color: AppColors.textMuted),
                        const SizedBox(width: 3),
                        Flexible(
                          child: Text(
                            AppStrings.isEnglish
                                ? 'Contacts and ID hidden. Accept to see contact and location.'
                                : 'Mawasiliano na ID zimefichwa. Kubali kuona mawasiliano na eneo.',
                            style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
                          ),
                        ),
                      ]),
                    ],
                    const SizedBox(height: 2),
                    Text(
                      '$amountFormatted${_txDuration(tx)}',
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 3),
                    if (_txWhen(tx).isNotEmpty)
                  Row(children: [
                      Icon(Icons.location_on_outlined, size: 12, color: AppColors.textMuted),
                      const SizedBox(width: 2),
                      Flexible(child: Text(_txWhen(tx), style: const TextStyle(fontSize: 11, color: AppColors.textMuted))),
                  ]),
                  ],
                ),
              ),
              _msgIcon((tx['buyer'] is Map ? tx['buyer']['id'] : null) ?? tx['buyerId'], buyerName),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: AppColors.primary,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  PaymentFlow.isOpen(incomingStatus) ? PaymentFlow.label(incomingStatus) : 'New',
                  style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.white),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),

          // Message bubble (only when the customer wrote one)
          if (message.isNotEmpty) ...[
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.borderLight.withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(10),
            ),
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => _showNote(buyerName, message),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    message,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 12,
                      color: AppColors.textPrimary,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    AppStrings.isEnglish ? 'See note' : 'Angalia ujumbe',
                    style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.primary),
                  ),
                ],
              ),
            ),
          ),
          ],
          const SizedBox(height: 12),
          if (PaymentFlow.payPreference(tx).isNotEmpty) ...[
            PaymentPreferenceBadge(tx: tx),
            const SizedBox(height: 12),
          ],
          RequestProgress(tx: tx),
          const SizedBox(height: 12),

          if (incomingStatus.contains('PENDING') && ref.isNotEmpty) ...[
            SizedBox(
              width: double.infinity,
              height: 36,
              child: OutlinedButton.icon(
                onPressed: () async {
                  final sent = await AskPaymentSheet.show(context, transactionRef: ref, amountText: amountFormatted);
                  if (sent && mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text(AppStrings.isEnglish
                          ? 'Payment request sent. The buyer has been alerted.'
                          : 'Ombi la malipo limetumwa. Mnunuzi amearifiwa.'),
                    ));
                    _loadData(silent: true);
                  }
                },
                icon: const Icon(Icons.payments_outlined, size: 16),
                label: Text(
                  AppStrings.isEnglish ? 'Ask buyer to pay first' : 'Mwombe mnunuzi alipe kwanza',
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
                ),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.primary,
                  side: const BorderSide(color: AppColors.primary),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
              ),
            ),
            const SizedBox(height: 8),
          ],
          if (PaymentFlow.isOpen(incomingStatus) || PaymentFlow.awaitingPayAfterAccept(tx)) ...[
            PaymentFlowPanel(tx: tx, isBuyer: false, onChanged: () => _loadData(silent: true)),
            if (BookingCancel.canCancel(incomingStatus) && ref.isNotEmpty) ...[
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                height: 36,
                child: OutlinedButton(
                  onPressed: () => _cancelBooking(ref, serviceTitle.toString(), incomingStatus),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.danger,
                    side: const BorderSide(color: AppColors.danger),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  child: Text(AppStrings.isEnglish ? 'Cancel Booking' : 'Ghairi Oda', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                ),
              ),
            ],
          ] else if (incomingStatus.contains('PENDING'))
            // View buyer info, then Accept / Reject
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
            _buyerInfoButton(tx, amountFormatted),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: SizedBox(
                    height: 36,
                    child: ElevatedButton(
                      onPressed: _acting.isNotEmpty ? null : () => _acceptOrder(ref),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.success,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                      child: _acting == 'accept:$ref'
                          ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                          : const Text('Accept', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: SizedBox(
                    height: 36,
                    child: OutlinedButton(
                      onPressed: _acting.isNotEmpty ? null : () => _rejectOrder(ref),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AppColors.danger,
                        side: const BorderSide(color: AppColors.danger),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                      child: _acting == 'reject:$ref'
                          ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.danger))
                          : const Text('Reject', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                    ),
                  ),
                ),
              ],
            ),
              ],
            )
          else if (BookingCancel.canCancel(incomingStatus) && ref.isNotEmpty)
            SizedBox(
              width: double.infinity,
              height: 36,
              child: OutlinedButton(
                onPressed: () => _cancelBooking(ref, serviceTitle.toString(), incomingStatus),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.danger,
                  side: const BorderSide(color: AppColors.danger),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: Text(AppStrings.isEnglish ? 'Cancel Booking' : 'Ghairi Oda', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
              ),
            )
          else
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 8),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: incomingStatus.contains('CANCEL') || incomingStatus.contains('REJECT') ? const Color(0xFFFEF2F2) : AppColors.borderLight,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                incomingStatus.contains('CANCEL')
                    ? (AppStrings.isEnglish ? 'Cancelled' : 'Imeghairiwa')
                    : incomingStatus.contains('REJECT')
                        ? (AppStrings.isEnglish ? 'Rejected' : 'Imekataliwa')
                        : incomingStatus.contains('COMPLETE')
                            ? (AppStrings.isEnglish ? 'Completed' : 'Imekamilika')
                            : incomingStatus,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: incomingStatus.contains('CANCEL') || incomingStatus.contains('REJECT') ? AppColors.danger : AppColors.textSecondary,
                ),
              ),
            ),
          if (!incomingStatus.contains('PENDING') || PaymentFlow.isOpen(incomingStatus)) ...[
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              height: 36,
              child: OutlinedButton(
                onPressed: () => _openSellerDetails(tx, buyerInfo, amountFormatted, index),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.primary,
                  side: const BorderSide(color: AppColors.primary),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: Text(AppStrings.isEnglish ? 'View details' : 'Angalia maelezo', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
              ),
            ),
          ],
        ],
      ),
    );
  }

  /// "View buyer info": opens the buyer's profile before the provider decides to accept.
  Widget _buyerInfoButton(Map<String, dynamic> tx, String amountFormatted) {
    return SizedBox(
      height: 36,
      child: OutlinedButton.icon(
        onPressed: () => _openBuyer(tx, amountFormatted),
        icon: const Icon(Icons.person_search_outlined, size: 16),
        label: Text(
          AppStrings.isEnglish ? 'View buyer info' : 'Angalia taarifa za mnunuzi',
          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
        ),
        style: OutlinedButton.styleFrom(
          foregroundColor: AppColors.primary,
          side: const BorderSide(color: AppColors.primary),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
      ),
    );
  }

  /// Full text of the customer's note.
  void _showNote(String buyerName, String message) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          AppStrings.isEnglish ? 'Note from $buyerName' : 'Ujumbe kutoka kwa $buyerName',
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
        ),
        content: SingleChildScrollView(child: SelectableText(message, style: const TextStyle(fontSize: 14, height: 1.45))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(AppStrings.isEnglish ? 'Close' : 'Funga')),
        ],
      ),
    );
  }

  /// Booking details for a request a provider received (chat + contacts live there).
  Future<void> _openSellerDetails(Map<String, dynamic> tx, BuyerInfo info, String amountFormatted, int index) async {
    final raw = (tx['status'] ?? 'PENDING_ACCEPTANCE').toString().toUpperCase();
    final (label, _, _) = _statusStyle(raw);
    final b = tx['buyer'] is Map ? tx['buyer'] as Map : const {};
    final changed = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => BookingDetailsScreen(
          bookingData: {
            'serviceTitle': (tx['serviceTitle'] ?? _anonService).toString(),
            'providerName': info.listName, // stage name is the main name
            'chatName': info.listName,
            'verifiedName': (info.nameVerified && !info.hideMyId && info.stageNameExtra != null) ? info.name : null,
            'isBuyer': false,
            'safeBadge': info.safeBadge,
            'providerId': b['id'] ?? tx['buyerId'],
            // The provider sees the customer only live, once the booking is accepted and paid (both can stop sharing).
            'hideMap': tx['contactsUnlocked'] != true,
            'price': amountFormatted,
            'status': label,
            'rawStatus': raw,
            'tx': tx,
            'ref': (tx['transactionRef'] ?? '').toString(),
            'image': _txImage(tx),
          },
        ),
      ),
    );
    if (changed == true && mounted) _loadData(silent: true);
  }

  // SCREEN 3: Seller Outgoing Request Card (Matches Photo 3)
  Widget _buildSellerOutgoingCard(Map<String, dynamic> tx, int index) {
    final buyer = tx['buyer'] ?? {};
    final buyerInfo = BuyerInfo.fromTx(tx);
    final name = buyerInfo.listName; // stage name on the card; the ID name is only in the details
    final serviceTitle = tx['serviceTitle'] ?? _anonService;
    final amount = (tx['amount'] as num?)?.toDouble() ?? 0.0;
    final amountFormatted = CurrencyService.format(amount);

    // Status badge from the real transaction status.
    final (statusLabel, statusBg, statusColor) =
        _statusStyle((tx['status'] ?? 'PENDING_ACCEPTANCE').toString().toUpperCase());

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () => _openBuyer(tx, amountFormatted),
                child: BuyerAvatar(buyer: BuyerInfo.fromTx(tx), size: 40, safeTick: true),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: GestureDetector(
                            onTap: () => _openBuyer(tx, amountFormatted),
                            child: Text(
                              name,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w800,
                                color: AppColors.textPrimary,
                              ),
                            ),
                          ),
                        ),
                        BuyerNameMark(buyer: buyerInfo),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      serviceTitle,
                      style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '$amountFormatted${_txDuration(tx)}',
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 3),
                    if (_txWhen(tx).isNotEmpty)
                  Row(children: [
                      Icon(Icons.access_time_rounded, size: 12, color: AppColors.textMuted),
                      const SizedBox(width: 2),
                      Flexible(child: Text(_txWhen(tx), style: const TextStyle(fontSize: 11, color: AppColors.textMuted))),
                  ]),
                  ],
                ),
              ),
              _msgIcon((buyer is Map ? buyer['id'] : null) ?? tx['buyerId'], name),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: statusBg,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  statusLabel,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: statusColor,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // View Details Single Full-Width Button matching Screen 3
          SizedBox(
            width: double.infinity,
            height: 36,
            child: OutlinedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => BookingDetailsScreen(
                      bookingData: {
                        'serviceTitle': serviceTitle,
                        'providerName': name, // stage name is the main name
                        'chatName': name,
                        'verifiedName': (buyerInfo.nameVerified && !buyerInfo.hideMyId && buyerInfo.stageNameExtra != null) ? buyerInfo.name : null,
                        'isBuyer': false,
                        'safeBadge': buyerInfo.safeBadge,
                        'tx': tx,
                        'rawStatus': (tx['status'] ?? 'PENDING_ACCEPTANCE').toString().toUpperCase(),
                        'ref': (tx['transactionRef'] ?? '').toString(),
                        'providerId': buyer['id'] ?? tx['buyerId'],
                        'hideMap': tx['contactsUnlocked'] != true,
                        'price': amountFormatted,
                        'status': statusLabel,
                        'image': _txImage(tx),
                      },
                    ),
                  ),
                );
              },
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.primary,
                side: const BorderSide(color: AppColors.primary),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              ),
              child: const Text('View Details', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
            ),
          ),
        ],
      ),
    );
  }
}
