import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../services/api_service.dart';
import '../widgets/admin_common.dart';

/// Admin: what the "Update available" dialog says, per platform.
/// Server: GET /admin/app/version?platform=android|ios, PUT /admin/app/version?platform= with
/// {latestVersion, minVersion, forceUpdate, storeUrl, messageEn, messageSw}.
/// Release order: publish to the store first, then raise latestVersion here.
class AdminAppVersionScreen extends StatefulWidget {
  const AdminAppVersionScreen({super.key});

  @override
  State<AdminAppVersionScreen> createState() => _AdminAppVersionScreenState();
}

class _AdminAppVersionScreenState extends State<AdminAppVersionScreen> {
  final _latest = TextEditingController();
  final _min = TextEditingController();
  final _store = TextEditingController();
  final _msgEn = TextEditingController();
  final _msgSw = TextEditingController();
  String _platform = 'android';
  bool _force = false;
  bool _loading = true;
  bool _forbidden = false;
  bool _failed = false;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    for (final c in [_latest, _min, _store, _msgEn, _msgSw]) {
      c.dispose();
    }
    super.dispose();
  }

  String _s(dynamic v) => v == null ? '' : v.toString();

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _failed = false;
    });
    final r = await ApiService.adminGetObject('/admin/app/version?platform=$_platform');
    if (!mounted) return;
    final d = r.data;
    setState(() {
      _loading = false;
      _forbidden = r.forbidden;
      _failed = !r.forbidden && d == null;
      _latest.text = _s(d?['latestVersion']);
      _min.text = _s(d?['minVersion']);
      _store.text = _s(d?['storeUrl']);
      _msgEn.text = _s(d?['messageEn']);
      _msgSw.text = _s(d?['messageSw']);
      _force = d?['forceUpdate'] == true;
    });
  }

  Future<void> _save() async {
    final latest = _latest.text.trim();
    if (!RegExp(r'^\d+(\.\d+){0,3}$').hasMatch(latest)) {
      adminSnack(context, adminT('Latest version looks like 1.2.0', 'Toleo jipya linafanana na 1.2.0'));
      return;
    }
    final store = _store.text.trim();
    if (store.isNotEmpty && !store.startsWith('https://')) {
      adminSnack(context, adminT('Store link must start with https://', 'Kiungo cha duka lazima kianze na https://'));
      return;
    }
    setState(() => _saving = true);
    // The server stores this JSON exactly as sent and hands it to the app, so keep empty optional fields out.
    final body = <String, dynamic>{
      'latestVersion': latest,
      if (_min.text.trim().isNotEmpty) 'minVersion': _min.text.trim(),
      'forceUpdate': _force,
      if (store.isNotEmpty) 'storeUrl': store,
      if (_msgEn.text.trim().isNotEmpty) 'messageEn': _msgEn.text.trim(),
      if (_msgSw.text.trim().isNotEmpty) 'messageSw': _msgSw.text.trim(),
    };
    final res = await ApiService.adminSend('PUT', '/admin/app/version?platform=$_platform', body);
    if (!mounted) return;
    setState(() => _saving = false);
    adminSnack(context, res.error ?? adminT('Saved for $_platform', 'Imehifadhiwa kwa $_platform'));
  }

  Widget _field(TextEditingController c, String label, {int lines = 1, TextInputType? type}) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: TextField(
          controller: c,
          maxLines: lines,
          keyboardType: type,
          decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final state = adminStateOrNull(loading: _loading, forbidden: _forbidden, failed: _failed, empty: false, onRetry: _load);
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text(adminT('App update message', 'Ujumbe wa kusasisha app'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        SegmentedButton<String>(
          segments: const [ButtonSegment(value: 'android', label: Text('Android')), ButtonSegment(value: 'ios', label: Text('iOS'))],
          selected: {_platform},
          onSelectionChanged: (s) {
            _platform = s.first;
            _load();
          },
        ),
        const SizedBox(height: 16),
        if (state != null)
          SizedBox(height: 300, child: state)
        else ...[
          _field(_latest, adminT('Latest version (e.g. 1.2.0)', 'Toleo jipya (mf. 1.2.0)')),
          _field(_min, adminT('Minimum version (older must update)', 'Toleo la chini (la zamani lazima lisasishwe)')),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(adminT('Force everyone to update', 'Lazimisha kila mtu kusasisha')),
            value: _force,
            onChanged: (v) => setState(() => _force = v),
          ),
          _field(_store, adminT('Store link (https)', 'Kiungo cha duka (https)'), type: TextInputType.url),
          _field(_msgEn, adminT('Message (English)', 'Ujumbe (Kiingereza)'), lines: 2),
          _field(_msgSw, adminT('Message (Swahili)', 'Ujumbe (Kiswahili)'), lines: 2),
          ElevatedButton(
            onPressed: _saving ? null : _save,
            child: _saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : Text(adminT('Save', 'Hifadhi')),
          ),
        ],
      ]),
    );
  }
}
