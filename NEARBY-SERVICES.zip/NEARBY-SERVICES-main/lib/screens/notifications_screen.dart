import 'dart:async';
import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/notification_feed.dart';
import 'chat_thread_screen.dart';
import 'requests_screen.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  String _activeFilter = 'All'; // 'All', 'Bookings', 'Messages', 'System'
  bool _isLoading = false;
  Timer? _backup;

  @override
  void initState() {
    super.initState();
    NotificationFeed.items.addListener(_onFeed);
    _reload();
    // Safety net while this screen is open: a slow refresh in case a live event was missed.
    _backup = Timer.periodic(const Duration(seconds: 60), (_) => NotificationFeed.refresh());
  }

  @override
  void dispose() {
    _backup?.cancel();
    NotificationFeed.items.removeListener(_onFeed);
    super.dispose();
  }

  void _onFeed() {
    if (mounted) setState(() {});
  }

  Future<void> _reload() async {
    setState(() => _isLoading = true);
    await NotificationFeed.refresh();
    if (mounted) setState(() => _isLoading = false);
  }

  /// Opens the chat this message notification is about (and marks it read).
  Future<void> _openChat(AppNotification item) async {
    NotificationFeed.markRead(item);
    await ChatThreadScreen.open(
      context,
      recipientId: item.chatUserId,
      name: item.chatName ?? '',
      isOnline: item.chatOnline,
    );
  }

  /// Tapping a notification: messages open their chat, bookings and offers open Requests.
  void _openNotification(AppNotification item) {
    if (item.isMessage) {
      _openChat(item);
      return;
    }
    NotificationFeed.markRead(item);
    if (item.opensRequests) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => const RequestsScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    final all = NotificationFeed.items.value;
    final filtered = _activeFilter == 'All' ? all : all.where((n) => n.type == _activeFilter).toList();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          AppStrings.notificationsTitle,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        actions: [
          TextButton(
            onPressed: NotificationFeed.markAllRead,
            child: Text(
              AppStrings.notificationsMarkAllRead,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: AppColors.primary,
              ),
            ),
          ),
          const SizedBox(width: 8),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(50),
          child: Column(
            children: [
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  children: [
                    {'key': 'All', 'label': AppStrings.chatsTabAll},
                    {'key': 'Bookings', 'label': AppStrings.chatsTabBookings},
                    {'key': 'Messages', 'label': AppStrings.chatsTitle},
                    {'key': 'System', 'label': 'System'},
                  ].map((filter) {
                    final isSelected = _activeFilter == filter['key'];
                    return Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: GestureDetector(
                        onTap: () => setState(() => _activeFilter = filter['key']!),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                          decoration: BoxDecoration(
                            color: isSelected ? AppColors.primary : AppColors.borderLight,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Text(
                            filter['label']!,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: isSelected ? Colors.white : AppColors.textSecondary,
                            ),
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
              const Divider(height: 1, color: AppColors.border),
            ],
          ),
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
          : filtered.isEmpty
              ? Center(
                  child: Text(
                    AppStrings.notificationsNoItems,
                    style: const TextStyle(fontSize: 14, color: AppColors.textMuted),
                  ),
                )
              : RefreshIndicator(
                  onRefresh: NotificationFeed.refresh,
                  child: ListView.separated(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.all(16),
              itemCount: filtered.length,
              separatorBuilder: (_, _) => const SizedBox(height: 10),
              itemBuilder: (context, index) {
                final item = filtered[index];
                final isRead = item.isTip || NotificationFeed.isRead(item);

                return InkWell(
                  onTap: () => _openNotification(item),
                  borderRadius: BorderRadius.circular(14),
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: isRead ? AppColors.surface : AppColors.primaryLight.withValues(alpha: 0.5),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: isRead ? AppColors.border : AppColors.primary.withValues(alpha: 0.3),
                      ),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: item.color.withValues(alpha: 0.1),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(item.icon, color: item.color, size: 20),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    children: [
                                      Text(
                                        item.title,
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontWeight: isRead ? FontWeight.w600 : FontWeight.w800,
                                          color: AppColors.textPrimary,
                                        ),
                                      ),
                                      if (!isRead) ...[
                                        const SizedBox(width: 6),
                                        Container(
                                          width: 7,
                                          height: 7,
                                          decoration: const BoxDecoration(
                                            color: AppColors.primary,
                                            shape: BoxShape.circle,
                                          ),
                                        ),
                                      ],
                                    ],
                                  ),
                                  if (item.time.isNotEmpty)
                                    Text(
                                      item.time,
                                      style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
                                    ),
                                ],
                              ),
                              const SizedBox(height: 4),
                              Text(
                                item.subtitle,
                                style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textSecondary),
                              ),
                            ],
                          ),
                        ),
                        // Their own message icon opens the chat with the person this notification is about.
                        if (item.chatUserId != null) ...[
                          const SizedBox(width: 8),
                          GestureDetector(
                            behavior: HitTestBehavior.opaque,
                            onTap: () => _openChat(item),
                            child: Tooltip(
                              message: AppStrings.isEnglish ? 'Message' : 'Ujumbe',
                              child: Container(
                                width: 36,
                                height: 36,
                                decoration: BoxDecoration(
                                  color: AppColors.primary.withValues(alpha: 0.1),
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(Icons.chat_bubble_outline_rounded, size: 18, color: AppColors.primary),
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                );
              },
            ),
                ),
    );
  }
}
