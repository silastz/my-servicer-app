import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../security/input_validation.dart';
import '../services/attempt_limiter.dart';
import '../services/api_service.dart';
import '../widgets/app_ui.dart';
import '../services/session_manager.dart';
import 'nida_verification_screen.dart';

/// The invited person enters the code a verified provider (Green or Blue) sent them. The NIN and
/// legal name were saved in Identity Verification (Step 1), so they are not asked again. The server
/// checks them and grants the Green Badge (identity only); both people are then on record as
/// knowing and trusting each other.
class AcceptInvitationScreen extends StatefulWidget {
  /// Pre-fills the code (e.g. when opened from an invitation card).
  final String? initialCode;
  const AcceptInvitationScreen({super.key, this.initialCode});

  @override
  State<AcceptInvitationScreen> createState() => _AcceptInvitationScreenState();
}

class _AcceptInvitationScreenState extends State<AcceptInvitationScreen> {
  final _code = TextEditingController();
  bool _busy = false;
  bool _done = false;
  String? _codeError;
  String? _error;

  List<Map<String, dynamic>> _received = const [];

  bool get _isEn => AppStrings.isEnglish;

  @override
  void initState() {
    super.initState();
    final c = widget.initialCode?.trim() ?? '';
    if (c.isNotEmpty) _code.text = c;
    _loadReceived();
  }

  /// Invitations sent to my phone number show up here, so no code typing is needed.
  Future<void> _loadReceived() async {
    final list = await ApiService.fetchPendingReceivedInvitations();
    await ApiService.fetchVerifiedName(); // is a legal name saved?
    if (!mounted) return;
    setState(() => _received = list);
  }

  String _codeOf(Map<String, dynamic> inv) => (inv['code'] ?? inv['inviteCode'] ?? '').toString().trim();

  @override
  void dispose() {
    _code.dispose();
    super.dispose();
  }

  Future<void> _paste() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final text = data?.text?.trim() ?? '';
    final clean = text.replaceAll(RegExp(r'[^A-Za-z0-9\-]'), '');
    if (clean.isNotEmpty) setState(() => _code.text = clean.length > 24 ? clean.substring(0, 24) : clean);
  }

  Future<void> _submit() async {
    if (_busy) return; // ignore double taps
    final code = _code.text.trim().toUpperCase();
    final codeErr = InputValidation.inviteCode(code);
    if (codeErr != null) {
      setState(() {
        _codeError = codeErr;
        _error = null;
      });
      return;
    }
    // Guessing codes: slow down after repeated wrong tries (kept across app restarts).
    const limitKey = 'invite:accept';
    final wait = AttemptLimiter.secondsLocked(limitKey);
    if (wait > 0) {
      setState(() => _error = '${AppStrings.authTooManyAttempts} ${wait}s');
      return;
    }
    setState(() {
      _busy = true;
      _codeError = null;
      _error = null;
    });
    final res = await ApiService.acceptInvitation(code: code);
    if (!mounted) return;
    if (res.ok) {
      AttemptLimiter.recordSuccess(limitKey);
      ApiService.fetchVerifiedName(); // identity is now verified: the server confirms the name by itself
    } else if (res.error != AppStrings.authNetworkError) {
      AttemptLimiter.recordFailure(limitKey); // a real rejection, not a dropped connection
    }
    setState(() {
      _busy = false;
      if (res.ok) {
        _done = true;
      } else {
        _error = InputValidation.safeServerMessage(res.error);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context, _done),
        ),
        title: Text(
          _isEn ? 'I have an invitation' : 'Nina mwaliko',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: _done ? _success() : _form(),
      ),
    );
  }

  Widget _success() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.successLight,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.success.withValues(alpha: 0.4)),
      ),
      child: Column(
        children: [
          const Icon(Icons.verified_rounded, color: AppColors.primary, size: 56),
          const SizedBox(height: 12),
          Text(
            _isEn ? 'Congratulations! You now have the Green Badge.' : 'Hongera! Sasa una Green Badge.',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
          ),
          const SizedBox(height: 8),
          Text(
            _isEn
                ? 'You and the person who invited you are now on record as knowing and trusting each other.'
                : 'Wewe na aliyekualika mnabaki kwenye kumbukumbu mkijuana na kuaminiana.',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 12, height: 1.45, color: AppColors.textSecondary),
          ),
          const SizedBox(height: 16),
          AppButton.primary(label: _isEn ? 'Done' : 'Sawa', onPressed: () => Navigator.pop(context, true)),
        ],
      ),
    );
  }

  Widget _receivedCard(Map<String, dynamic> inv) {
    final from = (inv['inviterName'] ?? inv['name'] ?? '').toString().trim();
    final code = _codeOf(inv);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.successLight,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.success.withValues(alpha: 0.4)),
      ),
      child: Row(
        children: [
          const Icon(Icons.mark_email_unread_outlined, color: AppColors.successDark),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              from.isNotEmpty
                  ? (_isEn ? '$from invited you.' : '$from amekualika.')
                  : (_isEn ? 'Someone you know invited you.' : 'Mtu unayemjua amekualika.'),
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
            ),
          ),
          if (code.isNotEmpty)
            TextButton(
              onPressed: _busy ? null : () => setState(() => _code.text = code),
              child: Text(_isEn ? 'Use code' : 'Tumia msimbo'),
            ),
        ],
      ),
    );
  }

  Widget _form() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppColors.primaryLight.withValues(alpha: 0.5),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.primary.withValues(alpha: 0.2)),
          ),
          child: Text(
            _isEn
                ? 'A verified provider who knows and trusts you can invite you. This gives you the Green Badge (identity). Enter the code they sent you. Your legal name and NIN (saved in Identity Verification) are checked against the official ID record. No ID photo is needed.'
                : 'Mtoa huduma aliyethibitishwa anayekujua na kukuamini anaweza kukualika. Hii inakupa Green Badge (utambulisho). Weka msimbo aliokutumia. Jina lako la kisheria na NIN (vilivyohifadhiwa kwenye Uthibitisho wa Utambulisho) vinahakikiwa dhidi ya rekodi rasmi ya kitambulisho. Huhitaji picha ya kitambulisho.',
            style: const TextStyle(fontSize: 12, height: 1.45, color: AppColors.textPrimary),
          ),
        ),
        if (SessionManager.getVerifiedNameStatus() == 'NONE' ||
            (SessionManager.getVerifiedNameStatus() != 'VERIFIED' && !SessionManager.isNinSaved())) ...[
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppColors.warningLight,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.warning.withValues(alpha: 0.5)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _isEn
                      ? 'First save your legal name and NIN in Identity Verification. The invitation checks them against the official ID record.'
                      : 'Kwanza hifadhi jina lako la kisheria na NIN kwenye Uthibitisho wa Utambulisho. Mwaliko unavihakiki dhidi ya rekodi rasmi ya kitambulisho.',
                  style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textPrimary),
                ),
                const SizedBox(height: 8),
                TextButton(
                  onPressed: () async {
                    await Navigator.push(context, MaterialPageRoute(builder: (_) => const NidaVerificationScreen()));
                    if (mounted) {
                      await ApiService.fetchVerifiedName();
                      if (mounted) setState(() {});
                    }
                  },
                  child: Text(_isEn ? 'Add my legal name and NIN' : 'Weka jina langu la kisheria na NIN'),
                ),
              ],
            ),
          ),
        ],
        for (final inv in _received) ...[
          const SizedBox(height: 12),
          _receivedCard(inv),
        ],
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              AppTextField(
                controller: _code,
                icon: Icons.vpn_key_outlined,
                label: _isEn ? 'Invitation code' : 'Msimbo wa mwaliko',
                hint: '123-ABC456',
                errorText: _codeError,
                enabled: !_busy,
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'[A-Za-z0-9\-]')),
                  LengthLimitingTextInputFormatter(24),
                ],
              ),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  onPressed: _busy ? null : _paste,
                  icon: const Icon(Icons.paste_rounded, size: 16),
                  label: Text(_isEn ? 'Paste' : 'Bandika'),
                ),
              ),
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(_error!, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.danger)),
              ],
              const SizedBox(height: 16),
              AppButton.primary(
                label: _isEn ? 'Accept invitation' : 'Kubali mwaliko',
                loading: _busy,
                onPressed: _busy ? null : _submit,
              ),
            ],
          ),
        ),
      ],
    );
  }
}
