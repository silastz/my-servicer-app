import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../services/api_service.dart';
import '../widgets/admin_common.dart';

/// Admin: reports sent by users (service, user or general). Server: GET /admin/reports?status=&limit=,
/// POST /admin/reports/{id}/status {status, note}.
class AdminReportsScreen extends StatefulWidget {
  const AdminReportsScreen({super.key});

  @override
  State<AdminReportsScreen> createState() => _AdminReportsScreenState();
}

class _AdminReportsScreenState extends State<AdminReportsScreen> {
  static const _statuses = ['OPEN', 'REVIEWING', 'RESOLVED', 'DISMISSED'];

  String? _filter = 'OPEN'; // null = all
  bool _loading = true;
  bool _forbidden = false;
  bool _failed = false;
  List<Map<String, dynamic>> _items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _failed = false;
    });
    final q = _filter == null ? '' : '&status=$_filter';
    final r = await ApiService.adminGetList('/admin/reports?limit=100$q');
    if (!mounted) return;
    setState(() {
      _loading = false;
      _forbidden = r.forbidden;
      _failed = !r.forbidden && r.items == null;
      _items = r.items ?? [];
    });
  }

  Color _color(String s) => switch (s) {
        'OPEN' => AppColors.warning,
        'REVIEWING' => AppColors.info,
        'RESOLVED' => AppColors.successDark,
        _ => AppColors.textSecondary,
      };

  Future<void> _update(Map<String, dynamic> m) async {
    String status = '${m['status']}';
    if (!_statuses.contains(status)) status = 'REVIEWING';
    final noteCtrl = TextEditingController(text: '${m['adminNote'] ?? ''}');
    final picked = await showDialog<(String, String)>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: Text(adminT('Report #${m['id']}', 'Ripoti #${m['id']}')),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            DropdownButton<String>(
              isExpanded: true,
              value: status,
              items: [for (final s in _statuses) DropdownMenuItem(value: s, child: Text(s))],
              onChanged: (v) => setS(() => status = v ?? status),
            ),
            TextField(
              controller: noteCtrl,
              maxLines: 3,
              minLines: 1,
              decoration: InputDecoration(hintText: adminT('Note (optional)', 'Maelezo (si lazima)')),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: Text(adminT('Cancel', 'Ghairi'))),
            TextButton(onPressed: () => Navigator.pop(ctx, (status, noteCtrl.text.trim())), child: Text(adminT('Save', 'Hifadhi'))),
          ],
        ),
      ),
    );
    if (picked == null || !mounted) return;
    final res = await ApiService.adminSend('POST', '/admin/reports/${m['id']}/status', {'status': picked.$1, 'note': picked.$2});
    if (!mounted) return;
    if (res.error != null) {
      adminSnack(context, res.error!);
      return;
    }
    adminSnack(context, adminT('Saved', 'Imehifadhiwa'));
    _load();
  }

  Widget _card(Map<String, dynamic> m) {
    final status = '${m['status']}';
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.all(14),
      decoration: adminCardDecoration(),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Text('#${m['id']}  ${m['type'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15))),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
            decoration: BoxDecoration(color: _color(status).withValues(alpha: 0.12), borderRadius: BorderRadius.circular(20)),
            child: Text(status, style: TextStyle(color: _color(status), fontWeight: FontWeight.w700, fontSize: 11)),
          ),
        ]),
        adminInfoLine(adminT('Reason', 'Sababu'), m['reason']),
        adminInfoLine(adminT('Details', 'Maelezo'), m['details']),
        adminInfoLine(adminT('Service', 'Huduma'), m['serviceId']),
        adminInfoLine(adminT('Reported user', 'Aliyeripotiwa'), m['reportedUserId']),
        adminInfoLine(adminT('Reporter', 'Aliyeripoti'), m['reporterId']),
        adminInfoLine(adminT('Admin note', 'Maelezo ya msimamizi'), m['adminNote']),
        adminInfoLine(adminT('Sent', 'Imetumwa'), m['createdAt']),
        const SizedBox(height: 8),
        Align(
          alignment: Alignment.centerRight,
          child: TextButton.icon(
            onPressed: () => _update(m),
            icon: const Icon(Icons.edit_note_rounded, size: 20),
            label: Text(adminT('Update status', 'Badilisha hali')),
          ),
        ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = adminStateOrNull(
      loading: _loading,
      forbidden: _forbidden,
      failed: _failed,
      empty: _items.isEmpty,
      onRetry: _load,
      emptyText: adminT('No reports with this status.', 'Hakuna ripoti za hali hii.'),
    );
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text(adminT('Reports', 'Ripoti'))),
      body: Column(children: [
        SizedBox(
          height: 52,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            children: [
              for (final s in [null, ..._statuses])
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(s ?? adminT('All', 'Zote')),
                    selected: _filter == s,
                    onSelected: (_) {
                      _filter = s;
                      _load();
                    },
                  ),
                ),
            ],
          ),
        ),
        Expanded(
          child: RefreshIndicator(
            onRefresh: _load,
            child: state != null
                ? ListView(children: [SizedBox(height: 400, child: state)])
                : ListView(padding: const EdgeInsets.only(bottom: 24), children: [for (final m in _items) _card(m)]),
          ),
        ),
      ]),
    );
  }
}
