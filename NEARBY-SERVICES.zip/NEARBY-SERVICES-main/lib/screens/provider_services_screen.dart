import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/models.dart';
import '../services/session_manager.dart';
import '../widgets/app_image.dart';

/// Full list of a provider's services, opened from "See All" on the provider
/// profile's Services tab. Cards are built by the caller so they look and
/// behave exactly like the ones on the profile (details, Request, boost badge).
class ProviderServicesScreen extends StatelessWidget {
  final String providerName;
  final String? providerAvatar;
  final bool providerOnline;
  final List<ServiceItem> services;
  final bool Function(ServiceItem service)? hideFilter;
  final Widget Function(ServiceItem service) cardBuilder;

  const ProviderServicesScreen({
    super.key,
    required this.providerName,
    this.providerAvatar,
    this.providerOnline = false,
    required this.services,
    this.hideFilter,
    required this.cardBuilder,
  });

  bool get _en => AppStrings.isEnglish;

  String get _initial => providerName.trim().isEmpty ? '?' : providerName.trim()[0].toUpperCase();

  Widget _fallback() => Container(
        color: AppColors.primary,
        alignment: Alignment.center,
        child: Text(_initial, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Colors.white)),
      );

  Widget _avatar() {
    const size = 40.0;
    final img = (providerAvatar ?? '').trim();
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          ClipOval(
            child: SizedBox(
              width: size,
              height: size,
              child: img.isNotEmpty ? AppImage(img, fit: BoxFit.cover, errorBuilder: (_, _, _) => _fallback()) : _fallback(),
            ),
          ),
          if (providerOnline)
            Positioned(
              right: -1,
              bottom: -1,
              child: Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  color: AppColors.onlineGreen,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 2),
                ),
              ),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Rebuilds when a service is favorited or marked "Not interested".
    return ValueListenableBuilder<int>(
      valueListenable: SessionManager.sessionNotifier,
      builder: (context, _, _) => _page(context),
    );
  }

  Widget _page(BuildContext context) {
    final services = hideFilter == null ? this.services : this.services.where(hideFilter!).toList();
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.maybePop(context),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _en ? 'All Services' : 'Huduma Zote',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
            ),
            if (providerName.trim().isNotEmpty)
              Text(
                providerName,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
              ),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(child: _avatar()),
          ),
        ],
        bottom: const PreferredSize(
          preferredSize: Size.fromHeight(1),
          child: Divider(height: 1, thickness: 1, color: AppColors.border),
        ),
      ),
      body: services.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 56,
                      height: 56,
                      decoration: const BoxDecoration(color: AppColors.primaryLight, shape: BoxShape.circle),
                      child: const Icon(Icons.design_services_outlined, color: AppColors.primary, size: 26),
                    ),
                    const SizedBox(height: 14),
                    Text(
                      _en ? 'No services yet' : 'Hakuna huduma bado',
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                    ),
                  ],
                ),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.only(top: 8, bottom: 28),
              itemCount: services.length + 1,
              itemBuilder: (_, i) {
                if (i == 0) {
                  return Padding(
                    padding: const EdgeInsets.fromLTRB(20, 6, 20, 0),
                    child: Text(
                      _en
                          ? '${services.length} ${services.length == 1 ? 'service' : 'services'} available'
                          : 'Huduma ${services.length} zinapatikana',
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textSecondary),
                    ),
                  );
                }
                return cardBuilder(services[i - 1]);
              },
            ),
    );
  }
}
