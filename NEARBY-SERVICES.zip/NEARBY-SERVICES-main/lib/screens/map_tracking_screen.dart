import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart' show Ticker;
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:url_launcher/url_launcher.dart';

import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../security/secure_http.dart';
import '../services/api_service.dart';
import '../services/gps_service.dart';
import '../services/live_follow.dart';
import '../services/navigation_engine.dart';
import 'chat_thread_screen.dart';
import '../services/app_log.dart';

/// In-app navigation (like Bolt / Uber): route preview, then turn-by-turn
/// guidance with a live, heading-following camera, next-turn banner, ETA,
/// automatic re-routing and arrival detection. No external maps app is opened.
///
/// Uses OpenStreetMap tiles and the public OSRM router (no API key). When the
/// provider has no saved coordinates the address is looked up with Nominatim.
class MapTrackingScreen extends StatefulWidget {
  final String providerName;
  final String serviceTitle;
  final String address;
  final double? providerLat;
  final double? providerLng;

  /// Provider's user id - enables the "Message" button.
  final int? providerId;

  /// The booking whose two people follow each other live (null = no live tracking). The server allows it
  /// only while the booking is accepted and paid, and only the two people on it can see each other.
  final String? bookingRef;

  /// True when a provider is navigating to a customer (changes the wording of the message button).
  final bool toCustomer;

  /// Start turn-by-turn guidance as soon as the route is ready
  /// (used by the "Navigate" buttons). Otherwise a preview is shown first.
  final bool startNavigating;

  const MapTrackingScreen({
    super.key,
    required this.providerName,
    required this.serviceTitle,
    required this.address,
    this.providerLat,
    this.providerLng,
    this.providerId,
    this.bookingRef,
    this.toCustomer = false,
    this.startNavigating = false,
  });

  @override
  State<MapTrackingScreen> createState() => _MapTrackingScreenState();
}

/// What the camera is doing: showing both people, following me, or left alone after the user dragged the map.
enum _Cam { both, follow, free }

class _MapTrackingScreenState extends State<MapTrackingScreen> with TickerProviderStateMixin {
  static const LatLng _fallbackCenter = LatLng(-6.7924, 39.2083); // Dar es Salaam
  static const double _offRouteMetres = 60;
  static const double _arriveMetres = 35;
  static const Duration _rerouteCooldown = Duration(seconds: 10);

  final MapController _map = MapController();
  StreamSubscription<Position>? _posSub;

  LatLng? _me;
  LatLng? _dest;
  /// True when the destination was guessed from the address text (the provider saved no exact pin).
  bool _destApprox = false;
  NavRoute? _route;
  NavProgress? _progress;
  int _nextStep = 1;

  bool _mapReady = false;
  bool _loadingRoute = false;
  bool _routeFailed = false;
  bool _locationDenied = false;
  bool _navigating = false;
  bool _arrived = false;
  _Cam _cam = _Cam.both;
  bool get _follow => _cam == _Cam.follow;
  LatLng? _lastRouteFrom;
  DateTime _lastReroute = DateTime.fromMillisecondsSinceEpoch(0);
  bool _autoStartPending = false;

  // Live tracking of the other person on this booking.
  LatLng? _other; // their last shared position
  bool _sharing = true; // am I sharing mine
  bool _liveActive = true; // false while the server says the booking is not active (checked again every ~12 s)
  int _idlePolls = 0;
  DateTime? _lastFixAt; // my last REAL GPS fix in this visit (the cached start-up position does not count)
  Timer? _liveTimer;
  DateTime _lastSent = DateTime.fromMillisecondsSinceEpoch(0);
  LatLng? _destRoutedTo;

  // Bolt-style smoothness: both markers glide between GPS fixes, driven by one ticker that only
  // runs while something is moving.
  final LiveGlide _meGlide = LiveGlide(
    bearingFromMovement: false, // my heading comes from the GPS only (no jitter while standing)
    minGlide: const Duration(milliseconds: 900),
    maxGlide: const Duration(seconds: 5),
  );
  final LiveGlide _otherGlide = LiveGlide();
  final ValueNotifier<int> _frame = ValueNotifier<int>(0);
  late final Ticker _ticker = createTicker(_onTick);

  // Camera animation (centre / zoom / rotation) for the "show both of us" view.
  late final AnimationController _camCtl =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 700))..addListener(_onCamTick);
  LatLng _cFrom = _fallbackCenter, _cTo = _fallbackCenter;
  double _zFrom = 14, _zTo = 14, _rFrom = 0, _rTo = 0;
  List<LatLng> _lastFitPts = const [];

  // The road route between the two people, from the other person to me (when I am the one
  // being visited; when I travel to them, the main route already is that route).
  NavRoute? _linkRoute;
  int _linkHint = 0;
  bool _linkLoading = false;
  bool _linkApprox = false;
  LatLng? _linkFrom, _linkTo;
  DateTime _linkAt = DateTime.fromMillisecondsSinceEpoch(0);

  LiveEta? _eta; // "8 min away · 2.4 km"
  DateTime? _otherStamp; // when the other person's position was recorded (server age applied)

  bool get _en => AppStrings.isEnglish;

  @override
  void initState() {
    super.initState();
    _autoStartPending = widget.startNavigating;
    if (widget.providerLat != null && widget.providerLng != null) {
      _dest = LatLng(widget.providerLat!, widget.providerLng!);
    }
    if (GpsService.hasFix) {
      _me = LatLng(GpsService.lat!, GpsService.lng!);
      _meGlide.push(_me!);
    }
    if (widget.bookingRef != null) {
      _pollOther();
      _liveTimer = Timer.periodic(const Duration(seconds: 3), (_) {
        _pollOther();
        _heartbeat();
      });
    }
    _init();
  }

  @override
  void dispose() {
    _liveTimer?.cancel();
    _ticker.dispose();
    _camCtl.dispose();
    _frame.dispose();
    final ref = widget.bookingRef;
    if (ref != null) ApiService.stopLiveLocation(ref); // leaving the map stops sharing
    _posSub?.cancel();
    super.dispose();
  }

  Future<void> _init() async {
    if (_dest == null) await _geocodeAddress();
    await _startTracking();
    if (_me != null && _dest != null && _route == null) {
      _lastRouteFrom = _me;
      await _fetchRoute(_me!, _dest!);
    }
  }

  // ───────────────────────── location ─────────────────────────

  Future<void> _startTracking() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        if (mounted) setState(() => _locationDenied = true);
        return;
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        if (mounted) setState(() => _locationDenied = true);
        return;
      }
      _posSub?.cancel();
      _posSub = Geolocator.getPositionStream(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.best, distanceFilter: 5),
      ).listen(_onPosition, onError: (_) {});

      final first = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 12)),
      );
      _onPosition(first);
    } catch (caught, trace) {
      AppLog.e('map_tracking_screen._startTracking', caught, trace);
      // keep whatever fix we already have
    }
  }

  /// Sends my position at most every 3 seconds, only while sharing is on.
  void _shareMine(Position p) =>
      _sendMine(LatLng(p.latitude, p.longitude), (p.speed >= 1.0 && p.heading >= 0) ? p.heading : null);

  void _sendMine(LatLng at, double? heading, {Duration every = const Duration(seconds: 3)}) {
    final ref = widget.bookingRef;
    if (ref == null || !_sharing || !_liveActive) return;
    final now = DateTime.now();
    if (now.difference(_lastSent) < every) return;
    _lastSent = now;
    ApiService.sendLiveLocation(ref, at.latitude, at.longitude, heading).then((code) {
      if (code == 409 && mounted) setState(() => _liveActive = false);
    });
  }

  /// Someone standing still produces no GPS events, and the server forgets a position after 90 s,
  /// so the other side's marker would vanish. Re-send the last known fix every ~12 s.
  void _heartbeat() {
    final me = _me;
    if (me == null || _lastFixAt == null || _locationDenied) return; // never pass a cached position off as live
    _sendMine(me, _meGlide.hasHeading ? _meGlide.heading : null, every: const Duration(seconds: 12));
  }

  /// Asks the server where the other person is. A provider heading to a customer navigates to that position.
  Future<void> _pollOther() async {
    final ref = widget.bookingRef;
    if (ref == null) return;
    if (!_liveActive && (_idlePolls++ % 4) != 0) return; // waiting for payment: ask every ~12 s, not every 3 s
    final d = await ApiService.fetchOtherLiveLocation(ref);
    if (!mounted || d == null) return;
    if (d['reason'] == 'BOOKING_NOT_ACTIVE') {
      _otherGlide.reset();
      if (_liveActive || _other != null) {
        setState(() {
          _liveActive = false;
          _other = null;
          _eta = null;
          _linkRoute = null;
          _linkFrom = null;
        });
      }
      return;
    }
    if (!_liveActive) {
      // Accepted and paid in the meantime: tracking starts without reopening the map.
      setState(() => _liveActive = true);
      _idlePolls = 0;
    }
    final lat = (d['latitude'] as num?)?.toDouble();
    final lng = (d['longitude'] as num?)?.toDouble();
    if (d['active'] != true || lat == null || lng == null) {
      _otherGlide.reset(); // when they start sharing again the marker appears at once, not flying in
      setState(() {
        _other = null;
        _eta = null;
        _linkRoute = null;
        _linkFrom = null;
        _otherStamp = null;
      });
      return;
    }
    final pt = LatLng(lat, lng);
    final heading = (d['heading'] as num?)?.toDouble();
    final age = (d['ageSeconds'] as num?)?.toInt() ?? 0;
    final prev = _other;
    final changed = prev == null || const Distance().as(LengthUnit.Meter, prev, pt) >= 0.5;
    if (changed) {
      _otherGlide.push(pt, heading: heading);
      _wake();
    }
    setState(() {
      _other = pt;
      _otherStamp = DateTime.now().subtract(Duration(seconds: age));
      _updateEta();
    });
    if (widget.toCustomer) {
      // The customer is the destination, and they may be moving: re-route when they moved a good way.
      final moved = _destRoutedTo == null || const Distance().as(LengthUnit.Meter, _destRoutedTo!, pt) > 80;
      if (_dest == null || moved) {
        setState(() {
          _dest = pt;
          _destApprox = false;
        });
        _destRoutedTo = pt;
        if (_me != null && !_loadingRoute) {
          _lastRouteFrom = _me;
          _fetchRoute(_me!, pt, rerouting: _route != null && _navigating);
        }
      }
    }
    _refreshLink();
    _autoFit();
  }

  /// Fetches the road route from the other person to me, only when it is worth it: they or I
  /// moved a good way, or the last one is a minute old. Never more often than every 8 s.
  Future<void> _refreshLink({bool force = false}) async {
    if (widget.toCustomer || !_liveActive || _linkLoading) return;
    final from = _otherGlide.target;
    final to = _me;
    if (from == null || to == null || _other == null) return;
    final now = DateTime.now();
    if (!force) {
      if (now.difference(_linkAt) < const Duration(seconds: 8)) return;
      final otherMoved = _linkFrom == null || const Distance().as(LengthUnit.Meter, _linkFrom!, from) > 120;
      final meMoved = _linkTo == null || const Distance().as(LengthUnit.Meter, _linkTo!, to) > 150;
      final old = now.difference(_linkAt) > const Duration(seconds: 60);
      if (!(otherMoved || meMoved || old)) return;
    }
    _linkLoading = true;
    _linkAt = now;
    _linkFrom = from;
    _linkTo = to;
    final fetched = await _osrm(from, to);
    _linkLoading = false;
    if (!mounted || _other == null) return;
    setState(() {
      _linkRoute = fetched ?? NavRoute.straight(from, to);
      _linkApprox = fetched == null;
      _linkHint = 0;
      _updateEta();
    });
    _autoFit();
  }

  /// Distance and time between the two of us, from the real route and how fast the mover is going.
  void _updateEta() {
    LiveEta? e;
    if (_other != null) {
      if (widget.toCustomer) {
        final r = _route, p = _progress;
        if (r != null && p != null) {
          e = LiveEta.fromRoute(r, remainingM: p.remainingM, observedMps: _meGlide.speed(), approximate: _routeFailed);
        }
      } else {
        final them = _otherGlide.target, me = _me;
        if (them != null && me != null) {
          final r = _linkRoute;
          if (r != null) {
            final p = r.progress(them, hint: _linkHint);
            _linkHint = p.index;
            e = LiveEta.fromRoute(r, remainingM: p.remainingM, observedMps: _otherGlide.speed(), approximate: _linkApprox);
          } else {
            e = LiveEta.straight(const Distance().as(LengthUnit.Meter, them, me), observedMps: _otherGlide.speed());
          }
        }
      }
    }
    _eta = e;
  }

  bool get _otherStale => _otherStamp != null && DateTime.now().difference(_otherStamp!).inSeconds > 30;

  void _onPosition(Position p) {
    if (!mounted) return;
    _shareMine(p);
    final here = LatLng(p.latitude, p.longitude);
    _lastFixAt = DateTime.now();
    _meGlide.push(here, heading: (p.speed >= 1.0 && p.heading >= 0) ? p.heading : null);
    _wake();
    setState(() {
      _me = here;
      _locationDenied = false;
      _updateEta();
    });
    _refreshLink();
    _autoFit();
    final dest = _dest;
    if (dest == null) return;

    if (_route == null) {
      if (!_loadingRoute) {
        _lastRouteFrom = here;
        _fetchRoute(here, dest);
      }
      return;
    }

    if (_arrived) return;
    final route = _route!;
    final prog = route.progress(here, hint: _progress?.index ?? 0);
    final toDest = const Distance().as(LengthUnit.Meter, here, dest);
    setState(() {
      _progress = prog;
      _nextStep = route.nextStepIndex(prog.index);
      _updateEta();
    });

    if (_navigating) {
      if (toDest <= _arriveMetres || prog.remainingM <= _arriveMetres) {
        setState(() {
          _arrived = true;
          _cam = _Cam.free;
        });
        return;
      }
      if (prog.offRouteM > _offRouteMetres &&
          !_loadingRoute &&
          DateTime.now().difference(_lastReroute) > _rerouteCooldown) {
        _lastReroute = DateTime.now();
        _fetchRoute(here, dest, rerouting: true);
      }
    } else {
      // Preview: refresh only after moving a good distance.
      final last = _lastRouteFrom;
      if (last == null || const Distance().as(LengthUnit.Meter, last, here) > 150) {
        _lastRouteFrom = here;
        _fetchRoute(here, dest);
      }
    }
  }

  // ───────────────────────── routing ─────────────────────────

  Future<void> _geocodeAddress() async {
    final q = widget.address.trim();
    if (q.isEmpty) return;
    try {
      final uri = Uri.https('nominatim.openstreetmap.org', '/search', {'format': 'json', 'limit': '1', 'q': q});
      final res = await SecureHttp.client
          .get(uri, headers: {'User-Agent': 'Ungana/1.0 (com.unganalink.app)'})
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final list = json.decode(res.body) as List;
        if (list.isNotEmpty) {
          final m = list.first as Map<String, dynamic>;
          final lat = double.tryParse(m['lat'].toString());
          final lng = double.tryParse(m['lon'].toString());
          if (lat != null && lng != null && mounted) {
            setState(() {
              _dest = LatLng(lat, lng);
              _destApprox = true;
            });
          }
        }
      }
    } catch (caught, trace) { AppLog.e('map_tracking_screen.setState', caught, trace); }
  }

  /// One driving route from the public OSRM router, or null when it is unreachable.
  Future<NavRoute?> _osrm(LatLng from, LatLng to) async {
    try {
      final uri = Uri.parse(
        'https://router.project-osrm.org/route/v1/driving/'
        '${from.longitude},${from.latitude};${to.longitude},${to.latitude}'
        '?overview=full&geometries=geojson&steps=true',
      );
      final res = await SecureHttp.client.get(uri).timeout(const Duration(seconds: 12));
      if (res.statusCode == 200) {
        final data = json.decode(res.body) as Map<String, dynamic>;
        final routes = data['routes'] as List?;
        if (routes != null && routes.isNotEmpty) {
          return NavRoute.fromOsrm(routes.first as Map<String, dynamic>);
        }
      }
    } catch (caught, trace) { AppLog.e('map_tracking_screen._osrm', caught, trace); }
    return null;
  }

  Future<void> _fetchRoute(LatLng from, LatLng to, {bool rerouting = false}) async {
    if (!mounted) return;
    setState(() {
      _loadingRoute = true;
      _routeFailed = false;
    });
    final fetched = await _osrm(from, to);
    if (!mounted) return;
    final failed = fetched == null;
    final route = fetched ?? NavRoute.straight(from, to);
    final prog = route.progress(from);
    setState(() {
      _route = route;
      _progress = prog;
      _nextStep = route.nextStepIndex(prog.index);
      _loadingRoute = false;
      _routeFailed = failed;
      _updateEta();
    });
    if (rerouting) {
      _snack(_en ? 'Route updated' : 'Njia imebadilishwa');
    } else if (_mapReady && !_navigating) {
      _autoFit(force: true); // only moves the camera while it is in "show both" mode
    }
    if (_autoStartPending) {
      _autoStartPending = false;
      _startNavigation();
    }
  }

  // ───────────────────────── camera / modes ─────────────────────────

  /// Wakes the frame ticker; it stops itself when both markers have arrived.
  void _wake() {
    if (mounted && !_ticker.isActive) _ticker.start();
  }

  void _onTick(Duration _) {
    final now = DateTime.now();
    final a = _meGlide.tick(now);
    final b = _otherGlide.tick(now);
    _frame.value++; // repaints only the markers
    if (_cam == _Cam.follow && !_camCtl.isAnimating && _mapReady) {
      final p = _meGlide.position;
      if (p != null) {
        try {
          if (_navigating) {
            _moveCamera(p);
          } else {
            _map.move(p, _map.camera.zoom);
          }
        } catch (caught, trace) { AppLog.e('map_tracking_screen._onTick', caught, trace); }
      }
    }
    if (!a && !b) _ticker.stop();
  }

  void _moveCamera(LatLng at) {
    try {
      _map.moveAndRotate(at, 17.5, -_meGlide.heading);
    } catch (caught, trace) { AppLog.e('map_tracking_screen._moveCamera', caught, trace); }
  }

  EdgeInsets get _fitPadding =>
      EdgeInsets.fromLTRB(56, _navigating ? 170 : 150, 56, _navigating ? 230 : 340);

  /// What the "show both of us" camera has to keep on screen: me, the other person (where they
  /// are drawn and where they are heading) or, when nobody else is live, the destination.
  List<LatLng> _bothPoints() {
    final out = <LatLng>[];
    final me = _meGlide.position ?? _me;
    if (me != null) out.add(me);
    final myT = _meGlide.target;
    if (myT != null) out.add(myT);
    if (_other != null) {
      final p = _otherGlide.position, t = _otherGlide.target;
      if (p != null) out.add(p);
      if (t != null) out.add(t);
    } else if (_dest != null) {
      out.add(_dest!);
    }
    return out;
  }

  /// Switches to the "show both of us" view and glides there.
  void _fitBounds() {
    if (!_mapReady) return;
    if (_cam != _Cam.both) setState(() => _cam = _Cam.both);
    _autoFit(force: true);
  }

  /// Keeps both people in view while the camera is in "both" mode. It only moves when something
  /// really changed (a point left the comfortable area, or the zoom should change a lot), so the
  /// map does not wobble with every GPS fix.
  void _autoFit({bool force = false}) {
    if (!_mapReady || _cam != _Cam.both) return;
    final pts = _bothPoints();
    if (pts.isEmpty) return;
    if (!force && _lastFitPts.length == pts.length) {
      var same = true;
      for (var i = 0; i < pts.length; i++) {
        if (const Distance().as(LengthUnit.Meter, pts[i], _lastFitPts[i]) > 25) {
          same = false;
          break;
        }
      }
      if (same) return;
    }
    _lastFitPts = pts;
    try {
      final cam = _map.camera;
      final c0 = cam.center, z0 = cam.zoom, r0 = cam.rotation;
      final b = LatLngBounds.fromPoints(pts);
      final tiny = (b.north - b.south).abs() < 0.0003 && (b.east - b.west).abs() < 0.0003; // ~30 m
      LatLng center;
      double zoom;
      if (tiny) {
        center = b.center;
        zoom = (_me == null && _other == null) ? 15.0 : 16.5; // alone with the destination: wider view
      } else {
        // Let flutter_map work out the fit, read the result, then put the camera back so that we
        // can glide there (all within one frame, nothing is drawn in between).
        _map.rotate(0);
        _map.fitCamera(CameraFit.bounds(bounds: b, padding: _fitPadding, maxZoom: 17));
        center = _map.camera.center;
        zoom = _map.camera.zoom;
        _map.moveAndRotate(c0, z0, r0);
      }
      if (force || _needsRefit(center, zoom)) _runCamera(center, zoom, 0);
    } catch (caught, trace) { AppLog.e('map_tracking_screen._autoFit', caught, trace); }
  }

  bool _needsRefit(LatLng center, double zoom) {
    try {
      final cam = _map.camera;
      if (cam.rotation.abs() > 1) return true;
      if ((zoom - cam.zoom).abs() > 0.4) return true;
      final vb = cam.visibleBounds;
      final spanLat = (vb.north - vb.south).abs();
      final spanLng = (vb.east - vb.west).abs();
      if (spanLat == 0 || spanLng == 0) return true;
      return (center.latitude - cam.center.latitude).abs() / spanLat > 0.2 ||
          (center.longitude - cam.center.longitude).abs() / spanLng > 0.2;
    } catch (caught, trace) {
      AppLog.e('map_tracking_screen._needsRefit', caught, trace);
      return true;
    }
  }

  /// Smoothly moves the camera to [center] / [zoom] / [rotation] (degrees).
  void _runCamera(LatLng center, double zoom, double rotation, {int ms = 700}) {
    if (!_mapReady) return;
    try {
      final cam = _map.camera;
      _cFrom = cam.center;
      _zFrom = cam.zoom;
      _rFrom = cam.rotation;
      _cTo = center;
      _zTo = zoom;
      _rTo = rotation;
      _camCtl
        ..stop()
        ..duration = Duration(milliseconds: ms)
        ..forward(from: 0);
    } catch (caught, trace) { AppLog.e('map_tracking_screen._runCamera', caught, trace); }
  }

  void _onCamTick() {
    if (!_mapReady) return;
    final done = _camCtl.value >= 1;
    final t = Curves.easeInOutCubic.transform(_camCtl.value);
    final c = LatLng(
      _cFrom.latitude + (_cTo.latitude - _cFrom.latitude) * t,
      _cFrom.longitude + (_cTo.longitude - _cFrom.longitude) * t,
    );
    final z = _zFrom + (_zTo - _zFrom) * t;
    final r = done ? _rTo : _rFrom + angleDelta(_rFrom, _rTo) * t;
    try {
      _map.moveAndRotate(done ? _cTo : c, done ? _zTo : z, r);
    } catch (caught, trace) { AppLog.e('map_tracking_screen._onCamTick', caught, trace); }
  }

  void _startNavigation() {
    if (_route == null) return;
    _camCtl.stop();
    setState(() {
      _navigating = true;
      _arrived = false;
      _cam = _Cam.follow;
    });
    final me = _meGlide.position ?? _me;
    if (me != null) _moveCamera(me);
  }

  void _stopNavigation() {
    setState(() {
      _navigating = false;
      _cam = _Cam.both;
    });
    _autoFit(force: true);
  }

  void _recenter() {
    final me = _meGlide.position ?? _me;
    if (me == null) return;
    setState(() => _cam = _Cam.follow);
    if (_navigating) {
      _runCamera(me, 17.5, -_meGlide.heading, ms: 450);
    } else {
      _runCamera(me, 16, 0, ms: 450);
    }
    _wake();
  }

  /// Optional: hand the trip over to an external maps app (Google Maps etc.).
  Future<void> _openExternalMaps() async {
    final to = _dest;
    final Uri uri;
    if (to != null) {
      uri = Uri.https('www.google.com', '/maps/dir/', {
        'api': '1',
        'destination': '${to.latitude},${to.longitude}',
        'travelmode': 'driving',
      });
    } else if (widget.address.trim().isNotEmpty) {
      uri = Uri.https('www.google.com', '/maps/search/', {'api': '1', 'query': widget.address.trim()});
    } else {
      _snack(_en ? 'No location available.' : 'Hakuna eneo linalopatikana.');
      return;
    }
    var ok = false;
    try {
      ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (caught, trace) { AppLog.e('map_tracking_screen._openExternalMaps', caught, trace); }
    if (!ok) _snack(_en ? 'Could not open the maps app' : 'Imeshindwa kufungua programu ya ramani');
  }

  /// Opens the provider's chat as a full page (login / self-chat checks are done by [ChatThreadScreen.open]).
  Future<void> _messageProvider() async {
    await ChatThreadScreen.open(
      context,
      recipientId: widget.providerId,
      name: widget.providerName,
    );
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 2)));
  }

  // ───────────────────────── UI ─────────────────────────

  @override
  Widget build(BuildContext context) {
    final dest = _dest;
    final center = _me ?? dest ?? _fallbackCenter;
    final route = _route;

    // Only the part of the route still ahead of the traveller is drawn.
    List<LatLng> ahead = const [];
    if (route != null) {
      final i = (_progress?.index ?? 0).clamp(0, route.points.length - 1).toInt();
      ahead = [if (_navigating && _me != null) _me!, ...route.points.sublist(i)];
    }

    // The other person's remaining road to me (thinner, amber), drawn from where they are heading.
    List<LatLng> linkAhead = const [];
    final lr = _linkRoute;
    if (lr != null && !widget.toCustomer && _other != null && _otherGlide.target != null) {
      final i = _linkHint.clamp(0, lr.points.length - 1).toInt();
      linkAhead = [_otherGlide.target!, ...lr.points.sublist(i)];
    }

    return PopScope(
      canPop: !_navigating,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && _navigating) _confirmExit();
      },
      child: Scaffold(
        backgroundColor: AppColors.background,
        body: Stack(
          children: [
            FlutterMap(
              mapController: _map,
              options: MapOptions(
                initialCenter: center,
                initialZoom: 14,
                minZoom: 3,
                maxZoom: 19,
                onPositionChanged: (_, hasGesture) {
                  // The user took over the camera: stop auto-framing until they ask for it again.
                  if (hasGesture && _cam != _Cam.free) {
                    _camCtl.stop();
                    setState(() => _cam = _Cam.free);
                  }
                },
                onMapReady: () {
                  _mapReady = true;
                  if (_navigating) {
                    if (_me != null) _moveCamera(_me!); // keep following; never fall back to "both" mid-navigation
                  } else {
                    _fitBounds();
                  }
                },
              ),
              children: [
                TileLayer(
                  urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                  userAgentPackageName: 'com.unganalink.app',
                ),
                if (linkAhead.length >= 2)
                  PolylineLayer(polylines: [
                    Polyline(
                      points: linkAhead,
                      strokeWidth: 5,
                      color: AppColors.warning,
                      borderStrokeWidth: 2,
                      borderColor: Colors.white,
                    ),
                  ]),
                if (ahead.length >= 2)
                  PolylineLayer(polylines: [
                    Polyline(
                      points: ahead,
                      strokeWidth: _navigating ? 8 : 5,
                      color: AppColors.primary,
                      borderStrokeWidth: 2,
                      borderColor: Colors.white,
                    ),
                  ]),
                // Rebuilt every frame while a marker glides (cheap: three markers).
                ValueListenableBuilder<int>(
                  valueListenable: _frame,
                  builder: (_, __, ___) {
                    final myPos = _meGlide.position ?? _me;
                    final theirPos = _otherGlide.position ?? _other;
                    return MarkerLayer(markers: [
                      // When I travel to the other person they ARE the destination, so no second pin.
                      if (dest != null && !(widget.toCustomer && _other != null))
                        Marker(
                          point: dest,
                          width: 150,
                          height: 88,
                          alignment: Alignment.topCenter,
                          rotate: true, // stay upright while the map turns
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                constraints: const BoxConstraints(maxWidth: 146),
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                decoration: BoxDecoration(
                                  color: AppColors.textPrimary,
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: const [BoxShadow(color: Color(0x40000000), blurRadius: 6, offset: Offset(0, 2))],
                                ),
                                child: Text(
                                  widget.providerName,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(color: Colors.white, fontSize: 11.5, fontWeight: FontWeight.w700),
                                ),
                              ),
                              const Icon(Icons.location_on_rounded, size: 48, color: AppColors.danger),
                            ],
                          ),
                        ),
                      if (theirPos != null && _other != null)
                        Marker(
                          point: theirPos,
                          width: 44,
                          height: 44,
                          rotate: true,
                          child: _otherMarker(),
                        ),
                      if (myPos != null)
                        Marker(
                          point: myPos,
                          width: 44,
                          height: 44,
                          rotate: true, // always upright; the arrow is turned by hand (see _arrow)
                          child: _navigating ? _carMarker() : _meDot(),
                        ),
                    ]);
                  },
                ),
                const SimpleAttributionWidget(source: Text('© OpenStreetMap contributors')),
              ],
            ),

            // Top: turn banner while navigating, title bar otherwise.
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _navigating && !_arrived ? _turnBanner() : _titleBar(),
                    if (widget.bookingRef != null) _livePill(),
                  ],
                ),
              ),
            ),

            // Map buttons
            Positioned(
              right: 12,
              bottom: _navigating ? 190 : 300,
              child: Column(
                children: [
                  if (!_navigating || _other != null) ...[
                    _roundButton(
                      _other != null ? Icons.people_alt_rounded : Icons.alt_route_rounded,
                      _fitBounds,
                      active: _cam == _Cam.both && _other != null,
                    ),
                    const SizedBox(height: 10),
                  ],
                  _roundButton(
                    _follow ? Icons.my_location_rounded : Icons.location_searching_rounded,
                    _recenter,
                    active: _follow,
                  ),
                ],
              ),
            ),

            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: _arrived ? _arrivedCard() : (_navigating ? _navBottomBar() : _previewCard()),
            ),
          ],
        ),
      ),
    );
  }

  /// Live-tracking status ("8 min away · 2.4 km") and the stop / start button for sharing my position.
  Widget _livePill() {
    final name = widget.providerName;
    final eta = _eta;
    final live = _liveActive && _other != null;
    final String title;
    String? sub;
    if (!_liveActive) {
      title = _en
          ? 'Live tracking starts once the booking is accepted and paid.'
          : 'Ufuatiliaji wa moja kwa moja unaanza baada ya ombi kukubaliwa na kulipiwa.';
    } else if (_other != null) {
      title = eta == null ? (_en ? 'Locating $name…' : 'Tunatafuta eneo la $name…') : LiveText.away(eta, _en);
      sub = _otherStale
          ? LiveText.lastSeen(DateTime.now().difference(_otherStamp!).inSeconds, _en)
          : (_en ? '$name · live' : '$name · moja kwa moja');
    } else {
      title = _en ? 'Waiting for $name to share their location' : 'Tunamsubiri $name ashiriki eneo lake';
    }
    return Container(
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.fromLTRB(12, 8, 6, 8),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(14), boxShadow: _shadow),
      child: Row(
        children: [
          Icon(Icons.sensors_rounded, size: live ? 22 : 16, color: live && !_otherStale ? AppColors.success : AppColors.textSecondary),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  title,
                  style: live
                      ? const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.successDark)
                      : const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                ),
                if (sub != null)
                  Text(sub, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
              ],
            ),
          ),
          if (_liveActive)
            TextButton(
              onPressed: () {
                final ref = widget.bookingRef!;
                setState(() => _sharing = !_sharing);
                if (!_sharing) ApiService.stopLiveLocation(ref);
              },
              style: TextButton.styleFrom(
                visualDensity: VisualDensity.compact,
                foregroundColor: _sharing ? AppColors.danger : AppColors.primary,
              ),
              child: Text(
                _sharing ? (_en ? 'Stop sharing' : 'Acha kushiriki') : (_en ? 'Share mine' : 'Shiriki eneo langu'),
                style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800),
              ),
            ),
        ],
      ),
    );
  }

  Widget _meDot() => Container(
        margin: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: AppColors.primary,
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white, width: 3),
          boxShadow: [BoxShadow(color: AppColors.primary.withValues(alpha: 0.35), blurRadius: 10, spreadRadius: 4)],
        ),
      );

  /// An arrow pointing the way someone is travelling. The marker is kept upright on screen, so the
  /// arrow is turned by (true heading + map rotation): that is straight up while the map follows my
  /// heading, and the real compass direction when the map is north-up ("show both").
  Widget _arrow(BuildContext ctx, double headingDeg, Color color) {
    final rot = MapCamera.maybeOf(ctx)?.rotation ?? 0;
    return Transform.rotate(
      angle: (headingDeg + rot) * math.pi / 180,
      child: Icon(Icons.navigation_rounded, color: color, size: 24),
    );
  }

  Widget _carMarker() => Builder(
        builder: (ctx) => Container(
          decoration: BoxDecoration(
            color: AppColors.primary,
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white, width: 3),
            boxShadow: const [BoxShadow(color: Color(0x55000000), blurRadius: 8, offset: Offset(0, 3))],
          ),
          child: Center(child: _arrow(ctx, _meGlide.hasHeading ? _meGlide.heading : 0, Colors.white)),
        ),
      );

  /// The other person: a round badge with a bubble above it ("Name · 8 min"), an arrow while they
  /// travel, dimmed when their position is getting old.
  Widget _otherMarker() {
    final stale = _otherStale;
    final eta = _eta;
    final label = eta == null ? widget.providerName : '${widget.providerName} · ${LiveText.chip(eta, _en)}';
    final badge = Builder(
      builder: (ctx) => Container(
        decoration: BoxDecoration(
          color: stale ? AppColors.textSecondary : AppColors.warning,
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white, width: 3),
          boxShadow: [
            const BoxShadow(color: Color(0x55000000), blurRadius: 8, offset: Offset(0, 3)),
            if (!stale) BoxShadow(color: AppColors.warning.withValues(alpha: 0.30), blurRadius: 10, spreadRadius: 5),
          ],
        ),
        child: Center(
          child: _otherGlide.moving() && _otherGlide.hasHeading
              ? _arrow(ctx, _otherGlide.heading, Colors.white)
              : const Icon(Icons.person_rounded, color: Colors.white, size: 22),
        ),
      ),
    );
    return Stack(
      clipBehavior: Clip.none,
      alignment: Alignment.center,
      children: [
        Positioned.fill(child: badge),
        Positioned(
          left: -63,
          right: -63,
          bottom: 50,
          child: Center(
            child: Container(
              constraints: const BoxConstraints(maxWidth: 170),
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
              decoration: BoxDecoration(
                color: stale ? AppColors.textSecondary : AppColors.textPrimary,
                borderRadius: BorderRadius.circular(10),
                boxShadow: const [BoxShadow(color: Color(0x40000000), blurRadius: 6, offset: Offset(0, 2))],
              ),
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white, fontSize: 11.5, fontWeight: FontWeight.w800),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _titleBar() {
    return Row(
      children: [
        _roundButton(Icons.arrow_back_rounded, () => Navigator.pop(context)),
        const SizedBox(width: 10),
        Expanded(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(14), boxShadow: _shadow),
            child: Row(
              children: [
                const Icon(Icons.navigation_rounded, size: 18, color: AppColors.primary),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _en ? 'Navigation' : 'Mwongozo wa Safari',
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                  ),
                ),
                if (_loadingRoute) const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _turnBanner() {
    final route = _route;
    final prog = _progress;
    if (route == null || prog == null) return _titleBar();
    final si = _nextStep.clamp(0, route.steps.length - 1).toInt();
    final step = route.steps[si];
    final metres = route.metresToStep(prog.index, si);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: AppColors.primaryDark,
        borderRadius: BorderRadius.circular(18),
        boxShadow: const [BoxShadow(color: Color(0x40000000), blurRadius: 14, offset: Offset(0, 4))],
      ),
      child: Row(
        children: [
          Icon(NavText.icon(step), color: Colors.white, size: 44),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  NavText.distance(metres, _en),
                  style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w900),
                ),
                Text(
                  NavText.instruction(step, _en),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
          if (_loadingRoute)
            const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)),
        ],
      ),
    );
  }

  Widget _sheet({required Widget child}) {
    return Container(
      padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).padding.bottom),
      decoration: const BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
        boxShadow: [BoxShadow(color: Color(0x1F000000), blurRadius: 16, offset: Offset(0, -4))],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Center(
            child: Container(
              width: 38,
              height: 4,
              margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)),
            ),
          ),
          child,
        ],
      ),
    );
  }

  /// Clock time of arrival, e.g. 14:35.
  String _arriveAt(double remainingSeconds) {
    final t = DateTime.now().add(Duration(seconds: remainingSeconds.round()));
    return '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
  }

  Widget _previewCard() {
    final prog = _progress;
    final ready = _route != null && prog != null;
    return _sheet(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: const BoxDecoration(color: AppColors.primaryLight, shape: BoxShape.circle),
                child: Icon(widget.toCustomer ? Icons.person_rounded : Icons.storefront_rounded, color: AppColors.primary, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(widget.providerName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                    if (widget.serviceTitle.trim().isNotEmpty)
                      Text(widget.serviceTitle,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                ready ? NavText.duration(prog.remainingS, _en) : '--',
                style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: AppColors.successDark, height: 1),
              ),
              const SizedBox(width: 10),
              Padding(
                padding: const EdgeInsets.only(bottom: 3),
                child: Text(
                  ready ? '${NavText.distance(prog.remainingM, _en)}  ·  ${_en ? 'arrive' : 'fika'} ${_arriveAt(prog.remainingS)}' : '',
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textSecondary),
                ),
              ),
            ],
          ),
          if (widget.address.trim().isNotEmpty) ...[
            const SizedBox(height: 12),
            Row(
              children: [
                const Icon(Icons.location_on_outlined, size: 16, color: AppColors.textSecondary),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(widget.address,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                ),
              ],
            ),
          ],
          if (_dest != null && _destApprox) ...[
            const SizedBox(height: 10),
            _notice(_en
                ? 'Approximate location, found from the address. Confirm the exact place with the provider.'
                : 'Eneo la makadirio, limepatikana kutoka kwenye anwani. Thibitisha eneo kamili na mtoa huduma.'),
          ],
          if (_dest == null && !_loadingRoute) ...[
            const SizedBox(height: 10),
            _notice(widget.toCustomer
                ? (_en
                    ? 'The customer has not shared their live location yet.'
                    : 'Mteja bado hajashiriki eneo lake.')
                : (_en
                    ? 'We could not find this provider\'s exact location yet.'
                    : 'Hatukuweza kupata eneo kamili la mtoa huduma huyu bado.')),
          ],
          if (_routeFailed) ...[
            const SizedBox(height: 10),
            _notice(_en
                ? 'Road directions are unavailable (offline?). Showing a straight line.'
                : 'Maelekezo ya barabara hayapatikani (huna mtandao?). Inaonyesha mstari ulionyooka.'),
          ],
          if (_locationDenied) ...[
            const SizedBox(height: 10),
            _notice(
              _en ? 'Turn on location to see your position and the route.' : 'Washa eneo (location) ili uone nafasi yako na njia.',
              action: _en ? 'Enable' : 'Washa',
              onAction: () async {
                await Geolocator.openLocationSettings();
                _startTracking();
              },
            ),
          ],
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: ready ? _startNavigation : null,
              icon: const Icon(Icons.navigation_rounded, size: 18),
              label: Text(_en ? 'Start' : 'Anza Safari', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                foregroundColor: Colors.white,
                elevation: 0,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _messageProvider,
              icon: const Icon(Icons.chat_bubble_outline_rounded, size: 18),
              label: Text(widget.toCustomer ? (_en ? 'Message customer' : 'Tuma ujumbe kwa mteja') : (_en ? 'Message provider' : 'Tuma ujumbe kwa mtoa huduma'),
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.primary,
                side: const BorderSide(color: AppColors.border),
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _openExternalMaps,
              icon: const Icon(Icons.map_rounded, size: 18),
              label: Text(_en ? 'Use Google Maps instead' : 'Tumia Ramani (Google Maps)',
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.primary,
                side: const BorderSide(color: AppColors.border),
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _navBottomBar() {
    final prog = _progress;
    final eta = prog == null ? null : DateTime.now().add(Duration(seconds: prog.remainingS.round()));
    String hhmm(DateTime t) => '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
    return _sheet(
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  prog == null ? '--' : NavText.duration(prog.remainingS, _en),
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppColors.successDark),
                ),
                const SizedBox(height: 2),
                Text(
                  prog == null
                      ? ''
                      : '${NavText.distance(prog.remainingM, _en)}  •  ${_en ? 'Arrive' : 'Fika'} ${hhmm(eta!)}',
                  style: const TextStyle(fontSize: 13, color: AppColors.textSecondary, fontWeight: FontWeight.w600),
                ),
                Text(
                  widget.providerName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                ),
              ],
            ),
          ),
          IconButton(
            tooltip: widget.toCustomer ? (_en ? 'Message customer' : 'Tuma ujumbe kwa mteja') : (_en ? 'Message provider' : 'Tuma ujumbe'),
            onPressed: _messageProvider,
            icon: const Icon(Icons.chat_bubble_rounded, color: AppColors.primary),
          ),
          IconButton(
            tooltip: _en ? 'Open in Google Maps' : 'Fungua Google Maps',
            onPressed: _openExternalMaps,
            icon: const Icon(Icons.map_rounded, color: AppColors.primary),
          ),
          const SizedBox(width: 4),
          ElevatedButton(
            onPressed: _confirmExit,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.danger,
              foregroundColor: Colors.white,
              elevation: 0,
              padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            child: Text(_en ? 'Exit' : 'Toka', style: const TextStyle(fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }

  Widget _arrivedCard() {
    return _sheet(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.check_circle_rounded, color: AppColors.success, size: 48),
          const SizedBox(height: 8),
          Text(_en ? 'You have arrived' : 'Umefika',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppColors.textPrimary)),
          const SizedBox(height: 4),
          Text(widget.providerName,
              textAlign: TextAlign.center, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _messageProvider,
              icon: const Icon(Icons.chat_bubble_outline_rounded, size: 18),
              label: Text(widget.toCustomer ? (_en ? 'Message customer' : 'Tuma ujumbe kwa mteja') : (_en ? 'Message provider' : 'Tuma ujumbe'), style: const TextStyle(fontWeight: FontWeight.w700)),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.primary,
                side: const BorderSide(color: AppColors.border),
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () => Navigator.pop(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                foregroundColor: Colors.white,
                elevation: 0,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: Text(_en ? 'Done' : 'Sawa', style: const TextStyle(fontWeight: FontWeight.w800)),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _confirmExit() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(_en ? 'Stop navigation?' : 'Acha mwongozo wa safari?'),
        content: Text(_en ? 'You will leave turn-by-turn guidance.' : 'Utaacha kupata maelekezo ya kila zamu.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(_en ? 'Continue' : 'Endelea')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(_en ? 'Stop' : 'Acha', style: const TextStyle(color: AppColors.danger)),
          ),
        ],
      ),
    );
    if (ok == true && mounted) {
      _stopNavigation();
    }
  }

  Widget _notice(String text, {String? action, VoidCallback? onAction}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(color: AppColors.warningLight, borderRadius: BorderRadius.circular(10)),
      child: Row(
        children: [
          const Icon(Icons.info_outline_rounded, size: 16, color: AppColors.warningDark),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 12, color: AppColors.warningDark))),
          if (action != null)
            TextButton(
              onPressed: onAction,
              style: TextButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 8), minimumSize: const Size(0, 30)),
              child: Text(action, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
            ),
        ],
      ),
    );
  }

  Widget _roundButton(IconData icon, VoidCallback onTap, {bool active = false}) {
    return Material(
      color: active ? AppColors.primary : AppColors.surface,
      shape: const CircleBorder(),
      elevation: 3,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(11),
          child: Icon(icon, size: 22, color: active ? Colors.white : AppColors.textPrimary),
        ),
      ),
    );
  }

  static const List<BoxShadow> _shadow = [BoxShadow(color: Color(0x1A000000), blurRadius: 10, offset: Offset(0, 3))];
}
