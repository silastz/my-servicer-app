import '../services/app_policy.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart' show CameraDevice, ImageSource;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/media_picker.dart';
import '../services/security_settings.dart';
import '../services/session_manager.dart';
import '../widgets/app_image.dart';
import '../widgets/app_ui.dart';
import '../widgets/location_picker_sheet.dart';
import '../widgets/login_modal.dart';
import '../widgets/profile_completion_card.dart';
import '../widgets/service_badges.dart';
import '../models/models.dart' show ServiceItem;
import '../services/block_service.dart';
import 'accept_invitation_screen.dart';
import 'admin_payment_gateway_screen.dart';
import 'admin_provider_fees_screen.dart';
import 'admin_otp_settings_screen.dart';
import 'admin_promo_push_screen.dart';
import 'admin_sms_gateway_screen.dart';
import 'admin_identity_lookup_screen.dart';
import 'admin_ads_screen.dart';
import 'admin_wallet_screen.dart';
import 'admin_verification_screen.dart';
import 'admin_reports_screen.dart';
import 'admin_users_screen.dart';
import 'admin_notification_prefs_screen.dart';
import 'admin_bookings_screen.dart';
import 'admin_boost_plans_screen.dart';
import 'admin_fees_screen.dart';
import 'admin_app_version_screen.dart';
import 'blocked_users_screen.dart';
import 'delete_account_screen.dart';
import 'favorites_screen.dart';
import 'help_support_screen.dart';
import 'invite_trusted_screen.dart';
import 'my_reviews_screen.dart';
import 'location_service_radius_screen.dart';
import 'nida_verification_screen.dart';
import 'payment_methods_screen.dart';
import 'payments_screen.dart';
import 'pocket_fund_screen.dart';
import 'profile_photo_screen.dart';
import 'provider_documents_screen.dart';
import 'register_provider_screen.dart';
import 'registration_fee_screen.dart';
import 'requests_screen.dart';
import 'sell_manage_services_screen.dart';
import 'seller_earnings_screen.dart';
import 'settings_security_screen.dart';
import 'verify_business_screen.dart';
import 'verify_name_screen.dart';
import 'verify_photo_screen.dart';
import '../widgets/language_selector_sheet.dart';
import '../services/data_sync.dart';
import '../services/currency_service.dart';
import '../services/location_service.dart';
import '../widgets/country_code_picker.dart';
import '../security/input_validation.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool _uploadingAvatar = false;
  bool _uploadingCover = false;
  int _serviceCount = 0;
  int _pendingInvites = 0; // invitations waiting for me to accept

  @override
  void initState() {
    super.initState();
    _fetchServiceCount();
    _loadMyServices();
    _fetchPendingInvites();
    _checkRegistrationFee();
    // The server is the truth: photo, cover, About me, lock state and social links on a new phone.
    ApiService.syncMyProfile().then((_) {
      if (mounted) setState(() {});
    });
    // Rebuild when city / badge / role change elsewhere in the app.
    SessionManager.sessionNotifier.addListener(_onSessionChanged);
    DataSync.changed.addListener(_onDataChanged);
  }

  void _onSessionChanged() {
    if (mounted) setState(() {});
  }

  // Wallet / services changed elsewhere (deposit, booking release, new service...).
  void _onDataChanged() {
    if (!mounted) return;
    _fetchServiceCount();
    _loadMyServices();
    _fetchPendingInvites();
  }

  @override
  void dispose() {
    DataSync.changed.removeListener(_onDataChanged);
    SessionManager.sessionNotifier.removeListener(_onSessionChanged);
    super.dispose();
  }

  /// After signing in (or when the account changed): pull what the server has and reload the numbers.
  Future<void> _refreshProfile() async {
    if (!SessionManager.isLoggedIn()) {
      if (mounted) setState(() {});
      return;
    }
    await ApiService.syncMyProfile();
    if (mounted) setState(() {});
    _fetchServiceCount();
    _loadMyServices();
    _fetchPendingInvites();
    _checkRegistrationFee();
  }

  Future<void> _fetchServiceCount() async {
    if (!SessionManager.isLoggedIn() || !SessionManager.isSeller()) return;
    final list = await ApiService.fetchSellerServices();
    if (mounted) setState(() => _serviceCount = list.length);
  }

  Future<void> _fetchPendingInvites() async {
    if (!SessionManager.isLoggedIn() || !SessionManager.isSeller() || SessionManager.isIdentityVerified()) {
      if (mounted && _pendingInvites != 0) setState(() => _pendingInvites = 0);
      return;
    }
    final list = await ApiService.fetchPendingReceivedInvitations();
    if (mounted) setState(() => _pendingInvites = list.length);
  }

  /// Older accounts have no local fee flag: ask the server once.
  Future<void> _checkRegistrationFee() async {
    if (!SessionManager.isLoggedIn() || !SessionManager.isSeller()) return;
    if (SessionManager.getRegFeePaid() != null) return;
    final res = await ApiService.getRegistrationFeeStatus();
    if (res != null && res['paid'] is bool) {
      await SessionManager.setRegFeePaid(res['paid'] as bool);
    }
  }

  void _open(Widget screen) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => screen)).then((_) {
      if (!mounted) return;
      _fetchServiceCount();
      _fetchPendingInvites();
        setState(() {});
    });
  }

  /// Pick a photo, upload it, and show it as the profile picture.
  Future<void> _changeAvatar([ImageSource? source]) async {
    if (_uploadingAvatar) return;
    final isEn = AppStrings.isEnglish;
    final messenger = ScaffoldMessenger.of(context);
    final file = await MediaPicker.pickImage(
      context,
      title: isEn ? 'Profile photo' : 'Picha ya wasifu',
      maxWidth: 1024,
      preferredCamera: CameraDevice.front,
      source: source,
    );
    if (file == null || !mounted) return;
    setState(() => _uploadingAvatar = true);
    final res = await ApiService.uploadAvatar(file.path);
    if (!mounted) return;
    setState(() => _uploadingAvatar = false);
    messenger.showSnackBar(SnackBar(
      backgroundColor: res.ok ? AppColors.success : AppColors.danger,
      content: Text(res.ok
          ? (isEn ? 'Profile photo updated.' : 'Picha ya wasifu imesasishwa.')
          : (res.error ?? (isEn ? 'Could not upload the photo.' : 'Imeshindwa kupakia picha.'))),
    ));
  }

  /// WhatsApp-style photo page: view the photo, change it (camera/gallery) or remove it.
  Future<void> _openPhotoOptions({required String stageName}) async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => ProfilePhotoScreen(name: stageName)));
    if (mounted) setState(() {});
  }

  /// Round profile picture: the uploaded photo, or the first letter of the
  /// name. Tapping it (signed in) changes the photo.
  Widget _avatar({required bool isLoggedIn, required String stageName, double size = 60}) {
    final url = isLoggedIn ? SessionManager.getAvatarUrl() : '';
    final initial = isLoggedIn && stageName.isNotEmpty ? stageName.substring(0, 1).toUpperCase() : '?';
    final letter = Center(
      child: Text(initial, style: TextStyle(color: Colors.white, fontSize: size * 0.37, fontWeight: FontWeight.bold)),
    );
    return GestureDetector(
      onTap: isLoggedIn ? () => _openPhotoOptions(stageName: stageName) : null,
      child: SizedBox(
        width: size,
        height: size,
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Container(
              width: size,
              height: size,
              clipBehavior: Clip.antiAlias,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isLoggedIn ? AppColors.primary : AppColors.textMuted,
                border: size > 70 ? Border.all(color: AppColors.surface, width: 3) : null,
                boxShadow: size > 70
                    ? const [BoxShadow(color: Color(0x24000000), blurRadius: 12, offset: Offset(0, 4))]
                    : null,
              ),
              child: url.isEmpty
                  ? letter
                  : AppImage(url, fit: BoxFit.cover, width: size, height: size, errorBuilder: (_, _, _) => letter),
            ),
            if (_uploadingAvatar)
              Positioned.fill(
                child: DecoratedBox(
                  decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.black38),
                  child: const Center(
                    child: SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    ),
                  ),
                ),
              )
            else if (isLoggedIn)
              Positioned(
                right: -2,
                bottom: -2,
                child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    shape: BoxShape.circle,
                    border: Border.all(color: AppColors.border),
                  ),
                  child: const Icon(Icons.photo_camera_rounded, size: 12, color: AppColors.primary),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _addPhone() => _changeContact(isPhone: true);

  List<ProfileTask> _tasks({required bool isSeller}) {
    final isEn = AppStrings.isEnglish;
    final badge = SessionManager.getBadge();
    final verified = badge == 'BLUE_TICK' || badge == 'GREEN_BADGE';
    return [
      ProfileTask(
        title: isEn ? 'Add phone number' : 'Weka namba ya simu',
        hint: isEn ? 'So providers and support can reach you' : 'Ili watoa huduma na msaada wakufikie',
        icon: Icons.phone_outlined,
        done: SessionManager.getPhone().trim().isNotEmpty,
        onTap: _addPhone,
      ),
      ProfileTask(
        title: isEn ? 'Choose your city' : 'Chagua mji wako',
        hint: isEn ? 'See services near you' : 'Ona huduma zilizo karibu nawe',
        icon: Icons.location_city_outlined,
        done: SessionManager.hasUserCity(),
        onTap: () => LocationPickerSheet.show(context),
      ),
      ProfileTask(
        title: isEn ? 'Add your social links' : 'Weka mitandao yako ya kijamii',
        hint: isEn ? 'WhatsApp, Instagram, TikTok and more' : 'WhatsApp, Instagram, TikTok na zaidi',
        icon: Icons.alternate_email_rounded,
        done: SessionManager.socialKeys.any((k) => SessionManager.getSocial(k).isNotEmpty),
        onTap: _editSocials,
      ),
      if (isSeller) ...[
        ProfileTask(
          title: isEn ? 'Upload a cover photo' : 'Pakia picha ya jalada',
          hint: isEn ? 'The big photo at the top of your profile' : 'Picha kubwa juu ya wasifu wako',
          icon: Icons.panorama_outlined,
          done: SessionManager.getCoverUrl().isNotEmpty,
          onTap: _coverOptions,
        ),
        ProfileTask(
          title: isEn ? 'Write your About me' : 'Andika Kuhusu mimi',
          hint: isEn ? 'Help customers get to know you' : 'Wasaidie wateja kukufahamu',
          icon: Icons.notes_rounded,
          done: SessionManager.getBio().isNotEmpty,
          onTap: _changeBio,
        ),
        ProfileTask(
          title: isEn ? 'Pay the one-time fee' : 'Lipa ada ya mara moja',
          hint: isEn ? 'Activates your provider account' : 'Huwasha akaunti yako ya mtoa huduma',
          icon: Icons.receipt_long_outlined,
          done: SessionManager.getRegFeePaid() != false,
          onTap: () => _open(const RegistrationFeeScreen()),
        ),
        ProfileTask(
          title: isEn ? 'Verify your identity' : 'Thibitisha utambulisho wako',
          hint: isEn ? 'Get a verified badge and more trust' : 'Pata alama ya uthibitisho na imani zaidi',
          icon: Icons.verified_user_outlined,
          done: verified,
          onTap: () => _open(const NidaVerificationScreen()),
        ),
        ProfileTask(
          title: isEn ? 'Upload your documents' : 'Pakia nyaraka zako',
          hint: isEn ? 'ID photos and selfie to finish verification' : 'Picha za kitambulisho na selfie kukamilisha uthibitisho',
          icon: Icons.upload_file_rounded,
          done: verified || ProviderDocumentsScreen.requiredIds.every(SessionManager.getSubmittedDocs().contains),
          onTap: () => _open(const ProviderDocumentsScreen()),
        ),
        ProfileTask(
          title: isEn ? 'Add your first service' : 'Weka huduma yako ya kwanza',
          hint: isEn ? 'Customers can only book listed services' : 'Wateja wanaweza kuoda huduma zilizowekwa tu',
          icon: Icons.add_business_outlined,
          done: _serviceCount > 0,
          onTap: () => _open(const SellManageServicesScreen()),
        ),
        ProfileTask(
          title: isEn ? 'Unlock your profile so customers can reach you' : 'Fungua wasifu wako ili wateja wakufikie',
          hint: isEn ? 'Settings → Privacy & Security → Profile' : 'Mipangilio → Faragha na Usalama → Wasifu',
          icon: Icons.lock_open_rounded,
          done: !SecuritySettings.profileLocked,
          onTap: () => _open(const SettingsSecurityScreen()),
        ),
      ] else
        ProfileTask(
          title: isEn ? 'Save a favorite service' : 'Hifadhi huduma pendwa',
          hint: isEn ? 'Tap the bookmark on any service' : 'Bonyeza alama ya kuhifadhi kwenye huduma yoyote',
          icon: Icons.favorite_border_rounded,
          done: SessionManager.getFavoriteIds().isNotEmpty,
          onTap: () => _open(const FavoritesScreen()),
        ),
    ];
  }

  Widget _feeBanner() {
    final isEn = AppStrings.isEnglish;
    final amount = CurrencyService.group(SessionManager.registrationFee);
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.dangerLight,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.danger.withValues(alpha: 0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                child: const Icon(Icons.receipt_long_rounded, color: AppColors.dangerDark, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            isEn ? 'One-time fee' : 'Ada ya mara moja',
                            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                          ),
                        ),
                        StatusPill(text: isEn ? 'Unpaid' : 'Haijalipwa', color: AppColors.dangerDark),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      !SessionManager.registrationFeeKnown
                          ? (isEn
                              ? 'Pay the one-time fee to activate your provider account.'
                              : 'Lipa ada ya mara moja kuwasha akaunti yako ya mtoa huduma.')
                          : isEn
                              ? 'Pay ${CurrencyService.symbol} $amount once to activate your provider account.'
                              : 'Lipa ${CurrencyService.symbol} $amount mara moja kuwasha akaunti yako ya mtoa huduma.',
                      style: const TextStyle(fontSize: 12, height: 1.35, color: AppColors.slateMuted),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 42,
            child: ElevatedButton(
              onPressed: () => _open(const RegistrationFeeScreen()),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.dangerDark,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: Text(isEn ? 'Pay Now' : 'Lipa Sasa', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _unverifiedBanner() {
    final isEn = AppStrings.isEnglish;
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.warningLight,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.warning.withValues(alpha: 0.35)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                child: const Icon(Icons.gpp_maybe_outlined, color: AppColors.warningDark, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      isEn ? 'Your profile is not verified' : 'Wasifu wako haujathibitishwa',
                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      isEn
                          ? 'Verify your identity to build trust with customers.'
                          : 'Thibitisha utambulisho wako ili upate imani ya wateja.',
                      style: const TextStyle(fontSize: 12, height: 1.35, color: AppColors.slateMuted),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 42,
            child: ElevatedButton(
              onPressed: () => _open(const NidaVerificationScreen()),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.warningDark,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: Text(isEn ? 'Verify now' : 'Thibitisha sasa', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            height: 42,
            child: OutlinedButton.icon(
              onPressed: () => _open(const ProviderDocumentsScreen()),
              icon: const Icon(Icons.upload_file_rounded, size: 18, color: AppColors.warningDark),
              label: Text(isEn ? 'Upload documents' : 'Pakia nyaraka',
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.warningDark)),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppColors.warningDark),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  static const _socialMeta = <String, ({IconData icon, Color color, String en, String sw, String hint})>{
    'whatsapp': (icon: FontAwesomeIcons.whatsapp, color: Color(0xFF25D366), en: 'WhatsApp', sw: 'WhatsApp', hint: '+255 7XX XXX XXX'),
    'instagram': (icon: FontAwesomeIcons.instagram, color: Color(0xFFDD2A7B), en: 'Instagram', sw: 'Instagram', hint: '@username'),
    'facebook': (icon: FontAwesomeIcons.facebookF, color: Color(0xFF1877F2), en: 'Facebook', sw: 'Facebook', hint: 'username'),
    'x': (icon: FontAwesomeIcons.xTwitter, color: Colors.black, en: 'X', sw: 'X', hint: '@username'),
    'tiktok': (icon: FontAwesomeIcons.tiktok, color: Colors.black, en: 'TikTok', sw: 'TikTok', hint: '@username'),
    'youtube': (icon: FontAwesomeIcons.youtube, color: Color(0xFFFF0000), en: 'YouTube', sw: 'YouTube', hint: '@channel'),
  };

  /// Same rules as the server (PUT /users/me/socials): up to 100 characters, no spaces (WhatsApp may have them),
  /// a leading @ is dropped. Returns the cleaned text, or null when the link is not acceptable.
  static String? _cleanSocial(String key, String raw) {
    var v = raw.trim();
    if (v.startsWith('@')) v = v.substring(1).trim();
    if (v.length > 100) return null;
    if (key != 'whatsapp' && RegExp(r'\s').hasMatch(v)) return null;
    return v;
  }

  Future<void> _editSocials() async {
    final isEn = AppStrings.isEnglish;
    final ctrls = {for (final k in SessionManager.socialKeys) k: TextEditingController(text: SessionManager.getSocial(k))};
    final errors = <String, String?>{};
    String? formError;
    bool saving = false;
    // The page stays open until the server accepted the links, so a refusal never costs the user what they typed.
    await AppPage.show<bool>(
      context,
      title: isEn ? 'Social links' : 'Mitandao ya kijamii',
      subtitle: isEn ? 'Shown on your profile while it is Unlocked.' : 'Huonekana kwenye wasifu wako ukiwa wazi.',
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => Column(
          children: [
            for (final k in SessionManager.socialKeys) ...[
              AppTextField(
                controller: ctrls[k]!,
                icon: _socialMeta[k]!.icon,
                hint: '${_socialMeta[k]!.en} (${k == 'whatsapp' ? '${CurrencyService.current.plusDial} 7XX XXX XXX' : _socialMeta[k]!.hint})',
                errorText: errors[k],
                onChanged: (_) {
                  if (errors[k] != null || formError != null) {
                    setD(() {
                      errors[k] = null;
                      formError = null;
                    });
                  }
                },
              ),
              const SizedBox(height: 10),
            ],
            if (formError != null) ...[
              Text(formError!, style: const TextStyle(fontSize: 12.5, color: AppColors.danger)),
              const SizedBox(height: 8),
            ],
            const SizedBox(height: 6),
            AppButton.primary(
              label: isEn ? 'Save' : 'Hifadhi',
              loading: saving,
              onPressed: () async {
                final values = <String, String>{};
                var bad = false;
                for (final k in SessionManager.socialKeys) {
                  final cleaned = _cleanSocial(k, ctrls[k]!.text);
                  if (cleaned == null) {
                    errors[k] = isEn ? 'Use the username only, no spaces' : 'Tumia jina la mtumiaji tu, bila nafasi';
                    bad = true;
                  } else {
                    errors[k] = null;
                    values[k] = cleaned;
                  }
                }
                if (bad) {
                  setD(() {});
                  return;
                }
                setD(() {
                  saving = true;
                  formError = null;
                });
                // Server first: it is the one that shows these links to the public, so this phone keeps them only once saved there.
                final ok = await ApiService.saveSocials(values);
                if (!ctx.mounted) return;
                if (!ok) {
                  setD(() {
                    saving = false;
                    formError = ApiService.lastProfileError ??
                        (isEn
                            ? 'Could not save your social links. Check your connection and try again.'
                            : 'Imeshindwa kuhifadhi mitandao yako. Angalia mtandao kisha jaribu tena.');
                  });
                  return;
                }
                final stored = ApiService.lastSavedSocials ?? values;
                for (final k in SessionManager.socialKeys) {
                  await SessionManager.saveSocial(k, stored[k] ?? values[k]!);
                }
                if (ctx.mounted) Navigator.pop(ctx, true);
              },
            ),
          ],
        ),
      ),
    );
    for (final c in ctrls.values) {
      c.dispose();
    }
    if (mounted) setState(() {});
  }

  /// The provider's own services the app already knows about (same data customers see).
  List<ServiceItem> get _myServices {
    // Once the server has answered, its list is the truth (a deleted service must not keep counting).
    if (_mineLoaded) return List.of(_loadedMine);
    final me = SessionManager.getUserIdValue();
    final byId = <String, ServiceItem>{
      for (final x in ApiService.knownServices.values)
        if (x.sellerId != null && x.sellerId == me) x.id: x,
    };
    for (final x in _loadedMine) {
      byId.putIfAbsent(x.id, () => x);
    }
    return byId.values.toList();
  }

  /// Own services fetched from the server, so the stats card does not depend on the Home feed.
  List<ServiceItem> _loadedMine = [];
  bool _mineLoaded = false;

  Future<void> _loadMyServices() async {
    if (!SessionManager.isLoggedIn() || !SessionManager.isSeller()) return;
    final items = await ApiService.fetchMyServiceItems();
    if (!mounted) return;
    // An empty answer is real too: the provider may have deleted their last service.
    setState(() {
      _loadedMine = items;
      _mineLoaded = true;
    });
  }

  Widget _statCell(String value, String label, {IconData? icon, Color? iconColor}) {
    return Expanded(
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (icon != null) ...[Icon(icon, size: 16, color: iconColor), const SizedBox(width: 3)],
              Flexible(
                child: Text(value,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
              ),
            ],
          ),
          const SizedBox(height: 2),
          Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
        ],
      ),
    );
  }

  /// Rating, jobs done, services and earned badges. Nothing is shown when the app has no
  /// services of this provider yet, and nothing is invented.
  Widget _sellerStatsCard() {
    final mine = _myServices;
    if (mine.isEmpty) return const SizedBox.shrink();
    final isEn = AppStrings.isEnglish;

    // Rating across all services, weighted by how many reviews each one has.
    var reviews = 0;
    var weighted = 0.0;
    for (final x in mine) {
      if (x.hasReviews) {
        reviews += x.reviewsCount;
        weighted += x.rating * x.reviewsCount;
      }
    }
    final rating = reviews > 0 ? weighted / reviews : 0.0;
    final jobs = mine.map((x) => x.completedJobs ?? 0).fold<int>(0, (a, b) => a > b ? a : b);

    final serverBadges = <String>[];
    for (final x in mine) {
      for (final b in x.badges) {
        if (!serverBadges.any((e) => e.toUpperCase() == b.toUpperCase())) serverBadges.add(b);
      }
    }
    final badges = ServiceBadgeRules.earned(rating: rating, reviewsCount: reviews, fromServer: serverBadges);

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _statCell(
                reviews > 0 ? rating.toStringAsFixed(1) : (isEn ? 'New' : 'Mpya'),
                reviews > 0 ? (isEn ? '$reviews reviews' : 'Maoni $reviews') : (isEn ? 'Rating' : 'Ukadiriaji'),
                icon: Icons.star_rounded,
                iconColor: AppColors.goldStar,
              ),
              _statCell('$jobs', isEn ? 'Jobs done' : 'Kazi zilizokamilika'),
              _statCell('${mine.length}', isEn ? (mine.length == 1 ? 'Service' : 'Services') : 'Huduma'),
            ],
          ),
          const SizedBox(height: 12),
          const Divider(height: 1, color: AppColors.borderLight),
          const SizedBox(height: 12),
          Text(isEn ? 'Badges you earned' : 'Beji ulizopata',
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
          const SizedBox(height: 8),
          if (badges.isEmpty)
            Text(
              isEn
                  ? 'No badges yet. They appear automatically as customers review your services.'
                  : 'Bado huna beji. Zinaonekana zenyewe wateja wanapokupa maoni.',
              style: const TextStyle(fontSize: 11, height: 1.4, color: AppColors.textSecondary),
            )
          else
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final key in badges)
                  Builder(builder: (_) {
                    final b = ServiceBadgeInfo.of(key);
                    return Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(color: b.bgColor, borderRadius: BorderRadius.circular(20)),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(b.icon, size: 14, color: b.iconColor),
                          const SizedBox(width: 5),
                          Text(b.label, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                        ],
                      ),
                    );
                  }),
              ],
            ),
        ],
      ),
    );
  }

  Widget _contactCard() {
    final isEn = AppStrings.isEnglish;
    final locked = SecuritySettings.profileLocked;
    final phone = SessionManager.getPhone().trim();
    final socials = [
      for (final k in SessionManager.socialKeys)
        if (SessionManager.getSocial(k).isNotEmpty) k,
    ];

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(locked ? Icons.lock_outline_rounded : Icons.lock_open_rounded,
                  size: 20, color: locked ? AppColors.textSecondary : AppColors.primary),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  isEn ? 'Contact & Socials' : 'Mawasiliano na Mitandao',
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                ),
              ),
              StatusPill(
                text: locked ? (isEn ? 'Locked' : 'Imefungwa') : (isEn ? 'Unlocked' : 'Iko wazi'),
                color: locked ? AppColors.textSecondary : AppColors.successDark,
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (locked) ...[
            Text(
              isEn
                  ? 'Your phone number and social links are hidden. Unlock your profile in Settings to show them.'
                  : 'Namba yako ya simu na mitandao vimefichwa. Fungua wasifu kwenye Mipangilio ili vionekane.',
              style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textSecondary),
            ),
            const SizedBox(height: 8),
            TextButton(
              onPressed: () => _open(const SettingsSecurityScreen()),
              style: TextButton.styleFrom(padding: EdgeInsets.zero, minimumSize: const Size(0, 30)),
              child: Text(isEn ? 'Open Settings' : 'Fungua Mipangilio', style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
          ] else ...[
            InkWell(
              onTap: _addPhone,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  children: [
                    const Icon(Icons.phone_outlined, size: 18, color: AppColors.textPrimary),
                    const SizedBox(width: 10),
                    Text(
                      phone.isEmpty ? (isEn ? 'Add phone number' : 'Weka namba ya simu') : phone,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: phone.isEmpty ? AppColors.primary : AppColors.textPrimary,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 6),
            if (socials.isEmpty)
              Text(
                isEn ? 'No social links added yet.' : 'Bado hujaweka mitandao ya kijamii.',
                style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
              )
            else
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final k in socials)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: _socialMeta[k]!.color.withValues(alpha: 0.08),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          FaIcon(_socialMeta[k]!.icon, size: 13, color: _socialMeta[k]!.color),
                          const SizedBox(width: 6),
                          Text(
                            SessionManager.getSocial(k),
                            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            const SizedBox(height: 6),
            TextButton(
              onPressed: _editSocials,
              style: TextButton.styleFrom(padding: EdgeInsets.zero, minimumSize: const Size(0, 30)),
              child: Text(isEn ? 'Edit social links' : 'Hariri mitandao', style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
          ],
        ],
      ),
    );
  }

  /// Three-dot menu in the profile header (replaces the old Sign Out button).
  Widget _profileMenu() {
    final isEn = AppStrings.isEnglish;
    PopupMenuItem<String> item(String value, IconData icon, String label, {Color? color}) {
      return PopupMenuItem<String>(
        value: value,
        child: Row(
          children: [
            Icon(icon, size: 20, color: color ?? AppColors.textSecondary),
            const SizedBox(width: 12),
            Text(label, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: color ?? AppColors.textPrimary)),
          ],
        ),
      );
    }

    return PopupMenuButton<String>(
      tooltip: isEn ? 'More options' : 'Chaguo zaidi',
      icon: const Icon(Icons.more_vert_rounded, color: Colors.white),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      onSelected: _onMenuSelected,
      itemBuilder: (_) => [
        item('edit', Icons.edit_outlined, isEn ? 'Edit profile' : 'Hariri wasifu'),
        item('language', Icons.language_rounded, AppStrings.profileLanguageTitle),
        item('settings', Icons.security_outlined, isEn ? 'Settings & Security' : 'Mipangilio na Usalama'),
        item('help', Icons.help_outline_rounded, AppStrings.profileHelpTitle),
        const PopupMenuDivider(),
        item('signout', Icons.logout_rounded, AppStrings.profileSignOutAction, color: AppColors.danger),
        if (SessionManager.isLoggedIn())
          item('delete', Icons.delete_forever_outlined, isEn ? 'Delete account' : 'Futa akaunti', color: AppColors.danger),
      ],
    );
  }

  void _onMenuSelected(String value) {
    switch (value) {
      case 'edit':
        _showEditProfileSheet();
        break;
      case 'language':
        _showLanguageSelector();
        break;
      case 'settings':
        _open(const SettingsSecurityScreen());
        break;
      case 'help':
        _open(const HelpSupportScreen());
        break;
      case 'signout':
        _confirmSignOut();
        break;
      case 'delete':
        _open(const DeleteAccountScreen());
        break;
    }
  }

  /// Asks the server first; the new value is only kept on this phone once the server accepted it.
  Future<void> _changeName() async {
    final isEn = AppStrings.isEnglish;
    final current = SessionManager.getStageName();
    final ctrl = TextEditingController(text: current == 'Guest User' ? '' : current);
    String? error;
    bool saving = false;
    await AppPage.show<void>(
      context,
      title: isEn ? 'Name' : 'Jina',
      subtitle: isEn ? 'The name other people see on your profile.' : 'Jina wanalolona watu wengine kwenye wasifu wako.',
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => Column(
          children: [
            AppTextField(
              controller: ctrl,
              icon: Icons.person_outline_rounded,
              hint: isEn ? 'Your name' : 'Jina lako',
              errorText: error,
              onChanged: (_) {
                if (error != null) setD(() => error = null);
              },
            ),
            const SizedBox(height: 20),
            AppButton.primary(
              label: isEn ? 'Save' : 'Hifadhi',
              loading: saving,
              onPressed: () async {
                final value = ctrl.text.trim().replaceAll(RegExp(r'\s+'), ' ');
                if (value.length < 2 || value.length > 40) {
                  setD(() => error = isEn ? 'Use 2 to 40 characters' : 'Tumia herufi 2 hadi 40');
                  return;
                }
                if (value == current) {
                  Navigator.pop(ctx);
                  return;
                }
                setD(() => saving = true);
                final ok = await ApiService.updateProfile(stageName: value);
                if (!ctx.mounted) return;
                if (!ok) {
                  setD(() {
                    saving = false;
                    error = ApiService.lastProfileError ?? (isEn ? 'Could not change your name. Try again.' : 'Imeshindwa kubadilisha jina. Jaribu tena.');
                  });
                  return;
                }
                await SessionManager.saveStageName(value);
                if (ctx.mounted) Navigator.pop(ctx);
              },
            ),
          ],
        ),
      ),
    );
    ctrl.dispose();
    if (mounted) setState(() {});
  }

  Future<void> _changeEmail() => _changeContact(isPhone: false);

  /// Phone and email are what the account was registered with, so a change is confirmed with a code
  /// sent to the NEW phone / email. Nothing changes here until the server accepts the code.
  Future<void> _changeContact({required bool isPhone}) async {
    final isEn = AppStrings.isEnglish;
    final current = isPhone ? SessionManager.getPhone() : SessionManager.getEmail();
    final valueCtrl = TextEditingController();
    final codeCtrl = TextEditingController();
    String? error;
    bool codeSent = false;
    bool busy = false;
    String target = '';
    // Same country-code chip as every phone field; the number is sent as +<code><number>.
    String dial = CountryDial.fromInternational('+${current.replaceAll(RegExp(r'\D'), '')}')?.dial ?? CurrencyService.current.plusDial;
    String intl(String v) =>
        InputValidation.toInternational(v, dial, otherDials: CountryDial.all.map((c) => c.dial));

    String? validate(String v) {
      if (isPhone) {
        return v.replaceAll(RegExp(r'[^0-9]'), '').length < 9 ? (isEn ? 'Enter a valid phone number' : 'Weka namba sahihi ya simu') : null;
      }
      return RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]{2,}$').hasMatch(v) ? null : (isEn ? 'Enter a valid email address' : 'Weka barua pepe sahihi');
    }

    await AppPage.show<void>(
      context,
      title: isPhone ? (isEn ? 'Phone number' : 'Namba ya simu') : (isEn ? 'Email' : 'Barua pepe'),
      subtitle: isPhone
          ? (isEn ? 'The number you registered with. To change it, we send a code to the new number.' : 'Namba uliyosajili nayo. Kuibadilisha, tunatuma msimbo kwenye namba mpya.')
          : (isEn ? 'The email you registered with. To change it, we send a code to the new email.' : 'Barua pepe uliyosajili nayo. Kuibadilisha, tunatuma msimbo kwenye barua pepe mpya.'),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) {
          Future<void> sendCode() async {
            final v = isPhone ? intl(valueCtrl.text) : valueCtrl.text.trim();
            final err = validate(v);
            if (err != null) {
              setD(() => error = err);
              return;
            }
            if (v.replaceAll(RegExp(r'\D'), '') == current.replaceAll(RegExp(r'\D'), '')) {
              Navigator.pop(ctx);
              return;
            }
            setD(() {
              busy = true;
              error = null;
            });
            final ok = await ApiService.requestContactChange(isPhone: isPhone, value: v);
            if (!ctx.mounted) return;
            setD(() {
              busy = false;
              if (ok) {
                codeSent = true;
                target = v;
              } else {
                error = ApiService.lastProfileError ?? (isEn ? 'Could not send the code. Try again.' : 'Imeshindwa kutuma msimbo. Jaribu tena.');
              }
            });
          }

          Future<void> confirm() async {
            final otp = codeCtrl.text.trim();
            if (otp.length != 6) {
              setD(() => error = isEn ? 'Enter the 6-digit code' : 'Weka msimbo wa tarakimu 6');
              return;
            }
            setD(() {
              busy = true;
              error = null;
            });
            final ok = await ApiService.confirmContactChange(isPhone: isPhone, value: target, otp: otp);
            if (!ctx.mounted) return;
            if (!ok) {
              setD(() {
                busy = false;
                error = ApiService.lastProfileError ?? (isEn ? 'Wrong or expired code. Try again.' : 'Msimbo si sahihi au umeisha muda. Jaribu tena.');
              });
              return;
            }
            if (isPhone) {
              await SessionManager.savePhone(target);
              // The only way a signed-in account's currency changes: the new number belongs to
              // another supported country. The server must accept it before the app switches.
              final newCur = CurrencyService.fromPhone(target);
              if (newCur != null && newCur.iso != CurrencyService.current.iso) {
                if (await ApiService.updateAccountCurrency(newCur.iso)) {
                  await CurrencyService.setAccountCurrency(newCur.iso);
                  await LocationService.chooseCountry(newCur.iso);
                }
              }
            } else {
              await SessionManager.saveEmail(target);
            }
            if (ctx.mounted) Navigator.pop(ctx);
          }

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                isEn ? 'Current' : 'Ya sasa',
                style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
              ),
              const SizedBox(height: 2),
              Text(
                current.isEmpty ? (isEn ? 'Not added' : 'Haijawekwa') : current,
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
              ),
              const SizedBox(height: 16),
              if (!codeSent) ...[
                AppTextField(
                  controller: valueCtrl,
                  icon: isPhone ? Icons.phone_outlined : Icons.mail_outline_rounded,
                  keyboardType: isPhone ? TextInputType.phone : TextInputType.emailAddress,
                  hint: isPhone ? '7XX XXX XXX' : 'name@example.com',
                  prefix: isPhone
                      ? CountryCodePicker(
                          value: dial,
                          enabled: !busy,
                          showIcon: false,
                          onChanged: (code) => setD(() {
                            dial = code;
                            error = null;
                          }),
                        )
                      : null,
                  errorText: error,
                  onChanged: (_) {
                    if (error != null) setD(() => error = null);
                  },
                ),
                const SizedBox(height: 20),
                AppButton.primary(
                  label: isEn ? 'Send code' : 'Tuma msimbo',
                  loading: busy,
                  onPressed: sendCode,
                ),
              ] else ...[
                Text(
                  isEn ? 'We sent a 6-digit code to $target.' : 'Tumetuma msimbo wa tarakimu 6 kwenda $target.',
                  style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
                ),
                const SizedBox(height: 12),
                AppTextField(
                  controller: codeCtrl,
                  icon: Icons.lock_outline_rounded,
                  keyboardType: TextInputType.number,
                  hint: '123456',
                  errorText: error,
                  onChanged: (_) {
                    if (error != null) setD(() => error = null);
                  },
                ),
                const SizedBox(height: 20),
                AppButton.primary(
                  label: isEn ? 'Confirm' : 'Thibitisha',
                  loading: busy,
                  onPressed: confirm,
                ),
                const SizedBox(height: 8),
                TextButton(
                  onPressed: busy
                      ? null
                      : () => setD(() {
                            codeSent = false;
                            codeCtrl.clear();
                            error = null;
                          }),
                  child: Text(isEn ? 'Use a different one' : 'Tumia nyingine'),
                ),
              ],
            ],
          );
        },
      ),
    );
    valueCtrl.dispose();
    codeCtrl.dispose();
    if (mounted) setState(() {});
  }

  /// Everything a person can change about their own profile, in one place.
  void _showEditProfileSheet() {
    final isEn = AppStrings.isEnglish;
    Widget row(IconData icon, String title, VoidCallback onTap, {String? current}) {
      return ListTile(
        leading: Icon(icon, color: AppColors.primary),
        title: Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        subtitle: current == null
            ? null
            : Text(
                current,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
              ),
        trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.textSecondary),
        onTap: () {
          Navigator.pop(context);
          onTap();
        },
      );
    }

    AppPage.show<void>(
      context,
      title: isEn ? 'Edit profile' : 'Hariri wasifu',
      builder: (_) => Column(
        children: [
          row(Icons.photo_camera_outlined, isEn ? 'Change profile photo' : 'Badilisha picha ya wasifu', _changeAvatar),
          if (SessionManager.isSeller()) ...[
            row(Icons.panorama_outlined, isEn ? 'Cover photo' : 'Picha ya jalada', _coverOptions,
                current: SessionManager.getCoverUrl().isEmpty ? (isEn ? 'Not added' : 'Haijawekwa') : (isEn ? 'Added' : 'Imewekwa')),
            row(Icons.notes_rounded, isEn ? 'About me' : 'Kuhusu mimi', _changeBio,
                current: SessionManager.getBio().isEmpty ? (isEn ? 'Not added' : 'Haijawekwa') : SessionManager.getBio()),
          ],
          row(Icons.person_outline_rounded, isEn ? 'Name' : 'Jina', _changeName,
              current: SessionManager.getStageName()),
          row(Icons.phone_outlined, isEn ? 'Phone number' : 'Namba ya simu', _addPhone,
              current: SessionManager.getPhone().isEmpty ? (isEn ? 'Not added' : 'Haijawekwa') : SessionManager.getPhone()),
          row(Icons.mail_outline_rounded, isEn ? 'Email' : 'Barua pepe', _changeEmail,
              current: SessionManager.getEmail().isEmpty ? (isEn ? 'Not added' : 'Haijawekwa') : SessionManager.getEmail()),
          row(Icons.location_city_outlined, isEn ? 'City' : 'Mji', () => LocationPickerSheet.show(context)),
          row(Icons.alternate_email_rounded, isEn ? 'Social links' : 'Mitandao ya kijamii', _editSocials),
        ],
      ),
    );
  }

  /// Cover photo: the wide picture on top of the public provider profile.
  Future<void> _changeCover([ImageSource? source]) async {
    if (_uploadingCover) return;
    final isEn = AppStrings.isEnglish;
    final messenger = ScaffoldMessenger.of(context);
    final file = await MediaPicker.pickImage(
      context,
      title: isEn ? 'Cover photo' : 'Picha ya jalada',
      subtitle: isEn ? 'A wide photo works best.' : 'Picha pana inapendeza zaidi.',
      maxWidth: 1800,
      source: source,
    );
    if (file == null || !mounted) return;
    setState(() => _uploadingCover = true);
    final res = await ApiService.uploadCover(file.path);
    if (!mounted) return;
    setState(() => _uploadingCover = false);
    messenger.showSnackBar(SnackBar(
      backgroundColor: res.ok ? AppColors.success : AppColors.danger,
      content: Text(res.ok
          ? (isEn ? 'Cover photo updated.' : 'Picha ya jalada imesasishwa.')
          : (res.error ?? (isEn ? 'Could not upload the photo.' : 'Imeshindwa kupakia picha.'))),
    ));
  }

  Future<void> _removeCover() async {
    final isEn = AppStrings.isEnglish;
    final messenger = ScaffoldMessenger.of(context);
    final ok = await ApiService.removeCover();
    if (!mounted) return;
    messenger.showSnackBar(SnackBar(
      backgroundColor: ok ? AppColors.success : AppColors.danger,
      content: Text(ok
          ? (isEn ? 'Cover photo removed.' : 'Picha ya jalada imeondolewa.')
          : (isEn ? 'Could not remove the photo.' : 'Imeshindwa kuondoa picha.')),
    ));
  }

  /// Change / remove sheet for the cover photo.
  void _coverOptions() {
    final isEn = AppStrings.isEnglish;
    final hasCover = SessionManager.getCoverUrl().isNotEmpty;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (hasCover)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: AspectRatio(
                    aspectRatio: 16 / 7,
                    child: AppImage(SessionManager.getCoverUrl(), fit: BoxFit.cover, errorBuilder: (_, _, _) => const SizedBox.shrink()),
                  ),
                ),
              ),
            ListTile(
              leading: const Icon(Icons.photo_library_outlined, color: AppColors.primary),
              title: Text(hasCover ? (isEn ? 'Change cover photo' : 'Badilisha picha ya jalada') : (isEn ? 'Upload cover photo' : 'Pakia picha ya jalada')),
              onTap: () {
                Navigator.pop(ctx);
                _changeCover();
              },
            ),
            if (hasCover)
              ListTile(
                leading: const Icon(Icons.delete_outline_rounded, color: AppColors.danger),
                title: Text(isEn ? 'Remove cover photo' : 'Ondoa picha ya jalada', style: const TextStyle(color: AppColors.danger)),
                onTap: () {
                  Navigator.pop(ctx);
                  _removeCover();
                },
              ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  /// "About me": the text customers read on the public profile.
  Future<void> _changeBio() async {
    final isEn = AppStrings.isEnglish;
    final current = SessionManager.getBio();
    final ctrl = TextEditingController(text: current);
    String? error;
    bool saving = false;
    await AppPage.show<void>(
      context,
      title: isEn ? 'About me' : 'Kuhusu mimi',
      subtitle: isEn ? 'Tell customers who you are and what you do best.' : 'Waambie wateja wewe ni nani na unafanya nini vizuri zaidi.',
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => Column(
          children: [
            AppTextField(
              controller: ctrl,
              icon: Icons.notes_rounded,
              hint: isEn ? 'Write a short introduction' : 'Andika utangulizi mfupi',
              maxLines: 6,
              maxLength: 500,
              errorText: error,
              onChanged: (_) {
                if (error != null) setD(() => error = null);
              },
            ),
            const SizedBox(height: 16),
            AppButton.primary(
              label: isEn ? 'Save' : 'Hifadhi',
              loading: saving,
              onPressed: () async {
                final value = ctrl.text.trim();
                if (value == current) {
                  Navigator.pop(ctx);
                  return;
                }
                setD(() => saving = true);
                final ok = await ApiService.updateProfile(bio: value);
                if (!ctx.mounted) return;
                if (!ok) {
                  setD(() {
                    saving = false;
                    error = ApiService.lastProfileError ?? (isEn ? 'Could not save. Try again.' : 'Imeshindwa kuhifadhi. Jaribu tena.');
                  });
                  return;
                }
                await SessionManager.saveBio(value);
                if (ctx.mounted) Navigator.pop(ctx);
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _confirmSignOut() async {
    final isEn = AppStrings.isEnglish;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(AppStrings.profileSignOutAction),
        content: Text(isEn ? 'Are you sure you want to sign out?' : 'Una uhakika unataka kuondoka kwenye akaunti yako?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(isEn ? 'Cancel' : 'Ghairi')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(AppStrings.profileSignOutAction, style: const TextStyle(color: AppColors.danger)),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    await SessionManager.clearSession();
    if (mounted) setState(() {});
  }

  void _showLanguageSelector() {
    LanguageSelectorSheet.show(context);
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppLanguage>(
      valueListenable: AppStrings.currentLanguage,
      builder: (context, _, _) {
        final isLoggedIn = SessionManager.isLoggedIn();
        final stageName = SessionManager.getStageName();
        // Profile content depends on who is using the app.
        final isSeller = isLoggedIn && SessionManager.isSeller();
        final isBuyer = isLoggedIn && !isSeller;
        // Verification badges belong to providers only.
        final badge = isSeller ? SessionManager.getBadge() : 'NONE';
        final hasBlueTick = badge == 'BLUE_TICK';
        final hasGreenBadge = badge == 'GREEN_BADGE';

        return Scaffold(
          backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        title: Text(
          AppStrings.profileTitle,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.border, height: 1),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Header: cover, overlapping avatar, name, role and status (legal NIDA name stays private).
            Container(
              color: AppColors.surface,
              padding: const EdgeInsets.only(bottom: 16),
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  ClipRect(
                    child: Container(
                      height: 96,
                      width: double.infinity,
                      color: AppColors.primaryDark,
                      child: Stack(
                        children: [
                          if (isLoggedIn && SessionManager.getCoverUrl().isNotEmpty)
                            Positioned.fill(
                              child: AppImage(
                                SessionManager.getCoverUrl(),
                                fit: BoxFit.cover,
                                errorBuilder: (_, _, _) => const SizedBox.shrink(),
                              ),
                            )
                          else ...[
                          Positioned(
                            right: -50,
                            top: -70,
                            child: Container(
                              width: 190,
                              height: 190,
                              decoration: const BoxDecoration(shape: BoxShape.circle, color: AppColors.primary),
                            ),
                          ),
                          Positioned(
                            left: -40,
                            bottom: -80,
                            child: Container(
                              width: 150,
                              height: 150,
                              decoration: BoxDecoration(shape: BoxShape.circle, color: AppColors.primary.withValues(alpha: 0.5)),
                            ),
                          ),
                          ],
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 54, 12, 0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _avatar(isLoggedIn: isLoggedIn, stageName: stageName, size: 84),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const SizedBox(height: 46),
                              Row(
                                children: [
                                  Flexible(
                                    child: Text(
                                      isLoggedIn ? stageName : AppStrings.profileGuestTitle,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: -0.3, color: AppColors.textPrimary),
                                    ),
                                  ),
                                  if (hasBlueTick || hasGreenBadge) ...[
                                    const SizedBox(width: 5),
                                    Icon(Icons.verified_rounded, size: 18, color: hasBlueTick ? AppColors.primary : AppColors.success),
                                  ],
                                ],
                              ),
                              const SizedBox(height: 2),
                              Text(
                                isLoggedIn
                                    ? (isSeller
                                        ? (AppStrings.isEnglish ? 'Service provider' : 'Mtoa Huduma')
                                        : (AppStrings.isEnglish ? 'Customer / Buyer' : 'Mteja / Mnunuzi'))
                                    : AppStrings.profileGuestSubtitle,
                                style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: AppColors.primary),
                              ),
                              if (isLoggedIn) ...[
                                const SizedBox(height: 2),
                                Text(
                                  [
                                    if (!SecuritySettings.profileLocked && SessionManager.getPhone().trim().isNotEmpty)
                                      SessionManager.getPhone().trim(),
                                    if (SessionManager.hasUserCity()) SessionManager.getUserCity(),
                                  ].join('  •  '),
                                  style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                                ),
                              ],
                              const SizedBox(height: 8),
                              // Verified providers already have the tick beside their name,
                              // so the status pill is only shown while unverified.
                              if (isSeller && !hasBlueTick && !hasGreenBadge)
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: AppColors.warningLight,
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      const Icon(Icons.info_outline_rounded, size: 13, color: AppColors.warningDark),
                                      const SizedBox(width: 4),
                                      Text(
                                        AppStrings.badgeUnverified,
                                        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.warningDark),
                                      ),
                                    ],
                                  ),
                                ),
                            ],
                          ),
                        ),
                        if (!isLoggedIn)
                          Padding(
                            padding: const EdgeInsets.only(top: 52),
                            child: OutlinedButton(
                              onPressed: () async {
                                await LoginModal.show(context);
                                await _refreshProfile();
                              },
                              style: OutlinedButton.styleFrom(
                                side: const BorderSide(color: AppColors.primary),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              ),
                              child: Text(
                                AppStrings.profileSignInAction,
                                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.primary),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                  if (isLoggedIn)
                    Positioned(top: 6, right: 4, child: _profileMenu()),
                ],
              ),
            ),
            // Providers who have not paid the one-time fee yet.
            if (isSeller && SessionManager.getRegFeePaid() == false) _feeBanner(),
            // Unverified providers are sent to the verification page.
            if (isSeller && !hasBlueTick && !hasGreenBadge) _unverifiedBanner(),
            // Missing profile data (phone, city, verification, first service / favorite).
            if (isLoggedIn) ProfileCompletionCard(tasks: _tasks(isSeller: isSeller)),
            // Contact + socials: shown only while the profile is Unlocked (Settings).
            if (isLoggedIn) _contactCard(),
            // Provider only: rating, jobs done, services and earned badges (same numbers customers see).
            if (isSeller) _sellerStatsCard(),
            if (isLoggedIn) _quickActions(isSeller: isSeller),
            const SizedBox(height: 12),

            // GUEST: favorites (saved on this device) + sign-in
            if (!isLoggedIn)
              _section([
                _buildProfileOption(
                  icon: Icons.favorite_border_rounded,
                  title: AppStrings.profileFavoritesTitle,
                  subtitle: AppStrings.profileFavoritesSubtitle,
                  trailingBadge: SessionManager.getFavoriteIds().isEmpty ? null : '${SessionManager.getFavoriteIds().length}',
                  onTap: () => _open(const FavoritesScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.login_rounded,
                  title: AppStrings.profileSignInAction,
                  subtitle: AppStrings.profileGuestSubtitle,
                  trailingBadge: AppStrings.isEnglish ? 'Free' : 'Bure',
                  badgeColor: AppColors.primary,
                  onTap: () async {
                    await LoginModal.show(context);
                    await _refreshProfile();
                  },
                ),
              ]),

            // MY ACTIVITY (all signed-in users)
            if (isLoggedIn)
              _section([
                _buildProfileOption(
                  icon: Icons.favorite_border_rounded,
                  title: AppStrings.profileFavoritesTitle,
                  subtitle: AppStrings.profileFavoritesSubtitle,
                  trailingBadge: SessionManager.getFavoriteIds().isEmpty ? null : '${SessionManager.getFavoriteIds().length}',
                  onTap: () => _open(const FavoritesScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.receipt_long_outlined,
                  title: AppStrings.isEnglish ? (isSeller ? 'Requests & Bookings' : 'My Requests') : (isSeller ? 'Maombi na Oda' : 'Maombi Yangu'),
                  subtitle: AppStrings.isEnglish ? 'Track your bookings' : 'Fuatilia oda zako',
                  onTap: () => _open(const RequestsScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.payments_outlined,
                  title: AppStrings.isEnglish ? 'Payments' : 'Malipo',
                  subtitle: AppStrings.isEnglish
                      ? (isSeller ? 'Payments from your customers' : 'Your payment history')
                      : (isSeller ? 'Malipo kutoka kwa wateja wako' : 'Historia ya malipo yako'),
                  onTap: () => _open(const PaymentsScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.star_outline_rounded,
                  title: AppStrings.isEnglish ? 'Reviews' : 'Maoni',
                  subtitle: AppStrings.isEnglish
                      ? (isSeller ? 'Rate customers and see your reviews' : 'Rate providers and see your reviews')
                      : (isSeller ? 'Pima wateja na uone maoni yako' : 'Pima watoa huduma na uone maoni yako'),
                  onTap: () => _open(const MyReviewsScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.block_rounded,
                  title: AppStrings.isEnglish ? 'Blocked Users' : 'Watumiaji Walizuiwa',
                  subtitle: AppStrings.isEnglish ? 'Manage people you blocked' : 'Simamia watu uliowazuia',
                  trailingBadge: BlockService.count == 0 ? null : '${BlockService.count}',
                  onTap: () => _open(const BlockedUsersScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.face_retouching_natural,
                  title: AppStrings.isEnglish ? 'Verify photo' : 'Thibitisha picha',
                  subtitle: AppStrings.isEnglish
                      ? 'Shown to providers on your requests when Hide My ID is off'
                      : 'Huonyeshwa kwa watoa huduma kwenye maombi yako Ficha Utambulisho kikizimwa',
                  trailingBadge: VerifyPhotoScreen.statusLabel(AppStrings.isEnglish) ?? (AppStrings.isEnglish ? 'Not verified' : 'Bado'),
                  badgeColor: SessionManager.getVerifiedPhotoStatus() == 'VERIFIED' ? AppColors.success : AppColors.warning,
                  onTap: () => _open(const VerifyPhotoScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.badge_outlined,
                  title: AppStrings.isEnglish ? 'Verify My Legal Name' : 'Thibitisha Jina Langu la Kisheria',
                  subtitle: AppStrings.isEnglish
                      ? 'Your name from your ID, shown when Hide My ID is off'
                      : 'Jina lako kutoka kitambulisho, huonyeshwa Ficha Utambulisho kikizimwa',
                  trailingBadge: VerifyNameScreen.statusLabel(AppStrings.isEnglish) ?? (AppStrings.isEnglish ? 'Not verified' : 'Bado'),
                  badgeColor: SessionManager.getVerifiedNameStatus() == 'VERIFIED' ? AppColors.success : AppColors.warning,
                  onTap: () => _open(const VerifyNameScreen()),
                ),
              ]),

            // PROVIDER business tools
            if (isSeller) ...[
              const SizedBox(height: 12),
              _section([
                _buildProfileOption(
                  icon: Icons.bar_chart_rounded,
                  title: AppStrings.isEnglish ? 'Earnings' : 'Mapato',
                  subtitle: AppStrings.isEnglish ? 'Completed bookings and payments' : 'Oda zilizokamilika na malipo',
                  onTap: () => _open(const SellerEarningsScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.verified_user_outlined,
                  title: AppStrings.profileNidaTitle,
                  subtitle: AppStrings.profileNidaSubtitle,
                  trailingBadge: hasGreenBadge ? 'Green Badge' : (hasBlueTick ? 'Green + Blue' : (AppStrings.isEnglish ? 'Not verified' : 'Bado')),
                  badgeColor: (hasBlueTick || hasGreenBadge) ? AppColors.success : AppColors.warning,
                  onTap: () => _open(const NidaVerificationScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.business_center_outlined,
                  title: AppStrings.isEnglish ? 'Verified Business' : 'Biashara Iliyothibitishwa',
                  subtitle: AppStrings.isEnglish ? 'TIN, business licence and other business papers' : 'TIN, leseni na nyaraka nyingine za biashara',
                  trailingBadge: VerifyBusinessScreen.statusLabel(AppStrings.isEnglish) ??
                      ((hasBlueTick || hasGreenBadge) ? (AppStrings.isEnglish ? 'Not started' : 'Bado') : (AppStrings.isEnglish ? 'Needs Green Badge' : 'Inahitaji Green Badge')),
                  badgeColor: SessionManager.getVerifiedBusinessStatus() == 'VERIFIED' ? AppColors.success : AppColors.warning,
                  onTap: () => _open(const VerifyBusinessScreen()),
                ),
                if (hasBlueTick || hasGreenBadge) ...[
                  _buildDivider(),
                  _buildProfileOption(
                    icon: Icons.group_add_outlined,
                    title: AppStrings.isEnglish ? 'Invite someone you trust' : 'Alika unayemwamini',
                    subtitle: AppStrings.isEnglish ? 'Give a friend with a NIN a Green Badge' : 'Mpe rafiki mwenye NIN Green Badge',
                    onTap: () => _open(const InviteTrustedScreen()),
                  ),
                ] else ...[
                  _buildDivider(),
                  _buildProfileOption(
                    icon: Icons.mark_email_read_outlined,
                    title: AppStrings.isEnglish ? 'I have an invitation' : 'Nina mwaliko',
                    subtitle: AppStrings.isEnglish ? 'Enter the code and your NIN to get a Green Badge' : 'Weka msimbo na NIN yako upate Green Badge',
                    trailingBadge: _pendingInvites > 0 ? '$_pendingInvites' : null,
                    badgeColor: AppColors.warning,
                    onTap: () => _open(const AcceptInvitationScreen()),
                  ),
                ],
                if (!hasBlueTick && !hasGreenBadge) ...[
                  _buildDivider(),
                  _buildProfileOption(
                    icon: Icons.upload_file_rounded,
                    title: AppStrings.isEnglish ? 'Documents' : 'Nyaraka',
                    subtitle: AppStrings.isEnglish ? 'Upload your ID, selfie and certificates' : 'Pakia kitambulisho, selfie na vyeti vyako',
                    trailingBadge:
                        '${ProviderDocumentsScreen.requiredIds.where(SessionManager.getSubmittedDocs().contains).length}/${ProviderDocumentsScreen.requiredIds.length}',
                    badgeColor: AppColors.warning,
                    onTap: () => _open(const ProviderDocumentsScreen()),
                  ),
                ],
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.location_on_outlined,
                  title: AppStrings.profileLocationTitle,
                  subtitle: AppStrings.profileLocationSubtitle,
                  onTap: () => LocationServiceRadiusSheet.show(context),
                ),
              ]),
            ],

            // ADMIN (only shown to admin accounts; the server re-checks every admin call)
            if (SessionManager.isAdmin()) ...[
              const SizedBox(height: 12),
              _section([
                _buildProfileOption(
                  icon: Icons.account_balance_rounded,
                  title: AppStrings.isEnglish ? 'Payment Gateway' : 'Gateway ya Malipo',
                  subtitle: AppStrings.isEnglish ? 'Which gateway takes card and mobile money payments' : 'Gateway inayopokea malipo ya kadi na pesa za simu',
                  trailingBadge: 'Admin',
                  badgeColor: AppColors.warning,
                  onTap: () => _open(const AdminPaymentGatewayScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.sms_rounded,
                  title: AppStrings.isEnglish ? 'SMS Provider' : 'Mtoa huduma wa SMS',
                  subtitle: AppStrings.isEnglish ? 'Meseji or Beem Africa, default and credentials' : 'Meseji au Beem Africa, chaguo-msingi na taarifa',
                  trailingBadge: 'Admin',
                  badgeColor: AppColors.warning,
                  onTap: () => _open(const AdminSmsGatewayScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.timer_outlined,
                  title: AppStrings.isEnglish ? 'OTP Pending Time' : 'Muda wa OTP Kusubiri',
                  subtitle: AppStrings.isEnglish ? 'Minutes a sent code stays pending after the app is closed' : 'Dakika ambazo namba iliyotumwa inasubiri app ikifungwa',
                  trailingBadge: 'Admin',
                  badgeColor: AppColors.warning,
                  onTap: () => _open(const AdminOtpSettingsScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.notifications_active_rounded,
                  title: AppStrings.isEnglish ? 'Promo Push' : 'Arifa za Matangazo',
                  subtitle: AppStrings.isEnglish ? 'Boosted services sent to users: on/off and hours between' : 'Huduma zilizopandishwa hutumwa kwa watumiaji: washa/zima na saa kati',
                  trailingBadge: 'Admin',
                  badgeColor: AppColors.warning,
                  onTap: () => _open(const AdminPromoPushScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.badge_rounded,
                  title: AppStrings.isEnglish ? 'ID Name Check Login' : 'Taarifa za Uhakiki wa Jina',
                  subtitle: AppStrings.isEnglish ? 'Login used to verify legal names against the NIN' : 'Taarifa za kuhakiki majina ya kisheria kwa NIN',
                  trailingBadge: 'Admin',
                  badgeColor: AppColors.warning,
                  onTap: () => _open(const AdminIdentityLookupScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.campaign_rounded,
                  title: AppStrings.isEnglish ? 'Ads' : 'Matangazo',
                  subtitle: AppStrings.isEnglish ? 'AdMob, Facebook, ironSource: network per page and ad IDs' : 'AdMob, Facebook, ironSource: mtandao wa kila ukurasa na ID',
                  trailingBadge: 'Admin',
                  badgeColor: AppColors.warning,
                  onTap: () => _open(const AdminAdsScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.percent_rounded,
                  title: AppStrings.isEnglish ? 'Provider Fees' : 'Ada za Watoa Huduma',
                  subtitle: AppStrings.isEnglish ? 'VAT % and payout fee, taken at withdrawal' : 'Asilimia ya VAT na ada ya kutuma, hukatwa wakati wa kutoa',
                  trailingBadge: 'Admin',
                  badgeColor: AppColors.warning,
                  onTap: () => _open(const AdminProviderFeesScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.account_balance_wallet_outlined,
                  title: AppStrings.isEnglish ? 'Admin Wallet' : 'Wallet ya Msimamizi',
                  subtitle: AppStrings.isEnglish ? 'Platform balance, income and activity' : 'Salio la jukwaa, mapato na shughuli',
                  trailingBadge: 'Admin',
                  badgeColor: AppColors.warning,
                  onTap: () => _open(const AdminWalletScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.verified_user_outlined,
                  title: AppStrings.isEnglish ? 'Verification Review' : 'Uhakiki wa Vitambulisho',
                  subtitle: AppStrings.isEnglish ? 'ID papers, photos and business licences waiting for approval' : 'Vitambulisho, picha na leseni zinazosubiri idhini',
                  trailingBadge: 'Admin',
                  badgeColor: AppColors.warning,
                  onTap: () => _open(const AdminVerificationScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.notifications_active_outlined,
                  title: AppStrings.isEnglish ? 'Admin Notifications' : 'Arifa za Msimamizi',
                  subtitle: AppStrings.isEnglish ? 'Choose which admin alerts you receive' : 'Chagua arifa za usimamizi unazopokea',
                  trailingBadge: 'Admin',
                  badgeColor: AppColors.warning,
                  onTap: () => _open(const AdminNotificationPrefsScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.manage_accounts_outlined,
                  title: AppStrings.isEnglish ? 'Users' : 'Watumiaji',
                  subtitle: AppStrings.isEnglish ? 'Find accounts, suspend, reactivate or delete' : 'Tafuta akaunti, simamisha, rudisha au futa',
                  trailingBadge: 'Admin',
                  badgeColor: AppColors.warning,
                  onTap: () => _open(const AdminUsersScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.flag_outlined,
                  title: AppStrings.isEnglish ? 'Reports' : 'Ripoti',
                  subtitle: AppStrings.isEnglish ? 'Reports from users about services and people' : 'Ripoti za watumiaji kuhusu huduma na watu',
                  trailingBadge: 'Admin',
                  badgeColor: AppColors.warning,
                  onTap: () => _open(const AdminReportsScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.receipt_long_outlined,
                  title: AppStrings.isEnglish ? 'All Bookings' : 'Maombi Yote',
                  subtitle: AppStrings.isEnglish ? 'Evidence, release money or refund the buyer' : 'Ushahidi, lipa mtoa huduma au rudisha pesa',
                  trailingBadge: 'Admin',
                  badgeColor: AppColors.warning,
                  onTap: () => _open(const AdminBookingsScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.rocket_launch_outlined,
                  title: AppStrings.isEnglish ? 'Boost Plans' : 'Mipango ya Kutangaza',
                  subtitle: AppStrings.isEnglish ? 'Days and prices of boost plans' : 'Siku na bei za mipango ya kutangaza',
                  trailingBadge: 'Admin',
                  badgeColor: AppColors.warning,
                  onTap: () => _open(const AdminBoostPlansScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.request_quote_outlined,
                  title: AppStrings.isEnglish ? 'Registration & Listing Fees' : 'Ada za Usajili na Matangazo',
                  subtitle: AppStrings.isEnglish ? 'Provider registration, free listings, package and service fee' : 'Usajili wa mtoa huduma, huduma za bure, kifurushi na ada',
                  trailingBadge: 'Admin',
                  badgeColor: AppColors.warning,
                  onTap: () => _open(const AdminFeesScreen()),
                ),
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.system_update_outlined,
                  title: AppStrings.isEnglish ? 'App Update Message' : 'Ujumbe wa Kusasisha App',
                  subtitle: AppStrings.isEnglish ? 'Latest version, forced update and store link' : 'Toleo jipya, kusasisha kwa lazima na kiungo cha duka',
                  trailingBadge: 'Admin',
                  badgeColor: AppColors.warning,
                  onTap: () => _open(const AdminAppVersionScreen()),
                ),
              ]),
            ],

            // WALLET + upgrade (signed-in)
            if (isLoggedIn) ...[
              const SizedBox(height: 12),
              _section([
                _buildProfileOption(
                  icon: Icons.account_balance_wallet_outlined,
                  title: AppStrings.profileWalletTitle,
                  subtitle: AppStrings.profileWalletSubtitle,
                  onTap: () => _open(const PocketFundScreen()),
                ),
                if (isBuyer) ...[
                  _buildDivider(),
                  _buildProfileOption(
                    icon: Icons.credit_card_rounded,
                    title: AppStrings.isEnglish ? 'Payment Methods' : 'Njia za Malipo',
                    subtitle: AppPolicy.cardPaymentsEnabled
                        ? (AppStrings.isEnglish ? 'M-Pesa, Airtel Money, Tigo Pesa, card' : 'M-Pesa, Airtel Money, Tigo Pesa, kadi')
                        : 'M-Pesa, Airtel Money, Tigo Pesa',
                    onTap: () => _open(const PaymentMethodsScreen()),
                  ),
                ],
                if (isBuyer) ...[
                  _buildDivider(),
                  _buildProfileOption(
                    icon: Icons.storefront_rounded,
                    title: AppStrings.profileBecomeSeller,
                    subtitle: AppStrings.profileBecomeSellerSubtitle,
                    trailingBadge: 'Upgrade',
                    badgeColor: AppColors.primary,
                    onTap: () async {
                      final upgraded = await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const RegisterProviderScreen(isUpgradeFromBuyer: true),
                        ),
                      );
                      if (upgraded == true && mounted) {
                        _fetchServiceCount();
                        setState(() {});
                      }
                    },
                  ),
                ],
              ]),
            ],

            // GENERAL
            const SizedBox(height: 12),
            _section([
              _buildProfileOption(
                icon: Icons.language_rounded,
                title: AppStrings.profileLanguageTitle,
                subtitle: AppStrings.isEnglish ? 'English' : 'Kiswahili',
                trailingBadge: AppStrings.isEnglish ? 'EN' : 'SW',
                badgeColor: AppColors.primary,
                onTap: _showLanguageSelector,
              ),
              if (isLoggedIn) ...[
                _buildDivider(),
                _buildProfileOption(
                  icon: Icons.security_outlined,
                  title: AppStrings.isEnglish ? 'Settings & Security' : 'Mipangilio na Usalama',
                  subtitle: AppStrings.isEnglish ? 'Privacy, password and security' : 'Faragha, nenosiri na usalama',
                  onTap: () => _open(const SettingsSecurityScreen()),
                ),
              ],
              _buildDivider(),
              _buildProfileOption(
                icon: Icons.help_outline_rounded,
                title: AppStrings.profileHelpTitle,
                onTap: () => _open(const HelpSupportScreen()),
              ),
            ]),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
      },
    );
  }

  /// Four shortcuts to what people open most. Same screens as the lists below.
  Widget _quickActions({required bool isSeller}) {
    final isEn = AppStrings.isEnglish;
    final tiles = <({IconData icon, String label, VoidCallback onTap})>[
      (
        icon: Icons.receipt_long_outlined,
        label: isEn ? (isSeller ? 'Requests' : 'My Requests') : (isSeller ? 'Maombi' : 'Maombi Yangu'),
        onTap: () => _open(const RequestsScreen()),
      ),
      if (isSeller) ...[
        (
          icon: Icons.bar_chart_rounded,
          label: isEn ? 'Earnings' : 'Mapato',
          onTap: () => _open(const SellerEarningsScreen()),
        ),
      ] else ...[
        (
          icon: Icons.favorite_border_rounded,
          label: AppStrings.profileFavoritesTitle,
          onTap: () => _open(const FavoritesScreen()),
        ),
        (
          icon: Icons.account_balance_wallet_outlined,
          label: isEn ? 'Wallet' : 'Wallet',
          onTap: () => _open(const PocketFundScreen()),
        ),
      ],
    ];
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
      child: GridView.count(
        crossAxisCount: 2,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
        childAspectRatio: 3.0,
        children: [
          for (final t in tiles)
            Material(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(14),
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: t.onTap,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 30,
                        height: 30,
                        decoration: BoxDecoration(color: AppColors.primaryLight, borderRadius: BorderRadius.circular(9)),
                        child: Icon(t.icon, size: 16, color: AppColors.primary),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          t.label,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildProfileOption({
    required IconData icon,
    required String title,
    String? subtitle,
    String? trailingBadge,
    Color? badgeColor,
    required VoidCallback onTap,
  }) {
    final isSignOut = title == AppStrings.profileSignOutAction;
    final tone = isSignOut ? AppColors.danger : AppColors.primary;
    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
      leading: Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: isSignOut ? AppColors.dangerLight : AppColors.primaryLight,
          borderRadius: BorderRadius.circular(11),
        ),
        child: Icon(icon, color: tone, size: 20),
      ),
      title: Text(
        title,
        style: TextStyle(
          fontSize: 14.5,
          fontWeight: FontWeight.w700,
          color: isSignOut ? AppColors.danger : AppColors.textPrimary,
        ),
      ),
      subtitle: subtitle != null
          ? Text(subtitle, style: const TextStyle(fontSize: 12, height: 1.3, color: AppColors.textSecondary))
          : null,
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (trailingBadge != null)
            Container(
              margin: const EdgeInsets.only(right: 6),
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: (badgeColor ?? AppColors.primary).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                trailingBadge,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  color: badgeColor ?? AppColors.primary,
                ),
              ),
            ),
          if (!isSignOut) const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted, size: 20),
        ],
      ),
    );
  }

  /// A rounded card holding a group of rows.
  Widget _section(List<Widget> children) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.border),
      ),
      clipBehavior: Clip.antiAlias,
      child: Material(color: AppColors.surface, child: Column(children: children)),
    );
  }

  Widget _buildDivider() {
    return const Divider(height: 1, thickness: 1, indent: 66, color: AppColors.borderLight);
  }
}
