import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../services/api_service.dart';
import '../widgets/admin_common.dart';

/// Admin: which admin alerts this admin receives. Server: GET / PUT /admin/notification-prefs
/// {reports, disputes, withdrawals, payments}. The server enforces the switches, so an alert that is off is never sent.
class AdminNotificationPrefsScreen extends StatefulWidget {
  const AdminNotificationPrefsScreen({super.key});

  @override
  State<AdminNotificationPrefsScreen> createState() => _AdminNotificationPrefsScreenState();
}

class _AdminNotificationPrefsScreenState extends State<AdminNotificationPrefsScreen> {
  static const _keys = ['reports', 'disputes', 'withdrawals', 'payments'];

  bool _loading = true;
  bool _forbidden = false;
  bool _failed = false;
  final Set<String> _saving = {};
  Map<String, bool> _prefs = {for (final k in _keys) k: true};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _failed = false;
    });
    final r = await ApiService.adminGetObject('/admin/notification-prefs');
    if (!mounted) return;
    setState(() {
      _loading = false;
      _forbidden = r.forbidden;
      _failed = !r.forbidden && r.data == null;
      if (r.data != null) _prefs = {for (final k in _keys) k: r.data![k] != false};
    });
  }

  Future<void> _set(String key, bool value) async {
    final before = _prefs[key] ?? true;
    setState(() {
      _prefs[key] = value;
      _saving.add(key);
    });
    final res = await ApiService.adminSend('PUT', '/admin/notification-prefs', {key: value});
    if (!mounted) return;
    setState(() {
      _saving.remove(key);
      if (res.error != null) {
        _prefs[key] = before; // the server did not take it: show the truth
      } else if (res.data != null && res.data![key] is bool) {
        _prefs[key] = res.data![key] as bool;
      }
    });
    if (res.error != null) adminSnack(context, res.error!);
  }

  (IconData, String, String, String) _info(String key) => switch (key) {
        'reports' => (
            Icons.flag_outlined,
            adminT('New reports', 'Ripoti mpya'),
            adminT('A user reports a service, a person or a problem', 'Mtumiaji anaripoti huduma, mtu au tatizo'),
            '',
          ),
        'disputes' => (
            Icons.gavel_rounded,
            adminT('Payment disputes', 'Migogoro ya malipo'),
            adminT('A provider says a payment did not arrive', 'Mtoa huduma anasema malipo hayajafika'),
            '',
          ),
        'withdrawals' => (
            Icons.account_balance_wallet_outlined,
            adminT('Withdrawals to pay out', 'Maombi ya kutoa pesa'),
            adminT('A provider asks to withdraw money', 'Mtoa huduma anaomba kutoa pesa'),
            '',
          ),
        _ => (
            Icons.error_outline_rounded,
            adminT('Payment problems', 'Matatizo ya malipo'),
            adminT('A payment fails, the gateway is down or a payment does not match', 'Malipo yanashindikana, mfumo wa malipo umeharibika au malipo hayalingani'),
            '',
          ),
      };

  @override
  Widget build(BuildContext context) {
    final state = adminStateOrNull(
      loading: _loading,
      forbidden: _forbidden,
      failed: _failed,
      empty: false,
      onRetry: _load,
    );
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text(adminT('Admin Notifications', 'Arifa za Msimamizi'))),
      body: state ??
          ListView(padding: const EdgeInsets.all(16), children: [
            Text(
              adminT('Choose which alerts this phone account receives. Only your own switches change.',
                  'Chagua arifa ambazo akaunti yako inapokea. Ni swichi zako tu zinabadilika.'),
              style: const TextStyle(color: AppColors.textSecondary, fontSize: 13),
            ),
            const SizedBox(height: 12),
            Container(
              decoration: adminCardDecoration(),
              child: Column(children: [
                for (var i = 0; i < _keys.length; i++) ...[
                  if (i > 0) const Divider(height: 1),
                  Builder(builder: (_) {
                    final key = _keys[i];
                    final info = _info(key);
                    return SwitchListTile(
                      secondary: Icon(info.$1, color: AppColors.textSecondary),
                      title: Text(info.$2, style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: Text(info.$3, style: const TextStyle(fontSize: 12)),
                      value: _prefs[key] ?? true,
                      onChanged: _saving.contains(key) ? null : (v) => _set(key, v),
                    );
                  }),
                ],
              ]),
            ),
          ]),
    );
  }
}
