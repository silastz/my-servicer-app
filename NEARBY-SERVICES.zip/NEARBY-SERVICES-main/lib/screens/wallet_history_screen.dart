import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/data_sync.dart';
import '../widgets/app_ui.dart';
import '../services/currency_service.dart';

enum WalletTxKind { topUp, withdrawal, booking, refund }

/// One line of wallet activity.
class WalletTx {
  final String id;
  final WalletTxKind kind;
  final double amount; // always positive
  final bool incoming;
  final String title;
  final String status;
  final String reference;
  final DateTime? date;

  const WalletTx({
    required this.id,
    required this.kind,
    required this.amount,
    required this.incoming,
    required this.title,
    required this.status,
    required this.reference,
    required this.date,
  });

  static WalletTxKind _kindOf(String type) {
    final t = type.toUpperCase();
    if (t.contains('DEPOSIT') || t.contains('TOP')) return WalletTxKind.topUp;
    if (t.contains('WITHDRAW')) return WalletTxKind.withdrawal;
    if (t.contains('REFUND')) return WalletTxKind.refund;
    return WalletTxKind.booking;
  }

  /// From `GET /wallet/transactions`.
  factory WalletTx.fromWallet(Map<String, dynamic> j) {
    final raw = (j['amount'] as num?)?.toDouble() ?? double.tryParse('${j['amount']}') ?? 0;
    final kind = _kindOf('${j['type'] ?? ''}');
    final dir = '${j['direction'] ?? ''}'.toUpperCase();
    final incoming = dir == 'IN'
        ? true
        : dir == 'OUT'
            ? false
            : raw < 0
                ? false
                : (kind == WalletTxKind.topUp || kind == WalletTxKind.refund);
    return WalletTx(
      id: '${j['id'] ?? j['reference'] ?? ''}',
      kind: kind,
      amount: raw.abs(),
      incoming: incoming,
      title: '${j['title'] ?? ''}'.trim(),
      status: '${j['status'] ?? 'COMPLETED'}'.toUpperCase(),
      reference: '${j['reference'] ?? ''}',
      date: DateTime.tryParse('${j['createdAt'] ?? ''}')?.toLocal(),
    );
  }

  /// From a booking (escrow) transaction, used when the wallet history is not available yet.
  factory WalletTx.fromBooking(Map<String, dynamic> j) {
    final seller = j['seller'] is Map ? j['seller'] as Map : const {};
    final name = '${seller['stageName'] ?? seller['username'] ?? ''}'.trim();
    return WalletTx(
      id: '${j['id'] ?? j['transactionRef'] ?? ''}',
      kind: WalletTxKind.booking,
      amount: ((j['amount'] as num?)?.toDouble() ?? 0).abs(),
      incoming: false,
      title: name.isEmpty ? '' : name,
      status: '${j['status'] ?? 'COMPLETED'}'.toUpperCase(),
      reference: '${j['transactionRef'] ?? ''}',
      date: DateTime.tryParse('${j['createdAt'] ?? ''}')?.toLocal(),
    );
  }
}

/// Full-page wallet history with filters, day groups and a detail sheet.
class WalletHistoryScreen extends StatefulWidget {
  const WalletHistoryScreen({super.key});

  @override
  State<WalletHistoryScreen> createState() => _WalletHistoryScreenState();
}

class _WalletHistoryScreenState extends State<WalletHistoryScreen> {
  List<WalletTx> _all = [];
  bool _loading = true;
  bool _failed = false;
  String _filter = 'all'; // all | in | out | topUp | withdrawal | booking

  bool get _isEn => AppStrings.isEnglish;

  @override
  void initState() {
    super.initState();
    DataSync.changed.addListener(_onChanged);
    _load();
  }

  @override
  void dispose() {
    DataSync.changed.removeListener(_onChanged);
    super.dispose();
  }

  void _onChanged() {
    if (mounted) _load(silent: true);
  }

  Future<void> _load({bool silent = false}) async {
    if (!silent) setState(() => _loading = true);
    final list = await ApiService.fetchWalletTransactions();
    List<WalletTx> items;
    if (list != null) {
      items = [for (final e in list) if (e is Map) WalletTx.fromWallet(Map<String, dynamic>.from(e))];
    } else {
      // Wallet history not available: show the bookings the buyer paid for.
      final bookings = await ApiService.fetchBuyerTransactions();
      items = [for (final e in bookings) if (e is Map) WalletTx.fromBooking(Map<String, dynamic>.from(e))];
      _failed = items.isEmpty;
    }
    items.sort((a, b) => (b.date ?? DateTime.fromMillisecondsSinceEpoch(0)).compareTo(a.date ?? DateTime.fromMillisecondsSinceEpoch(0)));
    if (!mounted) return;
    setState(() {
      _all = items;
      _loading = false;
      if (list != null) _failed = false;
    });
  }

  String _money(num v) =>
      CurrencyService.format(v);

  static const _months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  String _two(int v) => v.toString().padLeft(2, '0');

  String _dayLabel(DateTime? d) {
    if (d == null) return _isEn ? 'Earlier' : 'Awali';
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final day = DateTime(d.year, d.month, d.day);
    final diff = today.difference(day).inDays;
    if (diff == 0) return _isEn ? 'Today' : 'Leo';
    if (diff == 1) return _isEn ? 'Yesterday' : 'Jana';
    return '${d.day} ${_months[d.month - 1]} ${d.year}';
  }

  String _time(DateTime? d) => d == null ? '' : '${_two(d.hour)}:${_two(d.minute)}';

  String _kindLabel(WalletTxKind k) {
    switch (k) {
      case WalletTxKind.topUp:
        return _isEn ? 'Top up' : 'Kuweka pesa';
      case WalletTxKind.withdrawal:
        return _isEn ? 'Withdrawal' : 'Kutoa pesa';
      case WalletTxKind.refund:
        return _isEn ? 'Refund' : 'Marejesho';
      case WalletTxKind.booking:
        return _isEn ? 'Booking payment' : 'Malipo ya oda';
    }
  }

  IconData _kindIcon(WalletTxKind k) {
    switch (k) {
      case WalletTxKind.topUp:
        return Icons.add_circle_outline_rounded;
      case WalletTxKind.withdrawal:
        return Icons.account_balance_outlined;
      case WalletTxKind.refund:
        return Icons.replay_rounded;
      case WalletTxKind.booking:
        return Icons.event_available_outlined;
    }
  }

  (String, Color) _status(String s) {
    if (s.contains('PEND') || s.contains('PROCESS') || s.contains('AWAIT')) return (_isEn ? 'Pending' : 'Inasubiri', AppColors.warningDark);
    if (s.contains('FAIL') || s.contains('REJECT') || s.contains('CANCEL')) return (_isEn ? 'Failed' : 'Imeshindwa', AppColors.danger);
    return (_isEn ? 'Completed' : 'Imekamilika', AppColors.successDark);
  }

  bool _matches(WalletTx t) {
    switch (_filter) {
      case 'in':
        return t.incoming;
      case 'out':
        return !t.incoming;
      case 'topUp':
        return t.kind == WalletTxKind.topUp;
      case 'withdrawal':
        return t.kind == WalletTxKind.withdrawal;
      case 'booking':
        return t.kind == WalletTxKind.booking;
      default:
        return true;
    }
  }

  @override
  Widget build(BuildContext context) {
    final filters = <(String, String)>[
      ('all', _isEn ? 'All' : 'Zote'),
      ('in', _isEn ? 'Money in' : 'Zilizoingia'),
      ('out', _isEn ? 'Money out' : 'Zilizotoka'),
      ('topUp', _isEn ? 'Top ups' : 'Kuweka'),
      ('withdrawal', _isEn ? 'Withdrawals' : 'Kutoa'),
      ('booking', _isEn ? 'Bookings' : 'Oda'),
    ];
    final shown = _all.where(_matches).toList();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(_isEn ? 'History' : 'Historia',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(color: AppColors.borderLight, height: 1)),
      ),
      body: Column(
        children: [
          Container(
            color: AppColors.surface,
            height: 52,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              itemCount: filters.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) {
                final f = filters[i];
                final on = _filter == f.$1;
                return ChoiceChip(
                  label: Text(f.$2, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: on ? Colors.white : AppColors.textPrimary)),
                  selected: on,
                  showCheckmark: false,
                  selectedColor: AppColors.primary,
                  backgroundColor: AppColors.surface,
                  side: BorderSide(color: on ? AppColors.primary : AppColors.border),
                  onSelected: (_) => setState(() => _filter = f.$1),
                );
              },
            ),
          ),
          const Divider(height: 1, color: AppColors.borderLight),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : RefreshIndicator(
                    onRefresh: () => _load(silent: true),
                    child: shown.isEmpty ? _empty() : _list(shown),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _empty() {
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(24, 90, 24, 24),
      children: [
        const Icon(Icons.receipt_long_outlined, size: 48, color: AppColors.textMuted),
        const SizedBox(height: 12),
        Text(
          _failed ? (_isEn ? 'Could not load your history' : 'Imeshindwa kupakia historia yako') : (_isEn ? 'No transactions yet' : 'Hakuna miamala bado'),
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        const SizedBox(height: 4),
        Text(
          _failed
              ? (_isEn ? 'Pull down to try again.' : 'Vuta chini kujaribu tena.')
              : (_isEn ? 'Top ups, withdrawals and bookings will show up here.' : 'Kuweka, kutoa pesa na oda vitaonekana hapa.'),
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
        ),
      ],
    );
  }

  Widget _list(List<WalletTx> items) {
    final rows = <Widget>[];
    String? last;
    for (final t in items) {
      final label = _dayLabel(t.date);
      if (label != last) {
        rows.add(Padding(
          padding: EdgeInsets.only(top: last == null ? 0 : 14, bottom: 8),
          child: Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: AppColors.textSecondary)),
        ));
        last = label;
      }
      rows.add(_tile(t));
    }
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
      children: rows,
    );
  }

  Widget _tile(WalletTx t) {
    final color = t.incoming ? AppColors.successDark : AppColors.textPrimary;
    final (statusText, statusColor) = _status(t.status);
    final subtitle = [if (t.title.isNotEmpty) t.title, _time(t.date)].where((e) => e.isNotEmpty).join('  •  ');
    return InkWell(
      onTap: () => _showDetails(t),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: (t.incoming ? AppColors.successDark : AppColors.primary).withValues(alpha: 0.12),
                shape: BoxShape.circle,
              ),
              child: Icon(_kindIcon(t.kind), size: 20, color: t.incoming ? AppColors.successDark : AppColors.primary),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_kindLabel(t.kind), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                  if (subtitle.isNotEmpty) ...[
                    const SizedBox(height: 2),
                    Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                  ],
                ],
              ),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text('${t.incoming ? '+' : '-'} ${_money(t.amount)}',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: color)),
                if (statusColor != AppColors.successDark) ...[
                  const SizedBox(height: 4),
                  StatusPill(text: statusText, color: statusColor),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showDetails(WalletTx t) {
    final (statusText, statusColor) = _status(t.status);
    final d = t.date;
    final when = d == null ? '' : '${d.day} ${_months[d.month - 1]} ${d.year}, ${_time(d)}';
    AppSheet.show<void>(
      context,
      title: _kindLabel(t.kind),
      builder: (ctx) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Text('${t.incoming ? '+' : '-'} ${_money(t.amount)}',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: t.incoming ? AppColors.successDark : AppColors.textPrimary)),
          ),
          const SizedBox(height: 6),
          Center(child: StatusPill(text: statusText, color: statusColor)),
          const SizedBox(height: 18),
          if (t.title.isNotEmpty) _detail(_isEn ? 'Details' : 'Maelezo', t.title),
          if (when.isNotEmpty) _detail(_isEn ? 'Date' : 'Tarehe', when),
          if (t.reference.isNotEmpty)
            _detail(
              _isEn ? 'Reference' : 'Kumbukumbu',
              t.reference,
              onCopy: () {
                Clipboard.setData(ClipboardData(text: t.reference));
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_isEn ? 'Reference copied' : 'Kumbukumbu imenakiliwa')));
              },
            ),
        ],
      ),
    );
  }

  Widget _detail(String k, String v, {VoidCallback? onCopy}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(k, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
          const SizedBox(width: 16),
          Expanded(
            child: Text(v, textAlign: TextAlign.end, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
          ),
          if (onCopy != null) ...[
            const SizedBox(width: 6),
            GestureDetector(onTap: onCopy, child: const Icon(Icons.copy_rounded, size: 16, color: AppColors.primary)),
          ],
        ],
      ),
    );
  }
}
