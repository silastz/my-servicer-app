import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/sms_gateway.dart';
import '../security/input_validation.dart';
import '../services/api_service.dart';
import '../widgets/app_ui.dart';
import '../services/currency_service.dart';

/// Admin: choose which SMS provider (Meseji or Beem Africa) the platform sends OTPs and alerts
/// with, and enter that provider's credentials. Meseji is the default until the admin picks Beem.
///
/// This screen is only a remote control. The server checks every call (403 for anyone who is
/// not an admin), stores the secrets and is the one that really sends SMS. Secrets are
/// write-only: the server never sends them back, so a secret field stays blank and a blank
/// field means "keep the saved one".
class AdminSmsGatewayScreen extends StatefulWidget {
  const AdminSmsGatewayScreen({super.key});

  @override
  State<AdminSmsGatewayScreen> createState() => _AdminSmsGatewayScreenState();
}

class _AdminSmsGatewayScreenState extends State<AdminSmsGatewayScreen> {
  bool _loading = true;
  bool _forbidden = false;
  bool _loadFailed = false;

  SmsGatewayConfig? _saved; // what the server has now
  SmsProvider _selected = SmsProvider.defaultProvider; // default provider the admin tapped
  bool _failover = true; // switch to the other provider automatically when sending fails

  final _mesejiKey = TextEditingController();
  final _mesejiSender = TextEditingController();
  final _mesejiEmail = TextEditingController();
  final _mesejiPassword = TextEditingController();
  final _mesejiCost = TextEditingController();
  final _beemKey = TextEditingController();
  final _beemSecret = TextEditingController();
  final _beemSender = TextEditingController();
  final _beemCost = TextEditingController();
  final _testPhone = TextEditingController();

  final Map<String, String> _errors = {};
  bool _testBusy = false;

  bool get _isEn => AppStrings.isEnglish;
  String _t(String en, String sw) => _isEn ? en : sw;

  List<TextEditingController> get _all => [
        _mesejiKey, _mesejiSender, _mesejiEmail, _mesejiPassword, _mesejiCost,
        _beemKey, _beemSecret, _beemSender, _beemCost,
      ];

  @override
  void initState() {
    super.initState();
    for (final c in _all) {
      c.addListener(_onEdited);
    }
    _load();
  }

  @override
  void dispose() {
    for (final c in [..._all, _testPhone]) {
      c.dispose();
    }
    super.dispose();
  }

  void _onEdited() {
    if (mounted) setState(() {});
  }

  String _costText(double v) => v == v.roundToDouble() ? v.round().toString() : v.toString();

  /// Fills the fields from what the server has. Secrets are always left blank.
  void _fill(SmsGatewayConfig c) {
    _mesejiKey.clear();
    _mesejiPassword.clear();
    _beemKey.clear();
    _beemSecret.clear();
    _mesejiSender.text = c.meseji.senderId;
    _mesejiEmail.text = c.meseji.email;
    _mesejiCost.text = _costText(c.meseji.costPerSms);
    _beemSender.text = c.beem.senderId;
    _beemCost.text = _costText(c.beem.costPerSms);
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _loadFailed = false;
    });
    final r = await ApiService.getAdminSmsConfig();
    if (!mounted) return;
    if (r.config != null) _fill(r.config!);
    setState(() {
      _loading = false;
      _forbidden = r.forbidden;
      _loadFailed = !r.forbidden && r.config == null;
      _saved = r.config;
      if (r.config != null) {
        _selected = r.config!.defaultProvider;
        _failover = r.config!.autoFailover;
      }
    });
  }

  bool get _changed {
    final s = _saved;
    if (s == null) return false;
    if (_selected != s.defaultProvider || _failover != s.autoFailover) return true;
    if (_mesejiKey.text.isNotEmpty || _mesejiPassword.text.isNotEmpty) return true;
    if (_beemKey.text.isNotEmpty || _beemSecret.text.isNotEmpty) return true;
    return _mesejiSender.text.trim() != s.meseji.senderId ||
        _mesejiEmail.text.trim() != s.meseji.email ||
        SmsGatewayRules.parseCost(_mesejiCost.text) != s.meseji.costPerSms ||
        _beemSender.text.trim() != s.beem.senderId ||
        SmsGatewayRules.parseCost(_beemCost.text) != s.beem.costPerSms;
  }

  /// The chosen provider would have everything it needs after this save.
  bool _selectedReadyAfterSave() {
    final s = _saved!;
    if (_selected == SmsProvider.beem) {
      return (s.beem.apiKeySet || _beemKey.text.trim().isNotEmpty) &&
          (s.beem.secretSet || _beemSecret.text.trim().isNotEmpty) &&
          _beemSender.text.trim().isNotEmpty;
    }
    return (s.meseji.apiKeySet || _mesejiKey.text.trim().isNotEmpty) && _mesejiSender.text.trim().isNotEmpty;
  }

  bool _validate() {
    final e = <String, String>{};
    final ms = SmsGatewayRules.mesejiSender(_mesejiSender.text);
    if (ms != null) e['mesejiSender'] = ms == 'empty' ? _t('Enter the sender ID', 'Weka Sender ID') : _t('Letters, numbers, space, + - . only (max 20)', 'Herufi, namba, nafasi, + - . tu (juu 20)');
    final bs = SmsGatewayRules.beemSender(_beemSender.text);
    if (bs != null) e['beemSender'] = bs == 'empty' ? _t('Enter the sender ID', 'Weka Sender ID') : _t('Max 11 letters, numbers or spaces', 'Hadi herufi 11, namba au nafasi');
    if (SmsGatewayRules.parseCost(_mesejiCost.text) == null) e['mesejiCost'] = _t('Enter a number, 0 or more', 'Weka namba, 0 au zaidi');
    if (SmsGatewayRules.parseCost(_beemCost.text) == null) e['beemCost'] = _t('Enter a number, 0 or more', 'Weka namba, 0 au zaidi');
    final em = InputValidation.emailOptional(_mesejiEmail.text);
    if (em != null) e['mesejiEmail'] = em;
    setState(() {
      _errors
        ..clear()
        ..addAll(e);
    });
    return e.isEmpty;
  }

  void _snack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _save() async {
    if (_saved == null || !_validate()) return;
    if (!_selectedReadyAfterSave()) {
      _snack(_t(
        'Fill in ${_selected.label} credentials before making it the default.',
        'Weka taarifa za ${_selected.label} kabla ya kuifanya chaguo-msingi.',
      ));
      return;
    }
    if (_selected != _saved!.defaultProvider) {
      final ok = await AppDialog.confirm(
        context,
        icon: Icons.sms_rounded,
        title: _t('Switch to ${_selected.label}?', 'Badilisha kuwa ${_selected.label}?'),
        message: _t(
          'All new SMS (login codes and alerts) will be sent with ${_selected.label}.',
          'SMS zote mpya (misimbo ya kuingia na taarifa) zitatumwa kwa ${_selected.label}.',
        ),
        confirmLabel: _t('Switch', 'Badilisha'),
      );
      if (!ok || !mounted) return;
    }

    final update = SmsGatewayUpdate(
      defaultProvider: _selected,
      autoFailover: _failover,
      mesejiApiKey: _mesejiKey.text,
      mesejiSenderId: _mesejiSender.text,
      mesejiEmail: _mesejiEmail.text,
      mesejiPassword: _mesejiPassword.text,
      mesejiCost: SmsGatewayRules.parseCost(_mesejiCost.text)!,
      beemApiKey: _beemKey.text,
      beemSecretKey: _beemSecret.text,
      beemSenderId: _beemSender.text,
      beemCost: SmsGatewayRules.parseCost(_beemCost.text)!,
    );
    final saved = await ApiService.setAdminSmsConfig(update);
    if (!mounted) return;
    if (saved == null) {
      final err = ApiService.lastAdminError;
      _snack(err == 'forbidden'
          ? _t('Only an admin can change this.', 'Ni msimamizi pekee anayeweza kubadilisha hili.')
          : err == 'network'
              ? _t('No connection. Nothing was changed.', 'Hakuna mtandao. Hakuna kilichobadilishwa.')
              : _t('Could not save. Nothing was changed.', 'Imeshindwa kuhifadhi. Hakuna kilichobadilishwa.'));
      return;
    }
    _fill(saved); // clears the secret fields: they are never kept on the phone
    setState(() {
      _saved = saved;
      _selected = saved.defaultProvider;
      _failover = saved.autoFailover;
    });
    _snack(_t('SMS provider is now ${saved.defaultProvider.label}.', 'Mtoa huduma wa SMS sasa ni ${saved.defaultProvider.label}.'));
  }

  String _testError(SmsTestResult r) {
    if (r.message == 'forbidden') return _t('Only an admin can do this.', 'Ni msimamizi pekee anayeweza kufanya hili.');
    if (r.message == 'network') return _t('No connection.', 'Hakuna mtandao.');
    return r.message ?? _t('Failed.', 'Imeshindwa.');
  }

  Future<void> _testConnection() async {
    if (_testBusy) return;
    setState(() => _testBusy = true);
    final r = await ApiService.adminSmsTestConnection(_selected);
    if (!mounted) return;
    setState(() => _testBusy = false);
    _snack(r.success ? (r.message ?? _t('Connected.', 'Imeunganishwa.')) : _testError(r));
  }

  Future<void> _testSend() async {
    if (_testBusy) return;
    final phone = InputValidation.toInternational(_testPhone.text, '+255');
    if (InputValidation.phoneE164(phone) != null) {
      setState(() => _errors['testPhone'] = _t('Enter a valid phone number', 'Weka namba sahihi ya simu'));
      return;
    }
    setState(() => _errors.remove('testPhone'));
    final ok = await AppDialog.confirm(
      context,
      icon: Icons.send_rounded,
      title: _t('Send a test SMS?', 'Tuma SMS ya majaribio?'),
      message: _t(
        'One SMS will be sent to $phone with ${_selected.label}. It uses 1 credit.',
        'SMS moja itatumwa kwa $phone kwa ${_selected.label}. Inatumia credit 1.',
      ),
      confirmLabel: _t('Send', 'Tuma'),
    );
    if (!ok || !mounted) return;
    setState(() => _testBusy = true);
    final r = await ApiService.adminSmsTestSend(_selected, phone);
    if (!mounted) return;
    setState(() => _testBusy = false);
    _snack(r.success ? (r.message ?? _t('Test SMS sent.', 'SMS ya majaribio imetumwa.')) : _testError(r));
  }

  // ---------------------------------------------------------------------------
  // UI
  // ---------------------------------------------------------------------------

  Widget _info(String text, {Color color = AppColors.primary, IconData icon = Icons.info_outline_rounded}) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.2)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 12.5, height: 1.4, color: AppColors.textPrimary))),
        ],
      ),
    );
  }

  Widget _heading(String text) => Padding(
        padding: const EdgeInsets.only(top: 20, bottom: 10),
        child: Text(text, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
      );

  Widget _option(SmsProvider p) {
    final selected = p == _selected;
    final s = _saved!;
    final ready = p == SmsProvider.beem ? s.beem.isComplete : s.meseji.isComplete;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => setState(() => _selected = p),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: selected ? AppColors.primary : AppColors.border, width: selected ? 1.6 : 1),
          ),
          child: Row(
            children: [
              Icon(selected ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded,
                  color: selected ? AppColors.primary : AppColors.textMuted),
              const SizedBox(width: 12),
              Expanded(
                child: Text(p.label, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
              ),
              if (p == s.defaultProvider) StatusPill(text: _t('Active', 'Inatumika'), color: AppColors.success),
              if (p == s.defaultProvider && !ready) const SizedBox(width: 6),
              if (!ready) StatusPill(text: _t('Not set up', 'Haijawekwa'), color: AppColors.warning),
            ],
          ),
        ),
      ),
    );
  }

  /// "If sending fails, switch to the other provider automatically."
  Widget _failoverRow() {
    final other = _selected == SmsProvider.beem ? SmsProvider.meseji : SmsProvider.beem;
    final s = _saved!;
    final otherReady = other == SmsProvider.beem ? s.beem.isComplete : s.meseji.isComplete;
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 6, 6, 6),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  _t('Switch automatically if sending fails', 'Badilisha kiotomatiki kutuma kukishindwa'),
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                ),
              ),
              Switch(value: _failover, onChanged: (v) => setState(() => _failover = v)),
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(right: 12, bottom: 8),
            child: Text(
              !_failover
                  ? _t('If ${_selected.label} fails, the SMS is not sent.', 'Ikiwa ${_selected.label} itashindwa, SMS haitatumwa.')
                  : otherReady
                      ? _t('If ${_selected.label} fails, the same SMS is sent with ${other.label}.', 'Ikiwa ${_selected.label} itashindwa, SMS hiyo hiyo itatumwa kwa ${other.label}.')
                      : _t('${other.label} has no credentials yet, so there is nothing to switch to. Add them below.', '${other.label} haina taarifa bado, kwa hiyo hakuna cha kubadilisha. Ziweke hapa chini.'),
              style: TextStyle(fontSize: 12, height: 1.35, color: _failover && !otherReady ? AppColors.warning : AppColors.textSecondary),
            ),
          ),
        ],
      ),
    );
  }

  /// Secret field: blank means keep. The hint says whether one is already saved.
  Widget _secret(TextEditingController c, String label, bool isSet) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: AppTextField(
        controller: c,
        label: label,
        hint: isSet ? _t('Saved. Leave blank to keep it', 'Imehifadhiwa. Acha wazi ili kuiweka') : _t('Enter $label', 'Weka $label'),
        icon: isSet ? Icons.lock_rounded : Icons.key_rounded,
        obscureText: true,
      ),
    );
  }

  Widget _field(TextEditingController c, String label, String hint, IconData icon,
      {String? errorKey, TextInputType type = TextInputType.text, int? maxLength}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: AppTextField(
        controller: c,
        label: label,
        hint: hint,
        icon: icon,
        keyboardType: type,
        maxLength: maxLength,
        errorText: errorKey == null ? null : _errors[errorKey],
      ),
    );
  }

  Widget _body() {
    if (_loading) return const Center(child: CircularProgressIndicator(color: AppColors.primary));
    if (_forbidden) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: _info(
            _t('This account is not an admin, so it cannot change SMS settings.', 'Akaunti hii si ya msimamizi, kwa hiyo haiwezi kubadilisha mipangilio ya SMS.'),
            color: AppColors.danger,
            icon: Icons.lock_outline_rounded,
          ),
        ),
      );
    }
    if (_loadFailed || _saved == null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(_t('Could not load the SMS settings.', 'Imeshindwa kupakia mipangilio ya SMS.'),
                  textAlign: TextAlign.center, style: const TextStyle(fontSize: 14, color: AppColors.textSecondary)),
              const SizedBox(height: 16),
              AppButton.primary(label: _t('Try again', 'Jaribu tena'), onPressed: _load),
            ],
          ),
        ),
      );
    }
    final s = _saved!;
    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _info(_t(
                'Choose the provider that sends login codes and alerts, and enter its credentials. Saved keys are never shown again: leave a key blank to keep it.',
                'Chagua mtoa huduma anayetuma misimbo ya kuingia na taarifa, kisha weka taarifa zake. Funguo zilizohifadhiwa hazionyeshwi tena: acha wazi ili kuiweka.',
              )),
              _heading(_t('Default provider', 'Mtoa huduma wa msingi')),
              for (final p in SmsProvider.values) _option(p),
              _failoverRow(),

              _heading('Meseji'),
              _secret(_mesejiKey, 'API key', s.meseji.apiKeySet),
              _field(_mesejiSender, 'Sender ID', 'e.g. UNGANA', Icons.badge_outlined, errorKey: 'mesejiSender'),
              _field(_mesejiEmail, _t('Account email (balance)', 'Barua pepe ya akaunti (salio)'), 'account@example.com',
                  Icons.email_outlined, errorKey: 'mesejiEmail', type: TextInputType.emailAddress),
              _secret(_mesejiPassword, _t('Account password', 'Nenosiri la akaunti'), s.meseji.passwordSet),
              _field(_mesejiCost, _t('Cost per SMS (${CurrencyService.symbol})', 'Gharama kwa SMS (${CurrencyService.symbol})'), '15', Icons.payments_outlined,
                  errorKey: 'mesejiCost', type: const TextInputType.numberWithOptions(decimal: true)),

              _heading('Beem Africa'),
              _secret(_beemKey, 'API key', s.beem.apiKeySet),
              _secret(_beemSecret, 'Secret key', s.beem.secretSet),
              _field(_beemSender, 'Sender ID', 'INFO', Icons.badge_outlined, errorKey: 'beemSender', maxLength: SmsGatewayRules.beemSenderMax),
              _field(_beemCost, _t('Cost per SMS (${CurrencyService.symbol})', 'Gharama kwa SMS (${CurrencyService.symbol})'), '15', Icons.payments_outlined,
                  errorKey: 'beemCost', type: const TextInputType.numberWithOptions(decimal: true)),
              _info(_t(
                'Beem only accepts a Sender ID that is approved in your Beem Africa dashboard.',
                'Beem hukubali Sender ID iliyoidhinishwa kwenye dashboard yako ya Beem Africa pekee.',
              ), color: AppColors.warning),

              _heading(_t('Test ${_selected.label}', 'Jaribu ${_selected.label}')),
              _info(_t('Tests use the saved settings, so press Save first.', 'Majaribio hutumia mipangilio iliyohifadhiwa, kwa hiyo bonyeza Hifadhi kwanza.')),
              const SizedBox(height: 12),
              AppButton.outlined(label: _t('Test connection', 'Jaribu muunganisho'), onPressed: _testBusy ? null : _testConnection),
              const SizedBox(height: 12),
              _field(_testPhone, _t('Test phone number', 'Namba ya simu ya majaribio'), '0712345678', Icons.phone_outlined,
                  errorKey: 'testPhone', type: TextInputType.phone),
              AppButton.outlined(label: _t('Send test SMS', 'Tuma SMS ya majaribio'), onPressed: _testBusy ? null : _testSend),
              const SizedBox(height: 8),
            ],
          ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: SizedBox(
              width: double.infinity,
              child: AppButton.primary(label: _t('Save', 'Hifadhi'), onPressed: _changed ? _save : null),
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _t('SMS Provider', 'Mtoa huduma wa SMS'),
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: _body(),
    );
  }
}
