import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/provider_fees.dart';
import '../services/api_service.dart';
import '../services/app_policy.dart';
import '../services/data_sync.dart';
import '../services/payment_methods_service.dart';
import '../services/session_manager.dart';
import '../widgets/app_ui.dart';
import '../services/currency_service.dart';
import '../services/money_input.dart';

/// Admin: move money out of the platform wallet to a mobile-money number.
///
/// The ONLY fee on an admin withdrawal is the flat payout fee. No collection fee, no VAT.
/// (Provider withdrawals are different: see PROVIDER_FEES_FLOW.md.) The numbers shown here are an
/// estimate; the server takes the real payout fee and its answer wins. Pops with `true` when a
/// withdrawal was requested.
class AdminWithdrawScreen extends StatefulWidget {
  /// Platform balance reported by the server (what the admin can try to withdraw).
  final double balance;
  const AdminWithdrawScreen({super.key, this.balance = 0});

  @override
  State<AdminWithdrawScreen> createState() => _AdminWithdrawScreenState();
}

class _AdminWithdrawScreenState extends State<AdminWithdrawScreen> {
  final TextEditingController _amountCtrl = TextEditingController();
  final TextEditingController _phoneCtrl = TextEditingController();
  String? _amountError;
  String? _phoneError;
  bool _busy = false;
  double? _done;
  double? _doneNet;
  double? _doneFee;
  String _doneTo = '';

  bool get _isEn => AppStrings.isEnglish;

  /// Only the payout fee counts for the admin; collection % and VAT % are ignored on purpose.
  ProviderFees get _fees => AppPolicy.providerFees ?? const ProviderFees();

  double get _amount => MoneyInput.parse(_amountCtrl.text) ?? 0;

  @override
  void initState() {
    super.initState();
    _phoneCtrl.text = SessionManager.getPhone();
  }

  @override
  void dispose() {
    _amountCtrl.dispose();
    _phoneCtrl.dispose();
    super.dispose();
  }

  String _money(num v) =>
      CurrencyService.format(v);

  Future<void> _withdraw() async {
    if (_busy || _done != null) return;
    final amount = _amount;
    final fees = _fees;
    final phone = PaymentMethodsService.normalizeTzNumber(_phoneCtrl.text);

    String? badAmount;
    if (amount < 1000) {
      badAmount = _isEn ? 'Enter at least ${_money(1000)}' : 'Weka angalau ${_money(1000)}';
    } else if (amount > widget.balance) {
      badAmount = _isEn ? 'More than the platform balance' : 'Zaidi ya salio la jukwaa';
    } else if (!fees.adminWithdrawCovers(amount)) {
      badAmount = _isEn
          ? 'Too small: the payout fee would take all of it. Try at least ${_money(fees.adminSmallestUsable)}'
          : 'Ndogo mno: ada ya kutuma ingechukua yote. Jaribu angalau ${_money(fees.adminSmallestUsable)}';
    }
    final badPhone = phone == null ? (CurrencyService.badNumberMessage(_isEn)) : null;
    if (badAmount != null || badPhone != null) {
      setState(() {
        _amountError = badAmount;
        _phoneError = badPhone;
      });
      return;
    }

    final masked = PaymentMethodsService.mask(phone!);
    final fee = fees.adminWithdrawFee(amount);
    final ok = await AppDialog.confirm(
      context,
      icon: Icons.account_balance_outlined,
      title: _isEn ? 'Confirm withdrawal' : 'Thibitisha utoaji',
      message: fee > 0
          ? (_isEn
              ? '${_money(amount)} leaves the platform wallet. After the payout fee of ${_money(fee)}, $masked receives about ${_money(fees.adminWithdrawNet(amount))}.'
              : '${_money(amount)} inatoka kwenye wallet ya jukwaa. Baada ya ada ya kutuma ya ${_money(fee)}, $masked inapokea takriban ${_money(fees.adminWithdrawNet(amount))}.')
          : (_isEn
              ? 'Send ${_money(amount)} from the platform wallet to $masked?'
              : 'Tuma ${_money(amount)} kutoka wallet ya jukwaa kwenda $masked?'),
      confirmLabel: _isEn ? 'Withdraw' : 'Toa pesa',
    );
    if (!ok || !mounted) return;

    setState(() {
      _busy = true;
      _amountError = null;
      _phoneError = null;
    });
    final res = await ApiService.adminWithdrawWallet(amount, '+$phone');
    if (!mounted) return;
    setState(() => _busy = false);
    if (res.data == null) {
      final msg = switch (res.error) {
        'forbidden' => _isEn ? 'This account is not an admin.' : 'Akaunti hii si ya msimamizi.',
        'invalid' => _isEn ? 'The server rejected this amount. Check the balance and try again.' : 'Seva imekataa kiasi hiki. Angalia salio ujaribu tena.',
        'network' => _isEn ? 'No connection. Nothing was withdrawn.' : 'Hakuna mtandao. Hakuna pesa iliyotolewa.',
        _ => _isEn ? 'Withdrawal failed. Try again.' : 'Imeshindwa kutoa pesa. Jaribu tena.',
      };
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: AppColors.danger, content: Text(msg)));
      return;
    }
    DataSync.bump();
    // The server's own numbers win over the estimate.
    final d = res.data!;
    final srvNet = d['netAmount'] ?? d['net'];
    final srvFee = d['fee'];
    setState(() {
      _done = amount;
      _doneNet = srvNet is num ? srvNet.toDouble() : fees.adminWithdrawNet(amount).toDouble();
      _doneFee = srvFee is num ? srvFee.toDouble() : fee.toDouble();
      _doneTo = masked;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: _busy ? null : () => Navigator.pop(context, _done != null),
        ),
        title: Text(_isEn ? 'Withdraw (Admin)' : 'Toa Pesa (Msimamizi)',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(color: AppColors.borderLight, height: 1)),
      ),
      body: PopScope(
        canPop: false,
        onPopInvokedWithResult: (didPop, _) {
          if (!didPop && !_busy) Navigator.pop(context, _done != null);
        },
        child: SafeArea(
          child: ListView(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 24 + MediaQuery.of(context).viewInsets.bottom),
            children: _done != null ? _doneState() : _form(),
          ),
        ),
      ),
    );
  }

  List<Widget> _form() {
    final amount = _amount;
    return [
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(16)),
        child: Row(
          children: [
            const Icon(Icons.account_balance_wallet_outlined, color: Colors.white70, size: 22),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_isEn ? 'Platform balance' : 'Salio la jukwaa',
                      style: const TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w500)),
                  const SizedBox(height: 2),
                  Text(_money(widget.balance),
                      style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900, letterSpacing: -0.5)),
                ],
              ),
            ),
          ],
        ),
      ),
      const SizedBox(height: 20),
      Row(
        children: [
          Expanded(
            child: Text(_isEn ? 'How much do you want to withdraw?' : 'Unataka kutoa kiasi gani?',
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
          ),
          TextButton(
            onPressed: _busy || widget.balance <= 0
                ? null
                : () => setState(() {
                      _amountCtrl.text = MoneyInput.text(widget.balance.floor());
                      _amountError = null;
                    }),
            child: Text(_isEn ? 'Withdraw all' : 'Toa yote', style: const TextStyle(fontWeight: FontWeight.w700)),
          ),
        ],
      ),
      AppTextField(
        controller: _amountCtrl,
        icon: Icons.payments_outlined,
        keyboardType: TextInputType.number,
        hint: _isEn ? 'Amount (${CurrencyService.symbol})' : 'Kiasi (${CurrencyService.symbol})',
        errorText: _amountError,
        inputFormatters: const [MoneyInputFormatter(maxDigits: 10)],
        onChanged: (_) => setState(() => _amountError = null),
      ),
      const SizedBox(height: 22),
      Text(_isEn ? 'Send the money to' : 'Tuma pesa kwenda',
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
      const SizedBox(height: 10),
      AppTextField(
        controller: _phoneCtrl,
        icon: Icons.phone_outlined,
        keyboardType: TextInputType.phone,
        hint: '07XX XXX XXX',
        label: _isEn ? 'Mobile money number' : 'Namba ya pesa za simu',
        errorText: _phoneError,
        onChanged: (_) => setState(() => _phoneError = null),
      ),
      _feeBreakdown(),
      const SizedBox(height: 20),
      AppButton.primary(
        label: amount >= 1000 ? (_isEn ? 'Withdraw ${_money(amount)}' : 'Toa ${_money(amount)}') : (_isEn ? 'Withdraw' : 'Toa pesa'),
        loading: _busy,
        onPressed: _busy ? null : _withdraw,
      ),
    ];
  }

  /// Amount, payout fee, net. No collection fee and no VAT line, by design.
  Widget _feeBreakdown() {
    final fees = _fees;
    final amount = _amount;
    Widget row(String a, String b, {bool bold = false, Color? color}) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 3),
          child: Row(children: [
            Expanded(child: Text(a, style: TextStyle(fontSize: 13, fontWeight: bold ? FontWeight.w800 : FontWeight.w500, color: AppColors.textSecondary))),
            Text(b, style: TextStyle(fontSize: 13, fontWeight: bold ? FontWeight.w800 : FontWeight.w600, color: color ?? AppColors.textPrimary)),
          ]),
        );
    return Container(
      margin: const EdgeInsets.only(top: 18),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.borderLight)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(_isEn ? 'Withdrawal fee' : 'Ada ya kutoa pesa',
              style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
          const SizedBox(height: 6),
          if (amount > 0 && fees.adminWithdrawCovers(amount)) ...[
            row(_isEn ? 'You withdraw' : 'Unatoa', _money(amount)),
            if (fees.adminWithdrawFee(amount) > 0)
              row(_isEn ? 'Payout fee' : 'Ada ya kutuma', '- ${_money(fees.adminWithdrawFee(amount))}'),
            const Divider(height: 14),
            row(_isEn ? 'You receive' : 'Unapokea', _money(fees.adminWithdrawNet(amount)), bold: true, color: AppColors.successDark),
          ] else
            Text(
              _isEn
                  ? 'Only the payout fee is taken (no collection fee, no VAT). Enter an amount to see what you receive.'
                  : 'Ada ya kutuma pekee ndiyo hukatwa (hakuna ada ya ukusanyaji, hakuna VAT). Weka kiasi uone utakachopokea.',
              style: const TextStyle(fontSize: 12.5, height: 1.4, color: AppColors.textSecondary),
            ),
        ],
      ),
    );
  }

  List<Widget> _doneState() {
    return [
      const SizedBox(height: 40),
      Center(
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: const BoxDecoration(color: AppColors.successLight, shape: BoxShape.circle),
          child: const Icon(Icons.check_circle_rounded, color: AppColors.success, size: 56),
        ),
      ),
      const SizedBox(height: 16),
      Text(_isEn ? 'Withdrawal requested' : 'Ombi la kutoa pesa limetumwa',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
      const SizedBox(height: 6),
      Text(
        _doneNet != null && (_doneFee ?? 0) > 0
            ? (_isEn
                ? '${_money(_doneNet!)} is on its way to $_doneTo (${_money(_done ?? 0)} minus a ${_money(_doneFee!)} payout fee).'
                : '${_money(_doneNet!)} inaelekea $_doneTo (${_money(_done ?? 0)} ukiondoa ada ya kutuma ya ${_money(_doneFee!)}).')
            : (_isEn ? '${_money(_done ?? 0)} is on its way to $_doneTo.' : '${_money(_done ?? 0)} inaelekea $_doneTo.'),
        textAlign: TextAlign.center,
        style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
      ),
      const SizedBox(height: 28),
      AppButton.primary(label: _isEn ? 'Done' : 'Sawa', onPressed: () => Navigator.pop(context, true)),
    ];
  }
}
