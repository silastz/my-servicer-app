import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../constants/app_colors.dart';
import 'chat_thread_screen.dart';
import 'map_tracking_screen.dart';
import 'buyer_profile_screen.dart' show BuyerInfo, SafeBadge;
import '../widgets/cancel_booking_sheet.dart';
import '../constants/app_strings.dart';
import '../services/payment_flow.dart';
import '../services/api_service.dart';
import '../widgets/app_image.dart';
import '../widgets/payment_flow_widgets.dart';

class BookingDetailsScreen extends StatelessWidget {
  final Map<String, dynamic> bookingData;

  const BookingDetailsScreen({
    super.key,
    required this.bookingData,
  });

  @override
  Widget build(BuildContext context) {
    // rawStatus is the server status (e.g. AWAITING_PAYMENT); 'status' may be a display label.
    final status = (bookingData['rawStatus'] ?? bookingData['status'] ?? 'CONFIRMED').toString().toUpperCase();
    final payTx = bookingData['tx'] is Map<String, dynamic> ? bookingData['tx'] as Map<String, dynamic> : null;
    final showPay = payTx != null &&
        (PaymentFlow.isOpen(status) ||
            PaymentFlow.awaitingPayAfterAccept(payTx) ||
            (bookingData['isBuyer'] != false && PaymentFlow.canRelease(payTx)));
    final en = AppStrings.isEnglish;
    final tx = payTx ?? const <String, dynamic>{};
    String clean(dynamic v) => (v ?? '').toString().trim();

    // Real values from the booking / transaction only; anything unknown is hidden.
    DateTime? when;
    // createdAt is when the request was SENT, not the appointment, so it is never used as the date/time.
    for (final k in const ['scheduledAt', 'bookingDate', 'startTime']) {
      final d = DateTime.tryParse(clean(tx[k]));
      if (d != null) { when = d.toLocal(); break; }
    }
    String two(int v) => v.toString().padLeft(2, '0');
    // scheduledAt / serviceMode / place come from the server. Bookings made before those fields existed
    // carry "Date: d/m/yyyy, Time: HH:MM. Place: ... ." in the notes, so those are read as a fallback.
    final notes = clean(tx['notes']);
    final noteDate = RegExp(r'Date:\s*(\d{1,2}/\d{1,2}/\d{4})').firstMatch(notes)?.group(1) ?? '';
    final noteTime = RegExp(r'Time:\s*(\d{1,2}:\d{2})').firstMatch(notes)?.group(1) ?? '';
    final notePlace = RegExp(r'Place:\s*([^.]+)\.').firstMatch(notes)?.group(1)?.trim() ?? '';
    final serviceTitle = clean(bookingData['serviceTitle']).isNotEmpty
        ? bookingData['serviceTitle']
        : clean(tx['serviceTitle']).isNotEmpty ? tx['serviceTitle'] : (en ? 'Service' : 'Huduma');
    final providerName = clean(bookingData['providerName']).isNotEmpty
        ? bookingData['providerName']
        : (en ? 'Provider' : 'Mtoa huduma');
    // "As soon as possible" requests carry no date and time; tasks and photos come from the server's request.
    final isAsap = tx['asap'] == true;
    final taskRows = <(String, String)>[
      if (tx['tasks'] is List)
        for (final t in (tx['tasks'] as List))
          if (t is Map && clean(t['name']).isNotEmpty) (clean(t['name']), clean(t['price']).split('.').first),
    ];
    final photoUrls = <String>[
      if (tx['photoUrls'] is List)
        for (final u in (tx['photoUrls'] as List))
          if (clean(u).isNotEmpty) clean(u),
    ];
    final rating = clean(bookingData['rating']);
    final reviewsCount = clean(bookingData['reviewsCount']);
    final date = isAsap ? '' : clean(bookingData['date']).isNotEmpty
        ? clean(bookingData['date'])
        : when != null ? '${when.day}/${when.month}/${when.year}' : noteDate;
    final time = isAsap ? '' : clean(bookingData['time']).isNotEmpty
        ? clean(bookingData['time'])
        : when != null ? '${two(when.hour)}:${two(when.minute)}' : noteTime;
    final txPlace = clean(tx['place']).isNotEmpty ? clean(tx['place']) : clean(tx['address']).isNotEmpty ? clean(tx['address']) : clean(tx['location']).isNotEmpty ? clean(tx['location']) : clean(tx['city']).isNotEmpty ? clean(tx['city']) : notePlace;
    final location = clean(bookingData['location']).isNotEmpty ? clean(bookingData['location']) : txPlace;
    final price = clean(bookingData['price']).isNotEmpty ? bookingData['price'] : clean(tx['amount']);
    final txMinutes = tx['durationMinutes'] is num ? (tx['durationMinutes'] as num).toInt() : int.tryParse('${tx['durationMinutes'] ?? ''}');
    final duration = clean(bookingData['duration']).isNotEmpty ? bookingData['duration'] : ApiService.formatDuration(txMinutes);
    final txMode = clean(tx['serviceMode']);
    final mode = clean(bookingData['mode']).isNotEmpty
        ? clean(bookingData['mode'])
        : txMode == 'customer_comes'
            ? (en ? 'Customer comes to provider' : 'Mteja anakuja kwa mtoa huduma')
            : txMode == 'provider_travels'
                ? (en ? 'Provider travels to customer' : 'Mtoa huduma anasafiri kwa mteja')
                : '';
    final address = clean(tx['customerAddress']).isNotEmpty
        ? clean(tx['customerAddress'])
        : clean(bookingData['address']).isNotEmpty ? clean(bookingData['address']) : txPlace;
    final image = (bookingData['image'] ?? '').toString();
    final ref = (bookingData['ref'] ?? '').toString();
    final isCancelled = status.contains('CANCEL');
    final isRejected = status.contains('REJECT');
    final isCompleted = status.contains('COMPLETE');
    final isRefunded = status.contains('REFUND');
    final isDisputed = status.contains('DISPUTE');
    final canCancel = ref.isNotEmpty && BookingCancel.canCancel(status);
    final badgeColor = PaymentFlow.isOpen(status)
        ? PaymentFlow.color(status)
        : (isCancelled || isRejected || isDisputed) ? AppColors.danger : isRefunded ? AppColors.textSecondary : (status.contains('PENDING') ? AppColors.warning : AppColors.success);
    final badgeLabel = PaymentFlow.isOpen(status)
        ? PaymentFlow.label(status)
        : isCancelled
        ? 'Cancelled'
        : isRejected
            ? 'Rejected'
            : isCompleted
                ? 'Completed'
                : isRefunded
                    ? 'Refunded'
                    : isDisputed
                        ? 'Disputed'
                        : (status.contains('PENDING') ? 'Pending' : 'Confirmed');

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Booking Details',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16, top: 12, bottom: 12),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: badgeColor,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon((isCancelled || isRejected) ? Icons.cancel_rounded : Icons.check_circle_rounded, color: Colors.white, size: 14),
                const SizedBox(width: 4),
                Text(
                  badgeLabel,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Real service photo only (nothing is shown when the service has none)
            if (image.isNotEmpty) ...[
              ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: AppImage(
                  image,
                  height: 160,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (ctx, err, stack) => Container(
                    height: 160,
                    color: AppColors.borderLight,
                    child: const Icon(Icons.image_outlined, size: 40, color: AppColors.textMuted),
                  ),
                ),
              ),
              const SizedBox(height: 16),
            ],

            if (payTx != null) ...[
              RequestProgress(tx: payTx),
              const SizedBox(height: 16),
            ],
            if (showPay) ...[
              PaymentFlowPanel(
                tx: payTx!,
                isBuyer: bookingData['isBuyer'] != false,
                onChanged: () => Navigator.pop(context, true), // list refreshes
              ),
              const SizedBox(height: 16),
            ],

            // Service Title & Provider info
            Text(
              serviceTitle,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                Text(
                  providerName,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: AppColors.primary,
                  ),
                ),
                const SizedBox(width: 4),
                const Icon(Icons.verified_rounded, size: 16, color: AppColors.primary),
              ],
            ),
            const SizedBox(height: 6),
            if (rating.isNotEmpty)
              Row(
                children: [
                  const Icon(Icons.star_rounded, size: 16, color: AppColors.goldStar),
                  const SizedBox(width: 4),
                  Text(
                    reviewsCount.isEmpty ? rating : '$rating ($reviewsCount reviews)',
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ],
              ),
            const SizedBox(height: 16),

            // Date, Time & Location Card (only the rows we really know)
            if (date.isNotEmpty || time.isNotEmpty || location.isNotEmpty || isAsap)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppColors.border),
                ),
                child: Column(
                  children: [
                    for (final r in <(IconData, String)>[
                      if (isAsap) (Icons.bolt_rounded, en ? 'As soon as possible' : 'Haraka iwezekanavyo'),
                      (Icons.calendar_today_outlined, date),
                      (Icons.access_time_rounded, time),
                      (Icons.location_on_outlined, location),
                    ].where((r) => r.$2.isNotEmpty).toList().asMap().entries)
                      Padding(
                        padding: EdgeInsets.only(top: r.key == 0 ? 0 : 10),
                        child: Row(
                          children: [
                            Icon(r.value.$1, size: 16, color: AppColors.textSecondary),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                r.value.$2,
                                style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            if (taskRows.isNotEmpty) ...[
              const SizedBox(height: 16),
              Text(
                en ? 'Tasks' : 'Kazi',
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
              ),
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppColors.border),
                ),
                child: Column(
                  children: [
                    for (final t in taskRows)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 5),
                        child: Row(
                          children: [
                            const Icon(Icons.task_alt_rounded, size: 16, color: AppColors.success),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(t.$1, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
                            ),
                            Text(t.$2, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            ],
            if (photoUrls.isNotEmpty) ...[
              const SizedBox(height: 16),
              Text(
                en ? 'Photos from the customer' : 'Picha kutoka kwa mteja',
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final u in photoUrls)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: SizedBox(
                        width: 88,
                        height: 88,
                        child: AppImage(
                          u,
                          fit: BoxFit.cover,
                          errorBuilder: (c, e, st) => Container(
                            color: AppColors.borderLight,
                            child: const Icon(Icons.image_not_supported_outlined, color: AppColors.textSecondary),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ],
            const SizedBox(height: 20),

            // Booking Information Section Table
            const Text(
              'Booking Information',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w800,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                children: [
                  _buildInfoRow('Service', serviceTitle),
                  _buildDivider(),
                  _buildInfoRow(bookingData['isBuyer'] == false ? (AppStrings.isEnglish ? 'Customer' : 'Mteja') : 'Provider', providerName),
                  if (clean(bookingData['verifiedName']).isNotEmpty) ...[
                    _buildDivider(),
                    _buildInfoRow(en ? 'Legal name' : 'Jina la kisheria', clean(bookingData['verifiedName'])),
                  ],
                  if (bookingData['isBuyer'] == false && bookingData['safeBadge'] == true)
                    Align(
                      alignment: Alignment.centerRight,
                      heightFactor: 1.6,
                      child: SafeBadge(buyer: BuyerInfo(name: providerName.toString(), safeBadge: true), compact: false),
                    ),
                  _buildDivider(),
                  _buildInfoRow('Price', price, isPrimary: true),
                  if (duration.toString().trim().isNotEmpty) ...[
                    _buildDivider(),
                    _buildInfoRow('Duration', duration),
                  ],
                  if (mode.isNotEmpty) ...[
                    _buildDivider(),
                    _buildInfoRow('Mode', mode),
                  ],
                  if (address.isNotEmpty) ...[
                    _buildDivider(),
                    _buildInfoRow('Address', address),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 16),

            _contactCard(context, tx, bookingData['isBuyer'] != false, status),

            // Track on map (a provider only gets the customer's location once the booking is confirmed)
            if (bookingData['hideMap'] != true)
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () {
                  final lat = (bookingData['providerLat'] as num?)?.toDouble();
                  final lng = (bookingData['providerLng'] as num?)?.toDouble();
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => MapTrackingScreen(
                        providerName: providerName.toString(),
                        serviceTitle: serviceTitle.toString(),
                        address: address.toString(),
                        providerLat: lat,
                        providerLng: lng,
                        providerId: int.tryParse((bookingData['providerId'] ?? '').toString()),
                        // Both people follow each other live once the booking is accepted (and paid).
                        bookingRef: ref.isNotEmpty && (status == 'ACCEPTED' || status == 'FUNDED') ? ref : null,
                        toCustomer: bookingData['isBuyer'] == false,
                      ),
                    ),
                  );
                },
                icon: const Icon(Icons.map_rounded, size: 18),
                label: Text(
                  AppStrings.isEnglish ? 'Track on Map' : 'Fuatilia kwenye Ramani',
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryLight,
                  foregroundColor: AppColors.primary,
                  elevation: 0,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ),
            const SizedBox(height: 12),

            // Action Buttons: Cancel Booking & Chat
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: canCancel
                        ? () async {
                            final done = await CancelBookingSheet.show(
                              context,
                              transactionRef: ref,
                              serviceTitle: serviceTitle.toString(),
                              status: status,
                            );
                            if (done == true && context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  backgroundColor: AppColors.danger,
                                  content: Text(AppStrings.isEnglish ? 'Booking cancelled' : 'Oda imeghairiwa'),
                                ),
                              );
                              Navigator.pop(context, true);
                            }
                          }
                        : null,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.danger,
                      disabledForegroundColor: AppColors.textDisabled,
                      side: BorderSide(color: canCancel ? AppColors.danger : AppColors.border),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    child: const Text(
                      'Cancel Booking',
                      style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    // Opens the chat with the other person in this booking
                    // (providerId always holds the other party: the provider for a buyer, the customer for a provider).
                    onPressed: () => ChatThreadScreen.open(
                      context,
                      recipientId: int.tryParse('${bookingData['providerId'] ?? ''}'),
                      name: (bookingData['chatName'] ?? providerName).toString(),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    child: const Text(
                      'Chat',
                      style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  /// Phone contact of the other person. Locked until the server shares it:
  /// a provider sees the customer's number after accepting; a buyer sees the provider's
  /// number after the provider accepts and the buyer has paid.
  Widget _contactCard(BuildContext context, Map<String, dynamic> tx, bool isBuyer, String status) {
    if (status.contains('CANCEL') || status.contains('REJECT')) return const SizedBox.shrink();
    final en = AppStrings.isEnglish;
    final accepted = status.contains('ACCEPTED') || status.contains('COMPLETE') || status.contains('RELEASED');
    final waitingPay = isBuyer && PaymentFlow.awaitingPayAfterAccept(tx);
    // The server decides (it also keeps contacts open after a dispute on an accepted booking); the status check is the fallback.
    final unlocked = tx['contactsUnlocked'] == true || (accepted && !waitingPay);

    String phone = '';
    if (unlocked) {
      final raw = tx[isBuyer ? 'seller' : 'buyer'];
      final party = raw is Map ? raw : const {};
      for (final v in [party['phone'], party['phoneNumber'], party['mobile'], tx[isBuyer ? 'sellerPhone' : 'buyerPhone'], tx['contactPhone']]) {
        final t = (v ?? '').toString().trim();
        if (t.isNotEmpty && t != 'null') {
          phone = t;
          break;
        }
      }
    }

    final String lockText = !accepted
        ? (isBuyer
            ? (en ? 'Contacts unlock after the provider accepts and you pay.' : 'Mawasiliano yanafunguka mtoa huduma akikubali na ukilipa.')
            : (en ? 'Accept the request to see the customer\'s contact.' : 'Kubali ombi ili uone mawasiliano ya mteja.'))
        : (en ? 'Pay to unlock the provider\'s phone number.' : 'Lipa ili kufungua namba ya simu ya mtoa huduma.');

    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
        child: unlocked && phone.isNotEmpty
            ? Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(en ? 'Contact' : 'Mawasiliano', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                  const SizedBox(height: 8),
                  Text(phone, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => launchUrl(Uri(scheme: 'tel', path: phone)),
                          icon: const Icon(Icons.call_rounded, size: 16),
                          label: Text(en ? 'Call' : 'Piga simu', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: AppColors.primary,
                            side: const BorderSide(color: AppColors.primary),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () {
                            Clipboard.setData(ClipboardData(text: phone));
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(en ? 'Number copied' : 'Namba imenakiliwa')));
                          },
                          icon: const Icon(Icons.copy_rounded, size: 16),
                          label: Text(en ? 'Copy' : 'Nakili', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: AppColors.textPrimary,
                            side: const BorderSide(color: AppColors.border),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                          ),
                        ),
                      ),
                    ],
                  ),
                  if (isBuyer) ..._providerExtras(tx, en),
                ],
              )
            : Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(unlocked ? Icons.phone_disabled_outlined : Icons.lock_outline_rounded, size: 18, color: AppColors.textMuted),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      unlocked ? (en ? 'Phone number not shared yet. Use Chat for now.' : 'Namba ya simu haijashirikiwa bado. Tumia Chat kwa sasa.') : lockText,
                      style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textSecondary),
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  /// The provider's WhatsApp, email and social links, released by the server together with the phone.
  /// Each one is shown only when it has a value; handles are cleaned so they cannot change the link's path.
  List<Widget> _providerExtras(Map<String, dynamic> tx, bool en) {
    String text(dynamic v) {
      final t = (v ?? '').toString().trim();
      return t == 'null' ? '' : t;
    }

    final socials = tx['sellerSocials'] is Map ? tx['sellerSocials'] as Map : const {};
    final wa = text(tx['sellerWhatsappPhone']).isNotEmpty ? text(tx['sellerWhatsappPhone']) : text(socials['whatsapp']);
    final email = text(tx['sellerEmail']);
    const bases = {
      'instagram': ('Instagram', 'https://instagram.com/'),
      'facebook': ('Facebook', 'https://facebook.com/'),
      'x': ('X', 'https://x.com/'),
      'tiktok': ('TikTok', 'https://tiktok.com/@'),
      'youtube': ('YouTube', 'https://youtube.com/@'),
    };
    final chips = <Widget>[];
    Widget chip(IconData icon, String label, Uri uri) => ActionChip(
          avatar: Icon(icon, size: 16, color: AppColors.primary),
          label: Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
          backgroundColor: Colors.white,
          side: const BorderSide(color: AppColors.border),
          onPressed: () => launchUrl(uri, mode: LaunchMode.externalApplication),
        );
    final digits = wa.replaceAll(RegExp(r'\D'), '');
    if (digits.isNotEmpty) chips.add(chip(Icons.chat_rounded, 'WhatsApp', Uri.parse('https://wa.me/$digits')));
    if (email.isNotEmpty && email.contains('@')) chips.add(chip(Icons.email_outlined, en ? 'Email' : 'Barua pepe', Uri(scheme: 'mailto', path: email)));
    bases.forEach((key, meta) {
      final handle = text(socials[key]).replaceFirst(RegExp(r'^@+'), '').replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '');
      if (handle.isNotEmpty) chips.add(chip(Icons.alternate_email_rounded, meta.$1, Uri.parse('${meta.$2}$handle')));
    });
    if (chips.isEmpty) return const [];
    return [
      const SizedBox(height: 10),
      Wrap(spacing: 8, runSpacing: 6, children: chips),
    ];
  }

  Widget _buildInfoRow(String label, String value, {bool isPrimary = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
          ),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.end,
              style: TextStyle(
                fontSize: 13,
                fontWeight: isPrimary ? FontWeight.w800 : FontWeight.w700,
                color: isPrimary ? AppColors.primary : AppColors.textPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDivider() {
    return const Divider(height: 1, color: AppColors.borderLight);
  }
}
