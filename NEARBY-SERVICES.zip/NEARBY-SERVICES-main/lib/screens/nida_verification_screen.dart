import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../security/input_validation.dart';
import '../models/id_kinds.dart';
import '../services/api_service.dart';
import '../services/session_manager.dart';
import '../widgets/app_ui.dart';
import 'accept_invitation_screen.dart';
import 'invite_trusted_screen.dart';
import 'provider_documents_screen.dart';
import 'request_vouch_screen.dart';
import 'verify_business_screen.dart';

/// Where the provider's identity verification stands. Everything shown here is
/// real: the badge from the account and the status of each uploaded document
/// as reviewed by the server. The "Upload documents" button opens the
/// Documents screen, where the photos are actually taken and uploaded.
class NidaVerificationScreen extends StatefulWidget {
  const NidaVerificationScreen({super.key});

  @override
  State<NidaVerificationScreen> createState() => _NidaVerificationScreenState();
}

enum _DocState { approved, pending, rejected, missing }

class _NidaVerificationScreenState extends State<NidaVerificationScreen> {
  bool _loading = true;
  bool _loadFailed = false;
  // document type -> state reported by the server
  final Map<String, _DocState> _server = {};

  // Legal name as on the ID (a claim; the server verifies it against the ID)
  final _nameCtl = TextEditingController();
  final _ninCtl = TextEditingController(); // the 20-digit NIN, saved with the name; never kept on the phone
  String? _nameError;
  String? _ninError;
  String? _nameReason;
  bool _savingName = false;

  bool get _isEn => AppStrings.isEnglish;

  @override
  void initState() {
    super.initState();
    _nameCtl.text = SessionManager.getIdFullName();
    _load();
  }

  @override
  void dispose() {
    _nameTimer?.cancel();
    _nameCtl.dispose();
    _ninCtl.dispose();
    super.dispose();
  }

  Future<void> _saveName() async {
    if (_savingName) return;
    final err = InputValidation.name(_nameCtl.text);
    final clean = InputValidation.cleanText(_nameCtl.text);
    if (err == null && !clean.contains(' ')) {
      setState(() => _nameError = _isEn ? 'Enter your legal name (at least first and last name).' : 'Weka jina lako la kisheria (angalau la kwanza na la mwisho).');
      return;
    }
    if (err != null) {
      setState(() => _nameError = err);
      return;
    }
    final ninErr = InputValidation.nin(_ninCtl.text);
    if (ninErr != null) {
      setState(() => _ninError = ninErr);
      return;
    }
    setState(() {
      _nameError = null;
      _ninError = null;
      _savingName = true;
    });
    final e = await ApiService.submitFullName(clean, nin: InputValidation.digitsOf(_ninCtl.text));
    if (!mounted) return;
    setState(() {
      _savingName = false;
      _nameError = e == null ? null : InputValidation.safeServerMessage(e);
    });
    if (e == null) {
      _ninCtl.clear(); // do not keep the NIN in memory longer than needed
      // The server may have matched the name to the NIN record at once (status VERIFIED).
      final nowVerified = SessionManager.getVerifiedNameStatus() == 'VERIFIED';
      setState(() {});
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(nowVerified
            ? (_isEn ? 'Your legal name is verified. It matches your NIN.' : 'Jina lako la kisheria limethibitishwa. Linalingana na NIN yako.')
            : (_isEn ? 'Name saved. It is checked against your ID.' : 'Jina limehifadhiwa. Linahakikiwa dhidi ya kitambulisho chako.')),
      ));
    }
  }

  Future<void> _load() async {
    _nameTries = 0; // a refresh starts the wait again
    _nameGaveUp = false;
    setState(() => _loading = true);
    final list = await ApiService.fetchVerificationDocuments();
    final nameRes = await ApiService.fetchVerifiedName();
    if (!mounted) return;
    setState(() {
      _nameReason = nameRes?.reason;
      if (_nameCtl.text.trim().isEmpty && SessionManager.getIdFullName().isNotEmpty) _nameCtl.text = SessionManager.getIdFullName();
      _loadFailed = list == null;
      _server.clear();
      for (final e in list ?? const []) {
        if (e is Map && e['type'] != null) {
          final s = (e['status'] ?? 'PENDING').toString().toUpperCase();
          _server[e['type'].toString()] = (s == 'APPROVED' || s == 'VERIFIED')
              ? _DocState.approved
              : (s == 'REJECTED' ? _DocState.rejected : _DocState.pending);
        }
      }
      _loading = false;
    });
    // Legal name follows the ID front/back (selfie not needed): remember it, then wait for the server.
    if (list != null) {
      final kind = IdKinds.byId(SessionManager.getIdKind());
      final idOk = _group(['id_front', if (kind.hasBack) 'id_back']) == _DocState.approved;
      await SessionManager.saveIdDocsApproved(idOk);
      if (!mounted) return;
      setState(() {});
    }
    _watchLegalName();
  }

  Timer? _nameTimer;
  int _nameTries = 0;
  // The server did not fill the legal name from the ID in time: let the user fill it in.
  bool _nameGaveUp = false;

  /// While the server is confirming the legal name with the ID, re-check every few seconds
  /// (up to ~1 minute) so the card turns Verified without a manual pull-down.
  void _watchLegalName() {
    _nameTimer?.cancel();
    if (!SessionManager.isLegalNameConfirming()) {
      _nameTries = 0;
      return;
    }
    if (_nameTries >= 12) {
      if (!_nameGaveUp && mounted) setState(() => _nameGaveUp = true);
      return;
    }
    _nameTimer = Timer(const Duration(seconds: 5), () async {
      _nameTries++;
      await ApiService.fetchVerifiedName();
      if (!mounted) return;
      setState(() {});
      _watchLegalName();
    });
  }

  _DocState _stateOf(String type) {
    final s = _server[type];
    if (s != null) return s;
    return SessionManager.getSubmittedDocs().contains(type) ? _DocState.pending : _DocState.missing;
  }

  /// Worst state wins: a rejected or missing photo means the group needs action.
  _DocState _group(List<String> types) {
    final states = types.map(_stateOf).toList();
    if (states.contains(_DocState.rejected)) return _DocState.rejected;
    if (states.contains(_DocState.missing)) return _DocState.missing;
    if (states.contains(_DocState.pending)) return _DocState.pending;
    return _DocState.approved;
  }

  Future<void> _openDocuments() async {
    // Step 1 first: the legal name and NIN are saved before the ID photos are uploaded.
    final nameStatus = SessionManager.getVerifiedNameStatus();
    final saved = nameStatus == 'VERIFIED' || (nameStatus != 'NONE' && SessionManager.isNinSaved());
    if (!saved && !SessionManager.isIdentityVerified()) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(_isEn ? 'First save your legal name and NIN, then upload your ID.' : 'Kwanza hifadhi jina lako la kisheria na NIN, kisha pakia kitambulisho.'),
      ));
      return;
    }
    await Navigator.push(context, MaterialPageRoute(builder: (_) => const ProviderDocumentsScreen()));
    if (mounted) _load();
  }

  Future<void> _openInvitation() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => const AcceptInvitationScreen()));
    if (mounted) setState(() {}); // the badge may have changed
  }

  @override
  Widget build(BuildContext context) {
    final badge = SessionManager.getBadge();
    final verified = SessionManager.isIdentityVerified();
    final hasBlue = badge == 'BLUE_TICK';
    final kind = IdKinds.byId(SessionManager.getIdKind());
    final idState = verified ? _DocState.approved : _group(['id_front', if (kind.hasBack) 'id_back']);
    final selfieState = _stateOf('selfie_with_id');
    final faceState = _stateOf('face_photo');
    final hasPhone = SessionManager.getPhone().trim().isNotEmpty;
    final accent = verified ? AppColors.success : AppColors.warningDark;

    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _isEn ? 'Verify your identity' : 'Thibitisha utambulisho wako',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
          child: Column(
            children: [
              Center(
                child: Container(
                  width: 72,
                  height: 72,
                  decoration: BoxDecoration(color: verified ? AppColors.primary : AppColors.textMuted, shape: BoxShape.circle),
                  child: const Icon(Icons.verified_user_rounded, color: Colors.white, size: 40),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                _isEn ? 'Identity Verification' : 'Uthibitisho wa Utambulisho',
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: accent.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: accent.withValues(alpha: 0.3)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(verified ? Icons.check_circle_rounded : Icons.info_outline_rounded, size: 14, color: accent),
                    const SizedBox(width: 4),
                    Text(
                      verified ? (_isEn ? 'Verified' : 'Imethibitishwa') : (_isEn ? 'Not verified yet' : 'Bado haijathibitishwa'),
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: accent),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Text(
                verified
                    ? (hasBlue
                        ? (_isEn
                            ? 'Identity verified (Green Badge) and your business is verified (Blue). You can invite people you trust.'
                            : 'Utambulisho umethibitishwa (Green Badge) na biashara yako imethibitishwa (Blue). Unaweza kualika unaowaamini.')
                        : (_isEn
                            ? 'Your identity is verified (Green Badge). You can invite people you trust. Get Verified Business to earn the Blue badge.'
                            : 'Utambulisho wako umethibitishwa (Green Badge). Unaweza kualika unaowaamini. Pata Biashara Iliyothibitishwa upate beji ya Blue.'))
                    : (_isEn
                        ? 'Upload the front and back of your ID, plus a selfie holding it, to get the Green Badge. Or ask a verified provider who knows you to invite you.'
                        : 'Pakia picha za mbele na nyuma za kitambulisho chako, na selfie ukikishika, upate Green Badge. Au mwombe mtoa huduma aliyethibitishwa anayekujua akualike.'),
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, height: 1.4),
              ),
              const SizedBox(height: 24),
              _nameCard(),
              const SizedBox(height: 24),
              if (_loading)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 24),
                  child: CircularProgressIndicator(color: AppColors.primary),
                )
              else ...[
                if (_loadFailed)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Text(
                      _isEn
                          ? 'Could not load the latest status. Pull down to try again.'
                          : 'Imeshindwa kupata hali ya sasa. Vuta chini kujaribu tena.',
                      style: const TextStyle(fontSize: 12, color: AppColors.danger),
                    ),
                  ),
                Container(
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Column(
                    children: [
                      _checklistItem(
                        icon: kind.icon,
                        iconColor: AppColors.primary,
                        title: kind.title(_isEn),
                        state: idState,
                        missingText: kind.hasBack
                            ? (_isEn ? 'Front and back needed' : 'Mbele na nyuma zinahitajika')
                            : (_isEn ? 'Photo page needed' : 'Ukurasa wa picha unahitajika'),
                      ),
                      const Divider(height: 1, indent: 56, color: AppColors.borderLight),
                      _checklistItem(
                        icon: Icons.face_rounded,
                        iconColor: AppColors.primary,
                        title: _isEn ? 'Selfie holding your ID' : 'Selfie ukishika kitambulisho',
                        state: selfieState,
                      ),
                      const Divider(height: 1, indent: 56, color: AppColors.borderLight),
                      _checklistItem(
                        icon: Icons.face_retouching_natural_rounded,
                        iconColor: AppColors.primary,
                        title: _isEn ? 'Face photo (optional)' : 'Picha ya uso (hiari)',
                        state: faceState,
                        missingText: _isEn ? 'Optional' : 'Hiari',
                      ),
                      const Divider(height: 1, indent: 56, color: AppColors.borderLight),
                      _checklistItem(
                        icon: Icons.phone_android_rounded,
                        iconColor: const Color(0xFF10B981),
                        title: _isEn ? 'Phone number' : 'Namba ya simu',
                        state: hasPhone ? _DocState.approved : _DocState.missing,
                        approvedText: _isEn ? 'Added' : 'Imewekwa',
                        missingText: _isEn ? 'Not added' : 'Haijawekwa',
                      ),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 24),
              if (verified)
                AppButton.primary(
                  label: _isEn ? 'Invite someone you trust' : 'Alika unayemwamini',
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const InviteTrustedScreen())),
                )
              else ...[
                AppButton.primary(
                  label: _isEn ? 'Upload documents' : 'Pakia nyaraka',
                  onPressed: _openDocuments,
                ),
                const SizedBox(height: 10),
                AppButton.outlined(
                  label: _isEn ? 'I have an invitation' : 'Nina mwaliko',
                  onPressed: _openInvitation,
                ),
                const SizedBox(height: 10),
                AppButton.outlined(
                  label: _isEn ? 'Ask a verified provider to vouch for me' : 'Omba mtoa huduma aliyethibitishwa anithibitishe',
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RequestVouchScreen())),
                ),
              ],
              const SizedBox(height: 12),
              AppButton.outlined(
                label: _isEn ? 'Run a business? Get Verified Business (Blue)' : 'Una biashara? Pata Biashara Iliyothibitishwa (Blue)',
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const VerifyBusinessScreen())),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.primaryLight.withValues(alpha: 0.5),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.primary.withValues(alpha: 0.2)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.info_outline_rounded, color: AppColors.primary, size: 20),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        _isEn
                            ? 'Your verification data is protected and only visible to trusted systems.'
                            : 'Taarifa zako za uthibitisho zinalindwa na zinaonekana kwa mifumo inayoaminika tu.',
                        style: const TextStyle(fontSize: 12, color: AppColors.textPrimary, height: 1.35),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  /// Legal name as written on the ID. Once the server verifies it, it is read-only and is the
  /// "legal name" providers see on bookings (only while Hide My ID is off).
  Widget _nameCard() {
    final status = SessionManager.getVerifiedNameStatus();
    final verified = status == 'VERIFIED';
    // ID front/back approved: the server confirms the legal name with the ID by itself, so no typing.
    final confirming = SessionManager.isLegalNameConfirming() && !_nameGaveUp;
    final Color color = verified
        ? AppColors.success
        : (status == 'REJECTED' ? AppColors.danger : (status == 'PENDING' ? AppColors.warningDark : AppColors.textMuted));
    final String label = verified
        ? (_isEn ? 'Verified' : 'Imethibitishwa')
        : confirming
            ? (_isEn ? 'Confirming with your ID' : 'Inathibitishwa na kitambulisho')
            : (status == 'PENDING'
            ? (_isEn ? 'Under review' : 'Inakaguliwa')
            : (status == 'REJECTED' ? (_isEn ? 'Does not match your ID' : 'Halilingani na kitambulisho') : (_isEn ? 'Not saved yet' : 'Bado halijahifadhiwa')));
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  _isEn ? 'Step 1 · Legal name and NIN' : 'Hatua 1 · Jina la kisheria na NIN',
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                ),
              ),
              Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: color)),
            ],
          ),
          const SizedBox(height: 10),
          if (verified)
            Text(
              SessionManager.getVerifiedName().isNotEmpty ? SessionManager.getVerifiedName() : _nameCtl.text,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
            )
          else if (confirming)
            Text(
              _isEn
                  ? 'Your ID is verified, so your legal name is taken from your ID automatically. Pull down to refresh.'
                  : 'Kitambulisho chako kimethibitishwa, kwa hiyo jina lako la kisheria linachukuliwa kutoka kitambulisho chako moja kwa moja. Vuta chini kusasisha.',
              style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textSecondary),
            )
          else ...[
            if (_nameGaveUp)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Text(
                  _isEn
                      ? 'We could not take your name from your ID yet. Fill in your legal name and we will check it.'
                      : 'Hatukuweza kuchukua jina lako kutoka kitambulisho bado. Jaza jina lako la kisheria nasi tutalihakiki.',
                  style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textSecondary),
                ),
              ),
            AppTextField(
              controller: _nameCtl,
              icon: Icons.person_outline_rounded,
              hint: 'Amina Juma Mwanga',
              keyboardType: TextInputType.name,
              errorText: _nameError,
              enabled: !_savingName,
              maxLength: InputValidation.nameMax,
            ),
            const SizedBox(height: 4),
            AppTextField(
              controller: _ninCtl,
              icon: Icons.badge_outlined,
              hint: '00000000000000000000',
              keyboardType: TextInputType.number,
              errorText: _ninError,
              enabled: !_savingName,
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
                LengthLimitingTextInputFormatter(InputValidation.ninLength),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              _isEn ? 'Your 20-digit NIN stays private. Customers only see your stage name.' : 'NIN yako ya tarakimu 20 ni siri. Wateja wanaona jina lako la kazi pekee.',
              style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
            ),
            if (status == 'REJECTED' && (_nameReason ?? '').isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(_nameReason!, style: const TextStyle(fontSize: 12, color: AppColors.danger)),
              ),
            const SizedBox(height: 10),
            AppButton.primary(
              label: _isEn ? 'Save name' : 'Hifadhi jina',
              loading: _savingName,
              onPressed: _savingName ? null : _saveName,
            ),
          ],
        ],
      ),
    );
  }

  Widget _checklistItem({
    required IconData icon,
    required Color iconColor,
    required String title,
    required _DocState state,
    String? approvedText,
    String? missingText,
  }) {
    final String text;
    final Color color;
    final IconData stateIcon;
    switch (state) {
      case _DocState.approved:
        text = approvedText ?? (_isEn ? 'Verified' : 'Imethibitishwa');
        color = AppColors.success;
        stateIcon = Icons.check_circle_rounded;
      case _DocState.pending:
        text = _isEn ? 'Under review' : 'Inakaguliwa';
        color = AppColors.warningDark;
        stateIcon = Icons.hourglass_top_rounded;
      case _DocState.rejected:
        text = _isEn ? 'Rejected - upload again' : 'Imekataliwa - pakia tena';
        color = AppColors.danger;
        stateIcon = Icons.cancel_rounded;
      case _DocState.missing:
        text = missingText ?? (_isEn ? 'Not uploaded' : 'Haijapakiwa');
        color = AppColors.textMuted;
        stateIcon = Icons.remove_circle_outline_rounded;
    }
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: iconColor.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: iconColor, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
            ),
          ),
          Flexible(
            child: Text(
              text,
              textAlign: TextAlign.end,
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: color),
            ),
          ),
          const SizedBox(width: 8),
          Icon(stateIcon, color: color, size: 18),
        ],
      ),
    );
  }
}
