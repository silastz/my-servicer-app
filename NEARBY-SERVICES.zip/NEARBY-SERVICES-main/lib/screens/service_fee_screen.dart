import '../services/app_policy.dart';
import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/payment_methods_service.dart';
import '../services/session_manager.dart';
import '../widgets/app_ui.dart';
import '../widgets/country_code_picker.dart';
import '../widgets/card_payment_dialog.dart';
import 'registration_fee_screen.dart' show MaskedPhone, MobileWaitDialog;
import '../services/currency_service.dart';

/// "Pay Now" page for ONE extra service.
/// The provider's registration fee covers the first [freeLimit] services; every service after
/// that needs its own fee. Pops with `true` once the fee is paid (the server then holds one credit).
class ServiceFeeScreen extends StatefulWidget {
  final String serviceTitle;
  final double? amount;
  final int used;
  final int freeLimit;

  ServiceFeeScreen({
    super.key,
    required this.serviceTitle,
    this.amount,
    this.used = 0,
    int? freeLimit,
  }) : freeLimit = freeLimit ?? SessionManager.freeServiceLimit;

  @override
  State<ServiceFeeScreen> createState() => _ServiceFeeScreenState();
}

class _ServiceFeeScreenState extends State<ServiceFeeScreen> {
  String _method = 'mobile_money'; // mobile_money | card
  final TextEditingController _phoneCtrl = TextEditingController();
  String? _phoneError;
  bool _busy = false;
  bool _paid = false;
  late final double _amount;

  bool get _isEn => AppStrings.isEnglish;

  @override
  void initState() {
    super.initState();
    final a = widget.amount;
    _amount = (a != null && a > 0 && a <= 1000000) ? a : SessionManager.serviceFee.toDouble();
    _phoneCtrl.text = SessionManager.getPhone();
  }

  @override
  void dispose() {
    _phoneCtrl.dispose();
    super.dispose();
  }

  String _money(num v) =>
      CurrencyService.format(v);

  Future<void> _payNow() async {
    if (_busy || _paid) return;
    final messenger = ScaffoldMessenger.of(context);
    final userId = SessionManager.getUserIdValue();
    final reference = 'SVCFEE-$userId-${DateTime.now().millisecondsSinceEpoch}-'
        '${(DateTime.now().microsecondsSinceEpoch % 9973).toRadixString(36)}';
    bool paid = false;

    if (_method == 'mobile_money') {
      final normalized = PaymentMethodsService.normalizeTzNumber(_phoneCtrl.text);
      if (normalized == null) {
        setState(() => _phoneError = CurrencyService.badNumberMessage(_isEn));
        return;
      }
      setState(() {
        _phoneError = null;
        _busy = true;
      });
      final res = await ApiService.requestMobilePayment(
        amount: _amount,
        purpose: 'SERVICE_FEE',
        reference: reference,
        phone: '+$normalized',
      );
      if (!mounted) return;
      if (res == null) {
        setState(() => _busy = false);
        messenger.showSnackBar(SnackBar(
          backgroundColor: AppColors.danger,
          content: Text(ApiService.lastPaymentError ??
              (_isEn ? 'Could not send the payment request. Try again.' : 'Imeshindwa kutuma ombi la malipo. Jaribu tena.')),
        ));
        return;
      }
      final ref = (res['reference'] ?? reference).toString();
      paid = await showDialog<bool>(
            context: context,
            barrierDismissible: false,
            builder: (_) => MobileWaitDialog(reference: ref, phone: MaskedPhone.of(normalized)),
          ) ??
          false;
    } else {
      setState(() => _busy = true);
      paid = await CardPayment.pay(
        context,
        amount: _amount,
        purpose: 'SERVICE_FEE',
        reference: reference,
        description: 'Service fee',
        phone: SessionManager.getPhone().isEmpty ? null : SessionManager.getPhone(),
      );
    }

    if (!mounted) return;
    setState(() => _busy = false);
    if (!paid) {
      messenger.showSnackBar(SnackBar(
        backgroundColor: AppColors.warningDark,
        content: Text(_isEn ? 'Payment was not completed.' : 'Malipo hayakukamilika.'),
      ));
      return;
    }
    // The gateway dialog alone is not proof: ask the server whether it now holds the credit.
    final status = await ApiService.getServiceFeeStatus();
    if (!mounted) return;
    // Unreachable server (null) or still "needs payment" = not confirmed yet.
    if (status == null || status['needsPayment'] != false) {
      messenger.showSnackBar(SnackBar(
        backgroundColor: AppColors.warningDark,
        content: Text(_isEn
            ? 'Payment received but not confirmed yet. Try publishing again in a minute.'
            : 'Malipo yamepokelewa lakini hayajathibitishwa bado. Jaribu kuchapisha tena baada ya dakika moja.'),
      ));
      return;
    }
    setState(() => _paid = true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: _busy ? null : () => Navigator.pop(context, _paid),
        ),
        title: Text(
          _isEn ? 'Service fee' : 'Ada ya huduma',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: PopScope(
        canPop: false,
        onPopInvokedWithResult: (didPop, _) {
          if (!didPop && !_busy) Navigator.pop(context, _paid);
        },
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _feeCard(),
            const SizedBox(height: 14),
            _whyCard(),
            const SizedBox(height: 20),
            if (_paid) _paidState() else ..._payForm(),
          ],
        ),
      ),
    );
  }

  Widget _feeCard() {
    final title = widget.serviceTitle.trim();
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(color: AppColors.primaryLight, borderRadius: BorderRadius.circular(10)),
            child: const Icon(Icons.design_services_rounded, color: AppColors.primary, size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title.isEmpty ? (_isEn ? 'New service' : 'Huduma mpya') : title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontWeight: FontWeight.w500),
                ),
                const SizedBox(height: 2),
                Text(_money(_amount),
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppColors.textPrimary)),
                const SizedBox(height: 2),
                Text(_isEn ? 'Fee for this service' : 'Ada ya huduma hii',
                    style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
              ],
            ),
          ),
          StatusPill(
            text: _paid ? (_isEn ? 'Paid' : 'Imelipwa') : (_isEn ? 'Unpaid' : 'Haijalipwa'),
            color: _paid ? AppColors.successDark : AppColors.warningDark,
          ),
        ],
      ),
    );
  }

  Widget _whyCard() {
    final n = widget.freeLimit;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.primaryLight,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.primary.withValues(alpha: 0.15)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.info_outline_rounded, size: 18, color: AppColors.primary),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              _isEn
                  ? 'Your registration fee covers $n services, and you have posted ${widget.used}. Each extra service has its own fee.'
                  : 'Ada yako ya usajili inatosha huduma $n, na umeshaweka ${widget.used}. Kila huduma ya ziada ina ada yake.',
              style: const TextStyle(fontSize: 12, color: AppColors.primaryDark, height: 1.4),
            ),
          ),
        ],
      ),
    );
  }

  Widget _paidState() {
    return Column(
      children: [
        const SizedBox(height: 24),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: const BoxDecoration(color: AppColors.successLight, shape: BoxShape.circle),
          child: const Icon(Icons.check_circle_rounded, color: AppColors.success, size: 54),
        ),
        const SizedBox(height: 14),
        Text(_isEn ? 'Fee paid' : 'Ada imelipwa',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
        const SizedBox(height: 6),
        Text(
          _isEn ? 'Your service will be published now.' : 'Huduma yako itachapishwa sasa.',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
        ),
        const SizedBox(height: 24),
        AppButton.primary(label: _isEn ? 'Continue' : 'Endelea', onPressed: () => Navigator.pop(context, true)),
      ],
    );
  }

  List<Widget> _payForm() {
    return [
      Text(
        _isEn ? 'Choose how to pay' : 'Chagua njia ya kulipa',
        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
      ),
      const SizedBox(height: 12),
      _option(
        id: 'mobile_money',
        icon: Icons.phone_android_rounded,
        color: AppColors.successDark,
        title: _isEn ? 'Mobile Money' : 'Pesa za Simu (Mobile Money)',
        subtitle: 'M-Pesa • Airtel Money • Tigo Pesa • Halopesa',
      ),
      if (_method == 'mobile_money') ...[
        const SizedBox(height: 12),
        AppTextField(
          controller: _phoneCtrl,
          icon: Icons.phone_outlined,
          keyboardType: TextInputType.phone,
          hint: '07XX XXX XXX',
          label: _isEn ? 'Number to pay with' : 'Namba ya kulipia',
          prefix: const AccountCountryCode(),
          errorText: _phoneError,
        ),
        const SizedBox(height: 6),
        Text(
          _isEn
              ? 'You will get a prompt on this phone to confirm with your PIN.'
              : 'Utapata ujumbe kwenye simu hii kuthibitisha kwa PIN yako.',
          style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
        ),
      ],
      const SizedBox(height: 10),
      if (AppPolicy.cardPaymentsEnabled)
      _option(
        id: 'card',
        icon: Icons.credit_card_rounded,
        color: AppColors.categoryBlue,
        title: _isEn ? 'Card' : 'Kadi (Card)',
        subtitle: 'Visa • Mastercard',
      ),
      if (_method == 'card') ...[
        const SizedBox(height: 8),
        Text(
          _isEn
              ? 'You will pay on a secure card page. We never see or store your card details.'
              : 'Utalipa kwenye ukurasa salama wa kadi. Hatuoni wala kuhifadhi taarifa za kadi yako.',
          style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
        ),
      ],
      const SizedBox(height: 20),
      AppButton.primary(
        label: _isEn ? 'Pay ${_money(_amount)}' : 'Lipa ${_money(_amount)}',
        loading: _busy,
        onPressed: _busy ? null : _payNow,
      ),
    ];
  }

  Widget _option({
    required String id,
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
  }) {
    final selected = _method == id;
    return InkWell(
      onTap: _busy ? null : () => setState(() => _method = id),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: selected ? AppColors.primary : AppColors.border, width: selected ? 1.5 : 1),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, color: color, size: 22),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                  const SizedBox(height: 2),
                  Text(subtitle, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                ],
              ),
            ),
            Container(
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: selected ? AppColors.primary : AppColors.border, width: selected ? 6 : 2),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
