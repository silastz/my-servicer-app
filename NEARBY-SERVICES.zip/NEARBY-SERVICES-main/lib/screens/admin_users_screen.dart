import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../services/api_service.dart';
import '../widgets/admin_common.dart';

/// Admin: manage user accounts. Server: GET /admin/users?q=&status=&role=&page=&size=, GET /admin/users/{id},
/// POST /admin/users/{id}/suspend {reason}, POST /admin/users/{id}/reactivate, POST /admin/users/{id}/delete.
/// Admin accounts cannot be suspended or deleted (the server refuses with ADMIN_ACCOUNT).
class AdminUsersScreen extends StatefulWidget {
  const AdminUsersScreen({super.key});

  @override
  State<AdminUsersScreen> createState() => _AdminUsersScreenState();
}

class _AdminUsersScreenState extends State<AdminUsersScreen> {
  static const _pageSize = 30;
  static const _statuses = ['ACTIVE', 'SUSPENDED', 'DELETED'];

  final _searchCtrl = TextEditingController();
  String? _status; // null = all
  bool _loading = true;
  bool _loadingMore = false;
  bool _hasMore = false;
  bool _forbidden = false;
  bool _failed = false;
  int _page = 0;
  List<Map<String, dynamic>> _items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  String _path(int page) {
    final q = _searchCtrl.text.trim();
    final b = StringBuffer('/admin/users?size=$_pageSize&page=$page');
    if (_status != null) b.write('&status=$_status');
    if (q.isNotEmpty) b.write('&q=${Uri.encodeQueryComponent(q)}');
    return b.toString();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _failed = false;
      _page = 0;
    });
    final r = await ApiService.adminGetList(_path(0));
    if (!mounted) return;
    setState(() {
      _loading = false;
      _forbidden = r.forbidden;
      _failed = !r.forbidden && r.items == null;
      _items = r.items ?? [];
      _hasMore = (r.items?.length ?? 0) >= _pageSize;
    });
  }

  Future<void> _loadMore() async {
    if (_loadingMore) return;
    setState(() => _loadingMore = true);
    final r = await ApiService.adminGetList(_path(_page + 1));
    if (!mounted) return;
    setState(() {
      _loadingMore = false;
      if (r.items != null) {
        _page += 1;
        _items = [..._items, ...r.items!];
        _hasMore = r.items!.length >= _pageSize;
      }
    });
    if (r.items == null) adminSnack(context, adminT('Could not load more.', 'Imeshindwa kupakia zaidi.'));
  }

  Color _color(String s) => switch (s) {
        'ACTIVE' => AppColors.successDark,
        'SUSPENDED' => AppColors.warningDark,
        _ => AppColors.textSecondary,
      };

  String _label(String s) => switch (s) {
        'ACTIVE' => adminT('Active', 'Hai'),
        'SUSPENDED' => adminT('Suspended', 'Imesimamishwa'),
        'DELETED' => adminT('Deleted', 'Imefutwa'),
        _ => s,
      };

  String _roleLabel(String? r) => switch (r) {
        'ROLE_ADMIN' => adminT('Admin', 'Msimamizi'),
        'ROLE_SELLER' => adminT('Provider', 'Mtoa huduma'),
        'ROLE_BUYER' => adminT('Customer', 'Mteja'),
        _ => r ?? '',
      };

  Future<void> _suspend(Map<String, dynamic> m) async {
    final reason = await adminPrompt(
      context,
      title: adminT('Suspend ${m['stageName']}?', 'Simamisha ${m['stageName']}?'),
      hint: adminT('Reason (required, kept for your records)', 'Sababu (lazima, inahifadhiwa kwa kumbukumbu)'),
      required: true,
    );
    if (reason == null || !mounted) return;
    await _run('/admin/users/${m['id']}/suspend', {'reason': reason}, adminT('Account suspended', 'Akaunti imesimamishwa'));
  }

  Future<void> _reactivate(Map<String, dynamic> m) async {
    final ok = await _confirm(
      adminT('Reactivate ${m['stageName']}?', 'Rudisha ${m['stageName']}?'),
      adminT('They will be able to sign in again.', 'Ataweza kuingia tena.'),
      adminT('Reactivate', 'Rudisha'),
    );
    if (ok != true || !mounted) return;
    await _run('/admin/users/${m['id']}/reactivate', null, adminT('Account reactivated', 'Akaunti imerudishwa'));
  }

  Future<void> _delete(Map<String, dynamic> m) async {
    final ok = await _confirm(
      adminT('Delete ${m['stageName']} for good?', 'Futa ${m['stageName']} kabisa?'),
      adminT(
        'Name, phone, email, photos and ID papers are erased. This cannot be undone. It is refused while the wallet holds money or a booking is open.',
        'Jina, simu, barua pepe, picha na vitambulisho vinafutwa. Hili halirudishwi. Halitafanyika wakati wallet ina pesa au kuna ombi linaloendelea.',
      ),
      adminT('Delete', 'Futa'),
      danger: true,
    );
    if (ok != true || !mounted) return;
    await _run('/admin/users/${m['id']}/delete', null, adminT('Account deleted', 'Akaunti imefutwa'));
  }

  Future<void> _run(String path, Map<String, dynamic>? body, String doneText) async {
    final res = await ApiService.adminSend('POST', path, body);
    if (!mounted) return;
    if (res.error != null) {
      adminSnack(context, res.error!);
      return;
    }
    adminSnack(context, doneText);
    _load();
  }

  Future<bool?> _confirm(String title, String text, String action, {bool danger = false}) {
    return showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(text),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(adminT('Cancel', 'Ghairi'))),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(action, style: danger ? const TextStyle(color: AppColors.dangerDark) : null),
          ),
        ],
      ),
    );
  }

  Future<void> _openDetail(Map<String, dynamic> m) async {
    final r = await ApiService.adminGetObject('/admin/users/${m['id']}');
    if (!mounted) return;
    final d = r.data ?? m; // fall back to the list row when the detail could not be read
    final status = '${d['status']}';
    final isAdmin = d['role'] == 'ROLE_ADMIN';
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            Text('${d['stageName'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
            const SizedBox(height: 6),
            adminInfoLine('ID', d['id']),
            adminInfoLine(adminT('Username', 'Jina la mtumiaji'), d['username']),
            adminInfoLine(adminT('Phone', 'Simu'), d['phone']),
            adminInfoLine(adminT('Email', 'Barua pepe'), d['email']),
            adminInfoLine(adminT('Role', 'Aina'), _roleLabel(d['role'] as String?)),
            adminInfoLine(adminT('Badge', 'Alama'), d['verificationBadge']),
            adminInfoLine(adminT('Country', 'Nchi'), d['country']),
            adminInfoLine(adminT('Services', 'Huduma'), d['activeServices'] == null ? null : '${d['activeServices']} / ${d['servicesPosted']}'),
            adminInfoLine(adminT('Wallet', 'Wallet'), d['walletBalance'] == null ? null : '${d['walletBalance']} ${d['currency'] ?? ''}'),
            adminInfoLine(adminT('In escrow', 'Kwenye escrow'), d['walletLocked']),
            adminInfoLine(adminT('Joined', 'Alijiunga'), d['createdAt']),
            adminInfoLine(adminT('Status', 'Hali'), _label(status)),
            adminInfoLine(adminT('Suspended', 'Alisimamishwa'), d['suspendedAt']),
            adminInfoLine(adminT('Reason', 'Sababu'), d['suspendReason']),
            adminInfoLine(adminT('Deleted', 'Alifutwa'), d['deletedAt']),
            const SizedBox(height: 14),
            if (isAdmin)
              Text(adminT('Admin accounts cannot be changed here.', 'Akaunti za wasimamizi haziwezi kubadilishwa hapa.'),
                  style: const TextStyle(color: AppColors.textSecondary, fontSize: 13))
            else if (status == 'DELETED')
              Text(adminT('This account was deleted.', 'Akaunti hii imefutwa.'),
                  style: const TextStyle(color: AppColors.textSecondary, fontSize: 13))
            else
              Wrap(spacing: 8, runSpacing: 8, children: [
                if (status == 'SUSPENDED')
                  FilledButton.icon(
                    onPressed: () {
                      Navigator.pop(ctx);
                      _reactivate(d);
                    },
                    icon: const Icon(Icons.lock_open_rounded, size: 18),
                    label: Text(adminT('Reactivate', 'Rudisha')),
                  )
                else
                  FilledButton.icon(
                    style: FilledButton.styleFrom(backgroundColor: AppColors.warningDark),
                    onPressed: () {
                      Navigator.pop(ctx);
                      _suspend(d);
                    },
                    icon: const Icon(Icons.block_rounded, size: 18),
                    label: Text(adminT('Suspend', 'Simamisha')),
                  ),
                OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(foregroundColor: AppColors.dangerDark),
                  onPressed: () {
                    Navigator.pop(ctx);
                    _delete(d);
                  },
                  icon: const Icon(Icons.delete_outline_rounded, size: 18),
                  label: Text(adminT('Delete', 'Futa')),
                ),
              ]),
          ]),
        ),
      ),
    );
  }

  Widget _card(Map<String, dynamic> m) {
    final status = '${m['status']}';
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: () => _openDetail(m),
      child: Container(
        margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
        padding: const EdgeInsets.all(14),
        decoration: adminCardDecoration(),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(
              child: Text('${m['stageName'] ?? ''}',
                  maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
              decoration: BoxDecoration(color: _color(status).withValues(alpha: 0.12), borderRadius: BorderRadius.circular(20)),
              child: Text(_label(status), style: TextStyle(color: _color(status), fontWeight: FontWeight.w700, fontSize: 11)),
            ),
          ]),
          adminInfoLine('#${m['id']}', _roleLabel(m['role'] as String?)),
          adminInfoLine(adminT('Phone', 'Simu'), m['phone']),
          adminInfoLine(adminT('Email', 'Barua pepe'), m['email']),
          if (status == 'SUSPENDED') adminInfoLine(adminT('Reason', 'Sababu'), m['suspendReason']),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = adminStateOrNull(
      loading: _loading,
      forbidden: _forbidden,
      failed: _failed,
      empty: _items.isEmpty,
      onRetry: _load,
      emptyText: adminT('No users match.', 'Hakuna watumiaji wanaolingana.'),
    );
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text(adminT('Users', 'Watumiaji'))),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
          child: TextField(
            controller: _searchCtrl,
            textInputAction: TextInputAction.search,
            onSubmitted: (_) => _load(),
            decoration: InputDecoration(
              hintText: adminT('Name, phone, email or ID', 'Jina, simu, barua pepe au ID'),
              prefixIcon: const Icon(Icons.search_rounded),
              suffixIcon: IconButton(
                icon: const Icon(Icons.close_rounded),
                onPressed: () {
                  _searchCtrl.clear();
                  _load();
                },
              ),
            ),
          ),
        ),
        SizedBox(
          height: 52,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            children: [
              for (final s in [null, ..._statuses])
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(s == null ? adminT('All', 'Wote') : _label(s)),
                    selected: _status == s,
                    onSelected: (_) {
                      _status = s;
                      _load();
                    },
                  ),
                ),
            ],
          ),
        ),
        Expanded(
          child: RefreshIndicator(
            onRefresh: _load,
            child: state != null
                ? ListView(children: [SizedBox(height: 400, child: state)])
                : ListView(padding: const EdgeInsets.only(bottom: 24), children: [
                    for (final m in _items) _card(m),
                    if (_hasMore)
                      Padding(
                        padding: const EdgeInsets.only(top: 12),
                        child: Center(
                          child: _loadingMore
                              ? const CircularProgressIndicator()
                              : TextButton(onPressed: _loadMore, child: Text(adminT('Load more', 'Pakia zaidi'))),
                        ),
                      ),
                  ]),
          ),
        ),
      ]),
    );
  }
}
