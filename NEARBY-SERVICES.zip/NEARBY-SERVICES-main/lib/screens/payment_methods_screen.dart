import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/payment_methods_service.dart';
import '../widgets/app_ui.dart';
import '../widgets/country_code_picker.dart';
import '../services/currency_service.dart';

/// Buyer: choose how to pay (mobile money numbers + card) and pick a default.
class PaymentMethodsScreen extends StatefulWidget {
  const PaymentMethodsScreen({super.key});

  @override
  State<PaymentMethodsScreen> createState() => _PaymentMethodsScreenState();
}

class _PaymentMethodsScreenState extends State<PaymentMethodsScreen> {
  Map<String, String> _numbers = {};
  String? _default;
  bool _loading = true;

  bool get _isEn => AppStrings.isEnglish;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final numbers = await PaymentMethodsService.loadNumbers();
    final def = await PaymentMethodsService.loadDefault();
    if (!mounted) return;
    setState(() {
      _numbers = numbers;
      _default = def;
      _loading = false;
    });
  }

  bool _isAdded(PaymentMethodInfo m) => m.isMobileMoney ? _numbers.containsKey(m.id) : true;

  Future<void> _editNumber(PaymentMethodInfo m) async {
    final ctrl = TextEditingController(text: _numbers[m.id] == null ? '' : '0${_numbers[m.id]!.substring(3)}');
    String? error;
    final saved = await AppSheet.show<String>(
      context,
      title: _isEn ? '${m.nameEn} number' : 'Namba ya ${m.nameSw}',
      subtitle: _isEn
          ? 'The number you pay from. Only you can see it on this device.'
          : 'Namba unayolipia kutoka. Ni wewe tu unayeiona kwenye simu hii.',
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => Column(
          children: [
            AppTextField(
              controller: ctrl,
              icon: m.icon,
              keyboardType: TextInputType.phone,
              prefix: CountryCodePicker(value: CurrencyService.current.plusDial, enabled: false, showIcon: false, onChanged: (_) {}),
              hint: '07XX XXX XXX',
              errorText: error,
            ),
            const SizedBox(height: 20),
            AppButton.primary(
              label: _isEn ? 'Save' : 'Hifadhi',
              onPressed: () {
                final normalized = PaymentMethodsService.normalizeTzNumber(ctrl.text);
                if (normalized == null) {
                  setD(() => error = CurrencyService.badNumberMessage(_isEn));
                  return;
                }
                Navigator.pop(ctx, normalized);
              },
            ),
          ],
        ),
      ),
    );
    if (saved != null) {
      await PaymentMethodsService.saveNumber(m.id, saved);
      await _load();
    }
  }

  Future<void> _confirmRemove(PaymentMethodInfo m) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(_isEn ? 'Remove ${m.nameEn}?' : 'Ondoa ${m.nameSw}?',
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        content: Text(_isEn ? 'You can add it again at any time.' : 'Unaweza kuiongeza tena wakati wowote.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(_isEn ? 'Cancel' : 'Ghairi')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(_isEn ? 'Remove' : 'Ondoa', style: const TextStyle(color: AppColors.danger)),
          ),
        ],
      ),
    );
    if (ok == true) {
      await PaymentMethodsService.remove(m.id);
      await _load();
    }
  }

  Future<void> _makeDefault(PaymentMethodInfo m) async {
    await PaymentMethodsService.setDefault(m.id);
    await _load();
  }

  void _openOptions(PaymentMethodInfo m) {
    final added = _isAdded(m);
    final isDefault = _default == m.id;
    AppSheet.show<void>(
      context,
      title: _isEn ? m.nameEn : m.nameSw,
      builder: (ctx) => Column(
        children: [
          if (m.isMobileMoney)
            _sheetRow(
              icon: added ? Icons.edit_outlined : Icons.add_circle_outline_rounded,
              label: added ? (_isEn ? 'Change number' : 'Badilisha namba') : (_isEn ? 'Add number' : 'Weka namba'),
              onTap: () {
                Navigator.pop(ctx);
                _editNumber(m);
              },
            ),
          if (added && !isDefault)
            _sheetRow(
              icon: Icons.check_circle_outline_rounded,
              label: _isEn ? 'Set as default' : 'Weka kama chaguo kuu',
              onTap: () {
                Navigator.pop(ctx);
                _makeDefault(m);
              },
            ),
          if (m.isMobileMoney && added)
            _sheetRow(
              icon: Icons.delete_outline_rounded,
              label: _isEn ? 'Remove' : 'Ondoa',
              color: AppColors.danger,
              onTap: () {
                Navigator.pop(ctx);
                _confirmRemove(m);
              },
            ),
          if (!m.isMobileMoney)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Text(
                _isEn
                    ? 'Card details are never stored in this app. You enter them on the secure payment page when you pay.'
                    : 'Taarifa za kadi hazihifadhiwi kwenye programu hii. Unaziweka kwenye ukurasa salama wa malipo unapolipa.',
                style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textSecondary),
              ),
            ),
        ],
      ),
    );
  }

  Widget _sheetRow({required IconData icon, required String label, required VoidCallback onTap, Color? color}) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Icon(icon, color: color ?? AppColors.textPrimary),
      title: Text(label, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: color ?? AppColors.textPrimary)),
      onTap: onTap,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _isEn ? 'Payment Methods' : 'Njia za Malipo',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.primaryLight.withValues(alpha: 0.6),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.primary.withValues(alpha: 0.2)),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(Icons.shield_outlined, color: AppColors.primary, size: 20),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          _isEn
                              ? 'Your payment is held safely until the service is completed, then released to the provider.'
                              : 'Malipo yako yanashikiliwa salama hadi huduma ikamilike, kisha yanapelekwa kwa mtoa huduma.',
                          style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textPrimary),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Container(
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Column(
                    children: [
                      for (var i = 0; i < PaymentMethodsService.visibleMethods.length; i++) ...[
                        _methodTile(PaymentMethodsService.visibleMethods[i]),
                        if (i < PaymentMethodsService.visibleMethods.length - 1)
                          const Divider(height: 1, indent: 64, color: AppColors.borderLight),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  _isEn
                      ? 'Tap a method to add, change or remove it. The default method is selected first when you book.'
                      : 'Gusa njia kuiongeza, kuibadilisha au kuiondoa. Chaguo kuu huchaguliwa kwanza unapooda.',
                  style: const TextStyle(fontSize: 11, height: 1.4, color: AppColors.textSecondary),
                ),
              ],
            ),
    );
  }

  Widget _methodTile(PaymentMethodInfo m) {
    final added = _isAdded(m);
    final isDefault = _default == m.id && added;
    final String subtitle;
    if (m.isMobileMoney) {
      subtitle = added
          ? PaymentMethodsService.mask(_numbers[m.id]!)
          : (_isEn ? 'Not added' : 'Haijawekwa');
    } else {
      subtitle = _isEn ? 'Pay securely at checkout' : 'Lipa salama wakati wa malipo';
    }
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      onTap: () => _openOptions(m),
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(color: m.color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10)),
        child: Icon(m.icon, color: m.color, size: 22),
      ),
      title: Text(
        _isEn ? m.nameEn : m.nameSw,
        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
      ),
      subtitle: Text(
        subtitle,
        style: TextStyle(fontSize: 11, color: added ? AppColors.textSecondary : AppColors.textMuted),
      ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (isDefault) StatusPill(text: _isEn ? 'Default' : 'Kuu', color: AppColors.primary),
          if (!added) StatusPill(text: _isEn ? 'Add' : 'Ongeza', color: AppColors.primary),
          const SizedBox(width: 4),
          const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted, size: 20),
        ],
      ),
    );
  }
}
