import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/app_policy.dart';
import '../services/app_policy_service.dart';
import '../widgets/app_ui.dart';

/// Admin: how many minutes a sent sign-up / password-reset code stays "pending" in the app.
/// If the user closes the app and reopens it within this time, typing the same phone/email goes straight to
/// the code screen instead of sending another SMS. The code itself still lives 10 minutes on the server.
///
/// Only a remote control: the server checks every call (403 for non-admins) and validates the range.
class AdminOtpSettingsScreen extends StatefulWidget {
  const AdminOtpSettingsScreen({super.key});

  @override
  State<AdminOtpSettingsScreen> createState() => _AdminOtpSettingsScreenState();
}

class _AdminOtpSettingsScreenState extends State<AdminOtpSettingsScreen> {
  final _ctrl = TextEditingController();
  bool _loading = true;
  bool _forbidden = false;
  bool _loadFailed = false;
  bool _saving = false;
  int? _saved; // what the server uses now
  String? _error;

  bool get _isEn => AppStrings.isEnglish;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _loadFailed = false;
    });
    final r = await ApiService.getAdminOtpPendingMinutes();
    if (!mounted) return;
    setState(() {
      _loading = false;
      _forbidden = r.forbidden;
      _loadFailed = !r.forbidden && r.minutes == null;
      _saved = r.minutes;
      if (r.minutes != null) _ctrl.text = r.minutes.toString();
    });
  }

  int? get _minutes => int.tryParse(_ctrl.text.trim());

  bool get _changed {
    final m = _minutes;
    return _saved != null && m != null && m != _saved;
  }

  Future<void> _save() async {
    final m = _minutes;
    if (m == null || m < AppPolicy.otpPendingMin || m > AppPolicy.otpPendingMax) {
      setState(() => _error = _isEn
          ? 'Enter ${AppPolicy.otpPendingMin} to ${AppPolicy.otpPendingMax} minutes'
          : 'Weka dakika ${AppPolicy.otpPendingMin} hadi ${AppPolicy.otpPendingMax}');
      return;
    }
    setState(() => _saving = true);
    final messenger = ScaffoldMessenger.of(context);
    final res = await ApiService.setAdminOtpPendingMinutes(m);
    if (!mounted) return;
    setState(() => _saving = false);
    if (res == null) {
      final err = ApiService.lastAdminError;
      messenger.showSnackBar(SnackBar(
        content: Text(err == 'forbidden'
            ? (_isEn ? 'Only an admin can change this.' : 'Ni msimamizi pekee anayeweza kubadilisha hili.')
            : err == 'network'
                ? (_isEn ? 'No connection. Nothing was changed.' : 'Hakuna mtandao. Hakuna kilichobadilishwa.')
                : (_isEn ? 'Could not save. Nothing was changed.' : 'Imeshindwa kuhifadhi. Hakuna kilichobadilishwa.')),
      ));
      return;
    }
    setState(() {
      _saved = res;
      _ctrl.text = res.toString();
    });
    AppPolicyService.refresh(force: true);
    messenger.showSnackBar(SnackBar(
      content: Text(_isEn ? 'Pending time saved: $res min.' : 'Muda wa kusubiri umehifadhiwa: dakika $res.'),
    ));
  }

  Widget _note(String text, {Color color = AppColors.primary, IconData icon = Icons.info_outline_rounded}) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withValues(alpha: 0.2)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 12.5, height: 1.4, color: AppColors.textPrimary))),
        ],
      ),
    );
  }

  Widget _body() {
    if (_loading) return const Center(child: CircularProgressIndicator(color: AppColors.primary));
    if (_forbidden) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: _note(
            _isEn ? 'This account is not an admin, so it cannot change this setting.' : 'Akaunti hii si ya msimamizi, kwa hiyo haiwezi kubadilisha mpangilio huu.',
            color: AppColors.danger,
            icon: Icons.lock_outline_rounded,
          ),
        ),
      );
    }
    if (_loadFailed) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(_isEn ? 'Could not load the current setting.' : 'Imeshindwa kupakia mpangilio wa sasa.',
                textAlign: TextAlign.center, style: const TextStyle(fontSize: 14, color: AppColors.textSecondary)),
            const SizedBox(height: 16),
            AppButton.primary(label: _isEn ? 'Try again' : 'Jaribu tena', onPressed: _load),
          ]),
        ),
      );
    }
    final m = _minutes;
    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewInsets.bottom),
            children: [
              _note(_isEn
                  ? 'When a sign-up or password-reset code is sent, the app remembers it for this many minutes. If the user closes the app and comes back in time, typing the same phone number or email takes them straight to the code screen, with no new SMS. After that, a new code is sent as usual.'
                  : 'Namba ya uthibitisho (sign-up au kubadilisha nenosiri) ikitumwa, app inaikumbuka kwa dakika hizi. Mtumiaji akifunga app na kurudi ndani ya muda, akiandika namba ya simu au barua pepe ile ile anapelekwa moja kwa moja kwenye ukurasa wa kuweka namba, bila SMS mpya. Baada ya hapo, namba mpya hutumwa kama kawaida.'),
              const SizedBox(height: 14),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.border),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_isEn ? 'Pending minutes' : 'Dakika za kusubiri',
                        style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w800, color: AppColors.primaryDark)),
                    const SizedBox(height: 2),
                    Text(
                      _isEn
                          ? '${AppPolicy.otpPendingMin} to ${AppPolicy.otpPendingMax} minutes (a code is valid for 10). Default ${AppPolicy.otpPendingDefault}.'
                          : 'Dakika ${AppPolicy.otpPendingMin} hadi ${AppPolicy.otpPendingMax} (namba hudumu dakika 10). Kawaida ${AppPolicy.otpPendingDefault}.',
                      style: const TextStyle(fontSize: 11.5, height: 1.4, color: AppColors.textSecondary),
                    ),
                    const SizedBox(height: 12),
                    AppTextField(
                      controller: _ctrl,
                      icon: Icons.timer_outlined,
                      keyboardType: TextInputType.number,
                      hint: '${AppPolicy.otpPendingDefault}',
                      errorText: _error,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(2)],
                      onChanged: (_) => setState(() => _error = null),
                    ),
                    if (m != null && m >= AppPolicy.otpPendingMin && m <= AppPolicy.otpPendingMax) ...[
                      const SizedBox(height: 10),
                      Text(
                        _isEn
                            ? 'Reopen within $m min and type the same phone/email: the code screen opens again.'
                            : 'Ukirudi ndani ya dakika $m na kuandika namba/barua pepe ile ile: ukurasa wa namba unafunguka tena.',
                        style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textSecondary),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: SizedBox(
              width: double.infinity,
              child: AppButton.primary(
                label: _isEn ? 'Save' : 'Hifadhi',
                loading: _saving,
                onPressed: _changed && !_saving ? _save : null,
              ),
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: _saving ? null : () => Navigator.pop(context),
        ),
        title: Text(_isEn ? 'Code Pending Time' : 'Muda wa Namba ya OTP',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(color: AppColors.borderLight, height: 1)),
      ),
      body: _body(),
    );
  }
}
