import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart' show CameraDevice;
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/id_kinds.dart';
import '../services/api_service.dart';
import '../services/media_picker.dart';
import '../services/session_manager.dart';
import '../widgets/app_ui.dart';
import 'verify_business_screen.dart';

class _DocType {
  final String id;
  final String titleEn;
  final String titleSw;
  final String hintEn;
  final String hintSw;
  final IconData icon;
  final bool required;

  /// Face checks are taken live with the front camera (no gallery).
  final bool cameraOnly;
  const _DocType(this.id, this.titleEn, this.titleSw, this.hintEn, this.hintSw, this.icon,
      {this.required = true, this.cameraOnly = false});
}

/// Documents a provider uploads to finish their profile / get verified:
/// an identity document (front and back), a face check, and an optional
/// professional certificate. Business papers are handled in Verified Business.
class ProviderDocumentsScreen extends StatefulWidget {
  const ProviderDocumentsScreen({super.key});

  /// Required document ids (used by the profile checklist). A passport has no
  /// back side, so it only needs the front.
  static List<String> get requiredIds => [
        'id_front',
        if (IdKinds.byId(SessionManager.getIdKind()).hasBack) 'id_back',
        'selfie_with_id',
      ];

  @override
  State<ProviderDocumentsScreen> createState() => _ProviderDocumentsScreenState();
}

class _ProviderDocumentsScreenState extends State<ProviderDocumentsScreen> {
  static const _faceDocs = <_DocType>[
    _DocType('face_photo', 'Face photo', 'Picha ya uso',
        'Look straight at the camera in good light. No hat or sunglasses.',
        'Tazama kamera moja kwa moja mwangaza mzuri. Bila kofia au miwani.', Icons.face_retouching_natural_rounded,
        required: false, cameraOnly: true),
    _DocType('selfie_with_id', 'Selfie holding your ID', 'Picha yako ukishika kitambulisho',
        'Your face and the ID must both be readable', 'Uso wako na kitambulisho vionekane vizuri', Icons.face_rounded,
        cameraOnly: true),
  ];

  /// Skills papers belong to the person. Business papers (TIN, licence, BRELA) live in Verified Business.
  static const _certDocs = <_DocType>[
    _DocType('certificate', 'Professional certificate', 'Cheti cha ujuzi',
        'Optional - training or trade certificate', 'Hiari - cheti cha mafunzo au ufundi', Icons.workspace_premium_outlined,
        required: false),
  ];

  late String _kind = SessionManager.getIdKind();

  /// Front (and back, when the document has one) of the chosen ID.
  List<_DocType> get _idDocs {
    final k = IdKinds.byId(_kind);
    return [
      _DocType('id_front', k.hasBack ? '${k.en} - front' : '${k.en} - photo page',
          k.hasBack ? '${k.sw} - mbele' : '${k.sw} - ukurasa wa picha',
          'Clear photo, all four corners visible', 'Picha wazi, pembe zote nne zionekane', k.icon),
      if (k.hasBack)
        _DocType('id_back', '${k.en} - back', '${k.sw} - nyuma',
            'Clear photo, no glare', 'Picha wazi, bila mng\'ao', k.icon),
    ];
  }

  bool _loading = true;
  bool _loadFailed = false;
  String? _uploading;
  // type -> {status, reason}
  final Map<String, Map<String, String>> _server = {};

  bool get _isEn => AppStrings.isEnglish;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final list = await ApiService.fetchVerificationDocuments();
    if (!mounted) return;
    setState(() {
      _loadFailed = list == null;
      _server.clear();
      for (final e in list ?? const []) {
        if (e is Map && e['type'] != null) {
          _server[e['type'].toString()] = {
            'status': (e['status'] ?? 'PENDING').toString().toUpperCase(),
            'reason': (e['reason'] ?? '').toString(),
          };
        }
      }
      _loading = false;
    });
  }

  /// MISSING | PENDING | APPROVED | REJECTED
  String _statusOf(String id) {
    final s = _server[id]?['status'];
    if (s != null) {
      if (s == 'APPROVED' || s == 'VERIFIED') return 'APPROVED';
      if (s == 'REJECTED') return 'REJECTED';
      return 'PENDING';
    }
    return SessionManager.getSubmittedDocs().contains(id) ? 'PENDING' : 'MISSING';
  }

  Future<void> _pickAndUpload(_DocType doc) async {
    final messenger = ScaffoldMessenger.of(context);
    final isId = doc.id == 'id_front' || doc.id == 'id_back';
    final file = await MediaPicker.pickImage(
      context,
      title: _isEn ? doc.titleEn : doc.titleSw,
      cameraOnly: doc.cameraOnly,
      preferredCamera: doc.cameraOnly ? CameraDevice.front : CameraDevice.rear,
      maxWidth: doc.cameraOnly ? 1280 : 1800,
    );
    if (file == null || !mounted) return;

    setState(() => _uploading = doc.id);
    final res = await ApiService.uploadVerificationDocument(
      type: doc.id,
      filePath: file.path,
      idKind: isId ? _kind : null,
    );
    if (res.ok) await SessionManager.addSubmittedDoc(doc.id);
    if (!mounted) return;
    setState(() => _uploading = null);
    messenger.showSnackBar(SnackBar(
      backgroundColor: res.ok ? AppColors.success : AppColors.danger,
      content: Text(res.ok
          ? (_isEn ? 'Uploaded. We will review it shortly.' : 'Imepakiwa. Tutaipitia hivi karibuni.')
          : (res.error ?? (_isEn ? 'Upload failed. Check your connection and try again.' : 'Imeshindwa kupakia. Angalia mtandao kisha jaribu tena.'))),
    ));
    if (res.ok) _load();
  }

  @override
  Widget build(BuildContext context) {
    final requiredIds = ProviderDocumentsScreen.requiredIds;
    final done = requiredIds.where((id) => _statusOf(id) != 'MISSING').length;
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _isEn ? 'Documents' : 'Nyaraka',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _isEn ? '$done of ${requiredIds.length} required documents sent' : 'Nyaraka $done kati ya ${requiredIds.length} zimetumwa',
                          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                        ),
                        const SizedBox(height: 10),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(6),
                          child: LinearProgressIndicator(
                            value: done / requiredIds.length,
                            minHeight: 8,
                            backgroundColor: AppColors.borderLight,
                            color: AppColors.primary,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          _isEn
                              ? 'Upload clear photos of your documents to finish your profile and earn a verified badge.'
                              : 'Pakia picha wazi za nyaraka zako ili kukamilisha wasifu na kupata alama ya uthibitisho.',
                          style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textSecondary),
                        ),
                      ],
                    ),
                  ),
                  if (_loadFailed) ...[
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColors.warningLight,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        _isEn
                            ? 'Could not load your document status. Pull down to try again.'
                            : 'Imeshindwa kupakia hali ya nyaraka zako. Vuta chini ujaribu tena.',
                        style: const TextStyle(fontSize: 12, color: AppColors.warningDark),
                      ),
                    ),
                  ],
                  const SizedBox(height: 16),
                  _section(
                    title: _isEn ? 'Identity document' : 'Kitambulisho',
                    subtitle: _isEn
                        ? 'Choose the ID you will use, then add a photo of each side.'
                        : 'Chagua kitambulisho utakachotumia, kisha weka picha ya kila upande.',
                    header: _idKindPicker(),
                    docs: _idDocs,
                  ),
                  const SizedBox(height: 16),
                  _section(
                    title: _isEn ? 'Face verification' : 'Uthibitisho wa uso',
                    subtitle: _isEn
                        ? 'Taken live with the camera so we know it is really you.'
                        : 'Hupigwa moja kwa moja kwa kamera ili tujue ni wewe kweli.',
                    docs: _faceDocs,
                  ),
                  const SizedBox(height: 16),
                  _section(
                    title: _isEn ? 'Certificates' : 'Vyeti',
                    subtitle: _isEn ? 'Optional, but they help customers trust you.' : 'Hiari, lakini zinasaidia wateja kukuamini.',
                    docs: _certDocs,
                  ),
                  const SizedBox(height: 16),
                  _businessLink(),
                  const SizedBox(height: 14),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(Icons.lock_outline_rounded, size: 16, color: AppColors.textSecondary),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          _isEn
                              ? 'Your documents are only used for verification and are never shown to customers.'
                              : 'Nyaraka zako zinatumika kwa uthibitisho tu na hazionyeshwi kwa wateja.',
                          style: const TextStyle(fontSize: 11, height: 1.4, color: AppColors.textSecondary),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
    );
  }

  /// Points business owners to the one place where business papers are uploaded.
  Widget _businessLink() {
    return Material(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const VerifyBusinessScreen())),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.border)),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(color: AppColors.warningLight, borderRadius: BorderRadius.circular(12)),
                child: const Icon(Icons.business_center_rounded, size: 21, color: AppColors.warningDark),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_isEn ? 'Run a business?' : 'Una biashara?',
                        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                    const SizedBox(height: 2),
                    Text(
                      _isEn ? 'Add your TIN and business licence in Verified Business.' : 'Weka TIN na leseni ya biashara kwenye Biashara Iliyothibitishwa.',
                      style: const TextStyle(fontSize: 11.5, height: 1.4, color: AppColors.textSecondary),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted),
            ],
          ),
        ),
      ),
    );
  }

  /// A heading on the page background, then a card holding a group of document tiles.
  Widget _section({
    required String title,
    required String subtitle,
    required List<_DocType> docs,
    Widget? header,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(2, 0, 2, 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
              const SizedBox(height: 2),
              Text(subtitle, style: const TextStyle(fontSize: 11.8, height: 1.4, color: AppColors.textSecondary)),
            ],
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.border),
          ),
          clipBehavior: Clip.antiAlias,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (header != null) header,
              for (var i = 0; i < docs.length; i++) ...[
                if (i > 0 || header != null) const Divider(height: 1, color: AppColors.borderLight),
                _docTile(docs[i]),
              ],
            ],
          ),
        ),
      ],
    );
  }

  /// NIDA / Voter ID / Driving licence / Passport. Locked once a photo of the
  /// current ID is under review or approved, so the kind always matches it.
  Widget _idKindPicker() {
    final locked = _statusOf('id_front') == 'PENDING' || _statusOf('id_front') == 'APPROVED';
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 4,
            children: [
              for (final k in IdKinds.all)
                ChoiceChip(
                  label: Text(k.title(_isEn), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: _kind == k.id ? Colors.white : AppColors.textPrimary)),
                  selected: _kind == k.id,
                  selectedColor: AppColors.primary,
                  showCheckmark: false,
                  onSelected: (locked || _uploading != null)
                      ? null
                      : (_) async {
                          setState(() => _kind = k.id);
                          await SessionManager.saveIdKind(k.id);
                        },
                ),
            ],
          ),
          if (locked)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(
                _isEn ? 'Your ID is being reviewed, so its type cannot be changed now.' : 'Kitambulisho chako kinakaguliwa, kwa hiyo aina haiwezi kubadilishwa sasa.',
                style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
              ),
            ),
        ],
      ),
    );
  }

  Widget _docTile(_DocType d) {
    final status = _statusOf(d.id);
    final busy = _uploading == d.id;
    final reason = _server[d.id]?['reason'] ?? '';

    late final String label;
    late final Color color;
    switch (status) {
      case 'APPROVED':
        label = _isEn ? 'Approved' : 'Imekubaliwa';
        color = AppColors.successDark;
        break;
      case 'PENDING':
        label = _isEn ? 'Under review' : 'Inakaguliwa';
        color = AppColors.warningDark;
        break;
      case 'REJECTED':
        label = _isEn ? 'Rejected' : 'Imekataliwa';
        color = AppColors.danger;
        break;
      default:
        label = d.required ? (_isEn ? 'Required' : 'Inahitajika') : (_isEn ? 'Optional' : 'Hiari');
        color = AppColors.textSecondary;
    }

    final canUpload = status == 'MISSING' || status == 'REJECTED';
    final rejected = status == 'REJECTED';
    return Padding(
      padding: const EdgeInsets.all(14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(color: AppColors.primaryLight, borderRadius: BorderRadius.circular(12)),
            child: Icon(d.icon, color: AppColors.primary, size: 21),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_isEn ? d.titleEn : d.titleSw,
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                const SizedBox(height: 2),
                Text(_isEn ? d.hintEn : d.hintSw,
                    style: const TextStyle(fontSize: 11.5, height: 1.4, color: AppColors.textSecondary)),
                if (rejected && reason.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Text(reason,
                        style: const TextStyle(fontSize: 11.5, height: 1.4, fontWeight: FontWeight.w600, color: AppColors.danger)),
                  ),
                const SizedBox(height: 7),
                StatusPill(text: label, color: color),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: busy
                ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.primary))
                : (canUpload
                    ? FilledButton(
                        onPressed: _uploading == null ? () => _pickAndUpload(d) : null,
                        style: FilledButton.styleFrom(
                          backgroundColor: rejected ? AppColors.danger : AppColors.primary,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
                          padding: const EdgeInsets.symmetric(horizontal: 14),
                          minimumSize: const Size(0, 38),
                        ),
                        child: Text(
                          rejected ? (_isEn ? 'Re-upload' : 'Pakia tena') : (_isEn ? 'Upload' : 'Pakia'),
                          style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800, color: Colors.white),
                        ),
                      )
                    : Icon(status == 'APPROVED' ? Icons.check_circle_rounded : Icons.hourglass_bottom_rounded,
                        color: color, size: 24)),
          ),
        ],
      ),
    );
  }
}
