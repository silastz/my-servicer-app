import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:geolocator/geolocator.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import '../services/session_manager.dart';
import '../services/need_signals.dart';
import '../widgets/login_modal.dart';
import '../widgets/app_image.dart';
import '../services/currency_service.dart';
import '../services/app_log.dart';

class BookingRequestScreen extends StatefulWidget {
  final ServiceItem provider;
  final String serviceTitle;
  final String priceText;
  final String durationText;

  /// Set when the seller agreed to a price offer: the booking is made at this price
  /// and [offerId] lets the server check it (the server, not this app, decides the amount).
  final int? agreedAmount;
  final String? offerId;

  const BookingRequestScreen({
    super.key,
    required this.provider,
    required this.serviceTitle,
    required this.priceText,
    required this.durationText,
    this.agreedAmount,
    this.offerId,
  });

  @override
  State<BookingRequestScreen> createState() => _BookingRequestScreenState();
}

class _BookingRequestScreenState extends State<BookingRequestScreen> {
  DateTime _selectedDateTime = DateTime.now().add(const Duration(days: 1));
  TimeOfDay _selectedTimeOfDay = const TimeOfDay(hour: 10, minute: 0);
  /// Where the service happens, from what the provider set (null when they didn't say).
  String? get _locationOption {
    final en = AppStrings.isEnglish;
    switch (widget.provider.serviceMode) {
      case 'customer_comes':
        return en ? 'You visit the provider' : 'Unamtembelea mtoa huduma';
      case 'provider_travels':
        return en ? 'Provider comes to you' : 'Mtoa huduma anakufuata';
      case 'both':
        return en ? 'Visit them or they come to you' : 'Mnaweza kukutana popote';
      default:
        return null;
    }
  }
  final TextEditingController _noteController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();

  /// The customer's phone position is saved with the request as a safety record (scam and dispute reports).
  /// Only admins can read it; the provider never sees it. It is on by default and the customer can switch it off.
  bool _shareLocation = true;

  /// Current position, or null when the phone has no permission / no fix; the booking never waits long or fails for it.
  Future<Position?> _currentPosition() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) return null;
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) return null;
      return await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 8)),
      );
    } catch (caught, trace) {
      AppLog.e('booking_request_screen._currentPosition', caught, trace);
      return await Geolocator.getLastKnownPosition().catchError((_) => null);
    }
  }

  /// The customer's own address is asked only when the provider can come to them.
  bool get _asksAddress =>
      widget.provider.serviceMode == 'provider_travels' || widget.provider.serviceMode == 'both';

  /// What this booking costs: the agreed offer price, else the service's current price.
  /// With tasks, the total of the picked ones (the server works the same sum out again).
  double get _amount {
    if (widget.agreedAmount != null) return widget.agreedAmount!.toDouble();
    if (_usesTasks) return _pickedTasks.fold<int>(0, (a, t) => a + t.price).toDouble();
    return widget.provider.priceAmount.toDouble();
  }
  bool get _hasAgreedPrice => widget.agreedAmount != null && (widget.offerId ?? '').isNotEmpty;

  /// Tasks are picked only when the provider listed some and no agreed offer price is being used.
  bool get _usesTasks => widget.provider.tasks.isNotEmpty && !_hasAgreedPrice;
  final Set<int> _selectedTasks = {0};
  List<ServiceTask> get _pickedTasks {
    final idx = _selectedTasks.toList()..sort();
    return [for (final i in idx) if (i < widget.provider.tasks.length) widget.provider.tasks[i]];
  }

  /// The price shown on the summary and the send button.
  String get _shownPrice => _usesTasks ? CurrencyService.format(_amount) : widget.priceText;

  /// "As soon as possible": no date and time are sent.
  bool _asap = false;

  /// Photos of the job the customer attached (local files; uploaded when the request is sent).
  final List<String> _photoPaths = [];
  final ImagePicker _picker = ImagePicker();

  /// Camera takes one photo; gallery can add several, up to 5 in total.
  Future<void> _addPhotos(ImageSource source) async {
    final room = 5 - _photoPaths.length;
    if (room <= 0) return;
    try {
      final List<XFile> picked;
      if (source == ImageSource.camera || room == 1) {
        final x = await _picker.pickImage(source: source, imageQuality: 80, maxWidth: 1600);
        picked = x == null ? const [] : [x];
      } else {
        // image_picker requires limit >= 2, so a single free slot uses pickImage above.
        picked = await _picker.pickMultiImage(imageQuality: 80, maxWidth: 1600, limit: room);
      }
      if (!mounted || picked.isEmpty) return;
      setState(() {
        for (final x in picked) {
          if (_photoPaths.length < 5 && !_photoPaths.contains(x.path)) _photoPaths.add(x.path);
        }
      });
    } catch (caught, trace) {
      AppLog.e('booking_request_screen.setState', caught, trace);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(AppStrings.isEnglish ? 'Could not open your photos' : 'Imeshindwa kufungua picha zako'),
      ));
    }
  }

  Future<void> _photoSheet() async {
    final en = AppStrings.isEnglish;
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 36,
                  height: 4,
                  margin: const EdgeInsets.only(top: 4, bottom: 10),
                  decoration: BoxDecoration(color: AppColors.textDisabled, borderRadius: BorderRadius.circular(2)),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 2, 10, 4),
                child: Text(en ? 'Add a photo' : 'Ongeza picha',
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.navy)),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 0, 10, 8),
                child: Text(
                  en ? 'Show the provider what you need, for example the style you want.' : 'Mwonyeshe mtoa huduma unachohitaji, mfano mtindo unaoutaka.',
                  style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                ),
              ),
              ListTile(
                minTileHeight: 52,
                leading: const Icon(Icons.photo_camera_outlined, color: AppColors.primary),
                title: Text(en ? 'Take a photo' : 'Piga picha', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                onTap: () => Navigator.pop(ctx, ImageSource.camera),
              ),
              ListTile(
                minTileHeight: 52,
                leading: const Icon(Icons.image_outlined, color: AppColors.primary),
                title: Text(en ? 'Choose from gallery' : 'Chagua kutoka galeri', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                onTap: () => Navigator.pop(ctx, ImageSource.gallery),
              ),
              ListTile(
                minTileHeight: 52,
                title: Center(child: Text(en ? 'Cancel' : 'Ghairi', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: AppColors.textSecondary))),
                onTap: () => Navigator.pop(ctx),
              ),
            ],
          ),
        ),
      ),
    );
    if (source != null) await _addPhotos(source);
  }

  bool _isLoading = false;

  /// How the buyer wants to pay once the provider accepts:
  /// 'HELD' = online, kept in escrow until they are satisfied; 'DIRECT' = online, released to the provider on payment.
  String _payPref = 'HELD';

  @override
  void dispose() {
    _noteController.dispose();
    _addressController.dispose();
    super.dispose();
  }

  String _money(int v) =>
      CurrencyService.format(v);

  /// 'Price agreed with the seller: TSh 40,000 (listed TSh 50,000)'
  String _agreedBannerText() {
    final en = AppStrings.isEnglish;
    final listed = widget.provider.listedPriceAmount > 0 ? widget.provider.listedPriceAmount : widget.provider.priceAmount;
    final agreed = widget.agreedAmount ?? listed;
    final tail = listed > agreed ? (en ? ' (listed ${_money(listed)})' : ' (bei ya kawaida ${_money(listed)})') : '';
    return en
        ? 'Price agreed with the seller: ${_money(agreed)}$tail'
        : 'Bei mliyokubaliana na muuzaji: ${_money(agreed)}$tail';
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDateTime,
      firstDate: now,
      lastDate: now.add(const Duration(days: 90)),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: AppColors.primary,
              onPrimary: Colors.white,
              surface: AppColors.surface,
              onSurface: AppColors.textPrimary,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null) {
      setState(() => _selectedDateTime = picked);
    }
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(
      context: context,
      initialTime: _selectedTimeOfDay,
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: AppColors.primary,
              onPrimary: Colors.white,
              surface: AppColors.surface,
              onSurface: AppColors.textPrimary,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null) {
      setState(() => _selectedTimeOfDay = picked);
    }
  }

  String get _formattedDate {
    final d = _selectedDateTime;
    return '${d.day}/${d.month}/${d.year}';
  }

  String get _formattedTime {
    final h = _selectedTimeOfDay.hour.toString().padLeft(2, '0');
    final m = _selectedTimeOfDay.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }

  // ---------------- Look: cards on a light background (new design) ----------------

  Widget _card({required Widget child, EdgeInsets padding = const EdgeInsets.all(14)}) => Container(
        width: double.infinity,
        padding: padding,
        decoration: BoxDecoration(
          color: AppColors.surface,
          border: Border.all(color: AppColors.border),
          borderRadius: BorderRadius.circular(16),
        ),
        child: child,
      );

  Widget _sec(String title, [String? sub]) => Padding(
        padding: const EdgeInsets.fromLTRB(2, 22, 2, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
            if (sub != null)
              Padding(
                padding: const EdgeInsets.only(top: 2),
                child: Text(sub, style: const TextStyle(fontSize: 11.8, height: 1.4, color: AppColors.textSecondary)),
              ),
          ],
        ),
      );

  Widget _iconBox(IconData icon, {double box = 38, double size = 20, double radius = 11, Color bg = AppColors.primaryLight}) => Container(
        width: box,
        height: box,
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(radius)),
        child: Icon(icon, size: size, color: AppColors.primary),
      );

  Widget _providerCard() {
    final p = widget.provider;
    return _card(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Row(
        children: [
          ClipOval(
            child: SizedBox(
              width: 48,
              height: 48,
              child: AppImage(
                p.sellerAvatar ?? '',
                fit: BoxFit.cover,
                errorBuilder: (ctx, err, stack) => Container(
                  color: AppColors.borderLight,
                  child: const Icon(Icons.person_outline_rounded, color: AppColors.textSecondary),
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(p.stageName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                const SizedBox(height: 2),
                Row(
                  children: [
                    const Icon(Icons.star_rounded, size: 14, color: AppColors.goldStar),
                    const SizedBox(width: 3),
                    Text(p.ratingText, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                    const SizedBox(width: 3),
                    Text(p.reviewsLabel, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                  ],
                ),
                const SizedBox(height: 2),
                Row(
                  children: [
                    const Icon(Icons.location_on_outlined, size: 12, color: AppColors.textSecondary),
                    const SizedBox(width: 3),
                    Text(p.distance, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _serviceCard() {
    final en = AppStrings.isEnglish;
    final tasks = widget.provider.tasks;
    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: SizedBox(
                  width: 48,
                  height: 48,
                  child: AppImage(
                    widget.provider.featuredImage ?? '',
                    fit: BoxFit.cover,
                    errorBuilder: (ctx, err, stack) => Container(
                      color: AppColors.primaryLight,
                      child: const Icon(Icons.spa_rounded, color: AppColors.textSecondary),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(widget.serviceTitle,
                        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                    const SizedBox(height: 2),
                    Text(
                      _usesTasks
                          ? (en ? 'Pick one or more tasks' : 'Chagua kazi moja au zaidi')
                          : [widget.durationText, _shownPrice].where((e) => e.trim().isNotEmpty).join(' • '),
                      style: const TextStyle(fontSize: 11.5, color: AppColors.textSecondary),
                    ),
                  ],
                ),
              ),
            ],
          ),
          if (_usesTasks) ...[
            const SizedBox(height: 12),
            const Divider(height: 1, color: AppColors.borderLight),
            for (int i = 0; i < tasks.length; i++) _taskRow(i, tasks[i], last: i == tasks.length - 1),
            Padding(
              padding: const EdgeInsets.fromLTRB(2, 12, 2, 0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Flexible(
                    child: Text(
                      en ? 'Up to 3 tasks, each with its own price' : 'Hadi kazi 3, kila moja na bei yake',
                      style: const TextStyle(fontSize: 11.5, color: AppColors.textSecondary),
                    ),
                  ),
                  Text('${_selectedTasks.where((i) => i < tasks.length).length}/${tasks.length}',
                      style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: AppColors.primary)),
                ],
              ),
            ),
          ],
          if (_hasAgreedPrice) ...[
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: AppColors.successLight, borderRadius: BorderRadius.circular(10)),
              child: Row(
                children: [
                  const Icon(Icons.local_offer_outlined, size: 18, color: AppColors.successDark),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(_agreedBannerText(),
                        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.successDark)),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _taskRow(int i, ServiceTask t, {required bool last}) {
    final on = _selectedTasks.contains(i);
    return Semantics(
      checked: on,
      child: InkWell(
        onTap: () => setState(() {
          if (on) {
            // At least one task stays picked.
            if (_selectedTasks.length > 1) {
              _selectedTasks.remove(i);
            } else {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text(AppStrings.isEnglish ? 'Pick at least one task' : 'Chagua angalau kazi moja'),
              ));
            }
          } else {
            _selectedTasks.add(i);
          }
        }),
        child: Container(
          constraints: const BoxConstraints(minHeight: 54),
          padding: const EdgeInsets.symmetric(horizontal: 2),
          decoration: BoxDecoration(
            border: last ? null : const Border(bottom: BorderSide(color: AppColors.borderLight)),
          ),
          child: Row(
            children: [
              Container(
                width: 22,
                height: 22,
                decoration: BoxDecoration(
                  color: on ? AppColors.primary : Colors.white,
                  borderRadius: BorderRadius.circular(7),
                  border: Border.all(color: on ? AppColors.primary : AppColors.textDisabled, width: 2),
                ),
                child: on ? const Icon(Icons.check_rounded, size: 14, color: Colors.white) : null,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(t.name,
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: on ? AppColors.primary : AppColors.textPrimary)),
              ),
              const SizedBox(width: 8),
              Text(CurrencyService.format(t.price),
                  style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
            ],
          ),
        ),
      ),
    );
  }

  // ----- Date and time: "as soon as possible" tile, then Day and Time drop-downs -----

  static const List<String> _timeSlots = [
    '08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00',
  ];

  DateTime _dayOffset(int i) {
    final n = DateTime.now();
    return DateTime(n.year, n.month, n.day).add(Duration(days: i));
  }

  bool _sameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

  String _dayName(int i) {
    final en = AppStrings.isEnglish;
    final d = _dayOffset(i);
    if (i == 0) return en ? 'Today' : 'Leo';
    if (i == 1) return en ? 'Tomorrow' : 'Kesho';
    const enDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const swDays = ['Jum2', 'Jum3', 'Jum4', 'Alh', 'Ijum', 'Jmos', 'Jpili'];
    return '${(en ? enDays : swDays)[d.weekday - 1]} ${d.day}';
  }

  /// Text for the Day box and the summary (a day outside the next 7 shows its date).
  String get _dayText {
    for (int i = 0; i < 7; i++) {
      if (_sameDay(_dayOffset(i), _selectedDateTime)) return _dayName(i);
    }
    return _formattedDate;
  }

  Widget _dropdownBox({
    required String label,
    required IconData icon,
    required String value,
    required List<DropdownMenuItem<String>> items,
    required ValueChanged<String?> onChanged,
  }) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(2, 0, 2, 4),
            child: Text(label, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700, color: AppColors.textSecondary)),
          ),
          Container(
            height: 44,
            padding: const EdgeInsets.only(left: 12, right: 8),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.border, width: 1.5),
            ),
            child: Row(
              children: [
                Icon(icon, size: 20, color: AppColors.primary),
                const SizedBox(width: 8),
                Expanded(
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      isExpanded: true,
                      value: value,
                      items: items,
                      onChanged: onChanged,
                      borderRadius: BorderRadius.circular(12),
                      dropdownColor: AppColors.surface,
                      icon: const Icon(Icons.keyboard_arrow_down_rounded, color: AppColors.textSecondary),
                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _whenSection() {
    final en = AppStrings.isEnglish;
    final today = DateTime.now();

    // Day items: today + 6 days, the picked date when it is further away, and "Other date".
    final dayItems = <DropdownMenuItem<String>>[
      for (int i = 0; i < 7; i++) DropdownMenuItem(value: 'd$i', child: Text(i < 2 ? '${_dayName(i)} · ${_dayOffset(i).day}/${_dayOffset(i).month}' : _dayName(i))),
    ];
    String dayValue = 'custom';
    for (int i = 0; i < 7; i++) {
      if (_sameDay(_dayOffset(i), _selectedDateTime)) dayValue = 'd$i';
    }
    if (dayValue == 'custom') dayItems.add(DropdownMenuItem(value: 'custom', child: Text(_formattedDate)));
    dayItems.add(DropdownMenuItem(value: 'other', child: Text(en ? 'Other date…' : 'Tarehe nyingine…')));

    final isToday = _sameDay(_selectedDateTime, today);
    final timeItems = <DropdownMenuItem<String>>[
      for (final t in _timeSlots)
        DropdownMenuItem(
          value: t,
          enabled: !(isToday && int.parse(t.substring(0, 2)) <= today.hour),
          child: Text(t),
        ),
    ];
    final timeValue = _formattedTime;
    if (!_timeSlots.contains(timeValue)) timeItems.add(DropdownMenuItem(value: timeValue, child: Text(timeValue)));
    timeItems.add(DropdownMenuItem(value: 'other', child: Text(en ? 'Other time…' : 'Saa nyingine…')));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sec(AppStrings.bookingSelectDate, en ? 'Pick a day, then a time.' : 'Chagua siku, kisha saa.'),
        InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () => setState(() => _asap = !_asap),
          child: Container(
            constraints: const BoxConstraints(minHeight: 56),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: AppColors.primaryLight,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _asap ? AppColors.primary : const Color(0xFF9CC2FF), width: 1.5),
            ),
            child: Row(
              children: [
                _iconBox(Icons.bolt_rounded, box: 32, size: 17, radius: 10, bg: Colors.white),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(en ? 'As soon as possible' : 'Haraka iwezekanavyo',
                          style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: _asap ? AppColors.primary : AppColors.primaryDark)),
                      Text(en ? 'Starts right away' : 'Inaanza mara moja',
                          style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                    ],
                  ),
                ),
                Container(
                  width: 22,
                  height: 22,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: _asap ? AppColors.primary : AppColors.textDisabled, width: 2),
                  ),
                  child: _asap
                      ? Container(width: 10, height: 10, decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle))
                      : null,
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        Opacity(
          opacity: _asap ? 0.45 : 1,
          child: IgnorePointer(
            ignoring: _asap,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                _dropdownBox(
                  label: en ? 'Day' : 'Siku',
                  icon: Icons.calendar_today_rounded,
                  value: dayValue,
                  items: dayItems,
                  onChanged: (v) {
                    if (v == null || v == 'custom') return;
                    if (v == 'other') {
                      _pickDate();
                      return;
                    }
                    setState(() {
                      _selectedDateTime = _dayOffset(int.parse(v.substring(1)));
                      // Today: a time that has already passed moves to the next free hour.
                      if (_sameDay(_selectedDateTime, today) && _selectedTimeOfDay.hour <= today.hour) {
                        final next = today.hour + 1;
                        if (next <= 23) _selectedTimeOfDay = TimeOfDay(hour: next, minute: 0);
                      }
                    });
                  },
                ),
                const SizedBox(width: 10),
                _dropdownBox(
                  label: en ? 'Time' : 'Saa',
                  icon: Icons.access_time_rounded,
                  value: timeValue,
                  items: timeItems,
                  onChanged: (v) {
                    if (v == null) return;
                    if (v == 'other') {
                      _pickTime();
                      return;
                    }
                    final parts = v.split(':');
                    setState(() => _selectedTimeOfDay = TimeOfDay(hour: int.parse(parts[0]), minute: int.parse(parts[1])));
                  },
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _whereSection() {
    final en = AppStrings.isEnglish;
    final city = (widget.provider.city ?? '').trim();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sec(en ? 'Where' : 'Wapi', en ? 'Where the service takes place.' : 'Mahali huduma itakapofanyika.'),
        _card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _iconBox(Icons.location_on_outlined),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 2),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(_locationOption ?? (en ? 'Agree the place with the provider' : 'Kubaliana eneo na mtoa huduma'),
                              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                          if (city.isNotEmpty)
                            Text(city, style: const TextStyle(fontSize: 11.5, color: AppColors.textSecondary)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              if (_asksAddress) ...[
                const SizedBox(height: 16),
                TextField(
                  controller: _addressController,
                  maxLength: 255,
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
                  decoration: InputDecoration(
                    isDense: true,
                    counterText: '',
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    labelText: en ? 'Your address (only if they come to you)' : 'Anwani yako (kama wanakuja kwako)',
                    labelStyle: const TextStyle(fontSize: 12),
                  ),
                ),
              ],
              const SizedBox(height: 10),
              const Divider(height: 1, color: AppColors.borderLight),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                dense: true,
                value: _shareLocation,
                activeColor: AppColors.primary,
                onChanged: (v) => setState(() => _shareLocation = v),
                title: Text(
                  en ? 'Save my location with this request' : 'Hifadhi eneo langu na ombi hili',
                  style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                ),
                subtitle: Text(
                  en
                      ? 'A private safety record in case of fraud. The provider never sees it.'
                      : 'Kumbukumbu ya siri ya usalama endapo kutatokea udanganyifu. Mtoa huduma haioni.',
                  style: const TextStyle(fontSize: 11, height: 1.35, color: AppColors.textSecondary),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _payChoice({required String value, required IconData icon, required String title, required String subtitle, String? tag}) {
    final on = _payPref == value;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Semantics(
        button: true,
        selected: on,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () => setState(() => _payPref = value),
          child: Container(
            width: double.infinity,
            padding: EdgeInsets.all(on ? 11 : 12),
            decoration: BoxDecoration(
              color: on ? AppColors.primaryLight : AppColors.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: on ? AppColors.primary : AppColors.border, width: on ? 2 : 1),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(on ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded,
                    size: 20, color: on ? AppColors.primary : AppColors.textMuted),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(children: [
                        Icon(icon, size: 16, color: on ? AppColors.primaryDark : AppColors.textSecondary),
                        const SizedBox(width: 6),
                        Flexible(child: Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary))),
                        if (tag != null) ...[
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(color: AppColors.successLight, borderRadius: BorderRadius.circular(10)),
                            child: Text(tag, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: AppColors.successDark)),
                          ),
                        ],
                      ]),
                      const SizedBox(height: 4),
                      Text(subtitle, style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textSecondary)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _photosSection() {
    final en = AppStrings.isEnglish;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sec(en ? 'Photos (optional)' : 'Picha (si lazima)',
            en ? 'Show the provider what you need. Up to 5 photos.' : 'Mwonyeshe mtoa huduma unachohitaji. Hadi picha 5.'),
        Wrap(
          spacing: 10,
          runSpacing: 12,
          children: [
            for (final path in _photoPaths)
              SizedBox(
                width: 76,
                height: 76,
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Positioned.fill(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.file(File(path), fit: BoxFit.cover,
                            errorBuilder: (c, e, s) => Container(color: AppColors.primaryLight, child: const Icon(Icons.image_outlined, color: AppColors.primary))),
                      ),
                    ),
                    Positioned(
                      top: -7,
                      right: -7,
                      child: InkWell(
                        onTap: () => setState(() => _photoPaths.remove(path)),
                        child: Container(
                          width: 22,
                          height: 22,
                          decoration: BoxDecoration(
                            color: AppColors.slateDark,
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 2),
                          ),
                          child: const Icon(Icons.close_rounded, size: 12, color: Colors.white),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            if (_photoPaths.length < 5)
              InkWell(
                onTap: _photoSheet,
                borderRadius: BorderRadius.circular(12),
                child: CustomPaint(
                  foregroundPainter: const _DashedBorderPainter(color: Color(0xFF9CC2FF), radius: 12),
                  child: Container(
                  width: 76,
                  height: 76,
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.add_rounded, size: 24, color: AppColors.primary),
                      const SizedBox(height: 2),
                      Text(en ? 'Add' : 'Ongeza',
                          style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: AppColors.primaryDark)),
                    ],
                  ),
                ),
                ),
              ),
          ],
        ),
      ],
    );
  }

  Widget _summaryRow(String label, String value, {bool big = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Text(label,
                  style: TextStyle(fontSize: big ? 13 : 12.5, fontWeight: big ? FontWeight.w800 : FontWeight.w500, color: big ? AppColors.textPrimary : AppColors.textSecondary)),
            ),
            const SizedBox(width: 12),
            Flexible(
              child: Text(value,
                  textAlign: TextAlign.right,
                  style: TextStyle(fontSize: big ? 14 : 12.5, fontWeight: big ? FontWeight.w800 : FontWeight.w700, color: big ? AppColors.successDark : AppColors.textPrimary)),
            ),
          ],
        ),
      );

  Widget _summaryCard() {
    final en = AppStrings.isEnglish;
    final locText = _locationOption ?? (en ? 'Agree the place with the provider' : 'Kubaliana eneo na mtoa huduma');
    final whenText = _asap ? (en ? 'As soon as possible' : 'Haraka iwezekanavyo') : '$_dayText, $_formattedTime';
    final payText = _payPref == 'HELD'
        ? (en ? 'Held until you are satisfied' : 'Inashikiliwa hadi uridhike')
        : (en ? 'Paid directly' : 'Lipa moja kwa moja');
    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Text(
              (en ? 'Request summary' : 'Muhtasari wa ombi').toUpperCase(),
              style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 0.6, color: AppColors.textSecondary),
            ),
          ),
          if (_usesTasks)
            for (final t in _pickedTasks) _summaryRow(t.name, CurrencyService.format(t.price))
          else if (_hasAgreedPrice)
            _summaryRow(widget.serviceTitle, CurrencyService.format(widget.provider.listedPriceAmount > 0 ? widget.provider.listedPriceAmount : widget.provider.priceAmount))
          else
            _summaryRow(widget.serviceTitle, _shownPrice),
          if (_hasAgreedPrice) _summaryRow(en ? 'Agreed price' : 'Bei iliyokubaliwa', CurrencyService.format(_amount)),
          _summaryRow(en ? 'When' : 'Lini', whenText),
          _summaryRow(en ? 'Where' : 'Wapi', locText),
          _summaryRow(en ? 'Payment' : 'Malipo', payText),
          if (_photoPaths.isNotEmpty) _summaryRow(en ? 'Photos' : 'Picha', '${_photoPaths.length}'),
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: Divider(height: 1, color: AppColors.borderLight),
          ),
          _summaryRow(en ? 'Estimated total' : 'Jumla inayokadiriwa', CurrencyService.format(_amount), big: true),
        ],
      ),
    );
  }

  Future<void> _sendBookingRequest() async {
    // Signed-in users only (a guest would just get a generic error from the server).
    if (!SessionManager.isLoggedIn()) {
      final ok = await LoginModal.show(context);
      if (ok != true || !mounted) return;
    }
    final providerId = widget.provider.sellerId;
    if (providerId == null || providerId == 0) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        backgroundColor: AppColors.danger,
        content: Text(AppStrings.isEnglish
            ? "This service can't take requests right now. Please try again later."
            : 'Huduma hii haiwezi kupokea maombi kwa sasa. Tafadhali jaribu tena baadaye.'),
      ));
      return;
    }
    if (_usesTasks && _selectedTasks.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        backgroundColor: AppColors.danger,
        content: Text(AppStrings.isEnglish ? 'Pick at least one task' : 'Chagua angalau kazi moja'),
      ));
      return;
    }
    setState(() => _isLoading = true);

    // Upload the photos first; if one fails the request is not sent half-done.
    final photoUrls = <String>[];
    for (final path in _photoPaths) {
      final up = await ApiService.uploadChatImage(path);
      if (!mounted) return;
      if (!up.ok || (up.url ?? '').isEmpty) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          backgroundColor: AppColors.danger,
          content: Text(AppStrings.isEnglish
              ? 'A photo could not be uploaded. Check your connection and try again.'
              : 'Picha moja haikupakiwa. Angalia mtandao kisha ujaribu tena.'),
        ));
        return;
      }
      photoUrls.add(up.url!);
    }

    final sellerId = providerId;
    final serviceId = int.tryParse(widget.provider.id);

    // Date, time and place travel as their own fields (scheduledAt; the server adds serviceMode and place).
    final scheduledAt = DateTime(_selectedDateTime.year, _selectedDateTime.month, _selectedDateTime.day,
        _selectedTimeOfDay.hour, _selectedTimeOfDay.minute);
    // Only what the customer typed goes in the note the provider reads. The payment choice
    // travels as its own field (paymentPreference), not as text in the note.
    final bookingDetails = _noteController.text.trim();

    final pos = _shareLocation ? await _currentPosition() : null;

    // Nothing is paid now: the buyer pays after the provider accepts (from Requests).
    final res = await ApiService.createEscrow(
      sellerId: sellerId,
      serviceId: serviceId,
      amount: _amount,
      paymentMethod: 'PAY_AFTER_ACCEPT',
      paymentPreference: _payPref,
      offerId: _hasAgreedPrice ? widget.offerId : null,
      notes: bookingDetails,
      scheduledAt: _asap ? null : scheduledAt,
      asap: _asap,
      taskIndexes: _usesTasks ? (_selectedTasks.toList()..sort()) : const [],
      photoUrls: photoUrls,
      customerAddress: _asksAddress ? _addressController.text : null,
      buyerLatitude: pos?.latitude,
      buyerLongitude: pos?.longitude,
      buyerAccuracyMeters: pos?.accuracy,
    );

    if (!mounted) return;
    setState(() => _isLoading = false);

    if (res != null) NeedSignals.recordBooking(widget.provider.category);

    if (res != null && mounted) {
      // No reference is shown unless the server really sent one (never a made-up one).
      final bookingRef = (res['transactionRef'] ?? '').toString().trim();
      final refWord = AppStrings.isEnglish ? 'Reference' : 'Kumbukumbu';
      final refLine = bookingRef.isEmpty ? '' : '\n$refWord: $bookingRef';
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Row(
            children: [
              const Icon(Icons.verified_user_rounded, color: AppColors.success),
              const SizedBox(width: 8),
              Text(AppStrings.bookingSuccessTitle),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('${widget.serviceTitle} - ${widget.provider.stageName}'),
              const SizedBox(height: 8),
              Text(
                '${AppStrings.sellPriceLabel}: $_shownPrice$refLine',
                style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 8),
              Text(
                AppStrings.isEnglish
                    ? 'Your request was sent. When the provider accepts it you will get an alert, then you pay from Requests. You can follow every step on the request page.'
                    : 'Ombi lako limetumwa. Mtoa huduma akikubali utapata taarifa, kisha unalipa kupitia Maombi. Unaweza kufuatilia kila hatua kwenye ukurasa wa ombi.',
                style: const TextStyle(fontSize: 11, color: AppColors.successDark),
              ),
            ],
          ),
          actions: [
            ElevatedButton(
              onPressed: () {
                Navigator.pop(ctx);
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              ),
              child: Text(AppStrings.confirm, style: const TextStyle(color: Colors.white)),
            ),
          ],
        ),
      );
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: AppColors.danger,
          // Show the server's reason (e.g. not enough Pocket Fund balance) when it sent one.
          content: Text(ApiService.lastPaymentError ?? AppStrings.error),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final en = AppStrings.isEnglish;
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          AppStrings.bookingTitle,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: Stack(
        children: [
          Positioned.fill(
            child: SingleChildScrollView(
              // Bottom room so the last lines can scroll above the floating button.
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 110),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _providerCard(),

                  _sec(AppStrings.navServices, en ? 'The service you are asking for.' : 'Huduma unayoomba.'),
                  _serviceCard(),

                  _whenSection(),
                  _whereSection(),

                  _sec(en ? 'How do you want to pay?' : 'Unataka kulipaje?',
                      en
                          ? 'You pay online after the provider accepts. The provider sees your choice in your request.'
                          : 'Unalipa mtandaoni baada ya mtoa huduma kukubali. Mtoa huduma ataona chaguo lako kwenye ombi lako.'),
                  _payChoice(
                    value: 'HELD',
                    icon: Icons.verified_user_rounded,
                    title: en ? 'Hold until I am satisfied' : 'Shikilia hadi niridhike',
                    subtitle: en
                        ? 'Your money is kept safe and released only when you confirm the job is done.'
                        : 'Pesa zako zinashikiliwa salama na kutolewa unapothibitisha kazi imekamilika.',
                    tag: en ? 'Recommended' : 'Inapendekezwa',
                  ),
                  _payChoice(
                    value: 'DIRECT',
                    icon: Icons.bolt_rounded,
                    title: en ? 'Pay directly' : 'Lipa moja kwa moja',
                    subtitle: en
                        ? 'The money goes to the provider as soon as you pay. Nothing is held, so you cannot get it back through escrow.'
                        : 'Pesa zinaenda kwa mtoa huduma mara tu unapolipa. Hakuna kinachoshikiliwa, kwa hiyo huwezi kuzirudisha kupitia escrow.',
                  ),
                  // Escrow guarantee: only while the buyer has chosen to hold the payment.
                  if (_payPref == 'HELD')
                    Container(
                      margin: const EdgeInsets.only(top: 4),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColors.successLight,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: AppColors.success.withValues(alpha: 0.3)),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.verified_user_rounded, color: AppColors.successDark, size: 22),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              AppStrings.bookingEscrowGuarantee,
                              style: const TextStyle(fontSize: 11, height: 1.4, color: AppColors.successDark, fontWeight: FontWeight.w600),
                            ),
                          ),
                        ],
                      ),
                    ),

                  _sec(AppStrings.bookingNotesLabel),
                  Container(
                    height: 92,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: TextField(
                      controller: _noteController,
                      maxLines: 4,
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500, height: 1.45),
                      decoration: InputDecoration(
                        hintText: AppStrings.bookingNotesHint,
                        hintStyle: const TextStyle(fontSize: 12, color: AppColors.textMuted),
                        border: InputBorder.none,
                        isDense: true,
                      ),
                    ),
                  ),

                  _photosSection(),

                  _sec(en ? 'Review' : 'Hakiki'),
                  _summaryCard(),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(4, 8, 4, 0),
                    child: Text(
                      en ? 'Nothing is charged now. You pay after the provider accepts.' : 'Hakuna kinacholipwa sasa. Unalipa baada ya mtoa huduma kukubali.',
                      style: const TextStyle(fontSize: 11, height: 1.4, color: AppColors.textSecondary),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Send Request floats above the form while it scrolls (hidden while the keyboard is open, so it never covers a field).
          if (MediaQuery.of(context).viewInsets.bottom == 0)
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [BoxShadow(color: AppColors.primary.withValues(alpha: 0.35), blurRadius: 20, offset: const Offset(0, 8))],
                    ),
                    child: SizedBox(
                      width: double.infinity,
                      height: 54,
                      child: ElevatedButton(
                        onPressed: _isLoading ? null : _sendBookingRequest,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primary,
                          foregroundColor: Colors.white,
                          disabledBackgroundColor: AppColors.primary.withValues(alpha: 0.7),
                          disabledForegroundColor: Colors.white,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          elevation: 0,
                        ),
                        child: _isLoading
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                              )
                            : Text(
                                '${AppStrings.bookingConfirmButton} ($_shownPrice)',
                                style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w800),
                              ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// Dashed rounded border for the "Add photo" tile.
class _DashedBorderPainter extends CustomPainter {
  final Color color;
  final double radius;

  const _DashedBorderPainter({required this.color, required this.radius});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    final rrect = RRect.fromRectAndRadius(Offset.zero & size, Radius.circular(radius)).deflate(0.75);
    final path = Path()..addRRect(rrect);
    for (final metric in path.computeMetrics()) {
      var d = 0.0;
      while (d < metric.length) {
        final end = d + 5 > metric.length ? metric.length : d + 5;
        canvas.drawPath(metric.extractPath(d, end), paint);
        d += 9;
      }
    }
  }

  @override
  bool shouldRepaint(covariant _DashedBorderPainter old) => old.color != color || old.radius != radius;
}
