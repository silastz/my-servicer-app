import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../security/password_policy.dart';
import '../services/api_service.dart';
import '../services/attempt_limiter.dart';
import '../services/biometric_service.dart';
import '../services/security_settings.dart';
import '../services/notification_service.dart';
import '../services/session_manager.dart';
import '../widgets/app_lock_gate.dart' show PinKeypad;
import '../widgets/app_ui.dart';
import '../widgets/language_selector_sheet.dart';
import 'help_support_screen.dart';

class SettingsSecurityScreen extends StatefulWidget {
  const SettingsSecurityScreen({super.key});

  @override
  State<SettingsSecurityScreen> createState() => _SettingsSecurityScreenState();
}

class _SettingsSecurityScreenState extends State<SettingsSecurityScreen> {
  static const _pinLimiterKey = 'app_lock_pin';

  bool? _bioAvailable; // null = still checking
  bool _notifBookings = SecuritySettings.flag('notif_bookings', defaultValue: true);
  bool _notifMessages = SecuritySettings.flag('notif_messages', defaultValue: true);
  bool _notifPromos = SecuritySettings.flag('notif_promos', defaultValue: true);

  bool get _isEn => AppStrings.isEnglish;
  bool get _rememberMe => SecuritySettings.rememberMe;
  bool get _appLock => SecuritySettings.appLockEnabled;
  bool get _profileLocked => SecuritySettings.profileLocked;
  bool get _allowSensitive => SecuritySettings.allowSensitive;
  bool get _hideMyId => SecuritySettings.hideMyId;

  @override
  void initState() {
    super.initState();
    _checkBiometric();
    _loadSwitchesFromServer();
  }

  bool _notifBusy = false; // a notification switch is being saved on the server

  /// The server is the truth for Hide My ID and the notification switches: show what it has saved
  /// (e.g. after a reinstall or on a new phone) instead of this phone's old local copy.
  Future<void> _loadSwitchesFromServer() async {
    final s = await ApiService.getMySwitches();
    if (s == null || !mounted) return;
    if (s.hideMyId != null && s.hideMyId != SecuritySettings.hideMyId) {
      await SecuritySettings.setHideMyId(s.hideMyId!);
    }
    if (s.profileLocked != null && s.profileLocked != SecuritySettings.profileLocked) {
      await SecuritySettings.setProfileLocked(s.profileLocked!);
    }
    if (!_notifBusy) {
      if (s.bookings != null) await SecuritySettings.setFlag('notif_bookings', s.bookings!);
      if (s.messages != null) await SecuritySettings.setFlag('notif_messages', s.messages!);
      if (s.promos != null) await SecuritySettings.setFlag('notif_promos', s.promos!);
    }
    if (!mounted) return;
    setState(() {
      if (!_notifBusy) {
        _notifBookings = SecuritySettings.flag('notif_bookings', defaultValue: true);
        _notifMessages = SecuritySettings.flag('notif_messages', defaultValue: true);
        _notifPromos = SecuritySettings.flag('notif_promos', defaultValue: true);
      }
    });
  }

  /// One notification switch. Saved on the server FIRST (like Hide My ID); if that fails the switch stays as it
  /// was and the person is told, so the screen never shows a state the server does not have.
  /// Signed out there is no server copy, so the choice is kept on this phone only.
  Future<void> _setNotif(String key, bool v, Future<bool> Function() saveOnServer, void Function() refreshSheet) async {
    if (_notifBusy) return;
    final signedIn = SessionManager.isLoggedIn();
    if (signedIn) {
      setState(() => _notifBusy = true);
      final ok = await saveOnServer();
      if (!mounted) return;
      setState(() => _notifBusy = false);
      if (!ok) {
        _snack(_isEn
            ? 'Could not save this setting. Check your connection and try again.'
            : 'Imeshindwa kuhifadhi mpangilio huu. Angalia mtandao kisha jaribu tena.');
        refreshSheet();
        return;
      }
    }
    await SecuritySettings.setFlag(key, v);
    if (!mounted) return;
    setState(() {
      if (key == 'notif_bookings') _notifBookings = v;
      if (key == 'notif_messages') _notifMessages = v;
      if (key == 'notif_promos') _notifPromos = v;
    });
    refreshSheet();
    NotificationService.syncPreferences(server: false); // OneSignal tags only: the server already has it
  }

  Future<void> _checkBiometric() async {
    final a = await BiometricService.isAvailable();
    if (mounted) setState(() => _bioAvailable = a);
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }

  // ---------------------------------------------------------------------------
  // About
  // ---------------------------------------------------------------------------
  void _showAbout() {
    AppPage.show<void>(
      context,
      title: _isEn ? 'About Ungana' : 'Kuhusu Ungana',
      builder: (ctx) => Column(
        children: [
          const SizedBox(height: 16),
          Center(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Image.asset(
                'assets/images/app_icon.png',
                width: 80,
                height: 80,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  width: 80,
                  height: 80,
                  color: AppColors.primaryLight,
                  child: const Icon(Icons.location_on_rounded, color: AppColors.primary, size: 40),
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text('Ungana', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
          const SizedBox(height: 12),
          Text(
            _isEn
                ? 'Ungana connects you with trusted service providers around you. Chat, call, book and pay securely inside the app.'
                : 'Ungana inakuunganisha na watoa huduma wanaoaminika karibu nawe. Ongea, piga simu, weka oda na lipa kwa usalama ndani ya app.',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 14, height: 1.5, color: AppColors.textSecondary),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Notification preferences
  // ---------------------------------------------------------------------------
  void _showNotificationPrefs() {
    AppPage.show<void>(
      context,
      title: _isEn ? 'Notification Preferences' : 'Mipangilio ya Arifa',
      subtitle: _isEn ? 'Choose what you want to be notified about.' : 'Chagua unachotaka kuarifiwa.',
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) {
          Widget row(IconData icon, String title, String sub, bool value, void Function(bool) onChanged) {
            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.fromLTRB(12, 10, 8, 10),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(color: AppColors.primaryLight, borderRadius: BorderRadius.circular(12)),
                    child: Icon(icon, color: AppColors.primary, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                        const SizedBox(height: 2),
                        Text(sub, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                      ],
                    ),
                  ),
                  Switch(
                    value: value,
                    onChanged: _notifBusy ? null : onChanged,
                  ),
                ],
              ),
            );
          }

          return Column(
            children: [
              row(Icons.receipt_long_outlined, _isEn ? 'Bookings & requests' : 'Oda na maombi',
                  _isEn ? 'New requests and status updates' : 'Maombi mapya na mabadiliko', _notifBookings, (v) {
                _setNotif('notif_bookings', v, () => ApiService.updateNotificationPrefs(bookings: v), () { if (ctx.mounted) setSheet(() {}); });
              }),
              row(Icons.chat_bubble_outline_rounded, _isEn ? 'Messages & calls' : 'Ujumbe na simu',
                  _isEn ? 'Chats and incoming call invites' : 'Mazungumzo na mialiko ya simu', _notifMessages, (v) {
                _setNotif('notif_messages', v, () => ApiService.updateNotificationPrefs(messages: v), () { if (ctx.mounted) setSheet(() {}); });
              }),
              row(Icons.local_offer_outlined, _isEn ? 'Offers & news' : 'Ofa na habari',
                  _isEn ? 'Promotions and app updates' : 'Matangazo na taarifa za app', _notifPromos, (v) {
                _setNotif('notif_promos', v, () => ApiService.updateNotificationPrefs(promos: v), () { if (ctx.mounted) setSheet(() {}); });
              }),
            ],
          );
        },
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Change password (OTP)
  // ---------------------------------------------------------------------------
  void _showChangePassword() {
    final idCtrl = TextEditingController();
    final otpCtrl = TextEditingController();
    final pwCtrl = TextEditingController();
    bool otpSent = false;
    bool busy = false;
    String? error;

    AppPage.show<void>(
      context,
      title: _isEn ? 'Change Password' : 'Badilisha Nenosiri',
      subtitle: otpSent ? null : (_isEn ? 'We will send a code to your phone or email.' : 'Tutatuma namba kwenye simu au barua pepe yako.'),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) {
          Future<void> submit() async {
            setD(() {
              busy = true;
              error = null;
            });
            if (!otpSent) {
              final r = await ApiService.forgotPassword(idCtrl.text);
              if (!ctx.mounted) return;
              setD(() {
                busy = false;
                if (r['success'] == true) {
                  otpSent = true;
                } else {
                  error = r['message']?.toString();
                }
              });
            } else {
              final weak = PasswordPolicy.validate(pwCtrl.text, phoneOrId: idCtrl.text);
              if (weak != null) {
                setD(() {
                  busy = false;
                  error = weak;
                });
                return;
              }
              if (otpCtrl.text.trim().length != 6) {
                setD(() {
                  busy = false;
                  error = AppStrings.authOtpHint;
                });
                return;
              }
              final r = await ApiService.resetPassword(idCtrl.text, otpCtrl.text, pwCtrl.text);
              if (!ctx.mounted) return;
              if (r['success'] == true) {
                Navigator.pop(ctx);
                _snack(r['message']?.toString() ?? '');
              } else {
                setD(() {
                  busy = false;
                  error = r['message']?.toString();
                });
              }
            }
          }

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              AppTextField(
                controller: idCtrl,
                enabled: !otpSent,
                icon: Icons.person_outline_rounded,
                hint: _isEn ? 'Phone or email' : 'Simu au barua pepe',
              ),
              if (otpSent) ...[
                const SizedBox(height: 12),
                AppTextField(
                  controller: otpCtrl,
                  icon: Icons.sms_outlined,
                  keyboardType: TextInputType.number,
                  hint: _isEn ? 'OTP code' : 'Namba ya OTP',
                ),
                const SizedBox(height: 12),
                AppTextField(
                  controller: pwCtrl,
                  icon: Icons.lock_outline_rounded,
                  obscureText: true,
                  hint: _isEn ? 'New password' : 'Nenosiri jipya',
                ),
              ],
              if (error != null) ...[
                const SizedBox(height: 10),
                Text(error!, style: const TextStyle(fontSize: 12, color: AppColors.danger, fontWeight: FontWeight.w600)),
              ],
              const SizedBox(height: 20),
              AppButton.primary(
                label: otpSent ? (_isEn ? 'Save new password' : 'Hifadhi nenosiri jipya') : (_isEn ? 'Send code' : 'Tuma namba'),
                loading: busy,
                onPressed: submit,
              ),
            ],
          );
        },
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // On/Off switches: every change goes through a popup
  // ---------------------------------------------------------------------------
  Future<void> _toggleRememberMe() async {
    final turnOn = !_rememberMe;
    final ok = await AppDialog.confirm(
      context,
      icon: Icons.how_to_reg_outlined,
      color: turnOn ? AppColors.primary : AppColors.danger,
      title: turnOn ? (_isEn ? 'Turn on Remember Me?' : 'Washa Nikumbuke?') : (_isEn ? 'Turn off Remember Me?' : 'Zima Nikumbuke?'),
      message: turnOn
          ? (_isEn ? 'You will stay signed in when you reopen the app.' : 'Utabaki umeingia unapofungua app tena.')
          : (_isEn ? 'You will need to sign in every time you open the app.' : 'Utahitaji kuingia kila unapofungua app.'),
      confirmLabel: turnOn ? (_isEn ? 'Turn on' : 'Washa') : (_isEn ? 'Turn off' : 'Zima'),
    );
    if (!ok) return;
    await SecuritySettings.setRememberMe(turnOn);
    if (mounted) setState(() {});
  }

  // ---------------------------------------------------------------------------
  // Profile Locked / Unlocked  +  Allow sensitive content
  // ---------------------------------------------------------------------------
  Future<void> _toggleProfileLock() async {
    final unlock = _profileLocked; // currently locked -> user wants to unlock
    final ok = await AppDialog.confirm(
      context,
      icon: unlock ? Icons.lock_open_rounded : Icons.lock_outline_rounded,
      color: unlock ? AppColors.warningDark : AppColors.primary,
      title: unlock
          ? (_isEn ? 'Unlock your profile?' : 'Fungua wasifu wako?')
          : (_isEn ? 'Lock your profile?' : 'Funga wasifu wako?'),
      message: unlock
          ? (_isEn
              ? 'Your phone number and social links will be shown on your profile.'
              : 'Namba yako ya simu na mitandao ya kijamii vitaonekana kwenye wasifu wako.')
          : (_isEn
              ? 'Your phone number and social links will be hidden on your profile.'
              : 'Namba yako ya simu na mitandao ya kijamii vitafichwa kwenye wasifu wako.'),
      confirmLabel: unlock ? (_isEn ? 'Unlock' : 'Fungua') : (_isEn ? 'Lock' : 'Funga'),
    );
    if (!ok) return;
    // Saved on the server first: the server is the one that hides or shows your contacts to the public.
    final saved = await ApiService.updateProfileLocked(!unlock);
    if (!saved) {
      _snack(_isEn
          ? 'Could not update your profile lock. Check your connection and try again.'
          : 'Imeshindwa kubadilisha ufungaji wa wasifu. Angalia mtandao kisha jaribu tena.');
      return;
    }
    await SecuritySettings.setProfileLocked(!unlock);
    if (mounted) setState(() {});
  }

  /// Hide My ID: providers see your profile photo, stage name and a Safe badge.
  /// The change is saved on the server first; if that fails nothing changes here.
  Future<void> _toggleHideMyId() async {
    final turnOn = !_hideMyId;
    final ok = await AppDialog.confirm(
      context,
      icon: turnOn ? Icons.shield_outlined : Icons.visibility_outlined,
      color: turnOn ? AppColors.primary : AppColors.warningDark,
      title: turnOn
          ? (_isEn ? 'Hide your ID?' : 'Ficha utambulisho wako?')
          : (_isEn ? 'Show your ID again?' : 'Onyesha utambulisho wako tena?'),
      message: turnOn
          ? (_isEn
              ? 'Providers will see your profile photo and stage name with a Safe badge, not your name from your ID or your verified photo. Your phone number and exact address stay private until a booking is confirmed.'
              : 'Watoa huduma wataona picha ya wasifu na jina lako la kikazi (stage name) pamoja na beji ya Safe, si jina la kitambulisho wala picha iliyothibitishwa. Namba yako ya simu na anwani kamili hubaki siri hadi oda ithibitishwe.')
          : (_isEn
              ? 'Providers will see your verified photo and your name from your ID (if you verified them), and the Safe badge will be removed.'
              : 'Watoa huduma wataona picha yako iliyothibitishwa na jina lako la kitambulisho (ikiwa umevithibitisha), na beji ya Safe itaondolewa.'),
      confirmLabel: turnOn ? (_isEn ? 'Hide' : 'Ficha') : (_isEn ? 'Show' : 'Onyesha'),
    );
    if (!ok) return;
    final saved = await ApiService.updateHideMyId(turnOn);
    if (!saved) {
      _snack(_isEn
          ? 'Could not update Hide My ID. Check your connection and try again.'
          : 'Imeshindwa kubadilisha Ficha Utambulisho. Angalia mtandao kisha jaribu tena.');
      return;
    }
    await SecuritySettings.setHideMyId(turnOn);
    if (mounted) setState(() {});
  }

  Future<void> _toggleSensitive() async {
    final turnOn = !_allowSensitive;
    final ok = await AppDialog.confirm(
      context,
      icon: Icons.visibility_outlined,
      color: turnOn ? AppColors.danger : AppColors.primary,
      title: turnOn
          ? (_isEn ? 'Allow sensitive content?' : 'Ruhusu maudhui nyeti?')
          : (_isEn ? 'Hide sensitive content?' : 'Ficha maudhui nyeti?'),
      message: turnOn
          ? (_isEn
              ? 'Sensitive (18+) services will appear on the home page, categories, search and favorites. Only turn this on if you are 18 or older.'
              : 'Huduma nyeti (18+) zitaonekana kwenye ukurasa wa mwanzo, makundi, utafutaji na pendwa. Washa tu ikiwa una miaka 18 au zaidi.')
          : (_isEn
              ? 'Sensitive (18+) services will no longer be shown anywhere in the app.'
              : 'Huduma nyeti (18+) hazitaonekana tena popote kwenye app.'),
      confirmLabel: turnOn ? (_isEn ? 'I am 18+, allow' : 'Nina 18+, ruhusu') : (_isEn ? 'Hide' : 'Ficha'),
    );
    if (!ok) return;
    await SecuritySettings.setAllowSensitive(turnOn);
    if (mounted) setState(() {});
  }

  // ---------------------------------------------------------------------------
  // App Lock (PIN)
  // ---------------------------------------------------------------------------

  /// Bottom sheet with 4 dots + keypad. Returns the 4 digits, or null if closed.
  /// [validate] may return an error text to keep the sheet open (wrong PIN).
  Future<String?> _askPin({
    required String title,
    String? subtitle,
    String? Function(String pin)? validate,
  }) {
    String entered = '';
    String? error;
    bool done = false;
    return AppPage.show<String>(
      context,
      title: title,
      subtitle: subtitle,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                for (var i = 0; i < 4; i++)
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 120),
                    margin: const EdgeInsets.symmetric(horizontal: 8),
                    width: 16,
                    height: 16,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: i < entered.length ? (error != null ? AppColors.danger : AppColors.primary) : Colors.transparent,
                      border: Border.all(color: error != null ? AppColors.danger : AppColors.primary, width: 2),
                    ),
                  ),
              ],
            ),
            SizedBox(
              height: 36,
              child: Center(
                child: Text(
                  error ?? '',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 12, color: AppColors.danger, fontWeight: FontWeight.w600),
                ),
              ),
            ),
            PinKeypad(
              keySize: 60,
              onDigit: (d) {
                if (entered.length >= 4 || done) return;
                setD(() {
                  entered += d;
                  error = null;
                });
                if (entered.length == 4) {
                  final problem = validate?.call(entered);
                  if (problem != null) {
                    Future.delayed(const Duration(milliseconds: 150), () {
                      if (ctx.mounted) {
                        setD(() {
                          error = problem;
                          entered = '';
                        });
                      }
                    });
                  } else {
                    done = true;
                    Future.delayed(const Duration(milliseconds: 150), () {
                      if (ctx.mounted) Navigator.pop(ctx, entered);
                    });
                  }
                }
              },
              onBackspace: () {
                if (entered.isNotEmpty && !done) setD(() => entered = entered.substring(0, entered.length - 1));
              },
            ),
          ],
        ),
      ),
    );
  }

  /// Asks for the current PIN; wrong entries show an error and the sheet stays open.
  Future<bool> _verifyCurrentPin(String title) async {
    final pin = await _askPin(
      title: title,
      subtitle: _isEn ? 'Enter your current PIN' : 'Weka PIN yako ya sasa',
      validate: (p) {
        final wait = AttemptLimiter.secondsLocked(_pinLimiterKey);
        if (wait > 0) {
          return _isEn ? 'Too many attempts. Try again in ${wait}s.' : 'Majaribio mengi. Jaribu tena baada ya sekunde $wait.';
        }
        if (SecuritySettings.verifyPin(p)) {
          AttemptLimiter.recordSuccess(_pinLimiterKey);
          return null;
        }
        AttemptLimiter.recordFailure(_pinLimiterKey);
        return _isEn ? 'Wrong PIN. Try again.' : 'PIN si sahihi. Jaribu tena.';
      },
    );
    return pin != null;
  }

  /// Create + confirm a new PIN. Returns it, or null if cancelled / mismatch.
  Future<String?> _createPin() async {
    final first = await _askPin(
      title: _isEn ? 'Create a PIN' : 'Tengeneza PIN',
      subtitle: _isEn ? 'Choose 4 digits you will remember.' : 'Chagua tarakimu 4 utakazokumbuka.',
    );
    if (first == null || !mounted) return null;
    final second = await _askPin(
      title: _isEn ? 'Confirm your PIN' : 'Thibitisha PIN',
      subtitle: _isEn ? 'Enter the same 4 digits again.' : 'Weka tarakimu 4 zilezile tena.',
      validate: (p) => p == first ? null : (_isEn ? 'PINs do not match. Try again.' : 'PIN hazilingani. Jaribu tena.'),
    );
    return second;
  }

  Future<void> _toggleAppLock() async {
    if (!_appLock) {
      final ok = await AppDialog.confirm(
        context,
        icon: Icons.lock_outline_rounded,
        title: _isEn ? 'Turn on App Lock?' : 'Washa App Lock?',
        message: _isEn
            ? 'You will set a 4-digit PIN. The app will ask for it when you open it or come back to it.'
            : 'Utaweka PIN ya tarakimu 4. App itaiomba unapoifungua au kurudi kwenye app.',
        confirmLabel: _isEn ? 'Set PIN' : 'Weka PIN',
      );
      if (!ok || !mounted) return;
      final pin = await _createPin();
      if (pin == null) return;
      final saved = await SecuritySettings.enableAppLock(pin);
      _snack(saved
          ? (_isEn ? 'App Lock is on' : 'App Lock imewashwa')
          : (_isEn ? 'Could not save the PIN on this device' : 'Imeshindwa kuhifadhi PIN kwenye kifaa hiki'));
    } else {
      final ok = await _verifyCurrentPin(_isEn ? 'Turn off App Lock' : 'Zima App Lock');
      if (!ok || !mounted) return;
      await SecuritySettings.disableAppLock();
      _snack(_isEn ? 'App Lock is off' : 'App Lock imezimwa');
    }
    if (mounted) setState(() {});
  }

  Future<void> _changePin() async {
    if (!await _verifyCurrentPin(_isEn ? 'Change PIN' : 'Badilisha PIN') || !mounted) return;
    final pin = await _createPin();
    if (pin == null) return;
    final saved = await SecuritySettings.changePin(pin);
    _snack(saved ? (_isEn ? 'PIN changed' : 'PIN imebadilishwa') : (_isEn ? 'Could not save the PIN' : 'Imeshindwa kuhifadhi PIN'));
  }

  Future<void> _toggleBiometric() async {
    final turnOn = !SecuritySettings.biometricEnabled;

    if (turnOn) {
      // Re-check now: the user may have just added a fingerprint in phone settings.
      final available = await BiometricService.isAvailable();
      if (mounted) setState(() => _bioAvailable = available);
      if (!mounted) return;
      if (!available) {
        await AppDialog.info(
          context,
          icon: Icons.fingerprint_rounded,
          color: AppColors.warning,
          title: _isEn ? 'Biometrics not available' : 'Alama za mwili hazipatikani',
          message: _isEn
              ? 'This phone has no fingerprint or face recognition, or none is set up yet. Add one in your phone settings, then try again. You can keep using your PIN.'
              : 'Simu hii haina alama ya kidole au utambuzi wa uso, au bado haijawekwa. Weka kwenye mipangilio ya simu kisha ujaribu tena. Unaweza kuendelea kutumia PIN.',
        );
        return;
      }
    }

    final ok = await AppDialog.confirm(
      context,
      icon: Icons.fingerprint_rounded,
      color: turnOn ? AppColors.primary : AppColors.danger,
      title: turnOn
          ? (_isEn ? 'Turn on fingerprint / face unlock?' : 'Washa kufungua kwa kidole / uso?')
          : (_isEn ? 'Turn off fingerprint / face unlock?' : 'Zima kufungua kwa kidole / uso?'),
      message: turnOn
          ? (_isEn ? 'You can unlock the app with your fingerprint or face. Your PIN still works.' : 'Unaweza kufungua app kwa alama ya kidole au uso. PIN yako bado inafanya kazi.')
          : (_isEn ? 'You will unlock the app with your PIN only.' : 'Utafungua app kwa PIN pekee.'),
      confirmLabel: turnOn ? (_isEn ? 'Turn on' : 'Washa') : (_isEn ? 'Turn off' : 'Zima'),
    );
    if (!ok) return;

    if (turnOn) {
      // Prove it works before switching it on.
      final r = await BiometricService.authenticate(_isEn ? 'Confirm to turn on biometric unlock' : 'Thibitisha kuwasha kufungua kwa alama za mwili');
      if (r != BiometricResult.success) {
        _snack(r == BiometricResult.lockedOut
            ? (_isEn ? 'Biometrics are temporarily locked. Try again later.' : 'Alama za mwili zimefungwa kwa muda. Jaribu tena baadaye.')
            : r == BiometricResult.unavailable
                ? (_isEn ? 'Biometrics are not available on this phone.' : 'Alama za mwili hazipatikani kwenye simu hii.')
                : (_isEn ? 'Not confirmed. Biometric unlock stays off.' : 'Haijathibitishwa. Kufungua kwa alama za mwili hakujawashwa.'));
        return;
      }
    }
    await SecuritySettings.setBiometricEnabled(turnOn);
    if (mounted) setState(() {});
  }

  String _timeoutLabel(int seconds) {
    if (seconds == 0) return _isEn ? 'Immediately' : 'Mara moja';
    if (seconds < 60) return _isEn ? '$seconds seconds' : 'Sekunde $seconds';
    final m = seconds ~/ 60;
    return _isEn ? '$m min' : 'Dakika $m';
  }

  Future<void> _pickLockTimeout() async {
    final picked = await AppPage.show<int>(
      context,
      title: _isEn ? 'Lock the app after' : 'Funga app baada ya',
      subtitle: _isEn ? 'How long the app can be in the background before it asks for your PIN.' : 'Muda app inaweza kukaa nyuma kabla ya kuomba PIN yako.',
      builder: (ctx) => Column(
        children: [
          for (final sec in const [0, 30, 60, 300])
            Container(
              margin: const EdgeInsets.only(bottom: 8),
              decoration: BoxDecoration(
                color: SecuritySettings.lockTimeoutSeconds == sec ? AppColors.primaryLight : AppColors.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: SecuritySettings.lockTimeoutSeconds == sec ? AppColors.primary : AppColors.border),
              ),
              child: ListTile(
                dense: true,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                onTap: () => Navigator.pop(ctx, sec),
                title: Text(_timeoutLabel(sec), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
                trailing: SecuritySettings.lockTimeoutSeconds == sec
                    ? const Icon(Icons.check_circle_rounded, color: AppColors.primary, size: 22)
                    : null,
              ),
            ),
        ],
      ),
    );
    if (picked == null) return;
    await SecuritySettings.setLockTimeout(picked);
    if (mounted) setState(() {});
  }

  // ---------------------------------------------------------------------------
  // Build
  // ---------------------------------------------------------------------------
  @override
  Widget build(BuildContext context) {
    // Guests have no account, so no profile / password / security settings.
    final loggedIn = SessionManager.isLoggedIn();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _isEn ? 'Settings & Security' : 'Mipangilio na Usalama',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionTitle(_isEn ? 'Account' : 'Akaunti'),
            _buildSettingsContainer([
              if (loggedIn) ...[
                _buildNavigationTile(
                  icon: Icons.lock_outline_rounded,
                  title: _isEn ? 'Change Password' : 'Badilisha Nenosiri',
                  onTap: _showChangePassword,
                ),
                _buildDivider(),
              ],
              _buildNavigationTile(
                icon: Icons.language_rounded,
                title: _isEn ? 'Language' : 'Lugha',
                trailingText: _isEn ? 'English' : 'Kiswahili',
                onTap: () => LanguageSelectorSheet.show(context),
              ),
              if (loggedIn) ...[
                _buildDivider(),
                _buildNavigationTile(
                  icon: Icons.notifications_none_rounded,
                  title: _isEn ? 'Notification Preferences' : 'Mapendeleo ya Arifa',
                  onTap: _showNotificationPrefs,
                ),
              ],
              _buildDivider(),
              _buildSwitchTile(
                icon: Icons.visibility_outlined,
                title: _isEn ? 'Allow sensitive content (18+)' : 'Ruhusu maudhui nyeti (18+)',
                value: _allowSensitive,
                onTap: _toggleSensitive,
              ),
            ]),
            const SizedBox(height: 24),

            if (loggedIn) ...[
              _buildSectionTitle(_isEn ? 'Privacy & Security' : 'Faragha na Usalama'),
              _buildSettingsContainer([
                _buildSwitchTile(
                  icon: _profileLocked ? Icons.lock_outline_rounded : Icons.lock_open_rounded,
                  title: _isEn ? 'Profile' : 'Wasifu',
                  value: _profileLocked,
                  onText: _isEn ? 'Locked' : 'Imefungwa',
                  offText: _isEn ? 'Unlocked' : 'Iko wazi',
                  onTap: _toggleProfileLock,
                ),
                _buildDivider(),
                _buildSwitchTile(
                  icon: _hideMyId ? Icons.verified_user_rounded : Icons.verified_user_outlined,
                  title: _isEn ? 'Hide My ID' : 'Ficha Utambulisho Wangu',
                  value: _hideMyId,
                  onText: _isEn ? 'On · Safe' : 'Imewashwa · Safe',
                  offText: _isEn ? 'Off' : 'Imezimwa',
                  onTap: _toggleHideMyId,
                ),
                _buildDivider(),
                _buildSwitchTile(
                  icon: Icons.how_to_reg_outlined,
                  title: _isEn ? 'Remember Me' : 'Nikumbuke',
                  value: _rememberMe,
                  onTap: _toggleRememberMe,
                ),
                _buildDivider(),
                _buildSwitchTile(
                  icon: Icons.lock_clock_outlined,
                  title: _isEn ? 'App Lock' : 'Kufunga App',
                  value: _appLock,
                  onTap: _toggleAppLock,
                ),
                if (_appLock) ...[
                  _buildDivider(),
                  _buildSwitchTile(
                    icon: Icons.fingerprint_rounded,
                    title: _isEn ? 'Fingerprint / Face unlock' : 'Kufungua kwa kidole / uso',
                    value: SecuritySettings.biometricEnabled,
                    unavailable: _bioAvailable == false && !SecuritySettings.biometricEnabled,
                    onTap: _toggleBiometric,
                  ),
                  _buildDivider(),
                  _buildNavigationTile(
                    icon: Icons.pin_outlined,
                    title: _isEn ? 'Change PIN' : 'Badilisha PIN',
                    onTap: _changePin,
                  ),
                  _buildDivider(),
                  _buildNavigationTile(
                    icon: Icons.timer_outlined,
                    title: _isEn ? 'Lock after' : 'Funga baada ya',
                    trailingText: _timeoutLabel(SecuritySettings.lockTimeoutSeconds),
                    onTap: _pickLockTimeout,
                  ),
                ],
              ]),
              const SizedBox(height: 24),
            ],

            _buildSectionTitle(_isEn ? 'Support' : 'Msaada'),
            _buildSettingsContainer([
              _buildNavigationTile(
                icon: Icons.help_outline_rounded,
                title: _isEn ? 'Help & Support' : 'Msaada na Usaidizi',
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const HelpSupportScreen()));
                },
              ),
              _buildDivider(),
              _buildNavigationTile(
                icon: Icons.info_outline_rounded,
                title: _isEn ? 'About Us' : 'Kuhusu Sisi',
                onTap: _showAbout,
              ),
            ]),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: Text(
        title,
        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textSecondary),
      ),
    );
  }

  Widget _buildSettingsContainer(List<Widget> children) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(children: children),
    );
  }

  Widget _tileIcon(IconData icon) {
    return Container(
      width: 34,
      height: 34,
      decoration: BoxDecoration(color: AppColors.primaryLight, borderRadius: BorderRadius.circular(10)),
      child: Icon(icon, color: AppColors.primary, size: 19),
    );
  }

  Widget _buildNavigationTile({
    required IconData icon,
    required String title,
    String? trailingText,
    required VoidCallback onTap,
  }) {
    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
      leading: _tileIcon(icon),
      title: Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (trailingText != null) ...[
            Text(trailingText, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
            const SizedBox(width: 4),
          ],
          const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted, size: 20),
        ],
      ),
    );
  }

  /// Tapping opens a popup (never flips silently). The pill shows the current state.
  Widget _buildSwitchTile({
    required IconData icon,
    required String title,
    required bool value,
    required VoidCallback onTap,
    bool unavailable = false,
    String? onText,
    String? offText,
  }) {
    final pill = unavailable
        ? StatusPill(text: _isEn ? 'Not available' : 'Haipatikani', color: AppColors.warningDark)
        : StatusPill(text: value ? (onText ?? (_isEn ? 'On' : 'Imewashwa')) : (offText ?? (_isEn ? 'Off' : 'Imezimwa')), color: value ? AppColors.successDark : AppColors.textSecondary);
    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
      leading: _tileIcon(icon),
      title: Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          pill,
          const SizedBox(width: 4),
          const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted, size: 20),
        ],
      ),
    );
  }

  Widget _buildDivider() {
    return const Divider(height: 1, indent: 66, color: AppColors.borderLight);
  }
}
