import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/models.dart' show VerificationLevel;
import '../services/api_service.dart';
import '../services/block_service.dart';
import '../widgets/app_image.dart';
import '../widgets/block_user_dialog.dart';
import '../widgets/report_sheet.dart';
import '../widgets/verification_badge.dart';
import 'chat_thread_screen.dart';

/// Reads the buyer out of a transaction map (`tx['buyer']`) and exposes the
/// few fields the UI needs. Nothing is invented: missing data stays null.
class BuyerInfo {
  final int? id;
  final String name;

  /// The buyer's stage name (profile name). With Hide My ID off, [name] is the name from their ID
  /// and this is shown next to it; with Hide My ID on, [name] already is the stage name.
  final String? stageName;
  final String? avatarUrl;
  final DateTime? memberSince;
  final String? city;

  /// Activity numbers the server may send (null = not sent, so nothing is shown).
  final int? completedBookings;
  final int? reviewsGiven;

  /// The buyer turned on Hide My ID: providers get their stage name and normal profile
  /// image, never the name from their ID or the verified photo.
  final bool hideMyId;

  /// Safe badge, shown only when the buyer hides their ID AND the server says so.
  final bool safeBadge;

  /// [avatarUrl] is the buyer's server-verified photo (only possible while Hide My ID is off).
  final bool photoVerified;

  /// [name] is the buyer's name taken from their verified ID (only while Hide My ID is off).
  final bool nameVerified;

  /// Verification tier the server gave this user: green (identity verified) or
  /// blue (also Verified Business). Colors the Safe badge.
  final VerificationLevel level;

  /// The buyer's profile is Locked (server flag; missing = Locked, the safe default).
  final bool profileLocked;

  /// Locked profile AND Hide My ID on: contacts and ID are hidden until the provider accepts.
  bool get contactsAndIdHidden => hideMyId && profileLocked;

  /// Name for lists and cards: the stage name when there is one. The name from the buyer's ID
  /// (when Hide My ID is off) is only shown in the detail views, never in lists.
  String get listName {
    final t = (stageName ?? '').trim();
    return t.isNotEmpty ? t : name;
  }

  /// The stage name to show beside the legal name, or null when there is nothing extra to show
  /// (Hide My ID on, or the stage name is the same as the name already displayed).
  String? get stageNameExtra {
    if (hideMyId) return null;
    final t = (stageName ?? '').trim();
    if (t.isEmpty || t.toLowerCase() == name.trim().toLowerCase()) return null;
    return t;
  }

  const BuyerInfo({
    this.id,
    required this.name,
    this.stageName,
    this.avatarUrl,
    this.memberSince,
    this.city,
    this.completedBookings,
    this.reviewsGiven,
    this.hideMyId = false,
    this.safeBadge = false,
    this.photoVerified = false,
    this.nameVerified = false,
    this.level = VerificationLevel.none,
    this.profileLocked = true,
  });

  static VerificationLevel _levelOf(String? raw) {
    final t = (raw ?? '').toUpperCase();
    if (t.contains('BLUE')) return VerificationLevel.blueBusiness;
    if (t.contains('GREEN')) return VerificationLevel.greenIdentity;
    return VerificationLevel.none;
  }

  static bool _truthy(dynamic v) => v == true || v?.toString().toLowerCase() == 'true';

  static String? _first(List<dynamic> options) {
    for (final o in options) {
      final t = o?.toString().trim() ?? '';
      if (t.isNotEmpty && t != 'null') return t;
    }
    return null;
  }

  factory BuyerInfo.fromTx(Map<String, dynamic> tx) {
    final raw = tx['buyer'];
    final b = raw is Map ? Map<String, dynamic>.from(raw) : <String, dynamic>{};
    final hide = _truthy(b['hideMyId'] ?? tx['hideMyId']);
    // Hide My ID ON: stage name + normal profile image (+ Safe badge). The name from the
    // ID and the verified photo are never used, even if the server sent them.
    // Hide My ID OFF: the name verified from the ID comes first, then the stage name;
    // the verified photo comes first, then the normal profile image.
    final verifiedName = hide ? null : _first([b['verifiedName'], tx['buyerVerifiedName']]);
    final name = (hide
            ? _first([b['stageName']])
            : (verifiedName ?? _first([b['stageName'], b['name'], b['fullName'], tx['buyerName']]))) ??
        (AppStrings.isEnglish ? 'Customer' : 'Mteja');
    final verifiedPhoto = hide ? null : _first([b['verifiedPhotoUrl'], tx['buyerVerifiedPhotoUrl']]);
    final avatar = verifiedPhoto ?? _first([b['avatarUrl'], b['profileImage'], b['profilePhoto'], b['avatar']]);
    final id = int.tryParse('${b['id'] ?? tx['buyerId'] ?? ''}');
    return BuyerInfo(
      id: (id == null || id == 0) ? null : id,
      name: name,
      stageName: _first([b['stageName'], b['name'], tx['buyerName']]),
      avatarUrl: avatar == null ? null : ApiService.absoluteUrl(avatar),
      memberSince: DateTime.tryParse(_first([b['createdAt'], b['memberSince'], b['joinedAt'], b['registeredAt']]) ?? ''),
      city: _first([b['city'], b['location']]),
      completedBookings: int.tryParse(_first([b['completedBookings'], b['completedOrders'], b['bookingsCount']]) ?? ''),
      reviewsGiven: int.tryParse(_first([b['reviewsGiven'], b['reviewsCount'], b['reviewsWritten']]) ?? ''),
      hideMyId: hide,
      safeBadge: hide && _truthy(b['safeBadge'] ?? tx['buyerSafeBadge']),
      photoVerified: verifiedPhoto != null,
      nameVerified: verifiedName != null,
      profileLocked: (b['profileLocked'] ?? tx['buyerProfileLocked']) != false,
      level: _levelOf(_first([b['verificationBadge'], b['verificationLevel'], tx['buyerVerificationBadge']])),
    );
  }
}

/// The buyer's real photo, or a coloured circle with their initial.
class BuyerAvatar extends StatelessWidget {
  final BuyerInfo buyer;
  final double size;

  /// Show the tick on the avatar for a customer who uses Hide My ID (replaces the "Safe" pill).
  final bool safeTick;
  const BuyerAvatar({super.key, required this.buyer, this.size = 40, this.safeTick = false});

  @override
  Widget build(BuildContext context) {
    final shown = buyer.listName.trim();
    final initial = shown.isEmpty ? '?' : shown.substring(0, 1).toUpperCase();
    final fallback = Container(
      width: size,
      height: size,
      color: AppColors.primary,
      alignment: Alignment.center,
      child: Text(initial, style: TextStyle(fontSize: size * 0.4, fontWeight: FontWeight.w800, color: Colors.white)),
    );
    final photo = ClipOval(
      child: SizedBox(
        width: size,
        height: size,
        child: (buyer.avatarUrl ?? '').isEmpty
            ? fallback
            : AppImage(buyer.avatarUrl!, width: size, height: size, fit: BoxFit.cover, errorBuilder: (_, _, _) => fallback),
      ),
    );
    // Small check on a server-verified photo (only when there is a photo to verify),
    // or on a Safe customer (Hide My ID) when [safeTick] is requested.
    final showSafe = safeTick && buyer.safeBadge;
    final showVerified = buyer.photoVerified && (buyer.avatarUrl ?? '').isNotEmpty;
    if (!showSafe && !showVerified) return photo;
    final tickColor = showSafe && !showVerified
        ? (buyer.level == VerificationLevel.blueBusiness ? AppColors.primary : AppColors.successDark)
        : AppColors.primary;
    final mark = size * 0.34;
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          photo,
          Positioned(
            right: -mark * 0.15,
            bottom: -mark * 0.15,
            child: Container(
              width: mark,
              height: mark,
              decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 1.5),
              ),
              child: Icon(Icons.verified_rounded, size: mark - 3, color: tickColor),
            ),
          ),
        ],
      ),
    );
  }
}

/// Small green "Safe" mark shown next to a customer who uses Hide My ID.
/// Draws nothing unless [BuyerInfo.safeBadge] is true.
class SafeBadge extends StatelessWidget {
  final BuyerInfo buyer;

  /// Small variant for list cards.
  final bool compact;
  const SafeBadge({super.key, required this.buyer, this.compact = true});

  @override
  Widget build(BuildContext context) {
    if (!buyer.safeBadge) return const SizedBox.shrink();
    final en = AppStrings.isEnglish;
    // Same colors as the verification badges: blue tier = blue, otherwise green.
    final tint = buyer.level == VerificationLevel.blueBusiness ? AppColors.primary : AppColors.successDark;
    return Container(
      padding: EdgeInsets.symmetric(horizontal: compact ? 6 : 10, vertical: compact ? 2 : 5),
      decoration: BoxDecoration(
        color: tint.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.verified_user_rounded, size: compact ? 11 : 14, color: tint),
          const SizedBox(width: 3),
          Text(
            en ? 'Safe' : 'Salama',
            style: TextStyle(
              fontSize: compact ? 10 : 12,
              fontWeight: FontWeight.w800,
              color: tint,
            ),
          ),
        ],
      ),
    );
  }
}

/// Mark next to a customer's name while Hide My ID is OFF: the green or blue
/// verification badge, or a plain check when only the name was verified.
class BuyerNameMark extends StatelessWidget {
  final BuyerInfo buyer;
  final double size;
  const BuyerNameMark({super.key, required this.buyer, this.size = 14});

  @override
  Widget build(BuildContext context) {
    if (buyer.hideMyId) return const SizedBox.shrink();
    if (buyer.level != VerificationLevel.none) {
      return Padding(padding: const EdgeInsets.only(left: 4), child: VerificationBadge(level: buyer.level, size: size));
    }
    if (buyer.nameVerified) {
      return Padding(
        padding: const EdgeInsets.only(left: 4),
        child: Icon(Icons.verified_rounded, size: size, color: AppColors.primary),
      );
    }
    return const SizedBox.shrink();
  }
}

/// What a provider sees about a customer who booked them.
/// Contact details and the exact address are deliberately not shown here.
class BuyerProfileScreen extends StatefulWidget {
  final BuyerInfo buyer;
  final String serviceTitle;
  final String amount;
  final String when;
  final String statusLabel;
  final Color statusColor;

  const BuyerProfileScreen({
    super.key,
    required this.buyer,
    this.serviceTitle = '',
    this.amount = '',
    this.when = '',
    this.statusLabel = '',
    this.statusColor = AppColors.textSecondary,
  });

  @override
  State<BuyerProfileScreen> createState() => _BuyerProfileScreenState();
}

class _BuyerProfileScreenState extends State<BuyerProfileScreen> {
  static const _months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  static const double _hero = 130;

  final ScrollController _scroll = ScrollController();

  BuyerInfo get buyer => widget.buyer;
  String get serviceTitle => widget.serviceTitle;
  String get amount => widget.amount;
  String get when => widget.when;
  String get statusLabel => widget.statusLabel;
  Color get statusColor => widget.statusColor;

  bool get _en => AppStrings.isEnglish;
  double get _topInset => MediaQuery.of(context).padding.top;
  double get _barHeight => _topInset + kToolbarHeight;

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  String _first(String n) => n.trim().split(RegExp(r'\s+')).first;

  /// The privacy note under the checklist (same wording as before).
  String get _note => buyer.contactsAndIdHidden
      ? (_en
          ? 'This customer has hidden their contacts and ID. Accept the request to see their contact and location.'
          : 'Mteja huyu amefichwa mawasiliano na utambulisho. Kubali ombi ili uone mawasiliano na eneo lake.')
      : (_en
          ? 'Phone number and exact address are shared only after you confirm this booking.'
          : 'Namba ya simu na anwani kamili hushirikiwa tu baada ya wewe kuthibitisha oda hii.');

  // ------------------------------------------------------------------ build

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Scaffold(
        backgroundColor: AppColors.background,
        body: Stack(
          children: [
            CustomScrollView(
              controller: _scroll,
              slivers: [
                SliverToBoxAdapter(child: _cover()),
                SliverToBoxAdapter(child: _identity()),
                SliverToBoxAdapter(child: _statsCard()),
                SliverToBoxAdapter(child: _actions()),
                SliverToBoxAdapter(child: _details()),
              ],
            ),
            Positioned(top: 0, left: 0, right: 0, child: _topBar()),
          ],
        ),
      ),
    );
  }

  // -------------------------------------------------------------------- top

  Widget _roundButton({required IconData icon, required VoidCallback onTap}) {
    return Padding(
      padding: const EdgeInsets.all(6),
      child: Material(
        color: Colors.black.withValues(alpha: 0.38),
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: Padding(padding: const EdgeInsets.all(7), child: Icon(icon, color: Colors.white, size: 20)),
        ),
      ),
    );
  }

  /// Back / menu buttons floating over the cover. Turns into a solid bar with the customer's
  /// name once the cover has scrolled away.
  Widget _topBar() {
    return AnimatedBuilder(
      animation: _scroll,
      builder: (context, _) {
        final span = (_hero + _topInset - _barHeight).clamp(1.0, double.infinity);
        final off = _scroll.hasClients ? _scroll.offset : 0.0;
        final t = (off / span).clamp(0.0, 1.0);
        return Container(
          height: _barHeight,
          padding: EdgeInsets.only(top: _topInset),
          color: AppColors.slateDark.withValues(alpha: t * 0.97),
          child: Row(
            children: [
              _roundButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.pop(context)),
              Expanded(
                child: Opacity(
                  opacity: t,
                  child: Text(
                    buyer.listName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Colors.white),
                  ),
                ),
              ),
              if (buyer.id != null) _menu(context) else const SizedBox(width: 12),
            ],
          ),
        );
      },
    );
  }

  /// Gradient cover (customers have no cover photo).
  Widget _cover() {
    return SizedBox(
      height: _hero + _topInset,
      child: Stack(
        clipBehavior: Clip.hardEdge,
        fit: StackFit.expand,
        children: [
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [AppColors.slateDark, AppColors.primaryDark],
              ),
            ),
          ),
          Positioned(
            right: -60,
            top: -90,
            child: Container(
              width: 220,
              height: 220,
              decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withValues(alpha: 0.07)),
            ),
          ),
          Positioned(
            left: -50,
            bottom: -90,
            child: Container(
              width: 150,
              height: 150,
              decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withValues(alpha: 0.06)),
            ),
          ),
        ],
      ),
    );
  }

  // --------------------------------------------------------------- identity

  Widget _avatar() => Container(
        width: 82,
        height: 82,
        padding: const EdgeInsets.all(3),
        decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.14), blurRadius: 12, offset: const Offset(0, 4))],
        ),
        child: BuyerAvatar(buyer: buyer, size: 76, safeTick: true),
      );

  Widget _chip({required String label, IconData? icon, required Color bg, required Color fg, Color? border}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(20),
        border: border == null ? null : Border.all(color: border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[Icon(icon, size: 12, color: fg), const SizedBox(width: 4)],
          Flexible(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: fg))),
        ],
      ),
    );
  }

  /// Avatar overlapping the cover, stage name beside it, then the trust chips.
  Widget _identity() {
    final showIdName = buyer.nameVerified && !buyer.hideMyId;
    final city = (buyer.city ?? '').trim();
    final sub = [_en ? 'Customer' : 'Mteja', if (city.isNotEmpty) city].join('  •  ');
    final chips = <Widget>[
      if (showIdName)
        _chip(
          label: _en ? 'Legal name verified' : 'Jina la kisheria limethibitishwa',
          icon: Icons.verified_user_rounded,
          bg: AppColors.primaryLight,
          fg: AppColors.navy,
          border: AppColors.primary.withValues(alpha: 0.22),
        ),
      if (buyer.safeBadge) SafeBadge(buyer: buyer, compact: false),
      if (showIdName && city.isNotEmpty)
        _chip(label: city, icon: Icons.location_on_outlined, bg: AppColors.borderLight, fg: AppColors.slateDark),
    ];
    return Container(
      color: AppColors.surface,
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                width: 82,
                height: 46,
                child: Stack(clipBehavior: Clip.none, children: [Positioned(left: 0, top: -42, child: _avatar())]),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Stage name is the strong title. The name from the ID (Hide My ID off) sits under it.
                      Row(
                        children: [
                          Flexible(
                            child: Text(
                              buyer.listName,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.navy, letterSpacing: -0.4),
                            ),
                          ),
                          if (!buyer.nameVerified) BuyerNameMark(buyer: buyer, size: 18),
                        ],
                      ),
                      if (showIdName) ...[
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Flexible(
                              child: Text(
                                buyer.name,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.slateMuted),
                              ),
                            ),
                            BuyerNameMark(buyer: buyer, size: 14),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 2),
                          child: Text(
                            _en ? 'Legal name (verified from ID)' : 'Jina la kisheria (limethibitishwa kwa kitambulisho)',
                            style: const TextStyle(fontSize: 11, color: AppColors.primary, fontWeight: FontWeight.w600),
                          ),
                        ),
                      ] else
                        Padding(
                          padding: const EdgeInsets.only(top: 2),
                          child: Text(sub, style: const TextStyle(fontSize: 12.5, color: AppColors.textSecondary)),
                        ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          if (chips.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Wrap(spacing: 6, runSpacing: 6, children: chips),
            ),
          if (buyer.safeBadge)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(
                _en
                    ? 'This customer hides their ID. You see their stage name and profile photo only.'
                    : 'Mteja huyu amefichwa utambulisho. Unaona jina lake la kikazi na picha ya wasifu tu.',
                style: const TextStyle(fontSize: 11, height: 1.4, color: AppColors.textSecondary),
              ),
            ),
        ],
      ),
    );
  }

  /// Bookings done / Reviews given / Member since as one card. Only what the server sent is shown.
  Widget _statsCard() {
    final tiles = <(IconData, String, String)>[
      if (buyer.completedBookings != null)
        (Icons.event_available_outlined, '${buyer.completedBookings}', _en ? 'Bookings done' : 'Oda zilizokamilika'),
      if (buyer.reviewsGiven != null)
        (Icons.star_outline_rounded, '${buyer.reviewsGiven}', _en ? 'Reviews given' : 'Maoni aliyotoa'),
      if (buyer.memberSince != null)
        (Icons.schedule_rounded, '${_months[buyer.memberSince!.month - 1]} ${buyer.memberSince!.year}', _en ? 'Member since' : 'Mwanachama tangu'),
    ];
    if (tiles.isEmpty) return Container(height: 0, color: AppColors.surface);
    return Container(
      color: AppColors.surface,
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.background,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border),
        ),
        child: IntrinsicHeight(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              for (var i = 0; i < tiles.length; i++) ...[
                if (i > 0) const VerticalDivider(width: 1, thickness: 1, color: AppColors.border),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 4),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 28,
                          height: 28,
                          decoration: BoxDecoration(color: AppColors.primaryLight, borderRadius: BorderRadius.circular(9)),
                          child: Icon(tiles[i].$1, size: 15, color: AppColors.primary),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          tiles[i].$2,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.w800, color: AppColors.navy, letterSpacing: -0.3),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          tiles[i].$3,
                          maxLines: 2,
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 10.5, color: AppColors.textSecondary),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  /// Message button plus a Call button that stays locked until the booking is confirmed.
  Widget _actions() {
    final locked = InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(_note), duration: const Duration(seconds: 3)),
      ),
      child: Container(
        height: 42,
        padding: const EdgeInsets.symmetric(horizontal: 14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFFBFD3F5)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.lock_outline_rounded, size: 17, color: AppColors.textMuted),
            const SizedBox(width: 7),
            Text(_en ? 'Call' : 'Piga simu', style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: AppColors.textMuted)),
          ],
        ),
      ),
    );
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
      decoration: const BoxDecoration(
        color: AppColors.surface,
        border: Border(bottom: BorderSide(color: AppColors.border)),
      ),
      child: Row(
        children: [
          if (buyer.id != null) ...[
            Expanded(
              child: SizedBox(
                height: 42,
                child: ElevatedButton.icon(
                  onPressed: () => ChatThreadScreen.open(context, recipientId: buyer.id, name: buyer.listName),
                  icon: const Icon(Icons.chat_bubble_rounded, size: 18),
                  label: Text(
                    _en ? 'Message ${_first(buyer.name)}' : 'Tuma ujumbe kwa ${_first(buyer.name)}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            locked,
          ] else
            Expanded(child: locked),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------- details

  Widget _details() {
    final hasBooking = serviceTitle.isNotEmpty || amount.isNotEmpty || when.isNotEmpty || statusLabel.isNotEmpty;
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
      child: Column(
        children: [
          if (hasBooking) ...[_bookingCard(), const SizedBox(height: 10)],
          _visibleCard(),
        ],
      ),
    );
  }

  /// "25/10/2026, 10:00" (how the requests screen formats it) -> weekday, day, month, time. Null when
  /// the text is in some other shape, so the card falls back to showing it as it is.
  ({String wk, String day, String mon, String time})? _parseWhen() {
    final m = RegExp(r'^(\d{1,2})/(\d{1,2})/(\d{4}),\s*(\d{1,2}:\d{2})$').firstMatch(when.trim());
    if (m == null) return null;
    final d = int.parse(m[1]!), mo = int.parse(m[2]!), y = int.parse(m[3]!);
    if (mo < 1 || mo > 12 || d < 1 || d > 31) return null;
    const en = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const sw = ['Jtt', 'Jne', 'Jtn', 'Alh', 'Ijm', 'Jmo', 'Jpi'];
    final wd = DateTime(y, mo, d).weekday;
    return (wk: (_en ? en : sw)[wd - 1], day: '$d', mon: _months[mo - 1], time: m[4]!);
  }

  Widget _dateTile() {
    final p = _parseWhen();
    const border = Color(0xFFC9DAFB);
    if (p == null) {
      return Container(
        width: 56,
        height: 56,
        decoration: BoxDecoration(color: AppColors.primaryLight, borderRadius: BorderRadius.circular(12), border: Border.all(color: border)),
        child: const Icon(Icons.calendar_today_outlined, color: AppColors.primary, size: 22),
      );
    }
    const small = TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: AppColors.primary, letterSpacing: 0.5);
    return Container(
      width: 56,
      padding: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(color: AppColors.primaryLight, borderRadius: BorderRadius.circular(12), border: Border.all(color: border)),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(p.wk.toUpperCase(), style: small),
          Text(p.day, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.navy, height: 1.1)),
          Text(p.mon.toUpperCase(), style: small),
        ],
      ),
    );
  }

  Widget _notch({required bool left}) => Positioned(
        top: 0,
        left: left ? -8 : null,
        right: left ? null : -8,
        child: Container(
          width: 14,
          height: 14,
          decoration: BoxDecoration(
            color: AppColors.background,
            shape: BoxShape.circle,
            border: Border.all(color: AppColors.border),
          ),
        ),
      );

  /// Ticket-style booking card: status on top, date tile + service + time, dashed divider, price.
  Widget _bookingCard() {
    final p = _parseWhen();
    final timeText = p?.time ?? when;
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 0),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    _en ? 'THIS BOOKING' : 'ODA HII',
                    style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 0.6, color: AppColors.textSecondary),
                  ),
                ),
                if (statusLabel.isNotEmpty)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
                    decoration: BoxDecoration(color: statusColor.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10)),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(width: 6, height: 6, decoration: BoxDecoration(color: statusColor, shape: BoxShape.circle)),
                        const SizedBox(width: 5),
                        Text(statusLabel, style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700, color: statusColor)),
                      ],
                    ),
                  ),
              ],
            ),
          ),
          if (serviceTitle.isNotEmpty || when.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
              child: Row(
                children: [
                  if (when.isNotEmpty) ...[_dateTile(), const SizedBox(width: 12)],
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (serviceTitle.isNotEmpty)
                          Text(
                            serviceTitle,
                            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary, letterSpacing: -0.2, height: 1.25),
                          ),
                        if (timeText.isNotEmpty)
                          Padding(
                            padding: EdgeInsets.only(top: serviceTitle.isNotEmpty ? 5 : 0),
                            child: Row(
                              children: [
                                const Icon(Icons.schedule_rounded, size: 14, color: AppColors.textSecondary),
                                const SizedBox(width: 5),
                                Flexible(
                                  child: Text(timeText, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: AppColors.textSecondary)),
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            )
          else
            const SizedBox(height: 12),
          if (amount.isNotEmpty) ...[
            SizedBox(
              height: 14,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Positioned.fill(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: CustomPaint(painter: const _TicketDashPainter()),
                    ),
                  ),
                  _notch(left: true),
                  _notch(left: false),
                ],
              ),
            ),
            Container(
              color: AppColors.background,
              padding: const EdgeInsets.fromLTRB(14, 8, 14, 12),
              child: Row(
                children: [
                  Expanded(child: Text(_en ? 'Price' : 'Bei', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.textSecondary))),
                  Text(amount, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.primary, letterSpacing: -0.3)),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _visRow(String label, bool visible, {bool first = false}) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(border: first ? null : const Border(top: BorderSide(color: AppColors.borderLight))),
      child: Row(
        children: [
          Container(
            width: 26,
            height: 26,
            decoration: BoxDecoration(
              color: visible ? AppColors.successLight : AppColors.borderLight,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              visible ? Icons.check_rounded : Icons.lock_outline_rounded,
              size: 14,
              color: visible ? AppColors.successDark : AppColors.textMuted,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(child: Text(label, style: const TextStyle(fontSize: 12.5, color: AppColors.textPrimary))),
          Text(
            visible ? (_en ? 'Visible' : 'Inaonekana') : (_en ? 'Locked' : 'Imefungwa'),
            style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
          ),
        ],
      ),
    );
  }

  /// What the provider can and cannot see yet, with the privacy note under it.
  Widget _visibleCard() {
    final idVisible = buyer.nameVerified && !buyer.hideMyId;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _en ? 'What you can see' : 'Unachoweza kuona',
            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.navy),
          ),
          const SizedBox(height: 6),
          _visRow(_en ? 'Stage name' : 'Jina la kikazi', true, first: true),
          _visRow(_en ? 'Legal name' : 'Jina la kisheria', idVisible),
          _visRow(_en ? 'Phone number' : 'Namba ya simu', false),
          _visRow(_en ? 'Exact address' : 'Anwani kamili', false),
          const SizedBox(height: 8),
          const Divider(height: 1, color: AppColors.borderLight),
          const SizedBox(height: 10),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.only(top: 1),
                child: Icon(Icons.lock_outline_rounded, color: AppColors.primary, size: 16),
              ),
              const SizedBox(width: 9),
              Expanded(child: Text(_note, style: const TextStyle(fontSize: 11.5, height: 1.45, color: AppColors.slateMuted))),
            ],
          ),
        ],
      ),
    );
  }

  Widget _menu(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(6),
      child: Material(
        color: Colors.black.withValues(alpha: 0.38),
        shape: const CircleBorder(),
        child: SizedBox(
          width: 34,
          height: 34,
          child: PopupMenuButton<String>(
            padding: EdgeInsets.zero,
            icon: const Icon(Icons.more_vert_rounded, color: Colors.white, size: 20),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            onSelected: (choice) async {
              final id = buyer.id!;
              if (choice == 'block') {
                final done = await BlockUserDialog.confirmBlock(context, userId: id, name: buyer.name);
                if (done && context.mounted) Navigator.pop(context);
                return;
              }
              final out = await ReportSheet.show(context, target: ReportTarget.user, userId: id, name: buyer.name);
              if (out.blocked && context.mounted) Navigator.pop(context);
            },
            itemBuilder: (_) => [
              PopupMenuItem(
                value: 'report',
                child: Row(children: [
                  const Icon(Icons.flag_outlined, size: 18, color: AppColors.danger),
                  const SizedBox(width: 10),
                  Text(_en ? 'Report customer' : 'Ripoti mteja',
                      style: const TextStyle(fontWeight: FontWeight.w600, color: AppColors.danger)),
                ]),
              ),
              if (!BlockService.isBlocked(buyer.id))
                PopupMenuItem(
                  value: 'block',
                  child: Row(children: [
                    const Icon(Icons.block_rounded, size: 18, color: AppColors.danger),
                    const SizedBox(width: 10),
                    Text(_en ? 'Block customer' : 'Mzuie mteja',
                        style: const TextStyle(fontWeight: FontWeight.w600, color: AppColors.danger)),
                  ]),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Dashed line across the ticket divider of the booking card.
class _TicketDashPainter extends CustomPainter {
  const _TicketDashPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppColors.border
      ..strokeWidth = 1.5;
    final y = size.height / 2;
    for (var x = 0.0; x < size.width; x += 9) {
      canvas.drawLine(Offset(x, y), Offset((x + 5).clamp(0.0, size.width), y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _TicketDashPainter old) => false;
}
