import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/identity_lookup.dart';
import '../services/api_service.dart';
import '../widgets/app_ui.dart';

/// Admin: change the login the server uses to look up the name registered for a NIN
/// (the check behind "Verify My Legal Name").
///
/// This screen is only a remote control. The server checks every call (403 for anyone who is not an
/// admin), stores the password encrypted and uses it for the lookups. The password is write-only: the
/// server never sends it back, so the field stays blank and a blank field means "keep the saved one".
class AdminIdentityLookupScreen extends StatefulWidget {
  const AdminIdentityLookupScreen({super.key});

  @override
  State<AdminIdentityLookupScreen> createState() => _AdminIdentityLookupScreenState();
}

class _AdminIdentityLookupScreenState extends State<AdminIdentityLookupScreen> {
  bool _loading = true;
  bool _forbidden = false;
  bool _loadFailed = false;
  bool _saving = false;
  bool _testBusy = false;

  IdentityLookupConfig? _saved; // what the server has now
  final _username = TextEditingController();
  final _password = TextEditingController();
  final Map<String, String> _errors = {};

  bool get _isEn => AppStrings.isEnglish;
  String _t(String en, String sw) => _isEn ? en : sw;

  @override
  void initState() {
    super.initState();
    _username.addListener(_onEdited);
    _password.addListener(_onEdited);
    _load();
  }

  @override
  void dispose() {
    _username.dispose();
    _password.dispose();
    super.dispose();
  }

  void _onEdited() {
    if (mounted) setState(() {});
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _loadFailed = false;
    });
    final r = await ApiService.getAdminIdentityLookup();
    if (!mounted) return;
    if (r.config != null) _fill(r.config!);
    setState(() {
      _loading = false;
      _forbidden = r.forbidden;
      _loadFailed = !r.forbidden && r.config == null;
      _saved = r.config;
    });
  }

  /// The password field is always left blank: it is never kept on the phone.
  void _fill(IdentityLookupConfig c) {
    _username.text = c.username;
    _password.clear();
  }

  bool get _changed {
    final s = _saved;
    if (s == null) return false;
    return _password.text.isNotEmpty || _username.text.trim() != s.username;
  }

  bool _validate() {
    final e = <String, String>{};
    final u = IdentityLookupRules.username(_username.text);
    if (u != null) {
      e['username'] = u == 'empty'
          ? _t('Enter the username', 'Weka jina la mtumiaji')
          : _t('Letters, numbers and . _ @ + - only', 'Herufi, namba na . _ @ + - tu');
    }
    if (IdentityLookupRules.password(_password.text) != null) {
      e['password'] = _t('Up to 200 characters, no line breaks', 'Hadi herufi 200, bila mistari mipya');
    }
    // The first time a login is saved it needs both a username and a password.
    if (_saved != null && !_saved!.passwordSet && _password.text.isEmpty) {
      e['password'] = _t('Enter the password', 'Weka nenosiri');
    }
    setState(() {
      _errors
        ..clear()
        ..addAll(e);
    });
    return e.isEmpty;
  }

  void _snack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  String _saveError(String? code) {
    switch (code) {
      case 'forbidden':
        return _t('Only an admin can change this.', 'Ni msimamizi pekee anayeweza kubadilisha hili.');
      case 'network':
        return _t('No connection. Nothing was changed.', 'Hakuna mtandao. Hakuna kilichobadilishwa.');
      case 'USERNAME_INVALID':
        return _t('The username has characters that are not allowed.', 'Jina la mtumiaji lina herufi zisizoruhusiwa.');
      case 'PASSWORD_INVALID':
        return _t('The password has characters that are not allowed.', 'Nenosiri lina herufi zisizoruhusiwa.');
      case 'CREDENTIALS_INCOMPLETE':
        return _t('Enter both the username and the password.', 'Weka jina la mtumiaji na nenosiri vyote.');
      case 'NO_CHANGES':
        return _t('Nothing to save.', 'Hakuna cha kuhifadhi.');
      default:
        return _t('Could not save. Nothing was changed.', 'Imeshindwa kuhifadhi. Hakuna kilichobadilishwa.');
    }
  }

  Future<void> _save() async {
    if (_saving || _saved == null || !_validate()) return;
    final ok = await AppDialog.confirm(
      context,
      icon: Icons.badge_rounded,
      title: _t('Change the lookup login?', 'Badilisha taarifa za kuingia?'),
      message: _t(
        'The name check will use this login right away. A wrong login makes new name checks wait (pending) until it is fixed.',
        'Uhakiki wa jina utatumia taarifa hizi mara moja. Taarifa zisizo sahihi zitafanya uhakiki mpya usubiri hadi zirekebishwe.',
      ),
      confirmLabel: _t('Change', 'Badilisha'),
    );
    if (!ok || !mounted) return;

    setState(() => _saving = true);
    // Only send what changed; a missing field keeps the saved value.
    final changedUser = _username.text.trim() != _saved!.username ? _username.text : null;
    final saved = await ApiService.setAdminIdentityLookup(username: changedUser, password: _password.text);
    if (!mounted) return;
    setState(() => _saving = false);
    if (saved == null) {
      _snack(_saveError(ApiService.lastAdminError));
      return;
    }
    _fill(saved); // clears the password field
    setState(() => _saved = saved);
    _snack(_t('Login saved. Press Test login to check it.', 'Taarifa zimehifadhiwa. Bonyeza Jaribu kuingia kuzihakiki.'));
  }

  Future<void> _test() async {
    if (_testBusy) return;
    setState(() => _testBusy = true);
    final r = await ApiService.adminIdentityLookupTest();
    if (!mounted) return;
    setState(() => _testBusy = false);
    if (r.success) {
      _snack(_t('Login works.', 'Kuingia kunafanya kazi.'));
    } else if (r.message == 'forbidden') {
      _snack(_t('Only an admin can do this.', 'Ni msimamizi pekee anayeweza kufanya hili.'));
    } else if (r.message == 'network') {
      _snack(_t('No connection.', 'Hakuna mtandao.'));
    } else {
      _snack(r.message ?? _t('Login failed.', 'Kuingia kumeshindwa.'));
    }
  }

  String _fmt(DateTime d) {
    final l = d.toLocal();
    String two(int v) => v.toString().padLeft(2, '0');
    return '${l.year}-${two(l.month)}-${two(l.day)} ${two(l.hour)}:${two(l.minute)}';
  }

  // ---------------------------------------------------------------------------
  // UI
  // ---------------------------------------------------------------------------

  Widget _info(String text, {Color color = AppColors.primary, IconData icon = Icons.info_outline_rounded}) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.2)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 12.5, height: 1.4, color: AppColors.textPrimary))),
        ],
      ),
    );
  }

  Widget _heading(String text) => Padding(
        padding: const EdgeInsets.only(top: 20, bottom: 10),
        child: Text(text, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
      );

  Widget _statusCard(IdentityLookupConfig s) {
    final ready = s.isComplete;
    String detail;
    if (s.source == 'ADMIN') {
      detail = s.updatedAt == null
          ? _t('Saved in the app.', 'Imehifadhiwa kwenye app.')
          : _t('Saved in the app. Last changed ${_fmt(s.updatedAt!)}.', 'Imehifadhiwa kwenye app. Ilibadilishwa ${_fmt(s.updatedAt!)}.');
    } else if (s.source == 'CONFIG') {
      detail = _t(
        'Using the server\'s own login. Save one here to replace it.',
        'Inatumia taarifa za seva. Hifadhi zako hapa kuzibadilisha.',
      );
    } else {
      detail = _t('No login yet. Name checks stay pending until you add one.', 'Hakuna taarifa bado. Uhakiki wa jina utasubiri hadi uziweke.');
    }
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_t('Lookup login', 'Taarifa za kuingia'),
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                const SizedBox(height: 4),
                Text(detail, style: const TextStyle(fontSize: 12, height: 1.35, color: AppColors.textSecondary)),
              ],
            ),
          ),
          const SizedBox(width: 8),
          StatusPill(
            text: ready ? _t('Set up', 'Imewekwa') : _t('Not set up', 'Haijawekwa'),
            color: ready ? AppColors.success : AppColors.warning,
          ),
        ],
      ),
    );
  }

  Widget _body() {
    if (_loading) return const Center(child: CircularProgressIndicator(color: AppColors.primary));
    if (_forbidden) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: _info(
            _t('This account is not an admin, so it cannot change this login.', 'Akaunti hii si ya msimamizi, kwa hiyo haiwezi kubadilisha taarifa hizi.'),
            color: AppColors.danger,
            icon: Icons.lock_outline_rounded,
          ),
        ),
      );
    }
    if (_loadFailed || _saved == null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(_t('Could not load the settings.', 'Imeshindwa kupakia mipangilio.'),
                  textAlign: TextAlign.center, style: const TextStyle(fontSize: 14, color: AppColors.textSecondary)),
              const SizedBox(height: 16),
              AppButton.primary(label: _t('Try again', 'Jaribu tena'), onPressed: _load),
            ],
          ),
        ),
      );
    }
    final s = _saved!;
    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _info(_t(
                'This login lets the server look up the name registered for a NIN, so a user\'s legal name can be verified. The saved password is never shown again: leave it blank to keep it.',
                'Taarifa hizi zinaruhusu seva kutafuta jina lililosajiliwa kwa NIN, ili jina la kisheria la mtumiaji lihakikiwe. Nenosiri lililohifadhiwa halionyeshwi tena: liache wazi ili kuliweka.',
              )),
              const SizedBox(height: 14),
              _statusCard(s),
              _heading(_t('Change login', 'Badilisha taarifa')),
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: AppTextField(
                  controller: _username,
                  label: _t('Username', 'Jina la mtumiaji'),
                  hint: _t('Lookup service username', 'Jina la mtumiaji la huduma'),
                  icon: Icons.person_outline_rounded,
                  errorText: _errors['username'],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: AppTextField(
                  controller: _password,
                  label: _t('Password', 'Nenosiri'),
                  hint: s.passwordSet
                      ? _t('Saved. Leave blank to keep it', 'Limehifadhiwa. Acha wazi ili kuliweka')
                      : _t('Enter the password', 'Weka nenosiri'),
                  icon: s.passwordSet ? Icons.lock_rounded : Icons.key_rounded,
                  obscureText: true,
                  errorText: _errors['password'],
                ),
              ),
              _heading(_t('Test', 'Jaribu')),
              _info(_t('The test uses the saved login, so press Save first. It signs in only; no NIN is looked up.',
                  'Jaribio linatumia taarifa zilizohifadhiwa, kwa hiyo bonyeza Hifadhi kwanza. Linaingia tu; hakuna NIN inayotafutwa.')),
              const SizedBox(height: 12),
              AppButton.outlined(label: _t('Test login', 'Jaribu kuingia'), onPressed: (_testBusy || _saving) ? null : _test),
              const SizedBox(height: 8),
            ],
          ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: SizedBox(
              width: double.infinity,
              child: AppButton.primary(label: _t('Save', 'Hifadhi'), onPressed: (_changed && !_saving) ? _save : null),
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _t('ID Name Check Login', 'Taarifa za Uhakiki wa Jina'),
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: _body(),
    );
  }
}
