import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../services/api_service.dart';
import '../widgets/admin_common.dart';

/// Admin: review queue for ID papers, verified photos and Verified Business.
/// Server: GET /admin/verification/{documents|photos|business}?status=PENDING, then approve / reject per item.
class AdminVerificationScreen extends StatelessWidget {
  const AdminVerificationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: AppColors.background,
        appBar: AppBar(
          title: Text(adminT('Verification review', 'Uhakiki wa vitambulisho')),
          bottom: TabBar(tabs: [
            Tab(text: adminT('ID papers', 'Vitambulisho')),
            Tab(text: adminT('Photos', 'Picha')),
            Tab(text: adminT('Business', 'Biashara')),
          ]),
        ),
        body: const TabBarView(children: [
          _Queue(kind: 'documents'),
          _Queue(kind: 'photos'),
          _Queue(kind: 'business'),
        ]),
      ),
    );
  }
}

class _Queue extends StatefulWidget {
  final String kind; // documents | photos | business
  const _Queue({required this.kind});

  @override
  State<_Queue> createState() => _QueueState();
}

class _QueueState extends State<_Queue> with AutomaticKeepAliveClientMixin {
  bool _loading = true;
  bool _forbidden = false;
  bool _failed = false;
  List<Map<String, dynamic>> _items = [];
  final Set<String> _busy = {};

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _failed = false;
    });
    final r = await ApiService.adminGetList('/admin/verification/${widget.kind}?status=PENDING');
    if (!mounted) return;
    setState(() {
      _loading = false;
      _forbidden = r.forbidden;
      _failed = !r.forbidden && r.items == null;
      _items = r.items ?? [];
    });
  }

  /// documents are approved by their id; photos and business by the user id.
  String _key(Map<String, dynamic> m) => widget.kind == 'documents' ? '${m['id']}' : '${m['userId']}';

  Future<void> _act(Map<String, dynamic> m, bool approve) async {
    final key = _key(m);
    Map<String, dynamic>? body;
    if (approve) {
      if (widget.kind == 'documents' && '${m['type']}'.toLowerCase().startsWith('id_')) {
        final name = await adminPrompt(context,
            title: adminT('Legal name on the ID', 'Jina la kisheria kwenye kitambulisho'),
            hint: adminT('Optional: name as printed on the ID', 'Si lazima: jina kama lilivyo kwenye kitambulisho'),
            initial: '${m['claimedName'] ?? ''}'.replaceAll('null', ''));
        if (name == null || !mounted) return;
        if (name.isNotEmpty) body = {'legalName': name};
      } else if (widget.kind == 'business') {
        final now = DateTime.now();
        final d = await showDatePicker(
          context: context,
          helpText: adminT('Business licence expires on', 'Leseni ya biashara inaisha tarehe'),
          initialDate: DateTime(now.year + 1, now.month, now.day),
          firstDate: now,
          lastDate: DateTime(now.year + 10),
        );
        if (d == null || !mounted) return;
        body = {'expiresAt': '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}'};
      }
    } else {
      final reason = await adminPrompt(context,
          title: adminT('Reject: reason', 'Kataa: sababu'),
          hint: adminT('Shown to the user', 'Itaonyeshwa kwa mtumiaji'),
          required: true);
      if (reason == null || !mounted) return;
      body = {'reason': reason};
    }
    setState(() => _busy.add(key));
    final res = await ApiService.adminSend('POST', '/admin/verification/${widget.kind}/$key/${approve ? 'approve' : 'reject'}', body);
    if (!mounted) return;
    setState(() => _busy.remove(key));
    if (res.error != null) {
      adminSnack(context, res.error!);
      return;
    }
    setState(() => _items.removeWhere((e) => _key(e) == key));
    adminSnack(context, approve ? adminT('Approved', 'Imekubaliwa') : adminT('Rejected', 'Imekataliwa'));
  }

  void _zoom(String url) {
    showDialog<void>(
      context: context,
      builder: (ctx) => Dialog.fullscreen(
        backgroundColor: Colors.black,
        child: Stack(children: [
          Positioned.fill(
            child: InteractiveViewer(
              child: Image.network(url, headers: ApiService.adminHeaders(), fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => const Center(child: Icon(Icons.broken_image_outlined, color: Colors.white54, size: 48))),
            ),
          ),
          Positioned(top: 32, right: 12, child: IconButton(icon: const Icon(Icons.close, color: Colors.white), onPressed: () => Navigator.pop(ctx))),
        ]),
      ),
    );
  }

  Widget _card(Map<String, dynamic> m) {
    final key = _key(m);
    final busy = _busy.contains(key);
    String? imageUrl;
    if (widget.kind == 'documents') {
      imageUrl = ApiService.absoluteUrl('/api/admin/verification/documents/${m['id']}/file');
    } else if (widget.kind == 'photos' && '${m['url'] ?? ''}'.isNotEmpty) {
      imageUrl = ApiService.absoluteUrl('${m['url']}');
    }
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.all(14),
      decoration: adminCardDecoration(),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('${m['stageName'] ?? adminT('User', 'Mtumiaji')}  #${m['userId']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
        adminInfoLine(adminT('Type', 'Aina'), m['type']),
        adminInfoLine(adminT('ID kind', 'Aina ya kitambulisho'), m['idKind']),
        adminInfoLine(adminT('Name claimed', 'Jina alilotaja'), m['claimedName']),
        adminInfoLine(adminT('Business', 'Biashara'), m['businessName']),
        adminInfoLine(adminT('Uploaded', 'Imepakiwa'), m['uploadedAt']),
        if (imageUrl != null) ...[
          const SizedBox(height: 10),
          GestureDetector(
            onTap: () => _zoom(imageUrl!),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.network(imageUrl, headers: ApiService.adminHeaders(), height: 190, width: double.infinity, fit: BoxFit.cover,
                  loadingBuilder: (c, child, p) => p == null ? child : const SizedBox(height: 190, child: Center(child: CircularProgressIndicator())),
                  errorBuilder: (_, __, ___) => Container(
                        height: 120,
                        color: AppColors.borderLight,
                        child: const Center(child: Icon(Icons.broken_image_outlined, color: AppColors.textMuted, size: 36)),
                      )),
            ),
          ),
        ],
        const SizedBox(height: 12),
        Row(children: [
          Expanded(
            child: OutlinedButton(
              onPressed: busy ? null : () => _act(m, false),
              style: OutlinedButton.styleFrom(foregroundColor: AppColors.danger),
              child: Text(adminT('Reject', 'Kataa')),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: ElevatedButton(
              onPressed: busy ? null : () => _act(m, true),
              child: busy
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : Text(adminT('Approve', 'Kubali')),
            ),
          ),
        ]),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final state = adminStateOrNull(
      loading: _loading,
      forbidden: _forbidden,
      failed: _failed,
      empty: _items.isEmpty,
      onRetry: _load,
      emptyText: adminT('Nothing waiting for review.', 'Hakuna kinachosubiri uhakiki.'),
    );
    return RefreshIndicator(
      onRefresh: _load,
      child: state != null
          ? ListView(children: [SizedBox(height: 400, child: state)])
          : ListView(padding: const EdgeInsets.only(bottom: 24), children: [for (final m in _items) _card(m)]),
    );
  }
}
