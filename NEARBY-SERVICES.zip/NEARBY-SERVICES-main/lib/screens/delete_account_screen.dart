import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/error_messages.dart';
import '../widgets/app_ui.dart';

/// In-app account deletion (required by Google Play and the App Store).
///
/// Shows what will be erased and what is kept, explains anything that blocks it (money in the pocket fund,
/// bookings in progress), then asks for the password. The server does the real checks and the erasing.
class DeleteAccountScreen extends StatefulWidget {
  const DeleteAccountScreen({super.key});

  @override
  State<DeleteAccountScreen> createState() => _DeleteAccountScreenState();
}

class _DeleteAccountScreenState extends State<DeleteAccountScreen> {
  final _password = TextEditingController();
  bool _checking = true;
  String? _blocker;
  bool _understood = false;
  bool _deleting = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _check();
  }

  @override
  void dispose() {
    _password.dispose();
    super.dispose();
  }

  Future<void> _check() async {
    final reason = await ApiService.accountDeleteBlocker();
    if (!mounted) return;
    setState(() {
      _blocker = reason;
      _checking = false;
    });
  }

  Future<void> _delete() async {
    final isEn = AppStrings.isEnglish;
    final pw = _password.text;
    if (pw.isEmpty) {
      setState(() => _error = isEn ? 'Enter your password to confirm.' : 'Weka nenosiri lako kuthibitisha.');
      return;
    }
    final sure = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(isEn ? 'Delete account for good?' : 'Futa akaunti moja kwa moja?'),
        content: Text(isEn
            ? 'This cannot be undone. Your profile, services and ID papers will be erased.'
            : 'Hili haliwezi kurudishwa. Wasifu wako, huduma na nyaraka za kitambulisho vitafutwa.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(isEn ? 'Cancel' : 'Ghairi')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(isEn ? 'Delete' : 'Futa', style: const TextStyle(color: AppColors.danger)),
          ),
        ],
      ),
    );
    if (sure != true || !mounted) return;

    setState(() {
      _deleting = true;
      _error = null;
    });
    final err = await ApiService.deleteAccount(pw);
    if (!mounted) return;
    if (err != null) {
      setState(() {
        _deleting = false;
        _error = err;
      });
      return;
    }
    // The session is already cleared. Go back to the first screen and say it is done.
    final messenger = ScaffoldMessenger.of(context);
    Navigator.of(context).popUntil((r) => r.isFirst);
    messenger.showSnackBar(SnackBar(
      content: Text(isEn ? 'Your account has been deleted.' : 'Akaunti yako imefutwa.'),
    ));
  }

  Widget _bullet(String text, {IconData icon = Icons.check_rounded, Color color = AppColors.textSecondary}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 14, height: 1.4, color: AppColors.textPrimary))),
        ],
      ),
    );
  }

  Widget _heading(String text) => Padding(
        padding: const EdgeInsets.only(top: 16, bottom: 8),
        child: Text(text, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
      );

  @override
  Widget build(BuildContext context) {
    final isEn = AppStrings.isEnglish;
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: _deleting ? null : () => Navigator.pop(context),
        ),
        title: Text(
          isEn ? 'Delete account' : 'Futa akaunti',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
      ),
      body: SafeArea(
        child: _checking
            ? const Center(child: CircularProgressIndicator())
            : ListView(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: AppColors.dangerLight, borderRadius: BorderRadius.circular(12)),
                    child: Text(
                      isEn
                          ? 'Deleting your account is permanent. You will be signed out and cannot sign in to it again.'
                          : 'Kufuta akaunti ni kwa kudumu. Utatolewa kwenye akaunti na huwezi kuiingia tena.',
                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.dangerDark),
                    ),
                  ),
                  _heading(isEn ? 'What is erased' : 'Kinachofutwa'),
                  _bullet(isEn ? 'Your name, phone number, email and password' : 'Jina, namba ya simu, barua pepe na nenosiri lako'),
                  _bullet(isEn ? 'Your photos, bio and social links' : 'Picha, wasifu na viungo vyako vya mitandao'),
                  _bullet(isEn ? 'Your ID papers, selfie and business documents' : 'Nyaraka zako za kitambulisho, selfie na za biashara'),
                  _bullet(isEn ? 'Your services (switched off) and your saved location' : 'Huduma zako (zinazimwa) na eneo ulilohifadhi'),
                  _heading(isEn ? 'What is kept' : 'Kinachobaki'),
                  _bullet(
                    isEn
                        ? 'Payment and booking records, without any personal details, as the law requires'
                        : 'Rekodi za malipo na maombi, bila taarifa binafsi, kama sheria inavyotaka',
                    icon: Icons.info_outline_rounded,
                  ),
                  _bullet(
                    isEn
                        ? 'Messages you sent stay in other people\'s chats as "Deleted user"'
                        : 'Ujumbe uliotuma unabaki kwenye mazungumzo ya wengine kama "Deleted user"',
                    icon: Icons.info_outline_rounded,
                  ),
                  const SizedBox(height: 8),
                  if (_blocker != null) ...[
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(color: AppColors.warningLight, borderRadius: BorderRadius.circular(12)),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(Icons.warning_amber_rounded, color: AppColors.warningDark),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              ErrorMessages.lookup(_blocker) ??
                                  (isEn ? 'The account cannot be deleted right now.' : 'Akaunti haiwezi kufutwa kwa sasa.'),
                              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    AppButton.outlined(label: isEn ? 'Check again' : 'Angalia tena', onPressed: () async {
                      setState(() => _checking = true);
                      await _check();
                    }),
                  ] else ...[
                    _heading(isEn ? 'Confirm with your password' : 'Thibitisha kwa nenosiri lako'),
                    AppTextField(
                      controller: _password,
                      icon: Icons.lock_outline_rounded,
                      hint: isEn ? 'Password' : 'Nenosiri',
                      obscureText: true,
                      errorText: _error,
                      onChanged: (_) {
                        if (_error != null) setState(() => _error = null);
                      },
                    ),
                    const SizedBox(height: 8),
                    CheckboxListTile(
                      contentPadding: EdgeInsets.zero,
                      controlAffinity: ListTileControlAffinity.leading,
                      value: _understood,
                      onChanged: _deleting ? null : (v) => setState(() => _understood = v ?? false),
                      title: Text(
                        isEn ? 'I understand this cannot be undone' : 'Naelewa kuwa hili haliwezi kurudishwa',
                        style: const TextStyle(fontSize: 14, color: AppColors.textPrimary),
                      ),
                    ),
                    const SizedBox(height: 8),
                    AppButton.primary(
                      label: isEn ? 'Delete my account' : 'Futa akaunti yangu',
                      color: AppColors.danger,
                      loading: _deleting,
                      onPressed: (_understood && !_deleting) ? _delete : null,
                    ),
                  ],
                ],
              ),
      ),
    );
  }
}
