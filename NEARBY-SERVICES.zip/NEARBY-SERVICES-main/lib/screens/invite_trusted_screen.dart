import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/deep_link_service.dart';
import '../services/session_manager.dart';
import '../services/currency_service.dart';
import '../widgets/app_ui.dart';
import '../widgets/country_code_picker.dart';
import '../services/app_log.dart';

/// A verified provider (Green Badge or Blue) vouches for someone
/// they personally know and trust. Many people have a NIN but no ID photo, so
/// this is how they can still earn a Green Badge (identity only): the inviter creates the
/// invitation here, the invited person accepts it with their NIN, and both are
/// on record as knowing and trusting each other.
class InviteTrustedScreen extends StatefulWidget {
  const InviteTrustedScreen({super.key});

  @override
  State<InviteTrustedScreen> createState() => _InviteTrustedScreenState();
}

class _InviteTrustedScreenState extends State<InviteTrustedScreen> {
  final _phone = TextEditingController();
  bool _vouch = false;
  bool _creating = false;
  bool _loadingList = true;
  List<Map<String, dynamic>>? _sent; // null = could not be loaded
  String? _error;
  List<Map<String, dynamic>> _requests = const []; // people asking me to vouch for them

  // The invitation just created, ready to share.
  String? _createdCode;
  String _createdPhone = ''; // digits with country code

  bool get _isEn => AppStrings.isEnglish;
  bool get _hasBlueTick => SessionManager.canInvite();

  @override
  void initState() {
    super.initState();
    _loadList();
  }

  @override
  void dispose() {
    _phone.dispose();
    super.dispose();
  }

  Future<void> _loadList() async {
    final raw = await ApiService.fetchInvitations();
    final reqs = await ApiService.fetchVouchRequests();
    if (!mounted) return;
    setState(() {
      _loadingList = false;
      _requests = [
        for (final r in reqs ?? const <Map<String, dynamic>>[])
          if (r['direction']?.toString().toUpperCase() == 'RECEIVED' && (r['status'] ?? 'PENDING').toString().toUpperCase() == 'PENDING') r,
      ];
      _sent = raw == null
          ? null
          : [
              for (final e in raw)
                if (e is Map && e['direction']?.toString().toUpperCase() != 'RECEIVED') Map<String, dynamic>.from(e),
            ];
    });
  }

  /// Digits with the country code of the account (Tanzania by default): 0712... -> 255712...
  String _intlDigits(String raw) {
    final dial = CurrencyService.current.dial;
    var d = raw.replaceAll(RegExp(r'[^0-9]'), '');
    if (d.startsWith('00')) d = d.substring(2);
    if (d.startsWith('0')) d = '$dial${d.substring(1)}';
    if (d.length == CurrencyService.current.nationalLength) d = '$dial$d';
    return d;
  }

  String _fullCode(String serverCode) => '${SessionManager.getUserIdValue()}-$serverCode';

  String _message(String code) => _isEn
      ? 'I know you personally and I trust you, so I am inviting you to get verified (Green Badge) on Ungana. '
          'Tap this link: ${DeepLinkService.inviteLink(code)}\n'
          'Or open the app > Profile > "I have an invitation" and enter this code: $code '
          '(save your legal name and NIN in Identity Verification first).'
      : 'Nakujua binafsi na ninakuamini, kwa hiyo nakualika upate uthibitisho (Green Badge) kwenye Ungana. '
          'Bonyeza link hii: ${DeepLinkService.inviteLink(code)}\n'
          'Au fungua programu > Wasifu > "Nina mwaliko" kisha weka msimbo huu: $code '
          '(hifadhi kwanza jina lako la kisheria na NIN kwenye Uthibitisho wa Utambulisho).';

  Future<void> _create() async {
    final digits = _intlDigits(_phone.text);
    final mine = _intlDigits(SessionManager.getPhone());
    String? err;
    if (digits.length < 11 || digits.length > 15) {
      err = _isEn ? 'Enter a valid phone number.' : 'Weka namba sahihi ya simu.';
    } else if (mine.isNotEmpty && digits == mine) {
      err = _isEn ? 'You cannot invite yourself.' : 'Huwezi kujialika mwenyewe.';
    } else if (!_vouch) {
      err = _isEn ? 'Please confirm that you know and trust this person.' : 'Tafadhali thibitisha kuwa unamjua na unamwamini mtu huyu.';
    }
    if (err != null) {
      setState(() => _error = err);
      return;
    }
    setState(() {
      _creating = true;
      _error = null;
    });
    final res = await ApiService.createInvitation(inviteePhone: '+$digits');
    if (!mounted) return;
    final code = (res.data['code'] ?? res.data['inviteCode'])?.toString().trim() ?? '';
    setState(() {
      _creating = false;
      if (!res.ok) {
        _error = res.error;
      } else if (code.isEmpty) {
        _error = _isEn ? 'The invitation was created but the server sent no code.' : 'Mwaliko umetengenezwa lakini seva haikutuma msimbo.';
      } else {
        _createdCode = _fullCode(code);
        _createdPhone = digits;
        _phone.clear();
        _vouch = false;
      }
    });
    if (res.ok && code.isNotEmpty) _loadList();
  }

  void _snack(String text, {bool error = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: error ? AppColors.danger : null,
      content: Text(text),
    ));
  }

  Future<void> _copy(String code) async {
    await Clipboard.setData(ClipboardData(text: code));
    if (mounted) _snack(_isEn ? 'Code copied' : 'Msimbo umenakiliwa');
  }

  /// WhatsApp opens with the message ready; the person picks the contact there
  /// (whatsapp://send?text=...). Falls back to the system share sheet.
  Future<void> _shareWhatsApp(String code) async {
    final text = _message(code);
    var ok = false;
    try {
      ok = await launchUrl(
        Uri.parse('whatsapp://send?text=${Uri.encodeComponent(text)}'),
        mode: LaunchMode.externalApplication,
      );
    } catch (caught, trace) { AppLog.e('invite_trusted_screen._shareWhatsApp', caught, trace); }
    if (!ok) await _shareMore(code, notice: _isEn ? 'WhatsApp not found. Choose another app.' : 'WhatsApp haijapatikana. Chagua programu nyingine.');
  }

  /// Opens the phone's messages app with the invited number and text filled in.
  Future<void> _shareSms(String code, String digits) async {
    final text = _message(code);
    var ok = false;
    try {
      ok = await launchUrl(
        Uri.parse('sms:+$digits?body=${Uri.encodeComponent(text)}'),
        mode: LaunchMode.externalApplication,
      );
    } catch (caught, trace) { AppLog.e('invite_trusted_screen._shareSms', caught, trace); }
    if (!ok) await _shareMore(code);
  }

  /// System share sheet: any installed messaging, email or social app.
  Future<void> _shareMore(String code, {String? notice}) async {
    if (notice != null && mounted) _snack(notice);
    try {
      await Share.share(_message(code), subject: _isEn ? 'Ungana invitation' : 'Mwaliko wa Ungana');
    } catch (caught, trace) {
      AppLog.e('invite_trusted_screen._shareMore', caught, trace);
      if (mounted) _snack(_isEn ? 'Could not open sharing' : 'Imeshindwa kufungua kushiriki', error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _isEn ? 'Invite someone you trust' : 'Alika unayemwamini',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: _loadList,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16),
          children: [
            _intro(),
            const SizedBox(height: 16),
            if (_hasBlueTick && _requests.isNotEmpty) ...[
              _requestsCard(),
              const SizedBox(height: 16),
            ],
            if (!_hasBlueTick)
              _notice(_isEn ? 'Only verified providers (Green Badge or Blue) can invite others.' : 'Ni watoa huduma waliothibitishwa (Green Badge au Blue) pekee wanaoweza kualika wengine.')
            else ...[
              _form(),
              if (_createdCode != null) ...[
                const SizedBox(height: 16),
                _createdCard(_createdCode!, _createdPhone),
              ],
            ],
            const SizedBox(height: 20),
            _sentList(),
          ],
        ),
      ),
    );
  }

  Future<void> _answer(Map<String, dynamic> r, bool approve) async {
    final id = (r['id'] ?? '').toString();
    if (id.isEmpty) return;
    if (approve) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
          title: Text(_isEn ? 'Vouch for this person?' : 'Mthibitishe mtu huyu?'),
          content: Text(_isEn
              ? 'Only approve if you know them personally and trust them. They will get an invitation for the Green Badge, and you will be on record as vouching for them.'
              : 'Kubali tu kama unamjua binafsi na unamwamini. Atapata mwaliko wa Green Badge, na utarekodiwa kama uliyemthibitisha.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: Text(_isEn ? 'Cancel' : 'Ghairi')),
            TextButton(onPressed: () => Navigator.pop(c, true), child: Text(_isEn ? 'I know and trust them' : 'Namjua na namwamini')),
          ],
        ),
      );
      if (ok != true || !mounted) return;
    }
    final res = await ApiService.answerVouchRequest(id: id, approve: approve);
    if (!mounted) return;
    _snack(res.ok ? (approve ? (_isEn ? 'Approved. They can accept their invitation now.' : 'Umekubali. Sasa wanaweza kukubali mwaliko wao.') : (_isEn ? 'Request declined.' : 'Ombi limekataliwa.')) : (res.error ?? ''), error: !res.ok);
    if (res.ok) _loadList();
  }

  Widget _requestsCard() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.primary.withValues(alpha: 0.4)),
      ),
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _isEn ? 'Asking you to vouch for them' : 'Wanakuomba uwathibitishe',
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
          ),
          const SizedBox(height: 4),
          Text(
            _isEn ? 'Only approve people you know personally and trust.' : 'Kubali tu watu unaowajua binafsi na kuwaamini.',
            style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
          ),
          for (final r in _requests) ...[
            const Divider(height: 20, color: AppColors.borderLight),
            Text(
              ((r['name'] ?? r['requesterName'] ?? '').toString().trim().isNotEmpty ? (r['name'] ?? r['requesterName']).toString().trim() : (r['phone'] ?? '').toString()),
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: AppButton.outlined(label: _isEn ? 'Decline' : 'Kataa', onPressed: () => _answer(r, false))),
                const SizedBox(width: 10),
                Expanded(child: AppButton.primary(label: _isEn ? 'Approve' : 'Kubali', onPressed: () => _answer(r, true))),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _intro() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.verified_rounded, color: AppColors.primary, size: 22),
              const SizedBox(width: 8),
              Text(
                _isEn ? 'Vouch for a person you know' : 'Mdhamini mtu unayemjua',
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            _isEn
                ? 'Many people have a NIN but no ID photo. As a verified provider you can invite someone you personally know. '
                    'When they accept, they get a Green Badge (identity only; Blue is for Verified Business), and you both stand on record as knowing and trusting each other.'
                : 'Watu wengi wana NIN lakini hawana picha ya kitambulisho. Kama mtoa huduma aliyethibitishwa unaweza kumwalika mtu unayemjua binafsi. '
                    'Akikubali, naye anapata Green Badge (utambulisho tu; Blue ni ya Biashara Iliyothibitishwa), na nyote mnabaki kwenye kumbukumbu mkijuana na kuaminiana.',
            style: const TextStyle(fontSize: 12, height: 1.45, color: AppColors.textSecondary),
          ),
          const SizedBox(height: 8),
          Text(
            _isEn ? 'Only invite people you truly trust. Your verified badge is your word.' : 'Alika tu watu unaowaamini kweli. Beji yako ya uthibitisho ni neno lako.',
            style: const TextStyle(fontSize: 12, height: 1.45, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
          ),
        ],
      ),
    );
  }

  Widget _notice(String text) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppColors.warningLight, borderRadius: BorderRadius.circular(12)),
      child: Text(text, style: const TextStyle(fontSize: 12, color: AppColors.warningDark)),
    );
  }

  Widget _form() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AppTextField(
            controller: _phone,
            icon: Icons.phone_outlined,
            label: _isEn ? 'Their phone number' : 'Namba yao ya simu',
            prefix: const AccountCountryCode(),
            hint: '07XX XXX XXX',
            keyboardType: TextInputType.phone,
            errorText: _error,
            enabled: !_creating,
          ),
          const SizedBox(height: 12),
          InkWell(
            onTap: _creating ? null : () => setState(() => _vouch = !_vouch),
            borderRadius: BorderRadius.circular(8),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Checkbox(
                  value: _vouch,
                  activeColor: AppColors.primary,
                  onChanged: _creating ? null : (v) => setState(() => _vouch = v ?? false),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Text(
                      _isEn
                          ? 'I personally know this person and I trust them.'
                          : 'Namjua mtu huyu binafsi na ninamwamini.',
                      style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textPrimary),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          AppButton.primary(
            label: _isEn ? 'Create invitation' : 'Tengeneza mwaliko',
            loading: _creating,
            onPressed: _creating ? null : _create,
          ),
        ],
      ),
    );
  }

  /// The code to hand over, with one-tap sharing.
  Widget _createdCard(String code, String digits) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.successLight,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.success.withValues(alpha: 0.4)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _isEn ? 'Invitation ready. Send them this code:' : 'Mwaliko uko tayari. Watumie msimbo huu:',
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.successDark),
          ),
          const SizedBox(height: 8),
          SelectableText(
            code,
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, letterSpacing: 2, color: AppColors.textPrimary),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              OutlinedButton.icon(
                onPressed: () => _shareWhatsApp(code),
                icon: const Icon(Icons.chat_rounded, size: 16),
                label: const Text('WhatsApp'),
              ),
              OutlinedButton.icon(
                onPressed: () => _shareSms(code, digits),
                icon: const Icon(Icons.sms_outlined, size: 16),
                label: const Text('SMS'),
              ),
              OutlinedButton.icon(
                onPressed: () => _shareMore(code),
                icon: const Icon(Icons.share_rounded, size: 16),
                label: Text(_isEn ? 'More' : 'Zaidi'),
              ),
              OutlinedButton.icon(
                onPressed: () => _copy(code),
                icon: const Icon(Icons.copy_rounded, size: 16),
                label: Text(_isEn ? 'Copy' : 'Nakili'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _sentList() {
    if (_loadingList) {
      return const Center(child: Padding(padding: EdgeInsets.all(16), child: CircularProgressIndicator(color: AppColors.primary)));
    }
    final sent = _sent;
    if (sent == null) return const SizedBox.shrink(); // list not available: keep the screen clean
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          _isEn ? 'People you invited' : 'Watu uliowaalika',
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        const SizedBox(height: 8),
        if (sent.isEmpty)
          Text(
            _isEn ? 'No invitations yet.' : 'Bado hujaalika mtu.',
            style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
          )
        else
          Container(
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.border),
            ),
            child: Column(
              children: [
                for (var i = 0; i < sent.length; i++) ...[
                  _sentTile(sent[i]),
                  if (i < sent.length - 1) const Divider(height: 1, color: AppColors.borderLight),
                ],
              ],
            ),
          ),
      ],
    );
  }

  Widget _sentTile(Map<String, dynamic> inv) {
    final name = (inv['name'] ?? inv['inviteeName'] ?? '').toString().trim();
    final phone = (inv['phone'] ?? inv['inviteePhone'] ?? '').toString().trim();
    final status = (inv['status'] ?? 'PENDING').toString().toUpperCase();
    final code = (inv['code'] ?? inv['inviteCode'] ?? '').toString().trim();

    final String label;
    final Color color;
    switch (status) {
      case 'ACCEPTED':
        label = _isEn ? 'Accepted - has Green Badge' : 'Amekubali - ana Green Badge';
        color = AppColors.successDark;
      case 'EXPIRED':
      case 'CANCELLED':
        label = _isEn ? 'Expired' : 'Umeisha muda';
        color = AppColors.textMuted;
      default:
        label = _isEn ? 'Waiting for them' : 'Anamsubiri';
        color = AppColors.warningDark;
    }
    final pending = status != 'ACCEPTED' && status != 'EXPIRED' && status != 'CANCELLED';
    return ListTile(
      title: Text(
        name.isNotEmpty ? name : (phone.isNotEmpty ? phone : (_isEn ? 'Invited person' : 'Aliyealikwa')),
        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
      ),
      subtitle: Padding(
        padding: const EdgeInsets.only(top: 4),
        child: Align(alignment: Alignment.centerLeft, child: StatusPill(text: label, color: color)),
      ),
      trailing: pending && code.isNotEmpty
          ? IconButton(
              tooltip: _isEn ? 'Copy code' : 'Nakili msimbo',
              icon: const Icon(Icons.copy_rounded, size: 18, color: AppColors.primary),
              onPressed: () => _copy(_fullCode(code)),
            )
          : null,
    );
  }
}
