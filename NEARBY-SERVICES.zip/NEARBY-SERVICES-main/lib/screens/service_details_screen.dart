import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import '../services/block_service.dart';
import '../services/call_service.dart';
import '../services/data_sync.dart';
import '../services/session_manager.dart';
import '../services/share_service.dart';
import '../widgets/ad_widgets.dart';
import '../widgets/app_image.dart';
import '../widgets/boost_badge.dart';
import '../widgets/call_options_sheet.dart';
import '../widgets/fullscreen_image_viewer.dart';
import '../widgets/login_modal.dart';
import '../widgets/block_user_dialog.dart';
import '../widgets/make_offer_sheet.dart';
import '../widgets/offer_flow_widgets.dart';
import '../services/need_signals.dart';
import '../services/offer_flow.dart';
import '../widgets/report_sheet.dart';
import '../widgets/sensitive_tag.dart';
import '../widgets/social_links_row.dart';
import '../widgets/service_badges.dart';
import '../widgets/verification_badge.dart';
import '../widgets/video_player_screen.dart';
import 'booking_request_screen.dart';
import '../services/currency_service.dart';
import 'chat_thread_screen.dart';
import 'seller_profile_screen.dart';
import '../widgets/online_indicator.dart';
import '../widgets/whatsapp_text.dart';
import '../models/ads_config.dart';

class ServiceDetailsScreen extends StatefulWidget {
  final ServiceItem service;

  const ServiceDetailsScreen({
    super.key,
    required this.service,
  });

  @override
  State<ServiceDetailsScreen> createState() => _ServiceDetailsScreenState();
}

class _ServiceDetailsScreenState extends State<ServiceDetailsScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  int _selectedDurationIndex = 0;
  int _selectedThumbnailIndex = 0;
  final PageController _heroController = PageController();
  final ScrollController _thumbScroll = ScrollController();
  static const double _thumbW = 84;
  static const double _thumbGap = 8;
  bool get _isFavorite => SessionManager.isFavorite(widget.service.id);
  int _selectedVideoIndex = 0;

  static const List<String> _monthsEn = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  String _monthYear(DateTime d) => '${_monthsEn[d.month - 1]} ${d.year}';

  // Opens the share sheet: WhatsApp, Messages, any other app, or copy.
  Future<void> _shareService(ServiceItem service) async {
    await ShareService.showServiceSheet(
      context,
      title: service.title,
      priceText: service.priceText,
      providerName: service.providerName,
      category: service.category,
      serviceId: service.id,
    );
  }

  // Keeps the big image, the counter and the thumbnail strip on the same image.
  void _selectImage(int i, {bool animateHero = false}) {
    if (i == _selectedThumbnailIndex && !animateHero) return;
    setState(() => _selectedThumbnailIndex = i);
    if (animateHero && _heroController.hasClients) {
      _heroController.animateToPage(i, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
    }
    if (_thumbScroll.hasClients) {
      final viewport = _thumbScroll.position.viewportDimension;
      final target = i * (_thumbW + _thumbGap) - (viewport - _thumbW) / 2;
      _thumbScroll.animateTo(target.clamp(0.0, _thumbScroll.position.maxScrollExtent),
          duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
    }
  }

  void _openGallery(int index) {
    if (_galleryImages.isEmpty) return;
    FullscreenImageViewer.open(
      context,
      images: _galleryImages,
      initialIndex: index,
      onIndexChanged: (i) {
        // Back from full screen on the image the person last looked at.
        if (!mounted) return;
        setState(() => _selectedThumbnailIndex = i);
        if (_heroController.hasClients) _heroController.jumpToPage(i);
      },
      onShare: () => _shareService(widget.service),
      initialSaved: _isFavorite,
      onSavedChanged: (v) {
        if (v != _isFavorite) {
          if (v) NeedSignals.recordFavorite(widget.service.category);
          SessionManager.toggleFavorite(widget.service.id);
        }
      },
    );
  }

  void _playVideo(int index) {
    final video = _videos[index];
    VideoPlayerScreen.open(context, url: video['url']!, title: video['title']!);
  }

  // The provider's uploaded videos (empty when they have none: the section is hidden).
  List<Map<String, String>> get _videos {
    final urls = widget.service.videoUrls;
    return [
      for (int i = 0; i < urls.length; i++)
        {
          'title': 'Video ${i + 1}',
          'subtitle': widget.service.title,
          'duration': '',
          'thumb': widget.service.featuredImage ?? '',
          'url': urls[i],
        },
    ];
  }

  // The provider's uploaded photos only.
  List<String> get _galleryImages => widget.service.imageUrls;

  // The listed duration/price of THIS service (the same price Home and Category
  // show), so what the buyer sees here is what the booking screen charges.
  List<Map<String, dynamic>> get _durations => [
        {
          'duration': widget.service.durationText,
          'price': widget.service.priceText,
          'priceVal': widget.service.priceAmount,
        },
      ];

  Widget _videoThumb(String path, {BorderRadius? radius}) {
    return ClipRRect(
      borderRadius: radius ?? BorderRadius.circular(12),
      child: AppImage(
        path,
        fit: BoxFit.cover,
        width: double.infinity,
        height: double.infinity,
        errorBuilder: (c, e, s) => Container(color: AppColors.slateDark),
      ),
    );
  }

  Widget _buildVideosSection() {
    final videos = _videos;
    if (videos.isEmpty) return const SizedBox.shrink();
    final selected = videos[_selectedVideoIndex.clamp(0, videos.length - 1)];
    // Remaining videos shown in the list below the featured one.
    final others = <int>[
      for (int i = 0; i < videos.length; i++)
        if (i != _selectedVideoIndex) i,
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Service Videos',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
          ),
          const SizedBox(height: 12),

          // Featured (big) video
          GestureDetector(
            onTap: () => _playVideo(_selectedVideoIndex),
            child: AspectRatio(
            aspectRatio: 16 / 10,
            child: Stack(
              fit: StackFit.expand,
              children: [
                _videoThumb(selected['thumb']!, radius: BorderRadius.circular(14)),
                Center(
                  child: Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.55),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 34),
                  ),
                ),
                if (selected['duration']!.isNotEmpty)
                Positioned(
                  right: 10,
                  bottom: 10,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.65),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      selected['duration']!,
                      style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
              ],
            ),
          ),
          ),
          const SizedBox(height: 10),

          // Other videos: thumbnails only, no titles or descriptions.
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final i in others)
                GestureDetector(
                  onTap: () {
                    setState(() => _selectedVideoIndex = i);
                    _playVideo(i);
                  },
                  child: SizedBox(
                    width: 96,
                    height: 66,
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        _videoThumb(videos[i]['thumb']!, radius: BorderRadius.circular(10)),
                        Center(
                          child: Container(
                            width: 28,
                            height: 28,
                            decoration: BoxDecoration(
                              color: Colors.black.withValues(alpha: 0.55),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 20),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    NeedSignals.recordServiceView(widget.service.category);
    _loadReviews();
    SessionManager.sessionNotifier.addListener(_onSessionChanged);
    DataSync.changed.addListener(_checkAccepted);
    _checkAccepted();
  }

  /// True once the provider accepted this buyer's booking for this service.
  bool _bookingAccepted = false;

  Future<void> _checkAccepted() async {
    if (!SessionManager.isLoggedIn()) {
      if (_bookingAccepted && mounted) setState(() => _bookingAccepted = false);
      return;
    }
    final txs = await ApiService.fetchBuyerTransactions();
    final svc = widget.service;
    final accepted = txs.any((tx) {
      // Accepted AND unlocked by the server (an accepted but unpaid booking keeps contacts locked).
      if ((tx['status'] ?? '').toString().toUpperCase() != 'ACCEPTED') return false;
      if (tx['contactsUnlocked'] != true) return false;
      final sid = (tx['serviceId'] ?? (tx['service'] is Map ? tx['service']['id'] : null))?.toString();
      if (sid != null && sid.isNotEmpty) return sid == svc.id;
      final seller = tx['seller'];
      final sellerId = (seller is Map ? seller['id'] : tx['sellerId'])?.toString();
      return sellerId != null && sellerId == svc.sellerId?.toString();
    });
    if (mounted && accepted != _bookingAccepted) setState(() => _bookingAccepted = accepted);
  }

  void _onSessionChanged() {
    if (mounted) setState(() {}); // favorite toggled (here or elsewhere)
  }

  @override
  void dispose() {
    DataSync.changed.removeListener(_checkAccepted);
    SessionManager.sessionNotifier.removeListener(_onSessionChanged);
    _tabController.dispose();
    _heroController.dispose();
    _thumbScroll.dispose();
    super.dispose();
  }

  // After the provider accepts the booking, "Book Now" is replaced by navigation
  // to the provider (opens in-app turn-by-turn navigation).
  Future<void> _emailProvider(String email) async {
    final ok = await launchUrl(Uri(scheme: 'mailto', path: email));
    if (!ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(AppStrings.isEnglish ? 'Could not open email app' : 'Imeshindwa kufungua barua pepe')),
      );
    }
  }

  Widget _navigateButton(ServiceItem service) {
    return ElevatedButton.icon(
      onPressed: () => CallService.navigate(
        context,
        lat: service.latitude,
        lng: service.longitude,
        query: [service.stageName, service.city ?? service.distance].join(' '),
        providerName: service.stageName,
        serviceTitle: service.title,
        providerId: service.sellerId,
      ),
      icon: const Icon(Icons.navigation_rounded, size: 18, color: Colors.white),
      label: _barLabel(
        AppStrings.isEnglish ? 'Navigate' : 'Elekea Mahali',
        const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: Colors.white),
      ),
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.success,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 8),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final service = widget.service;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: false,
        leading: Padding(
          padding: const EdgeInsets.all(8.0),
          child: InkWell(
            onTap: () => Navigator.pop(context),
            borderRadius: BorderRadius.circular(20),
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.border),
              ),
              child: const Icon(Icons.arrow_back_ios_new_rounded, size: 16, color: AppColors.textPrimary),
            ),
          ),
        ),
        titleSpacing: 0,
        title: FittedBox(
          fit: BoxFit.scaleDown,
          alignment: Alignment.centerLeft,
          child: Text(
            AppStrings.isEnglish ? 'Service Details' : 'Taarifa za Huduma',
            maxLines: 1,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
            ),
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: InkWell(
              onTap: () {
                if (!_isFavorite) NeedSignals.recordFavorite(widget.service.category);
                SessionManager.toggleFavorite(widget.service.id);
              },
              borderRadius: BorderRadius.circular(20),
              child: Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.border),
                ),
                child: Icon(
                  _isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                  size: 19,
                  color: _isFavorite ? AppColors.danger : AppColors.slateDark,
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Padding(
            padding: const EdgeInsets.only(top: 8, bottom: 8, right: 16),
            child: InkWell(
              onTap: () => _shareService(service),
              borderRadius: BorderRadius.circular(20),
              child: Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.border),
                ),
                child: const Icon(
                  Icons.share_outlined,
                  size: 19,
                  color: AppColors.slateDark,
                ),
              ),
            ),
          ),
          // Report this service (hidden on the provider's own service).
          if (!(SessionManager.isLoggedIn() && service.sellerId == SessionManager.getUserIdValue()))
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_vert_rounded, color: AppColors.slateDark),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              onSelected: (choice) async {
                final sid = service.sellerId;
                if (choice == 'block') {
                  if (sid == null) return;
                  if (!SessionManager.isLoggedIn()) {
                    final ok = await LoginModal.show(context);
                    if (ok != true || !context.mounted) return;
                  }
                  final done = await BlockUserDialog.confirmBlock(context, userId: sid, name: service.stageName);
                  if (done && context.mounted) Navigator.pop(context);
                  return;
                }
                final out = await ReportSheet.show(
                  context,
                  target: ReportTarget.service,
                  serviceId: service.id,
                  userId: sid,
                  name: service.stageName,
                );
                if (out.blocked && context.mounted) Navigator.pop(context);
              },
              itemBuilder: (_) => [
                PopupMenuItem(
                  value: 'report',
                  child: Row(
                    children: [
                      const Icon(Icons.flag_outlined, size: 18, color: AppColors.danger),
                      const SizedBox(width: 10),
                      Text(
                        AppStrings.isEnglish ? 'Report this service' : 'Ripoti huduma hii',
                        style: const TextStyle(fontWeight: FontWeight.w600, color: AppColors.danger),
                      ),
                    ],
                  ),
                ),
                if (service.sellerId != null && !BlockService.isBlocked(service.sellerId))
                  PopupMenuItem(
                    value: 'block',
                    child: Row(
                      children: [
                        const Icon(Icons.block_rounded, size: 18, color: AppColors.danger),
                        const SizedBox(width: 10),
                        Text(
                          AppStrings.isEnglish ? 'Block provider' : 'Mzuie mtoa huduma',
                          style: const TextStyle(fontWeight: FontWeight.w600, color: AppColors.danger),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          const SizedBox(width: 4),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.only(bottom: 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // AdMob banner above the big image (takes no space until an ad loads)
            const AdBannerView(page: AdPage.serviceDetails),

            // 1. Hero Image with Badges & Counter
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: ClipRRect(
                borderRadius: BorderRadius.zero, // big image: square corners
                child: GestureDetector(
                  onTap: () => _openGallery(_selectedThumbnailIndex),
                  child: Stack(
                  children: [
                    SizedBox(
                      height: 220,
                      width: double.infinity,
                      child: _galleryImages.isEmpty
                          ? Container(
                              color: AppColors.borderLight,
                              child: Icon(widget.service.icon, size: 64, color: AppColors.textMuted),
                            )
                          : PageView.builder(
                        controller: _heroController,
                        itemCount: _galleryImages.length,
                        onPageChanged: (i) => _selectImage(i),
                        itemBuilder: (ctx, i) => AppImage(
                          _galleryImages[i],
                          height: 220,
                          width: double.infinity,
                          fit: BoxFit.cover,
                          errorBuilder: (ctx, err, stack) => Container(
                            height: 220,
                            color: AppColors.borderLight,
                            child: const Icon(Icons.spa_rounded, size: 64, color: AppColors.textMuted),
                          ),
                        ),
                      ),
                    ),
                    // Verification pill top left (only for verified providers; colour follows their level)
                    if (service.isVerified)
                      Positioned(
                        top: 12,
                        left: 12,
                        // Badge only (no text), on a small white disc so it reads on any photo.
                        child: Container(
                          padding: const EdgeInsets.all(5),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.18), blurRadius: 6, offset: const Offset(0, 2))],
                          ),
                          child: VerificationBadge(level: service.verificationLevel, size: 22),
                        ),
                      ),
                    // 1/5 counter bottom right
                    if (_galleryImages.length > 1)
                    Positioned(
                      bottom: 12,
                      right: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.65),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          '${_selectedThumbnailIndex + 1}/${_galleryImages.length}',
                          style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                  ],
                  ),
                ),
              ),
            ),

            // 2. Thumbnails: scrollable, so any number of images works
            if (_galleryImages.length > 1)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: SizedBox(
                  height: 60,
                  child: ListView.separated(
                    controller: _thumbScroll,
                    scrollDirection: Axis.horizontal,
                    itemCount: _galleryImages.length,
                    separatorBuilder: (_, _) => const SizedBox(width: _thumbGap),
                    itemBuilder: (context, index) {
                      final isSelected = _selectedThumbnailIndex == index;
                      return GestureDetector(
                        onTap: () => _selectImage(index, animateHero: true),
                        child: Container(
                          width: _thumbW,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: isSelected ? AppColors.primary : Colors.transparent,
                              width: 2,
                            ),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: AppImage(
                              _galleryImages[index],
                              fit: BoxFit.cover,
                              errorBuilder: (ctx, err, stack) => Container(color: AppColors.border),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),

            // 16 under the thumbnail strip (as in the mockup); 8 when there is no strip.
            SizedBox(height: _galleryImages.length > 1 ? 16 : 8),

            // 3. Title, Category, Price & Duration Row
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          service.title,
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        if (service.is18Plus) ...[
                          const SizedBox(height: 6),
                          const Align(alignment: Alignment.centerLeft, child: SensitiveTag()),
                        ],
                        if (service.isBoosted) ...[
                          const SizedBox(height: 6),
                          const Align(alignment: Alignment.centerLeft, child: BoostBadge()),
                        ],
                        const SizedBox(height: 4),
                        if (service.category.trim().isNotEmpty)
                          Text(
                            service.category,
                            style: const TextStyle(
                              fontSize: 14,
                              color: AppColors.textSecondary,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  ConstrainedBox(
                    constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.45),
                    child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      if (_priceTypeLabel != null)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 2),
                          child: Text(_priceTypeLabel!, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.textSecondary)),
                        ),
                      if (widget.service.hasDiscount)
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Flexible(
                              child: Text(
                                widget.service.listedPriceText,
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: AppColors.textMuted,
                                  decoration: TextDecoration.lineThrough,
                                ),
                              ),
                            ),
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(color: AppColors.successLight, borderRadius: BorderRadius.circular(6)),
                              child: Text(
                                '-${widget.service.discountPercentShown}%',
                                style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.successDark),
                              ),
                            ),
                          ],
                        ),
                      FittedBox(
                        fit: BoxFit.scaleDown,
                        alignment: Alignment.centerRight,
                        child: Text(
                          _durations[_selectedDurationIndex]['price'] as String,
                          maxLines: 1,
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                            color: AppColors.primary,
                          ),
                        ),
                      ),
                      if (widget.service.hasDiscount && widget.service.discountEndsAt != null)
                        Text(
                          AppStrings.isEnglish
                              ? 'Sale ends ${widget.service.discountEndsAt!.toLocal().day}/${widget.service.discountEndsAt!.toLocal().month}'
                              : 'Punguzo linaisha ${widget.service.discountEndsAt!.toLocal().day}/${widget.service.discountEndsAt!.toLocal().month}',
                          style: const TextStyle(fontSize: 10, color: AppColors.warningDark),
                        ),
                      const SizedBox(height: 2),
                      Text(
                        AppStrings.detailsPerSession,
                        textAlign: TextAlign.end,
                        style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                      ),
                    ],
                  ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 10),

            // Rating & Location row (wraps on narrow screens, nothing is cut)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Wrap(
                spacing: 12,
                runSpacing: 6,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.star_rounded, color: AppColors.goldStar, size: 18),
                      const SizedBox(width: 4),
                      Text(
                        service.ratingText,
                        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                      ),
                      if (service.reviewsLabel.isNotEmpty) ...[
                        const SizedBox(width: 4),
                        Text(
                          service.reviewsLabel,
                          style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
                        ),
                      ],
                    ],
                  ),
                  if (service.locationLabel.trim().isNotEmpty)
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Padding(
                          padding: EdgeInsets.only(top: 1),
                          child: Icon(Icons.location_on_outlined, color: AppColors.primary, size: 15),
                        ),
                        const SizedBox(width: 4),
                        Flexible(
                          child: Text(
                            service.locationLabel,
                            style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontWeight: FontWeight.w500),
                          ),
                        ),
                      ],
                    ),
                  if (service.hasDuration)
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.access_time_rounded, color: AppColors.textSecondary, size: 14),
                        const SizedBox(width: 4),
                        Text(
                          _durations[_selectedDurationIndex]['duration'] as String,
                          style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontWeight: FontWeight.w500),
                        ),
                      ],
                    ),
                ],
              ),
            ),

            // Social media icons (WhatsApp, Instagram, Facebook, X, TikTok, YouTube)
            SocialLinksRow(service: service),

            // Email the provider typed when publishing: shown only once contacts are unlocked
            // (same rule as the phone and socials). Nothing is shown when they left it empty.
            if (!service.isContactLocked && (service.email ?? '').trim().isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
                child: InkWell(
                  borderRadius: BorderRadius.circular(8),
                  onTap: () => _emailProvider(service.email!.trim()),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.email_outlined, size: 16, color: AppColors.primary),
                        const SizedBox(width: 6),
                        Flexible(
                          child: Text(
                            service.email!.trim(),
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

            const SizedBox(height: 16),

            // 4. Earned badges: awarded by the server from the provider's reviews, plus a live
            // "Available Now" while they are online. Nothing is shown that was not earned.
            if (_earnedBadges.isNotEmpty || service.isOnline) ...[
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: LayoutBuilder(
                    builder: (context, c) {
                      const gap = 6.0;
                      final tileW = (c.maxWidth - gap) / 2;
                      Widget tile({required IconData icon, required Color iconColor, required Color bg, required String label, double iconSize = 16}) {
                        return Container(
                          width: tileW,
                          constraints: const BoxConstraints(minHeight: 44),
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
                          decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(14)),
                          child: Row(
                            children: [
                              Container(
                                width: 28,
                                height: 28,
                                decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                                child: Icon(icon, color: iconColor, size: iconSize),
                              ),
                              const SizedBox(width: 8),
                              Flexible(
                                child: Text(
                                  label,
                                  style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800, height: 1.2, color: AppColors.slateDark),
                                ),
                              ),
                            ],
                          ),
                        );
                      }

                      return Wrap(
                        spacing: gap,
                        runSpacing: gap,
                        children: [
                          for (final key in _earnedBadges)
                            Builder(builder: (_) {
                              final b = ServiceBadgeInfo.of(key);
                              return tile(icon: b.icon, iconColor: b.iconColor, bg: b.bgColor, label: b.label);
                            }),
                          // Online tile: only while the provider is online right now.
                          if (service.isOnline)
                            tile(
                              icon: Icons.circle,
                              iconColor: AppColors.onlineGreen,
                              bg: AppColors.successLight,
                              label: AppStrings.detailsAvailableNow,
                              iconSize: 10,
                            ),
                        ],
                      );
                    },
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],

            // 4b. Tasks and their prices (only when the provider listed some)
            if (service.tasks.isNotEmpty) ...[
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      AppStrings.isEnglish ? 'Tasks & prices' : 'Kazi na bei',
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      AppStrings.isEnglish
                          ? 'Pick one or more when you book. Each has its own price.'
                          : 'Chagua kazi moja au zaidi unapoomba. Kila moja ina bei yake.',
                      style: const TextStyle(fontSize: 12, color: AppColors.slateMuted),
                    ),
                    const SizedBox(height: 10),
                    for (final t in service.tasks)
                      Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                        decoration: BoxDecoration(
                          color: AppColors.surface,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: AppColors.border),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.task_alt_rounded, size: 18, color: AppColors.success),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                t.name,
                                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              CurrencyService.format(t.price),
                              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.primary),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
            ],

            // 5. About This Service: only what the provider wrote (nothing invented)
            if (service.subtitle.trim().isNotEmpty || service.features.isNotEmpty) ...[
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      AppStrings.detailsAboutService,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    if (service.subtitle.trim().isNotEmpty) ...[
                      const SizedBox(height: 8),
                      WhatsAppText(
                        service.subtitle.trim(),
                        style: const TextStyle(
                          fontSize: 13,
                          height: 1.5,
                          color: AppColors.slateMuted,
                        ),
                      ),
                    ],
                    if (service.features.isNotEmpty) ...[
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: service.features
                            .map((f) => _buildFeaturePill(
                                  icon: Icons.check_circle_rounded,
                                  iconColor: AppColors.success,
                                  bgColor: AppColors.successLight,
                                  label: f,
                                  iconSize: 14,
                                  wrap: true,
                                ))
                            .toList(),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 20),
            ],

            // AdMob banner between About and the provider card
            const AdBannerView(page: AdPage.serviceDetails, bottomGap: 20),

            // 6. Provider card: avatar, name, stats strip and a full-width View Profile button.
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: AppColors.border),
                  boxShadow: [
                    BoxShadow(color: AppColors.textPrimary.withValues(alpha: 0.04), blurRadius: 10, offset: const Offset(0, 2)),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: _openProviderProfile,
                      child: Row(
                        children: [
                          SizedBox(
                            width: 56,
                            height: 56,
                            child: Stack(
                              clipBehavior: Clip.none,
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(2),
                                  decoration: const BoxDecoration(shape: BoxShape.circle, color: AppColors.primaryLight),
                                  child: ClipOval(
                                    child: AppImage(
                                      service.sellerAvatar ?? '',
                                      width: 52,
                                      height: 52,
                                      fit: BoxFit.cover,
                                      errorBuilder: (ctx, err, stack) => const CircleAvatar(
                                        radius: 26,
                                        backgroundColor: AppColors.primary,
                                        child: Icon(Icons.person, color: Colors.white),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(bottom: 0, right: 0, child: OnlineDot(online: service.isOnline, size: 14)),
                              ],
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  AppStrings.isEnglish ? 'PROVIDED BY' : 'ANATOA HUDUMA',
                                  style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700, letterSpacing: 0.6, color: AppColors.textMuted),
                                ),
                                const SizedBox(height: 2),
                                // Name + badge flow together and wrap onto a second line when long.
                                Text.rich(
                                  TextSpan(
                                    children: [
                                      TextSpan(
                                        text: service.stageName,
                                        style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, letterSpacing: -0.2, color: AppColors.navy),
                                      ),
                                      if (service.isVerified)
                                        WidgetSpan(
                                          alignment: PlaceholderAlignment.middle,
                                          child: Padding(
                                            padding: const EdgeInsets.only(left: 5),
                                            child: VerificationBadge(level: service.verificationLevel, size: 17),
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                                if (service.category.trim().isNotEmpty || (service.city ?? '').trim().isNotEmpty) ...[
                                  const SizedBox(height: 2),
                                  Text(
                                    [service.category.trim(), (service.city ?? '').trim()].where((s) => s.isNotEmpty).join(' · '),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(fontSize: 12.5, color: AppColors.textSecondary),
                                  ),
                                ],
                              ],
                            ),
                          ),
                          const Icon(Icons.chevron_right_rounded, size: 22, color: AppColors.textDisabled),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),
                    _providerStats(service),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      height: 42,
                      child: OutlinedButton(
                        onPressed: _openProviderProfile,
                        style: OutlinedButton.styleFrom(
                          backgroundColor: AppColors.primaryLight,
                          side: const BorderSide(color: AppColors.primary),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        child: Text(
                          AppStrings.detailsViewProfile,
                          style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: AppColors.primary),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 20),

            // 7. Tab Bar (Overview, Portfolio, Reviews, Availability, Location)
            TabBar(
              controller: _tabController,
              isScrollable: true,
              labelColor: AppColors.primary,
              unselectedLabelColor: AppColors.textSecondary,
              labelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
              unselectedLabelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
              indicatorColor: AppColors.primary,
              indicatorWeight: 3,
              tabAlignment: TabAlignment.start,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              onTap: (index) => setState(() {}),
              tabs: [
                Tab(text: AppStrings.detailsTabOverview),
                Tab(text: AppStrings.detailsTabReviews),
                Tab(text: AppStrings.detailsTabAvailability),
                Tab(text: AppStrings.detailsTabLocation),
              ],
            ),

            const Divider(height: 1, color: AppColors.borderLight),

            const SizedBox(height: 16),

            // Tab-specific content
            if (_tabController.index == 0) ...[
              // Overview Tab Content:
              // 1. Service Videos Gallery (Item 2: Videos will be in overview tab)
              _buildVideosSection(),

              const SizedBox(height: 20),

              if (widget.service.hasDuration) ...[
              // 3. Service Duration & Price Section (only when the provider priced by duration)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      AppStrings.detailsServiceDurationPrice,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: List.generate(_durations.length, (index) {
                        final item = _durations[index];
                        final isSelected = _selectedDurationIndex == index;
                        return Expanded(
                          child: GestureDetector(
                            onTap: () => setState(() => _selectedDurationIndex = index),
                            child: Container(
                              margin: EdgeInsets.only(right: index == _durations.length - 1 ? 0 : 8),
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: isSelected ? AppColors.primaryLight : Colors.white,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: isSelected ? AppColors.primary : AppColors.border,
                                  width: isSelected ? 1.8 : 1,
                                ),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Flexible(
                                        child: Text(
                                          item['duration'] as String,
                                          style: TextStyle(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w700,
                                            color: isSelected ? AppColors.primary : AppColors.textPrimary,
                                          ),
                                        ),
                                      ),
                                      const SizedBox(width: 6),
                                      Icon(
                                        isSelected ? Icons.radio_button_checked : Icons.radio_button_off,
                                        size: 16,
                                        color: isSelected ? AppColors.primary : AppColors.textDisabled,
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    item['price'] as String,
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w800,
                                      color: isSelected ? AppColors.primary : AppColors.slateMuted,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      }),
                    ),
                  ],
                ),
              ),
              ],
            ] else if (_tabController.index == 1) ...[
              // Reviews Tab: same as the provider profile's Reviews tab.
              _reviewsTab(),
            ] else if (_tabController.index == 2) ...[
              // Availability Tab
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.background,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        AppStrings.isEnglish ? 'Working hours' : 'Saa za Kazi',
                        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      // The provider's own schedule; nothing is invented when they have not set one.
                      if (service.availableDays.isEmpty && service.availableFrom == null && service.availableTo == null)
                        Text(
                          AppStrings.isEnglish
                              ? 'The provider has not set working hours yet. Send a message to ask when they are available.'
                              : 'Mtoa huduma hajaweka saa za kazi bado. Mtumie ujumbe kuuliza anapopatikana.',
                          style: const TextStyle(fontSize: 12, color: AppColors.slateMuted),
                        )
                      else ...[
                        if (service.availableDays.isNotEmpty)
                          Text(
                            service.availableDays.join(', '),
                            style: const TextStyle(fontSize: 12, color: AppColors.slateMuted),
                          ),
                        if (service.availableFrom != null || service.availableTo != null) ...[
                          const SizedBox(height: 4),
                          Text(
                            (service.availableFrom != null && service.availableTo != null)
                                ? '${service.availableFrom} - ${service.availableTo}'
                                : service.availableFrom != null
                                    ? '${AppStrings.isEnglish ? 'From' : 'Kuanzia'} ${service.availableFrom}'
                                    : '${AppStrings.isEnglish ? 'Until' : 'Hadi'} ${service.availableTo}',
                            style: const TextStyle(fontSize: 12, color: AppColors.slateMuted),
                          ),
                        ],
                      ],
                      if (_modeLabel != null) ...[
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            const Icon(Icons.directions_walk_rounded, size: 16, color: AppColors.primary),
                            const SizedBox(width: 6),
                            Expanded(child: Text(_modeLabel!, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.slateMuted))),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ] else ...[
              // Location Tab
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.background,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.location_pin, color: AppColors.primary, size: 28),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              [
                                if ((service.area ?? '').trim().isNotEmpty) service.area!.trim(),
                                (service.city ?? '').trim().isEmpty ? CurrencyService.countryName : '${service.city!.trim()}, ${CurrencyService.countryName}',
                              ].join(', '),
                              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                            ),
                            if (_radiusLabel != null) ...[
                              const SizedBox(height: 2),
                              Text(_radiusLabel!, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.primary)),
                            ],
                            const SizedBox(height: 2),
                            if (service.distance.trim().isNotEmpty)
                              Text(
                                AppStrings.isEnglish
                                    ? 'About ${service.distance} from your location'
                                    : 'Umbali wa takriban ${service.distance} kutoka ulipo sasa',
                                style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                              ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),

      // 9. Bottom Action Bar: Chat | Call | Book Now
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.08),
              blurRadius: 16,
              offset: const Offset(0, -4),
            ),
          ],
        ),
        child: SafeArea(
          top: false,
          minimum: const EdgeInsets.only(bottom: 12),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (!_bookingAccepted && service.allowOffers && !(SessionManager.isLoggedIn() && service.sellerId == SessionManager.getUserIdValue()))
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: () async {
                      if (!SessionManager.isLoggedIn()) {
                        final loggedIn = await LoginModal.show(context);
                        if (loggedIn != true) return;
                      }
                      if (!context.mounted) return;
                      final offer = await MakeOfferSheet.show(context, service);
                      if (offer == null || !context.mounted) return;
                      DataSync.bump();
                      if (OfferFlow.stateOf(offer['status']) == OfferState.agreed) {
                        // The seller's auto-accept price accepted it: go straight to booking.
                        await showInstantlyAgreedDialog(context, offer, service);
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            backgroundColor: AppColors.success,
                            content: Text(AppStrings.isEnglish
                                ? 'Offer sent. Track it in Requests > Offers.'
                                : 'Ofa imetumwa. Ifuatilie kwenye Maombi > Ofa.'),
                          ),
                        );
                      }
                    },
                    icon: const Icon(Icons.local_offer_outlined, size: 18, color: AppColors.primary),
                    label: Text(
                      AppStrings.isEnglish ? 'Make an Offer' : 'Toa Ofa',
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.primary),
                    ),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: AppColors.primary),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                  ),
                ),
              ),
            Row(
          children: [
            // Chat Button
            Expanded(
              flex: 3,
              child: OutlinedButton.icon(
                onPressed: () => ChatThreadScreen.open(
                  context,
                  recipientId: service.sellerId,
                  name: service.stageName,
                  isOnline: service.isOnline,
                ),
                icon: const Icon(Icons.chat_bubble_outline_rounded, size: 18, color: AppColors.textPrimary),
                label: _barLabel(
                  AppStrings.detailsChat,
                  const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                ),
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: AppColors.border),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 8),
                ),
              ),
            ),
            const SizedBox(width: 8),

            // Call Button: opens the call options pop-up
            // (locked contacts -> in-app audio only; unlocked -> audio, video, mobile)
            Expanded(
              flex: 3,
              child: OutlinedButton.icon(
                onPressed: () => CallOptionsSheet.show(context, service),
                icon: const Icon(Icons.phone_outlined, size: 18, color: AppColors.primary),
                label: _barLabel(
                  AppStrings.isEnglish ? 'Call' : 'Piga Simu',
                  const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.primary),
                ),
                style: OutlinedButton.styleFrom(
                  backgroundColor: AppColors.primaryLight,
                  side: const BorderSide(color: AppColors.border),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 8),
                ),
              ),
            ),
            const SizedBox(width: 8),

            // Book Now Button
            Expanded(
              flex: 5,
              child: _bookingAccepted ? _navigateButton(service) : ElevatedButton.icon(
                onPressed: () async {
                  if (!SessionManager.isLoggedIn()) {
                    final loggedIn = await LoginModal.show(context);
                    if (loggedIn != true) return;
                  }

                  if (context.mounted) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => BookingRequestScreen(
                          provider: service,
                          serviceTitle: service.title,
                          priceText: _durations[_selectedDurationIndex]['price'] as String,
                          durationText: _durations[_selectedDurationIndex]['duration'] as String,
                        ),
                      ),
                    );
                  }
                },
                icon: const Icon(Icons.calendar_month_rounded, size: 18, color: Colors.white),
                label: _barLabel(
                  AppStrings.detailsBookNow,
                  const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: Colors.white),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 8),
                ),
              ),
            ),
          ],
        ),
          ],
        ),
          ),
        ),
      ),
    );
  }

  void _openProviderProfile() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => SellerProfileScreen(provider: widget.service)),
    );
  }

  /// Rating / jobs done / member since, in one light strip (a fact the provider has not earned is left out).
  Widget _providerStats(ServiceItem s) {
    final en = AppStrings.isEnglish;
    final cells = <Widget>[
      _statCell(
        value: s.ratingText,
        label: en ? 'Rating' : 'Ukadiriaji',
        leading: s.hasReviews ? const Icon(Icons.star_rounded, size: 14, color: AppColors.goldStar) : null,
      ),
      if ((s.completedJobs ?? 0) > 0) _statCell(value: '${s.completedJobs}', label: en ? 'Jobs done' : 'Kazi zilizokamilika'),
      if (s.sellerSince != null) _statCell(value: _monthYear(s.sellerSince!), label: AppStrings.detailsMemberSince),
    ];
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(color: AppColors.background, borderRadius: BorderRadius.circular(12)),
      child: Row(
        children: [
          for (var i = 0; i < cells.length; i++) ...[
            if (i > 0) Container(width: 1, height: 26, color: AppColors.border),
            Expanded(child: cells[i]),
          ],
        ],
      ),
    );
  }

  Widget _statCell({required String value, required String label, Widget? leading}) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (leading != null) ...[leading, const SizedBox(width: 3)],
            Flexible(
              child: Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.navy)),
            ),
          ],
        ),
        const SizedBox(height: 2),
        Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10.5, color: AppColors.textSecondary)),
      ],
    );
  }

  // Button label that shrinks to fit instead of wrapping or being cut off.
  Widget _barLabel(String text, TextStyle style) => FittedBox(
        fit: BoxFit.scaleDown,
        child: Text(text, maxLines: 1, softWrap: false, style: style),
      );

  /// 'Starting from' / 'Per hour' / 'Fixed price', straight from what the provider picked.
  String? get _priceTypeLabel {
    final en = AppStrings.isEnglish;
    switch (widget.service.priceType) {
      case 'STARTING_FROM':
        return en ? 'Starting from' : 'Kuanzia';
      case 'PER_HOUR':
        return en ? 'Per hour' : 'Kwa saa';
      case 'FIXED':
        return en ? 'Fixed price' : 'Bei maalum';
      default:
        return null;
    }
  }

  String? get _modeLabel {
    final en = AppStrings.isEnglish;
    switch (widget.service.serviceMode) {
      case 'customer_comes':
        return en ? 'Customer comes to the provider' : 'Mteja anakuja kwa mtoa huduma';
      case 'provider_travels':
        return en ? 'Provider travels to the customer' : 'Mtoa huduma anamfuata mteja';
      case 'both':
        return en ? 'Customer visits or provider travels' : 'Mteja anaenda au mtoa huduma anamfuata';
      default:
        return null;
    }
  }

  String? get _radiusLabel {
    final r = widget.service.serviceRadiusKm;
    if (r == null) return null;
    final en = AppStrings.isEnglish;
    return r == 0 ? (en ? 'Serves the whole city' : 'Anahudumia mji mzima') : (en ? 'Serves within $r km' : 'Anahudumia ndani ya km $r');
  }

  /// Automatic: worked out from the real rating and review count, merged with any server award.
  List<String> get _earnedBadges => ServiceBadgeRules.earned(
        rating: widget.service.rating,
        reviewsCount: widget.service.reviewsCount,
        fromServer: widget.service.badges,
      );

  Widget _buildFeaturePill({
    required IconData icon,
    required Color iconColor,
    required Color bgColor,
    required String label,
    double iconSize = 14,
    bool wrap = false, // true inside a Wrap: a long label wraps instead of overflowing
  }) {
    final text = Text(
      label,
      style: const TextStyle(
        fontSize: 11,
        fontWeight: FontWeight.w600,
        color: AppColors.slateMuted,
      ),
    );
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: iconColor, size: iconSize),
          const SizedBox(width: 6),
          wrap ? Flexible(child: text) : text,
        ],
      ),
    );
  }

  // ---------------------------------------------------------------- reviews
  // Same reviews layout as the provider profile (seller_profile_screen.dart):
  // rating summary with breakdown bars, then one card per review.

  late Future<List<dynamic>?> _reviewsFuture;

  void _loadReviews() {
    final id = widget.service.sellerId;
    _reviewsFuture = (id == null || id == 0) ? Future.value(<dynamic>[]) : ApiService.fetchProviderReviews(id);
  }

  String _dateText(DateTime d) => '${d.day} ${_monthsEn[d.month - 1]} ${d.year}';

  _ReviewData _parseReview(dynamic j) {
    if (j is! Map) return const _ReviewData(name: '', rating: 0, comment: '');
    final who = j['reviewer'] ?? j['buyer'] ?? j['user'] ?? j['author'] ?? const {};
    String name = '';
    if (who is Map) name = '${who['stageName'] ?? who['name'] ?? who['username'] ?? ''}'.trim();
    if (name.isEmpty) name = '${j['reviewerName'] ?? j['buyerName'] ?? j['name'] ?? ''}'.trim();
    final r = j['rating'] ?? j['stars'] ?? j['score'];
    final rating = r is num ? r.toDouble() : (double.tryParse('$r') ?? 0);
    final comment = '${j['comment'] ?? j['text'] ?? j['review'] ?? j['message'] ?? ''}'.trim();
    final date = DateTime.tryParse('${j['createdAt'] ?? j['date'] ?? ''}');
    final svcRaw = j['serviceTitle'] ?? j['serviceName'] ?? j['service'];
    final svc = svcRaw is Map ? '${svcRaw['title'] ?? svcRaw['name'] ?? ''}'.trim() : '${svcRaw ?? ''}'.trim();
    return _ReviewData(name: name, rating: rating, comment: comment, date: date, service: svc == 'null' ? '' : svc);
  }

  Widget _reviewStars(double rating, {double size = 14}) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(
        5,
        (i) => Icon(i < rating.round() ? Icons.star_rounded : Icons.star_outline_rounded, size: size, color: AppColors.goldStar),
      ),
    );
  }

  Widget _reviewCardShell({required Widget child}) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
      child: Material(
        color: AppColors.surface,
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: const BorderSide(color: AppColors.border)),
        child: Padding(padding: const EdgeInsets.all(14), child: child),
      ),
    );
  }

  Widget _reviewsEmpty(String title, String hint) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(32, 36, 32, 12),
      child: Column(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: const BoxDecoration(color: AppColors.primaryLight, shape: BoxShape.circle),
            child: const Icon(Icons.rate_review_outlined, color: AppColors.primary, size: 26),
          ),
          const SizedBox(height: 12),
          Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
          const SizedBox(height: 4),
          Text(hint, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textSecondary)),
        ],
      ),
    );
  }

  Widget _reviewsTab() {
    final en = AppStrings.isEnglish;
    final s = widget.service;
    return FutureBuilder<List<dynamic>?>(
      future: _reviewsFuture,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Padding(
            padding: EdgeInsets.all(40),
            child: Center(child: CircularProgressIndicator(color: AppColors.primary)),
          );
        }
        final list = snap.data?.map(_parseReview).where((r) => r.comment.isNotEmpty || r.rating > 0).toList();
        return Column(
          children: [
            if (s.hasReviews)
              _reviewCardShell(
                child: Row(
                  children: [
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(s.ratingText, style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w900, color: AppColors.textPrimary, letterSpacing: -1, height: 1)),
                        const SizedBox(height: 6),
                        _reviewStars(s.rating, size: 15),
                        const SizedBox(height: 4),
                        Text(
                          en ? '${s.reviewsCount} ${s.reviewsCount == 1 ? 'review' : 'reviews'}' : 'Maoni ${s.reviewsCount}',
                          style: const TextStyle(fontSize: 11.5, color: AppColors.textSecondary),
                        ),
                      ],
                    ),
                    // Breakdown from the reviews actually loaded (no invented numbers).
                    if (list != null && list.where((r) => r.rating > 0).isNotEmpty) ...[
                      const SizedBox(width: 18),
                      Expanded(child: _ratingBars(list)),
                    ],
                  ],
                ),
              ),
            if (list != null && list.isEmpty && !s.hasReviews)
              _reviewsEmpty(
                en ? 'No reviews yet' : 'Hakuna maoni bado',
                en ? 'Reviews appear here after customers complete a booking.' : 'Maoni yataonekana hapa baada ya wateja kukamilisha oda.',
              ),
            if (list == null)
              _reviewCardShell(
                child: Row(
                  children: [
                    const Icon(Icons.cloud_off_rounded, color: AppColors.textSecondary),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        en ? 'Reviews could not be loaded right now.' : 'Maoni hayakuweza kupakiwa kwa sasa.',
                        style: const TextStyle(fontSize: 12.5, color: AppColors.textSecondary),
                      ),
                    ),
                    TextButton(
                      onPressed: () => setState(_loadReviews),
                      child: Text(en ? 'Retry' : 'Jaribu tena'),
                    ),
                  ],
                ),
              ),
            if (list != null)
              for (final r in list) _reviewCard(r),
          ],
        );
      },
    );
  }

  Widget _ratingBars(List<_ReviewData> list) {
    final rated = list.where((r) => r.rating > 0).toList();
    final total = rated.length;
    return Column(
      children: [
        for (var star = 5; star >= 1; star--)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Row(
              children: [
                SizedBox(width: 12, child: Text('$star', style: const TextStyle(fontSize: 11, color: AppColors.textSecondary))),
                const SizedBox(width: 6),
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(3),
                    child: LinearProgressIndicator(
                      minHeight: 5,
                      value: rated.where((r) => r.rating.round() == star).length / total,
                      color: AppColors.goldStar,
                      backgroundColor: AppColors.borderLight,
                    ),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }

  Widget _reviewCard(_ReviewData r) {
    final en = AppStrings.isEnglish;
    final name = r.name.isEmpty ? (en ? 'Customer' : 'Mteja') : r.name;
    return _reviewCardShell(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 18,
                backgroundColor: AppColors.primaryLight,
                child: Text(name.substring(0, 1).toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary)),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(name, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                    if (r.date != null) Text(_dateText(r.date!), style: const TextStyle(fontSize: 11, color: AppColors.textMuted)),
                  ],
                ),
              ),
              if (r.rating > 0) _reviewStars(r.rating),
            ],
          ),
          if (r.service.isNotEmpty) ...[
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(color: AppColors.primaryLight, borderRadius: BorderRadius.circular(10)),
              child: Text(r.service, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, color: AppColors.primary)),
            ),
          ],
          if (r.comment.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(r.comment, style: const TextStyle(fontSize: 13, height: 1.45, color: AppColors.slateMuted)),
          ],
        ],
      ),
    );
  }
}

class _ReviewData {
  final String name;
  final double rating;
  final String comment;
  final DateTime? date;
  final String service;
  const _ReviewData({required this.name, required this.rating, required this.comment, this.date, this.service = ''});
}
