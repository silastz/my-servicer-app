import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../constants/app_colors.dart';
import '../services/api_service.dart';
import '../constants/app_strings.dart';
import '../widgets/app_ui.dart';

/// Admin: promo push. A boosted service is pushed to users who switched promo notifications on.
/// Each user gets ONE service per interval, and different users get different services.
/// The switch and the hours are saved together with the Save button.
///
/// Only a remote control: the server checks every call (403 for non-admins) and validates the range.
class AdminPromoPushScreen extends StatefulWidget {
  const AdminPromoPushScreen({super.key});

  @override
  State<AdminPromoPushScreen> createState() => _AdminPromoPushScreenState();
}

class _AdminPromoPushScreenState extends State<AdminPromoPushScreen> {
  final _ctrl = TextEditingController();
  bool _loading = true;
  bool _forbidden = false;
  bool _loadFailed = false;
  bool _saving = false;
  bool _enabled = true;
  bool? _savedEnabled;
  int? _savedHours;
  int _min = 1;
  int _max = 72;
  String? _error;

  bool get _isEn => AppStrings.isEnglish;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _loadFailed = false;
    });
    final r = await ApiService.getAdminPromoPush();
    if (!mounted) return;
    setState(() {
      _loading = false;
      _forbidden = r.forbidden;
      _loadFailed = !r.forbidden && r.hours == null;
      _min = r.min;
      _max = r.max;
      _savedEnabled = r.enabled;
      _savedHours = r.hours;
      if (r.enabled != null) _enabled = r.enabled!;
      if (r.hours != null) _ctrl.text = r.hours.toString();
    });
  }

  int? get _hours => int.tryParse(_ctrl.text.trim());

  bool get _changed {
    final h = _hours;
    if (_savedHours == null || _savedEnabled == null || h == null) return false;
    return h != _savedHours || _enabled != _savedEnabled;
  }

  Future<void> _save() async {
    final h = _hours;
    if (h == null || h < _min || h > _max) {
      setState(() => _error = _isEn ? 'Enter $_min to $_max hours' : 'Weka saa $_min hadi $_max');
      return;
    }
    setState(() => _saving = true);
    final messenger = ScaffoldMessenger.of(context);
    final ok = await ApiService.setAdminPromoPush(enabled: _enabled, hours: h);
    if (!mounted) return;
    setState(() => _saving = false);
    if (!ok) {
      final err = ApiService.lastAdminError;
      messenger.showSnackBar(SnackBar(
        content: Text(err == 'forbidden'
            ? (_isEn ? 'Only an admin can change this.' : 'Ni msimamizi pekee anayeweza kubadilisha hili.')
            : err == 'network'
                ? (_isEn ? 'No connection. Nothing was changed.' : 'Hakuna mtandao. Hakuna kilichobadilishwa.')
                : (_isEn ? 'Could not save. Nothing was changed.' : 'Imeshindwa kuhifadhi. Hakuna kilichobadilishwa.')),
      ));
      return;
    }
    setState(() {
      _savedEnabled = _enabled;
      _savedHours = h;
    });
    messenger.showSnackBar(SnackBar(
      content: Text(_isEn ? 'Promo push saved.' : 'Mipangilio ya arifa za matangazo imehifadhiwa.'),
    ));
  }

  Widget _note(String text, {Color color = AppColors.primary, IconData icon = Icons.info_outline_rounded}) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withValues(alpha: 0.2)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 12.5, height: 1.4, color: AppColors.textPrimary))),
        ],
      ),
    );
  }

  Widget _body() {
    if (_loading) return const Center(child: CircularProgressIndicator(color: AppColors.primary));
    if (_forbidden) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: _note(
            _isEn ? 'This account is not an admin, so it cannot change this setting.' : 'Akaunti hii si ya msimamizi, kwa hiyo haiwezi kubadilisha mpangilio huu.',
            color: AppColors.danger,
            icon: Icons.lock_outline_rounded,
          ),
        ),
      );
    }
    if (_loadFailed) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(_isEn ? 'Could not load the current setting.' : 'Imeshindwa kupakia mpangilio wa sasa.',
                textAlign: TextAlign.center, style: const TextStyle(fontSize: 14, color: AppColors.textSecondary)),
            const SizedBox(height: 16),
            AppButton.primary(label: _isEn ? 'Try again' : 'Jaribu tena', onPressed: _load),
          ]),
        ),
      );
    }
    final h = _hours;
    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewInsets.bottom),
            children: [
              _note(_isEn
                  ? 'A boosted service is pushed to users who switched on promo notifications. Each user gets only ONE service per interval, and different users get different services. A service the user searched for comes first. Pushes go out between 08:00 and 20:00 on the user\'s own clock and never to the owner of the service. 18+ services are never sent.'
                  : 'Huduma iliyopandishwa hutumwa kwa watumiaji walioruhusu arifa za matangazo. Kila mtumiaji hupata huduma MOJA tu kwa kila kipindi, na watumiaji tofauti hupata huduma tofauti. Huduma aliyotafuta mtumiaji huja kwanza. Arifa hutumwa kati ya saa 08:00 na 20:00 kwa saa ya mtumiaji, si kwa mwenye huduma. Huduma za 18+ hazitumwi kamwe.'),
              const SizedBox(height: 14),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.border),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(_isEn ? 'Send promo pushes' : 'Tuma arifa za matangazo',
                              style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w800, color: AppColors.primaryDark)),
                        ),
                        Switch(value: _enabled, onChanged: _saving ? null : (v) => setState(() => _enabled = v)),
                      ],
                    ),
                    const Divider(height: 24),
                    Text(_isEn ? 'Hours between two pushes to the same user' : 'Saa kati ya arifa mbili kwa mtumiaji yule yule',
                        style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w800, color: AppColors.primaryDark)),
                    const SizedBox(height: 2),
                    Text(
                      _isEn ? '$_min to $_max hours. Default 6.' : 'Saa $_min hadi $_max. Kawaida 6.',
                      style: const TextStyle(fontSize: 11.5, height: 1.4, color: AppColors.textSecondary),
                    ),
                    const SizedBox(height: 12),
                    AppTextField(
                      controller: _ctrl,
                      icon: Icons.schedule_rounded,
                      keyboardType: TextInputType.number,
                      hint: '6',
                      errorText: _error,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(2)],
                      onChanged: (_) => setState(() => _error = null),
                    ),
                    if (h != null && h >= _min && h <= _max) ...[
                      const SizedBox(height: 10),
                      Text(
                        _isEn
                            ? 'Each user can get at most one promo push every $h hours.'
                            : 'Kila mtumiaji anaweza kupata arifa moja tu ya tangazo kila baada ya saa $h.',
                        style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textSecondary),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: SizedBox(
              width: double.infinity,
              child: AppButton.primary(
                label: _isEn ? 'Save' : 'Hifadhi',
                loading: _saving,
                onPressed: _changed && !_saving ? _save : null,
              ),
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: _saving ? null : () => Navigator.pop(context),
        ),
        title: Text(_isEn ? 'Promo Push' : 'Arifa za Matangazo',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(color: AppColors.borderLight, height: 1)),
      ),
      body: _body(),
    );
  }
}
