import '../services/app_policy.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/data_sync.dart';
import '../services/payment_methods_service.dart';
import '../services/session_manager.dart';
import '../widgets/app_ui.dart';
import '../widgets/country_code_picker.dart';
import '../widgets/card_payment_dialog.dart';
import 'registration_fee_screen.dart' show MaskedPhone, MobileWaitDialog;
import '../services/currency_service.dart';
import '../services/money_input.dart';

/// Full-page "Top Up" for the Pocket Fund wallet.
/// Pays with a mobile-money prompt or the hosted card page (same flow as the one-time
/// fee), then credits the wallet on the server. Pops with `true` when money was added.
class TopUpScreen extends StatefulWidget {
  final double balance;
  const TopUpScreen({super.key, this.balance = 0});

  @override
  State<TopUpScreen> createState() => _TopUpScreenState();
}

class _TopUpScreenState extends State<TopUpScreen> {
  double get _minAmount => AppPolicy.topUpMin ?? 1000;
  double get _maxAmount => AppPolicy.topUpMax ?? 5000000;
  static const List<int> _quick = [5000, 10000, 20000, 50000, 100000, 200000];

  final TextEditingController _amountCtrl = TextEditingController();
  final TextEditingController _phoneCtrl = TextEditingController();
  String _method = 'mobile_money'; // mobile_money | card
  String? _amountError;
  String? _phoneError;
  bool _busy = false;
  double? _added; // set when the top up finished

  bool get _isEn => AppStrings.isEnglish;

  @override
  void initState() {
    super.initState();
    _phoneCtrl.text = SessionManager.getPhone();
  }

  @override
  void dispose() {
    _amountCtrl.dispose();
    _phoneCtrl.dispose();
    super.dispose();
  }

  String _money(num v) =>
      CurrencyService.format(v);

  double get _amount => MoneyInput.parse(_amountCtrl.text) ?? 0;

  void _snack(String msg, {Color? color}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: color, content: Text(msg)));
  }

  Future<void> _topUp() async {
    if (_busy || _added != null) return;
    final amount = _amount;
    if (amount < _minAmount || amount > _maxAmount) {
      setState(() => _amountError = amount > _maxAmount
          ? (_isEn ? 'The most you can add at once is ${_money(_maxAmount)}' : 'Kiwango cha juu kwa mara moja ni ${_money(_maxAmount)}')
          : (_isEn ? 'Enter at least ${_money(_minAmount)}' : 'Weka angalau ${_money(_minAmount)}'));
      return;
    }
    setState(() => _amountError = null);

    final userId = SessionManager.getUserIdValue();
    final reference = 'TOPUP-$userId-${DateTime.now().millisecondsSinceEpoch}-'
        '${(DateTime.now().microsecondsSinceEpoch % 9973).toRadixString(36)}';
    var payRef = reference;
    bool paid = false;

    if (_method == 'mobile_money') {
      final normalized = PaymentMethodsService.normalizeTzNumber(_phoneCtrl.text);
      if (normalized == null) {
        setState(() => _phoneError = CurrencyService.badNumberMessage(_isEn));
        return;
      }
      setState(() {
        _phoneError = null;
        _busy = true;
      });
      final res = await ApiService.requestMobilePayment(
        amount: amount,
        purpose: 'WALLET_TOPUP',
        reference: reference,
        phone: '+$normalized',
      );
      if (!mounted) return;
      if (res == null) {
        setState(() => _busy = false);
        _snack(
          ApiService.lastPaymentError ??
              (_isEn ? 'Could not send the payment request. Try again.' : 'Imeshindwa kutuma ombi la malipo. Jaribu tena.'),
          color: AppColors.danger,
        );
        return;
      }
      payRef = (res['reference'] ?? reference).toString();
      paid = await showDialog<bool>(
            context: context,
            barrierDismissible: false,
            builder: (_) => MobileWaitDialog(reference: payRef, phone: MaskedPhone.of(normalized)),
          ) ??
          false;
    } else {
      setState(() => _busy = true);
      paid = await CardPayment.pay(
        context,
        amount: amount,
        purpose: 'WALLET_TOPUP',
        reference: reference,
        description: 'Pocket Fund top up',
        phone: SessionManager.getPhone().isEmpty ? null : SessionManager.getPhone(),
      );
    }

    if (!mounted) return;
    if (!paid) {
      setState(() => _busy = false);
      _snack(_isEn ? 'Payment was not completed.' : 'Malipo hayakukamilika.', color: AppColors.warningDark);
      return;
    }

    // Money was paid: credit the wallet. The reference lets the server credit it only once.
    final res = await ApiService.depositWallet(amount, reference: payRef, method: _method);
    if (!mounted) return;
    setState(() => _busy = false);
    DataSync.bump();
    if (res == null) {
      _snack(
        _isEn
            ? 'Payment received but your wallet is not updated yet. Check again in a minute.'
            : 'Malipo yamepokelewa lakini pochi yako haijasasishwa bado. Angalia tena baada ya dakika moja.',
        color: AppColors.warningDark,
      );
      return;
    }
    setState(() => _added = amount);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: _busy ? null : () => Navigator.pop(context, _added != null),
        ),
        title: Text(
          _isEn ? 'Top Up Wallet' : 'Weka Pesa kwenye Pochi',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: PopScope(
        canPop: false,
        onPopInvokedWithResult: (didPop, _) {
          if (!didPop && !_busy) Navigator.pop(context, _added != null);
        },
        child: SafeArea(
          child: ListView(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 24 + MediaQuery.of(context).viewInsets.bottom),
            children: _added != null ? _doneState() : _form(),
          ),
        ),
      ),
    );
  }

  List<Widget> _form() {
    final amount = _amount;
    return [
      _balanceCard(),
      const SizedBox(height: 20),
      Text(
        _isEn ? 'How much do you want to add?' : 'Unataka kuweka kiasi gani?',
        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
      ),
      const SizedBox(height: 10),
      AppTextField(
        controller: _amountCtrl,
        icon: Icons.payments_outlined,
        keyboardType: TextInputType.number,
        hint: _isEn ? 'Amount (${CurrencyService.symbol})' : 'Kiasi (${CurrencyService.symbol})',
        errorText: _amountError,
        inputFormatters: const [MoneyInputFormatter(maxDigits: 8)],
        onChanged: (_) => setState(() => _amountError = null),
      ),
      const SizedBox(height: 10),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          for (final q in _quick)
            ChoiceChip(
              label: Text(_money(q), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: amount == q ? Colors.white : AppColors.textPrimary)),
              selected: amount == q,
              showCheckmark: false,
              selectedColor: AppColors.primary,
              backgroundColor: AppColors.surface,
              side: BorderSide(color: amount == q ? AppColors.primary : AppColors.border),
              onSelected: _busy
                  ? null
                  : (_) => setState(() {
                        _amountCtrl.text = MoneyInput.text(q);
                        _amountError = null;
                      }),
            ),
        ],
      ),
      const SizedBox(height: 22),
      Text(
        _isEn ? 'Choose how to pay' : 'Chagua njia ya kulipa',
        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
      ),
      const SizedBox(height: 12),
      _option(
        id: 'mobile_money',
        icon: Icons.phone_android_rounded,
        color: AppColors.successDark,
        title: _isEn ? 'Mobile Money' : 'Pesa za Simu (Mobile Money)',
        subtitle: 'M-Pesa • Airtel Money • Tigo Pesa • Halopesa',
      ),
      if (_method == 'mobile_money') ...[
        const SizedBox(height: 12),
        AppTextField(
          controller: _phoneCtrl,
          icon: Icons.phone_outlined,
          keyboardType: TextInputType.phone,
          hint: '07XX XXX XXX',
          label: _isEn ? 'Number to pay with' : 'Namba ya kulipia',
          prefix: const AccountCountryCode(),
          errorText: _phoneError,
          onChanged: (_) => setState(() => _phoneError = null),
        ),
        const SizedBox(height: 6),
        Text(
          _isEn
              ? 'You will get a prompt on this phone to confirm with your PIN.'
              : 'Utapata ujumbe kwenye simu hii kuthibitisha kwa PIN yako.',
          style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
        ),
      ],
      const SizedBox(height: 10),
      if (AppPolicy.cardPaymentsEnabled)
      _option(
        id: 'card',
        icon: Icons.credit_card_rounded,
        color: const Color(0xFF1D4ED8),
        title: _isEn ? 'Card' : 'Kadi (Card)',
        subtitle: 'Visa • Mastercard',
      ),
      if (_method == 'card') ...[
        const SizedBox(height: 8),
        Text(
          _isEn
              ? 'You will pay on a secure card page. We never see or store your card details.'
              : 'Utalipa kwenye ukurasa salama wa kadi. Hatuoni wala kuhifadhi taarifa za kadi yako.',
          style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
        ),
      ],
      const SizedBox(height: 20),
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.primaryLight,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppColors.primary.withValues(alpha: 0.15)),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(Icons.shield_outlined, size: 18, color: AppColors.primary),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                _isEn
                    ? 'Money you add stays in your Pocket Fund. Payments for bookings are held in escrow until you approve the job.'
                    : 'Pesa unayoweka hubaki kwenye Pocket Fund yako. Malipo ya oda hushikiliwa kwenye escrow hadi uidhinishe kazi.',
                style: const TextStyle(fontSize: 12, color: AppColors.primaryDark, height: 1.4),
              ),
            ),
          ],
        ),
      ),
      const SizedBox(height: 20),
      AppButton.primary(
        label: amount >= _minAmount
            ? (_isEn ? 'Top up ${_money(amount)}' : 'Weka ${_money(amount)}')
            : (_isEn ? 'Top up' : 'Weka pesa'),
        loading: _busy,
        onPressed: _busy ? null : _topUp,
      ),
    ];
  }

  List<Widget> _doneState() {
    final added = _added ?? 0;
    return [
      const SizedBox(height: 40),
      Center(
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: const BoxDecoration(color: AppColors.successLight, shape: BoxShape.circle),
          child: const Icon(Icons.check_circle_rounded, color: AppColors.success, size: 56),
        ),
      ),
      const SizedBox(height: 16),
      Text(
        _isEn ? 'Top up complete' : 'Umeweka pesa',
        textAlign: TextAlign.center,
        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
      ),
      const SizedBox(height: 6),
      Text(
        _isEn ? '${_money(added)} was added to your Pocket Fund.' : '${_money(added)} imeongezwa kwenye Pocket Fund yako.',
        textAlign: TextAlign.center,
        style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
      ),
      const SizedBox(height: 28),
      AppButton.primary(label: _isEn ? 'Done' : 'Sawa', onPressed: () => Navigator.pop(context, true)),
    ];
  }

  Widget _balanceCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(16)),
      child: Row(
        children: [
          const Icon(Icons.account_balance_wallet_outlined, color: Colors.white70, size: 22),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_isEn ? 'Current balance' : 'Salio la sasa',
                    style: const TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w500)),
                const SizedBox(height: 2),
                Text(_money(widget.balance),
                    style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900, letterSpacing: -0.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _option({
    required String id,
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
  }) {
    final selected = _method == id;
    return InkWell(
      onTap: _busy ? null : () => setState(() => _method = id),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: selected ? AppColors.primary : AppColors.border, width: selected ? 1.5 : 1),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, color: color, size: 22),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                  const SizedBox(height: 2),
                  Text(subtitle, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                ],
              ),
            ),
            Container(
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: selected ? AppColors.primary : AppColors.border, width: selected ? 6 : 2),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
