import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../widgets/app_ui.dart';
import 'admin_withdraw_screen.dart';
import 'wallet_history_screen.dart' show WalletTx, WalletTxKind;

/// Admin: the platform's own wallet. Shows what the app has collected (registration fees,
/// service fees, boosts, commissions), what is still held in escrow, and the latest movements.
///
/// The only thing that moves money here is Withdraw (see admin_withdraw_screen.dart): its only
/// fee is the payout fee. Everything else is display only, and the server checks every call
/// (403 for anyone who is not an admin).
class AdminWalletScreen extends StatefulWidget {
  const AdminWalletScreen({super.key});

  @override
  State<AdminWalletScreen> createState() => _AdminWalletScreenState();
}

class _AdminWalletScreenState extends State<AdminWalletScreen> {
  bool _loading = true;
  bool _forbidden = false;
  Map<String, dynamic>? _summary;
  List<WalletTx> _txs = const [];

  bool get _isEn => AppStrings.isEnglish;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load({bool silent = false}) async {
    if (!silent) setState(() => _loading = true);
    final results = await Future.wait([
      ApiService.getAdminWallet(),
      ApiService.getAdminWalletTransactions(),
    ]);
    if (!mounted) return;
    final w = results[0] as ({Map<String, dynamic>? data, bool forbidden});
    final raw = results[1] as List<Map<String, dynamic>>;
    setState(() {
      _loading = false;
      _forbidden = w.forbidden;
      _summary = w.data;
      _txs = w.forbidden ? const [] : raw.map(WalletTx.fromWallet).toList();
    });
  }

  double _num(dynamic v) => v is num ? v.toDouble() : (double.tryParse('$v') ?? 0);

  String _money(double v) {
    final s = v.round().abs().toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},');
    return '${v < 0 ? '-' : ''}${AppStrings.currency} $s';
  }

  Widget _card({required Widget child}) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.borderLight),
        ),
        child: child,
      );

  Widget _balanceCard(Map<String, dynamic> s) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(16)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(_isEn ? 'Platform balance' : 'Salio la jukwaa',
              style: const TextStyle(fontSize: 12.5, color: Colors.white70, fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          Text(_money(_num(s['balance'])),
              style: const TextStyle(fontSize: 28, color: Colors.white, fontWeight: FontWeight.w800)),
          const SizedBox(height: 14),
          Row(
            children: [
              _miniStat(_isEn ? 'Held in escrow' : 'Imeshikiliwa', _money(_num(s['held']))),
              _miniStat(_isEn ? 'Total in' : 'Jumla iliyoingia', _money(_num(s['totalIn']))),
              _miniStat(_isEn ? 'Total out' : 'Jumla iliyotoka', _money(_num(s['totalOut']))),
            ],
          ),
        ],
      ),
    );
  }

  Widget _miniStat(String label, String value) => Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: const TextStyle(fontSize: 10.5, color: Colors.white70)),
            const SizedBox(height: 2),
            Text(value,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 12.5, color: Colors.white, fontWeight: FontWeight.w700)),
          ],
        ),
      );

  Widget _incomeCard(Map<String, dynamic> s) {
    final inc = s['income'] is Map ? Map<String, dynamic>.from(s['income'] as Map) : const <String, dynamic>{};
    final rows = <(String, double)>[
      (_isEn ? 'Registration fees' : 'Ada za usajili', _num(inc['registrationFees'])),
      (_isEn ? 'Service fees' : 'Ada za huduma', _num(inc['serviceFees'])),
      (_isEn ? 'Boosts' : 'Kuongeza huduma', _num(inc['boosts'])),
      (_isEn ? 'Commissions' : 'Kamisheni', _num(inc['commissions'])),
      (_isEn ? 'Withdrawal fees (payout)' : 'Ada za kutoa pesa (kutuma)', _num(inc['withdrawalFees'])),
      (_isEn ? 'Collection fees' : 'Ada za ukusanyaji', _num(inc['collectionFees'])),
    ];
    final vat = _num(inc['vat']);
    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(_isEn ? 'Income by source' : 'Mapato kwa chanzo',
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
          const SizedBox(height: 10),
          for (final r in rows)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 5),
              child: Row(
                children: [
                  Expanded(child: Text(r.$1, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary))),
                  Text(_money(r.$2),
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                ],
              ),
            ),
          const Divider(height: 18),
          Row(
            children: [
              Expanded(child: Text(_isEn ? 'VAT collected (to remit)' : 'VAT iliyokusanywa (ya kulipa)', style: const TextStyle(fontSize: 13, color: AppColors.textSecondary))),
              Text(_money(vat), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.warningDark)),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            _isEn ? 'VAT is held for the tax authority. It is not income.' : 'VAT inashikiliwa kwa mamlaka ya kodi. Si mapato.',
            style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
          ),
        ],
      ),
    );
  }

  String _date(DateTime? d) {
    if (d == null) return '';
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(d.day)}/${two(d.month)}/${d.year}  ${two(d.hour)}:${two(d.minute)}';
  }

  IconData _icon(WalletTx t) {
    switch (t.kind) {
      case WalletTxKind.topUp:
        return Icons.add_card_rounded;
      case WalletTxKind.withdrawal:
        return Icons.north_east_rounded;
      case WalletTxKind.refund:
        return Icons.undo_rounded;
      case WalletTxKind.booking:
        return Icons.receipt_long_rounded;
    }
  }

  Widget _txRow(WalletTx t) {
    final color = t.incoming ? AppColors.successDark : AppColors.textPrimary;
    final title = t.title.isNotEmpty ? t.title : (t.reference.isNotEmpty ? t.reference : (_isEn ? 'Transaction' : 'Muamala'));
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: CircleAvatar(
        radius: 18,
        backgroundColor: AppColors.primaryLight,
        child: Icon(_icon(t), size: 18, color: AppColors.primary),
      ),
      title: Text(title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
      subtitle: Text('${_date(t.date)}${t.status == 'COMPLETED' || t.status.isEmpty ? '' : '  •  ${t.status}'}',
          style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
      trailing: Text('${t.incoming ? '+' : '-'} ${_money(t.amount)}',
          style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: color)),
    );
  }

  Widget _body() {
    if (_loading) return const Center(child: CircularProgressIndicator(color: AppColors.primary));
    if (_forbidden) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(
            _isEn ? 'This account is not an admin, so it cannot see the platform wallet.' : 'Akaunti hii si ya msimamizi, kwa hiyo haiwezi kuona wallet ya jukwaa.',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 14, color: AppColors.textSecondary),
          ),
        ),
      );
    }
    final s = _summary;
    if (s == null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(_isEn ? 'Could not load the platform wallet.' : 'Imeshindwa kupakia wallet ya jukwaa.',
                  textAlign: TextAlign.center, style: const TextStyle(fontSize: 14, color: AppColors.textSecondary)),
              const SizedBox(height: 16),
              AppButton.primary(label: _isEn ? 'Try again' : 'Jaribu tena', onPressed: _load),
            ],
          ),
        ),
      );
    }
    return RefreshIndicator(
      color: AppColors.primary,
      onRefresh: () => _load(silent: true),
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16),
        children: [
          _balanceCard(s),
          const SizedBox(height: 10),
          AppButton.primary(
            label: _isEn ? 'Withdraw' : 'Toa pesa',
            onPressed: () async {
              final done = await Navigator.push<bool>(
                context,
                MaterialPageRoute(builder: (_) => AdminWithdrawScreen(balance: _num(s['balance']))),
              );
              if (done == true) _load();
            },
          ),
          const SizedBox(height: 14),
          _incomeCard(s),
          const SizedBox(height: 14),
          _card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_isEn ? 'Recent activity' : 'Shughuli za hivi karibuni',
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                const SizedBox(height: 4),
                if (_txs.isEmpty)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    child: Text(_isEn ? 'No activity yet.' : 'Hakuna shughuli bado.',
                        style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
                  )
                else
                  for (final t in _txs) _txRow(t),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _isEn ? 'Admin Wallet' : 'Wallet ya Msimamizi',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: _body(),
    );
  }
}
