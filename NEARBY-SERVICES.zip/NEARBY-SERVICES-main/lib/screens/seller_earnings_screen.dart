import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/data_sync.dart';
import 'pocket_fund_screen.dart';
import '../services/currency_service.dart';
import '../widgets/app_image.dart';

class SellerEarningsScreen extends StatefulWidget {
  final bool showBackButton;
  const SellerEarningsScreen({super.key, this.showBackButton = true});

  @override
  State<SellerEarningsScreen> createState() => _SellerEarningsScreenState();
}

class _SellerEarningsScreenState extends State<SellerEarningsScreen> {
  String _selectedPeriod = 'This Month';
  bool _isLoading = false;

  double _totalEarnings = 0.0;
  int _completedBookings = 0;
  int _pendingPayments = 0;
  double _withdrawnAmount = 0.0;

  List<Map<String, dynamic>> _recentEarnings = [];

  // Something was written to the server elsewhere (booking, accept, wallet, review...): re-fetch.
  void _onDataChanged() {
    if (mounted) _loadLiveEarnings(silent: true);
  }

  @override
  void dispose() {
    DataSync.changed.removeListener(_onDataChanged);
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    DataSync.changed.addListener(_onDataChanged);
    _loadLiveEarnings();
  }

  /// True when an order created at [createdAt] belongs to the selected period.
  /// An order with no readable date only shows under "All Time".
  bool _inSelectedPeriod(dynamic createdAt) {
    if (_selectedPeriod == 'All Time') return true;
    final d = DateTime.tryParse('${createdAt ?? ''}')?.toLocal();
    if (d == null) return false;
    final now = DateTime.now();
    final thisMonth = DateTime(now.year, now.month);
    final start = _selectedPeriod == 'This Month' ? thisMonth : DateTime(now.year, now.month - 1);
    final end = _selectedPeriod == 'This Month' ? DateTime(now.year, now.month + 1) : thisMonth;
    return !d.isBefore(start) && d.isBefore(end);
  }

  static bool _isPaidStatus(String status) => status == 'COMPLETED' || status == 'RELEASED' || status == 'SATISFIED';


  static bool _isDeadStatus(String status) =>
      status.contains('CANCEL') || status.contains('REJECT') || status.contains('REFUND') || status.contains('DECLIN') || status.contains('EXPIRED');

  /// Badge text shown on each row, from the real order status.
  static String _badgeFor(String status) => _isPaidStatus(status) ? 'Paid' : (_isDeadStatus(status) ? 'Cancelled' : 'Pending');

  Future<void> _loadLiveEarnings({bool silent = false}) async {
    if (!silent) setState(() => _isLoading = true);
    final ordersFuture = ApiService.fetchSellerOrders();
    final walletFuture = ApiService.getWallet();

    final results = await Future.wait([ordersFuture, walletFuture]);
    final orders = results[0] as List<dynamic>? ?? [];
    final wallet = results[1] as Map<String, dynamic>?;

    if (!mounted) return;
    double total = 0.0;
    int completed = 0;
    int pending = 0;

    final inPeriod = orders
        .whereType<Map>()
        .where((o) => _inSelectedPeriod(o['createdAt']))
        .toList()
      ..sort((a, b) {
        final da = DateTime.tryParse('${a['createdAt'] ?? ''}');
        final db = DateTime.tryParse('${b['createdAt'] ?? ''}');
        if (da == null || db == null) return 0;
        return db.compareTo(da); // newest first
      });

    final mapped = inPeriod.map((order) {
      final amt = (order['amount'] as num?)?.toDouble() ?? 0.0;
      final status = (order['status'] ?? '').toString().toUpperCase();
      final service = order['service'] is Map ? order['service'] as Map : const {};
      final buyer = order['buyer'] is Map ? order['buyer'] as Map : const {};
      final title = (order['serviceTitle'] ?? service['title'] ?? '').toString().trim();
      final created = DateTime.tryParse('${order['createdAt'] ?? ''}')?.toLocal();
      String two(int v) => v.toString().padLeft(2, '0');
      final date = created == null ? '' : '${two(created.day)}/${two(created.month)}/${created.year}';
      final avatar = (buyer['avatarUrl'] ?? '').toString().trim();

      if (_isPaidStatus(status)) {
        total += amt;
        completed++;
      } else if (!_isDeadStatus(status)) {
        pending++; // still open: waiting, accepted, awaiting or sent payment, disputed
      }

      return {
        'title': title,
        'buyer': (buyer['stageName'] ?? '').toString().trim(),
        'amount': CurrencyService.format(amt),
        'date': date,
        'status': status,
        'avatar': avatar.isEmpty ? '' : ApiService.absoluteUrl(avatar),
      };
    }).toList();

    setState(() {
      _recentEarnings = mapped;
      _totalEarnings = total;
      _completedBookings = completed;
      _pendingPayments = pending;
      if (wallet != null) {
        _withdrawnAmount = (wallet['withdrawn'] as num?)?.toDouble() ?? 0.0;
      }
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: widget.showBackButton && Navigator.canPop(context)
            ? IconButton(
                icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
                onPressed: () => Navigator.pop(context),
              )
            : null,
        title: Text(
          AppStrings.isEnglish ? 'Earnings' : 'Mapato',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16, top: 10, bottom: 10),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: AppColors.borderLight,
              borderRadius: BorderRadius.circular(16),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: _selectedPeriod,
                icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 16, color: AppColors.textPrimary),
                style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                items: ['This Month', 'Last Month', 'All Time'].map((p) {
                  return DropdownMenuItem(
                    value: p,
                    child: Text(p == 'This Month'
                        ? (AppStrings.isEnglish ? 'This Month' : 'Mwezi Huu')
                        : (p == 'Last Month' ? (AppStrings.isEnglish ? 'Last Month' : 'Mwezi Uliopita') : (AppStrings.isEnglish ? 'All Time' : 'Wakati Wote'))),
                  );
                }).toList(),
                onChanged: (val) {
                  if (val == null || val == _selectedPeriod) return;
                  setState(() => _selectedPeriod = val);
                  _loadLiveEarnings();
                },
              ),
            ),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
          : RefreshIndicator(
              color: AppColors.primary,
              onRefresh: () => _loadLiveEarnings(silent: true),
              child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
            // Total Earnings Card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    AppStrings.isEnglish ? 'Total Earnings' : 'Jumla ya Mapato',
                    style: TextStyle(fontSize: 13, color: AppColors.textSecondary, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    CurrencyService.format(_totalEarnings),
                    style: const TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.w900,
                      color: AppColors.textPrimary,
                      letterSpacing: -0.5,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      const Icon(Icons.arrow_upward_rounded, size: 14, color: AppColors.success),
                      const SizedBox(width: 4),
                      Text(
                        AppStrings.isEnglish ? 'Live from escrow orders' : 'Moja kwa moja kutoka oda za escrow',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: AppColors.success,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // 3 KPI Metrics Boxes (Completed Bookings, Pending Payments, Withdrawn)
            Row(
              children: [
                Expanded(
                  child: _buildMetricBox(
                    label: AppStrings.isEnglish ? 'Completed Bookings' : 'Oda Zilizokamilika',
                    value: '$_completedBookings',
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _buildMetricBox(
                    label: AppStrings.isEnglish ? 'Pending Payments' : 'Malipo Yanayosubiri',
                    value: '$_pendingPayments',
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _buildMetricBox(
                    label: AppStrings.isEnglish ? 'Withdrawn' : 'Yaliyotolewa',
                    value: CurrencyService.format(_withdrawnAmount),
                    isCurrency: true,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 26),

            // Recent Earnings Section
            Text(
              AppStrings.isEnglish ? 'Recent Earnings' : 'Mapato ya Hivi Karibuni',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w800,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 12),

            if (_recentEarnings.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 20),
                child: Center(
                  child: Text(
                    AppStrings.isEnglish ? 'No earnings in this period' : 'Hakuna mapato katika kipindi hiki',
                    style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
                  ),
                ),
              ),
            ..._recentEarnings.map((e) {
              return Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppColors.border),
                ),
                child: Row(
                  children: [
                    ClipOval(
                      child: SizedBox(
                        width: 40,
                        height: 40,
                        child: (e['avatar'] as String).isEmpty
                            ? Container(
                                color: AppColors.borderLight,
                                child: const Icon(Icons.person_rounded, size: 22, color: AppColors.textMuted),
                              )
                            : AppImage(
                                e['avatar'] as String,
                                fit: BoxFit.cover,
                                errorBuilder: (ctx, err, stack) => Container(
                                  color: AppColors.borderLight,
                                  child: const Icon(Icons.person_rounded, size: 22, color: AppColors.textMuted),
                                ),
                              ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            (e['title'] as String).isNotEmpty
                                ? e['title'] as String
                                : (AppStrings.isEnglish ? 'Booking' : 'Oda'),
                            style: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          if ((e['buyer'] as String).isNotEmpty) ...[
                            const SizedBox(height: 2),
                            Text(
                              e['buyer'] as String,
                              style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                            ),
                          ],
                          const SizedBox(height: 2),
                          Text(
                            e['amount'] as String,
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          const SizedBox(height: 2),
                          if ((e['date'] as String).isNotEmpty)
                            Text(
                              e['date'] as String,
                              style: const TextStyle(fontSize: 10, color: AppColors.textMuted),
                            ),
                        ],
                      ),
                    ),
                    Builder(builder: (_) {
                      final label = _badgeFor(e['status'] as String);
                      final color = label == 'Paid'
                          ? AppColors.success
                          : (label == 'Cancelled' ? AppColors.textMuted : AppColors.warning);
                      return Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: color.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          label == 'Paid'
                              ? (AppStrings.isEnglish ? 'Paid' : 'Imelipwa')
                              : (label == 'Cancelled' ? (AppStrings.isEnglish ? 'Cancelled' : 'Imeghairiwa') : (AppStrings.isEnglish ? 'Pending' : 'Inasubiri')),
                          style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: color),
                        ),
                      );
                    }),
                  ],
                ),
              );
            }),
            const SizedBox(height: 24),

            // Withdraw Funds Full-Width Action Button
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                // Withdrawals are made from the wallet screen (amount + mobile money number).
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const PocketFundScreen()),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: Text(
                  AppStrings.isEnglish ? 'Withdraw Funds' : 'Toa Pesa',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800),
                ),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
            ),
    );
  }

  Widget _buildMetricBox({
    required String label,
    required String value,
    bool isCurrency = false,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 10, color: AppColors.textSecondary),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: TextStyle(
              fontSize: isCurrency ? 11 : 16,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
        ],
      ),
    );
  }
}
