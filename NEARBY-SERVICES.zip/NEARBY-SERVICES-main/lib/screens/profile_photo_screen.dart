import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart' show CameraDevice, ImageSource;
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/media_picker.dart';
import '../services/session_manager.dart';
import '../widgets/app_image.dart';
import '../widgets/app_ui.dart';

/// WhatsApp-style profile photo page: big photo, then Camera / Gallery / Remove.
class ProfilePhotoScreen extends StatefulWidget {
  final String name;
  const ProfilePhotoScreen({super.key, required this.name});

  @override
  State<ProfilePhotoScreen> createState() => _ProfilePhotoScreenState();
}

class _ProfilePhotoScreenState extends State<ProfilePhotoScreen> {
  bool _busy = false;

  bool get _en => AppStrings.isEnglish;

  void _toast(String msg, {required bool ok}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: ok ? AppColors.success : AppColors.danger,
      content: Text(msg),
    ));
  }

  Future<void> _change(ImageSource source) async {
    if (_busy) return;
    final file = await MediaPicker.pickImage(
      context,
      title: _en ? 'Profile photo' : 'Picha ya wasifu',
      maxWidth: 1024,
      preferredCamera: CameraDevice.front,
      source: source,
    );
    if (file == null || !mounted) return;
    setState(() => _busy = true);
    final res = await ApiService.uploadAvatar(file.path);
    if (!mounted) return;
    setState(() => _busy = false);
    _toast(
      res.ok
          ? (_en ? 'Profile photo updated.' : 'Picha ya wasifu imesasishwa.')
          : (res.error ?? (_en ? 'Could not upload the photo.' : 'Imeshindwa kupakia picha.')),
      ok: res.ok,
    );
  }

  Future<void> _remove() async {
    if (_busy) return;
    final yes = await AppDialog.confirm(
      context,
      icon: Icons.delete_outline_rounded,
      title: _en ? 'Remove profile photo?' : 'Ondoa picha ya wasifu?',
      message: _en ? 'Your initial will be shown instead.' : 'Herufi ya jina lako itaonyeshwa badala yake.',
      confirmLabel: _en ? 'Remove' : 'Ondoa',
      color: AppColors.danger,
    );
    if (!yes || !mounted) return;
    setState(() => _busy = true);
    final ok = await ApiService.removeAvatar();
    if (!mounted) return;
    setState(() => _busy = false);
    _toast(
      ok
          ? (_en ? 'Profile photo removed.' : 'Picha ya wasifu imeondolewa.')
          : (_en ? 'Could not remove the photo.' : 'Imeshindwa kuondoa picha.'),
      ok: ok,
    );
  }

  @override
  Widget build(BuildContext context) {
    final url = SessionManager.getAvatarUrl();
    final name = widget.name;
    final initial = name.isNotEmpty ? name.substring(0, 1).toUpperCase() : '?';
    final letter = Center(
      child: Text(initial, style: const TextStyle(color: Colors.white, fontSize: 96, fontWeight: FontWeight.bold)),
    );

    Widget action(IconData icon, String label, VoidCallback onTap, {Color color = Colors.white}) => InkWell(
          onTap: _busy ? null : onTap,
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, color: color, size: 26),
                const SizedBox(height: 6),
                Text(label, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        );

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(_en ? 'Profile photo' : 'Picha ya wasifu',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Colors.white)),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Center(
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    AspectRatio(
                      aspectRatio: 1,
                      child: Container(
                        color: AppColors.primary,
                        child: url.isEmpty
                            ? letter
                            : InteractiveViewer(
                                child: AppImage(url, fit: BoxFit.cover, errorBuilder: (_, _, _) => letter),
                              ),
                      ),
                    ),
                    if (_busy)
                      const CircularProgressIndicator(color: Colors.white),
                  ],
                ),
              ),
            ),
            Container(
              color: const Color(0xFF111111),
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  action(Icons.photo_camera_outlined, _en ? 'Camera' : 'Kamera', () => _change(ImageSource.camera)),
                  action(Icons.photo_library_outlined, _en ? 'Gallery' : 'Picha', () => _change(ImageSource.gallery)),
                  if (url.isNotEmpty)
                    action(Icons.delete_outline_rounded, _en ? 'Remove' : 'Ondoa', _remove, color: const Color(0xFFFF6B6B)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
