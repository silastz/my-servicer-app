import '../models/provider_fees.dart';
import '../services/app_policy.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/data_sync.dart';
import '../services/payment_methods_service.dart';
import '../services/session_manager.dart';
import '../widgets/app_ui.dart';
import '../widgets/country_code_picker.dart';
import 'wallet_history_screen.dart';
import '../services/currency_service.dart';
import '../services/money_input.dart';

/// Full-page "Withdraw": moves money from the Pocket Fund to a mobile-money number.
/// Pops with `true` when a withdrawal was requested.
class WithdrawScreen extends StatefulWidget {
  final double balance;
  const WithdrawScreen({super.key, this.balance = 0});

  @override
  State<WithdrawScreen> createState() => _WithdrawScreenState();
}

class _WithdrawScreenState extends State<WithdrawScreen> {
  double get _minAmount => AppPolicy.withdrawMinEffective;
  double? get _maxAmount => AppPolicy.withdrawMaxEffective;
  static const List<int> _quick = [5000, 10000, 20000, 50000];

  final TextEditingController _amountCtrl = TextEditingController();
  final TextEditingController _phoneCtrl = TextEditingController();
  Map<String, String> _saved = {};
  String? _amountError;
  String? _phoneError;
  bool _busy = false;
  double? _done;
  double? _doneNet; // what the provider receives after fees (null = no fees)
  double? _doneFee;
  String _doneTo = '';

  bool get _isEn => AppStrings.isEnglish;

  @override
  void initState() {
    super.initState();
    _phoneCtrl.text = SessionManager.getPhone();
    _loadSaved();
  }

  @override
  void dispose() {
    _amountCtrl.dispose();
    _phoneCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadSaved() async {
    final numbers = await PaymentMethodsService.loadNumbers();
    final def = await PaymentMethodsService.loadDefault();
    if (!mounted) return;
    setState(() {
      _saved = {for (final m in PaymentMethodsService.methods) if (m.isMobileMoney && numbers[m.id] != null) m.id: numbers[m.id]!};
      if (def != null && _saved[def] != null) _phoneCtrl.text = _saved[def]!;
    });
  }

  String _money(num v) =>
      CurrencyService.format(v);

  double get _amount => MoneyInput.parse(_amountCtrl.text) ?? 0;

  /// Fees the admin announced (shown as an estimate; the server charges the real ones).
  ProviderFees? get _fees {
    final f = AppPolicy.providerFees;
    return (f == null || f.isZero) ? null : f;
  }

  Future<void> _withdraw() async {
    if (_busy || _done != null) return;
    final amount = _amount;
    final phone = PaymentMethodsService.normalizeTzNumber(_phoneCtrl.text);
    String? badAmount;
    if (amount < _minAmount) {
      badAmount = _isEn ? 'Enter at least ${_money(_minAmount)}' : 'Weka angalau ${_money(_minAmount)}';
    } else if (_maxAmount != null && amount > _maxAmount!) {
      badAmount = _isEn ? 'The most you can withdraw at once is ${_money(_maxAmount!)}' : 'Kiwango cha juu cha kutoa kwa mara moja ni ${_money(_maxAmount!)}';
    } else if (amount > widget.balance) {
      badAmount = _isEn ? 'More than your available balance' : 'Zaidi ya salio lako';
    }
    final fees = _fees;
    if (badAmount == null && fees != null && !fees.covers(amount)) {
      badAmount = _isEn
          ? 'Too small: the fee would take all of it. Try at least ${_money(fees.smallestUsable)}'
          : 'Ndogo mno: ada ingechukua yote. Jaribu angalau ${_money(fees.smallestUsable)}';
    }
    final badPhone = phone == null ? (CurrencyService.badNumberMessage(_isEn)) : null;
    if (badAmount != null || badPhone != null) {
      setState(() {
        _amountError = badAmount;
        _phoneError = badPhone;
      });
      return;
    }
    final masked = PaymentMethodsService.mask(phone!);
    final ok = await AppDialog.confirm(
      context,
      icon: Icons.account_balance_outlined,
      title: _isEn ? 'Confirm withdrawal' : 'Thibitisha utoaji',
      message: fees == null
          ? (_isEn
              ? 'Send ${_money(amount)} from your Pocket Fund to $masked?'
              : 'Tuma ${_money(amount)} kutoka Pocket Fund yako kwenda $masked?')
          : (_isEn
              ? '${_money(amount)} leaves your Pocket Fund. After the fee of ${_money(fees.totalFee(amount))}, $masked receives about ${_money(fees.net(amount))}.'
              : '${_money(amount)} inatoka Pocket Fund yako. Baada ya ada ya ${_money(fees.totalFee(amount))}, $masked inapokea takriban ${_money(fees.net(amount))}.'),
      confirmLabel: _isEn ? 'Withdraw' : 'Toa pesa',
    );
    if (!ok || !mounted) return;

    setState(() {
      _busy = true;
      _amountError = null;
      _phoneError = null;
    });
    final res = await ApiService.withdrawWallet(amount, '+$phone');
    if (!mounted) return;
    setState(() => _busy = false);
    if (res == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        backgroundColor: AppColors.danger,
        content: Text(ApiService.lastPaymentError ??
            (_isEn ? 'Withdrawal failed. Check your balance and try again.' : 'Imeshindwa kutoa pesa. Angalia salio lako ujaribu tena.')),
      ));
      return;
    }
    DataSync.bump();
    // The server's own numbers win over the estimate (it charges the real fees).
    final srvNet = res['netAmount'] ?? res['net'];
    final srvFee = res['fee'] ?? res['totalFee'];
    final net = srvNet is num ? srvNet.toDouble() : (fees?.net(amount).toDouble());
    final fee = srvFee is num ? srvFee.toDouble() : fees?.totalFee(amount).toDouble();
    setState(() {
      _done = amount;
      _doneNet = net;
      _doneFee = fee;
      _doneTo = masked;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: _busy ? null : () => Navigator.pop(context, _done != null),
        ),
        title: Text(_isEn ? 'Withdraw' : 'Toa Pesa',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(color: AppColors.borderLight, height: 1)),
      ),
      body: PopScope(
        canPop: false,
        onPopInvokedWithResult: (didPop, _) {
          if (!didPop && !_busy) Navigator.pop(context, _done != null);
        },
        child: SafeArea(
          child: ListView(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 24 + MediaQuery.of(context).viewInsets.bottom),
            children: _done != null ? _doneState() : _form(),
          ),
        ),
      ),
    );
  }

  List<Widget> _form() {
    final amount = _amount;
    return [
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(16)),
        child: Row(
          children: [
            const Icon(Icons.account_balance_wallet_outlined, color: Colors.white70, size: 22),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_isEn ? 'Available to withdraw' : 'Salio linaloweza kutolewa',
                      style: const TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w500)),
                  const SizedBox(height: 2),
                  Text(_money(widget.balance),
                      style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900, letterSpacing: -0.5)),
                ],
              ),
            ),
          ],
        ),
      ),
      const SizedBox(height: 20),
      Row(
        children: [
          Expanded(
            child: Text(_isEn ? 'How much do you want to withdraw?' : 'Unataka kutoa kiasi gani?',
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
          ),
          TextButton(
            onPressed: _busy || widget.balance <= 0
                ? null
                : () => setState(() {
                      final cap = _maxAmount;
                      _amountCtrl.text = MoneyInput.text((cap != null && widget.balance > cap ? cap : widget.balance).floor());
                      _amountError = null;
                    }),
            child: Text(_isEn ? 'Withdraw all' : 'Toa yote', style: const TextStyle(fontWeight: FontWeight.w700)),
          ),
        ],
      ),
      AppTextField(
        controller: _amountCtrl,
        icon: Icons.payments_outlined,
        keyboardType: TextInputType.number,
        hint: _isEn ? 'Amount (${CurrencyService.symbol})' : 'Kiasi (${CurrencyService.symbol})',
        errorText: _amountError,
        inputFormatters: const [MoneyInputFormatter(maxDigits: 8)],
        onChanged: (_) => setState(() => _amountError = null),
      ),
      Padding(
        padding: const EdgeInsets.only(top: 6, left: 4),
        child: Text(
          _maxAmount == null
              ? (_isEn ? 'Minimum ${_money(_minAmount)}' : 'Kiwango cha chini ${_money(_minAmount)}')
              : (_isEn ? 'From ${_money(_minAmount)} to ${_money(_maxAmount!)} per withdrawal' : 'Kuanzia ${_money(_minAmount)} hadi ${_money(_maxAmount!)} kwa kila utoaji'),
          style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
        ),
      ),
      const SizedBox(height: 10),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          for (final q in _quick)
            ChoiceChip(
              label: Text(_money(q), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: amount == q ? Colors.white : AppColors.textPrimary)),
              selected: amount == q,
              showCheckmark: false,
              selectedColor: AppColors.primary,
              backgroundColor: AppColors.surface,
              side: BorderSide(color: amount == q ? AppColors.primary : AppColors.border),
              onSelected: _busy
                  ? null
                  : (_) => setState(() {
                        _amountCtrl.text = MoneyInput.text(q);
                        _amountError = null;
                      }),
            ),
        ],
      ),
      const SizedBox(height: 22),
      Text(_isEn ? 'Send the money to' : 'Tuma pesa kwenda',
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
      const SizedBox(height: 10),
      AppTextField(
        controller: _phoneCtrl,
        icon: Icons.phone_outlined,
        keyboardType: TextInputType.phone,
        prefix: const AccountCountryCode(),
        hint: '07XX XXX XXX',
        label: _isEn ? 'Mobile money number' : 'Namba ya pesa za simu',
        errorText: _phoneError,
        onChanged: (_) => setState(() => _phoneError = null),
      ),
      if (_saved.isNotEmpty) ...[
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final e in _saved.entries)
              ActionChip(
                avatar: Icon(PaymentMethodsService.byId(e.key).icon, size: 16, color: PaymentMethodsService.byId(e.key).color),
                label: Text('${_isEn ? PaymentMethodsService.byId(e.key).nameEn : PaymentMethodsService.byId(e.key).nameSw} ${PaymentMethodsService.mask(e.value)}',
                    style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
                backgroundColor: AppColors.surface,
                side: const BorderSide(color: AppColors.border),
                onPressed: _busy
                    ? null
                    : () => setState(() {
                          _phoneCtrl.text = e.value;
                          _phoneError = null;
                        }),
              ),
          ],
        ),
      ],
      _feeBreakdown(),
      const SizedBox(height: 20),
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.primaryLight,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppColors.primary.withValues(alpha: 0.15)),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(Icons.info_outline_rounded, size: 18, color: AppColors.primary),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                _isEn
                    ? 'Only money in your Pocket Fund can be withdrawn. Money held in escrow for a booking is released to the provider after you approve the job.'
                    : 'Pesa zilizo kwenye Pocket Fund pekee ndizo zinaweza kutolewa. Pesa zilizoshikiliwa kwenye escrow kwa ajili ya oda hutolewa kwa mtoa huduma baada ya wewe kuidhinisha kazi.',
                style: const TextStyle(fontSize: 12, color: AppColors.primaryDark, height: 1.4),
              ),
            ),
          ],
        ),
      ),
      const SizedBox(height: 20),
      AppButton.primary(
        label: amount >= _minAmount ? (_isEn ? 'Withdraw ${_money(amount)}' : 'Toa ${_money(amount)}') : (_isEn ? 'Withdraw' : 'Toa pesa'),
        loading: _busy,
        onPressed: _busy ? null : _withdraw,
      ),
    ];
  }

  /// Shows the collection fee and the charge as two lines. The charge hides its payout fee / VAT split.
  Widget _feeBreakdown() {
    final fees = _fees;
    if (fees == null) return const SizedBox.shrink();
    final amount = _amount;
    Widget row(String a, String b, {bool bold = false, Color? color}) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 3),
          child: Row(children: [
            Expanded(child: Text(a, style: TextStyle(fontSize: 13, fontWeight: bold ? FontWeight.w800 : FontWeight.w500, color: AppColors.textSecondary))),
            Text(b, style: TextStyle(fontSize: 13, fontWeight: bold ? FontWeight.w800 : FontWeight.w600, color: color ?? AppColors.textPrimary)),
          ]),
        );
    return Container(
      margin: const EdgeInsets.only(top: 18),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.borderLight)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(_isEn ? 'Withdrawal fee' : 'Ada ya kutoa pesa',
              style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
          const SizedBox(height: 6),
          if (amount > 0 && fees.covers(amount)) ...[
            row(_isEn ? 'You withdraw' : 'Unatoa', _money(amount)),
            if (fees.collectionPercent > 0)
              row(_isEn ? 'Collection fee' : 'Ada ya ukusanyaji', '- ${_money(fees.collectionFee(amount))}'),
            if (fees.chargeFee(amount) > 0) row(_isEn ? 'Fee' : 'Ada', '- ${_money(fees.chargeFee(amount))}'),
            const Divider(height: 14),
            row(_isEn ? 'You receive' : 'Unapokea', _money(fees.net(amount)), bold: true, color: AppColors.successDark),
          ] else
            Text(
              _isEn
                  ? 'A fee is taken when you withdraw. Enter an amount to see the fee and what you receive.'
                  : 'Ada hukatwa unapotoa pesa. Weka kiasi uone ada na utakachopokea.',
              style: const TextStyle(fontSize: 12.5, height: 1.4, color: AppColors.textSecondary),
            ),
        ],
      ),
    );
  }

  List<Widget> _doneState() {
    return [
      const SizedBox(height: 40),
      Center(
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: const BoxDecoration(color: AppColors.successLight, shape: BoxShape.circle),
          child: const Icon(Icons.check_circle_rounded, color: AppColors.success, size: 56),
        ),
      ),
      const SizedBox(height: 16),
      Text(_isEn ? 'Withdrawal requested' : 'Ombi la kutoa pesa limetumwa',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
      const SizedBox(height: 6),
      Text(
        _doneNet != null && (_doneFee ?? 0) > 0
            ? (_isEn
                ? '${_money(_doneNet!)} is on its way to $_doneTo (${_money(_done ?? 0)} minus a ${_money(_doneFee!)} fee).'
                : '${_money(_doneNet!)} inaelekea $_doneTo (${_money(_done ?? 0)} ukiondoa ada ya ${_money(_doneFee!)}).')
            : (_isEn ? '${_money(_done ?? 0)} is on its way to $_doneTo.' : '${_money(_done ?? 0)} inaelekea $_doneTo.'),
        textAlign: TextAlign.center,
        style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
      ),
      const SizedBox(height: 28),
      AppButton.primary(label: _isEn ? 'Done' : 'Sawa', onPressed: () => Navigator.pop(context, true)),
      const SizedBox(height: 10),
      AppButton.outlined(
        label: _isEn ? 'View history' : 'Angalia historia',
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WalletHistoryScreen())),
      ),
    ];
  }
}
