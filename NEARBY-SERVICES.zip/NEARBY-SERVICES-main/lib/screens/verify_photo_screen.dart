import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart' show CameraDevice;
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/media_picker.dart';
import '../services/security_settings.dart';
import '../services/session_manager.dart';
import '../widgets/app_image.dart';
import '../widgets/app_ui.dart';

/// "Verify photo": the user takes a live face photo. Once the server verifies it,
/// providers see it on this user's requests, but only while Hide My ID is OFF.
class VerifyPhotoScreen extends StatefulWidget {
  const VerifyPhotoScreen({super.key});

  /// Short label for the profile menu: 'Verified', 'In review', 'Rejected' or null.
  static String? statusLabel(bool en) {
    switch (SessionManager.getVerifiedPhotoStatus()) {
      case 'VERIFIED':
        return en ? 'Verified' : 'Imethibitishwa';
      case 'PENDING':
        return en ? 'In review' : 'Inakaguliwa';
      case 'REJECTED':
        return en ? 'Rejected' : 'Imekataliwa';
    }
    return null;
  }

  @override
  State<VerifyPhotoScreen> createState() => _VerifyPhotoScreenState();
}

class _VerifyPhotoScreenState extends State<VerifyPhotoScreen> {
  bool _loading = true;
  String? _reason;

  bool get _en => AppStrings.isEnglish;
  String get _status => SessionManager.getVerifiedPhotoStatus();
  String get _url => SessionManager.getVerifiedPhotoUrl();

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final r = await ApiService.fetchVerifiedPhoto();
    if (!mounted) return;
    setState(() {
      _loading = false;
      _reason = r?.reason;
    });
  }

  void _toast(String msg, {required bool ok}) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(backgroundColor: ok ? AppColors.success : AppColors.danger, content: Text(msg)));
  }

  Future<void> _take() async {
    // A new photo replaces the verified one and goes through review again. Say so before it happens.
    if (_status == 'VERIFIED') {
      final go = await AppDialog.confirm(
        context,
        icon: Icons.photo_camera_outlined,
        title: _en ? 'Replace your verified photo?' : 'Badilisha picha yako iliyothibitishwa?',
        message: _en
            ? 'A new photo replaces the verified one and is reviewed again. Until it is approved you will not have a verified photo, and if it is rejected you will need to take another.'
            : 'Picha mpya inachukua nafasi ya iliyothibitishwa na inakaguliwa tena. Hadi iidhinishwe hutakuwa na picha iliyothibitishwa, na ikikataliwa utahitaji kupiga nyingine.',
        confirmLabel: _en ? 'Take new photo' : 'Piga picha mpya',
      );
      if (!go || !mounted) return;
    }
    // Live camera only, so the photo is a real face and not a picture from the gallery.
    final file = await MediaPicker.pickImage(
      context,
      title: _en ? 'Verify photo' : 'Thibitisha picha',
      maxWidth: 1024,
      preferredCamera: CameraDevice.front,
      cameraOnly: true,
    );
    if (file == null || !mounted) return;
    setState(() => _loading = true);
    final res = await ApiService.uploadVerifiedPhoto(file.path);
    if (!mounted) return;
    setState(() {
      _loading = false;
      _reason = null;
    });
    _toast(
      res.ok
          ? (_en ? 'Photo sent. We will review it.' : 'Picha imetumwa. Tutaikagua.')
          : (res.error ?? (_en ? 'Could not send the photo.' : 'Imeshindwa kutuma picha.')),
      ok: res.ok,
    );
  }

  (String, Color) get _pill {
    switch (_status) {
      case 'VERIFIED':
        return (_en ? 'Verified' : 'Imethibitishwa', AppColors.successDark);
      case 'PENDING':
        return (_en ? 'In review' : 'Inakaguliwa', AppColors.warningDark);
      case 'REJECTED':
        return (_en ? 'Rejected' : 'Imekataliwa', AppColors.danger);
    }
    return (_en ? 'Not verified' : 'Haijathibitishwa', AppColors.textSecondary);
  }

  @override
  Widget build(BuildContext context) {
    final (pillText, pillColor) = _pill;
    final verified = _status == 'VERIFIED';
    final hidden = SecuritySettings.hideMyId;
    final stageName = SessionManager.getStageName();
    final initial = stageName.trim().isEmpty ? '?' : stageName.trim().substring(0, 1).toUpperCase();
    final letter = Center(
      child: Text(initial, style: const TextStyle(fontSize: 48, fontWeight: FontWeight.w800, color: Colors.white)),
    );

    Widget note(IconData icon, Color color, Color bg, String text) => Container(
          margin: const EdgeInsets.only(top: 12),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, size: 20, color: color),
              const SizedBox(width: 10),
              Expanded(child: Text(text, style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textPrimary))),
            ],
          ),
        );

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Text(_en ? 'Verify photo' : 'Thibitisha picha',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
        iconTheme: const IconThemeData(color: AppColors.textPrimary),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(16, 22, 16, 18),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.border),
            ),
            child: Column(
              children: [
                Stack(
                  alignment: Alignment.center,
                  children: [
                    ClipOval(
                      child: Container(
                        width: 110,
                        height: 110,
                        color: AppColors.primary,
                        child: _url.isEmpty
                            ? letter
                            : AppImage(_url, width: 110, height: 110, fit: BoxFit.cover, errorBuilder: (_, _, _) => letter),
                      ),
                    ),
                    if (_loading) const CircularProgressIndicator(color: Colors.white),
                  ],
                ),
                const SizedBox(height: 12),
                StatusPill(text: pillText, color: pillColor),
                const SizedBox(height: 10),
                Text(
                  _en
                      ? 'Take a clear photo of your face in good light. No sunglasses, hat or filters.'
                      : 'Piga picha ya uso wako wazi kwenye mwanga mzuri. Bila miwani ya jua, kofia wala vichujio.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 13, height: 1.4, color: AppColors.textSecondary),
                ),
              ],
            ),
          ),
          if (_status == 'REJECTED')
            note(
              Icons.error_outline_rounded,
              AppColors.danger,
              AppColors.dangerLight,
              (_reason ?? (_en ? 'The photo could not be verified.' : 'Picha haikuweza kuthibitishwa.')) +
                  (_en ? ' Please take a new one.' : ' Tafadhali piga nyingine.'),
            ),
          if (_status == 'PENDING')
            note(
              Icons.hourglass_top_rounded,
              AppColors.warningDark,
              AppColors.warningLight,
              _en ? 'Your photo is being reviewed. This can take a little while.' : 'Picha yako inakaguliwa. Hii inaweza kuchukua muda kidogo.',
            ),
          if (verified && hidden)
            note(
              Icons.visibility_off_outlined,
              AppColors.primary,
              AppColors.primaryLight,
              _en
                  ? 'Hide My ID is ON, so providers see your profile photo and stage name with the Safe badge, not this photo. Turn it off in Settings to show this verified photo.'
                  : 'Ficha Utambulisho kimewashwa, kwa hiyo watoa huduma wanaona picha ya wasifu na jina lako la kikazi pamoja na beji ya Safe, si picha hii. Kizime kwenye Mipangilio ili picha hii ionekane.',
            ),
          if (verified && !hidden)
            note(
              Icons.verified_rounded,
              AppColors.successDark,
              AppColors.successLight,
              _en
                  ? 'Providers see this verified photo on your requests.'
                  : 'Watoa huduma wanaona picha hii iliyothibitishwa kwenye maombi yako.',
            ),
          if (!verified)
            note(
              Icons.info_outline_rounded,
              AppColors.primary,
              AppColors.primaryLight,
              _en
                  ? 'Once verified, this photo is shown to providers on your requests while Hide My ID is off.'
                  : 'Ikishathibitishwa, picha hii huonyeshwa kwa watoa huduma kwenye maombi yako ikiwa Ficha Utambulisho kimezimwa.',
            ),
          const SizedBox(height: 20),
          AppButton.primary(
            label: verified
                ? (_en ? 'Take a new photo' : 'Piga picha mpya')
                : (_en ? 'Take photo' : 'Piga picha'),
            onPressed: _loading ? null : _take,
          ),
        ],
      ),
    );
  }
}
