import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:audioplayers/audioplayers.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:record/record.dart';
import 'package:url_launcher/url_launcher.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/call_service.dart';
import '../services/media_picker.dart';
import '../services/permission_service.dart';
import '../services/session_manager.dart';
import '../services/block_service.dart';
import '../services/chat_prefs.dart';
import '../services/chat_socket.dart';
import '../models/models.dart';
import 'seller_profile_screen.dart';
import '../widgets/app_image.dart';
import '../widgets/app_ui.dart';
import '../widgets/block_user_dialog.dart';
import '../widgets/call_options_sheet.dart';
import '../widgets/report_sheet.dart';
import '../widgets/fullscreen_image_viewer.dart';
import '../widgets/login_modal.dart';
import '../services/data_sync.dart';
import '../widgets/online_indicator.dart';
import '../services/app_log.dart';

/// One-to-one conversation with a provider / client.
/// Open it with [ChatThreadScreen.open] - it asks the user to sign in first.
class ChatThreadScreen extends StatefulWidget {
  /// User id of the person being chatted with (the seller's user id).
  final String otherUserId;
  final String otherName;

  /// Whether the other person was online when the chat was opened.
  final bool isOnline;

  const ChatThreadScreen({
    super.key,
    required this.otherUserId,
    required this.otherName,
    this.isOnline = false,
  });

  /// Opens a chat with [recipientId]. Guests get the login sheet first.
  static Future<void> open(
    BuildContext context, {
    required int? recipientId,
    required String name,
    bool isOnline = false,
  }) async {
    final isEn = AppStrings.isEnglish;
    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);

    if (recipientId == null || recipientId == 0) {
      messenger.showSnackBar(SnackBar(
        content: Text(isEn ? 'Chat is not available for this provider yet.' : 'Mazungumzo hayapatikani kwa mtoa huduma huyu bado.'),
      ));
      return;
    }

    if (!SessionManager.isLoggedIn()) {
      final ok = await LoginModal.show(context);
      if (ok != true || !SessionManager.isLoggedIn()) return;
    }

    if (SessionManager.getUserIdValue() == recipientId) {
      messenger.showSnackBar(SnackBar(
        content: Text(isEn ? "You can't chat with yourself." : 'Huwezi kuzungumza na wewe mwenyewe.'),
      ));
      return;
    }

    await navigator.push(MaterialPageRoute(
      builder: (_) => ChatThreadScreen(otherUserId: recipientId.toString(), otherName: name, isOnline: isOnline),
    ));
    // Messages were read/sent in the thread: refresh the Chats list and the Home bell badge.
    DataSync.bump();
  }

  @override
  State<ChatThreadScreen> createState() => _ChatThreadScreenState();
}

class _Msg {
  final bool isMe;
  final String text;
  final String time;
  final bool pending;

  /// Picture shown in the bubble (a link on our own server), if any.
  final String? imageUrl;

  /// Voice note (link on our own server) and its length in seconds, if known.
  final String? audioUrl;
  final int? audioSeconds;

  /// Document (link on our own server) and its original file name.
  final String? fileUrl;
  final String? fileName;

  /// An attachment (photo / voice note / document) still being uploaded.
  final ChatAttachmentKind? uploading;

  /// When the message was sent (null when the server gave no usable time).
  final DateTime? at;

  /// Server id (null while a message is still being sent).
  final int? id;

  /// While an attachment uploads: the file on this phone (for the thumbnail) and how far it is (0..1).
  final String? localPath;
  final ValueNotifier<double>? progress;

  /// My messages only: 'sent' (stored on the server), 'delivered' (reached their phone), 'read' (they opened the chat).
  final String status;

  /// The message this one answers, if any.
  final _ReplyRef? replyTo;

  /// Text was changed after sending.
  final bool edited;

  /// Used by the "fly from the text box" animation: the bubble is laid out
  /// (so its place can be measured) but stays invisible until the flight lands.
  final GlobalKey? flyKey;
  bool flying;

  /// Weak network: all tries failed. The message stays in the chat; tap it to try again.
  bool failed = false;

  /// App-made id of this send: the server ignores a repeat of it, so a retry never doubles the message.
  final String? clientId;

  /// The message this one answers (id), kept for retries.
  final int? replyToId;

  /// Attachment already uploaded on an earlier try: only the final send is left.
  String? uploadedLink;

  /// The document name given when the attachment was picked (goes into the message link).
  final String? attachName;

  _Msg({
    this.clientId,
    this.replyToId,
    this.attachName,
    required this.isMe,
    required this.text,
    required this.time,
    this.pending = false,
    this.imageUrl,
    this.audioUrl,
    this.audioSeconds,
    this.fileUrl,
    this.fileName,
    this.uploading,
    this.at,
    this.id,
    this.localPath,
    this.progress,
    this.status = 'sent',
    this.replyTo,
    this.edited = false,
    this.flyKey,
    this.flying = false,
  });
}

/// What a reply quotes. [text] is already a short label (attachments show "Photo", ...).
class _ReplyRef {
  final int? id;
  final String text;
  final bool isMe;
  final bool deleted;
  const _ReplyRef({this.id, required this.text, required this.isMe, this.deleted = false});
}

/// Play / pause of a voice note that has not been sent yet (own player, so the chat's player is not disturbed).
class _VoicePreview extends StatefulWidget {
  final String path;
  final int seconds;
  const _VoicePreview({required this.path, required this.seconds});

  @override
  State<_VoicePreview> createState() => _VoicePreviewState();
}

class _VoicePreviewState extends State<_VoicePreview> {
  final AudioPlayer _p = AudioPlayer();
  final List<StreamSubscription<dynamic>> _subs = [];
  bool _playing = false;
  Duration _pos = Duration.zero;

  @override
  void initState() {
    super.initState();
    _subs.addAll([
      _p.onPlayerStateChanged.listen((s) {
        if (mounted) setState(() => _playing = s == PlayerState.playing);
      }),
      _p.onPositionChanged.listen((d) {
        if (mounted) setState(() => _pos = d);
      }),
      _p.onPlayerComplete.listen((_) {
        if (mounted) setState(() => _pos = Duration.zero);
      }),
    ]);
  }

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    _p.dispose();
    super.dispose();
  }

  Future<void> _toggle() async {
    try {
      if (_playing) {
        await _p.pause();
      } else {
        await _p.play(DeviceFileSource(widget.path));
      }
    } catch (caught, trace) { AppLog.e('chat_thread_screen._toggle', caught, trace); }
  }

  String _fmt(int sec) => '${(sec ~/ 60)}:${(sec % 60).toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final total = widget.seconds <= 0 ? 1 : widget.seconds;
    final frac = (_pos.inMilliseconds / (total * 1000)).clamp(0.0, 1.0);
    return Row(
      children: [
        Material(
          color: AppColors.primary,
          shape: const CircleBorder(),
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: _toggle,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Icon(_playing ? Icons.pause_rounded : Icons.play_arrow_rounded, color: Colors.white, size: 26),
            ),
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: frac,
                  minHeight: 5,
                  color: AppColors.primary,
                  backgroundColor: AppColors.borderLight,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                '${_fmt(_pos.inSeconds)} / ${_fmt(widget.seconds)}',
                style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

/// The text travelling from the text box into its chat bubble.
class _FlyingBubble extends StatefulWidget {
  final Rect from;
  final Rect to;
  final String text;
  final VoidCallback onDone;
  const _FlyingBubble({required this.from, required this.to, required this.text, required this.onDone});

  @override
  State<_FlyingBubble> createState() => _FlyingBubbleState();
}

class _FlyingBubbleState extends State<_FlyingBubble> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 420));

  @override
  void initState() {
    super.initState();
    _c.forward().whenComplete(widget.onDone);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  static double _lerp(double a, double b, double t) => a + (b - a) * t;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: _c,
        builder: (_, _) {
          final t = Curves.easeInOutCubic.transform(_c.value);
          final r = Rect.lerp(widget.from, widget.to, t)!;
          return Stack(
            children: [
              Positioned.fromRect(
                rect: r,
                child: Material(
                  color: Color.lerp(AppColors.background, AppColors.primary, t),
                  elevation: 4 * (1 - (2 * t - 1).abs()),
                  borderRadius: BorderRadius.circular(_lerp(22, 14, t)),
                  clipBehavior: Clip.antiAlias,
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: _lerp(14, 12, t)),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        widget.text,
                        maxLines: 4,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: _lerp(16, 14, t),
                          color: Color.lerp(AppColors.textPrimary, Colors.white, t),
                          decoration: TextDecoration.none,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _ChatThreadScreenState extends State<ChatThreadScreen> {
  final _input = TextEditingController();
  final _inputFocus = FocusNode();
  final _fieldKey = GlobalKey(); // the text box: where the flying bubble starts
  final _scroll = ScrollController();
  _Msg? _replyingTo; // the message the next one answers
  _Msg? _editing; // the message whose text is being changed

  // "Go to latest" button: shown while scrolled up; counts messages that arrived meanwhile.
  static const double _awayDistance = 240;
  bool _showJump = false;
  int _newAway = 0;
  List<_Msg> _messages = [];
  bool _loading = true;
  bool _sending = false;
  Timer? _poll;
  StreamSubscription<ChatEvent>? _socketSub;
  int _pollTick = 0;
  int _loadSeq = 0; // only the newest fetch may update the screen
  bool _offline = false; // live line down for a while: "waiting for network" bar
  Timer? _offlineTimer;
  bool _retryingFailed = false;

  // Search in conversation
  bool _searching = false;
  String _query = '';
  final TextEditingController _searchCtl = TextEditingController();
  final FocusNode _searchFocus = FocusNode();

  // View profile (looks the provider up first when it is not cached)
  bool _profileLoading = false;

  // Voice note recording
  static const int _maxVoiceSeconds = 300; // 5 minutes
  static const int _maxFileBytes = 15 * 1024 * 1024; // 15 MB
  final AudioRecorder _recorder = AudioRecorder();
  bool _recording = false;
  int _recSeconds = 0;
  Timer? _recTimer;

  // Voice note playback (one at a time)
  final AudioPlayer _player = AudioPlayer();
  final List<StreamSubscription<dynamic>> _playerSubs = [];
  final ValueNotifier<Duration> _pos = ValueNotifier(Duration.zero);
  final ValueNotifier<Duration> _dur = ValueNotifier(Duration.zero);
  String? _playingUrl;
  bool _isPlaying = false;

  bool get _isEn => AppStrings.isEnglish;
  int? get _otherId => int.tryParse(widget.otherUserId);
  bool get _isBlocked => BlockService.isBlocked(_otherId);
  bool get _isMuted => ChatPrefs.isMuted(_otherId);
  int get _myId => SessionManager.getUserIdValue();

  @override
  void initState() {
    super.initState();
    BlockService.changed.addListener(_onBlockChanged);
    ChatPrefs.changed.addListener(_onBlockChanged);
    _scroll.addListener(_onScroll);
    _load();
    // Live: the server tells us the moment this conversation changes.
    ChatSocket.start();
    _socketSub = ChatSocket.events.listen((e) {
      if (!mounted) return;
      if (e.involves(_otherId)) _load(silent: true);
      if (e.isReconnect) _retryAllFailed(); // the network is back: send what could not go
    });
    ChatSocket.connected.addListener(_onSocketState);
    _onSocketState();
    // Safety net: refresh every 8 s while the live line is down, every ~32 s while it is up.
    _poll = Timer.periodic(const Duration(seconds: 8), (_) {
      if (ChatSocket.connected.value && ++_pollTick % 4 != 0) return;
      _load(silent: true);
    });

    _playerSubs.addAll([
      _player.onPlayerStateChanged.listen((s) {
        if (mounted) setState(() => _isPlaying = s == PlayerState.playing);
      }),
      _player.onPositionChanged.listen((p) => _pos.value = p),
      _player.onDurationChanged.listen((d) => _dur.value = d),
      _player.onPlayerComplete.listen((_) {
        _pos.value = Duration.zero;
        if (mounted) {
          setState(() {
            _isPlaying = false;
            _playingUrl = null;
          });
        }
      }),
    ]);
  }

  /// Shows the "waiting for network" bar only after the line has been down a few seconds (no flicker).
  void _onSocketState() {
    _offlineTimer?.cancel();
    if (ChatSocket.connected.value) {
      if (_offline && mounted) setState(() => _offline = false);
    } else {
      _offlineTimer = Timer(const Duration(seconds: 6), () {
        if (mounted && !ChatSocket.connected.value) setState(() => _offline = true);
      });
    }
  }

  void _onBlockChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    BlockService.changed.removeListener(_onBlockChanged);
    ChatPrefs.changed.removeListener(_onBlockChanged);
    _scroll.removeListener(_onScroll);
    _searchCtl.dispose();
    _searchFocus.dispose();
    _poll?.cancel();
    _socketSub?.cancel();
    ChatSocket.connected.removeListener(_onSocketState);
    _offlineTimer?.cancel();
    _recTimer?.cancel();
    if (_recording) {
      unawaited(_recorder.cancel().whenComplete(_recorder.dispose));
    } else {
      _recorder.dispose();
    }
    for (final sub in _playerSubs) {
      sub.cancel();
    }
    _player.dispose();
    _pos.dispose();
    _dur.dispose();
    _input.dispose();
    _inputFocus.dispose();
    _scroll.dispose();
    super.dispose();
  }

  String _fmtTime(dynamic raw) {
    final d = DateTime.tryParse(raw?.toString() ?? '')?.toLocal();
    if (d == null) return '';
    final h = d.hour.toString().padLeft(2, '0');
    final m = d.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }

  _Msg _parse(Map<String, dynamic> m) {
    dynamic senderId = m['senderId'];
    final sender = m['sender'];
    if (senderId == null && sender is Map) senderId = sender['id'];
    final isMe = m['isMe'] == true ||
        (senderId != null && senderId.toString() == _myId.toString());
    final text = (m['content'] ?? m['message'] ?? m['text'] ?? '').toString();
    // A picture arrives either as its own field or as a link in the text
    // (that is how this app sends one, like call links). Voice notes and
    // documents are links in the text too.
    var image = (m['imageUrl'] ?? m['attachmentUrl'] ?? m['mediaUrl'])?.toString().trim();
    if (image != null && (image.isEmpty || image == 'null')) image = null;
    final kind = ApiService.chatAttachmentKind(text);
    if (image == null && kind == ChatAttachmentKind.image) image = text.trim();
    final rawTime = m['createdAt'] ?? m['timestamp'] ?? m['sentAt'] ?? m['time'];
    _ReplyRef? reply;
    final rp = m['replyTo'];
    if (rp is Map) {
      reply = _ReplyRef(
        id: int.tryParse('${rp['id'] ?? ''}'),
        text: ApiService.chatPreview('${rp['text'] ?? ''}'),
        isMe: rp['isMe'] == true,
        deleted: rp['deleted'] == true,
      );
    }
    return _Msg(
      id: int.tryParse('${m['id'] ?? ''}'),
      status: m['status']?.toString() ?? (m['isRead'] == true ? 'read' : 'sent'),
      replyTo: reply,
      edited: m['edited'] == true,
      isMe: isMe,
      at: DateTime.tryParse(rawTime?.toString() ?? '')?.toLocal(),
      text: kind != null ? '' : text,
      imageUrl: image == null ? null : ApiService.absoluteUrl(image),
      audioUrl: kind == ChatAttachmentKind.audio ? ApiService.chatAttachmentUrl(text) : null,
      audioSeconds: kind == ChatAttachmentKind.audio ? ApiService.chatAudioSeconds(text) : null,
      fileUrl: kind == ChatAttachmentKind.file ? ApiService.chatAttachmentUrl(text) : null,
      fileName: kind == ChatAttachmentKind.file ? ApiService.chatAttachmentName(text) : null,
      time: _fmtTime(rawTime),
    );
  }

  Future<void> _load({bool silent = false}) async {
    if (silent && _sending) return; // a send is in flight: its own reload follows
    await ChatPrefs.ensureLoaded();
    final seq = ++_loadSeq;
    final raw = await ApiService.fetchMessages(widget.otherUserId);
    if (!mounted || seq != _loadSeq) return; // a newer fetch is already on its way / done
    if (raw == null) {
      // no answer (weak network): keep every message already on screen, never wipe the chat
      if (_loading) setState(() => _loading = false);
      return;
    }
    // a send started while we were fetching: this result may already contain the
    // new message while its pending bubble is still shown, so drop it
    if (silent && _sending) return;
    final clearedAt = ChatPrefs.clearedAt(_otherId);
    final parsed = raw
        .whereType<Map>()
        .map((e) => _parse(Map<String, dynamic>.from(e)))
        .where((m) => m.text.isNotEmpty || m.imageUrl != null || m.audioUrl != null || m.fileUrl != null)
        .where((m) => clearedAt == null || m.at == null || m.at!.isAfter(clearedAt))
        .toList();
    final before = _messages.where((m) => !m.pending).length;
    final changed = parsed.length != before;
    final wasNearEnd = !_scroll.hasClients || !_isAwayFromEnd;
    // messages from the other person that arrived while I was reading older ones
    final arrived = parsed.length > before ? parsed.skip(before).where((m) => !m.isMe).length : 0;
    setState(() {
      _loading = false;
      // keep any message still being sent
      _messages = [...parsed, ..._messages.where((m) => m.pending)];
      if (silent && changed && !wasNearEnd) _newAway += arrived;
    });
    // Follow new messages only when already at the end; never pull someone away from old ones.
    if (!silent || (changed && wasNearEnd)) _scrollToEnd();
  }

  bool get _isAwayFromEnd =>
      _scroll.hasClients && _scroll.position.maxScrollExtent - _scroll.position.pixels > _awayDistance;

  void _onScroll() {
    final away = _isAwayFromEnd;
    if (away == _showJump && (away || _newAway == 0)) return;
    setState(() {
      _showJump = away;
      if (!away) _newAway = 0;
    });
  }

  void _jumpToLatest() {
    setState(() => _newAway = 0);
    if (_scroll.hasClients) {
      _scroll.animateTo(
        _scroll.position.maxScrollExtent,
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeOutCubic,
      );
    }
  }

  /// Round button at the bottom right of the messages.
  Widget _jumpButton() {
    final show = _showJump && !_searching;
    return Positioned(
      right: 14,
      bottom: 12,
      child: IgnorePointer(
        ignoring: !show,
        child: AnimatedScale(
          scale: show ? 1 : 0,
          duration: const Duration(milliseconds: 160),
          curve: Curves.easeOut,
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Material(
                color: Colors.white,
                elevation: 4,
                shape: const CircleBorder(),
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: _jumpToLatest,
                  child: Tooltip(
                    message: _isEn ? 'Go to latest message' : 'Nenda ujumbe wa mwisho',
                    child: const Padding(
                      padding: EdgeInsets.all(9),
                      child: Icon(Icons.keyboard_arrow_down_rounded, size: 26, color: AppColors.primary),
                    ),
                  ),
                ),
              ),
              if (_newAway > 0)
                Positioned(
                  top: -6,
                  right: -4,
                  child: Container(
                    constraints: const BoxConstraints(minWidth: 18),
                    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                    decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(10)),
                    child: Text(
                      _newAway > 99 ? '99+' : '$_newAway',
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: Colors.white),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  void _scrollToEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  /// Where [key]'s widget is on screen, or null when it is not laid out.
  Rect? _rectOf(GlobalKey key) {
    final ro = key.currentContext?.findRenderObject();
    if (ro is! RenderBox || !ro.attached || !ro.hasSize) return null;
    return ro.localToGlobal(Offset.zero) & ro.size;
  }

  /// Flies [text] from the text box [from] into the new bubble of [msg].
  /// Completes when the bubble has landed (or at once when it cannot be animated).
  Future<void> _flyToBubble(_Msg msg, Rect from, String text) {
    final done = Completer<void>();
    void land() {
      msg.flying = false;
      if (mounted) setState(() {});
      if (!done.isCompleted) done.complete();
    }

    // Wait for the new bubble to be built, move the list to its end without animation
    // (so the target holds still), wait for that layout, then measure and fly.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) {
        land();
        return;
      }
      if (_scroll.hasClients) _scroll.jumpTo(_scroll.position.maxScrollExtent);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        final to = msg.flyKey == null ? null : _rectOf(msg.flyKey!);
        final overlay = mounted ? Overlay.maybeOf(context) : null;
        if (to == null || overlay == null) {
          land();
          return;
        }
        late OverlayEntry entry;
        entry = OverlayEntry(
          builder: (_) => _FlyingBubble(
            from: from,
            to: to,
            text: text,
            onDone: () {
              entry.remove();
              land();
            },
          ),
        );
        overlay.insert(entry);
      });
    });
    return done.future;
  }

  Future<void> _send() async {
    final text = _input.text.trim();
    if (text.isEmpty || _sending || _isBlocked) return;
    if (_editing != null) {
      await _saveEdit(text);
      return;
    }

    final reply = _replyingTo;
    final from = _rectOf(_fieldKey);
    final msg = _Msg(
      isMe: true,
      text: text,
      time: _fmtTime(DateTime.now().toIso8601String()),
      pending: true,
      at: DateTime.now(),
      replyTo: reply == null ? null : _replyRefOf(reply),
      flyKey: from == null ? null : GlobalKey(),
      flying: from != null,
      clientId: _newClientId(),
      replyToId: reply?.id,
    );
    _input.clear();
    setState(() {
      _sending = true;
      _replyingTo = null;
      _messages.add(msg);
    });

    final landed = from == null ? Future<void>.value() : _flyToBubble(msg, from, text);
    if (from == null) _scrollToEnd();
    final res = await _sendRetrying(text, reply?.id, msg.clientId!);
    final rejected = ApiService.lastSendRejected;
    await landed;
    if (!mounted) return;
    setState(() => _sending = false);

    if (res == null) {
      if (rejected) {
        // the server refused it (for example blocked): give the text back
        setState(() {
          _messages.remove(msg);
          _replyingTo = reply;
        });
        _input.text = text;
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          backgroundColor: AppColors.danger,
          content: Text(_isEn ? 'Message not sent. Try again.' : 'Ujumbe haujatumwa. Jaribu tena.'),
        ));
      } else {
        // weak network: the message stays here and goes out by itself when the network is back
        setState(() => msg.failed = true);
        _snackNoNetwork();
      }
      return;
    }
    // The server copy replaces the local pending bubble. Without removing it here
    // _load() keeps every pending message, so the sent message showed up twice.
    setState(() => _messages.remove(msg));
    await _load(silent: true);
    _scrollToEnd();
  }

  String _newClientId() =>
      '${_myId}_${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}${Random().nextInt(1 << 30).toRadixString(36)}';

  void _snackNoNetwork() {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: AppColors.danger,
      content: Text(_isEn
          ? 'Weak network. Your message is saved here; tap it to try again.'
          : 'Mtandao dhaifu. Ujumbe wako umehifadhiwa hapa; ugusa kujaribu tena.'),
    ));
  }

  /// Sends with up to 3 tries on a weak network. The same [clientId] goes every time, so if an earlier
  /// try reached the server but its answer got lost, the server returns the saved message (no duplicate).
  Future<Map<String, dynamic>?> _sendRetrying(String text, int? replyToId, String clientId) async {
    const waits = [Duration(seconds: 2), Duration(seconds: 5)];
    for (var i = 0;; i++) {
      final res = await ApiService.sendMessage(
        recipientId: widget.otherUserId,
        message: text,
        replyToId: replyToId,
        clientId: clientId,
      );
      if (res != null || ApiService.lastSendRejected || i >= waits.length || !mounted) return res;
      await Future<void>.delayed(waits[i]);
      if (!mounted) return null;
    }
  }

  /// Tap on a message that could not be sent.
  Future<void> _retryMessage(_Msg m) async {
    if (!m.failed || _sending || _isBlocked) return;
    setState(() {
      m.failed = false;
      _sending = true;
    });
    if (m.uploading != null) {
      await _uploadAndSend(m);
      return;
    }
    final res = await _sendRetrying(m.text, m.replyToId, m.clientId ?? _newClientId());
    final rejected = ApiService.lastSendRejected;
    if (!mounted) return;
    if (res == null) {
      setState(() {
        _sending = false;
        if (rejected) {
          _messages.remove(m);
        } else {
          m.failed = true;
        }
      });
      if (rejected) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          backgroundColor: AppColors.danger,
          content: Text(_isEn ? 'Message not sent.' : 'Ujumbe haujatumwa.'),
        ));
      } else {
        _snackNoNetwork();
      }
      return;
    }
    setState(() {
      _sending = false;
      _messages.remove(m);
    });
    await _load(silent: true);
    _scrollToEnd();
  }

  /// The network came back: send everything that was waiting, oldest first.
  Future<void> _retryAllFailed() async {
    if (_retryingFailed) return;
    _retryingFailed = true;
    try {
      for (final m in _messages.where((x) => x.failed).toList()) {
        if (!mounted || _sending) return;
        await _retryMessage(m);
      }
    } finally {
      _retryingFailed = false;
    }
  }

  /// Long-press on a message that could not be sent: try again or throw it away.
  Future<void> _showFailedMenu(_Msg m) async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.refresh_rounded, color: AppColors.primary),
              title: Text(_isEn ? 'Try again' : 'Jaribu tena', style: const TextStyle(fontWeight: FontWeight.w600)),
              onTap: () => Navigator.pop(ctx, 'retry'),
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline_rounded, color: AppColors.danger),
              title: Text(_isEn ? 'Delete' : 'Futa',
                  style: const TextStyle(fontWeight: FontWeight.w600, color: AppColors.danger)),
              onTap: () => Navigator.pop(ctx, 'delete'),
            ),
          ],
        ),
      ),
    );
    if (!mounted) return;
    if (choice == 'retry') {
      await _retryMessage(m);
    } else if (choice == 'delete') {
      setState(() => _messages.remove(m));
      final path = m.localPath;
      if (path != null && m.uploading == ChatAttachmentKind.audio) {
        try {
          await File(path).delete(); // the recording was only a temporary file
        } catch (caught, trace) { AppLog.e('chat_thread_screen._showFailedMenu', caught, trace); }
      }
    }
  }

  // ---------------------------------------------------------------------------
  // Reply / edit / delete
  // ---------------------------------------------------------------------------

  /// Short label of a message for quotes and the reply bar.
  String _labelOf(_Msg m) {
    if (m.text.isNotEmpty) return m.text;
    if (m.imageUrl != null) return _isEn ? '📷 Photo' : '📷 Picha';
    if (m.audioUrl != null) return _isEn ? '🎤 Voice message' : '🎤 Ujumbe wa sauti';
    if (m.fileUrl != null) return '📎 ${m.fileName ?? (_isEn ? 'Document' : 'Faili')}';
    return '';
  }

  _ReplyRef _replyRefOf(_Msg m) => _ReplyRef(id: m.id, text: _labelOf(m), isMe: m.isMe);

  bool _canEdit(_Msg m) =>
      m.isMe &&
      !m.pending &&
      m.id != null &&
      m.text.isNotEmpty &&
      m.imageUrl == null &&
      m.audioUrl == null &&
      m.fileUrl == null &&
      (m.at == null || DateTime.now().difference(m.at!) < const Duration(minutes: 15));

  void _startReply(_Msg m) {
    if (m.id == null || _isBlocked) return;
    final wasEditing = _editing != null;
    setState(() {
      _replyingTo = m;
      _editing = null;
    });
    if (wasEditing) _input.clear();
    _inputFocus.requestFocus();
  }

  void _startEdit(_Msg m) {
    setState(() {
      _editing = m;
      _replyingTo = null;
    });
    _input.value = TextEditingValue(text: m.text, selection: TextSelection.collapsed(offset: m.text.length));
    _inputFocus.requestFocus();
  }

  void _cancelEdit() {
    setState(() => _editing = null);
    _input.clear();
  }

  Future<void> _saveEdit(String text) async {
    final target = _editing;
    final id = target?.id;
    if (target == null || id == null || text == target.text) {
      _cancelEdit();
      return;
    }
    setState(() => _sending = true);
    final res = await ApiService.editMessage(id, text);
    if (!mounted) return;
    setState(() => _sending = false);
    if (res == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        backgroundColor: AppColors.danger,
        content: Text(_isEn
            ? 'Could not change the message. Messages can be edited for 15 minutes.'
            : 'Imeshindwa kubadilisha ujumbe. Ujumbe hubadilishwa ndani ya dakika 15.'),
      ));
      return;
    }
    _cancelEdit();
    await _load(silent: true);
  }

  /// Delete for me only. The server removes the message for good once both people deleted it.
  Future<void> _deleteMsg(_Msg m) async {
    final id = m.id;
    if (id == null) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(_isEn ? 'Delete message?' : 'Futa ujumbe?'),
        content: Text(_isEn ? 'It will be deleted from your chat.' : 'Utafutwa kwenye mazungumzo yako.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(_isEn ? 'Cancel' : 'Ghairi')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(_isEn ? 'Delete' : 'Futa', style: const TextStyle(color: AppColors.danger)),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    final done = await ApiService.deleteMessage(id);
    if (!mounted) return;
    if (!done) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        backgroundColor: AppColors.danger,
        content: Text(_isEn ? 'Could not delete the message. Try again.' : 'Imeshindwa kufuta ujumbe. Jaribu tena.'),
      ));
      return;
    }
    setState(() {
      if (_replyingTo?.id == id) _replyingTo = null;
      _messages.remove(m);
    });
    if (_editing?.id == id) _cancelEdit();
    await _load(silent: true);
  }

  /// Long-press menu of a message.
  Future<void> _showMessageMenu(_Msg m) async {
    if (m.pending || m.uploading != null || m.id == null) return;
    final copyText = m.text;
    final choice = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (ctx) {
        Widget tile(String value, IconData icon, String label, {Color? color}) => ListTile(
              leading: Icon(icon, color: color ?? AppColors.textPrimary),
              title: Text(label, style: TextStyle(fontWeight: FontWeight.w600, color: color ?? AppColors.textPrimary)),
              onTap: () => Navigator.pop(ctx, value),
            );
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (!_isBlocked) tile('reply', Icons.reply_rounded, _isEn ? 'Reply' : 'Jibu'),
              if (copyText.isNotEmpty) tile('copy', Icons.copy_rounded, _isEn ? 'Copy' : 'Nakili'),
              if (_canEdit(m)) tile('edit', Icons.edit_outlined, _isEn ? 'Edit' : 'Hariri'),
              tile('delete', Icons.delete_outline_rounded, _isEn ? 'Delete' : 'Futa', color: AppColors.danger),
            ],
          ),
        );
      },
    );
    if (!mounted || choice == null) return;
    switch (choice) {
      case 'reply':
        _startReply(m);
      case 'copy':
        await Clipboard.setData(ClipboardData(text: copyText));
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          duration: const Duration(seconds: 1),
          content: Text(_isEn ? 'Copied' : 'Imenakiliwa'),
        ));
      case 'edit':
        _startEdit(m);
      case 'delete':
        await _deleteMsg(m);
    }
  }

  // ---------------------------------------------------------------------------
  // Three-dots menu actions
  // ---------------------------------------------------------------------------

  void _openSearch() {
    setState(() {
      _searching = true;
      _query = '';
      _searchCtl.clear();
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _searchFocus.requestFocus();
    });
  }

  void _closeSearch() {
    FocusScope.of(context).unfocus();
    setState(() {
      _searching = false;
      _query = '';
      _searchCtl.clear();
    });
    _scrollToEnd();
  }

  bool _matchesQuery(_Msg m) {
    final q = _query.trim().toLowerCase();
    if (q.isEmpty) return true;
    return m.text.toLowerCase().contains(q) || (m.fileName ?? '').toLowerCase().contains(q);
  }

  /// The other person's service (needed for the profile page and call options).
  /// Opened from the Chats list or a notification it is not cached yet, so it
  /// is looked up first. Null when this person has no provider listing.
  Future<ServiceItem?> _resolveProvider() async {
    final id = _otherId;
    if (id == null || id == 0) return null;

    ServiceItem? find() {
      for (final s in ApiService.knownServices.values) {
        if (s.sellerId == id) return s;
      }
      return null;
    }

    var provider = find();
    if (provider == null) {
      setState(() => _profileLoading = true);
      await ApiService.fetchServices(query: widget.otherName);
      if (!mounted) return null;
      setState(() => _profileLoading = false);
      provider = find();
    }
    return provider;
  }

  Future<void> _viewProfile() async {
    if (_profileLoading) return;
    final provider = await _resolveProvider();
    if (!mounted) return;
    if (provider == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(_isEn
            ? 'No provider profile for ${widget.otherName}.'
            : 'Hakuna wasifu wa mtoa huduma kwa ${widget.otherName}.'),
      ));
      return;
    }
    await Navigator.push(context, MaterialPageRoute(builder: (_) => SellerProfileScreen(provider: provider)));
  }

  /// Call button: opens every way to reach this person (in-app audio / video,
  /// mobile call, WhatsApp, directions).
  Future<void> _showCallOptions() async {
    if (_profileLoading) return;
    final contacts = await _bookingContacts();
    if (!mounted) return;
    final provider = await _resolveProvider();
    if (!mounted) return;
    if (provider == null && contacts == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(_isEn
            ? 'No call options available for ${widget.otherName}.'
            : 'Hakuna njia za kupiga simu kwa ${widget.otherName}.'),
      ));
      return;
    }
    if (provider == null) {
      await CallOptionsSheet.showForBooking(context, contacts!);
    } else {
      await CallOptionsSheet.show(context, provider, booking: contacts);
    }
  }

  /// The other person's contacts from a booking the server has unlocked (accepted and paid, completed, or disputed
  /// after acceptance). Null when there is no such booking. This is what lets a locked profile be called after a booking.
  Future<BookingContacts?> _bookingContacts() async {
    final other = _otherId;
    final me = SessionManager.getUserIdValue();
    if (other == null || other == 0 || !SessionManager.isLoggedIn()) return null;
    try {
      final lists = await Future.wait([ApiService.fetchBuyerTransactions(), ApiService.fetchSellerOrders()]);
      int? idOf(dynamic u) => u is Map ? int.tryParse('${u['id']}') : null;
      String text(dynamic v) => (v ?? '').toString().trim() == 'null' ? '' : (v ?? '').toString().trim();
      for (final list in lists) {
        for (final t in list) {
          if (t is! Map || t['contactsUnlocked'] != true) continue;
          final buyerId = idOf(t['buyer']);
          final sellerId = idOf(t['seller']);
          if (buyerId == me && sellerId == other) {
            return BookingContacts(
              userId: other,
              name: widget.otherName,
              phone: text(t['sellerPhone']),
              whatsapp: text(t['sellerWhatsappPhone']),
              latitude: (t['sellerLatitude'] as num?)?.toDouble(),
              longitude: (t['sellerLongitude'] as num?)?.toDouble(),
            );
          }
          if (sellerId == me && buyerId == other) {
            return BookingContacts(userId: other, name: widget.otherName, phone: text(t['buyerPhone']));
          }
        }
      }
    } catch (caught, trace) { AppLog.e('chat_thread_screen._bookingContacts', caught, trace); }
    return null;
  }

  Future<void> _toggleMute() async {
    final id = _otherId;
    if (id == null || id == 0) return;
    final mute = !_isMuted;
    await ChatPrefs.setMuted(id, mute);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(mute
          ? (_isEn ? 'Notifications muted for ${widget.otherName}.' : 'Arifa zimenyamazishwa kwa ${widget.otherName}.')
          : (_isEn ? 'Notifications turned on.' : 'Arifa zimewashwa.')),
    ));
  }

  Future<void> _clearChat() async {
    final id = _otherId;
    if (id == null || id == 0) return;
    DateTime? latest;
    for (final m in _messages) {
      final t = m.at;
      if (!m.pending && t != null && (latest == null || t.isAfter(latest))) latest = t;
    }
    if (latest == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(_isEn ? 'There are no messages to clear.' : 'Hakuna ujumbe wa kufuta.'),
      ));
      return;
    }
    final moment = latest;
    final ok = await AppDialog.confirm(
      context,
      icon: Icons.delete_sweep_outlined,
      color: AppColors.danger,
      title: _isEn ? 'Clear this chat?' : 'Futa mazungumzo haya?',
      message: _isEn
          ? 'Messages are removed from this phone only. ${widget.otherName} keeps their copy.'
          : 'Ujumbe unafutwa kwenye simu hii tu. ${widget.otherName} ataendelea kuwa nao.',
      confirmLabel: _isEn ? 'Clear chat' : 'Futa',
    );
    if (!ok || !mounted) return;
    await ChatPrefs.clearUpTo(id, moment);
    if (!mounted) return;
    setState(() => _messages.removeWhere((m) => !m.pending));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(_isEn ? 'Chat cleared.' : 'Mazungumzo yamefutwa.'),
    ));
  }

  /// Opens the "+" menu: photo or document.
  Future<void> _showAttachMenu() async {
    if (_sending || _isBlocked) return;
    final choice = await AppSheet.show<String>(
      context,
      title: _isEn ? 'Attach' : 'Ambatisha',
      builder: (ctx) => Column(
        children: [
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.photo_outlined, color: AppColors.textPrimary),
            title: Text(_isEn ? 'Photo' : 'Picha',
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
            onTap: () => Navigator.pop(ctx, 'photo'),
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.insert_drive_file_outlined, color: AppColors.textPrimary),
            title: Text(_isEn ? 'Document' : 'Hati / Faili',
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
            subtitle: Text(
              _isEn ? 'PDF, Word, Excel, PowerPoint, text...' : 'PDF, Word, Excel, PowerPoint, maandishi...',
              style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
            ),
            onTap: () => Navigator.pop(ctx, 'file'),
          ),
        ],
      ),
    );
    if (!mounted) return;
    if (choice == 'photo') {
      _attachImage();
    } else if (choice == 'file') {
      _attachFile();
    }
  }

  /// Pick a photo, upload it, then send its link as the message.
  Future<void> _attachImage() async {
    if (_sending || _isBlocked) return;
    final file = await MediaPicker.pickImage(
      context,
      title: _isEn ? 'Send a photo' : 'Tuma picha',
      maxWidth: 1600,
    );
    if (file == null || !mounted) return;
    await _sendAttachment(path: file.path, kind: ChatAttachmentKind.image);
  }

  /// Pick a document, upload it, then send its link as the message.
  Future<void> _attachFile() async {
    if (_sending || _isBlocked) return;
    final messenger = ScaffoldMessenger.of(context);
    void warn(String text) =>
        messenger.showSnackBar(SnackBar(backgroundColor: AppColors.danger, content: Text(text)));

    FilePickerResult? res;
    try {
      res = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ApiService.chatFileExtensions,
        withData: false,
      );
    } catch (caught, trace) {
      AppLog.e('chat_thread_screen._attachFile', caught, trace);
      warn(_isEn ? 'Could not open the file picker.' : 'Imeshindwa kufungua uchaguzi wa faili.');
      return;
    }
    if (res == null || res.files.isEmpty || !mounted) return;
    final f = res.files.single;
    final path = f.path;
    if (path == null) {
      warn(_isEn ? 'Could not read that file.' : 'Imeshindwa kusoma faili hilo.');
      return;
    }
    if (f.size > _maxFileBytes) {
      warn(_isEn ? 'File is too large (max 15 MB).' : 'Faili ni kubwa mno (kiwango ni MB 15).');
      return;
    }
    await _sendAttachment(path: path, kind: ChatAttachmentKind.file, name: f.name);
  }

  static String _fmtBytes(int b) {
    if (b >= 1024 * 1024) return '${(b / (1024 * 1024)).toStringAsFixed(1)} MB';
    if (b >= 1024) return '${(b / 1024).round()} KB';
    return '$b B';
  }

  /// "Send this?" sheet shown before an attachment is uploaded. True = send.
  Future<bool> _previewAttachment({
    required String path,
    required ChatAttachmentKind kind,
    String? name,
    int? seconds,
  }) async {
    var size = 0;
    try {
      size = File(path).lengthSync();
    } catch (caught, trace) { AppLog.e('chat_thread_screen._fmtBytes', caught, trace); }
    final fileName = name ?? path.split(RegExp(r'[\\/]')).last;
    final title = switch (kind) {
      ChatAttachmentKind.image => _isEn ? 'Send this photo' : 'Tuma picha hii',
      ChatAttachmentKind.audio => _isEn ? 'Send this voice message' : 'Tuma ujumbe huu wa sauti',
      ChatAttachmentKind.file => _isEn ? 'Send this file' : 'Tuma faili hili',
    };
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) {
        final Widget body;
        switch (kind) {
          case ChatAttachmentKind.image:
            body = ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: ConstrainedBox(
                constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.5),
                child: Image.file(
                  File(path),
                  fit: BoxFit.contain,
                  errorBuilder: (_, _, _) => Container(
                    height: 160,
                    alignment: Alignment.center,
                    color: Colors.black12,
                    child: const Icon(Icons.broken_image_outlined, color: AppColors.textMuted),
                  ),
                ),
              ),
            );
          case ChatAttachmentKind.audio:
            body = _VoicePreview(path: path, seconds: seconds ?? 0);
          case ChatAttachmentKind.file:
            body = Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: AppColors.background, borderRadius: BorderRadius.circular(12)),
                  child: const Icon(Icons.insert_drive_file_outlined, size: 30, color: AppColors.primary),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(fileName,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                      if (size > 0)
                        Text(_fmtBytes(size), style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                    ],
                  ),
                ),
              ],
            );
        }
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(title,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                Text(_isEn ? 'to ${widget.otherName}' : 'kwa ${widget.otherName}',
                    style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                const SizedBox(height: 14),
                body,
                const SizedBox(height: 18),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(ctx, false),
                        child: Text(_isEn ? 'Cancel' : 'Ghairi'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () => Navigator.pop(ctx, true),
                        icon: const Icon(Icons.send_rounded, size: 18),
                        label: Text(_isEn ? 'Send' : 'Tuma'),
                        style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary, foregroundColor: Colors.white),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
    return ok == true && mounted;
  }

  /// Uploads [path] and sends its link as the message. Shows a placeholder
  /// bubble while uploading and removes it again if anything fails.
  Future<void> _sendAttachment({
    required String path,
    required ChatAttachmentKind kind,
    String? name,
    int? seconds,
  }) async {
    // Show what is about to be sent first; nothing is uploaded until the user taps Send.
    final confirmed = await _previewAttachment(path: path, kind: kind, name: name, seconds: seconds);
    if (!confirmed) {
      if (kind == ChatAttachmentKind.audio) {
        // the recording was only a temporary file
        try {
          await File(path).delete();
        } catch (caught, trace) { AppLog.e('chat_thread_screen._fmtBytes', caught, trace); }
      }
      return;
    }
    if (!mounted) return;
    final reply = _replyingTo;
    // (a plain notifier: it holds no native resources, so there is nothing to dispose)
    final progress = ValueNotifier<double>(0);
    final msg = _Msg(
      isMe: true,
      text: '',
      time: _fmtTime(DateTime.now().toIso8601String()),
      pending: true,
      at: DateTime.now(),
      uploading: kind,
      localPath: path,
      progress: progress,
      fileName: name ?? path.split(RegExp(r'[\\/]')).last,
      audioSeconds: seconds,
      clientId: _newClientId(),
      replyToId: reply?.id,
      attachName: name,
    );
    setState(() {
      _sending = true;
      _replyingTo = null;
      _messages.add(msg);
    });
    _scrollToEnd();
    await _uploadAndSend(msg);
  }

  /// Uploads the attachment of [m] (3 tries on a weak network) and sends its link. When it still fails
  /// the bubble stays in the chat with a retry mark; a retry skips an upload that already succeeded.
  Future<void> _uploadAndSend(_Msg m) async {
    final kind = m.uploading!;
    final path = m.localPath!;
    final messenger = ScaffoldMessenger.of(context);

    final failText = switch (kind) {
      ChatAttachmentKind.image => _isEn ? 'Photo not sent. Try again.' : 'Picha haijatumwa. Jaribu tena.',
      ChatAttachmentKind.audio => _isEn ? 'Voice message not sent. Try again.' : 'Ujumbe wa sauti haujatumwa. Jaribu tena.',
      ChatAttachmentKind.file => _isEn ? 'File not sent. Try again.' : 'Faili halijatumwa. Jaribu tena.',
    };

    // [giveUp]: the server really refused it (retrying cannot help), so the bubble goes away.
    void fail(String text, {required bool giveUp}) {
      if (!mounted) return;
      setState(() {
        _sending = false;
        if (giveUp) {
          _messages.remove(m);
        } else {
          m.failed = true;
        }
      });
      messenger.showSnackBar(SnackBar(
        backgroundColor: AppColors.danger,
        content: Text(giveUp
            ? text
            : (_isEn
                ? 'Weak network. Tap the message to try again.'
                : 'Mtandao dhaifu. Gusa ujumbe kujaribu tena.')),
      ));
    }

    // 1) upload (skipped when an earlier try already uploaded it)
    if (m.uploadedLink == null) {
      const waits = [Duration(seconds: 2), Duration(seconds: 5)];
      UploadResult up;
      for (var i = 0;; i++) {
        m.progress?.value = 0;
        void onProgress(double p) => m.progress?.value = p;
        up = kind == ChatAttachmentKind.image
            ? await ApiService.uploadChatImage(path, onProgress: onProgress)
            : await ApiService.uploadChatFile(path, onProgress: onProgress);
        if (!mounted) return;
        if ((up.ok && up.url != null) || !up.retryable || i >= waits.length) break;
        await Future<void>.delayed(waits[i]);
        if (!mounted) return;
      }
      final url = up.url;
      if (!up.ok || url == null) {
        fail(up.error ?? failText, giveUp: !up.retryable);
        return;
      }
      m.uploadedLink = kind == ChatAttachmentKind.image
          ? url
          : ApiService.chatAttachmentLink(url, kind: kind, name: m.attachName, seconds: m.audioSeconds);
    }

    // 2) send the link
    final res = await _sendRetrying(m.uploadedLink!, m.replyToId, m.clientId ?? _newClientId());
    final rejected = ApiService.lastSendRejected;
    if (!mounted) return;
    if (res == null) {
      fail(failText, giveUp: rejected);
      return;
    }
    if (kind == ChatAttachmentKind.audio) {
      // the recording was only a temporary file
      try {
        await File(path).delete();
      } catch (caught, trace) { AppLog.e('chat_thread_screen.setState', caught, trace); }
    }
    setState(() {
      _sending = false;
      _messages.remove(m);
    });
    await _load(silent: true);
    _scrollToEnd();
  }

  // ---------------------------------------------------------------------------
  // Voice notes: record
  // ---------------------------------------------------------------------------

  Future<void> _startRecording() async {
    if (_sending || _isBlocked || _recording) return;
    final messenger = ScaffoldMessenger.of(context);
    final access = await MediaPermissions.microphone();
    if (!mounted) return;
    if (access != MediaAccess.granted) {
      messenger.showSnackBar(SnackBar(
        backgroundColor: AppColors.danger,
        content: Text(_isEn ? 'Allow microphone access to record a voice message.' : 'Ruhusu kipaza sauti ili kurekodi ujumbe wa sauti.'),
        action: access == MediaAccess.permanentlyDenied
            ? SnackBarAction(
                label: _isEn ? 'Settings' : 'Mipangilio',
                textColor: Colors.white,
                onPressed: PermissionService.openSettings,
              )
            : null,
      ));
      return;
    }

    try {
      await _stopPlayback(); // don't record over a playing voice note
      final path = '${Directory.systemTemp.path}/voice_${DateTime.now().millisecondsSinceEpoch}.m4a';
      await _recorder.start(
        const RecordConfig(
          encoder: AudioEncoder.aacLc,
          bitRate: 64000,
          sampleRate: 44100,
          numChannels: 1,
        ),
        path: path,
      );
      if (!mounted) {
        await _recorder.cancel();
        return;
      }
      setState(() {
        _recording = true;
        _recSeconds = 0;
      });
      _recTimer?.cancel();
      _recTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (!mounted || !_recording) return;
        setState(() => _recSeconds++);
        if (_recSeconds >= _maxVoiceSeconds) _finishRecording();
      });
    } catch (caught, trace) {
      AppLog.e('chat_thread_screen.setState', caught, trace);
      messenger.showSnackBar(SnackBar(
        backgroundColor: AppColors.danger,
        content: Text(_isEn ? 'Could not start recording.' : 'Imeshindwa kuanza kurekodi.'),
      ));
    }
  }

  /// Stops recording and sends the voice note.
  Future<void> _finishRecording() async {
    if (!_recording) return;
    final seconds = _recSeconds;
    _recTimer?.cancel();
    setState(() {
      _recording = false;
      _recSeconds = 0;
    });
    String? path;
    try {
      path = await _recorder.stop();
    } catch (caught, trace) { AppLog.e('chat_thread_screen.setState', caught, trace); }
    if (!mounted) return;
    if (path == null || seconds < 1) {
      if (path != null) {
        try {
          await File(path).delete();
        } catch (caught, trace) { AppLog.e('chat_thread_screen.setState', caught, trace); }
      }
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(_isEn ? 'Voice message too short.' : 'Ujumbe wa sauti ni mfupi mno.'),
      ));
      return;
    }
    await _sendAttachment(path: path, kind: ChatAttachmentKind.audio, seconds: seconds);
  }

  /// Throws the recording away.
  Future<void> _cancelRecording() async {
    if (!_recording) return;
    _recTimer?.cancel();
    setState(() {
      _recording = false;
      _recSeconds = 0;
    });
    try {
      await _recorder.cancel();
    } catch (caught, trace) { AppLog.e('chat_thread_screen.setState', caught, trace); }
  }

  // ---------------------------------------------------------------------------
  // Voice notes: play, and open documents
  // ---------------------------------------------------------------------------

  Future<void> _togglePlay(String url) async {
    try {
      if (_playingUrl == url) {
        if (_isPlaying) {
          await _player.pause();
        } else {
          await _player.resume();
        }
        return;
      }
      await _player.stop();
      _pos.value = Duration.zero;
      _dur.value = Duration.zero;
      setState(() => _playingUrl = url);
      await _player.play(UrlSource(url));
    } catch (caught, trace) {
      AppLog.e('chat_thread_screen._togglePlay', caught, trace);
      if (!mounted) return;
      setState(() {
        _playingUrl = null;
        _isPlaying = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        backgroundColor: AppColors.danger,
        content: Text(_isEn ? 'Could not play this voice message.' : 'Imeshindwa kucheza ujumbe huu wa sauti.'),
      ));
    }
  }

  /// Stops the voice note completely (back to 0:00), unlike pause which keeps the position.
  Future<void> _stopPlayback() async {
    try {
      await _player.stop();
    } catch (caught, trace) { AppLog.e('chat_thread_screen._stopPlayback', caught, trace); }
    _pos.value = Duration.zero;
    _dur.value = Duration.zero;
    if (!mounted) return;
    setState(() {
      _playingUrl = null;
      _isPlaying = false;
    });
  }

  Future<void> _openFile(String url) async {
    final messenger = ScaffoldMessenger.of(context);
    var ok = false;
    try {
      ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (caught, trace) { AppLog.e('chat_thread_screen._openFile', caught, trace); }
    if (!ok) {
      messenger.showSnackBar(SnackBar(
        backgroundColor: AppColors.danger,
        content: Text(_isEn ? 'Could not open this file.' : 'Imeshindwa kufungua faili hili.'),
      ));
    }
  }

  String _fmtDur(Duration d) {
    final m = d.inMinutes.toString();
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  Widget _blockedBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: AppColors.borderLight)),
      ),
      child: Row(
        children: [
          const Icon(Icons.block_rounded, size: 18, color: AppColors.danger),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              _isEn ? 'You blocked this user. Unblock to send messages.' : 'Umemzuia mtumiaji huyu. Mfungulie ili utume ujumbe.',
              style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
            ),
          ),
          TextButton(
            onPressed: () {
              final id = _otherId;
              if (id != null) BlockUserDialog.confirmUnblock(context, userId: id, name: widget.otherName);
            },
            child: Text(_isEn ? 'Unblock' : 'Fungulia', style: const TextStyle(fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      // Back closes the search first instead of leaving the chat.
      canPop: !_searching,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && _searching) _closeSearch();
      },
      child: _scaffold(context),
    );
  }

  Widget _scaffold(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        titleSpacing: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18, color: AppColors.textPrimary),
          onPressed: _searching ? _closeSearch : () => Navigator.pop(context),
        ),
        title: _searching ? _searchField() : Row(
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                CircleAvatar(
                  radius: 17,
                  backgroundColor: AppColors.primaryLight,
                  child: Text(
                    widget.otherName.isNotEmpty ? widget.otherName.substring(0, 1).toUpperCase() : '?',
                    style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.primary),
                  ),
                ),
                Positioned(right: -1, bottom: -1, child: OnlineDot(online: widget.isOnline, size: 12)),
              ],
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          widget.otherName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                        ),
                      ),
                      if (_isMuted)
                        const Padding(
                          padding: EdgeInsets.only(left: 6),
                          child: Icon(Icons.notifications_off_outlined, size: 15, color: AppColors.textMuted),
                        ),
                    ],
                  ),
                  if (widget.isOnline)
                    Text(
                      AppStrings.chatsOnline,
                      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.onlineGreen),
                    ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          if (_searching) ...[
            if (_query.isNotEmpty)
              IconButton(
                tooltip: _isEn ? 'Clear' : 'Futa',
                icon: const Icon(Icons.close_rounded, color: AppColors.textSecondary),
                onPressed: () {
                  _searchCtl.clear();
                  setState(() => _query = '');
                },
              ),
          ] else if (_otherId != null && _otherId != 0) ...[
            IconButton(
              tooltip: _isEn ? 'Call' : 'Piga simu',
              icon: const Icon(Icons.call_outlined, color: AppColors.textPrimary),
              onPressed: _isBlocked ? null : _showCallOptions,
            ),
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_vert_rounded, color: AppColors.textPrimary),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              onSelected: (v) {
                final id = _otherId!;
                switch (v) {
                  case 'profile':
                    _viewProfile();
                  case 'search':
                    _openSearch();
                  case 'mute':
                    _toggleMute();
                  case 'clear':
                    _clearChat();
                  case 'report':
                    ReportSheet.show(context, target: ReportTarget.user, userId: id, name: widget.otherName).then((out) {
                      if (out.blocked && mounted) Navigator.pop(context);
                    });
                  case 'block':
                    BlockUserDialog.confirmBlock(context, userId: id, name: widget.otherName);
                  default:
                    BlockUserDialog.confirmUnblock(context, userId: id, name: widget.otherName);
                }
              },
              itemBuilder: (_) => [
                _menuItem('profile', Icons.person_outline_rounded, _isEn ? 'View profile' : 'Tazama wasifu'),
                _menuItem('search', Icons.search_rounded, _isEn ? 'Search' : 'Tafuta'),
                _menuItem(
                  'mute',
                  _isMuted ? Icons.notifications_active_outlined : Icons.notifications_off_outlined,
                  _isMuted
                      ? (_isEn ? 'Unmute notifications' : 'Washa arifa')
                      : (_isEn ? 'Mute notifications' : 'Nyamazisha arifa'),
                ),
                _menuItem('clear', Icons.delete_sweep_outlined, _isEn ? 'Clear chat' : 'Futa mazungumzo'),
                const PopupMenuDivider(),
                _menuItem(
                  _isBlocked ? 'unblock' : 'block',
                  _isBlocked ? Icons.lock_open_rounded : Icons.block_rounded,
                  _isBlocked ? (_isEn ? 'Unblock user' : 'Mfungulie mtumiaji') : (_isEn ? 'Block user' : 'Mzuie mtumiaji'),
                  color: _isBlocked ? AppColors.primary : AppColors.danger,
                ),
                _menuItem('report', Icons.flag_outlined, _isEn ? 'Report user' : 'Ripoti mtumiaji'),
              ],
            ),
          ],
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.border, height: 1),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            if (_profileLoading)
              const LinearProgressIndicator(minHeight: 2, color: AppColors.primary, backgroundColor: AppColors.borderLight),
            if (_offline)
              Container(
                width: double.infinity,
                color: const Color(0xFFFFF3CD),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                child: Row(
                  children: [
                    const SizedBox(
                      width: 12,
                      height: 12,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF8A6D00)),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        _isEn
                            ? 'Waiting for network... messages will send when you are back online.'
                            : 'Inasubiri mtandao... ujumbe utatumwa mtandao ukirudi.',
                        style: const TextStyle(fontSize: 12, color: Color(0xFF8A6D00)),
                      ),
                    ),
                  ],
                ),
              ),
            Expanded(
              child: Stack(
                children: [
                  Positioned.fill(child: _messageArea()),
                  _jumpButton(),
                ],
              ),
            ),
            if (_searching)
              const SizedBox.shrink()
            else if (_isBlocked)
              _blockedBar()
            else
              _composer(),
          ],
        ),
      ),
    );
  }

  /// The messages (or the search results while searching).
  Widget _messageArea() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator(color: AppColors.primary));
    }
    final visible = _searching ? _messages.where(_matchesQuery).toList() : _messages;
    if (visible.isEmpty) {
      final searchingNothing = _searching && _query.trim().isNotEmpty;
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Text(
            searchingNothing
                ? (_isEn ? 'No messages found.' : 'Hakuna ujumbe uliopatikana.')
                : (_isEn ? 'Say hello to ${widget.otherName} 👋' : 'Mwambie ${widget.otherName} habari 👋'),
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 14, color: AppColors.textSecondary),
          ),
        ),
      );
    }
    return ListView.builder(
      controller: _scroll,
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
      itemCount: visible.length,
      itemBuilder: (_, i) {
        final m = visible[i];
        // a divider where the day changes (messages without a usable time never start one)
        final at = m.at;
        DateTime? prev;
        for (var j = i - 1; j >= 0 && prev == null; j--) {
          prev = visible[j].at;
        }
        final newDay = at != null && (prev == null || !_sameDay(prev, at));
        if (!newDay) return _bubble(m);
        return Column(children: [_dayDivider(at), _bubble(m)]);
      },
    );
  }

  Widget _searchField() {
    return TextField(
      controller: _searchCtl,
      focusNode: _searchFocus,
      textInputAction: TextInputAction.search,
      onChanged: (v) => setState(() => _query = v),
      decoration: InputDecoration(
        hintText: _isEn ? 'Search messages...' : 'Tafuta ujumbe...',
        hintStyle: const TextStyle(fontSize: 14, color: AppColors.textMuted),
        border: InputBorder.none,
      ),
      style: const TextStyle(fontSize: 15, color: AppColors.textPrimary),
    );
  }

  PopupMenuItem<String> _menuItem(String value, IconData icon, String label, {Color? color}) {
    final c = color ?? AppColors.textPrimary;
    return PopupMenuItem<String>(
      value: value,
      child: Row(
        children: [
          Icon(icon, size: 18, color: color ?? AppColors.textSecondary),
          const SizedBox(width: 10),
          Text(label, style: TextStyle(fontWeight: FontWeight.w600, color: c)),
        ],
      ),
    );
  }

  /// A text message; while searching, the matching words are highlighted.
  Widget _messageText(_Msg m) {
    final style = TextStyle(fontSize: 14, color: m.isMe ? Colors.white : AppColors.textPrimary);
    final q = _query.trim().toLowerCase();
    final lower = m.text.toLowerCase();
    if (!_searching || q.isEmpty || lower.length != m.text.length) return Text(m.text, style: style);
    final spans = <TextSpan>[];
    var i = 0;
    while (true) {
      final at = lower.indexOf(q, i);
      if (at < 0) {
        if (i < m.text.length) spans.add(TextSpan(text: m.text.substring(i)));
        break;
      }
      if (at > i) spans.add(TextSpan(text: m.text.substring(i, at)));
      spans.add(TextSpan(
        text: m.text.substring(at, at + q.length),
        style: TextStyle(backgroundColor: Colors.yellow.shade300, color: Colors.black, fontWeight: FontWeight.w700),
      ));
      i = at + q.length;
    }
    return Text.rich(TextSpan(style: style, children: spans));
  }

  Widget _roundButton({required IconData icon, required VoidCallback? onTap, Color color = AppColors.primary}) {
    return Material(
      color: color,
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(11),
          child: Icon(icon, color: Colors.white, size: 20),
        ),
      ),
    );
  }

  Widget _composer() {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: AppColors.borderLight)),
      ),
      child: _recording
          ? _recordingBar()
          : Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (_replyingTo != null || _editing != null) _contextBar(),
                _inputRow(),
              ],
            ),
    );
  }

  /// Bar above the text box while replying to, or editing, a message.
  Widget _contextBar() {
    final editing = _editing != null;
    final m = (editing ? _editing : _replyingTo)!;
    final title = editing
        ? (_isEn ? 'Edit message' : 'Hariri ujumbe')
        : (_isEn
            ? 'Replying to ${m.isMe ? 'yourself' : widget.otherName}'
            : 'Unamjibu ${m.isMe ? 'mwenyewe' : widget.otherName}');
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.fromLTRB(10, 6, 2, 6),
      decoration: BoxDecoration(
        color: AppColors.background,
        borderRadius: BorderRadius.circular(10),
        border: const Border(left: BorderSide(color: AppColors.primary, width: 3)),
      ),
      child: Row(
        children: [
          Icon(editing ? Icons.edit_outlined : Icons.reply_rounded, size: 18, color: AppColors.primary),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.primary)),
                Text(_labelOf(m), maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
              ],
            ),
          ),
          IconButton(
            visualDensity: VisualDensity.compact,
            tooltip: _isEn ? 'Cancel' : 'Ghairi',
            icon: const Icon(Icons.close_rounded, size: 18, color: AppColors.textMuted),
            onPressed: () {
              if (editing) {
                _cancelEdit();
              } else {
                setState(() => _replyingTo = null);
              }
            },
          ),
        ],
      ),
    );
  }

  Widget _inputRow() {
    return Row(
      children: [
        IconButton(
          tooltip: _isEn ? 'Attach' : 'Ambatisha',
          onPressed: (_sending || _editing != null) ? null : _showAttachMenu,
          icon: const Icon(Icons.attach_file_rounded, color: AppColors.primary),
        ),
        Expanded(
          child: TextField(
            key: _fieldKey,
            controller: _input,
            focusNode: _inputFocus,
            minLines: 1,
            maxLines: 4,
            textInputAction: TextInputAction.send,
            onSubmitted: (_) => _send(),
            decoration: InputDecoration(
              hintText: _isEn ? 'Type a message...' : 'Andika ujumbe...',
              hintStyle: const TextStyle(fontSize: 13, color: AppColors.textMuted),
              filled: true,
              fillColor: AppColors.background,
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(22),
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        // Empty box: microphone (tap to record). With text: send.
        ValueListenableBuilder<TextEditingValue>(
          valueListenable: _input,
          builder: (_, value, _) {
            final hasText = value.text.trim().isNotEmpty;
            final editing = _editing != null;
            return Tooltip(
              message: hasText
                  ? (editing ? (_isEn ? 'Save' : 'Hifadhi') : (_isEn ? 'Send' : 'Tuma'))
                  : (editing ? (_isEn ? 'Cancel' : 'Ghairi') : (_isEn ? 'Record voice message' : 'Rekodi ujumbe wa sauti')),
              child: _roundButton(
                icon: hasText
                    ? (editing ? Icons.check_rounded : Icons.send_rounded)
                    : (editing ? Icons.close_rounded : Icons.mic_rounded),
                onTap: hasText ? _send : (editing ? _cancelEdit : (_sending ? null : _startRecording)),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _recordingBar() {
    return Row(
      children: [
        IconButton(
          tooltip: _isEn ? 'Cancel' : 'Ghairi',
          onPressed: _cancelRecording,
          icon: const Icon(Icons.delete_outline_rounded, color: AppColors.danger),
        ),
        const SizedBox(width: 4),
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(
            color: _recSeconds.isEven ? AppColors.danger : AppColors.danger.withValues(alpha: 0.35),
            shape: BoxShape.circle,
          ),
        ),
        const SizedBox(width: 10),
        Text(
          _fmtDur(Duration(seconds: _recSeconds)),
          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            _isEn ? 'Recording...' : 'Inarekodi...',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
          ),
        ),
        _roundButton(icon: Icons.send_rounded, onTap: _finishRecording),
      ],
    );
  }

  /// Our own call-room link inside a message, if any.
  String? _callLink(String text) {
    final m = RegExp(r'https://meet\.jit\.si/[^\s]+').firstMatch(text);
    return m?.group(0);
  }

  /// Delivery state of my message: clock = sending, one tick = sent, two ticks = delivered,
  /// two bright ticks = read.
  Widget _tick(_Msg m) {
    if (m.failed) return const Icon(Icons.error_outline_rounded, size: 14, color: Color(0xFFFFB4B4));
    if (m.pending) return const Icon(Icons.access_time_rounded, size: 12, color: Colors.white70);
    switch (m.status) {
      case 'read':
        return const Icon(Icons.done_all_rounded, size: 14, color: Color(0xFF8EE6FF));
      case 'delivered':
        return const Icon(Icons.done_all_rounded, size: 14, color: Colors.white70);
      default:
        return const Icon(Icons.done_rounded, size: 14, color: Colors.white70);
    }
  }

  static const _monthsEn = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  static const _monthsSw = ['Jan', 'Feb', 'Mac', 'Apr', 'Mei', 'Jun', 'Jul', 'Ago', 'Sep', 'Okt', 'Nov', 'Des'];

  static bool _sameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

  /// "Today", "Yesterday", or the full date.
  String _dayLabel(DateTime d) {
    final now = DateTime.now();
    if (_sameDay(d, now)) return _isEn ? 'Today' : 'Leo';
    if (_sameDay(d, now.subtract(const Duration(days: 1)))) return _isEn ? 'Yesterday' : 'Jana';
    final month = (_isEn ? _monthsEn : _monthsSw)[d.month - 1];
    return '${d.day} $month ${d.year}';
  }

  Widget _dayDivider(DateTime d) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.black.withValues(alpha: 0.06),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(
            _dayLabel(d),
            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.textSecondary),
          ),
        ),
      ),
    );
  }

  /// Quoted message at the top of a reply bubble.
  Widget _replyQuote(_Msg m) {
    final r = m.replyTo!;
    final who = r.isMe ? (_isEn ? 'You' : 'Wewe') : widget.otherName;
    final label = r.deleted ? (_isEn ? 'Message deleted' : 'Ujumbe umefutwa') : r.text;
    final fg = m.isMe ? Colors.white : AppColors.textPrimary;
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.fromLTRB(8, 4, 8, 4),
      decoration: BoxDecoration(
        color: m.isMe ? Colors.white.withValues(alpha: 0.18) : AppColors.background,
        borderRadius: BorderRadius.circular(8),
        border: Border(left: BorderSide(color: m.isMe ? Colors.white : AppColors.primary, width: 3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(who, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: m.isMe ? Colors.white : AppColors.primary)),
          Text(label, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 12, fontStyle: r.deleted ? FontStyle.italic : FontStyle.normal, color: fg.withValues(alpha: 0.85))),
        ],
      ),
    );
  }

  Widget _bubble(_Msg m) {
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: m.failed ? () => _retryMessage(m) : null,
      onLongPress: () => m.failed ? _showFailedMenu(m) : _showMessageMenu(m),
      // swipe right = reply
      onHorizontalDragEnd: (d) {
        if ((d.primaryVelocity ?? 0) > 300) _startReply(m);
      },
      child: Opacity(opacity: m.flying ? 0 : 1, child: _bubbleBody(m)),
    );
  }

  Widget _bubbleBody(_Msg m) {
    return Align(
      alignment: m.isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        key: m.flyKey,
        margin: const EdgeInsets.symmetric(vertical: 3),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
        decoration: BoxDecoration(
          color: m.isMe ? AppColors.primary : Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(14),
            topRight: const Radius.circular(14),
            bottomLeft: Radius.circular(m.isMe ? 14 : 3),
            bottomRight: Radius.circular(m.isMe ? 3 : 14),
          ),
          border: m.isMe ? null : Border.all(color: AppColors.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            if (m.replyTo != null) _replyQuote(m),
            if (m.uploading != null)
              _uploadingPlaceholder(m)
            else if (m.audioUrl != null)
              _voiceBubble(m)
            else if (m.fileUrl != null)
              _fileBubble(m)
            else if (m.imageUrl != null)
              GestureDetector(
                onTap: () {
                  final all = [for (final x in _messages) if (x.imageUrl != null) x.imageUrl!];
                  final at = all.indexOf(m.imageUrl!);
                  FullscreenImageViewer.open(context, images: all, initialIndex: at < 0 ? 0 : at);
                },
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: AppImage(
                    m.imageUrl!,
                    width: 220,
                    height: 160,
                    fit: BoxFit.cover,
                    errorBuilder: (_, _, _) => Container(
                      width: 220,
                      height: 120,
                      alignment: Alignment.center,
                      color: Colors.black12,
                      child: const Icon(Icons.broken_image_outlined, color: AppColors.textMuted),
                    ),
                  ),
                ),
              ),
            if (m.text.isNotEmpty)
              Padding(
                padding: EdgeInsets.only(top: m.imageUrl != null ? 6 : 0),
                child: _messageText(m),
              ),
            if (_callLink(m.text) != null) ...[
              const SizedBox(height: 8),
              SizedBox(
                height: 34,
                child: ElevatedButton.icon(
                  onPressed: () => CallService.joinCall(context, _callLink(m.text)!),
                  icon: const Icon(Icons.call_rounded, size: 16),
                  label: Text(_isEn ? 'Join call' : 'Jiunge na simu'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: m.isMe ? Colors.white : AppColors.success,
                    foregroundColor: m.isMe ? AppColors.primary : Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                ),
              ),
            ],
            const SizedBox(height: 2),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  m.failed
                      ? (_isEn ? 'Not sent · tap to retry' : 'Haijatumwa · gusa kujaribu')
                      : m.pending ? '' : (m.edited ? '${_isEn ? 'edited' : 'imehaririwa'} · ${m.time}' : m.time),
                  style: TextStyle(fontSize: 10, color: m.isMe ? Colors.white70 : AppColors.textMuted),
                ),
                if (m.isMe) ...[
                  const SizedBox(width: 3),
                  _tick(m),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  /// Round progress ring: spins until the first bytes are sent, then fills up with the percentage inside.
  Widget _progressRing(_Msg m, {double size = 48, Color ring = Colors.white, Color? track, Color? fill}) {
    final notifier = m.progress;
    return ValueListenableBuilder<double>(
      valueListenable: notifier ?? ValueNotifier<double>(0),
      builder: (_, p, _) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(color: fill ?? Colors.black54, shape: BoxShape.circle),
        child: Stack(
          alignment: Alignment.center,
          children: [
            SizedBox(
              width: size - 8,
              height: size - 8,
              child: CircularProgressIndicator(
                value: p > 0 ? p : null,
                strokeWidth: 3,
                color: ring,
                backgroundColor: track ?? Colors.white24,
              ),
            ),
            if (p > 0)
              Text('${(p * 100).round()}%',
                  style: TextStyle(fontSize: size * 0.24, fontWeight: FontWeight.w700, color: ring))
            else
              Icon(Icons.arrow_upward_rounded, size: size * 0.4, color: ring),
          ],
        ),
      ),
    );
  }

  Widget _uploadingPlaceholder(_Msg m) {
    if (m.uploading == ChatAttachmentKind.image) {
      final path = m.localPath;
      return ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: SizedBox(
          width: 220,
          height: 160,
          child: Stack(
            fit: StackFit.expand,
            alignment: Alignment.center,
            children: [
              if (path != null)
                Image.file(File(path), fit: BoxFit.cover, errorBuilder: (_, _, _) => Container(color: Colors.black12))
              else
                Container(color: Colors.black12),
              Container(color: Colors.black26),
              Center(
                child: m.failed
                    ? const Icon(Icons.refresh_rounded, color: Colors.white, size: 34)
                    : _progressRing(m),
              ),
            ],
          ),
        ),
      );
    }
    final fg = m.isMe ? Colors.white : AppColors.textPrimary;
    final isAudio = m.uploading == ChatAttachmentKind.audio;
    final label = isAudio
        ? (_isEn ? 'Voice message' : 'Ujumbe wa sauti')
        : (m.fileName ?? (_isEn ? 'File' : 'Faili'));
    final sub = isAudio
        ? '${(m.audioSeconds ?? 0) ~/ 60}:${((m.audioSeconds ?? 0) % 60).toString().padLeft(2, '0')}'
        : (_isEn ? 'Sending...' : 'Inatuma...');
    final sub2 = m.failed ? (_isEn ? 'Not sent · tap to retry' : 'Haijatumwa · gusa kujaribu') : sub;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (m.failed)
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: m.isMe ? Colors.white.withValues(alpha: 0.18) : AppColors.background,
            ),
            child: Icon(Icons.refresh_rounded, color: m.isMe ? Colors.white : AppColors.primary, size: 24),
          )
        else
        _progressRing(m, size: 40, ring: m.isMe ? Colors.white : AppColors.primary,
            track: m.isMe ? Colors.white24 : AppColors.borderLight,
            fill: m.isMe ? Colors.white.withValues(alpha: 0.18) : AppColors.background),
        const SizedBox(width: 10),
        Flexible(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: fg)),
              Text(sub2, style: TextStyle(fontSize: 11, color: fg.withValues(alpha: 0.75))),
            ],
          ),
        ),
      ],
    );
  }

  Widget _voiceBubble(_Msg m) {
    final url = m.audioUrl!;
    final fg = m.isMe ? Colors.white : AppColors.primary;
    final active = _playingUrl == url;
    final playing = active && _isPlaying;
    final known = Duration(seconds: m.audioSeconds ?? 0);

    return SizedBox(
      width: 210,
      child: Row(
        children: [
          InkWell(
            customBorder: const CircleBorder(),
            onTap: () => _togglePlay(url),
            child: Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: m.isMe ? Colors.white24 : AppColors.primaryLight,
              ),
              child: Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded, color: fg, size: 24),
            ),
          ),
          if (active)
            Tooltip(
              message: _isEn ? 'Stop' : 'Simamisha',
              child: InkWell(
                customBorder: const CircleBorder(),
                onTap: _stopPlayback,
                child: Padding(
                  padding: const EdgeInsets.only(left: 4),
                  child: Icon(Icons.stop_circle_outlined, color: fg, size: 24),
                ),
              ),
            ),
          const SizedBox(width: 6),
          Expanded(
            child: ValueListenableBuilder<Duration>(
              valueListenable: _pos,
              builder: (_, pos, _) => ValueListenableBuilder<Duration>(
                valueListenable: _dur,
                builder: (_, dur, _) {
                  final total = active && dur.inMilliseconds > 0 ? dur : known;
                  final shownPos = active ? pos : Duration.zero;
                  final frac = total.inMilliseconds == 0
                      ? 0.0
                      : (shownPos.inMilliseconds / total.inMilliseconds).clamp(0.0, 1.0).toDouble();
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SliderTheme(
                        data: SliderTheme.of(context).copyWith(
                          trackHeight: 3,
                          thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 5, disabledThumbRadius: 5),
                          overlayShape: SliderComponentShape.noOverlay,
                          activeTrackColor: fg,
                          inactiveTrackColor: fg.withValues(alpha: 0.3),
                          thumbColor: fg,
                          disabledActiveTrackColor: fg,
                          disabledInactiveTrackColor: fg.withValues(alpha: 0.3),
                          disabledThumbColor: fg,
                        ),
                        child: Slider(
                          value: frac,
                          onChanged: active && total.inMilliseconds > 0
                              ? (v) => _player.seek(Duration(milliseconds: (v * total.inMilliseconds).round()))
                              : null,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 6),
                        child: Text(
                          total.inMilliseconds == 0 && !active
                              ? '🎤'
                              : _fmtDur(active ? shownPos : total),
                          style: TextStyle(fontSize: 11, color: m.isMe ? Colors.white70 : AppColors.textSecondary),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  IconData _fileIcon(String ext) {
    switch (ext) {
      case 'pdf':
        return Icons.picture_as_pdf_outlined;
      case 'doc':
      case 'docx':
      case 'odt':
      case 'rtf':
      case 'txt':
        return Icons.description_outlined;
      case 'xls':
      case 'xlsx':
      case 'csv':
      case 'ods':
        return Icons.table_chart_outlined;
      case 'ppt':
      case 'pptx':
        return Icons.slideshow_outlined;
      case 'zip':
        return Icons.folder_zip_outlined;
      default:
        return Icons.insert_drive_file_outlined;
    }
  }

  Widget _fileBubble(_Msg m) {
    final name = m.fileName ?? (_isEn ? 'Document' : 'Faili');
    final dot = name.lastIndexOf('.');
    final ext = dot < 0 ? '' : name.substring(dot + 1).toLowerCase();
    final fg = m.isMe ? Colors.white : AppColors.textPrimary;
    final sub = m.isMe ? Colors.white70 : AppColors.textSecondary;
    return InkWell(
      borderRadius: BorderRadius.circular(10),
      onTap: () => _openFile(m.fileUrl!),
      child: SizedBox(
        width: 220,
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: m.isMe ? Colors.white24 : AppColors.primaryLight,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(_fileIcon(ext), color: m.isMe ? Colors.white : AppColors.primary, size: 22),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: fg),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '${ext.isEmpty ? '' : '${ext.toUpperCase()} • '}${_isEn ? 'Tap to open' : 'Gusa kufungua'}',
                    style: TextStyle(fontSize: 10, color: sub),
                  ),
                ],
              ),
            ),
            Icon(Icons.download_rounded, size: 18, color: sub),
          ],
        ),
      ),
    );
  }
}
