import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/media_picker.dart';
import '../services/session_manager.dart';
import '../widgets/app_ui.dart';
import '../widgets/verification_badge.dart';
import 'nida_verification_screen.dart';

class _BizDoc {
  final String id;
  final String titleEn;
  final String titleSw;
  final String hintEn;
  final String hintSw;
  final IconData icon;
  final bool required;
  const _BizDoc(this.id, this.titleEn, this.titleSw, this.hintEn, this.hintSw, this.icon, {this.required = true});
}

/// Verified Business (providers only). Needs a Green Badge (verified identity) first. Once approved the provider gets the Blue badge. The provider gives the
/// business name and uploads the business papers; the server checks them (owner name must
/// match the verified ID) and sets the status. Customers then see a "Verified Business"
/// chip. Document numbers are never shown.
///
/// Layout: status + progress card, business name, documents card (one row per paper with its
/// own status pill and Upload button), then a preview of the mark customers will see.
class VerifyBusinessScreen extends StatefulWidget {
  const VerifyBusinessScreen({super.key});

  /// Short label for the profile menu, or null when nothing has been sent yet.
  static String? statusLabel(bool en) {
    switch (SessionManager.getVerifiedBusinessStatus()) {
      case 'VERIFIED':
        return en ? 'Verified' : 'Imethibitishwa';
      case 'PENDING':
        return en ? 'In review' : 'Inakaguliwa';
      case 'REJECTED':
        return en ? 'Rejected' : 'Imekataliwa';
      case 'EXPIRED':
        return en ? 'Expired' : 'Imeisha muda';
    }
    return null;
  }

  @override
  State<VerifyBusinessScreen> createState() => _VerifyBusinessScreenState();
}

class _VerifyBusinessScreenState extends State<VerifyBusinessScreen> {
  static const _docs = <_BizDoc>[
    _BizDoc('business_registration', 'Business registration (BRELA)', 'Usajili wa biashara (BRELA)',
        'Optional - certificate showing your business name and owner', 'Hiari - cheti kinachoonyesha jina la biashara na mmiliki',
        Icons.apartment_outlined,
        required: false),
    _BizDoc('tin_certificate', 'TIN certificate', 'Cheti cha TIN',
        'Your tax number certificate', 'Cheti cha namba ya mlipakodi', Icons.receipt_long_outlined),
    _BizDoc('business_license', 'Business licence', 'Leseni ya biashara',
        'A licence that is still valid', 'Leseni ambayo bado ni halali', Icons.business_center_outlined),
    _BizDoc('location_permit', 'Location permit', 'Kibali cha eneo',
        'Optional - for shops, salons and studios', 'Hiari - kwa maduka, saluni na studio', Icons.store_mall_directory_outlined,
        required: false),
  ];

  final _nameCtrl = TextEditingController();
  bool _loading = true;
  bool _saving = false;
  String? _uploading;
  String? _nameError;
  String _status = 'NONE';
  String? _reason;
  DateTime? _expiresAt;
  final Map<String, String> _docStatus = {}; // type -> MISSING | PENDING | APPROVED | REJECTED
  final Map<String, String> _docReason = {}; // type -> reviewer's reason for a rejected paper

  bool get _en => AppStrings.isEnglish;
  bool get _hasBlue => SessionManager.isIdentityVerified();
  bool get _locked => _status == 'VERIFIED' || _status == 'PENDING';
  String _t(String en, String sw) => _en ? en : sw;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final biz = await ApiService.fetchVerifiedBusiness();
    final list = await ApiService.fetchVerificationDocuments();
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (biz != null) {
        _status = biz.status;
        _reason = biz.reason;
        _expiresAt = biz.expiresAt;
        if (_nameCtrl.text.isEmpty && (biz.name ?? '').isNotEmpty) _nameCtrl.text = biz.name!;
      }
      _docStatus.clear();
      _docReason.clear();
      for (final e in list ?? const []) {
        if (e is Map && e['type'] != null) {
          final type = e['type'].toString();
          final s = (e['status'] ?? 'PENDING').toString().toUpperCase();
          _docStatus[type] = (s == 'APPROVED' || s == 'VERIFIED') ? 'APPROVED' : (s == 'REJECTED' ? 'REJECTED' : 'PENDING');
          final why = (e['reason'] ?? '').toString().trim();
          if (why.isNotEmpty && _docStatus[type] == 'REJECTED') _docReason[type] = why;
        }
      }
    });
  }

  void _toast(String msg, {required bool ok}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(backgroundColor: ok ? AppColors.success : AppColors.danger, content: Text(msg)));
  }

  Future<bool> _saveName() async {
    final name = _nameCtrl.text.trim();
    if (name.length < 2) {
      final msg = _t('Enter your business name first.', 'Weka jina la biashara kwanza.');
      setState(() => _nameError = msg);
      _toast(msg, ok: false);
      return false;
    }
    setState(() => _saving = true);
    final err = await ApiService.saveBusinessName(name);
    if (!mounted) return false;
    setState(() => _saving = false);
    if (err != null) {
      _toast(err, ok: false);
      return false;
    }
    return true;
  }

  Future<void> _upload(_BizDoc doc) async {
    if (!_hasBlue) return;
    // The name is saved with the first document so the server can match owner and business.
    if (!await _saveName() || !mounted) return;
    final file = await MediaPicker.pickImage(context, title: _t(doc.titleEn, doc.titleSw));
    if (file == null || !mounted) return;
    setState(() => _uploading = doc.id);
    final res = await ApiService.uploadVerificationDocument(type: doc.id, filePath: file.path);
    if (!mounted) return;
    setState(() => _uploading = null);
    _toast(
      res.ok
          ? _t('Uploaded. We will review it shortly.', 'Imepakiwa. Tutaipitia hivi karibuni.')
          : (res.error ?? _t('Upload failed. Try again.', 'Imeshindwa kupakia. Jaribu tena.')),
      ok: res.ok,
    );
    if (res.ok) _load();
  }

  // ---- labels -------------------------------------------------------------------------------

  /// Pill for the whole business.
  (String, Color) _statusPill(String s) {
    switch (s) {
      case 'VERIFIED':
        return (_t('Verified', 'Imethibitishwa'), AppColors.successDark);
      case 'PENDING':
        return (_t('In review', 'Inakaguliwa'), AppColors.warningDark);
      case 'REJECTED':
        return (_t('Rejected', 'Imekataliwa'), AppColors.danger);
      case 'EXPIRED':
        return (_t('Expired', 'Imeisha muda'), AppColors.danger);
    }
    return (_t('Not verified', 'Haijathibitishwa'), AppColors.textSecondary);
  }

  /// Pill for one paper.
  (String, Color) _docPill(_BizDoc d, String s) {
    switch (s) {
      case 'APPROVED':
        return (_t('Approved', 'Imekubaliwa'), AppColors.successDark);
      case 'PENDING':
        return (_t('Under review', 'Inakaguliwa'), AppColors.warningDark);
      case 'REJECTED':
        return (_t('Rejected', 'Imekataliwa'), AppColors.danger);
    }
    return d.required
        ? (_t('Required', 'Inahitajika'), AppColors.primaryDark)
        : (_t('Optional', 'Hiari'), AppColors.textSecondary);
  }

  // ---- building blocks ----------------------------------------------------------------------

  BoxDecoration get _cardBox => BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      );

  Widget _note(IconData icon, Color color, String text) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.09),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withValues(alpha: 0.3)),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 18, color: color),
            const SizedBox(width: 10),
            Expanded(child: Text(text, style: const TextStyle(fontSize: 12, height: 1.45, color: AppColors.textPrimary))),
          ],
        ),
      );

  Widget _section(String title, [String? sub]) => Padding(
        padding: const EdgeInsets.fromLTRB(2, 18, 2, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
            if (sub != null) ...[
              const SizedBox(height: 2),
              Text(sub, style: const TextStyle(fontSize: 11.8, height: 1.4, color: AppColors.textSecondary)),
            ],
          ],
        ),
      );

  Widget _steps() => Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: _cardBox,
        child: Column(
          children: [
            _step('1', _t('Green Badge: confirm who you are', 'Green Badge: thibitisha wewe ni nani'), true),
            _step('2', _t('Business documents: confirm the business', 'Nyaraka za biashara: thibitisha biashara'), false),
          ],
        ),
      );

  Widget _step(String n, String text, bool active) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            Container(
              width: 22,
              height: 22,
              alignment: Alignment.center,
              decoration: BoxDecoration(shape: BoxShape.circle, color: active ? AppColors.primary : AppColors.borderLight),
              child: Text(n,
                  style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: active ? Colors.white : AppColors.textSecondary)),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(text,
                  style: TextStyle(
                      fontSize: 12.5,
                      fontWeight: active ? FontWeight.w700 : FontWeight.w500,
                      color: active ? AppColors.textPrimary : AppColors.textSecondary)),
            ),
          ],
        ),
      );

  Widget _statusCard() {
    final (pillText, pillColor) = _statusPill(_status);
    final req = _docs.where((d) => d.required).toList();
    final done = req.where((d) => (_docStatus[d.id] ?? 'MISSING') != 'MISSING').length;
    return Container(
      padding: const EdgeInsets.all(14),
      margin: const EdgeInsets.only(bottom: 12),
      decoration: _cardBox,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(color: AppColors.warningLight, borderRadius: BorderRadius.circular(13)),
                child: const Icon(Icons.business_center_rounded, size: 22, color: AppColors.warningDark),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(_t('Show customers your business is real', 'Onyesha wateja biashara yako ni halisi'),
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, height: 1.3, color: AppColors.textPrimary)),
              ),
              const SizedBox(width: 8),
              StatusPill(text: pillText, color: pillColor),
            ],
          ),
          if (_status == 'VERIFIED' && _expiresAt != null) ...[
            const SizedBox(height: 10),
            Text(
              _t('Valid until ${_expiresAt!.day}/${_expiresAt!.month}/${_expiresAt!.year}. Renew before it expires.',
                  'Halali hadi ${_expiresAt!.day}/${_expiresAt!.month}/${_expiresAt!.year}. Sasisha kabla haijaisha.'),
              style: const TextStyle(fontSize: 11.8, height: 1.4, color: AppColors.textSecondary),
            ),
          ],
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(5),
            child: LinearProgressIndicator(
              value: done / req.length,
              minHeight: 8,
              backgroundColor: AppColors.borderLight,
              color: AppColors.primary,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _t('$done of ${req.length} required documents sent', 'Nyaraka $done kati ya ${req.length} zinazohitajika zimetumwa'),
            style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
          ),
        ],
      ),
    );
  }

  Widget _nameCard() {
    final enabled = _hasBlue && !_locked;
    OutlineInputBorder border(Color c, [double w = 1.5]) =>
        OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: c, width: w));
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: _cardBox,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(_t('Business name', 'Jina la biashara'),
              style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
          const SizedBox(height: 6),
          TextField(
            controller: _nameCtrl,
            enabled: enabled,
            textCapitalization: TextCapitalization.words,
            onChanged: (_) => setState(() => _nameError = null),
            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
            decoration: InputDecoration(
              hintText: _t('e.g. Zeen Beauty Studio', 'mf. Zeen Beauty Studio'),
              hintStyle: const TextStyle(fontWeight: FontWeight.w500, color: AppColors.textMuted),
              errorText: _nameError,
              filled: true,
              fillColor: enabled ? Colors.white : AppColors.background,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
              enabledBorder: border(AppColors.border),
              disabledBorder: border(AppColors.border),
              focusedBorder: border(AppColors.primary, 2),
              errorBorder: border(AppColors.danger),
              focusedErrorBorder: border(AppColors.danger, 2),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            _t('The owner name on the papers must match the name on your verified ID.',
                'Jina la mmiliki kwenye nyaraka lazima lilingane na jina kwenye kitambulisho chako kilichothibitishwa.'),
            style: const TextStyle(fontSize: 11, height: 1.35, color: AppColors.textSecondary),
          ),
        ],
      ),
    );
  }

  Widget _docRow(_BizDoc d, {required bool first}) {
    final s = _docStatus[d.id] ?? 'MISSING';
    final (text, color) = _docPill(d, s);
    final busy = _uploading == d.id;
    final reason = _docReason[d.id];
    final canUpload = _hasBlue && !_saving && _uploading == null;

    Widget right;
    if (busy) {
      right = const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2));
    } else if (s == 'MISSING' || s == 'REJECTED') {
      right = SizedBox(
        height: 38,
        child: ElevatedButton(
          onPressed: canUpload ? () => _upload(d) : null,
          style: ElevatedButton.styleFrom(
            elevation: 0,
            backgroundColor: s == 'REJECTED' ? AppColors.danger : AppColors.primary,
            foregroundColor: Colors.white,
            disabledBackgroundColor: AppColors.textDisabled,
            disabledForegroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 14),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
          ),
          child: Text(
            s == 'REJECTED' ? _t('Re-upload', 'Pakia tena') : _t('Upload', 'Pakia'),
            style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800),
          ),
        ),
      );
    } else if (s == 'APPROVED') {
      right = const Icon(Icons.check_circle_rounded, size: 24, color: AppColors.successDark);
    } else {
      right = const Icon(Icons.schedule_rounded, size: 24, color: AppColors.warningDark);
    }

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 13, 14, 13),
      decoration: BoxDecoration(border: first ? null : const Border(top: BorderSide(color: AppColors.borderLight))),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(color: AppColors.primaryLight, borderRadius: BorderRadius.circular(12)),
            child: Icon(d.icon, size: 21, color: AppColors.primary),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_t(d.titleEn, d.titleSw),
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                const SizedBox(height: 2),
                Text(_t(d.hintEn, d.hintSw),
                    style: const TextStyle(fontSize: 11.5, height: 1.4, color: AppColors.textSecondary)),
                if (reason != null) ...[
                  const SizedBox(height: 2),
                  Text(reason, style: const TextStyle(fontSize: 11.5, height: 1.4, fontWeight: FontWeight.w600, color: AppColors.danger)),
                ],
                const SizedBox(height: 7),
                StatusPill(text: text, color: color),
              ],
            ),
          ),
          const SizedBox(width: 10),
          right,
        ],
      ),
    );
  }

  /// What customers will see. Dimmed until the business is verified.
  Widget _preview() {
    final name = _nameCtrl.text.trim().isEmpty ? _t('Your business', 'Biashara yako') : _nameCtrl.text.trim();
    final on = _status == 'VERIFIED';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Opacity(
          opacity: on ? 1 : 0.45,
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: _cardBox,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  radius: 23,
                  backgroundColor: AppColors.primary,
                  child: Text(name.characters.first.toUpperCase(),
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Colors.white)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Text(name,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                          ),
                          const SizedBox(width: 5),
                          const Icon(Icons.verified_rounded, size: 16, color: AppColors.primary),
                        ],
                      ),
                      const SizedBox(height: 6),
                      const VerifiedBusinessChip(),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        if (!on)
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 6, 4, 0),
            child: Text(_t('This mark appears once your business is verified.', 'Alama hii itaonekana biashara yako ikishathibitishwa.'),
                style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        shape: const Border(bottom: BorderSide(color: AppColors.borderLight)),
        title: Text(_t('Verified Business', 'Biashara Iliyothibitishwa'),
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, letterSpacing: -0.3, color: AppColors.textPrimary)),
        iconTheme: const IconThemeData(color: AppColors.textPrimary),
      ),
      bottomNavigationBar: (!_loading && !_hasBlue)
          ? Container(
              padding: EdgeInsets.fromLTRB(14, 10, 14, 10 + MediaQuery.of(context).padding.bottom),
              decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: AppColors.borderLight))),
              child: AppButton.primary(
                label: _t('Verify my identity (Green Badge)', 'Thibitisha utambulisho wangu (Green Badge)'),
                onPressed: () async {
                  await Navigator.push(context, MaterialPageRoute(builder: (_) => const NidaVerificationScreen()));
                  if (mounted) setState(() {});
                },
              ),
            )
          : null,
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 24),
                children: [
                  if (!_hasBlue) ...[
                    _note(
                      Icons.lock_outline_rounded,
                      AppColors.warningDark,
                      _t('You need the Green Badge first. It proves who you are; business documents then prove the business and give you the Blue badge.',
                          'Unahitaji Green Badge kwanza. Inathibitisha wewe ni nani; nyaraka za biashara kisha zinathibitisha biashara na kukupa beji ya Blue.'),
                    ),
                    _steps(),
                  ],
                  _statusCard(),
                  if (_status == 'REJECTED' || _status == 'EXPIRED')
                    _note(
                      Icons.error_outline_rounded,
                      AppColors.danger,
                      (_reason ??
                              (_status == 'EXPIRED'
                                  ? _t('Your business verification has expired.', 'Uthibitisho wa biashara yako umeisha muda.')
                                  : _t('We could not verify your business.', 'Hatukuweza kuthibitisha biashara yako.'))) +
                          _t(' Please upload new documents.', ' Tafadhali pakia nyaraka mpya.'),
                    ),
                  if (_status == 'PENDING')
                    _note(
                      Icons.hourglass_top_rounded,
                      AppColors.warningDark,
                      _t('Your documents are being reviewed.', 'Nyaraka zako zinakaguliwa.'),
                    ),
                  _nameCard(),
                  _section(
                    _t('Business documents', 'Nyaraka za biashara'),
                    _t('TIN and licence are required. BRELA and the location permit are optional.',
                        'TIN na leseni zinahitajika. BRELA na kibali cha eneo ni hiari.'),
                  ),
                  Container(
                    clipBehavior: Clip.antiAlias,
                    decoration: _cardBox,
                    child: Column(
                      children: [
                        for (var i = 0; i < _docs.length; i++) _docRow(_docs[i], first: i == 0),
                      ],
                    ),
                  ),
                  _section(_t('How customers see you', 'Jinsi wateja wanavyokuona')),
                  _preview(),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(2, 16, 2, 4),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Padding(
                          padding: EdgeInsets.only(top: 1),
                          child: Icon(Icons.lock_outline_rounded, size: 16, color: AppColors.textSecondary),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            _t('Document numbers are never shown to customers. Only the mark and your business name.',
                                'Namba za nyaraka hazionyeshwi kwa wateja kamwe. Ni alama na jina la biashara tu.'),
                            style: const TextStyle(fontSize: 11.2, height: 1.45, color: AppColors.textSecondary),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
