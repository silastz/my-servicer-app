import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/ads_config.dart';
import '../models/house_ads.dart';
import '../services/ads_config_service.dart';
import '../services/api_service.dart';
import '../widgets/app_ui.dart';

/// Admin: which ad network (AdMob, Facebook, ironSource) the app uses, page by page, and the ad IDs
/// of each network. Changes reach every phone the next time it starts or comes back to the
/// front (no app update). Ad IDs are not secrets, so they are shown and edited as plain text.
///
/// This screen is only a remote control. The server checks every call (403 for anyone who is
/// not an admin) and stores the settings (docs/ads_config_api_contract.md).
class AdminAdsScreen extends StatefulWidget {
  const AdminAdsScreen({super.key});

  @override
  State<AdminAdsScreen> createState() => _AdminAdsScreenState();
}

class _AdminAdsScreenState extends State<AdminAdsScreen> {
  bool _loading = true;
  bool _forbidden = false;
  bool _loadFailed = false;
  bool _saving = false;

  AdsConfig? _saved;
  bool _enabled = true;
  bool _testMode = true;
  bool _fallback = true;
  AdProvider _default = AdProvider.defaultProvider;
  Map<AdPage, AdPageSetting> _pages = {};

  final Map<String, TextEditingController> _ctl = {};
  final Map<String, String> _errors = {};

  // In-house ads: the JSON the admin pastes and what it parses to (checked on every edit).
  final TextEditingController _houseCtl = TextEditingController();
  HouseParse _house = const HouseParse([], []);

  bool get _isEn => AppStrings.isEnglish;
  String _t(String en, String sw) => _isEn ? en : sw;

  static const _fields = ['appKey', 'banner', 'native', 'rewarded'];

  String _k(AdProvider p, AdPlatform pl, String f) => '${p.name}.${pl.name}.$f';

  List<String> _fieldsOf(AdProvider p) => p == AdProvider.ironsource ? _fields : _fields.sublist(1);

  @override
  void initState() {
    super.initState();
    for (final p in AdProvider.networks) {
      for (final pl in AdPlatform.values) {
        for (final f in _fieldsOf(p)) {
          _ctl[_k(p, pl, f)] = TextEditingController()..addListener(_onEdited);
        }
      }
    }
    _houseCtl.addListener(() {
      if (mounted) setState(() => _house = HouseAds.parseText(_houseCtl.text));
    });
    _load();
  }

  @override
  void dispose() {
    for (final c in _ctl.values) {
      c.dispose();
    }
    _houseCtl.dispose();
    super.dispose();
  }

  void _onEdited() {
    if (mounted) setState(() {});
  }

  String _text(AdProvider p, AdPlatform pl, String f) => _ctl[_k(p, pl, f)]!.text.trim();

  void _fill(AdsConfig c) {
    _enabled = c.enabled;
    _testMode = c.testMode;
    _fallback = c.autoFallback;
    _default = c.defaultProvider;
    _pages = {for (final p in AdPage.values) p: c.page(p)};
    _houseCtl.text = HouseAds.toText(c.house);
    _house = HouseAds.parseText(_houseCtl.text);
    for (final p in AdProvider.networks) {
      for (final pl in AdPlatform.values) {
        final ids = c.idsOf(p, pl);
        for (final f in _fieldsOf(p)) {
          _ctl[_k(p, pl, f)]!.text = f == 'appKey' ? ids.appKey : ids.of(AdFormat.values.firstWhere((x) => x.name == f));
        }
      }
    }
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _loadFailed = false;
    });
    final r = await ApiService.getAdminAdsConfig();
    if (!mounted) return;
    // Before anything was ever saved the server may have nothing: start from the app's defaults.
    setState(() {
      _loading = false;
      _forbidden = r.forbidden;
      _loadFailed = !r.forbidden && r.config == null;
      _saved = r.config;
      if (r.config != null) _fill(r.config!);
    });
  }

  AdsConfig _draft() {
    return AdsConfig(
      enabled: _enabled,
      testMode: _testMode,
      defaultProvider: _default,
      autoFallback: _fallback,
      pages: Map.of(_pages),
      house: _house.ads,
      units: {
        for (final p in AdProvider.networks)
          p: {
            for (final pl in AdPlatform.values)
              pl: AdUnitIds(
                appKey: p == AdProvider.ironsource ? _text(p, pl, 'appKey') : '',
                banner: _text(p, pl, 'banner'),
                native: _text(p, pl, 'native'),
                rewarded: _text(p, pl, 'rewarded'),
              ),
          },
      },
    );
  }

  bool get _changed => _saved != null && !_draft().sameAs(_saved!);

  bool _validate() {
    final e = <String, String>{};
    if (!_house.ok) {
      _snack(_t('Fix the in-house ads JSON first (see the red messages).', 'Rekebisha JSON ya matangazo yako kwanza (angalia ujumbe mwekundu).'));
      return false;
    }
    for (final p in AdProvider.networks) {
      for (final pl in AdPlatform.values) {
        for (final f in _fieldsOf(p)) {
          final v = _text(p, pl, f);
          final ok = f == 'appKey'
              ? AdIdRules.validAppKey(v)
              : AdIdRules.valid(p, AdFormat.values.firstWhere((x) => x.name == f), v);
          if (!ok) e[_k(p, pl, f)] = _shapeHint(p, f);
        }
      }
    }
    setState(() {
      _errors
        ..clear()
        ..addAll(e);
    });
    return e.isEmpty;
  }

  String _shapeHint(AdProvider p, String f) {
    switch (p) {
      case AdProvider.admob:
        return _t('Ad unit ID looks like ca-app-pub-1234567890123456/1234567890 (not the app ID with ~)',
            'Ad unit ID inaonekana kama ca-app-pub-1234567890123456/1234567890 (si app ID yenye ~)');
      case AdProvider.facebook:
        return _t('Placement ID looks like 1234567890123456_1234567890123456', 'Placement ID inaonekana kama 1234567890123456_1234567890123456');
      case AdProvider.ironsource:
        return f == 'native'
            ? _t('Letters, numbers, space, - and _ only', 'Herufi, namba, nafasi, - na _ tu')
            : _t('Letters and numbers only (5 to 40)', 'Herufi na namba tu (5 hadi 40)');
      case AdProvider.inhouse:
      case AdProvider.all:
        return '';
    }
  }

  void _snack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  /// The chosen default network could not show anything on some platform the app runs on.
  String? _defaultProblem(AdsConfig d) {
    if (!d.enabled) return null;
    for (final pl in AdPlatform.values) {
      if (!d.canShow(d.defaultProvider, pl)) return pl == AdPlatform.android ? 'Android' : 'iOS';
    }
    return null;
  }

  Future<void> _save() async {
    if (_saved == null || _saving || !_validate()) return;
    final d = _draft();
    final problem = _defaultProblem(d);
    if (problem != null) {
      final ok = await AppDialog.confirm(
        context,
        icon: Icons.warning_amber_rounded,
        title: _t('${d.defaultProvider.label} has no IDs on $problem', '${d.defaultProvider.label} haina ID kwenye $problem'),
        message: _t(
          'Pages that follow the default will show no ad on $problem${d.autoFallback ? ' unless another network has IDs' : ''}. Save anyway?',
          'Kurasa zinazofuata chaguo-msingi hazitaonyesha tangazo kwenye $problem${d.autoFallback ? ' isipokuwa mtandao mwingine una ID' : ''}. Hifadhi hata hivyo?',
        ),
        confirmLabel: _t('Save', 'Hifadhi'),
      );
      if (!ok || !mounted) return;
    }
    if (!d.testMode && _saved!.testMode) {
      final ok = await AppDialog.confirm(
        context,
        icon: Icons.campaign_rounded,
        title: _t('Switch to real ads?', 'Badilisha kuwa matangazo halisi?'),
        message: _t(
          'Every phone will show real ads. Never tap real ads yourself while testing: it can get the ad account banned.',
          'Kila simu itaonyesha matangazo halisi. Usibonyeze matangazo halisi ukijaribu: akaunti ya matangazo inaweza kufungiwa.',
        ),
        confirmLabel: _t('Go live', 'Anza'),
      );
      if (!ok || !mounted) return;
    }
    setState(() => _saving = true);
    final saved = await ApiService.setAdminAdsConfig(d);
    if (!mounted) return;
    setState(() => _saving = false);
    if (saved == null) {
      final err = ApiService.lastAdminError;
      _snack(err == 'forbidden'
          ? _t('Only an admin can change this.', 'Ni msimamizi pekee anayeweza kubadilisha hili.')
          : err == 'network'
              ? _t('No connection. Nothing was changed.', 'Hakuna mtandao. Hakuna kilichobadilishwa.')
              : _t('Could not save. Nothing was changed.', 'Imeshindwa kuhifadhi. Hakuna kilichobadilishwa.'));
      return;
    }
    setState(() {
      _saved = saved;
      _fill(saved);
    });
    AdsConfigService.apply(saved); // this phone uses it at once
    _snack(_t('Ad settings saved.', 'Mipangilio ya matangazo imehifadhiwa.'));
  }

  // ---------------------------------------------------------------------------
  // UI
  // ---------------------------------------------------------------------------

  Widget _info(String text, {Color color = AppColors.primary, IconData icon = Icons.info_outline_rounded}) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.2)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 12.5, height: 1.4, color: AppColors.textPrimary))),
        ],
      ),
    );
  }

  Widget _heading(String text) => Padding(
        padding: const EdgeInsets.only(top: 20, bottom: 10),
        child: Text(text, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
      );

  Widget _card({required Widget child}) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.fromLTRB(14, 6, 6, 6),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border),
        ),
        child: child,
      );

  Widget _switchRow(String title, String note, bool value, ValueChanged<bool> onChanged) {
    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Expanded(child: Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary))),
            Switch(value: value, onChanged: onChanged),
          ]),
          Padding(
            padding: const EdgeInsets.only(right: 12, bottom: 8),
            child: Text(note, style: const TextStyle(fontSize: 12, height: 1.35, color: AppColors.textSecondary)),
          ),
        ],
      ),
    );
  }

  /// Number of formats of [p] that have an ID (on the platform with fewer).
  bool _setUp(AdsConfig d, AdProvider p) => p == AdProvider.inhouse
      ? d.house.isNotEmpty
      : AdPlatform.values.every((pl) => d.canShow(p, pl));

  /// The one-tap switch at the top: which network the whole app shows ads from, or none.
  /// Choosing a network also sets every page back to "Default", so the whole app follows it.
  Widget _quickSwitch() {
    final custom = _pages.values.any((s) => s.provider != null);
    // null = pages use different networks (set below in "Pages")
    final AdProvider? current = !_enabled || custom ? null : _default;
    Widget chip(String label, bool selected, VoidCallback onTap) => ChoiceChip(
          label: Text(label),
          selected: selected,
          onSelected: (_) => onTap(),
          selectedColor: AppColors.primary.withValues(alpha: 0.15),
        );
    void choose(AdProvider p) => setState(() {
          _enabled = true;
          _default = p;
          _pages = {for (final e in _pages.entries) e.key: e.value.copyWith(clearProvider: true)};
        });
    final note = !_enabled
        ? _t('Ads are OFF everywhere.', 'Matangazo yamezimwa kila mahali.')
        : custom
            ? _t('Pages use different networks (see "Pages" below). Tap a choice to make every page follow it.',
                'Kurasa zinatumia mitandao tofauti (angalia "Kurasa" hapa chini). Bonyeza chaguo ili kurasa zote zilifuate.')
            : _t('Every page shows ads from: ${_default.label}.', 'Kurasa zote zinaonyesha matangazo kutoka: ${_default.label}.');
    return _card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(0, 8, 8, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: [
                for (final p in [AdProvider.all, AdProvider.admob, AdProvider.facebook, AdProvider.ironsource, AdProvider.inhouse])
                  chip(p == AdProvider.all ? _t('All', 'Zote') : p.label, current == p, () => choose(p)),
                chip(_t('Off', 'Zima'), !_enabled, () => setState(() => _enabled = false)),
              ],
            ),
            const SizedBox(height: 8),
            Text(note, style: const TextStyle(fontSize: 12, height: 1.35, color: AppColors.textSecondary)),
          ],
        ),
      ),
    );
  }

  Widget _defaultOption(AdProvider p, AdsConfig d) {
    final selected = p == _default;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => setState(() => _default = p),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: selected ? AppColors.primary : AppColors.border, width: selected ? 1.6 : 1),
          ),
          child: Row(children: [
            Icon(selected ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded,
                color: selected ? AppColors.primary : AppColors.textMuted),
            const SizedBox(width: 12),
            Expanded(child: Text(p.label, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.textPrimary))),
            if (p == _saved!.defaultProvider) StatusPill(text: _t('Active', 'Inatumika'), color: AppColors.success),
            if (p == _saved!.defaultProvider && !_setUp(d, p)) const SizedBox(width: 6),
            if (!_setUp(d, p))
              StatusPill(
                  text: p == AdProvider.inhouse
                      ? _t('No ads added', 'Hakuna matangazo')
                      : p == AdProvider.all
                          ? _t('Nothing set up', 'Hakuna kilichowekwa')
                          : _t('IDs missing', 'ID hazipo'),
                  color: AppColors.warning),
          ]),
        ),
      ),
    );
  }

  Widget _pageRow(AdPage page) {
    final s = _pages[page] ?? const AdPageSetting();
    final value = s.provider?.id ?? 'DEFAULT';
    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Expanded(
              child: Text(_t(page.labelEn, page.labelSw),
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
            ),
            Switch(value: s.enabled, onChanged: (v) => setState(() => _pages[page] = s.copyWith(enabled: v))),
          ]),
          Text(_t(page.noteEn, page.noteSw), style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
          if (s.enabled)
            Padding(
              padding: const EdgeInsets.only(top: 6, right: 8),
              child: DropdownButton<String>(
                isExpanded: true,
                value: value,
                underline: const SizedBox.shrink(),
                items: [
                  DropdownMenuItem(value: 'DEFAULT', child: Text(_t('Default (${_default.label})', 'Chaguo-msingi (${_default.label})'))),
                  for (final p in AdProvider.values) DropdownMenuItem(value: p.id, child: Text(p.label)),
                ],
                onChanged: (v) => setState(() {
                  _pages[page] = v == null || v == 'DEFAULT' ? s.copyWith(clearProvider: true) : s.copyWith(provider: AdProvider.tryParse(v));
                }),
              ),
            )
          else
            Padding(
              padding: const EdgeInsets.only(top: 6, bottom: 4),
              child: Text(_t('No ads on this page', 'Hakuna matangazo kwenye ukurasa huu'),
                  style: const TextStyle(fontSize: 12, color: AppColors.warning)),
            ),
        ],
      ),
    );
  }

  String _fieldLabel(AdProvider p, String f) {
    switch (f) {
      case 'appKey':
        return 'App key';
      case 'banner':
        return p == AdProvider.facebook ? 'Banner placement ID' : 'Banner ad unit ID';
      case 'native':
        return p == AdProvider.facebook
            ? 'Native placement ID'
            : p == AdProvider.ironsource
                ? _t('Native placement name (optional)', 'Jina la placement ya native (hiari)')
                : 'Native ad unit ID';
      default:
        return p == AdProvider.facebook ? 'Rewarded video placement ID' : 'Rewarded ad unit ID';
    }
  }

  Widget _idFields(AdProvider p, AdPlatform pl) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 6, bottom: 8),
          child: Text(pl == AdPlatform.android ? 'Android' : 'iOS',
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textSecondary)),
        ),
        for (final f in _fieldsOf(p))
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: AppTextField(
              controller: _ctl[_k(p, pl, f)]!,
              label: _fieldLabel(p, f),
              hint: _t('Leave blank if not used', 'Acha wazi kama haitumiki'),
              icon: Icons.tag_rounded,
              errorText: _errors[_k(p, pl, f)],
            ),
          ),
      ],
    );
  }

  Widget _providerIds(AdProvider p) {
    final note = switch (p) {
      AdProvider.admob => _t(
          'The AdMob app ID is fixed inside the app (AndroidManifest / Info.plist): changing it needs an app update. Ad unit IDs here change at once. In test mode Google test units are used whatever is typed here.',
          'App ID ya AdMob iko ndani ya app (AndroidManifest / Info.plist): kuibadilisha kunahitaji toleo jipya. Ad unit ID hapa hubadilika mara moja. Katika hali ya majaribio units za majaribio za Google hutumika bila kujali kilichoandikwa hapa.'),
      AdProvider.facebook => _t(
          'Placement IDs from the Meta Monetization Manager. Facebook needs a real placement ID even in test mode.',
          'Placement ID kutoka Meta Monetization Manager. Facebook inahitaji placement ID halisi hata katika hali ya majaribio.'),
      AdProvider.ironsource => _t(
          'App key and ad unit IDs from the LevelPlay dashboard. LevelPlay mixes Meta, AdMob and others as set up there. A new app key needs an app restart on each phone.',
          'App key na ad unit ID kutoka dashboard ya LevelPlay. LevelPlay huchanganya Meta, AdMob na wengine kama ilivyowekwa huko. App key mpya inahitaji kuwasha upya app kwenye kila simu.'),
      AdProvider.inhouse || AdProvider.all => '',
    };
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          tilePadding: const EdgeInsets.symmetric(horizontal: 14),
          childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 8),
          title: Text(p.label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
          expandedCrossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _info(note),
            for (final pl in AdPlatform.values) _idFields(p, pl),
          ],
        ),
      ),
    );
  }

  String _houseSummary(HouseAd a) {
    final formats = [for (final f in AdFormat.values) if (a.formats.contains(f)) f.name].join(' + ');
    final defaults = HouseAds.defaultPages(a.formats);
    final pages = a.pages.length >= defaults.length && a.pages.containsAll(defaults)
        ? _t('all pages', 'kurasa zote')
        : [for (final p in AdPage.values) if (a.pages.contains(p)) p.id].join(', ');
    final countries = a.countries.isEmpty ? _t('all countries', 'nchi zote') : (a.countries.toList()..sort()).join(', ');
    final own = (a.local.keys.toList()..sort()).join(', ');
    String d(DateTime t) => t.toLocal().toIso8601String().substring(0, 10);
    final dates = a.start == null && a.end == null
        ? ''
        : ' · ${a.start != null ? d(a.start!) : '...'} → ${a.end != null ? d(a.end!) : '...'}';
    return '$formats · $pages · $countries'
        '${own.isEmpty ? '' : ' · ${_t('own text', 'maandishi yao')}: $own'}'
        ' · ${_t('weight', 'uzito')} ${a.weight}$dates${a.enabled ? '' : ' · ${_t('OFF', 'IMEZIMWA')}'}';
  }

  Widget _houseSection() {
    final r = _house;
    final empty = _houseCtl.text.trim().isEmpty;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _info(_t(
          'Add your own ads as JSON. Each ad needs id, title, imageUrl and url (both https). formats: banner, native, rewarded (full-screen ad before a provider video, with rewardSeconds). countries: ["TZ","KE"] limits who sees it (none = everyone). Own text per country: title_TZ, body_KE, cta_TZ, imageUrl_KE, url_TZ. They show where "In-house ads" is chosen, and as the last fallback when the networks have no ad.',
          'Weka matangazo yako kama JSON. Kila tangazo linahitaji id, title, imageUrl na url (zote https). formats: banner, native, rewarded (tangazo la skrini nzima kabla ya video, na rewardSeconds). countries: ["TZ","KE"] huamua nani anaona (hakuna = wote). Maandishi kwa kila nchi: title_TZ, body_KE, cta_TZ, imageUrl_KE, url_TZ. Yanaonekana mahali "In-house ads" imechaguliwa, na kama chaguo la mwisho mitandao ikikosa tangazo.',
        )),
        const SizedBox(height: 10),
        TextField(
          controller: _houseCtl,
          minLines: 8,
          maxLines: 16,
          keyboardType: TextInputType.multiline,
          autocorrect: false,
          enableSuggestions: false,
          style: const TextStyle(fontFamily: 'monospace', fontSize: 12, height: 1.35),
          decoration: InputDecoration(
            hintText: '{ "ads": [ ... ] }',
            filled: true,
            fillColor: AppColors.surface,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: r.ok ? AppColors.border : AppColors.danger),
            ),
          ),
        ),
        Row(
          children: [
            TextButton.icon(
              onPressed: empty ? () => _houseCtl.text = HouseAds.example : null,
              icon: const Icon(Icons.data_object_rounded, size: 18),
              label: Text(_t('Insert example', 'Weka mfano')),
            ),
            TextButton.icon(
              onPressed: empty ? null : () => _houseCtl.clear(),
              icon: const Icon(Icons.delete_outline_rounded, size: 18),
              label: Text(_t('Clear', 'Futa')),
            ),
          ],
        ),
        if (empty)
          Text(_t('No in-house ads.', 'Hakuna matangazo yako.'), style: const TextStyle(fontSize: 12, color: AppColors.textSecondary))
        else if (!r.ok)
          _info(
            [
              for (final e in r.errors.take(8)) '• $e',
              if (r.errors.length > 8) _t('...and ${r.errors.length - 8} more.', '...na mengine ${r.errors.length - 8}.'),
            ].join('\n'),
            color: AppColors.danger,
            icon: Icons.error_outline_rounded,
          )
        else ...[
          Text(
            _t('${r.ads.length} ad(s) are valid.', 'Matangazo ${r.ads.length} yako sawa.'),
            style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: AppColors.success),
          ),
          const SizedBox(height: 6),
          for (final a in r.ads)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: SizedBox(
                      width: 44,
                      height: 44,
                      child: Image.network(
                        a.imageUrl,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: AppColors.borderLight,
                          child: const Icon(Icons.broken_image_outlined, size: 20, color: AppColors.textMuted),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(a.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                        Text(_houseSummary(a), style: const TextStyle(fontSize: 11.5, color: AppColors.textSecondary)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
        ],
      ],
    );
  }

  Widget _body() {
    if (_loading) return const Center(child: CircularProgressIndicator(color: AppColors.primary));
    if (_forbidden) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: _info(
            _t('This account is not an admin, so it cannot change ad settings.', 'Akaunti hii si ya msimamizi, kwa hiyo haiwezi kubadilisha mipangilio ya matangazo.'),
            color: AppColors.danger,
            icon: Icons.lock_outline_rounded,
          ),
        ),
      );
    }
    if (_loadFailed || _saved == null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(_t('Could not load the ad settings.', 'Imeshindwa kupakia mipangilio ya matangazo.'),
                textAlign: TextAlign.center, style: const TextStyle(fontSize: 14, color: AppColors.textSecondary)),
            const SizedBox(height: 16),
            AppButton.primary(label: _t('Try again', 'Jaribu tena'), onPressed: _load),
          ]),
        ),
      );
    }
    final d = _draft();
    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _info(_t(
                'Choose which ad network each page uses and edit the ad IDs. Changes reach phones when the app starts or is reopened. If a network has no ID or no ad, the next one is tried (when automatic fallback is on).',
                'Chagua mtandao wa matangazo wa kila ukurasa na ubadilishe ID. Mabadiliko hufika kwenye simu app inapowashwa au kufunguliwa tena. Mtandao ukikosa ID au tangazo, unaofuata hujaribiwa (fallback ikiwa wazi).',
              )),
              _heading(_t('Show ads from', 'Onyesha matangazo kutoka')),
              _quickSwitch(),
              _heading(_t('General', 'Jumla')),
              _switchRow(
                _t('Ads on', 'Matangazo yamewashwa'),
                _enabled ? _t('Ads can show in the app.', 'Matangazo yanaweza kuonekana kwenye app.') : _t('No ads anywhere in the app.', 'Hakuna matangazo popote kwenye app.'),
                _enabled,
                (v) => setState(() => _enabled = v),
              ),
              _switchRow(
                _t('Test mode', 'Hali ya majaribio'),
                _testMode
                    ? _t('Safe test ads: Google sample ads, Facebook test requests. Turn off to go live.', 'Matangazo salama ya majaribio. Zima ili kuanza matangazo halisi.')
                    : _t('LIVE: real ads and real IDs. Do not tap them yourself.', 'HALISI: matangazo na ID halisi. Usiyabonyeze mwenyewe.'),
                _testMode,
                (v) => setState(() => _testMode = v),
              ),
              _switchRow(
                _t('Automatic fallback', 'Fallback kiotomatiki'),
                _fallback
                    ? _t('If a network has no ID or no ad, the default and then the other networks are tried.', 'Mtandao ukikosa ID au tangazo, chaguo-msingi kisha mingine hujaribiwa.')
                    : _t('Only the network chosen for the page is used.', 'Mtandao uliochaguliwa kwa ukurasa pekee ndio hutumika.'),
                _fallback,
                (v) => setState(() => _fallback = v),
              ),
              _heading(_t('Default network', 'Mtandao wa msingi')),
              for (final p in AdProvider.values) _defaultOption(p, d),
              _heading(_t('Pages', 'Kurasa')),
              for (final page in AdPage.values) _pageRow(page),
              _heading(_t('In-house ads (your own JSON)', 'Matangazo yako mwenyewe (JSON)')),
              _houseSection(),
              _heading(_t('Ad IDs', 'ID za matangazo')),
              for (final p in AdProvider.networks) _providerIds(p),
              const SizedBox(height: 8),
            ],
          ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: SizedBox(
              width: double.infinity,
              child: AppButton.primary(label: _t('Save', 'Hifadhi'), loading: _saving, onPressed: _changed ? _save : null),
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _t('Ads', 'Matangazo'),
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: _body(),
    );
  }
}
