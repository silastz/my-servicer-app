import 'package:flutter/material.dart';
import '../widgets/report_sheet.dart';
import 'package:url_launcher/url_launcher.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/faq_content.dart';
import '../services/app_policy.dart';
import '../security/client_security_config.dart';
import '../services/currency_service.dart';
import '../services/app_log.dart';

/// Text in the language the person chose in the app.
String _t(String en, String sw) => AppStrings.isEnglish ? en : sw;

class HelpSupportScreen extends StatelessWidget {
  const HelpSupportScreen({super.key});

  // The admin sets these (GET /api/app/policy -> support). A contact that is not set is hidden, never invented.
  static String? get _supportPhone => AppPolicy.supportPhone;
  static String? get _supportWhatsapp => AppPolicy.supportWhatsapp;
  static String? get _supportEmail => AppPolicy.supportEmail;
  static bool get _hasAnySupport => _supportPhone != null || _supportWhatsapp != null || _supportEmail != null;

  // The admin may publish their own pages (GET /api/app/policy -> legal). Otherwise the pages the server hosts itself
  // are used (LegalController), so the store listing and the app always point at a real page.
  static String get _termsUrl => AppPolicy.termsUrl ?? '${ClientSecurityConfig.origin}/legal/terms';
  static String get _privacyUrl => AppPolicy.privacyUrl ?? '${ClientSecurityConfig.origin}/legal/privacy';

  /// Opens [uri] in another app. Tells the person when nothing on the phone can open it
  /// (no canLaunchUrl pre-check: it wrongly answers "no" on some phones).
  /// Returns whether it opened. With [quiet] a failure shows nothing, so the caller can offer another way.
  Future<bool> _launch(BuildContext context, Uri uri, {LaunchMode mode = LaunchMode.platformDefault, bool quiet = false}) async {
    var ok = false;
    try {
      ok = await launchUrl(uri, mode: mode);
    } catch (e) {
      AppLog.d('Could not open $uri: $e');
      ok = false;
    }
    if (!ok && !quiet && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(_t("Couldn't open this on your phone.", 'Imeshindwa kufungua hili kwenye simu yako.')),
      ));
    }
    return ok;
  }

  Future<void> _makePhoneCall(BuildContext context, String phone) => _launch(context, Uri(scheme: 'tel', path: phone));

  Future<void> _openWhatsApp(BuildContext context, String phone) {
    final text = _t('Hello Ungana Support, I need help.', 'Habari Ungana Support, ninahitaji msaada.');
    return _launch(context, Uri.https('wa.me', '/$phone', {'text': text}), mode: LaunchMode.externalApplication);
  }

  Future<void> _sendEmail(BuildContext context, String email) =>
      _launch(context, Uri(scheme: 'mailto', path: email, queryParameters: {'subject': 'Ungana Customer Support'}));

  @override
  Widget build(BuildContext context) {
    // The policy arrives from the server after the app starts: redraw when it changes so contacts appear at once.
    return ValueListenableBuilder<int>(
      valueListenable: AppPolicy.changed,
      builder: (context, _, __) => _buildScreen(context),
    );
  }

  Widget _buildScreen(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _t('Help & Support', 'Msaada na Usaidizi'),
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // List of Support Options matching Screen 12
            Container(
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                children: [
                  _buildHelpItem(
                    icon: Icons.chat_bubble_outline_rounded,
                    title: _t('FAQs', 'Maswali Yanayoulizwa Mara kwa Mara'),
                    subtitle: _t('Find answers to common questions', 'Pata majibu ya maswali ya kawaida'),
                    onTap: () => _showFaqSheet(context),
                  ),
                  _buildDivider(),
                  if (_hasAnySupport) ...[
                    _buildHelpItem(
                      icon: Icons.headset_mic_outlined,
                      title: _t('Contact Support', 'Wasiliana na Msaada'),
                      subtitle: _t('Reach us directly', 'Wasiliana nasi moja kwa moja'),
                      onTap: () => _showContactOptionsSheet(context),
                    ),
                    _buildDivider(),
                  ],
                  _buildHelpItem(
                    icon: Icons.report_problem_outlined,
                    title: _t('Report a Problem', 'Ripoti Tatizo'),
                    subtitle: _t('Report bugs or suspicious services', 'Ripoti hitilafu au huduma za kutiliwa shaka'),
                    onTap: () => _showReportSheet(context),
                  ),
                  _buildDivider(),
                  _buildHelpItem(
                    icon: Icons.security_rounded,
                    title: _t('Safety Tips', 'Vidokezo vya Usalama'),
                    subtitle: _t('Escrow protection and security guidelines', 'Ulinzi wa Escrow na miongozo ya usalama'),
                    onTap: () => _showSafetyTipsSheet(context),
                  ),
                  _buildDivider(),
                  _buildHelpItem(
                    icon: Icons.description_outlined,
                    title: _t('Terms & Conditions', 'Masharti na Vigezo'),
                    subtitle: _t('Platform rules and policies', 'Kanuni na sera za jukwaa'),
                    onTap: () => _showTermsSheet(context),
                  ),
                  _buildDivider(),
                  _buildHelpItem(
                    icon: Icons.privacy_tip_outlined,
                    title: _t('Privacy Policy', 'Sera ya Faragha'),
                    subtitle: _t('How we protect your data', 'Jinsi tunavyolinda taarifa zako'),
                    onTap: () => _showPrivacySheet(context),
                  ),
                ],
              ),
            ),
            if (_supportPhone != null) ...[
            const SizedBox(height: 24),

            // Call Us Banner Card matching Screen 12
            InkWell(
              onTap: () => _makePhoneCall(context, _supportPhone!),
              borderRadius: BorderRadius.circular(16),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.primaryLight.withValues(alpha: 0.6),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.primary.withValues(alpha: 0.2)),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: const BoxDecoration(
                        color: AppColors.primary,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.phone_rounded, color: Colors.white, size: 20),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _t('Need immediate help?', 'Unahitaji msaada wa haraka?'),
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: AppColors.textSecondary,
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            _t('Call us: ${_supportPhone!}', 'Tupigie: ${_supportPhone!}'),
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w800,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            _t('Tap to call', 'Gusa kupiga'),
                            style: TextStyle(
                              fontSize: 11,
                              color: AppColors.textMuted,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildHelpItem({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: AppColors.borderLight,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: AppColors.primary, size: 20),
      ),
      title: Text(
        title,
        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
      ),
      subtitle: Text(
        subtitle,
        style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
      ),
      trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted, size: 20),
    );
  }

  Widget _buildDivider() {
    return const Divider(height: 1, indent: 64, color: AppColors.borderLight);
  }

  Widget _page(BuildContext context, String title, Widget body) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: SafeArea(child: body),
    );
  }

  void _push(BuildContext context, String title, Widget body) {
    Navigator.of(context).push(MaterialPageRoute(builder: (ctx) => _page(ctx, title, body)));
  }

  void _showContactOptionsSheet(BuildContext context) {
    _push(
      context,
      _t('Contact Ungana Support', 'Wasiliana na Msaada wa Ungana'),
      Builder(builder: (ctx) => SingleChildScrollView(
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
          child: Column(
            children: [
              if (_supportWhatsapp != null) ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: const BoxDecoration(color: Color(0xFF25D366), shape: BoxShape.circle),
                  child: const Icon(Icons.chat_rounded, color: Colors.white, size: 20),
                ),
                title: Text(_t('Chat on WhatsApp', 'Ongea kwenye WhatsApp'), style: TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(_t('Instant answers & chat assistance', 'Majibu ya haraka na msaada wa mazungumzo')),
                onTap: () {
                  _openWhatsApp(ctx, _supportWhatsapp!.replaceFirst('+', ''));
                },
              ),
              if (_supportWhatsapp != null && (_supportEmail != null || _supportPhone != null)) const Divider(height: 1),
              if (_supportEmail != null) ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle),
                  child: const Icon(Icons.email_rounded, color: Colors.white, size: 20),
                ),
                title: Text(_t('Send an Email', 'Tuma Barua Pepe'), style: TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(_supportEmail!),
                onTap: () {
                  _sendEmail(ctx, _supportEmail!);
                },
              ),
              if (_supportEmail != null && _supportPhone != null) const Divider(height: 1),
              if (_supportPhone != null) ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: const BoxDecoration(color: AppColors.onlineGreen, shape: BoxShape.circle),
                  child: const Icon(Icons.phone_rounded, color: Colors.white, size: 20),
                ),
                title: Text(_t('Call Direct Support', 'Piga Simu kwa Msaada'), style: TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(_supportPhone!),
                onTap: () {
                  _makePhoneCall(ctx, _supportPhone!);
                },
              ),
            ],
          ),
        )),
    );
  }

  void _showFaqSheet(BuildContext context) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const _FaqPage()));
  }

  void _showReportSheet(BuildContext context) {
    ReportSheet.show(context, target: ReportTarget.general);
  }

  void _showSafetyTipsSheet(BuildContext context) {
    // Builds one section: a heading followed by its tips.
    String sec(String title, List<String> tips) =>
        '$title\n${tips.map((t) => '• $t').join('\n')}';

    final en = [
      sec('BEFORE YOU BOOK', [
        'Check the badges. Green means our team verified the identity (ID plus a selfie holding the ID). Blue means a Verified Business (business documents approved and still valid). No badge means no identity check, so take extra care.',
        'Read the ratings and reviews. Badges such as Top Rated, Professional and Customer Favorite are earned from real reviews.',
        'Look at how long the provider has been a member and how many jobs they have finished.',
        'Agree the price and the work in the app (use Make an Offer). The price on your booking is the one that counts, not a different number quoted in chat.',
      ]),
      sec('PAY SAFELY', [
        'Pay inside Ungana (Pocket Fund, mobile money or card). When the payment is held, the provider gets the money only after you confirm the job.',
        'Tap Satisfied / Mark Completed only after the work is done and you have checked it. Do not confirm early because someone is rushing you.',
        'Some bookings use direct payment: the money goes to the provider as soon as you pay. Check the payment option before you pay.',
        'A provider can ask for payment outside the app by sending a payment request in the booking, with instructions and a deadline. Ungana holds no money in that case, so there is no escrow protection. Pay exactly as the request says, then tap I have paid and add the reference and a proof photo.',
        'Never pay someone who only asks in chat, by phone or on WhatsApp, with no payment request in the app. Report them.',
        'Unpaid payment requests expire at the deadline and the booking is cancelled automatically. Pay before then.',
        'Refunds for mobile money or card payments come back to your Pocket Fund balance, not to your phone or card. You can withdraw from there.',
        'Never share your OTP codes, PIN or password with anyone, including people who say they work for Ungana.',
      ]),
      sec('DURING THE JOB', [
        'Phone numbers and the exact address unlock only after the provider accepts the booking and payment is in place. Do not share them earlier.',
        'Keep the conversation in the app. Chats and the booking record help us if there is a dispute. Be careful with anyone who wants to move the chat elsewhere.',
        'Tell a family member or friend where you are going and who you are meeting. Meet in daytime or in a public place when you can, and have another person with you for jobs at home.',
        'Live location sharing is optional and works only on an active booking. Your position is kept for about 90 seconds, no history is saved, and it is deleted when you stop sharing or the booking ends.',
        'When you send a request, your phone position is saved as a private safety record for fraud or dispute reports. The provider never sees it.',
        'Take photos before and after the work. They help if you need to report a problem.',
      ]),
      sec('AFTER THE JOB', [
        'Leave an honest review. It helps the next person decide.',
        'If the work was not done or not as agreed, do not confirm completion. Report the problem first.',
      ]),
      sec('PROTECT YOUR PRIVACY', [
        'Your legal name and ID number are never shown publicly. People see your stage name and badge.',
        'Turn on Hide My ID if you do not want providers to see your verified name and photo. They then see your stage name and a Safe badge.',
        'Keep your profile locked so your phone number and social links stay hidden from people who have no accepted booking with you.',
        'Do not send photos of your ID or bank details in chat. Only upload ID documents through the verification screens.',
        'Use Block when someone bothers you. Neither of you can message or book the other, and they are not told. Bookings already in progress continue. You can unblock at any time.',
      ]),
      sec('PROTECT YOUR ACCOUNT', [
        'Turn on App Lock (4-digit PIN, and fingerprint or face if your phone has it) in Settings.',
        'Use a strong password you do not use anywhere else. Change it from Settings if you think someone knows it.',
        'Log out on shared or borrowed phones.',
        'Install the app only from the official store and keep it updated.',
        'The app may refuse to run on rooted phones, with a VPN, or may block screenshots. This is for your protection.',
      ]),
      sec('IF YOU ARE A PROVIDER', [
        'Complete identity verification. Verified providers get more trust and more bookings.',
        'Do not start the job or hand over your work until the payment is confirmed (or held) in the app.',
        'For an offline payment, confirm it only after the money is really in your account. If it did not arrive, tap Payment not received.',
        'Never give out your contact details before the booking is accepted. Never pay anyone outside the app to get jobs, boosts or badges.',
        'Be honest in your service description and prices. Fake profiles and services are removed.',
      ]),
      sec('RED FLAGS', [
        'Asks you to pay outside the app, or to a personal number, with no payment request in the app.',
        'Pushes you to pay or confirm right now.',
        'A price far below the normal rate, or a story that sounds too good to be true.',
        'Asks for your OTP, PIN, password or ID photos.',
        'New profile with no reviews and no badge asking for money upfront.',
        'Rude, threatening or abusive messages.',
      ]),
      sec('IF SOMETHING GOES WRONG', [
        'Do not release or confirm the payment.',
        'Report it: use Report on the service or profile, or Help & Support > Report a Problem. Choose the reason (scam, fake profile, harassment, payment outside the app, and others) and add details. You can send up to 20 reports a day. The person you report is not told.',
        'Block the person if you feel unsafe, and contact Support from the Help screen.',
        'If you are in danger, leave and call your local police or emergency number first.',
      ]),
    ].join('\n\n');

    final sw = [
      sec('KABLA YA KUWEKA ODA', [
        'Angalia beji. Kijani maana yake timu yetu imethibitisha utambulisho (kitambulisho pamoja na selfie ukishika kitambulisho). Blue maana yake Biashara Iliyothibitishwa (nyaraka za biashara zimekubaliwa na bado ni halali). Bila beji maana yake hakuna uthibitisho wa utambulisho, kwa hiyo kuwa mwangalifu zaidi.',
        'Soma ukadiriaji na tathmini. Beji kama Top Rated, Professional na Customer Favorite hupatikana kutokana na tathmini halisi.',
        'Angalia mtoa huduma amekuwa mwanachama kwa muda gani na amekamilisha kazi ngapi.',
        'Kubaliana bei na kazi ndani ya app (tumia Toa Ofa). Bei iliyo kwenye oda yako ndiyo inayohesabika, si namba nyingine iliyotajwa kwenye chat.',
      ]),
      sec('LIPA KWA USALAMA', [
        'Lipa ndani ya Ungana (Pocket Fund, pesa za simu au kadi). Malipo yakishikiliwa, mtoa huduma anapata pesa baada ya wewe kuthibitisha kazi tu.',
        'Bonyeza Nimeridhika / Kamilisha baada ya kazi kuisha na kuikagua tu. Usithibitishe mapema kwa sababu mtu anakuharakisha.',
        'Baadhi ya oda hutumia malipo ya moja kwa moja: pesa huenda kwa mtoa huduma mara tu unapolipa. Angalia chaguo la malipo kabla ya kulipa.',
        'Mtoa huduma anaweza kuomba malipo nje ya app kwa kutuma ombi la malipo kwenye oda, lenye maelekezo na muda wa mwisho. Hapo Ungana haishikilii pesa, kwa hiyo hakuna ulinzi wa escrow. Lipa kama ombi linavyosema, kisha bonyeza Nimelipa na weka namba ya muamala na picha ya uthibitisho.',
        'Usilipe kwa mtu anayeomba kwenye chat, simu au WhatsApp tu bila ombi la malipo ndani ya app. Mripoti.',
        'Maombi ya malipo yasiyolipwa huisha muda wake na oda hufutwa yenyewe. Lipa kabla ya hapo.',
        'Marejesho ya malipo ya pesa za simu au kadi hurudi kwenye salio lako la Pocket Fund, si kwenye simu au kadi yako. Unaweza kutoa pesa kutoka hapo.',
        'Kamwe usimpe mtu yeyote namba yako ya OTP, PIN au nenosiri, hata wanaosema wanafanya kazi Ungana.',
      ]),
      sec('WAKATI WA KAZI', [
        'Namba ya simu na anwani kamili hufunguka tu baada ya mtoa huduma kukubali oda na malipo kuwepo. Usizitoe mapema.',
        'Endelea kuongea ndani ya app. Chat na kumbukumbu ya oda hutusaidia kukiwa na mgogoro. Kuwa mwangalifu na anayetaka kuhamishia mazungumzo kwingine.',
        'Mwambie ndugu au rafiki unakwenda wapi na unakutana na nani. Kutana mchana au sehemu ya wazi inapowezekana, na uwe na mtu mwingine kwa kazi za nyumbani.',
        'Kushiriki eneo la moja kwa moja ni hiari na hufanya kazi kwenye oda inayoendelea tu. Eneo lako huhifadhiwa kwa takriban sekunde 90, hakuna historia inayohifadhiwa, na hufutwa ukiacha kushiriki au oda ikiisha.',
        'Unapotuma ombi, eneo la simu yako huhifadhiwa kama kumbukumbu ya siri ya usalama kwa ripoti za ulaghai au migogoro. Mtoa huduma hawezi kuliona.',
        'Piga picha kabla na baada ya kazi. Zinasaidia ukihitaji kuripoti tatizo.',
      ]),
      sec('BAADA YA KAZI', [
        'Andika tathmini ya kweli. Inamsaidia mtu anayefuata kuamua.',
        'Kama kazi haikufanyika au haikuwa kama mlivyokubaliana, usithibitishe kukamilika. Ripoti tatizo kwanza.',
      ]),
      sec('LINDA FARAGHA YAKO', [
        'Jina lako halali na namba ya kitambulisho havionyeshwi hadharani. Watu wanaona jina lako la kikazi na beji.',
        'Washa Ficha Utambulisho Wangu ikiwa hutaki watoa huduma waone jina na picha yako iliyothibitishwa. Wataona jina lako la kikazi na beji ya Safe.',
        'Weka wasifu wako ukiwa umefungwa ili namba ya simu na mitandao ya kijamii vibaki siri kwa watu wasio na oda iliyokubaliwa nawe.',
        'Usitume picha za kitambulisho au taarifa za benki kwenye chat. Pakia nyaraka za kitambulisho kupitia skrini za uthibitisho tu.',
        'Tumia Zuia mtu akikusumbua. Hamwezi kutumiana ujumbe wala kuwekeana oda, na yeye haambiwi. Oda zinazoendelea tayari zinaendelea. Unaweza kumfungulia wakati wowote.',
      ]),
      sec('LINDA AKAUNTI YAKO', [
        'Washa App Lock (PIN ya tarakimu 4, na alama ya kidole au uso kama simu yako inayo) kwenye Mipangilio.',
        'Tumia nenosiri imara usilolitumia mahali pengine. Libadilishe kutoka Mipangilio ukidhani mtu analijua.',
        'Toka kwenye akaunti (log out) ukitumia simu ya kuazima au ya watu wengi.',
        'Sakinisha app kutoka duka rasmi tu na iweke ikiwa imesasishwa.',
        'App inaweza kukataa kufanya kazi kwenye simu iliyobadilishwa (root), ukitumia VPN, au kuzuia picha za skrini. Hii ni kwa ulinzi wako.',
      ]),
      sec('KAMA WEWE NI MTOA HUDUMA', [
        'Kamilisha uthibitisho wa utambulisho. Watoa huduma waliothibitishwa hupata uaminifu na oda nyingi zaidi.',
        'Usianze kazi wala kukabidhi kazi hadi malipo yathibitishwe (au yashikiliwe) ndani ya app.',
        'Kwa malipo ya nje ya app, yathibitishe tu pesa ikiwa imeingia kweli kwenye akaunti yako. Isipofika, bonyeza Malipo hayajafika.',
        'Usitoe mawasiliano yako kabla oda haijakubaliwa. Usimlipe mtu yeyote nje ya app ili kupata kazi, boost au beji.',
        'Kuwa mkweli kwenye maelezo ya huduma na bei. Wasifu na huduma za uongo huondolewa.',
      ]),
      sec('ISHARA ZA HATARI', [
        'Anakuomba ulipe nje ya app, au kwa namba binafsi, bila ombi la malipo ndani ya app.',
        'Anakusukuma ulipe au uthibitishe sasa hivi.',
        'Bei ya chini sana kuliko kawaida, au hadithi inayosikika nzuri kupita kiasi.',
        'Anaomba OTP, PIN, nenosiri au picha za kitambulisho chako.',
        'Wasifu mpya usio na tathmini wala beji unaoomba pesa mapema.',
        'Ujumbe wa kebehi, vitisho au matusi.',
      ]),
      sec('IKITOKEA TATIZO', [
        'Usiachilie wala kuthibitisha malipo.',
        'Ripoti: tumia Ripoti kwenye huduma au wasifu, au Msaada na Usaidizi > Ripoti Tatizo. Chagua sababu (ulaghai, wasifu wa uongo, unyanyasaji, malipo nje ya app, na nyingine) na ongeza maelezo. Unaweza kutuma ripoti hadi 20 kwa siku. Unayemripoti haambiwi.',
        'Mzuie mtu huyo ukihisi hauko salama, na wasiliana na Msaada kupitia skrini ya Msaada.',
        'Ukiwa hatarini, ondoka na upige simu polisi au namba ya dharura ya eneo lako kwanza.',
      ]),
    ].join('\n\n');

    _showTextContentSheet(
      context: context,
      title: _t('Safety Guidelines & Tips', 'Miongozo na Vidokezo vya Usalama'),
      content: _t(en, sw),
    );
  }

  Future<void> _showTermsSheet(BuildContext context) async {
    // The full page first; the short text below is the fallback when the phone cannot open a browser.
    if (await _launch(context, Uri.parse(_termsUrl), mode: LaunchMode.externalApplication, quiet: true)) return;
    if (!context.mounted) return;

    String sec(String title, List<String> clauses) {
      final body = <String>[];
      for (var i = 0; i < clauses.length; i++) {
        body.add('${i + 1}. ${clauses[i]}');
      }
      return '$title\n${body.join('\n')}';
    }

    final en = [
      'Last updated: [DATE]. By creating an account or using Ungana you agree to these Terms. If you do not agree, please do not use the app.',
      sec('1. ABOUT UNGANA', [
        'Ungana is an online marketplace that helps people find and book local services. Ungana is run by [COMPANY NAME] (we, us).',
        'Providers are independent people or businesses, not employees or agents of Ungana. The service contract is between the buyer and the provider. We do not do the work and we do not guarantee it, but we give tools (escrow, verification, reviews, reports) to make dealings safer.',
      ]),
      sec('2. YOUR ACCOUNT', [
        'You must be 18 or older and give true information. Use only your own phone number and email.',
        'You are responsible for what happens in your account. Keep your password, PIN and one-time codes private and tell us at once if someone else uses your account.',
        'One person, one account. You may not sell, share or transfer your account.',
      ]),
      sec('3. IDENTITY VERIFICATION AND BADGES', [
        'Verification is optional but needed for some features. You must upload only your own genuine documents. Giving false or someone else identity details leads to permanent suspension.',
        'A Green badge means our team approved the identity documents. A Blue badge means the business documents were approved and are still valid. A badge shows that a check was made at that time. It is not a guarantee of the quality or behaviour of the person.',
        'Your legal name, ID number and ID photos are stored privately, opened only by our verification team, and never shown publicly. Other users see your stage name and badge.',
      ]),
      sec('4. BOOKINGS AND PAYMENTS', [
        'The price of a booking is set by the system from the service page, the offer you agreed, or the tasks you chose. Prices are shown in the app currency.',
        'Payments inside the app can be made with Pocket Fund, mobile money or card. When a payment is held in escrow, the money goes to the provider only after the buyer confirms the job (Satisfied / Mark Completed). Some bookings use direct payment, where the money goes to the provider as soon as it is paid. The payment option is shown before you pay.',
        'A provider may ask for payment outside the app through an offline payment request in the booking. In that case Ungana holds no money and escrow does not apply. Such payments are at your own risk. Pay only as stated in the request and keep your proof.',
        'Payment requests that are not paid before the deadline expire and the booking ends automatically.',
        'Contact details and the exact address are shown only after the provider accepts the booking and the payment step is complete.',
        'Do not confirm a job before the work is done. A confirmation releases the money to the provider and you may not be able to reverse it.',
        'Ungana does not take a commission on bookings. Fees that do apply are listed in clause 6.',
      ]),
      sec('5. CANCELLATIONS, REFUNDS AND DISPUTES', [
        'A buyer can cancel before the provider accepts. A provider who rejects a booking returns any held money to the buyer.',
        'Refunds for payments made with mobile money or card are returned to the Pocket Fund balance of the buyer, not to the phone or card. Service charges set in the app may be deducted from a refund and are shown before you confirm.',
        'If there is a problem, report it from the booking or from Help & Support. Our team may look at the booking record, chat messages, payment proof and the safety record saved with the request, and may decide to release or refund held money. Our decision on held money is final inside the app but does not limit your legal rights.',
      ]),
      sec('6. FEES FOR PROVIDERS', [
        'Providers may have to pay a one-time registration fee before posting the first service, and a fee per service after the free limit. Providers may buy boosts to rank a service higher for the chosen days.',
        'When a provider withdraws money from the wallet, a collection fee, a payout charge and tax (VAT) may be deducted. The exact amounts are shown before you confirm.',
        'Withdrawals are paid to the mobile money number you give and may take time to process. A failed withdrawal is returned to your wallet. Check the number carefully: we are not responsible for money sent to a wrong number you entered.',
        'Fees and prices can change. A change applies to later actions and never to a payment already made.',
        'Fees paid for registration, services and boosts are not refundable once the service was given, except where the law requires.',
      ]),
      sec('7. RULES OF CONDUCT', [
        'You may not: cheat, scam or mislead anyone; post a fake profile, service or review; harass, threaten or abuse others; ask for or take payment to avoid the app protection; share contact details to avoid the app; post illegal, violent, hateful or sexual content involving minors; or offer services that are illegal in Tanzania.',
        'Adult-only (18+) services, where allowed, must be marked correctly and are shown only to adults who switched them on.',
        'You may not copy data from the app, attack or test the security of the app or the servers, use bots, or bypass protections such as device checks or screenshot limits.',
        'Reviews must be honest and based on a real booking.',
      ]),
      sec('8. REPORTS, BLOCKING AND ACTION BY US', [
        'You can report users and services and block other users. The person you report is not told and you do not see our internal notes.',
        'If we find or believe that you broke these Terms or the law, we may remove content, hold or cancel bookings, freeze payments linked to fraud, limit features, suspend or close your account. Serious breaches, such as false identity or abusive messages, can lead to immediate and permanent suspension.',
        'We may share information with the police or other authorities when the law requires or to protect people from serious harm.',
      ]),
      sec('9. PRIVACY', [
        'We use your data as explained in the Privacy Policy. Your phone number, WhatsApp, exact address and social links stay private until a booking is accepted, unless you choose to unlock them.',
        'Your last position is used to work out distances. Live location is optional, kept for about 90 seconds and not saved as history. When you send a request, your phone position is saved as a private safety record for fraud and dispute checks.',
      ]),
      sec('10. OUR RESPONSIBILITY', [
        'We work to keep the app available and safe, but we do not promise it will always work without errors or interruptions. Features may change.',
        'To the extent the law allows, Ungana is not responsible for the quality, safety, legality or timing of services given by providers, for what users say or do, for payments made outside the app, or for losses caused by events we cannot control. Nothing in these Terms removes rights you have under the law.',
        'You agree to compensate us for loss caused by your breach of these Terms or by content you post that breaks the law or the rights of others.',
      ]),
      sec('11. CHANGES, CLOSING YOUR ACCOUNT AND LAW', [
        'We may update these Terms. If a change is important we will tell you in the app. If you keep using Ungana after the change, you accept it.',
        'You can stop using Ungana at any time. Bookings in progress and money owed must be settled first.',
        'These Terms follow the laws of [COUNTRY, e.g. the United Republic of Tanzania]. Disputes go to the courts of that country after we have first tried to solve them with you in good faith.',
        'Questions: Help & Support in the app or [CONTACT EMAIL].',
      ]),
    ].join('\n\n');

    final sw = [
      'Imesasishwa: [TAREHE]. Kwa kufungua akaunti au kutumia Ungana unakubali Masharti haya. Kama hukubali, tafadhali usitumie app.',
      sec('1. KUHUSU UNGANA', [
        'Ungana ni soko la mtandaoni linalosaidia watu kupata na kuweka oda za huduma za karibu. Ungana inaendeshwa na [JINA LA KAMPUNI] (sisi).',
        'Watoa huduma ni watu au biashara huru, si wafanyakazi wala mawakala wa Ungana. Mkataba wa huduma ni kati ya mnunuzi na mtoa huduma. Hatufanyi kazi na hatuihakikishi, lakini tunatoa zana (escrow, uthibitisho, tathmini, ripoti) ili kufanya biashara kuwa salama zaidi.',
      ]),
      sec('2. AKAUNTI YAKO', [
        'Lazima uwe na miaka 18 au zaidi na utoe taarifa za kweli. Tumia namba ya simu na barua pepe yako mwenyewe tu.',
        'Unawajibika kwa kinachotokea kwenye akaunti yako. Weka siri nenosiri, PIN na namba za siri za mara moja, na utuambie mara moja mtu mwingine akitumia akaunti yako.',
        'Mtu mmoja, akaunti moja. Huruhusiwi kuuza, kushirikisha au kuhamisha akaunti yako.',
      ]),
      sec('3. UTHIBITISHO WA UTAMBULISHO NA BEJI', [
        'Uthibitisho ni hiari lakini unahitajika kwa baadhi ya huduma. Pakia nyaraka zako halisi tu. Kutoa taarifa za utambulisho za uongo au za mtu mwingine husababisha kufungiwa milele.',
        'Beji ya Kijani inamaanisha timu yetu imekubali nyaraka za utambulisho. Beji ya Blue inamaanisha nyaraka za biashara zimekubaliwa na bado ni halali. Beji inaonyesha ukaguzi ulifanyika wakati huo. Si dhamana ya ubora au tabia ya mtu.',
        'Jina lako halali, namba ya kitambulisho na picha za kitambulisho huhifadhiwa kwa siri, hufunguliwa na timu yetu ya uthibitisho pekee, na havionyeshwi hadharani. Watumiaji wengine wanaona jina lako la kikazi na beji.',
      ]),
      sec('4. ODA NA MALIPO', [
        'Bei ya oda huwekwa na mfumo kutoka kwenye ukurasa wa huduma, ofa mliyokubaliana, au kazi ulizochagua. Bei zinaonyeshwa kwa sarafu ya app.',
        'Malipo ndani ya app yanaweza kufanywa kwa Pocket Fund, pesa za simu au kadi. Malipo yakishikiliwa kwenye escrow, pesa huenda kwa mtoa huduma baada ya mnunuzi kuthibitisha kazi (Nimeridhika / Kamilisha) tu. Baadhi ya oda hutumia malipo ya moja kwa moja, ambapo pesa huenda kwa mtoa huduma mara tu zinapolipwa. Chaguo la malipo huonyeshwa kabla ya kulipa.',
        'Mtoa huduma anaweza kuomba malipo nje ya app kupitia ombi la malipo kwenye oda. Hapo Ungana haishikilii pesa na escrow haitumiki. Malipo hayo ni kwa hatari yako mwenyewe. Lipa kama ombi linavyosema na uhifadhi uthibitisho wako.',
        'Maombi ya malipo yasiyolipwa kabla ya muda wa mwisho huisha na oda hufungwa yenyewe.',
        'Mawasiliano na anwani kamili huonyeshwa tu baada ya mtoa huduma kukubali oda na hatua ya malipo kukamilika.',
        'Usithibitishe kazi kabla haijaisha. Uthibitisho huachilia pesa kwa mtoa huduma na huenda usiweze kuurudisha nyuma.',
        'Ungana haichukui kamisheni kwenye oda. Ada zinazotumika zimeorodheshwa kwenye kifungu cha 6.',
      ]),
      sec('5. KUGHAIRI, MAREJESHO NA MIGOGORO', [
        'Mnunuzi anaweza kughairi kabla mtoa huduma hajakubali. Mtoa huduma akikataa oda, pesa zozote zilizoshikiliwa hurudishwa kwa mnunuzi.',
        'Marejesho ya malipo yaliyofanywa kwa pesa za simu au kadi hurudishwa kwenye salio la Pocket Fund la mnunuzi, si kwenye simu wala kadi. Gharama zilizowekwa kwenye app zinaweza kukatwa kwenye marejesho na huonyeshwa kabla ya kuthibitisha.',
        'Kukiwa na tatizo, liripoti kupitia oda au Msaada na Usaidizi. Timu yetu inaweza kuangalia kumbukumbu ya oda, ujumbe wa chat, uthibitisho wa malipo na kumbukumbu ya usalama iliyohifadhiwa na ombi, na inaweza kuamua kuachilia au kurejesha pesa zilizoshikiliwa. Uamuzi wetu kuhusu pesa zilizoshikiliwa ni wa mwisho ndani ya app lakini haupunguzi haki zako za kisheria.',
      ]),
      sec('6. ADA KWA WATOA HUDUMA', [
        'Watoa huduma wanaweza kulipa ada ya usajili ya mara moja kabla ya kuweka huduma ya kwanza, na ada kwa kila huduma baada ya kikomo cha bure. Watoa huduma wanaweza kununua boost ili huduma ipande juu kwa siku walizochagua.',
        'Mtoa huduma anapotoa pesa kwenye pochi, ada ya ukusanyaji, gharama ya kutuma na kodi (VAT) vinaweza kukatwa. Kiasi kamili huonyeshwa kabla ya kuthibitisha.',
        'Utoaji pesa hulipwa kwa namba ya pesa za simu uliyoitoa na unaweza kuchukua muda kushughulikiwa. Utoaji ukishindikana hurudishwa kwenye pochi yako. Kagua namba kwa makini: hatuwajibiki kwa pesa zilizotumwa kwa namba isiyo sahihi uliyoiingiza.',
        'Ada na bei vinaweza kubadilika. Mabadiliko hutumika kwa vitendo vya baadaye, si malipo yaliyokwisha fanywa.',
        'Ada za usajili, huduma na boost hazirudishwi huduma ikishatolewa, isipokuwa pale sheria inapohitaji.',
      ]),
      sec('7. SHERIA ZA TABIA', [
        'Huruhusiwi: kudanganya, kutapeli au kupotosha mtu; kuweka wasifu, huduma au tathmini ya uongo; kunyanyasa, kutisha au kutukana wengine; kuomba au kupokea malipo ili kukwepa ulinzi wa app; kushirikisha mawasiliano ili kukwepa app; kuweka maudhui haramu, ya vurugu, ya chuki au ya ngono yanayohusu watoto; au kutoa huduma zilizo haramu Tanzania.',
        'Huduma za watu wazima tu (18+), pale zinaporuhusiwa, lazima ziwekewe alama sahihi na huonyeshwa kwa watu wazima waliozishwasha tu.',
        'Huruhusiwi kunakili data ya app, kushambulia au kujaribu usalama wa app au seva, kutumia roboti, au kukwepa ulinzi kama ukaguzi wa kifaa au kikomo cha picha za skrini.',
        'Tathmini lazima ziwe za kweli na zitokane na oda halisi.',
      ]),
      sec('8. RIPOTI, KUZUIA NA HATUA ZETU', [
        'Unaweza kuripoti watumiaji na huduma na kuzuia watumiaji wengine. Unayemripoti haambiwi na wewe huoni maelezo yetu ya ndani.',
        'Tukigundua au kuamini umevunja Masharti haya au sheria, tunaweza kuondoa maudhui, kushikilia au kughairi oda, kuzuia malipo yanayohusiana na ulaghai, kupunguza huduma, kusimamisha au kufunga akaunti yako. Ukiukaji mkubwa, kama utambulisho wa uongo au ujumbe wa matusi, unaweza kusababisha kufungiwa mara moja na milele.',
        'Tunaweza kushirikisha taarifa kwa polisi au mamlaka nyingine pale sheria inapohitaji au kulinda watu dhidi ya madhara makubwa.',
      ]),
      sec('9. FARAGHA', [
        'Tunatumia data yako kama ilivyoelezwa kwenye Sera ya Faragha. Namba yako ya simu, WhatsApp, anwani kamili na mitandao ya kijamii hubaki siri hadi oda ikubaliwe, isipokuwa ukichagua kuvifungua.',
        'Eneo lako la mwisho hutumika kukokotoa umbali. Eneo la moja kwa moja ni hiari, huhifadhiwa kwa takriban sekunde 90 na halihifadhiwi kama historia. Unapotuma ombi, eneo la simu yako huhifadhiwa kama kumbukumbu ya siri ya usalama kwa ukaguzi wa ulaghai na migogoro.',
      ]),
      sec('10. WAJIBU WETU', [
        'Tunajitahidi kuweka app ipatikane na salama, lakini hatuahidi itafanya kazi bila hitilafu au kukatika. Huduma zinaweza kubadilika.',
        'Kadiri sheria inavyoruhusu, Ungana haiwajibiki kwa ubora, usalama, uhalali au muda wa huduma zinazotolewa na watoa huduma, kwa wanachosema au kufanya watumiaji, kwa malipo yaliyofanywa nje ya app, wala kwa hasara zinazosababishwa na matukio nje ya uwezo wetu. Hakuna kitu kwenye Masharti haya kinachoondoa haki ulizonazo kisheria.',
        'Unakubali kutufidia hasara inayosababishwa na ukiukaji wako wa Masharti haya au maudhui uliyoweka yanayovunja sheria au haki za wengine.',
      ]),
      sec('11. MABADILIKO, KUFUNGA AKAUNTI NA SHERIA', [
        'Tunaweza kusasisha Masharti haya. Mabadiliko yakiwa muhimu tutakuambia ndani ya app. Ukiendelea kutumia Ungana baada ya mabadiliko, unayakubali.',
        'Unaweza kuacha kutumia Ungana wakati wowote. Oda zinazoendelea na pesa zinazodaiwa lazima zimalizwe kwanza.',
        'Masharti haya yanafuata sheria za [NCHI, mfano Jamhuri ya Muungano wa Tanzania]. Migogoro huenda mahakama za nchi hiyo baada ya sisi kujaribu kuisuluhisha nawe kwa nia njema kwanza.',
        'Maswali: Msaada na Usaidizi ndani ya app au [BARUA PEPE YA MAWASILIANO].',
      ]),
    ].join('\n\n');

    _showTextContentSheet(
      context: context,
      title: _t('Terms & Conditions', 'Masharti na Vigezo'),
      content: _t(en, sw),
    );
  }

  Future<void> _showPrivacySheet(BuildContext context) async {
    if (await _launch(context, Uri.parse(_privacyUrl), mode: LaunchMode.externalApplication, quiet: true)) return;
    if (!context.mounted) return;

    String sec(String title, List<String> points) =>
        '$title\n${points.map((p) => '• $p').join('\n')}';

    final en = [
      'Last updated: [DATE]. This policy explains what personal data Ungana collects, why, who sees it, and the choices you have. By using Ungana you accept it.',
      sec('1. WHO WE ARE', [
        'Ungana is run by [COMPANY NAME] (we, us). We decide how your data is used. Contact: [CONTACT EMAIL] or Help & Support in the app.',
      ]),
      sec('2. DATA WE COLLECT', [
        'Account: stage name, phone number, email, password (stored only as a one-way hash), profile photo, language and country. Sign-up and reset codes are also stored only as one-way hashes.',
        'Verification (optional): legal name, ID number (NIN), photos of your ID, a selfie, and for businesses the business documents and licence date. These are stored privately.',
        'Bookings and money: requests, offers, prices, status, payment references, proof photos you upload, wallet and withdrawal history, and the mobile money number you give for payouts. We do not store your full card details: card payments are handled by the payment provider.',
        'Messages and content: chats, voice messages, photos and videos you send or post, services you publish, reviews, reports and block list.',
        'Location: your last known position (private, used for distance and search), the position of your phone when you send a booking request (private safety record), and live location only if you choose to share it on an active booking.',
        'Device and usage: device type, app version, language, security checks (such as rooted device or VPN, if the admin turns them on), search terms you use, and the settings you choose. We also record admin actions in an audit log.',
        'Notifications: a push identifier linked to your user id so we can send notifications.',
        'Advertising: ad networks may use the advertising ID of your device (see clause 6).',
      ]),
      sec('3. WHY WE USE IT', [
        'To create and protect your account and sign you in (including sending codes by SMS or email).',
        'To show services near you, match buyers and providers, and run bookings, escrow, wallets, refunds and withdrawals.',
        'To verify identities and businesses, give badges, and prevent fake profiles, scams and abuse.',
        'To handle reports, disputes and safety cases, and to enforce our Terms.',
        'To send notifications about your bookings, messages, offers and, if you allow them, promotions.',
        'To show ads, keep the app secure, fix errors and improve features.',
        'To follow the law and answer legal requests.',
      ]),
      sec('4. WHAT OTHER USERS CAN SEE', [
        'Everyone sees your stage name, profile photo, badge, services, ratings, reviews and, for providers, member-since date, completed jobs and online status.',
        'Your legal name, ID number and ID photos are never public. A provider sees your verified name and photo on a booking only if you have Hide My ID turned off. With Hide My ID on, they see your stage name, photo and a Safe badge.',
        'Your phone number, WhatsApp, exact address and social links stay hidden until the provider accepts the booking and the payment step is done. If your profile is locked, they stay hidden from people with no accepted booking with you.',
        'Your exact position is never shown to others. Live location is shared only with the other person on that booking, only while you share.',
      ]),
      sec('5. WHO WE SHARE DATA WITH', [
        'Service providers that work for us: hosting and servers; SMS and email senders (they receive the phone number or email and the message to deliver a code); payment and mobile money providers (they receive the amount, reference and payment number needed to process a payment); push notification service; and the identity source we use to check the name registered for an ID number.',
        'Ad networks used in the app (see clause 6).',
        'Our verification and support staff, only as needed for their work.',
        'Police, courts or other authorities when the law requires, or to prevent serious harm or fraud.',
        'A new owner, if Ungana is sold or merged, under the same protection.',
        'We do not sell your personal data.',
      ]),
      sec('6. ADS', [
        'Ungana shows ads from Google AdMob, Meta Audience Network and ironSource / Unity LevelPlay, and from our own in-house ads. These companies may collect your advertising ID, IP address, device and ad interaction data to deliver and measure ads and to prevent fraud, under their own privacy policies.',
        'You can reset or turn off the advertising ID and personalised ads in your phone settings.',
        'In-house ads may be shown by country. We do not give ad networks your name, phone number, messages or ID documents.',
      ]),
      sec('7. PERMISSIONS ON YOUR PHONE', [
        'Location: distances, nearby services, safety record and live location. You can refuse or turn it off in phone settings. Some features then work less well.',
        'Camera, microphone, photos and videos: profile photo, verification photos, service media, voice messages and proof of payment. Used only when you choose to use these features.',
        'Notifications: booking, chat and offer alerts.',
        'Fingerprint or face: only to unlock the app (App Lock). We do not receive or store your biometric data. The phone keeps it.',
      ]),
      sec('8. HOW WE PROTECT DATA', [
        'Traffic between the app and our servers is encrypted. ID documents and payment proofs are kept in a private area that only our team and the people on that booking can open. Passwords and codes are stored as hashes. Secrets such as gateway keys are stored encrypted.',
        'The app can block screenshots, rooted phones and VPNs when the admin switches this on, and supports an App Lock PIN.',
        'No system is perfectly safe. Keep your password, PIN and codes private.',
      ]),
      sec('9. HOW LONG WE KEEP DATA', [
        'Live location is kept about 90 seconds and is not saved as history. Search history and promotion logs are deleted automatically after a limited time.',
        'Account data is kept while your account is open. Booking, payment and wallet records may be kept longer where the law, tax rules, fraud prevention or an open dispute require it.',
        'Verification documents are kept while needed to confirm your identity or business and as the law requires.',
      ]),
      sec('10. YOUR CHOICES AND RIGHTS', [
        'You can see and edit your profile, lock your profile, turn Hide My ID on or off, change your password, set App Lock, choose notification settings, block users, and withdraw your wallet balance.',
        'You can ask us for a copy of your data, to correct it, to limit or object to some uses, or to close your account and delete your data. There is no delete button in the app yet: use Help & Support or write to [CONTACT EMAIL]. Withdraw your Pocket Fund balance first. We will answer within a reasonable time. We may keep what the law requires or what is needed for fraud checks and disputes.',
        'You can withdraw consent at any time, for example for location or promotions. This does not affect past use.',
        'If you think your data was misused, tell us first. You also have the right to complain to the data protection authority in your country.',
      ]),
      sec('11. CHILDREN', [
        'Ungana is for people aged 18 and over. We do not knowingly collect data from children. If you think a child has an account, tell us and we will remove it.',
      ]),
      sec('12. OTHER COUNTRIES', [
        'Our providers (for example ad networks, push, SMS and hosting) may handle data on servers outside your country. We ask them to protect it as required by law.',
      ]),
      sec('13. CHANGES TO THIS POLICY', [
        'We may update this policy. For important changes we will tell you in the app. The date at the top shows the latest version.',
      ]),
    ].join('\n\n');

    final sw = [
      'Imesasishwa: [TAREHE]. Sera hii inaeleza Ungana inakusanya taarifa gani binafsi, kwa nini, nani anaziona, na chaguo ulizonazo. Kwa kutumia Ungana unaikubali.',
      sec('1. SISI NI NANI', [
        'Ungana inaendeshwa na [JINA LA KAMPUNI] (sisi). Sisi tunaamua jinsi data yako inavyotumika. Mawasiliano: [BARUA PEPE YA MAWASILIANO] au Msaada na Usaidizi ndani ya app.',
      ]),
      sec('2. DATA TUNAYOKUSANYA', [
        'Akaunti: jina la kikazi, namba ya simu, barua pepe, nenosiri (huhifadhiwa kama alama isiyorudishika tu), picha ya wasifu, lugha na nchi. Namba za siri za kujisajili na kubadilisha nenosiri pia huhifadhiwa kama alama isiyorudishika tu.',
        'Uthibitisho (hiari): jina halali, namba ya kitambulisho (NIN), picha za kitambulisho, selfie, na kwa biashara nyaraka za biashara na tarehe ya leseni. Huhifadhiwa kwa siri.',
        'Oda na pesa: maombi, ofa, bei, hali ya oda, namba za malipo, picha za uthibitisho unazopakia, historia ya pochi na utoaji pesa, na namba ya pesa za simu unayoitoa kwa malipo. Hatuhifadhi taarifa kamili za kadi yako: malipo ya kadi hushughulikiwa na mtoa huduma wa malipo.',
        'Ujumbe na maudhui: chat, ujumbe wa sauti, picha na video unazotuma au kuweka, huduma unazochapisha, tathmini, ripoti na orodha ya uliowazuia.',
        'Eneo: eneo lako la mwisho linalojulikana (siri, hutumika kwa umbali na utafutaji), eneo la simu yako unapotuma ombi la oda (kumbukumbu ya siri ya usalama), na eneo la moja kwa moja ukichagua kulishiriki kwenye oda inayoendelea tu.',
        'Kifaa na matumizi: aina ya kifaa, toleo la app, lugha, ukaguzi wa usalama (kama simu iliyobadilishwa au VPN, admin akiwasha), maneno unayotafuta, na mipangilio uliyochagua. Pia tunarekodi vitendo vya admin kwenye kumbukumbu ya ukaguzi.',
        'Arifa: kitambulisho cha arifa kilichounganishwa na namba yako ya mtumiaji ili tukutumie arifa.',
        'Matangazo: mitandao ya matangazo inaweza kutumia kitambulisho cha matangazo cha kifaa chako (tazama kifungu cha 6).',
      ]),
      sec('3. KWA NINI TUNAITUMIA', [
        'Kufungua na kulinda akaunti yako na kukuingiza (ikiwemo kutuma namba za siri kwa SMS au barua pepe).',
        'Kukuonyesha huduma zilizo karibu nawe, kuwaunganisha wanunuzi na watoa huduma, na kuendesha oda, escrow, pochi, marejesho na utoaji pesa.',
        'Kuthibitisha utambulisho na biashara, kutoa beji, na kuzuia wasifu wa uongo, ulaghai na matusi.',
        'Kushughulikia ripoti, migogoro na masuala ya usalama, na kutekeleza Masharti yetu.',
        'Kukutumia arifa kuhusu oda, ujumbe, ofa zako na, ukiruhusu, matangazo ya promosheni.',
        'Kuonyesha matangazo, kuweka app salama, kurekebisha hitilafu na kuboresha huduma.',
        'Kufuata sheria na kujibu maombi ya kisheria.',
      ]),
      sec('4. WATUMIAJI WENGINE WANAONA NINI', [
        'Kila mtu anaona jina lako la kikazi, picha ya wasifu, beji, huduma, ukadiriaji, tathmini na, kwa watoa huduma, tarehe ya kujiunga, kazi zilizokamilika na hali ya mtandaoni.',
        'Jina lako halali, namba ya kitambulisho na picha za kitambulisho havionyeshwi hadharani kamwe. Mtoa huduma anaona jina na picha yako iliyothibitishwa kwenye oda tu kama Ficha Utambulisho Wangu imezimwa. Ikiwa imewashwa, anaona jina lako la kikazi, picha na beji ya Safe.',
        'Namba yako ya simu, WhatsApp, anwani kamili na mitandao ya kijamii hubaki siri hadi mtoa huduma akubali oda na hatua ya malipo ikamilike. Wasifu ukiwa umefungwa, huvifichwa kwa watu wasio na oda iliyokubaliwa nawe.',
        'Eneo lako kamili halionyeshwi kwa wengine kamwe. Eneo la moja kwa moja hushirikiwa na mtu wa oda hiyo tu, na tu wakati unashiriki.',
      ]),
      sec('5. TUNASHIRIKISHA DATA NA NANI', [
        'Watoa huduma wanaofanya kazi kwa niaba yetu: seva na hosting; watuma SMS na barua pepe (hupokea namba ya simu au barua pepe na ujumbe wa kufikisha namba ya siri); watoa huduma wa malipo na pesa za simu (hupokea kiasi, namba ya muamala na namba ya malipo inayohitajika); huduma ya arifa; na chanzo cha utambulisho tunachotumia kuangalia jina lililosajiliwa kwa namba ya kitambulisho.',
        'Mitandao ya matangazo inayotumika kwenye app (tazama kifungu cha 6).',
        'Wafanyakazi wetu wa uthibitisho na msaada, kwa kadiri ya kazi yao tu.',
        'Polisi, mahakama au mamlaka nyingine sheria inapohitaji, au kuzuia madhara makubwa au ulaghai.',
        'Mmiliki mpya, Ungana ikiuzwa au kuunganishwa, kwa ulinzi huohuo.',
        'Hatuuzi data yako binafsi.',
      ]),
      sec('6. MATANGAZO', [
        'Ungana inaonyesha matangazo kutoka Google AdMob, Meta Audience Network na ironSource / Unity LevelPlay, na matangazo yetu wenyewe. Kampuni hizi zinaweza kukusanya kitambulisho cha matangazo, anwani ya IP, data ya kifaa na mwingiliano na matangazo ili kuyaonyesha, kuyapima na kuzuia ulaghai, kulingana na sera zao za faragha.',
        'Unaweza kuweka upya au kuzima kitambulisho cha matangazo na matangazo ya kibinafsi kwenye mipangilio ya simu yako.',
        'Matangazo yetu wenyewe yanaweza kuonyeshwa kwa nchi. Hatuipi mitandao ya matangazo jina lako, namba ya simu, ujumbe wala nyaraka za kitambulisho.',
      ]),
      sec('7. RUHUSA KWENYE SIMU YAKO', [
        'Eneo: umbali, huduma za karibu, kumbukumbu ya usalama na eneo la moja kwa moja. Unaweza kukataa au kuzima kwenye mipangilio ya simu. Baadhi ya huduma zitafanya kazi kwa ubora mdogo.',
        'Kamera, maikrofoni, picha na video: picha ya wasifu, picha za uthibitisho, maudhui ya huduma, ujumbe wa sauti na uthibitisho wa malipo. Hutumika tu ukichagua kutumia huduma hizi.',
        'Arifa: tahadhari za oda, chat na ofa.',
        'Alama ya kidole au uso: kufungua app (App Lock) tu. Hatupokei wala kuhifadhi data yako ya mwili. Simu ndiyo huihifadhi.',
      ]),
      sec('8. TUNAVYOLINDA DATA', [
        'Mawasiliano kati ya app na seva zetu yamesimbwa. Nyaraka za kitambulisho na uthibitisho wa malipo huhifadhiwa kwenye eneo la siri linaloweza kufunguliwa na timu yetu na watu wa oda husika tu. Nenosiri na namba za siri huhifadhiwa kama alama isiyorudishika. Siri kama funguo za malipo huhifadhiwa zikiwa zimesimbwa.',
        'App inaweza kuzuia picha za skrini, simu zilizobadilishwa na VPN admin akiwasha, na inasaidia PIN ya App Lock.',
        'Hakuna mfumo salama kabisa. Weka siri nenosiri, PIN na namba zako za siri.',
      ]),
      sec('9. TUNAHIFADHI DATA KWA MUDA GANI', [
        'Eneo la moja kwa moja huhifadhiwa takriban sekunde 90 na halihifadhiwi kama historia. Historia ya utafutaji na kumbukumbu za promosheni hufutwa kiotomatiki baada ya muda mfupi.',
        'Data ya akaunti huhifadhiwa wakati akaunti yako ipo wazi. Kumbukumbu za oda, malipo na pochi zinaweza kuhifadhiwa kwa muda mrefu zaidi pale sheria, kodi, kuzuia ulaghai au mgogoro ulio wazi unapohitaji.',
        'Nyaraka za uthibitisho huhifadhiwa kwa muda unaohitajika kuthibitisha utambulisho au biashara yako na kama sheria inavyotaka.',
      ]),
      sec('10. CHAGUO NA HAKI ZAKO', [
        'Unaweza kuona na kuhariri wasifu wako, kufunga wasifu, kuwasha au kuzima Ficha Utambulisho Wangu, kubadilisha nenosiri, kuweka App Lock, kuchagua mipangilio ya arifa, kuzuia watumiaji, na kutoa salio la pochi yako.',
        'Unaweza kutuomba nakala ya data yako, kuirekebisha, kupunguza au kupinga matumizi fulani, au kufunga akaunti yako na kufuta data yako. Bado hakuna kitufe cha kufuta akaunti ndani ya app: tumia Msaada na Usaidizi au andika [BARUA PEPE YA MAWASILIANO]. Toa salio lako la Pocket Fund kwanza. Tutajibu ndani ya muda unaofaa. Tunaweza kuhifadhi kile ambacho sheria inahitaji au kinachohitajika kwa ukaguzi wa ulaghai na migogoro.',
        'Unaweza kuondoa ridhaa wakati wowote, kwa mfano kwa eneo au matangazo ya promosheni. Hii haiathiri matumizi yaliyokwisha fanyika.',
        'Ukidhani data yako imetumiwa vibaya, tuambie kwanza. Pia una haki ya kulalamika kwa mamlaka ya ulinzi wa data ya nchi yako.',
      ]),
      sec('11. WATOTO', [
        'Ungana ni kwa watu wenye miaka 18 na zaidi. Hatukusanyi data ya watoto kwa makusudi. Ukidhani mtoto ana akaunti, tuambie nasi tutaiondoa.',
      ]),
      sec('12. NCHI NYINGINE', [
        'Watoa huduma wetu (kwa mfano mitandao ya matangazo, arifa, SMS na hosting) wanaweza kushughulikia data kwenye seva nje ya nchi yako. Tunawataka wailinde kama sheria inavyotaka.',
      ]),
      sec('13. MABADILIKO YA SERA HII', [
        'Tunaweza kusasisha sera hii. Mabadiliko muhimu tutakuambia ndani ya app. Tarehe ya juu inaonyesha toleo la hivi karibuni.',
      ]),
    ].join('\n\n');

    _showTextContentSheet(
      context: context,
      title: _t('Privacy Policy', 'Sera ya Faragha'),
      content: _t(en, sw),
    );
  }

  /// Draws a legal / help text: UPPERCASE lines are section headings, lines starting with a bullet are
  /// list items, everything else is a paragraph. Keeps the policy text in one plain string.
  Widget _legalBody(String content) {
    const body = TextStyle(fontSize: 14, height: 1.6, color: AppColors.slateMuted);
    bool isHeading(String l) => l.length > 3 && l == l.toUpperCase() && l != l.toLowerCase();
    final children = <Widget>[];
    for (final raw in content.split('\n')) {
      final line = raw.trimRight();
      if (line.isEmpty) {
        children.add(const SizedBox(height: 4));
      } else if (line.startsWith('\u2022 ')) {
        children.add(Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Padding(
              padding: EdgeInsets.only(top: 9, right: 10, left: 2),
              child: Icon(Icons.circle, size: 5, color: AppColors.primary),
            ),
            Expanded(child: Text(line.substring(2), style: body)),
          ]),
        ));
      } else if (isHeading(line)) {
        children.add(Padding(
          padding: const EdgeInsets.only(top: 16, bottom: 8),
          child: Text(line,
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, letterSpacing: 0.4, color: AppColors.primary)),
        ));
      } else {
        children.add(Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(line, style: body)));
      }
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: children);
  }

  void _showTextContentSheet({
    required BuildContext context,
    required String title,
    required String content,
  }) {
    _push(
      context,
      title,
      SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
        child: _legalBody(content),
      ),
    );
  }
}


/// Numbers the admin controls, in words, for the FAQ answers. Unknown ones are left empty and the text copes.
Map<String, String> _faqValues(bool en) {
  String money(num v) => CurrencyService.format(v);
  String pct(double v) => '${v == v.roundToDouble() ? v.toInt() : v}%';
  String range(num min, num? max) {
    if (max == null) return en ? 'at least ${money(min)}' : 'angalau ${money(min)}';
    return en ? 'from ${money(min)} to ${money(max)}' : 'kuanzia ${money(min)} hadi ${money(max)}';
  }

  final fees = AppPolicy.providerFees;
  return {
    'regFee': AppPolicy.registrationFee == null ? '' : money(AppPolicy.registrationFee!),
    'svcFee': AppPolicy.serviceFee == null ? '' : money(AppPolicy.serviceFee!),
    'freeLimit': AppPolicy.freeServiceLimit?.toString() ?? (en ? 'a few' : 'baadhi ya'),
    'collection': (fees != null && fees.collectionPercent > 0) ? pct(fees.collectionPercent) : '',
    'withdrawRange': range(AppPolicy.withdrawMinEffective, AppPolicy.withdrawMaxEffective),
    'topUpRange': range(AppPolicy.topUpMin ?? 1000, AppPolicy.topUpMax ?? 5000000),
  };
}

/// Frequently asked questions: grouped by topic, with a search box.
class _FaqPage extends StatefulWidget {
  const _FaqPage();

  @override
  State<_FaqPage> createState() => _FaqPageState();
}

class _FaqPageState extends State<_FaqPage> {
  final _search = TextEditingController();
  String _query = '';

  static const Map<String, IconData> _icons = {
    'start': Icons.waving_hand_outlined,
    'find': Icons.search_rounded,
    'booking': Icons.receipt_long_outlined,
    'offers': Icons.local_offer_outlined,
    'wallet': Icons.account_balance_wallet_outlined,
    'sell': Icons.storefront_outlined,
    'verify': Icons.verified_user_outlined,
    'safety': Icons.shield_outlined,
    'chat': Icons.chat_bubble_outline_rounded,
    'trouble': Icons.build_circle_outlined,
  };

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Widget _tile(FaqItem i, bool en, Map<String, String> v) => ExpansionTile(
        tilePadding: const EdgeInsets.symmetric(horizontal: 16),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
        expandedCrossAxisAlignment: CrossAxisAlignment.start,
        title: Text(i.q(en), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
        children: [
          Text(FaqContent.render(i.a(en), v), style: const TextStyle(fontSize: 12.5, height: 1.55, color: AppColors.textSecondary)),
        ],
      );

  Widget _card(List<Widget> children) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(children: children),
      );

  @override
  Widget build(BuildContext context) {
    final en = AppStrings.isEnglish;
    final v = _faqValues(en);
    final hits = FaqContent.search(_query, en, v);
    final searching = _query.trim().isNotEmpty;

    final body = <Widget>[];
    if (searching) {
      if (hits.isEmpty) {
        body.add(Padding(
          padding: const EdgeInsets.all(24),
          child: Text(
            _t('No answer found. Try other words, or use Report a Problem.', 'Hakuna jibu lililopatikana. Jaribu maneno mengine, au tumia Ripoti Tatizo.'),
            textAlign: TextAlign.center,
            style: const TextStyle(color: AppColors.textSecondary),
          ),
        ));
      } else {
        body.add(_card([for (final h in hits) _tile(h.item, en, v)]));
      }
    } else {
      for (final c in FaqContent.categories) {
        body.add(Padding(
          padding: const EdgeInsets.fromLTRB(4, 8, 4, 8),
          child: Row(children: [
            Icon(_icons[c.id] ?? Icons.help_outline_rounded, size: 18, color: AppColors.primary),
            const SizedBox(width: 8),
            Expanded(child: Text(c.title(en), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary))),
          ]),
        ));
        body.add(_card([for (final i in c.items) _tile(i, en, v)]));
      }
    }

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(_t('Frequently Asked Questions', 'Maswali Yanayoulizwa Mara kwa Mara'),
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: TextField(
              controller: _search,
              onChanged: (t) => setState(() => _query = t),
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                hintText: _t('Search questions...', 'Tafuta maswali...'),
                prefixIcon: const Icon(Icons.search_rounded),
                suffixIcon: searching
                    ? IconButton(
                        icon: const Icon(Icons.close_rounded),
                        onPressed: () {
                          _search.clear();
                          setState(() => _query = '');
                        },
                      )
                    : null,
                filled: true,
                fillColor: AppColors.surface,
                isDense: true,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: AppColors.border)),
              ),
            ),
          ),
          Expanded(child: ListView(padding: const EdgeInsets.all(16), children: body)),
        ]),
      ),
    );
  }
}
