import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/provider_fees.dart';
import '../services/api_service.dart';
import '../services/app_policy_service.dart';
import '../widgets/app_ui.dart';
import '../services/currency_service.dart';
import '../services/money_input.dart';

/// Admin: set the withdrawal charges. Collection % is taken on its own; VAT % is taken from the
/// withdrawn amount with the flat payout fee INSIDE it (20,000: 600 collection + 3,600 = 1,500
/// payout fee + 2,100 VAT; the provider receives 15,800). Nothing is taken when a buyer pays: the
/// provider's wallet shows the full amount.
///
/// Only a remote control: the server checks every call (403 for non-admins) and does the
/// real charging.
class AdminProviderFeesScreen extends StatefulWidget {
  const AdminProviderFeesScreen({super.key});

  @override
  State<AdminProviderFeesScreen> createState() => _AdminProviderFeesScreenState();
}

class _AdminProviderFeesScreenState extends State<AdminProviderFeesScreen> {
  final _collCtrl = TextEditingController();
  final _vatCtrl = TextEditingController();
  final _flatCtrl = TextEditingController();
  final _minCtrl = TextEditingController();
  final _maxCtrl = TextEditingController();
  bool _loading = true;
  bool _forbidden = false;
  bool _loadFailed = false;
  bool _saving = false;
  ProviderFees? _saved; // what the server uses now
  String? _collError;
  String? _vatError;
  String? _flatError;
  String? _minError;
  String? _maxError;

  bool get _isEn => AppStrings.isEnglish;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _collCtrl.dispose();
    _vatCtrl.dispose();
    _flatCtrl.dispose();
    _minCtrl.dispose();
    _maxCtrl.dispose();
    super.dispose();
  }

  String _pctText(double v) => v == v.roundToDouble() ? v.toInt().toString() : v.toString();

  void _fill(ProviderFees f) {
    _collCtrl.text = _pctText(f.collectionPercent);
    _vatCtrl.text = _pctText(f.vatPercent);
    _flatCtrl.text = MoneyInput.text(f.payoutFee, blankZero: false);
    _minCtrl.text = MoneyInput.text(f.withdrawMin, blankZero: false);
    _maxCtrl.text = MoneyInput.text(f.withdrawMax, blankZero: false);
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _loadFailed = false;
    });
    final r = await ApiService.getAdminProviderFees();
    if (!mounted) return;
    setState(() {
      _loading = false;
      _forbidden = r.forbidden;
      _loadFailed = !r.forbidden && r.fees == null;
      _saved = r.fees;
      if (r.fees != null) _fill(r.fees!);
    });
  }

  double? get _coll => double.tryParse(_collCtrl.text.trim());
  double? get _vat => double.tryParse(_vatCtrl.text.trim());
  int? get _flat => MoneyInput.parse(_flatCtrl.text)?.toInt();
  int? get _min => MoneyInput.parse(_minCtrl.text)?.toInt();
  int? get _max => MoneyInput.parse(_maxCtrl.text)?.toInt();

  bool get _changed {
    final s = _saved;
    if (s == null) return false;
    final c = _coll, v = _vat, f = _flat, lo = _min, hi = _max;
    if (c == null || v == null || f == null || lo == null || hi == null) return false;
    return c != s.collectionPercent || v != s.vatPercent || f != s.payoutFee || lo != s.withdrawMin || hi != s.withdrawMax;
  }

  String _money(num v) =>
      CurrencyService.format(v.round());

  String _limitsText(ProviderFees f, bool en) {
    final lo = f.withdrawMin > 0 ? _money(f.withdrawMin) : (en ? 'the default' : 'kawaida');
    if (f.withdrawMax > 0) {
      return en
          ? 'Withdrawals: from $lo to ${_money(f.withdrawMax)}.'
          : 'Utoaji: kuanzia $lo hadi ${_money(f.withdrawMax)}.';
    }
    return en ? 'Withdrawals: minimum $lo, no maximum.' : 'Utoaji: kiwango cha chini $lo, hakuna cha juu.';
  }

  Future<void> _save() async {
    final c = _coll, v = _vat, f = _flat, lo = _min, hi = _max;
    String? ce, ve, fe, le, he;
    if (lo == null || lo < 0 || lo > ProviderFees.maxWithdrawLimit || (lo > 0 && lo < ProviderFees.minWithdrawFloor)) {
      le = _isEn ? 'Enter 0 (default) or ${_money(ProviderFees.minWithdrawFloor)} or more' : 'Weka 0 (kawaida) au ${_money(ProviderFees.minWithdrawFloor)} au zaidi';
    }
    if (hi == null || hi < 0 || hi > ProviderFees.maxWithdrawLimit) {
      he = _isEn ? 'Enter 0 (no maximum) up to ${_money(ProviderFees.maxWithdrawLimit)}' : 'Weka 0 (hakuna kiwango cha juu) hadi ${_money(ProviderFees.maxWithdrawLimit)}';
    } else if (le == null && hi > 0 && lo! > 0 && hi < lo) {
      he = _isEn ? 'The maximum must not be below the minimum' : 'Kiwango cha juu kisiwe chini ya cha chini';
    } else if (le == null && hi > 0 && hi < ProviderFees.minWithdrawFloor) {
      he = _isEn ? 'Enter 0 (no maximum) or ${_money(ProviderFees.minWithdrawFloor)} or more' : 'Weka 0 (hakuna) au ${_money(ProviderFees.minWithdrawFloor)} au zaidi';
    }
    if (c == null || c < 0 || c > ProviderFees.maxCollection) {
      ce = _isEn ? 'Enter 0 to ${ProviderFees.maxCollection.toInt()}' : 'Weka 0 hadi ${ProviderFees.maxCollection.toInt()}';
    }
    if (v == null || v < 0 || v > ProviderFees.maxVat) {
      ve = _isEn ? 'Enter 0 to ${ProviderFees.maxVat.toInt()}' : 'Weka 0 hadi ${ProviderFees.maxVat.toInt()}';
    }
    if (f == null || f < 0 || f > ProviderFees.maxPayoutFee) {
      fe = _isEn ? 'Enter 0 to ${_money(ProviderFees.maxPayoutFee)}' : 'Weka 0 hadi ${_money(ProviderFees.maxPayoutFee)}';
    }
    if (ce != null || ve != null || fe != null || le != null || he != null) {
      setState(() {
        _minError = le;
        _maxError = he;
        _collError = ce;
        _vatError = ve;
        _flatError = fe;
      });
      return;
    }
    final fees = ProviderFees(collectionPercent: c!, vatPercent: v!, payoutFee: f!, withdrawMin: lo!, withdrawMax: hi!);
    final ok = await AppDialog.confirm(
      context,
      icon: Icons.percent_rounded,
      title: _isEn ? 'Save provider fees?' : 'Hifadhi ada za watoa huduma?',
      message: _isEn
          ? 'On each withdrawal providers pay a ${_pctText(c)}% collection fee, plus ${_pctText(v)}% in which the ${_money(f)} payout fee is included (not added on top). Nothing is taken when a buyer pays. Refunds carry the ${_pctText(v)}% charge only. Example: ${_money(20000)} withdrawn pays out ${_money(fees.net(20000))}; the admin wallet gets ${_money(fees.collectionFee(20000))} collection fee, ${_money(fees.payoutAmount(20000))} fee income and ${_money(fees.vatAmount(20000))} VAT. ${_limitsText(fees, true)}'
          : 'Kila utoaji watoa huduma hulipa ada ya ukusanyaji ${_pctText(c)}%, pamoja na ${_pctText(v)}% ambayo ada ya kutuma ${_money(f)} ipo ndani yake (haiongezwi juu). Hakuna kinachokatwa mnunuzi anapolipa. Marejesho yana ada ya ${_pctText(v)}% pekee. Mfano: ${_money(20000)} ikitolewa inalipa ${_money(fees.net(20000))}; wallet ya msimamizi inapata ada ya ukusanyaji ${_money(fees.collectionFee(20000))}, mapato ${_money(fees.payoutAmount(20000))} na VAT ${_money(fees.vatAmount(20000))}. ${_limitsText(fees, false)}',
      confirmLabel: _isEn ? 'Save' : 'Hifadhi',
    );
    if (!ok || !mounted) return;

    setState(() => _saving = true);
    final messenger = ScaffoldMessenger.of(context);
    final res = await ApiService.setAdminProviderFees(fees);
    if (!mounted) return;
    setState(() => _saving = false);
    if (res == null) {
      final err = ApiService.lastAdminError;
      messenger.showSnackBar(SnackBar(
        content: Text(err == 'forbidden'
            ? (_isEn ? 'Only an admin can change this.' : 'Ni msimamizi pekee anayeweza kubadilisha hili.')
            : err == 'network'
                ? (_isEn ? 'No connection. Nothing was changed.' : 'Hakuna mtandao. Hakuna kilichobadilishwa.')
                : (_isEn ? 'Could not save. Nothing was changed.' : 'Imeshindwa kuhifadhi. Hakuna kilichobadilishwa.')),
      ));
      return;
    }
    setState(() {
      _saved = res;
      _fill(res);
    });
    AppPolicyService.refresh(force: true);
    messenger.showSnackBar(SnackBar(content: Text(_isEn ? 'Provider fees saved.' : 'Ada za watoa huduma zimehifadhiwa.')));
  }

  Widget _note(String text, {Color color = AppColors.primary, IconData icon = Icons.info_outline_rounded}) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withValues(alpha: 0.2)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 12.5, height: 1.4, color: AppColors.textPrimary))),
        ],
      ),
    );
  }

  Widget _card(String title, String? subtitle, Widget child) => Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w800, color: AppColors.primaryDark)),
            if (subtitle != null) ...[
              const SizedBox(height: 2),
              Text(subtitle, style: const TextStyle(fontSize: 11.5, height: 1.4, color: AppColors.textSecondary)),
            ],
            const SizedBox(height: 12),
            child,
          ],
        ),
      );

  Widget _fieldLabel(String t) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Text(t, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
      );

  Widget _row(String a, String b, {bool bold = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(children: [
          Expanded(child: Text(a, style: TextStyle(fontSize: 13, color: AppColors.textSecondary, fontWeight: bold ? FontWeight.w800 : FontWeight.w500))),
          Text(b, style: TextStyle(fontSize: 13, color: AppColors.textPrimary, fontWeight: bold ? FontWeight.w800 : FontWeight.w600)),
        ]),
      );

  Widget _preview() {
    final c = _coll, v = _vat, f = _flat;
    if (c == null || v == null || f == null || c < 0 || c > ProviderFees.maxCollection || v < 0 || v > ProviderFees.maxVat || f < 0 || f > ProviderFees.maxPayoutFee) {
      return const SizedBox.shrink();
    }
    final fees = ProviderFees(collectionPercent: c, vatPercent: v, payoutFee: f);
    const paid = 20000;
    return Container(
      margin: const EdgeInsets.only(top: 0),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.border)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(_isEn ? '1. A buyer pays ${_money(paid)}' : '1. Mnunuzi analipa ${_money(paid)}',
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
          const SizedBox(height: 6),
          _row(_isEn ? 'Provider wallet shows' : 'Wallet ya mtoa huduma inaonyesha', _money(paid), bold: true),
          const Divider(height: 18),
          Text(_isEn ? '2. The provider withdraws ${_money(paid)}' : '2. Mtoa huduma anatoa ${_money(paid)}',
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
          const SizedBox(height: 6),
          _row(_isEn ? 'Collection fee' : 'Ada ya ukusanyaji', '- ${_money(fees.collectionFee(paid))}'),
          _row(_isEn ? 'Fee (payout fee inside)' : 'Ada (ada ya kutuma ipo ndani)', '- ${_money(fees.chargeFee(paid))}'),
          _row(_isEn ? 'Provider receives' : 'Mtoa huduma anapokea', _money(fees.net(paid)), bold: true),
          const Divider(height: 18),
          Text(_isEn ? '3. Admin wallet (only you see this split)' : '3. Wallet ya msimamizi (wewe tu unaona mgawanyo huu)',
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
          const SizedBox(height: 6),
          _row(_isEn ? 'Collection fee' : 'Ada ya ukusanyaji', '+ ${_money(fees.collectionFee(paid))}'),
          _row(_isEn ? 'Payout fee income' : 'Mapato ya ada ya kutuma', '+ ${_money(fees.payoutAmount(paid))}'),
          _row(_isEn ? 'VAT collected (to remit)' : 'VAT iliyokusanywa (ya kulipa)', '+ ${_money(fees.vatAmount(paid))}'),
        ],
      ),
    );
  }

  Widget _body() {
    if (_loading) return const Center(child: CircularProgressIndicator(color: AppColors.primary));
    if (_forbidden) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: _note(
            _isEn ? 'This account is not an admin, so it cannot change payment settings.' : 'Akaunti hii si ya msimamizi, kwa hiyo haiwezi kubadilisha mipangilio ya malipo.',
            color: AppColors.danger,
            icon: Icons.lock_outline_rounded,
          ),
        ),
      );
    }
    if (_loadFailed) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(_isEn ? 'Could not load the current fees.' : 'Imeshindwa kupakia ada za sasa.',
                textAlign: TextAlign.center, style: const TextStyle(fontSize: 14, color: AppColors.textSecondary)),
            const SizedBox(height: 16),
            AppButton.primary(label: _isEn ? 'Try again' : 'Jaribu tena', onPressed: _load),
          ]),
        ),
      );
    }
    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewInsets.bottom),
            children: [
              _note(_isEn
                  ? 'Charges are taken only when the provider withdraws: the collection fee on its own, plus the VAT % charge. The payout fee is part of the VAT % charge, not added on top. When a buyer pays, the provider\'s wallet shows the full amount.'
                  : 'Ada hukatwa mtoa huduma anapotoa pesa tu: ada ya ukusanyaji peke yake, pamoja na ada ya asilimia ya VAT. Ada ya kutuma ipo ndani ya asilimia ya VAT, haiongezwi juu. Mnunuzi anapolipa, wallet ya mtoa huduma huonyesha kiasi kamili.'),
              const SizedBox(height: 14),
              _card(
                _isEn ? 'Fees at withdrawal' : 'Ada wakati wa kutoa pesa',
                _isEn ? 'Percent of the amount the provider withdraws.' : 'Asilimia ya kiasi anachotoa mtoa huduma.',
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        _fieldLabel(_isEn ? 'Collection fee (%)' : 'Ada ya ukusanyaji (%)'),
                        AppTextField(
                          controller: _collCtrl,
                          icon: Icons.percent_rounded,
                          keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          hint: '3',
                          errorText: _collError,
                          inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'^\d{0,2}(\.\d{0,2})?$'))],
                          onChanged: (_) => setState(() => _collError = null),
                        ),
                      ]),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        _fieldLabel(_isEn ? 'VAT (%)' : 'VAT (%)'),
                        AppTextField(
                          controller: _vatCtrl,
                          icon: Icons.percent_rounded,
                          keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          hint: '18',
                          errorText: _vatError,
                          inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'^\d{0,2}(\.\d{0,2})?$'))],
                          onChanged: (_) => setState(() => _vatError = null),
                        ),
                      ]),
                    ),
                  ]),
                  const SizedBox(height: 12),
                  _fieldLabel(_isEn
                      ? 'Payout fee (${CurrencyService.symbol}), inside the VAT charge'
                      : 'Ada ya kutuma (${CurrencyService.symbol}), ndani ya ada ya VAT'),
                  AppTextField(
                    controller: _flatCtrl,
                    icon: Icons.payments_outlined,
                    keyboardType: TextInputType.number,
                    hint: '1500',
                    errorText: _flatError,
                    inputFormatters: const [MoneyInputFormatter(maxDigits: 7)],
                    onChanged: (_) => setState(() => _flatError = null),
                  ),
                ]),
              ),
              _card(
                _isEn ? 'Withdrawal limits (${CurrencyService.symbol})' : 'Viwango vya kutoa pesa (${CurrencyService.symbol})',
                _isEn
                    ? 'Lowest and highest amount a provider can withdraw at once. 0 in "From" = app default (1,000). 0 in "To" = no maximum.'
                    : 'Kiasi cha chini na cha juu mtoa huduma anachoweza kutoa kwa mara moja. 0 kwenye "Kuanzia" = kawaida ya app (1,000). 0 kwenye "Hadi" = hakuna kiwango cha juu.',
                Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Expanded(
                    child: AppTextField(
                      controller: _minCtrl,
                      icon: Icons.south_rounded,
                      keyboardType: TextInputType.number,
                      hint: _isEn ? 'From' : 'Kuanzia',
                      errorText: _minError,
                      inputFormatters: const [MoneyInputFormatter(maxDigits: 9)],
                      onChanged: (_) => setState(() => _minError = null),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: AppTextField(
                      controller: _maxCtrl,
                      icon: Icons.north_rounded,
                      keyboardType: TextInputType.number,
                      hint: _isEn ? 'To' : 'Hadi',
                      errorText: _maxError,
                      inputFormatters: const [MoneyInputFormatter(maxDigits: 9)],
                      onChanged: (_) => setState(() => _maxError = null),
                    ),
                  ),
                ]),
              ),
              _preview(),
            ],
          ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: SizedBox(
              width: double.infinity,
              child: AppButton.primary(
                label: _isEn ? 'Save' : 'Hifadhi',
                loading: _saving,
                onPressed: _changed && !_saving ? _save : null,
              ),
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: _saving ? null : () => Navigator.pop(context),
        ),
        title: Text(_isEn ? 'Provider Fees' : 'Ada za Watoa Huduma',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(color: AppColors.borderLight, height: 1)),
      ),
      body: _body(),
    );
  }
}
