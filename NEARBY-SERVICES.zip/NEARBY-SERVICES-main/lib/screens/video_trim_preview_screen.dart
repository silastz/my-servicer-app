import 'dart:io';

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/keep_awake.dart';
import '../services/video_trim.dart';
import '../widgets/app_ui.dart';

/// Shown when a picked video is over the size limit: plays it and shows which part will be kept
/// (the first part, up to the cut line) and which part will be removed. The user confirms or cancels.
/// Pops `true` to trim and upload, `false` / null to cancel. Nothing is cut here.
class VideoTrimPreviewScreen extends StatefulWidget {
  const VideoTrimPreviewScreen({super.key, required this.path, required this.sizeBytes, required this.maxBytes});

  final String path;
  final int sizeBytes;
  final int maxBytes;

  @override
  State<VideoTrimPreviewScreen> createState() => _VideoTrimPreviewScreenState();
}

class _VideoTrimPreviewScreenState extends State<VideoTrimPreviewScreen> {
  late final VideoPlayerController _c;
  bool _ready = false;
  bool _failed = false;
  Duration _keep = Duration.zero;

  bool get _isEn => AppStrings.isEnglish;
  String _t(String en, String sw) => _isEn ? en : sw;

  @override
  void initState() {
    super.initState();
    _c = VideoPlayerController.file(File(widget.path))..addListener(_tick);
    _c.initialize().then((_) {
      if (!mounted) return;
      setState(() {
        _ready = true;
        _keep = VideoTrim.keepFor(_c.value.duration, widget.sizeBytes, widget.maxBytes);
      });
      _c.setLooping(false);
      _c.play();
    }).catchError((_) {
      if (mounted) setState(() => _failed = true);
    });
  }

  /// Playback stops at the cut line and starts over: the user only sees what will be kept.
  void _tick() {
    if (!mounted || !_ready) return;
    final v = _c.value;
    KeepAwake.follow(v.isPlaying);
    if (v.isPlaying && (v.position >= _keep || v.position >= v.duration)) {
      _c.pause();
      _c.seekTo(Duration.zero).then((_) => _c.play());
    }
    setState(() {});
  }

  @override
  void dispose() {
    _c.removeListener(_tick);
    KeepAwake.release();
    _c.dispose();
    super.dispose();
  }

  String _fmt(Duration d) {
    final m = d.inMinutes, s = d.inSeconds % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }

  String _mb(int bytes) => (bytes / (1024 * 1024)).toStringAsFixed(bytes >= 10 * 1024 * 1024 ? 0 : 1);

  Widget _bar(Duration total) {
    final totalMs = total.inMilliseconds <= 0 ? 1 : total.inMilliseconds;
    final keepFrac = (_keep.inMilliseconds / totalMs).clamp(0.0, 1.0);
    final posFrac = (_c.value.position.inMilliseconds / totalMs).clamp(0.0, 1.0);
    return LayoutBuilder(builder: (context, c) {
      final w = c.maxWidth;
      return SizedBox(
        height: 28,
        child: Stack(
          alignment: Alignment.centerLeft,
          children: [
            // removed part
            Container(height: 10, width: w, decoration: BoxDecoration(color: AppColors.danger.withValues(alpha: 0.35), borderRadius: BorderRadius.circular(5))),
            // kept part
            Container(height: 10, width: w * keepFrac, decoration: BoxDecoration(color: AppColors.success, borderRadius: BorderRadius.circular(5))),
            // cut line
            Positioned(left: (w * keepFrac - 1).clamp(0.0, w), child: Container(width: 2, height: 24, color: Colors.white)),
            // playhead
            Positioned(left: (w * posFrac - 6).clamp(0.0, w - 12), child: Container(width: 12, height: 12, decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle))),
          ],
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final total = _ready ? _c.value.duration : Duration.zero;
    final tooSmall = _ready && _keep.inMilliseconds < 1000;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(_t('Video will be trimmed', 'Video itapunguzwa'), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Center(
                child: _failed
                    ? Text(_t('Could not play this video.', 'Imeshindwa kucheza video hii.'), style: const TextStyle(color: Colors.white70))
                    : !_ready
                        ? const CircularProgressIndicator(color: Colors.white)
                        : GestureDetector(
                            onTap: () => _c.value.isPlaying ? _c.pause() : _c.play(),
                            child: AspectRatio(
                              aspectRatio: _c.value.aspectRatio,
                              child: Stack(alignment: Alignment.center, children: [
                                VideoPlayer(_c),
                                if (!_c.value.isPlaying)
                                  const Icon(Icons.play_circle_fill_rounded, size: 64, color: Colors.white70),
                              ]),
                            ),
                          ),
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
              decoration: const BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _t('This video is ${_mb(widget.sizeBytes)} MB. The limit is ${_mb(widget.maxBytes)} MB.',
                        'Video hii ni MB ${_mb(widget.sizeBytes)}. Kikomo ni MB ${_mb(widget.maxBytes)}.'),
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                  ),
                  const SizedBox(height: 10),
                  if (_ready) ...[
                    _bar(total),
                    const SizedBox(height: 6),
                    Row(children: [
                      Container(width: 10, height: 10, decoration: BoxDecoration(color: AppColors.success, borderRadius: BorderRadius.circular(3))),
                      const SizedBox(width: 6),
                      Expanded(child: Text(_t('Kept: first ${_fmt(_keep)}', 'Inabaki: ${_fmt(_keep)} ya kwanza'), style: const TextStyle(fontSize: 12.5, color: AppColors.textPrimary))),
                      Container(width: 10, height: 10, decoration: BoxDecoration(color: AppColors.danger.withValues(alpha: 0.5), borderRadius: BorderRadius.circular(3))),
                      const SizedBox(width: 6),
                      Text(_t('Removed: ${_fmt(total - _keep)}', 'Inaondolewa: ${_fmt(total - _keep)}'), style: const TextStyle(fontSize: 12.5, color: AppColors.textPrimary)),
                    ]),
                    const SizedBox(height: 6),
                    Text(
                      tooSmall
                          ? _t('Too little would be left. Choose a shorter video.', 'Kitabaki kidogo mno. Chagua video fupi zaidi.')
                          : _t('Only the first part is uploaded (the cut can land a little earlier). Playback loops over the kept part.',
                              'Sehemu ya kwanza pekee ndiyo inapakiwa (kata inaweza kuwa mapema kidogo). Uchezaji unarudia sehemu inayobaki.'),
                      style: TextStyle(fontSize: 12, height: 1.35, color: tooSmall ? AppColors.danger : AppColors.textSecondary),
                    ),
                  ],
                  const SizedBox(height: 14),
                  Row(children: [
                    Expanded(child: AppButton.outlined(label: _t('Cancel', 'Ghairi'), onPressed: () => Navigator.pop(context, false))),
                    const SizedBox(width: 12),
                    Expanded(
                      child: AppButton.primary(
                        label: _t('Trim & upload', 'Punguza & pakia'),
                        onPressed: _ready && !tooSmall ? () => Navigator.pop(context, true) : null,
                      ),
                    ),
                  ]),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
