import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/models.dart';
import '../models/portfolio_item.dart';
import '../services/media_picker.dart';
import '../services/api_service.dart';
import '../services/block_service.dart';
import '../services/session_manager.dart';
import '../services/share_service.dart';
import '../widgets/app_image.dart';
import '../widgets/block_user_dialog.dart';
import '../widgets/call_options_sheet.dart';
import '../widgets/fullscreen_image_viewer.dart';
import '../widgets/login_modal.dart';
import '../widgets/provider_contact_card.dart';
import '../widgets/report_sheet.dart';
import '../widgets/sensitive_tag.dart';
import '../widgets/verification_badge.dart';
import '../widgets/video_player_screen.dart';
import 'booking_request_screen.dart';
import 'chat_thread_screen.dart';
import 'provider_services_screen.dart';
import 'service_details_screen.dart';
import '../widgets/ad_widgets.dart';
import '../widgets/whatsapp_text.dart';
import '../models/ads_config.dart';
import '../services/security_settings.dart';

/// Provider profile: cover, Instagram-style header (stats beside the avatar, trust chips, bio, actions),
/// icon tabs (Services / Portfolio / Reviews / About) and a pinned "Starting from" price bar.
/// Every number and text on this page comes from the server; a fact the provider
/// has not shared is simply left out (nothing is invented).
class SellerProfileScreen extends StatefulWidget {
  final ServiceItem provider;

  const SellerProfileScreen({
    super.key,
    required this.provider,
  });

  @override
  State<SellerProfileScreen> createState() => _SellerProfileScreenState();
}

class _SellerProfileScreenState extends State<SellerProfileScreen> {
  static const double _heroHeight = 132;
  static const List<String> _monthsEn = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  final ScrollController _scroll = ScrollController();
  final GlobalKey _tabsKey = GlobalKey();
  int _tab = 0;
  late Future<List<dynamic>?> _reviewsFuture;

  bool get _en => AppStrings.isEnglish;
  ServiceItem get _p => widget.provider;
  int? get _sellerId => _p.sellerId;
  bool get _isMine => SessionManager.isLoggedIn() && _sellerId != null && _sellerId == SessionManager.getUserIdValue();
  bool get _canModerate => _sellerId != null && _sellerId != 0 && !_isMine;

  String get _name => _p.stageName.isNotEmpty ? _p.stageName : _p.title;

  /// The provider's real services (same data Home / Category / Details show),
  /// always including the one the buyer came from.
  late List<ServiceItem> _services = () {
    final mine = ApiService.knownServices.values
        .where((s) => s.id == _p.id || (_p.sellerId != null && s.sellerId == _p.sellerId))
        .toList();
    if (!mine.any((s) => s.id == _p.id)) mine.insert(0, _p);
    return mine;
  }();

  /// Services the buyer has not marked "Not interested" (their own are always shown).
  List<ServiceItem> get _visibleServices =>
      _services
          .where((s) => _isMine || (!SessionManager.isServiceHidden(s.id) && (SecuritySettings.allowSensitive || !s.is18Plus || s.id == _p.id)))
          .toList();

  // The provider's own portfolio (separate from their services' media). Null = not loaded yet.
  List<PortfolioItem>? _portfolio;
  bool _portfolioFailed = false;
  bool _uploading = false;
  double _uploadProgress = 0;

  Future<void> _loadPortfolio() async {
    final id = _sellerId;
    if (id == null || id == 0) {
      setState(() => _portfolio = const []);
      return;
    }
    final list = await ApiService.fetchPortfolio(id);
    if (!mounted) return;
    setState(() {
      if (list != null) _portfolio = list;
      _portfolioFailed = list == null && _portfolio == null;
    });
  }

  /// The provider's own cover photo (profile data). A service photo is never used as the cover.
  String? get _coverImage {
    final own = _isMine ? SessionManager.getCoverUrl() : '';
    if (own.isNotEmpty) return own;
    final set = (_p.sellerCover ?? '').trim();
    return set.isNotEmpty ? set : null;
  }
  /// Your own page shows your current photo (also right after you change or remove it); others show the
  /// photo the server sent with the service.
  String? get _avatarImage {
    if (_isMine) {
      final own = SessionManager.getAvatarUrl();
      return own.isNotEmpty ? own : null;
    }
    return (_p.sellerAvatar ?? '').isNotEmpty ? _p.sellerAvatar : null;
  }

  @override
  void initState() {
    super.initState();
    _loadReviews();
    _loadPortfolio();
    if (_isMine) _loadMineFromServer();
    // Your own page shows a new cover photo / About text as soon as it is saved.
    SessionManager.sessionNotifier.addListener(_onSessionChanged);
    SecuritySettings.changed.addListener(_onSettingsChanged);
  }

  void _onSessionChanged() {
    if (mounted && _isMine) setState(() {});
  }

  /// 'Allow sensitive content' was switched while this page is open.
  void _onSettingsChanged() {
    if (mounted) setState(() {});
  }

  /// Your own page: fetch your services so it never depends on the Home feed having loaded.
  Future<void> _loadMineFromServer() async {
    final items = await ApiService.fetchMyServiceItems();
    if (!mounted || items.isEmpty) return;
    // The server's list is the truth for your own page: a service you deleted must disappear, not stay from the cache.
    setState(() => _services = items);
  }

  @override
  void dispose() {
    SessionManager.sessionNotifier.removeListener(_onSessionChanged);
    SecuritySettings.changed.removeListener(_onSettingsChanged);
    _scroll.dispose();
    super.dispose();
  }

  void _loadReviews() {
    final id = _sellerId;
    _reviewsFuture = (id == null || id == 0) ? Future.value(<dynamic>[]) : ApiService.fetchProviderReviews(id);
  }

  // ---------------------------------------------------------------- helpers

  String _monthYear(DateTime d) => '${_monthsEn[d.month - 1]} ${d.year}';

  String _dateText(DateTime d) => '${d.day} ${_monthsEn[d.month - 1]} ${d.year}';

  /// 'Starting from' / 'Per hour' / 'Fixed price' for one service (null when the server doesn't say).
  String? _priceTypeLabel(ServiceItem s) {
    switch (s.priceType) {
      case 'STARTING_FROM':
        return _en ? 'Starting from' : 'Kuanzia';
      case 'PER_HOUR':
        return _en ? 'Per hour' : 'Kwa saa';
      case 'FIXED':
        return _en ? 'Fixed price' : 'Bei maalum';
      default:
        return null;
    }
  }

  String get _initial => _name.trim().isEmpty ? '?' : _name.trim().substring(0, 1).toUpperCase();

  void _openAllServices() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ProviderServicesScreen(
          providerName: _name,
          providerAvatar: _avatarImage,
          providerOnline: _p.isOnline,
          services: _services,
          hideFilter: (s) => _isMine || !SessionManager.isServiceHidden(s.id),
          cardBuilder: (s) => Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: _serviceCard(s)),
        ),
      ),
    );
  }

  Future<void> _toggleFavorite(ServiceItem s) async {
    final now = await SessionManager.toggleFavorite(s.id);
    if (!mounted) return;
    _toast(now ? (_en ? 'Added to favorites' : 'Imeongezwa kwenye vipendwa') : (_en ? 'Removed from favorites' : 'Imeondolewa kwenye vipendwa'));
  }

  Future<void> _hideService(ServiceItem s) async {
    await SessionManager.setServiceHidden(s.id, true);
    if (!mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    messenger.hideCurrentSnackBar();
    messenger.showSnackBar(SnackBar(
      content: Text(_en ? 'We\'ll show you less like this' : 'Tutakuonyesha chache kama hii'),
      action: SnackBarAction(
        label: _en ? 'Undo' : 'Tendua',
        onPressed: () => SessionManager.setServiceHidden(s.id, false),
      ),
    ));
  }

  Future<void> _reportService(ServiceItem s) async {
    final out = await ReportSheet.show(
      context,
      target: ReportTarget.service,
      serviceId: s.id,
      userId: s.sellerId,
      name: s.stageName,
    );
    if (out.sent && mounted) _toast(_en ? 'Report sent. Thank you' : 'Ripoti imetumwa. Asante');
  }

  Future<void> _shareServiceItem(ServiceItem s) => ShareService.showServiceSheet(
        context,
        title: s.title,
        priceText: s.priceText,
        providerName: s.providerName,
        category: s.category,
        serviceId: s.id,
      );

  void _toast(String msg) {
    final m = ScaffoldMessenger.of(context);
    m.hideCurrentSnackBar();
    m.showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 2)));
  }

  Widget _serviceMenu(ServiceItem s) {
    final fav = SessionManager.isFavorite(s.id);
    Widget item(IconData icon, String label, {Color? color}) => Row(
          children: [
            Icon(icon, size: 18, color: color ?? AppColors.slateDark),
            const SizedBox(width: 10),
            Text(label, style: TextStyle(fontWeight: FontWeight.w600, color: color ?? AppColors.textPrimary)),
          ],
        );
    return SizedBox(
      width: 30,
      height: 30,
      child: PopupMenuButton<String>(
        tooltip: _en ? 'More options' : 'Chaguo zaidi',
        padding: EdgeInsets.zero,
        icon: const Icon(Icons.more_vert_rounded, size: 20, color: AppColors.textSecondary),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        onSelected: (v) {
          switch (v) {
            case 'fav':
              _toggleFavorite(s);
            case 'share':
              _shareServiceItem(s);
            case 'hide':
              _hideService(s);
            case 'report':
              _reportService(s);
          }
        },
        itemBuilder: (_) => [
          PopupMenuItem(
            value: 'fav',
            child: item(
              fav ? Icons.favorite_rounded : Icons.favorite_border_rounded,
              fav ? (_en ? 'Remove from favorites' : 'Ondoa kwenye vipendwa') : (_en ? 'Add to favorites' : 'Ongeza kwenye vipendwa'),
              color: fav ? AppColors.danger : null,
            ),
          ),
          PopupMenuItem(value: 'share', child: item(Icons.share_outlined, _en ? 'Share' : 'Shiriki')),
          if (!_isMine) ...[
            PopupMenuItem(value: 'hide', child: item(Icons.visibility_off_outlined, _en ? 'Not interested' : 'Sipendezwi')),
            PopupMenuItem(value: 'report', child: item(Icons.flag_outlined, _en ? 'Report this service' : 'Ripoti huduma hii', color: AppColors.danger)),
          ],
        ],
      ),
    );
  }

  Future<void> _book(ServiceItem s) async {
    if (!SessionManager.isLoggedIn()) {
      final ok = await LoginModal.show(context);
      if (ok != true || !mounted) return;
    }
    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        // The chosen service itself, so the booking charges ITS price and id.
        builder: (_) => BookingRequestScreen(
          provider: s,
          serviceTitle: s.title,
          priceText: s.priceText,
          durationText: s.durationText,
        ),
      ),
    );
  }

  // ------------------------------------------------------------------ build

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      bottomNavigationBar: _isMine ? null : _actionBar(),
      body: Stack(
        children: [
          CustomScrollView(
            controller: _scroll,
            slivers: [
              SliverToBoxAdapter(child: _cover()),
              SliverToBoxAdapter(child: _identity()),
              SliverToBoxAdapter(child: _bioBlock()),
              if (!_isMine) SliverToBoxAdapter(child: _contactButtons()),
              // In-flow tab bar sits right under the stats card; once it scrolls under
              // the top bar, the copy below (see Positioned) takes over and stays pinned.
              const SliverToBoxAdapter(child: SizedBox(height: 14)),
              // AdMob banner between the contact buttons and the tabs (takes no space until loaded)
              const SliverToBoxAdapter(child: AdBannerView(page: AdPage.providerProfile, bottomGap: 14)),
              SliverToBoxAdapter(child: KeyedSubtree(key: _tabsKey, child: _tabBar())),
              SliverToBoxAdapter(child: _tabBody()),
              const SliverToBoxAdapter(child: SizedBox(height: 28)),
            ],
          ),
          Positioned(top: 0, left: 0, right: 0, child: _topBar()),
          Positioned(
            top: _barHeight,
            left: 0,
            right: 0,
            child: AnimatedBuilder(
              animation: _scroll,
              builder: (context, _) => _tabsPinned ? _tabBar() : const SizedBox.shrink(),
            ),
          ),
        ],
      ),
    );
  }

  // ------------------------------------------------------------------- hero

  Widget _roundButton({required IconData icon, required VoidCallback onTap}) {
    return Padding(
      padding: const EdgeInsets.all(6),
      child: Material(
        color: Colors.black.withValues(alpha: 0.38),
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: Icon(icon, color: Colors.white, size: 20),
        ),
      ),
    );
  }

  /// True once the in-flow tab bar has scrolled up under the floating top bar.
  bool get _tabsPinned {
    final box = _tabsKey.currentContext?.findRenderObject();
    if (box is! RenderBox || !box.attached || !box.hasSize) return false;
    return box.localToGlobal(Offset.zero).dy < _barHeight;
  }

  double get _topInset => MediaQuery.of(context).padding.top;
  double get _barHeight => _topInset + kToolbarHeight;

  /// Full-bleed cover photo that scrolls away with the page.
  Widget _cover() {
    return SizedBox(
      height: _heroHeight + _topInset,
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (_coverImage != null)
            AppImage(_coverImage!, fit: BoxFit.cover, errorBuilder: (_, _, _) => _coverFallback())
          else
            _coverFallback(),
          DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withValues(alpha: 0.38),
                  Colors.transparent,
                ],
                stops: const [0, 0.55],
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Back / menu buttons floating over the page. Turns into a solid bar with the
  /// provider's name once the cover has scrolled away. Lives above the scroll view so
  /// the overlapping avatar can never paint across it.
  Widget _topBar() {
    return AnimatedBuilder(
      animation: _scroll,
      builder: (context, _) {
        final span = (_heroHeight + _topInset - _barHeight).clamp(1.0, double.infinity);
        final off = _scroll.hasClients ? _scroll.offset : 0.0;
        final t = (off / span).clamp(0.0, 1.0);
        return Container(
          height: _barHeight,
          padding: EdgeInsets.only(top: _topInset),
          color: AppColors.slateDark.withValues(alpha: t * 0.97),
          child: Row(
            children: [
              _roundButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.pop(context)),
              Expanded(
                child: Opacity(
                  opacity: t,
                  child: Row(
                    children: [
                      Flexible(
                        child: Text(
                          _name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Colors.white),
                        ),
                      ),
                      if (_p.isVerified) ...[
                        const SizedBox(width: 5),
                        VerificationBadge(level: _p.verificationLevel, size: 16),
                      ],
                    ],
                  ),
                ),
              ),
              if (!_isMine) _roundButton(icon: Icons.ios_share_rounded, onTap: _shareProfile),
              if (_canModerate) _moderationMenu(),
              const SizedBox(width: 4),
            ],
          ),
        );
      },
    );
  }

  Widget _coverFallback() => Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [AppColors.slateDark, AppColors.primaryDark],
          ),
        ),
      );

  Widget _chip({required String label, IconData? icon, bool dot = false, required Color bg, required Color fg, Color? border}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(20),
        border: border == null ? null : Border.all(color: border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (dot) Icon(Icons.circle, size: 7, color: fg),
          if (icon != null) Icon(icon, size: 12, color: fg),
          const SizedBox(width: 4),
          Flexible(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: fg))),
        ],
      ),
    );
  }

  /// Trust and status chips under the name: only what is true for this provider.
  Widget _chips() {
    final chips = <Widget>[
      if (_p.isVerified)
        _chip(
          label: _en ? 'Verified & Trusted' : 'Amethibitishwa',
          icon: Icons.verified_user_rounded,
          bg: AppColors.primaryLight,
          fg: AppColors.navy,
          border: AppColors.primary.withValues(alpha: 0.22),
        ),
      if (_p.businessVerified) const VerifiedBusinessChip(),
      if (_p.isOnline)
        _chip(label: _en ? 'Online' : 'Mtandaoni', dot: true, bg: const Color(0xFFDCFCE7), fg: AppColors.successDark),
      if (_p.distanceKm != null)
        _chip(
          label: _en ? '${_p.distance} away' : _p.distance,
          icon: Icons.location_on_outlined,
          bg: AppColors.borderLight,
          fg: AppColors.slateDark,
        ),
    ];
    if (chips.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Wrap(spacing: 6, runSpacing: 6, children: chips),
    );
  }

  // --------------------------------------------------------------- identity

  Widget _avatar() {
    const size = 82.0;
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            width: size,
            height: size,
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white,
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.14), blurRadius: 12, offset: const Offset(0, 4))],
            ),
            child: ClipOval(
              child: _avatarImage != null
                  ? AppImage(_avatarImage!, fit: BoxFit.cover, errorBuilder: (_, _, _) => _avatarFallback())
                  : _avatarFallback(),
            ),
          ),
          if (_p.isOnline)
            Positioned(
              right: 3,
              bottom: 5,
              child: Container(
                width: 16,
                height: 16,
                decoration: BoxDecoration(
                  color: AppColors.onlineGreen,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 2.5),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _avatarFallback() => Container(
        color: AppColors.primary,
        alignment: Alignment.center,
        child: Text(_initial, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800, color: Colors.white)),
      );

  /// Avatar overlapping the cover with jobs / rating / reviews beside it, then name and chips.
  Widget _identity() {
    final cells = <MapEntry<String, String>>[
      if ((_p.completedJobs ?? 0) > 0) MapEntry('${_p.completedJobs}', _en ? 'Jobs done' : 'Kazi'),
      MapEntry(_p.hasReviews ? _p.ratingText : (_en ? 'New' : 'Mpya'), _en ? 'Rating' : 'Ukadiriaji'),
      if (_p.hasReviews) MapEntry('${_p.reviewsCount}', _en ? 'Reviews' : 'Maoni'),
    ];
    if (cells.length < 3) cells.add(MapEntry('${_services.length}', _en ? (_services.length == 1 ? 'Service' : 'Services') : 'Huduma'));
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: 50,
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                Positioned(left: 0, top: -41, child: _avatar()),
                Positioned(
                  left: 98,
                  right: 0,
                  top: 8,
                  child: Row(
                    children: [
                      for (final c in cells.take(3))
                        Expanded(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(c.key, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.navy)),
                              const SizedBox(height: 1),
                              Text(c.value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                            ],
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Row(
            children: [
              Flexible(
                child: Text(
                  _name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: AppColors.navy, letterSpacing: -0.4),
                ),
              ),
              if (_p.isVerified) ...[
                const SizedBox(width: 6),
                VerificationBadge(level: _p.verificationLevel, size: 18),
              ],
            ],
          ),
          _chips(),
        ],
      ),
    );
  }

  String get _bio => (_isMine && SessionManager.getBio().isNotEmpty)
      ? SessionManager.getBio()
      : (_p.sellerBio ?? '').trim().isNotEmpty
      ? _p.sellerBio!.trim()
      : '';

  /// Short bio (three lines) with a "more" link that opens the About tab. Left out when there is no bio.
  Widget _bioBlock() {
    final bio = _bio;
    if (bio.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          WhatsAppText(
            bio,
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 13, height: 1.45, color: AppColors.slateMuted),
          ),
          if (bio.length > 110)
            GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => setState(() => _tab = 3),
              child: Padding(
                padding: const EdgeInsets.only(top: 2),
                child: Text(_en ? 'more' : 'zaidi', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textSecondary)),
              ),
            ),
        ],
      ),
    );
  }

  /// Message and Call, under the bio (never on your own profile).
  Widget _contactButtons() {
    Widget btn(IconData icon, String label, VoidCallback onTap) => Expanded(
          child: SizedBox(
            height: 42,
            child: OutlinedButton.icon(
              onPressed: onTap,
              icon: Icon(icon, size: 18, color: AppColors.primary),
              label: Text(label, style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: AppColors.primary)),
              style: OutlinedButton.styleFrom(
                backgroundColor: AppColors.surface,
                side: const BorderSide(color: AppColors.border),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
        );
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Row(
        children: [
          btn(Icons.chat_bubble_outline_rounded, _en ? 'Message' : 'Ujumbe',
              () => ChatThreadScreen.open(context, recipientId: _p.sellerId, name: _p.stageName, isOnline: _p.isOnline)),
          const SizedBox(width: 8),
          btn(Icons.phone_outlined, _en ? 'Call' : 'Piga simu', () => CallOptionsSheet.show(context, _p)),
        ],
      ),
    );
  }

  Future<void> _shareProfile() => ShareService.showServiceSheet(
        context,
        title: _p.title,
        priceText: _p.priceText,
        providerName: _name,
        category: _p.category,
        serviceId: _p.id,
      );

  /// Block / unblock / report menu (never on your own profile).
  Widget _moderationMenu() {
    return ValueListenableBuilder<int>(
      valueListenable: BlockService.changed,
      builder: (ctx, _, _) {
        final id = _sellerId!;
        final blocked = BlockService.isBlocked(id);
        return Padding(
          padding: const EdgeInsets.all(6),
          child: Material(
            color: Colors.black.withValues(alpha: 0.38),
            shape: const CircleBorder(),
            child: PopupMenuButton<String>(
              padding: EdgeInsets.zero,
              icon: const Icon(Icons.more_vert_rounded, color: Colors.white, size: 20),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              onSelected: (choice) async {
                if (choice == 'report') {
                  final out = await ReportSheet.show(context, target: ReportTarget.user, userId: id, name: _p.stageName);
                  if (out.blocked && context.mounted) Navigator.pop(context);
                  return;
                }
                if (!SessionManager.isLoggedIn()) {
                  final ok = await LoginModal.show(context);
                  if (ok != true || !context.mounted) return;
                }
                if (!context.mounted) return;
                if (blocked) {
                  await BlockUserDialog.confirmUnblock(context, userId: id, name: _p.stageName);
                } else {
                  final done = await BlockUserDialog.confirmBlock(context, userId: id, name: _p.stageName);
                  if (done && context.mounted) Navigator.pop(context);
                }
              },
              itemBuilder: (_) => [
                PopupMenuItem(
                  value: 'toggle',
                  child: Row(
                    children: [
                      Icon(blocked ? Icons.lock_open_rounded : Icons.block_rounded,
                          size: 18, color: blocked ? AppColors.primary : AppColors.danger),
                      const SizedBox(width: 10),
                      Text(
                        blocked ? (_en ? 'Unblock user' : 'Mfungulie mtumiaji') : (_en ? 'Block user' : 'Mzuie mtumiaji'),
                        style: TextStyle(fontWeight: FontWeight.w600, color: blocked ? AppColors.primary : AppColors.danger),
                      ),
                    ],
                  ),
                ),
                PopupMenuItem(
                  value: 'report',
                  child: Row(
                    children: [
                      const Icon(Icons.flag_outlined, size: 18, color: AppColors.textSecondary),
                      const SizedBox(width: 10),
                      Text(
                        _en ? 'Report user' : 'Ripoti mtumiaji',
                        style: const TextStyle(fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ------------------------------------------------------------------- tabs

  Widget _tabBar() {
    final tabs = <(IconData, String)>[
      (Icons.view_agenda_outlined, _en ? 'Services' : 'Huduma'),
      (Icons.grid_view_rounded, _en ? 'Portfolio' : 'Kazi'),
      (Icons.star_border_rounded, _en ? 'Reviews' : 'Maoni'),
      (Icons.info_outline_rounded, _en ? 'About' : 'Kuhusu'),
    ];
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.surface,
        border: Border(bottom: BorderSide(color: AppColors.border)),
      ),
      child: Row(
        children: [
          for (var i = 0; i < tabs.length; i++)
            Expanded(
              child: InkWell(
                onTap: () => setState(() => _tab = i),
                child: Container(
                  padding: const EdgeInsets.only(top: 9, bottom: 7),
                  decoration: BoxDecoration(
                    border: Border(bottom: BorderSide(color: _tab == i ? AppColors.primary : Colors.transparent, width: 2)),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(tabs[i].$1, size: 21, color: _tab == i ? AppColors.primary : AppColors.textMuted),
                      const SizedBox(height: 3),
                      Text(
                        tabs[i].$2,
                        style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: _tab == i ? AppColors.primary : AppColors.textMuted),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _tabBody() {
    switch (_tab) {
      case 1:
        return _portfolioTab();
      case 2:
        return _reviewsTab();
      case 3:
        return _aboutTab();
      default:
        return ValueListenableBuilder<int>(
          valueListenable: SessionManager.sessionNotifier,
          builder: (context, _, _) => _servicesTab(),
        );
    }
  }

  Widget _card({required Widget child, VoidCallback? onTap, EdgeInsets margin = const EdgeInsets.fromLTRB(20, 8, 20, 0)}) {
    return Padding(
      padding: margin,
      child: Material(
        color: AppColors.surface,
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: const BorderSide(color: AppColors.border)),
        child: InkWell(onTap: onTap, child: Padding(padding: const EdgeInsets.all(14), child: child)),
      ),
    );
  }

  Widget _empty(IconData icon, String title, String hint) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(32, 36, 32, 12),
      child: Column(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: const BoxDecoration(color: AppColors.primaryLight, shape: BoxShape.circle),
            child: Icon(icon, color: AppColors.primary, size: 26),
          ),
          const SizedBox(height: 12),
          Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
          const SizedBox(height: 4),
          Text(hint, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textSecondary)),
        ],
      ),
    );
  }

  Widget _sectionTitle(String text) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 2),
        child: Text(text, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
      );

  // --------------------------------------------------------------- services

  /// Services tab: list cards (photo on the left), then a dashed "See all N services" button.
  Widget _servicesTab() {
    final all = _visibleServices;
    final list = all.take(3).toList();
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
      child: Column(
        children: [
          for (var i = 0; i < list.length; i++) ...[
            _serviceCard(list[i]),
            // AdMob native ad after the 2nd service (only when there are 3+ services)
            if (i == 1 && list.length > 2) const NativeAdRow(page: AdPage.providerProfile, padding: EdgeInsets.only(bottom: 8)),
          ],
          if (all.length > 3)
            GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: _openAllServices,
              child: CustomPaint(
                painter: const _DashedBorderPainter(color: Color(0xFFBFD3F5)),
                child: Container(
                  height: 44,
                  alignment: Alignment.center,
                  child: Text(
                    _en ? 'See all ${all.length} services' : 'Ona huduma zote ${all.length}',
                    style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: AppColors.primary),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  /// Boosted / discount label on the corner of the service photo.
  Widget _thumbBadge(String text, Color bg) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(5)),
        child: Text(text, style: const TextStyle(fontSize: 8.5, fontWeight: FontWeight.w800, color: Colors.white)),
      );

  /// List card: 80px photo on the left (Boosted / discount on it), then title, duration and price
  /// type, and the price with the Request button at the bottom. Has no flex children, so it works
  /// both on the profile and in the "See all" list.
  Widget _serviceCard(ServiceItem s) {
    final thumb = s.imageUrls.isNotEmpty ? s.imageUrls.first : null;
    final ptype = _priceTypeLabel(s);
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Material(
        color: Colors.transparent,
        clipBehavior: Clip.antiAlias,
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ServiceDetailsScreen(service: s))),
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: SizedBox(
                    width: 80,
                    height: 80,
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        thumb != null
                            ? AppImage(thumb, fit: BoxFit.cover, errorBuilder: (_, _, _) => _thumbFallback(s))
                            : _thumbFallback(s),
                        if (s.hasDiscount || s.isBoosted)
                          Positioned(
                            top: 4,
                            left: 4,
                            right: 4,
                            child: Wrap(
                              spacing: 3,
                              runSpacing: 3,
                              children: [
                                if (s.isBoosted) _thumbBadge(_en ? 'Boosted' : 'Imeboostiwa', AppColors.warning),
                                if (s.hasDiscount) _thumbBadge('-${s.discountPercentShown}%', AppColors.successDark),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 11),
                Expanded(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(minHeight: 80),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: Text(
                                    s.title,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: AppColors.navy, height: 1.25),
                                  ),
                                ),
                                Transform.translate(offset: const Offset(4, -6), child: _serviceMenu(s)),
                              ],
                            ),
                            if (s.hasDuration || ptype != null)
                              Padding(
                                padding: const EdgeInsets.only(top: 2),
                                child: Wrap(
                                  crossAxisAlignment: WrapCrossAlignment.center,
                                  spacing: 8,
                                  children: [
                                    if (s.hasDuration)
                                      Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          const Icon(Icons.schedule_rounded, size: 12, color: AppColors.textSecondary),
                                          const SizedBox(width: 4),
                                          Text(s.durationText, style: const TextStyle(fontSize: 11.5, color: AppColors.textSecondary)),
                                        ],
                                      ),
                                    if (ptype != null) Text(ptype, style: const TextStyle(fontSize: 11.5, color: AppColors.textMuted)),
                                  ],
                                ),
                              ),
                            if (s.is18Plus) ...[
                              const SizedBox(height: 4),
                              const SensitiveTag(compact: true),
                            ],
                          ],
                        ),
                        const SizedBox(height: 6),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  if (s.hasDiscount)
                                    Text(s.listedPriceText, style: const TextStyle(fontSize: 10.5, color: AppColors.textMuted, decoration: TextDecoration.lineThrough)),
                                  Text(
                                    s.priceText,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.navy, letterSpacing: -0.2),
                                  ),
                                ],
                              ),
                            ),
                            if (!_isMine) ...[
                              const SizedBox(width: 8),
                              FilledButton(
                                onPressed: () => _book(s),
                                style: FilledButton.styleFrom(
                                  backgroundColor: AppColors.primary,
                                  minimumSize: Size.zero,
                                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
                                ),
                                child: Text(_en ? 'Request' : 'Omba', style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700)),
                              ),
                            ],
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _thumbFallback(ServiceItem s) => Container(
        color: s.themeColor.withValues(alpha: 0.18),
        alignment: Alignment.center,
        child: Icon(s.icon, color: s.themeColor, size: 30),
      );

  // -------------------------------------------------------------- portfolio

  static const int _maxVideoMb = 100;

  void _snack(String msg, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: error ? AppColors.danger : null));
  }

  Future<void> _addPhoto() async {
    if (_uploading) return;
    final f = await MediaPicker.pickImage(
      context,
      title: _en ? 'Add a photo to your portfolio' : 'Ongeza picha kwenye kazi zako',
      maxWidth: 1600,
    );
    if (f == null || !mounted) return;
    await _upload(f.path, video: false);
  }

  Future<void> _addVideo() async {
    if (_uploading) return;
    XFile? f;
    try {
      f = await ImagePicker().pickVideo(source: ImageSource.gallery);
    } catch (_) {
      _snack(_en ? 'Could not open the video picker' : 'Imeshindikana kufungua video', error: true);
      return;
    }
    if (f == null || !mounted) return;
    if (await f.length() > _maxVideoMb * 1024 * 1024) {
      _snack(_en ? 'Video is too large. Maximum is $_maxVideoMb MB.' : 'Video ni kubwa mno. Kiwango cha juu ni MB $_maxVideoMb.', error: true);
      return;
    }
    await _upload(f.path, video: true);
  }

  Future<void> _upload(String path, {required bool video}) async {
    setState(() {
      _uploading = true;
      _uploadProgress = 0;
    });
    final res = await ApiService.uploadPortfolioItem(
      path,
      video: video,
      onProgress: (p) {
        if (mounted) setState(() => _uploadProgress = p);
      },
    );
    if (!mounted) return;
    setState(() => _uploading = false);
    if (res.ok) {
      await _loadPortfolio();
    } else {
      _snack(res.error ?? (_en ? 'Not uploaded. Try again.' : 'Haikupakiwa. Jaribu tena.'), error: true);
    }
  }

  Future<void> _confirmDelete(PortfolioItem it) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(it.isVideo ? (_en ? 'Remove this video?' : 'Ondoa video hii?') : (_en ? 'Remove this photo?' : 'Ondoa picha hii?')),
        content: Text(_en ? 'It will be removed from your portfolio for good.' : 'Itaondolewa kwenye kazi zako moja kwa moja.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(_en ? 'Cancel' : 'Ghairi')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(_en ? 'Remove' : 'Ondoa', style: const TextStyle(color: AppColors.danger)),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    final done = await ApiService.deletePortfolioItem(it.id);
    if (!mounted) return;
    if (done) {
      setState(() => _portfolio = _portfolio?.where((x) => x.id != it.id).toList());
    } else {
      _snack(_en ? 'Could not remove it. Try again.' : 'Imeshindikana kuondoa. Jaribu tena.', error: true);
    }
  }

  Widget _portfolioAddBar() {
    final items = _portfolio ?? const <PortfolioItem>[];
    final photos = items.where((i) => !i.isVideo).length;
    final videos = items.length - photos;
    Widget btn(IconData icon, String label, VoidCallback? onTap) => Expanded(
          child: OutlinedButton.icon(
            onPressed: onTap,
            icon: Icon(icon, size: 18),
            label: Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
          ),
        );
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            btn(Icons.add_photo_alternate_outlined, _en ? 'Add photo' : 'Ongeza picha', _uploading || photos >= 40 ? null : _addPhoto),
            const SizedBox(width: 10),
            btn(Icons.video_call_outlined, _en ? 'Add video' : 'Ongeza video', _uploading || videos >= 10 ? null : _addVideo),
          ]),
          const SizedBox(height: 6),
          if (_uploading)
            LinearProgressIndicator(value: _uploadProgress > 0 && _uploadProgress < 1 ? _uploadProgress : null)
          else
            Text(
              _en ? '$photos/40 photos  •  $videos/10 videos  •  Press and hold to remove' : '$photos/40 picha  •  $videos/10 video  •  Shikilia ili kuondoa',
              style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
            ),
        ],
      ),
    );
  }

  Widget _portfolioTab() {
    final items = _portfolio;
    if (items == null) {
      if (_portfolioFailed) {
        return _empty(
          Icons.cloud_off_outlined,
          _en ? 'Could not load the portfolio' : 'Imeshindikana kupakia kazi',
          _en ? 'Check your internet and open this tab again.' : 'Angalia mtandao kisha fungua tena.',
        );
      }
      return const Padding(padding: EdgeInsets.all(36), child: Center(child: CircularProgressIndicator()));
    }
    final photoUrls = [for (final i in items) if (!i.isVideo) i.url];
    final grid = items.isEmpty
        ? _empty(
            Icons.photo_library_outlined,
            _en ? 'No photos or videos yet' : 'Hakuna picha wala video bado',
            _isMine
                ? (_en ? 'Show your best work. Add photos and videos with the buttons above.' : 'Onyesha kazi zako bora. Ongeza picha na video kwa vitufe vilivyo juu.')
                : (_en ? 'This provider has not added any work yet.' : 'Mtoa huduma huyu hajaongeza kazi bado.'),
          )
        : Padding(
            padding: const EdgeInsets.only(top: 8),
            child: GridView.builder(
              shrinkWrap: true,
              padding: EdgeInsets.zero,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: items.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 2, mainAxisSpacing: 2, childAspectRatio: 1),
              itemBuilder: (_, n) {
                final it = items[n];
                final onHold = _isMine ? () => _confirmDelete(it) : null;
                if (!it.isVideo) {
                  return GestureDetector(
                    onTap: () => FullscreenImageViewer.open(context, images: photoUrls, initialIndex: photoUrls.indexOf(it.url)),
                    onLongPress: onHold,
                    child: AppImage(
                      it.url,
                      fit: BoxFit.cover,
                      errorBuilder: (_, _, _) => Container(color: AppColors.border, child: const Icon(Icons.broken_image_outlined, color: AppColors.textMuted)),
                    ),
                  );
                }
                return GestureDetector(
                  onTap: () => VideoPlayerScreen.open(context, url: it.url, title: it.caption ?? _name),
                  onLongPress: onHold,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Container(
                        color: AppColors.slateDark,
                        alignment: Alignment.center,
                        child: const Icon(Icons.videocam_rounded, color: Colors.white24, size: 28),
                      ),
                      Positioned(
                        top: 5,
                        right: 5,
                        child: Container(
                          width: 20,
                          height: 20,
                          decoration: BoxDecoration(color: Colors.black.withValues(alpha: 0.6), shape: BoxShape.circle),
                          child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 14),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          );
    return Column(children: [if (_isMine) _portfolioAddBar(), grid]);
  }

  // ---------------------------------------------------------------- reviews

  _ReviewData _parseReview(dynamic j) {
    if (j is! Map) return const _ReviewData(name: '', rating: 0, comment: '');
    final who = j['reviewer'] ?? j['buyer'] ?? j['user'] ?? j['author'] ?? const {};
    String name = '';
    if (who is Map) name = '${who['stageName'] ?? who['name'] ?? who['username'] ?? ''}'.trim();
    if (name.isEmpty) name = '${j['reviewerName'] ?? j['buyerName'] ?? j['name'] ?? ''}'.trim();
    final r = j['rating'] ?? j['stars'] ?? j['score'];
    final rating = r is num ? r.toDouble() : (double.tryParse('$r') ?? 0);
    final comment = '${j['comment'] ?? j['text'] ?? j['review'] ?? j['message'] ?? ''}'.trim();
    final date = DateTime.tryParse('${j['createdAt'] ?? j['date'] ?? ''}');
    final svcRaw = j['serviceTitle'] ?? j['serviceName'] ?? j['service'];
    final service = svcRaw is Map ? '${svcRaw['title'] ?? svcRaw['name'] ?? ''}'.trim() : '${svcRaw ?? ''}'.trim();
    return _ReviewData(name: name, rating: rating, comment: comment, date: date, service: service == 'null' ? '' : service);
  }

  Widget _stars(double rating, {double size = 14}) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(
        5,
        (i) => Icon(i < rating.round() ? Icons.star_rounded : Icons.star_outline_rounded, size: size, color: AppColors.goldStar),
      ),
    );
  }

  Widget _reviewsTab() {
    return FutureBuilder<List<dynamic>?>(
      future: _reviewsFuture,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Padding(
            padding: EdgeInsets.all(40),
            child: Center(child: CircularProgressIndicator(color: AppColors.primary)),
          );
        }
        final list = snap.data?.map(_parseReview).where((r) => r.comment.isNotEmpty || r.rating > 0).toList();
        return Column(
          children: [
            if (_p.hasReviews)
              _card(
                child: Row(
                  children: [
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(_p.ratingText, style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w900, color: AppColors.textPrimary, letterSpacing: -1, height: 1)),
                        const SizedBox(height: 6),
                        _stars(_p.rating, size: 15),
                        const SizedBox(height: 4),
                        Text(
                          _en ? '${_p.reviewsCount} ${_p.reviewsCount == 1 ? 'review' : 'reviews'}' : 'Maoni ${_p.reviewsCount}',
                          style: const TextStyle(fontSize: 11.5, color: AppColors.textSecondary),
                        ),
                      ],
                    ),
                    // Breakdown from the reviews actually loaded (no invented numbers).
                    if (list != null && list.where((r) => r.rating > 0).isNotEmpty) ...[
                      const SizedBox(width: 18),
                      Expanded(child: _ratingBars(list)),
                    ],
                  ],
                ),
              ),
            if (list != null && list.isEmpty && !_p.hasReviews)
              _empty(
                Icons.rate_review_outlined,
                _en ? 'No reviews yet' : 'Hakuna maoni bado',
                _en ? 'Reviews appear here after customers complete a booking.' : 'Maoni yataonekana hapa baada ya wateja kukamilisha oda.',
              ),
            if (list == null)
              _card(
                child: Row(
                  children: [
                    const Icon(Icons.cloud_off_rounded, color: AppColors.textSecondary),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        _en ? 'Reviews could not be loaded right now.' : 'Maoni hayakuweza kupakiwa kwa sasa.',
                        style: const TextStyle(fontSize: 12.5, color: AppColors.textSecondary),
                      ),
                    ),
                    TextButton(
                      onPressed: () => setState(_loadReviews),
                      child: Text(_en ? 'Retry' : 'Jaribu tena'),
                    ),
                  ],
                ),
              ),
            if (list != null)
              for (final r in list) _reviewCard(r),
          ],
        );
      },
    );
  }

  Widget _ratingBars(List<_ReviewData> list) {
    final rated = list.where((r) => r.rating > 0).toList();
    final total = rated.length;
    return Column(
      children: [
        for (var star = 5; star >= 1; star--)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Row(
              children: [
                SizedBox(width: 12, child: Text('$star', style: const TextStyle(fontSize: 11, color: AppColors.textSecondary))),
                const SizedBox(width: 6),
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(3),
                    child: LinearProgressIndicator(
                      minHeight: 5,
                      value: rated.where((r) => r.rating.round() == star).length / total,
                      color: AppColors.goldStar,
                      backgroundColor: AppColors.borderLight,
                    ),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }

  Widget _reviewCard(_ReviewData r) {
    final name = r.name.isEmpty ? (_en ? 'Customer' : 'Mteja') : r.name;
    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 18,
                backgroundColor: AppColors.primaryLight,
                child: Text(name.substring(0, 1).toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary)),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(name, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                    if (r.date != null) Text(_dateText(r.date!), style: const TextStyle(fontSize: 11, color: AppColors.textMuted)),
                  ],
                ),
              ),
              if (r.rating > 0) _stars(r.rating),
            ],
          ),
          if (r.service.isNotEmpty) ...[
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(color: AppColors.primaryLight, borderRadius: BorderRadius.circular(10)),
              child: Text(r.service, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, color: AppColors.primary)),
            ),
          ],
          if (r.comment.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(r.comment, style: const TextStyle(fontSize: 13, height: 1.45, color: AppColors.slateMuted)),
          ],
        ],
      ),
    );
  }

  // ------------------------------------------------------------------ about

  Widget _aboutTab() {
    final bio = _bio;

    final details = <MapEntry<IconData, MapEntry<String, String>>>[
      if (_p.sellerSince != null) MapEntry(Icons.event_available_outlined, MapEntry(_en ? 'Member since' : 'Mwanachama tangu', _monthYear(_p.sellerSince!))),
    ];

    return Column(
      children: [
        _card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(_en ? 'About' : 'Kuhusu', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
              const SizedBox(height: 8),
              WhatsAppText(
                bio.isNotEmpty ? bio : (_en ? 'This provider has not written a bio yet.' : 'Mtoa huduma bado hajaandika maelezo yake.'),
                style: TextStyle(fontSize: 13, height: 1.5, color: bio.isNotEmpty ? AppColors.slateMuted : AppColors.textMuted),
              ),
            ],
          ),
        ),
        _card(
          child: Column(
            children: [
              for (var i = 0; i < details.length; i++) ...[
                if (i > 0) const Divider(height: 18, color: AppColors.borderLight),
                Row(
                  children: [
                    Icon(details[i].key, size: 18, color: AppColors.primary),
                    const SizedBox(width: 10),
                    Expanded(child: Text(details[i].value.key, style: const TextStyle(fontSize: 12.5, color: AppColors.textSecondary))),
                    const SizedBox(width: 8),
                    Flexible(
                      child: Text(details[i].value.value,
                          textAlign: TextAlign.right, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
        ProviderContactCard(provider: _p),
        _card(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.shield_outlined, size: 20, color: AppColors.successDark),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  _en
                      ? 'Stay safe: book and pay through the app so your payment is protected by escrow. Report anyone who asks you to pay outside it.'
                      : 'Kaa salama: weka oda na ulipe kupitia app ili malipo yako yalindwe na escrow. Ripoti yeyote anayekuomba ulipe nje ya app.',
                  style: const TextStyle(fontSize: 12, height: 1.45, color: AppColors.textSecondary),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ------------------------------------------------------------- action bar

  Widget _actionBar() {
    // "Starting from" is the cheapest visible service, and the button books that same service.
    final list = _visibleServices;
    final target = list.isEmpty ? _p : list.reduce((a, b) => a.priceAmount <= b.priceAmount ? a : b);
    final label = list.length > 1 ? (_en ? 'Starting from' : 'Kuanzia') : (_priceTypeLabel(target) ?? (_en ? 'Price' : 'Bei'));
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.surface,
        border: Border(top: BorderSide(color: AppColors.border)),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
          child: Row(
            children: [
              Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                  Text(target.priceText, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.navy, letterSpacing: -0.3)),
                ],
              ),
              const SizedBox(width: 14),
              Expanded(
                child: SizedBox(
                  height: 48,
                  child: FilledButton(
                    onPressed: () => _book(target),
                    style: FilledButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    child: Text(
                      _en ? 'Request Service' : 'Omba Huduma',
                      style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ReviewData {
  final String name;
  final double rating;
  final String comment;
  final DateTime? date;
  final String service;
  const _ReviewData({required this.name, required this.rating, required this.comment, this.date, this.service = ''});
}

/// Dashed rounded outline for the "See all services" button.
class _DashedBorderPainter extends CustomPainter {
  final Color color;
  const _DashedBorderPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final rrect = RRect.fromRectAndRadius(Offset.zero & size, const Radius.circular(12));
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    for (final metric in (Path()..addRRect(rrect)).computeMetrics()) {
      var d = 0.0;
      while (d < metric.length) {
        canvas.drawPath(metric.extractPath(d, d + 6), paint);
        d += 10;
      }
    }
  }

  @override
  bool shouldRepaint(_DashedBorderPainter old) => old.color != color;
}
