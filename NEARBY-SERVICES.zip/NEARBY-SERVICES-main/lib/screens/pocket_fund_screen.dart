import '../services/app_policy.dart';
import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../widgets/skeleton_loader.dart';
import '../services/data_sync.dart';
import '../services/payment_methods_service.dart';
import 'top_up_screen.dart';
import 'withdraw_screen.dart';
import 'wallet_history_screen.dart';
import '../services/currency_service.dart';

class PocketFundScreen extends StatefulWidget {
  final bool showBackButton;
  const PocketFundScreen({super.key, this.showBackButton = true});

  @override
  State<PocketFundScreen> createState() => _PocketFundScreenState();
}

class _PocketFundScreenState extends State<PocketFundScreen> {
  double _balance = 0.0;
  bool _isLoading = false;
  String _selectedPaymentMethod = ''; // only the method the user saved as default

  final List<Map<String, dynamic>> _paymentMethods = [
    {
      'id': 'Mpesa',
      'title': 'Mpesa',
      'subtitle': 'No number saved',
      'icon': Icons.phone_android_rounded,
      'color': const Color(0xFF10B981),
      'connected': false,
    },
    {
      'id': 'Airtel',
      'title': 'Airtel Money',
      'subtitle': 'No number saved',
      'icon': Icons.sim_card_outlined,
      'color': const Color(0xFFEF4444),
      'connected': false,
    },
    {
      'id': 'Tigo',
      'title': 'Tigo Pesa',
      'subtitle': 'No number saved',
      'icon': Icons.swap_horiz_rounded,
      'color': const Color(0xFF3B82F6),
      'connected': false,
    },
    if (AppPolicy.cardPaymentsEnabled)
    {
      'id': 'Card',
      'title': 'Card',
      'subtitle': 'No number saved',
      'icon': Icons.credit_card_rounded,
      'color': const Color(0xFF6B7280),
      'connected': false,
    },
  ];

  List<WalletTx> _recentTransactions = [];

  // Something was written to the server elsewhere (booking, accept, wallet, review...): re-fetch.
  void _onDataChanged() {
    if (mounted) _loadWalletData(silent: true);
  }

  @override
  void dispose() {
    DataSync.changed.removeListener(_onDataChanged);
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    DataSync.changed.addListener(_onDataChanged);
    _loadWalletData();
  }

  /// [silent] keeps the page on screen (pull-to-refresh, the refresh button, background changes) instead of the skeleton.
  Future<void> _loadWalletData({bool silent = false}) async {
    if (!silent) setState(() => _isLoading = true);
    final walletFuture = ApiService.getWallet();
    final txFuture = ApiService.fetchWalletTransactions(); // real wallet activity
    final numbersFuture = PaymentMethodsService.loadNumbers();
    final defaultFuture = PaymentMethodsService.loadDefault();

    final results = await Future.wait([walletFuture, txFuture, numbersFuture, defaultFuture]);
    final wallet = results[0] as Map<String, dynamic>?;
    final txList = results[1] as List<dynamic>?;
    final numbers = results[2] as Map<String, String>;
    final defaultId = results[3] as String?;

    // Wallet activity (top ups, withdrawals, bookings, refunds). When it cannot be loaded,
    // fall back to the bookings the user paid for, as the History page does.
    List<WalletTx> recent;
    if (txList != null) {
      recent = [for (final e in txList) if (e is Map) WalletTx.fromWallet(Map<String, dynamic>.from(e))];
    } else {
      final bookings = await ApiService.fetchBuyerTransactions();
      recent = [for (final e in bookings) if (e is Map) WalletTx.fromBooking(Map<String, dynamic>.from(e))];
    }
    final epoch = DateTime.fromMillisecondsSinceEpoch(0);
    recent.sort((a, b) => (b.date ?? epoch).compareTo(a.date ?? epoch));
    if (recent.length > 5) recent = recent.sublist(0, 5);

    if (mounted) {
      setState(() {
        if (wallet != null) {
          _balance = (wallet['balance'] as num?)?.toDouble() ?? 0.0;
        }
        _recentTransactions = recent;
        // Connected state comes from the numbers this user really saved.
        for (final m in _paymentMethods) {
          final saved = numbers[(m['id'] as String).toLowerCase()];
          m['connected'] = saved != null;
          m['subtitle'] = saved != null
              ? '${_en ? 'Saved number' : 'Namba imehifadhiwa'} • ${PaymentMethodsService.mask(saved)}'
              : (_en ? 'No number saved' : 'Hakuna namba iliyohifadhiwa');
        }
        final match = _paymentMethods.where((m) => (m['id'] as String).toLowerCase() == defaultId);
        if (match.isNotEmpty) _selectedPaymentMethod = match.first['id'] as String;
        _isLoading = false;
      });
    }
  }

  String _money(num v) => CurrencyService.format(v);

  bool get _en => AppStrings.isEnglish;

  static const _months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  String _dateText(DateTime? d) => d == null ? '' : '${d.day} ${_months[d.month - 1]} ${d.year}';

  String _kindLabel(WalletTxKind k) {
    switch (k) {
      case WalletTxKind.topUp:
        return _en ? 'Top up' : 'Kuweka pesa';
      case WalletTxKind.withdrawal:
        return _en ? 'Withdrawal' : 'Kutoa pesa';
      case WalletTxKind.refund:
        return _en ? 'Refund' : 'Marejesho';
      case WalletTxKind.booking:
        return _en ? 'Booking payment' : 'Malipo ya oda';
    }
  }

  IconData _kindIcon(WalletTxKind k) {
    switch (k) {
      case WalletTxKind.topUp:
        return Icons.add_circle_outline_rounded;
      case WalletTxKind.withdrawal:
        return Icons.account_balance_outlined;
      case WalletTxKind.refund:
        return Icons.replay_rounded;
      case WalletTxKind.booking:
        return Icons.event_available_outlined;
    }
  }

  Future<void> _openWithdraw() async {
    final done = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => WithdrawScreen(balance: _balance)),
    );
    if (done == true && mounted) _loadWalletData();
  }

  void _openHistory() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => const WalletHistoryScreen()));
  }

  Future<void> _openTopUp() async {
    final added = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => TopUpScreen(balance: _balance)),
    );
    if (added == true && mounted) _loadWalletData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: widget.showBackButton && Navigator.canPop(context)
            ? IconButton(
                icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
                onPressed: () => Navigator.pop(context),
              )
            : null,
        title: Text(
          _en ? 'Payment & Wallet' : 'Malipo na Pochi',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            color: AppColors.textPrimary,
          ),
        ),
        actions: [
          IconButton(
            tooltip: _en ? 'Refresh' : 'Onyesha upya',
            icon: const Icon(Icons.refresh_rounded, color: AppColors.textPrimary),
            onPressed: _isLoading ? null : () => _loadWalletData(silent: true),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: _isLoading
          ? const Padding(
              padding: EdgeInsets.all(16),
              child: VerticalListCardSkeleton(),
            )
          : RefreshIndicator(
              onRefresh: () => _loadWalletData(silent: true),
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Blue Wallet Card (Screen 6 100% fidelity)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: AppColors.primary,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.primary.withValues(alpha: 0.25),
                            blurRadius: 16,
                            offset: const Offset(0, 6),
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  const Icon(Icons.account_balance_wallet_outlined, color: Colors.white70, size: 16),
                                  const SizedBox(width: 6),
                                  Text(
                                    _en ? 'Wallet Balance' : 'Salio la Pochi',
                                    style: const TextStyle(color: Colors.white70, fontSize: 13, fontWeight: FontWeight.w500),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 6),
                              Text(
                                CurrencyService.format(_balance),
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 26,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: -0.5,
                                ),
                              ),
                            ],
                          ),
                          ElevatedButton(
                            onPressed: _openTopUp,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,
                              foregroundColor: AppColors.primary,
                              elevation: 0,
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                            ),
                            child: Text(_en ? 'Top Up' : 'Weka Pesa', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Quick Actions Row: Withdraw, History
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _buildQuickAction(
                          icon: Icons.account_balance_outlined,
                          label: AppStrings.isEnglish ? 'Withdraw' : 'Toa Pesa',
                          onTap: _openWithdraw,
                        ),
                        _buildQuickAction(
                          icon: Icons.history_rounded,
                          label: AppStrings.isEnglish ? 'History' : 'Historia',
                          onTap: _openHistory,
                        ),
                      ],
                    ),
                    const SizedBox(height: 26),

                    // Payment Methods Section
                    Text(
                      _en ? 'Payment Methods' : 'Njia za Malipo',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Container(
                      decoration: BoxDecoration(
                        color: AppColors.surface,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: AppColors.border),
                      ),
                      child: Column(
                        children: _paymentMethods.asMap().entries.map((entry) {
                          final idx = entry.key;
                          final m = entry.value;
                          final isSelected = _selectedPaymentMethod == m['id'];

                          return Column(
                            children: [
                              ListTile(
                                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
                                leading: Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: (m['color'] as Color).withValues(alpha: 0.12),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Icon(m['icon'] as IconData, color: m['color'] as Color, size: 22),
                                ),
                                title: Text(
                                  m['title'] as String,
                                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                                ),
                                subtitle: Text(
                                  m['subtitle'] as String,
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: m['connected'] == true ? AppColors.textSecondary : AppColors.textMuted,
                                  ),
                                ),
                                trailing: Container(
                                  width: 20,
                                  height: 20,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: isSelected ? AppColors.primary : AppColors.border,
                                      width: isSelected ? 6 : 2,
                                    ),
                                  ),
                                ),
                                onTap: () {
                                  setState(() => _selectedPaymentMethod = m['id'] as String);
                                  PaymentMethodsService.setDefault((m['id'] as String).toLowerCase());
                                },
                              ),
                              if (idx < _paymentMethods.length - 1)
                                const Divider(height: 1, indent: 64, color: AppColors.borderLight),
                            ],
                          );
                        }).toList(),
                      ),
                    ),
                    const SizedBox(height: 26),

                    // Recent Transactions Section Header
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          _en ? 'Recent Transactions' : 'Miamala ya Hivi Karibuni',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        GestureDetector(
                          onTap: _openHistory,
                          child: Text(
                            _en ? 'View All' : 'Tazama Zote',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: AppColors.primary,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),

                    // Recent Transactions List
                    if (_recentTransactions.isEmpty)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        child: Center(
                          child: Text(_en ? 'No transactions yet' : 'Hakuna miamala bado',
                              style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
                        ),
                      ),
                    ..._recentTransactions.map((tx) {
                      final sign = tx.incoming ? '+' : '-';
                      final color = tx.incoming ? AppColors.success : AppColors.danger;
                      final pending = tx.status.contains('PEND') || tx.status.contains('PROCESS') || tx.status.contains('AWAIT');
                      final failed = tx.status.contains('FAIL') || tx.status.contains('REJECT') || tx.status.contains('CANCEL');
                      final when = _dateText(tx.date);
                      return Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: AppColors.surface,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: AppColors.border),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                color: color.withValues(alpha: 0.12),
                                shape: BoxShape.circle,
                              ),
                              child: Icon(_kindIcon(tx.kind), size: 20, color: color),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    tx.title.isNotEmpty ? tx.title : _kindLabel(tx.kind),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w700,
                                      color: AppColors.textPrimary,
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    [if (tx.title.isNotEmpty) _kindLabel(tx.kind), if (when.isNotEmpty) when].join(' • '),
                                    style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                                  ),
                                ],
                              ),
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(
                                  '$sign${_money(tx.amount)}',
                                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: color),
                                ),
                                if (pending || failed)
                                  Text(
                                    pending ? (_en ? 'Pending' : 'Inasubiri') : (_en ? 'Failed' : 'Imeshindwa'),
                                    style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w700,
                                      color: pending ? AppColors.warningDark : AppColors.danger,
                                    ),
                                  ),
                              ],
                            ),
                          ],
                        ),
                      );
                    }),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _buildQuickAction({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: AppColors.surface,
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.border),
            ),
            child: Icon(icon, color: AppColors.primary, size: 22),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: AppColors.textPrimary,
            ),
          ),
        ],
      ),
    );
  }
}
