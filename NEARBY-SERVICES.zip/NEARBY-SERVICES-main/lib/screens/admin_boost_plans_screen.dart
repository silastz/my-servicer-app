import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../services/api_service.dart';
import '../widgets/admin_common.dart';

/// Admin: the boost price list. Server: GET /admin/boosts/plans -> [{id, days, price, active}],
/// POST /admin/boosts/plans {id, days, price, active}, PUT /admin/boosts/plans/{id} {days?, price?, active?}.
/// Changes apply to future purchases only.
class AdminBoostPlansScreen extends StatefulWidget {
  const AdminBoostPlansScreen({super.key});

  @override
  State<AdminBoostPlansScreen> createState() => _AdminBoostPlansScreenState();
}

class _AdminBoostPlansScreenState extends State<AdminBoostPlansScreen> {
  bool _loading = true;
  bool _forbidden = false;
  bool _failed = false;
  List<Map<String, dynamic>> _plans = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _failed = false;
    });
    final r = await ApiService.adminGetList('/admin/boosts/plans');
    if (!mounted) return;
    setState(() {
      _loading = false;
      _forbidden = r.forbidden;
      _failed = !r.forbidden && r.items == null;
      _plans = r.items ?? [];
    });
  }

  Future<void> _toggle(Map<String, dynamic> p, bool on) async {
    final res = await ApiService.adminSend('PUT', '/admin/boosts/plans/${Uri.encodeComponent('${p['id']}')}', {'active': on});
    if (!mounted) return;
    if (res.error != null) {
      adminSnack(context, res.error!);
      return;
    }
    setState(() => p['active'] = on);
  }

  Future<void> _editOrCreate([Map<String, dynamic>? p]) async {
    final isNew = p == null;
    final idCtrl = TextEditingController(text: isNew ? '' : '${p['id']}');
    final daysCtrl = TextEditingController(text: isNew ? '' : '${p['days']}');
    final priceCtrl = TextEditingController(text: isNew ? '' : '${p['price']}'.replaceAll(RegExp(r'\.0+$'), ''));
    String? err;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: Text(isNew ? adminT('New boost plan', 'Mpango mpya wa kutangaza') : adminT('Edit plan', 'Hariri mpango')),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
              controller: idCtrl,
              enabled: isNew,
              decoration: InputDecoration(labelText: adminT('Plan id (e.g. week)', 'Kitambulisho (mf. week)')),
            ),
            TextField(controller: daysCtrl, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: adminT('Days', 'Siku'))),
            TextField(
              controller: priceCtrl,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(labelText: adminT('Price', 'Bei'), errorText: err),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(adminT('Cancel', 'Ghairi'))),
            TextButton(
              onPressed: () {
                final days = int.tryParse(daysCtrl.text.trim());
                final price = num.tryParse(priceCtrl.text.trim());
                if ((isNew && idCtrl.text.trim().isEmpty) || days == null || days < 1 || price == null || price < 0) {
                  setS(() => err = adminT('Fill every field with valid numbers', 'Jaza kila sehemu kwa namba sahihi'));
                  return;
                }
                Navigator.pop(ctx, true);
              },
              child: Text(adminT('Save', 'Hifadhi')),
            ),
          ],
        ),
      ),
    );
    if (ok != true || !mounted) return;
    final body = <String, dynamic>{
      'days': int.parse(daysCtrl.text.trim()),
      'price': num.parse(priceCtrl.text.trim()),
    };
    final res = isNew
        ? await ApiService.adminSend('POST', '/admin/boosts/plans', {...body, 'id': idCtrl.text.trim().toLowerCase(), 'active': true})
        : await ApiService.adminSend('PUT', '/admin/boosts/plans/${Uri.encodeComponent('${p['id']}')}', body);
    if (!mounted) return;
    if (res.error != null) {
      adminSnack(context, res.error!);
      return;
    }
    adminSnack(context, adminT('Saved. Applies to future purchases.', 'Imehifadhiwa. Itatumika kwa manunuzi yajayo.'));
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final state = adminStateOrNull(
      loading: _loading,
      forbidden: _forbidden,
      failed: _failed,
      empty: _plans.isEmpty,
      onRetry: _load,
      emptyText: adminT('No boost plans yet. Tap + to add one.', 'Hakuna mpango bado. Bonyeza + kuongeza.'),
    );
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text(adminT('Boost plans', 'Mipango ya kutangaza'))),
      floatingActionButton: _forbidden ? null : FloatingActionButton(onPressed: () => _editOrCreate(), child: const Icon(Icons.add)),
      body: RefreshIndicator(
        onRefresh: _load,
        child: state != null
            ? ListView(children: [SizedBox(height: 400, child: state)])
            : ListView(padding: const EdgeInsets.only(bottom: 90), children: [
                for (final p in _plans)
                  Container(
                    margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                    padding: const EdgeInsets.fromLTRB(14, 8, 8, 8),
                    decoration: adminCardDecoration(),
                    child: Row(children: [
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('${p['id']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                          adminInfoLine(adminT('Days', 'Siku'), p['days']),
                          adminInfoLine(adminT('Price', 'Bei'), p['price']),
                        ]),
                      ),
                      IconButton(icon: const Icon(Icons.edit_outlined), onPressed: () => _editOrCreate(p)),
                      Switch(value: p['active'] == true, onChanged: (v) => _toggle(p, v)),
                    ]),
                  ),
              ]),
      ),
    );
  }
}
