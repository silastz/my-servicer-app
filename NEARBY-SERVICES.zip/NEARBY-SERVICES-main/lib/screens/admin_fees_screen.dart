import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../services/api_service.dart';
import '../widgets/admin_common.dart';

/// Admin: provider registration fee, free-listing quota, package and per-service fee.
/// Server: GET /admin/settings, PUT /admin/settings {sellerRegistrationFee, freeServicesQuota,
/// combinedPackageCount, packagePrice, serviceFee}.
class AdminFeesScreen extends StatefulWidget {
  const AdminFeesScreen({super.key});

  @override
  State<AdminFeesScreen> createState() => _AdminFeesScreenState();
}

class _AdminFeesScreenState extends State<AdminFeesScreen> {
  final _reg = TextEditingController();
  final _quota = TextEditingController();
  final _pkgCount = TextEditingController();
  final _pkgPrice = TextEditingController();
  final _svcFee = TextEditingController();
  // Support contacts the Help screen shows. Empty = not set, and the app hides it.
  final _supPhone = TextEditingController();
  final _supWhatsapp = TextEditingController();
  final _supEmail = TextEditingController();
  bool _loading = true;
  bool _forbidden = false;
  bool _failed = false;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    for (final c in [_reg, _quota, _pkgCount, _pkgPrice, _svcFee, _supPhone, _supWhatsapp, _supEmail]) {
      c.dispose();
    }
    super.dispose();
  }

  String _n(dynamic v) => v == null ? '' : (v is num && v == v.roundToDouble() ? v.toInt().toString() : v.toString());

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _failed = false;
    });
    final r = await ApiService.adminGetObject('/admin/settings');
    if (!mounted) return;
    final d = r.data;
    setState(() {
      _loading = false;
      _forbidden = r.forbidden;
      _failed = !r.forbidden && d == null;
      if (d != null) {
        _reg.text = _n(d['sellerRegistrationFee']);
        _quota.text = _n(d['freeServicesQuota']);
        _pkgCount.text = _n(d['combinedPackageCount']);
        _pkgPrice.text = _n(d['packagePrice']);
        _svcFee.text = _n(d['serviceFee']);
        _supPhone.text = (d['supportPhone'] ?? '').toString();
        _supWhatsapp.text = (d['supportWhatsapp'] ?? '').toString();
        _supEmail.text = (d['supportEmail'] ?? '').toString();
      }
    });
  }

  Future<void> _save() async {
    final reg = num.tryParse(_reg.text.trim());
    final quota = int.tryParse(_quota.text.trim());
    final cnt = int.tryParse(_pkgCount.text.trim());
    final price = num.tryParse(_pkgPrice.text.trim());
    final fee = num.tryParse(_svcFee.text.trim());
    if (reg == null || quota == null || cnt == null || price == null || fee == null || reg < 0 || quota < 0 || cnt < 0 || price < 0 || fee < 0) {
      adminSnack(context, adminT('Fill every box with a valid number.', 'Jaza kila kisanduku na namba sahihi.'));
      return;
    }
    setState(() => _saving = true);
    final res = await ApiService.adminSend('PUT', '/admin/settings', {
      'sellerRegistrationFee': reg,
      'freeServicesQuota': quota,
      'combinedPackageCount': cnt,
      'packagePrice': price,
      'serviceFee': fee,
      'supportPhone': _supPhone.text.trim(),
      'supportWhatsapp': _supWhatsapp.text.trim(),
      'supportEmail': _supEmail.text.trim(),
    });
    if (!mounted) return;
    setState(() => _saving = false);
    adminSnack(context, res.error ?? adminT('Saved', 'Imehifadhiwa'));
  }

  Widget _field(TextEditingController c, String label, {bool decimal = true}) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: TextField(
          controller: c,
          keyboardType: TextInputType.numberWithOptions(decimal: decimal),
          decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
        ),
      );

  Widget _text(TextEditingController c, String label, TextInputType type) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: TextField(
          controller: c,
          keyboardType: type,
          decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final state = adminStateOrNull(loading: _loading, forbidden: _forbidden, failed: _failed, empty: false, onRetry: _load);
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text(adminT('Registration & listing fees', 'Ada za usajili na matangazo'))),
      body: state ??
          ListView(padding: const EdgeInsets.all(16), children: [
            _field(_reg, adminT('Provider registration fee', 'Ada ya usajili wa mtoa huduma')),
            _field(_quota, adminT('Free services per provider', 'Huduma za bure kwa mtoa huduma'), decimal: false),
            _field(_pkgCount, adminT('Services in one package', 'Huduma katika kifurushi kimoja'), decimal: false),
            _field(_pkgPrice, adminT('Package price', 'Bei ya kifurushi')),
            _field(_svcFee, adminT('Fee per extra service', 'Ada ya huduma ya ziada')),
            const SizedBox(height: 8),
            Text(adminT('Support contacts (Help screen)', 'Mawasiliano ya msaada (skrini ya Msaada)'),
                style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text(adminT('Leave a box empty to use the server default (SUPPORT_* setting); with no default the contact is hidden in the app.', 'Acha kisanduku wazi kutumia chaguo-msingi la seva (SUPPORT_*); bila chaguo-msingi mawasiliano hayo yatafichwa kwenye app.'),
                style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
            const SizedBox(height: 10),
            _text(_supPhone, adminT('Support phone (e.g. +255...)', 'Simu ya msaada (mf. +255...)'), TextInputType.phone),
            _text(_supWhatsapp, adminT('Support WhatsApp (e.g. +255...)', 'WhatsApp ya msaada (mf. +255...)'), TextInputType.phone),
            _text(_supEmail, adminT('Support email', 'Barua pepe ya msaada'), TextInputType.emailAddress),
            const SizedBox(height: 4),
            ElevatedButton(
              onPressed: _saving ? null : _save,
              child: _saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : Text(adminT('Save', 'Hifadhi')),
            ),
          ]),
    );
  }
}
