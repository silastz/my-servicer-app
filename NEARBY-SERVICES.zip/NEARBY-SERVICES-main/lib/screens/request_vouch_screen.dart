import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/currency_service.dart';
import '../services/session_manager.dart';
import '../widgets/app_ui.dart';

/// Someone who is not verified yet asks a verified provider (Green or Blue) who knows them to
/// vouch for them. The provider approves in "Invite someone you trust"; the server then creates a
/// normal invitation for this person's phone, which they accept under "I have an invitation".
class RequestVouchScreen extends StatefulWidget {
  const RequestVouchScreen({super.key});

  @override
  State<RequestVouchScreen> createState() => _RequestVouchScreenState();
}

class _RequestVouchScreenState extends State<RequestVouchScreen> {
  final _phone = TextEditingController();
  bool _sending = false;
  bool _loading = true;
  List<Map<String, dynamic>>? _sent; // null = could not be loaded
  String? _error;

  bool get _isEn => AppStrings.isEnglish;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _phone.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final raw = await ApiService.fetchVouchRequests();
    if (!mounted) return;
    setState(() {
      _loading = false;
      _sent = raw == null
          ? null
          : [
              for (final e in raw)
                if (e['direction']?.toString().toUpperCase() != 'RECEIVED') e,
            ];
    });
  }

  /// Digits with the country code of the account (Tanzania by default): 0712... -> 255712...
  String _intlDigits(String raw) {
    final dial = CurrencyService.current.dial;
    var d = raw.replaceAll(RegExp(r'[^0-9]'), '');
    if (d.startsWith('00')) d = d.substring(2);
    if (d.startsWith('0')) d = '$dial${d.substring(1)}';
    if (d.length == CurrencyService.current.nationalLength) d = '$dial$d';
    return d;
  }

  Future<void> _send() async {
    if (_sending) return;
    final digits = _intlDigits(_phone.text);
    final mine = _intlDigits(SessionManager.getPhone());
    String? err;
    if (digits.length < 11 || digits.length > 15) {
      err = _isEn ? 'Enter a valid phone number.' : 'Weka namba sahihi ya simu.';
    } else if (mine.isNotEmpty && digits == mine) {
      err = _isEn ? 'You cannot ask yourself.' : 'Huwezi kujiomba mwenyewe.';
    }
    if (err != null) {
      setState(() => _error = err);
      return;
    }
    setState(() {
      _sending = true;
      _error = null;
    });
    final res = await ApiService.requestVouch(providerPhone: '+$digits');
    if (!mounted) return;
    setState(() {
      _sending = false;
      _error = res.ok ? null : res.error;
      if (res.ok) _phone.clear();
    });
    if (res.ok) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(_isEn ? 'Request sent. We will tell you when they answer.' : 'Ombi limetumwa. Tutakujulisha watakapojibu.'),
      ));
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _isEn ? 'Ask a verified provider' : 'Omba mtoa huduma aliyethibitishwa',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderLight, height: 1),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.primaryLight,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.primary.withValues(alpha: 0.2)),
              ),
              child: Text(
                _isEn
                    ? 'Know a verified provider (Green Badge or Blue) who trusts you? Ask them to vouch for you. If they approve, you get an invitation here and can accept it with one tap. Save your legal name and NIN in Identity Verification first.'
                    : 'Unamjua mtoa huduma aliyethibitishwa (Green Badge au Blue) anayekuamini? Mwombe akuthibitishe. Akikubali, utapata mwaliko hapa na unaweza kuukubali kwa kubonyeza mara moja. Hifadhi jina lako la kisheria na NIN kwenye Uthibitisho wa Utambulisho kwanza.',
                style: const TextStyle(fontSize: 12, height: 1.45, color: AppColors.textPrimary),
              ),
            ),
            const SizedBox(height: 16),
            AppTextField(
              controller: _phone,
              icon: Icons.phone_outlined,
              label: _isEn ? "Verified provider's phone number" : 'Namba ya simu ya mtoa huduma',
              hint: '0712 345 678',
              keyboardType: TextInputType.phone,
              errorText: _error,
              enabled: !_sending,
              inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9+ ]'))],
            ),
            const SizedBox(height: 12),
            AppButton.primary(
              label: _isEn ? 'Send request' : 'Tuma ombi',
              loading: _sending,
              onPressed: _sending ? null : _send,
            ),
            const SizedBox(height: 20),
            _sentList(),
          ],
        ),
      ),
    );
  }

  Widget _sentList() {
    if (_loading) {
      return const Center(child: Padding(padding: EdgeInsets.all(16), child: CircularProgressIndicator(color: AppColors.primary)));
    }
    final sent = _sent;
    if (sent == null) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          _isEn ? 'Your requests' : 'Maombi yako',
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        const SizedBox(height: 8),
        if (sent.isEmpty)
          Text(_isEn ? 'No requests yet.' : 'Bado hujaomba.', style: const TextStyle(fontSize: 12, color: AppColors.textSecondary))
        else
          Container(
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.border),
            ),
            child: Column(
              children: [
                for (var i = 0; i < sent.length; i++) ...[
                  _tile(sent[i]),
                  if (i < sent.length - 1) const Divider(height: 1, color: AppColors.borderLight),
                ],
              ],
            ),
          ),
      ],
    );
  }

  Widget _tile(Map<String, dynamic> r) {
    final name = (r['name'] ?? r['providerName'] ?? '').toString().trim();
    final phone = (r['phone'] ?? r['providerPhone'] ?? '').toString().trim();
    final status = (r['status'] ?? 'PENDING').toString().toUpperCase();
    final String label;
    final Color color;
    switch (status) {
      case 'APPROVED':
        label = _isEn ? 'Approved - accept your invitation' : 'Amekubali - kubali mwaliko wako';
        color = AppColors.successDark;
      case 'DECLINED':
        label = _isEn ? 'Declined' : 'Amekataa';
        color = AppColors.danger;
      case 'EXPIRED':
      case 'CANCELLED':
        label = _isEn ? 'Expired' : 'Umeisha muda';
        color = AppColors.textSecondary;
      default:
        label = _isEn ? 'Waiting for them' : 'Anamsubiri';
        color = AppColors.warningDark;
    }
    return ListTile(
      title: Text(
        name.isNotEmpty ? name : (phone.isNotEmpty ? phone : (_isEn ? 'Verified provider' : 'Mtoa huduma')),
        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
      ),
      subtitle: Padding(
        padding: const EdgeInsets.only(top: 4),
        child: Align(alignment: Alignment.centerLeft, child: StatusPill(text: label, color: color)),
      ),
    );
  }
}
