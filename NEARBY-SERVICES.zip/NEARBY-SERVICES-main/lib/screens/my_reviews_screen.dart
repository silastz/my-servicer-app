import 'package:flutter/material.dart';
import '../services/load_guard.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/app_rating_service.dart';
import '../services/session_manager.dart';
import '../widgets/app_ui.dart';
import '../services/data_sync.dart';

/// Reviews work both ways for every signed-in user:
/// - To review: completed bookings you have not rated yet
///   (providers rate the buyer, buyers rate the provider)
/// - Given: reviews you wrote
/// - Received: reviews the other side wrote about you
class MyReviewsScreen extends StatefulWidget {
  const MyReviewsScreen({super.key});

  @override
  State<MyReviewsScreen> createState() => _MyReviewsScreenState();
}

class _MyReviewsScreenState extends State<MyReviewsScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabs;
  bool _loading = true;
  List<Map<String, dynamic>> _given = [];
  List<Map<String, dynamic>> _received = [];
  List<Map<String, dynamic>> _toReview = [];

  bool get _isEn => AppStrings.isEnglish;
  bool get _isSeller => SessionManager.isSeller();

  /// The other person in a booking: buyer for providers, provider for buyers.
  String get _otherKey => _isSeller ? 'buyer' : 'seller';

  @override
  void initState() {
    super.initState();
    DataSync.changed.addListener(_onDataChanged);
    _tabs = TabController(length: 3, vsync: this);
    _load();
  }

  // Something was written to the server elsewhere (booking, accept, wallet, review...): re-fetch.
  void _onDataChanged() {
    if (mounted) _load(silent: true);
  }

  @override
  void dispose() {
    DataSync.changed.removeListener(_onDataChanged);
    _tabs.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> _maps(List<dynamic> list) =>
      [for (final e in list) if (e is Map) Map<String, dynamic>.from(e)];

  String _nameOf(Map? user, String fallback) =>
      (user?['stageName'] ?? user?['username'] ?? fallback).toString();

  final _guard = LoadGuard();
  bool _loadedOnce = false;

  Future<void> _load({bool silent = false, bool refresh = false}) async {
    final id = _guard.next();
    if (!(silent || refresh) || !_loadedOnce) setState(() => _loading = true);
    final results = await Future.wait([
      ApiService.fetchReviewsWrittenOrNull(),
      ApiService.fetchReviewsReceivedOrNull(),
      _isSeller ? ApiService.fetchSellerOrdersOrNull() : ApiService.fetchBuyerTransactionsOrNull(),
    ]);
    if (!mounted || !_guard.isLatest(id)) return; // a newer load is running
    if (results.any((r) => r == null)) {
      // Any failed request: keep what is on screen instead of showing half-empty data.
      setState(() => _loading = false);
      if (!silent || !_loadedOnce) showLoadFailed(context, _load);
      return;
    }
    final given = _maps(results[0]!);
    final received = _maps(results[1]!);
    final reviewedRefs = {for (final r in given) (r['transactionRef'] ?? '').toString()};
    final toReview = _maps(results[2]!).where((t) {
      final s = (t['status'] ?? '').toString().toUpperCase();
      final ref = (t['transactionRef'] ?? '').toString();
      return (s == 'COMPLETED' || s == 'RELEASED' || s == 'SATISFIED') && ref.isNotEmpty && !reviewedRefs.contains(ref);
    }).toList();
    _loadedOnce = true;
    setState(() {
      _given = given;
      _received = received;
      _toReview = toReview;
      _loading = false;
    });
  }

  double get _average {
    if (_received.isEmpty) return 0;
    final total = _received.fold<double>(0, (a, r) => a + ((r['rating'] as num?)?.toDouble() ?? 0));
    return total / _received.length;
  }

  String _dateOf(Map<String, dynamic> r) {
    final c = r['createdAt']?.toString() ?? '';
    return c.length >= 10 ? c.substring(0, 10) : '';
  }

  Future<void> _rate(Map<String, dynamic> tx) async {
    final otherName = _nameOf(
      tx[_otherKey] as Map?,
      _isSeller ? (_isEn ? 'Customer' : 'Mteja') : 'Service Provider',
    );
    int stars = 5;
    final commentCtrl = TextEditingController();
    bool busy = false;
    await AppSheet.show<void>(
      context,
      title: _isEn ? 'Rate $otherName' : 'Mpe alama $otherName',
      subtitle: _isSeller
          ? (_isEn ? 'Tell other providers how this customer was to work with.' : 'Waambie watoa huduma wengine mteja huyu alivyokuwa.')
          : (_isEn ? 'Your review helps other customers.' : 'Maoni yako yanasaidia wateja wengine.'),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  for (var i = 1; i <= 5; i++)
                    IconButton(
                      onPressed: () => setD(() => stars = i),
                      icon: Icon(i <= stars ? Icons.star_rounded : Icons.star_outline_rounded,
                          size: 36, color: AppColors.warning),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: AppColors.background,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.border),
              ),
              child: TextField(
                controller: commentCtrl,
                maxLines: 4,
                maxLength: 500,
                style: const TextStyle(fontSize: 14, color: AppColors.textPrimary),
                decoration: InputDecoration(
                  hintText: _isSeller
                      ? (_isEn ? 'Add a comment (optional)' : 'Ongeza maoni (hiari)')
                      : (_isEn ? 'Tell others about the service (optional)' : 'Waeleze wengine kuhusu huduma (hiari)'),
                  hintStyle: const TextStyle(fontSize: 13, color: AppColors.textMuted),
                  contentPadding: const EdgeInsets.all(14),
                  border: InputBorder.none,
                ),
              ),
            ),
            const SizedBox(height: 16),
            AppButton.primary(
              label: _isEn ? 'Submit review' : 'Tuma maoni',
              loading: busy,
              onPressed: () async {
                setD(() => busy = true);
                final messenger = ScaffoldMessenger.of(context);
                final res = await ApiService.submitReview(
                  transactionRef: (tx['transactionRef'] ?? '').toString(),
                  rating: stars,
                  comment: commentCtrl.text,
                );
                if (!ctx.mounted) return;
                Navigator.pop(ctx);
                messenger.showSnackBar(SnackBar(
                  backgroundColor: res != null ? AppColors.success : AppColors.danger,
                  content: Text(res != null
                      ? (_isEn ? 'Thanks for your review!' : 'Asante kwa maoni yako!')
                      : (ApiService.lastReviewError ?? (_isEn ? 'Could not send your review. Try again.' : 'Imeshindwa kutuma maoni. Jaribu tena.'))),
                ));
                if (res != null && mounted) _load(silent: true);
                // Good review sent: the store's rating card may now appear inside the app.
                if (res != null) AppRatingService.maybeAsk(stars);
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    String count(int n) => n == 0 ? '' : ' ($n)';
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _isEn ? 'Reviews' : 'Maoni',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
        ),
        bottom: TabBar(
          controller: _tabs,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.textSecondary,
          indicatorColor: AppColors.primary,
          labelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
          tabs: [
            Tab(text: (_isEn ? 'To review' : 'Za kupima') + count(_toReview.length)),
            Tab(text: _isEn ? 'Given' : 'Nilizotoa'),
            Tab(text: _isEn ? 'Received' : 'Nilizopokea'),
          ],
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
          : TabBarView(
              controller: _tabs,
              children: [
                _refreshable(_toReviewList()),
                _refreshable(_givenList()),
                _refreshable(_receivedList()),
              ],
            ),
    );
  }

  Widget _refreshable(Widget child) => RefreshIndicator(onRefresh: () => _load(refresh: true), child: child);

  Widget _empty(IconData icon, String title, String body) {
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(24, 64, 24, 24),
      children: [
        Icon(icon, size: 46, color: AppColors.textMuted),
        const SizedBox(height: 10),
        Text(title,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
        const SizedBox(height: 4),
        Text(body, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
      ],
    );
  }

  Widget _stars(double rating, {double size = 16}) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (var i = 1; i <= 5; i++)
          Icon(
            rating >= i ? Icons.star_rounded : (rating >= i - 0.5 ? Icons.star_half_rounded : Icons.star_outline_rounded),
            size: size,
            color: AppColors.warning,
          ),
      ],
    );
  }

  // ---- To review -----------------------------------------------------------
  Widget _toReviewList() {
    if (_toReview.isEmpty) {
      return _empty(
        Icons.star_outline_rounded,
        _isEn ? 'Nothing to review' : 'Hakuna cha kupima',
        _isSeller
            ? (_isEn ? 'Completed bookings where you have not rated the customer will show here.' : 'Oda zilizokamilika ambazo hujampa mteja alama zitaonekana hapa.')
            : (_isEn ? 'Completed bookings you have not rated yet will show here.' : 'Oda zilizokamilika ambazo hujazipa alama zitaonekana hapa.'),
      );
    }
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(16),
      children: [
        for (final tx in _toReview)
          Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.border),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _nameOf(tx[_otherKey] as Map?, _isSeller ? (_isEn ? 'Customer' : 'Mteja') : 'Service Provider'),
                        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        [
                          ((tx['service'] as Map?)?['title'] ?? '').toString(),
                          (tx['createdAt']?.toString() ?? '').length >= 10 ? tx['createdAt'].toString().substring(0, 10) : '',
                        ].where((e) => e.isNotEmpty).join('  •  '),
                        style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                      ),
                    ],
                  ),
                ),
                ElevatedButton(
                  onPressed: () => _rate(tx),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  ),
                  child: Text(_isEn ? 'Rate' : 'Pima', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                ),
              ],
            ),
          ),
      ],
    );
  }

  // ---- Given ---------------------------------------------------------------
  Widget _givenList() {
    if (_given.isEmpty) {
      return _empty(
        Icons.rate_review_outlined,
        _isEn ? 'No reviews given' : 'Hujatoa maoni',
        _isSeller
            ? (_isEn ? 'Reviews you leave for customers will show here.' : 'Maoni unayowaachia wateja yataonekana hapa.')
            : (_isEn ? 'Reviews you leave for providers will show here.' : 'Maoni unayowaachia watoa huduma yataonekana hapa.'),
      );
    }
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(16),
      children: [
        for (final r in _given)
          _reviewCard(
            name: _nameOf(r[_otherKey] as Map?, _isSeller ? (_isEn ? 'Customer' : 'Mteja') : (_isEn ? 'Provider' : 'Mtoa huduma')),
            service: ((r['service'] as Map?)?['title'] ?? '').toString(),
            r: r,
          ),
      ],
    );
  }

  // ---- Received ------------------------------------------------------------
  Widget _receivedList() {
    if (_received.isEmpty) {
      return _empty(
        Icons.rate_review_outlined,
        _isEn ? 'No reviews yet' : 'Bado hakuna maoni',
        _isSeller
            ? (_isEn ? 'After a customer completes a booking they can rate you.' : 'Mteja akikamilisha oda anaweza kukupa alama.')
            : (_isEn ? 'Providers can rate you after a completed booking.' : 'Watoa huduma wanaweza kukupa alama baada ya oda kukamilika.'),
      );
    }
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.border),
          ),
          child: Row(
            children: [
              Text(_average.toStringAsFixed(1),
                  style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: AppColors.textPrimary)),
              const SizedBox(width: 14),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _stars(_average, size: 20),
                  const SizedBox(height: 4),
                  Text(
                    _isEn ? '${_received.length} reviews' : 'Maoni ${_received.length}',
                    style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        for (final r in _received)
          _reviewCard(
            name: _nameOf(r['reviewer'] as Map?, _isEn ? 'User' : 'Mtumiaji'),
            service: ((r['service'] as Map?)?['title'] ?? '').toString(),
            r: r,
          ),
      ],
    );
  }

  Widget _reviewCard({required String name, required String service, required Map<String, dynamic> r}) {
    final rating = (r['rating'] as num?)?.toDouble() ?? 0;
    final comment = (r['comment'] ?? '').toString();
    final date = _dateOf(r);
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 18,
                backgroundColor: AppColors.primaryLight,
                child: Text(name.isEmpty ? '?' : name.substring(0, 1).toUpperCase(),
                    style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w800)),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(name, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                    if (service.isNotEmpty || date.isNotEmpty)
                      Text([service, date].where((e) => e.isNotEmpty).join('  •  '),
                          style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                  ],
                ),
              ),
              _stars(rating),
            ],
          ),
          if (comment.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(comment, style: const TextStyle(fontSize: 13, height: 1.4, color: AppColors.textPrimary)),
          ],
        ],
      ),
    );
  }
}
