import 'dart:async';

import 'package:flutter/foundation.dart';

import 'package:flutter/widgets.dart' show GlobalKey, NavigatorState;

import '../models/ads_config.dart';
import '../models/house_ads.dart';
import 'ads/admob_ads.dart';
import 'ads/facebook_ads.dart';
import 'ads/house_rewarded.dart';
import 'ads/levelplay_ads.dart';
import 'ads/rewarded_source.dart';
import 'ads_config_service.dart';
import 'session_manager.dart';
import 'app_log.dart';

export 'ads/rewarded_source.dart' show RewardedResult;

enum _NetState { idle, starting, ready, failed }

/// Ads for the whole app: Google AdMob, Facebook Audience Network and ironSource LevelPlay (see ADS.md).
///
/// The admin decides, from the backend ([AdsConfigService] / [AdsConfig]):
///  * whether ads are on, and whether they are test ads,
///  * the default network and the network of each page,
///  * the ad unit IDs of every network (no app update needed).
///
/// This class starts the networks that have IDs, answers "which networks, in which order, for this
/// page and ad format" ([chainFor]) and owns the rewarded video ad. The banner and native ads
/// are drawn by lib/widgets/ad_widgets.dart, which walks the same list and moves on to the next
/// network when one has no ad.
///
/// Nothing here throws: the app works the same without ads, and a missing ID, a network that
/// failed to start, or no fill just means that spot shows nothing (or the next network).
class AdService {
  AdService._();

  /// Must match the id registered in MainActivity.kt (card-sized AdMob native ad).
  static const String cardFactoryId = 'serviceCard';

  /// Becomes true once the first network has started.
  static final ValueNotifier<bool> ready = ValueNotifier<bool>(false);

  /// Bumped whenever the settings or the state of a network change, so ad widgets that have
  /// not started yet can try again.
  static final ValueNotifier<int> revision = ValueNotifier<int>(0);

  static final Map<AdProvider, _NetState> _state = {};
  static bool _initCalled = false;

  static AdsConfig get config => AdsConfigService.config.value;

  /// The person's country (upper-case ISO code, e.g. "TZ", "KE") as the app detected or the person
  /// chose it. Empty when not known yet. In-house ads use it for `countries` and for the text
  /// written per country.
  static String get country => SessionManager.getCountryIso().trim().toUpperCase();

  static GlobalKey<NavigatorState>? _navKey;

  /// The app's navigator, needed to show the full-screen in-house rewarded ad. Call once from main.
  static void attachNavigator(GlobalKey<NavigatorState> key) => _navKey = key;

  static bool get _isAndroid => defaultTargetPlatform == TargetPlatform.android;

  /// Ads only run on Android and iOS (not web, desktop).
  static bool get supported => !kIsWeb && (_isAndroid || defaultTargetPlatform == TargetPlatform.iOS);

  static AdPlatform get platform => _isAndroid ? AdPlatform.android : AdPlatform.ios;

  /// The card-sized native ad in the Home grid is built for Android (the AdMob one uses a custom
  /// layout, see ServiceCardNativeAdFactory.kt). On iOS the native ad is a full-width row.
  static bool get cellAdsSupported => supported && _isAndroid;

  /// The ID to request from [p] for [format] (test units for AdMob in test mode).
  static String unitId(AdProvider p, AdFormat format) => config.unitId(p, platform, format);

  /// ironSource app key from the admin's settings.
  static String get levelPlayAppKey => config.idsOf(AdProvider.ironsource, platform).appKey.trim();

  /// The network has started and can serve ads.
  /// (The in-house ads need no start-up: they are always ready.)
  static bool isReady(AdProvider p) => p == AdProvider.inhouse || _state[p] == _NetState.ready;

  /// The networks to try for [page] and [format], best first. Empty when ads are off for that page,
  /// nothing is configured, or the networks failed to start. A network that is still starting is
  /// included (the ad widget waits for it).
  static List<AdProvider> chainFor(AdPage page, AdFormat format) {
    if (!supported) return const [];
    return config.chain(
      page,
      format,
      platform,
      country: country,
      available: (p) => p == AdProvider.inhouse || _state[p] == _NetState.starting || _state[p] == _NetState.ready,
    );
  }

  /// One of the admin's own (in-house) ads for [page] / [format], chosen at random by weight,
  /// among the ads allowed in the person's country, with that country's own title / text / button
  /// where the admin wrote them. Null when none is listed for that spot right now.
  static HouseAd? pickHouse(AdPage page, AdFormat format) {
    final c = country;
    return HouseAds.pick(config.houseFor(page, format, platform, country: c))?.forCountry(c);
  }

  /// Ads of [page] can be requested now (or soon).
  static bool enabledFor(AdPage page) => page.formats.any((f) => chainFor(page, f).isNotEmpty);

  /// Call once at start-up. Never throws, never delays the app.
  static Future<void> init() async {
    if (!supported || _initCalled) return;
    _initCalled = true;
    try {
      await AdsConfigService.load();
    } catch (e) {
      AppLog.d('Ads config load failed: $e');
    }
    AdsConfigService.config.addListener(_onConfigChanged);
    _sync();
  }

  static void _onConfigChanged() {
    _sync();
    _rewardedCheck();
  }

  static void _bump() => revision.value++;

  /// Starts every network the settings need and have IDs for.
  static void _sync() {
    final c = config;
    if (c.enabled) {
      _ensure(AdProvider.admob, AdmobAds.init); // always, as before this setting existed
      if (_wanted(AdProvider.facebook)) {
        _ensure(AdProvider.facebook, () => FacebookAds.init(testMode: c.testMode));
      }
      if (_wanted(AdProvider.ironsource)) {
        _ensure(AdProvider.ironsource, () => LevelPlayAds.init(appKey: levelPlayAppKey, debug: kDebugMode && c.testMode));
      }
    }
    _bump();
    loadRewarded(); // in-house rewarded ads need no network start-up: get one ready now
  }

  /// [p] has at least one ID the admin filled in.
  static bool _wanted(AdProvider p) => AdFormat.values.any((f) => config.hasUnit(p, platform, f));

  static void _ensure(AdProvider p, Future<bool> Function() start) {
    final s = _state[p];
    if (s == _NetState.starting || s == _NetState.ready) return;
    _state[p] = _NetState.starting;
    start().then((ok) {
      _state[p] = ok ? _NetState.ready : _NetState.failed;
      if (ok) {
        ready.value = true;
        loadRewarded(); // have the first video ad ready before the user taps play
      }
      _bump();
    }).catchError((Object e) {
      AppLog.d('${p.label} start failed: $e');
      _state[p] = _NetState.failed;
      _bump();
    });
  }

  // ---------------------------------------------------------------------------
  // Rewarded video ads (shown before a provider video plays)
  // ---------------------------------------------------------------------------

  static RewardedSource? _rewarded;
  static bool _rewardedLoading = false;

  /// A rewarded ad is loaded and can be shown right now.
  static bool get rewardedReady => _rewarded?.isReady ?? false;

  /// A loaded ad from a network the admin has since switched away from is dropped and replaced.
  static void _rewardedCheck() {
    final r = _rewarded;
    if (r != null) {
      final chain = chainFor(AdPage.videoReward, AdFormat.rewarded);
      // "All networks" starts at a random one each time, so a loaded ad stays while its network is in the list.
      final mixed = config.providerFor(AdPage.videoReward) == AdProvider.all;
      if (chain.isEmpty || (mixed ? !chain.contains(r.provider) : chain.first != r.provider)) {
        _rewarded = null;
        r.dispose();
      }
    }
    loadRewarded();
  }

  /// Starts loading the next rewarded ad (no-op if one is ready or loading). Tries the networks
  /// of the video page in order and keeps the first one that has an ad.
  static void loadRewarded() {
    if (_rewarded != null || _rewardedLoading) return;
    final all = chainFor(AdPage.videoReward, AdFormat.rewarded);
    // The admin's first choice is still starting: wait for it (loadRewarded runs again when it is ready).
    if (all.isEmpty || !isReady(all.first)) return;
    final chain = all.where(isReady).toList();
    _rewardedLoading = true;
    _loadRewardedAt(chain, 0);
  }

  static Future<void> _loadRewardedAt(List<AdProvider> chain, int i) async {
    if (i >= chain.length) {
      _rewardedLoading = false;
      return;
    }
    final source = _newRewarded(chain[i]);
    if (source == null) {
      await _loadRewardedAt(chain, i + 1); // this network has no rewarded ad to offer (e.g. no in-house ad listed)
      return;
    }
    var ok = false;
    try {
      ok = await source.load().timeout(const Duration(seconds: 20), onTimeout: () => false);
    } catch (e) {
      AppLog.d('Rewarded load failed (${chain[i].label}): $e');
    }
    if (ok) {
      _rewarded = source;
      _rewardedLoading = false;
      _bump();
    } else {
      source.dispose();
      await _loadRewardedAt(chain, i + 1);
    }
  }

  static RewardedSource? _newRewarded(AdProvider p) {
    final id = unitId(p, AdFormat.rewarded);
    switch (p) {
      case AdProvider.admob:
        return AdmobRewarded(id);
      case AdProvider.facebook:
        return FacebookRewarded(id);
      case AdProvider.ironsource:
        return LevelPlayRewarded(id);
      case AdProvider.all:
        return null; // not a network: the chain already lists the real ones
      case AdProvider.inhouse:
        // The admin's own full-screen ad (image, text, button, countdown), if one is listed for the video page.
        final ad = pickHouse(AdPage.videoReward, AdFormat.rewarded);
        return ad == null ? null : HouseRewarded(ad, _navKey);
    }
  }

  /// Shows a rewarded video ad and reports the outcome (see [RewardedResult]).
  static Future<RewardedResult> showRewarded() async {
    final source = _rewarded;
    if (source == null || !source.isReady || !enabledFor(AdPage.videoReward)) {
      loadRewarded();
      return RewardedResult.unavailable;
    }
    _rewarded = null; // an ad can only be shown once
    RewardedResult result;
    try {
      result = await source.show();
    } catch (e) {
      AppLog.d('Rewarded show failed: $e');
      result = RewardedResult.unavailable;
    }
    source.dispose();
    loadRewarded(); // preload the next one
    return result;
  }
}
