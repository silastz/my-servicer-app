import 'dart:async';
import 'dart:convert';
import 'dart:io' show Platform;

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/ads_config.dart';
import '../security/secure_http.dart';
import '../security/client_security_config.dart';
import 'app_log.dart';

/// Keeps the ad settings the admin chose (default network, network per page, ad IDs, test mode;
/// see docs/ads_config_api_contract.md).
///
/// - The last good answer is saved on the phone, so it applies at the next start and offline.
/// - Until the server has answered once, [AdsConfig.defaults] apply (AdMob test ads).
/// - A bad or missing answer changes nothing.
class AdsConfigService with WidgetsBindingObserver {
  AdsConfigService._();
  static final AdsConfigService _i = AdsConfigService._();

  static const String _key = 'ads_config_v1';
  static const Duration _minGap = Duration(minutes: 10);

  /// The settings in force right now. Listen to react when the admin changes them.
  static final ValueNotifier<AdsConfig> config = ValueNotifier<AdsConfig>(AdsConfig.defaults);

  static DateTime? _lastCheck;
  static bool _started = false;

  /// Reads the saved settings. Call early; never throws.
  static Future<void> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_key);
      if (raw == null) return;
      final parsed = AdsConfig.tryParse(jsonDecode(raw));
      if (parsed != null) _set(parsed);
    } catch (e) {
      AppLog.d('Saved ads config unreadable: $e');
    }
  }

  /// Call once after the app is on screen (the secure HTTP client is ready by then).
  static void start() {
    if (_started) return;
    _started = true;
    WidgetsBinding.instance.addObserver(_i);
    refresh(force: true);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) refresh();
  }

  static void _set(AdsConfig c) {
    if (!config.value.sameAs(c)) config.value = c;
  }

  /// Uses [c] at once and keeps it on the phone. The admin screen calls this after a save so the
  /// admin sees the change without waiting for the next refresh.
  static Future<void> apply(AdsConfig c) async {
    _set(c);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_key, jsonEncode(c.toJson()));
    } catch (e) {
      AppLog.d('Could not save ads config: $e');
    }
  }

  /// Asks the server for the current settings (at most every 10 minutes unless [force]).
  static Future<void> refresh({bool force = false}) async {
    final now = DateTime.now();
    if (!force && _lastCheck != null && now.difference(_lastCheck!) < _minGap) return;
    _lastCheck = now;
    try {
      final platform = kIsWeb ? 'web' : (Platform.isIOS ? 'ios' : 'android');
      final res = await SecureHttp.client
          .get(Uri.parse('${ClientSecurityConfig.apiBase}/app/ads?platform=$platform'))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode != 200) return;
      final body = jsonDecode(res.body);
      if (!AdsConfig.looksLikeConfig(body)) return; // not ad settings: keep what the phone has
      final parsed = AdsConfig.tryParse(body);
      if (parsed == null) return;
      await apply(parsed);
    } catch (e) {
      _lastCheck = null; // offline or endpoint missing: keep the saved settings, try again next time
      AppLog.d('Ads config refresh failed: $e');
    }
  }
}
