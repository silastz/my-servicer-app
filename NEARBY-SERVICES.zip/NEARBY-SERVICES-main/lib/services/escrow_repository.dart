import 'package:flutter/foundation.dart';
import '../models/escrow.dart';
import 'api_service.dart';

/// The one place screens read escrow bookings from.
///
///  - Concurrent callers share one in-flight request (no 13 identical calls).
///  - A fresh result is reused for [ttl], so opening a screen does not refetch.
///  - [changes] ticks once after a write; screens listen to it instead of every
///    screen reloading on its own.
///  - A failed refresh keeps the last good list.
class EscrowRepository {
  EscrowRepository._();
  static final EscrowRepository instance = EscrowRepository._();

  static const Duration ttl = Duration(seconds: 20);

  final ValueNotifier<int> changes = ValueNotifier<int>(0);

  final _Slot _buyer = _Slot();
  final _Slot _seller = _Slot();

  List<EscrowTransaction> get cachedBuyer => _buyer.items;
  List<EscrowTransaction> get cachedSeller => _seller.items;

  /// Null only when nothing is cached and the server could not be reached.
  Future<List<EscrowTransaction>?> buyer({bool force = false}) =>
      _load(_buyer, ApiService.fetchBuyerTransactionsOrNull, force);

  Future<List<EscrowTransaction>?> seller({bool force = false}) =>
      _load(_seller, ApiService.fetchSellerOrdersOrNull, force);

  EscrowTransaction? byRef(String ref) {
    for (final t in [..._buyer.items, ..._seller.items]) {
      if (t.ref == ref) return t;
    }
    return null;
  }

  /// Run a write (pay, release, accept...). On success the cache is dropped and
  /// listeners are told once.
  Future<T?> write<T>(Future<T?> Function() action) async {
    final r = await action();
    if (r != null) invalidate();
    return r;
  }

  void invalidate() {
    _buyer.fetchedAt = null;
    _seller.fetchedAt = null;
    changes.value++;
  }

  void clear() {
    _buyer.reset();
    _seller.reset();
    changes.value++;
  }

  Future<List<EscrowTransaction>?> _load(
    _Slot s,
    Future<List<dynamic>?> Function() fetch,
    bool force,
  ) {
    final at = s.fetchedAt;
    if (!force && at != null && DateTime.now().difference(at) < ttl) {
      return Future.value(s.items);
    }
    return s.inFlight ??= () async {
      try {
        final raw = await fetch();
        if (raw == null) return s.hasData ? s.items : null;
        s.items = [
          for (final r in raw)
            if (r is Map) EscrowTransaction.fromJson(Map<String, dynamic>.from(r)),
        ];
        s.hasData = true;
        s.fetchedAt = DateTime.now();
        return s.items;
      } finally {
        s.inFlight = null;
      }
    }();
  }
}

class _Slot {
  List<EscrowTransaction> items = const [];
  bool hasData = false;
  DateTime? fetchedAt;
  Future<List<EscrowTransaction>?>? inFlight;
  void reset() {
    items = const [];
    hasData = false;
    fetchedAt = null;
    inFlight = null;
  }
}
