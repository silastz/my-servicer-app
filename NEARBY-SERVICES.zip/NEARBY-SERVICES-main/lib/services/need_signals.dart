import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/customer_needs.dart';
import '../models/service_search.dart';
import 'session_manager.dart';
import 'app_log.dart';

/// Remembers what the customer looks at so [NeedEngine] can guess what they need.
///
/// Everything stays on this phone (per account, in SharedPreferences): nothing is
/// sent to the server. Old signals (over 120 days) and anything past the newest
/// 300 are dropped. Every call is fire-and-forget and never throws.
class NeedSignals {
  NeedSignals._();

  /// Bumped after every change so the home card can refresh.
  static final ValueNotifier<int> changed = ValueNotifier<int>(0);

  static const int _maxEvents = 300;
  static const Duration _maxAge = Duration(days: 120);

  static List<NeedEvent>? _cache;
  static int _cacheUid = -1;

  static int get _uid => SessionManager.getUserIdValue();
  static String get _key => 'need_events_$_uid';

  /// Category api key for whatever the screens call it, or null when unknown.
  static String? canonical(String? raw) {
    final c = (raw ?? '').trim();
    if (c.isEmpty || c.toLowerCase() == 'all') return null;
    for (final k in ServiceCategories.keys) {
      if (k.toLowerCase() == c.toLowerCase()) return k;
    }
    return ServiceCategories.match(c) ?? NeedEngine.bestCategory(c);
  }

  static Future<List<NeedEvent>> load() async {
    final uid = _uid;
    if (_cache != null && _cacheUid == uid) return _cache!;
    var list = <NeedEvent>[];
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('need_events_$uid');
      if (raw != null) {
        final decoded = jsonDecode(raw);
        if (decoded is List) {
          list = decoded.map(NeedEvent.fromJson).whereType<NeedEvent>().toList();
        }
      }
    } catch (caught, trace) { AppLog.e('need_signals.load', caught, trace); }
    _cache = list;
    _cacheUid = uid;
    return list;
  }

  static Future<void> _add(NeedEvent e) async {
    try {
      final list = await load();
      list.add(e);
      final cutoff = DateTime.now().subtract(_maxAge);
      list.removeWhere((x) => x.at.isBefore(cutoff));
      if (list.length > _maxEvents) list.removeRange(0, list.length - _maxEvents);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_key, jsonEncode(list.map((x) => x.toJson()).toList()));
      changed.value++;
    } catch (caught, trace) { AppLog.e('need_signals._add', caught, trace); }
  }

  /// A typed search. [category] is what the screen resolved (if anything); otherwise
  /// the words themselves are read ("bomba linavuja" -> Plumbing).
  static Future<void> recordSearch(String text, {String? category}) async {
    final q = text.trim();
    final cat = canonical(category) ?? NeedEngine.bestCategory(q);
    if (cat == null) return;
    await _add(NeedEvent(
      type: NeedSignalType.search,
      category: cat,
      at: DateTime.now(),
      text: q.isEmpty ? null : q,
      urgent: NeedEngine.isUrgent(q),
    ));
  }

  static Future<void> recordCategoryOpen(String? category) async {
    final cat = canonical(category);
    if (cat == null) return;
    await _add(NeedEvent(type: NeedSignalType.categoryOpen, category: cat, at: DateTime.now()));
  }

  static Future<void> recordServiceView(String? category) async {
    final cat = canonical(category);
    if (cat == null) return;
    await _add(NeedEvent(type: NeedSignalType.serviceView, category: cat, at: DateTime.now()));
  }

  static Future<void> recordFavorite(String? category) async {
    final cat = canonical(category);
    if (cat == null) return;
    await _add(NeedEvent(type: NeedSignalType.favorite, category: cat, at: DateTime.now()));
  }

  static Future<void> recordBooking(String? category) async {
    final cat = canonical(category);
    if (cat == null) return;
    await _add(NeedEvent(type: NeedSignalType.booking, category: cat, at: DateTime.now()));
  }

  static Future<List<NeedPrediction>> predict({int limit = 3}) async =>
      NeedEngine.predict(await load(), limit: limit);

  /// "Forget what you think I need" (also useful for a privacy setting).
  static Future<void> clear() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_key);
      _cache = <NeedEvent>[];
      _cacheUid = _uid;
      changed.value++;
    } catch (caught, trace) { AppLog.e('need_signals.clear', caught, trace); }
  }
}
