import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'app_policy.dart';
import 'app_log.dart';

/// What the code is for.
enum PendingOtpKind {
  /// New sign-up: the server saved nothing, so the form + signed challenge are kept here ([PendingOtp.form]).
  signup,

  /// "Forgot password": the server holds the code; only the contact is kept here.
  reset,

  /// Old account that still has to confirm its phone (login found it unverified).
  verify,
}

/// A code that was sent, remembered on the phone so closing and reopening the app does not lose it.
class PendingOtp {
  final PendingOtpKind kind;
  final String contact; // phone (+255...) or email, as the code was sent
  final DateTime sentAt;
  final Map<String, dynamic>? form; // sign-up form + challenge (kind == signup only)

  const PendingOtp({required this.kind, required this.contact, required this.sentAt, this.form});

  Map<String, dynamic> toJson() => {
        'kind': kind.name,
        'contact': contact,
        'sentAt': sentAt.millisecondsSinceEpoch,
        if (form != null) 'form': form,
      };

  static PendingOtp? tryParse(dynamic raw) {
    if (raw is! Map) return null;
    final kind = PendingOtpKind.values.where((k) => k.name == raw['kind']).firstOrNull;
    final contact = raw['contact'];
    final sent = raw['sentAt'];
    if (kind == null || contact is! String || contact.isEmpty || sent is! int) return null;
    final form = raw['form'] is Map ? Map<String, dynamic>.from(raw['form'] as Map) : null;
    if (kind == PendingOtpKind.signup && form == null) return null;
    return PendingOtp(
      kind: kind,
      contact: contact,
      sentAt: DateTime.fromMillisecondsSinceEpoch(sent),
      form: form,
    );
  }
}

/// Remembers the last code sent per kind, for [minutes] (admin setting, default 4).
///
/// Reopen the app within that time, type the same phone/email, and the app goes to the code screen
/// instead of sending a new SMS. Kept in encrypted storage (the sign-up form holds the password), and
/// erased when the code is used, replaced, or too old. The server still checks every code itself.
class PendingOtpStore {
  PendingOtpStore._();

  static const _key = 'pending_otp_v1';
  static const FlutterSecureStorage _secure = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  /// Window in force now: the admin's value, else 4.
  static Duration get window => Duration(minutes: AppPolicy.otpPendingMinutesEffective);

  /// True while a code sent at [sentAt] is still "pending". A clock set back counts as too old.
  @visibleForTesting
  static bool isFresh(DateTime sentAt, DateTime now, Duration window) {
    final age = now.difference(sentAt);
    return !age.isNegative && age < window;
  }

  /// Same phone (last 9 digits, so 0712... / +255712... / 255712... match) or same email (case-insensitive).
  @visibleForTesting
  static bool sameContact(String a, String b) {
    final x = a.trim(), y = b.trim();
    if (x.isEmpty || y.isEmpty) return false;
    if (x.contains('@') || y.contains('@')) return x.toLowerCase() == y.toLowerCase();
    String tail(String v) {
      final d = v.replaceAll(RegExp(r'\D'), '');
      return d.length > 9 ? d.substring(d.length - 9) : d;
    }
    final tx = tail(x), ty = tail(y);
    return tx.length >= 7 && tx == ty;
  }

  static Future<Map<String, dynamic>> _readAll() async {
    try {
      final raw = await _secure.read(key: _key);
      if (raw == null || raw.isEmpty) return {};
      final d = jsonDecode(raw);
      return d is Map ? Map<String, dynamic>.from(d) : {};
    } catch (e) {
      AppLog.d('Pending code unreadable: ${e.runtimeType}');
      return {};
    }
  }

  static Future<void> _writeAll(Map<String, dynamic> all) async {
    try {
      if (all.isEmpty) {
        await _secure.delete(key: _key);
      } else {
        await _secure.write(key: _key, value: jsonEncode(all));
      }
    } catch (e) {
      AppLog.d('Pending code not saved: ${e.runtimeType}'); // storage unavailable: the feature just does not apply
    }
  }

  /// Remember that a code of [kind] was just sent to [contact] (replaces any earlier one of that kind).
  /// Pass [sentAt] to update the saved form WITHOUT restarting the clock.
  static Future<void> save(PendingOtpKind kind, String contact, {Map<String, dynamic>? form, DateTime? sentAt}) async {
    final all = await _readAll();
    all[kind.name] = PendingOtp(kind: kind, contact: contact, sentAt: sentAt ?? DateTime.now(), form: form).toJson();
    await _writeAll(all);
  }

  /// The still-fresh code of [kind] that was sent to [contact], or null. Too-old ones are erased here.
  static Future<PendingOtp?> find(PendingOtpKind kind, String contact, {DateTime? now}) async {
    final all = await _readAll();
    final p = PendingOtp.tryParse(all[kind.name]);
    if (p == null) return null;
    if (!isFresh(p.sentAt, now ?? DateTime.now(), window)) {
      all.remove(kind.name);
      await _writeAll(all);
      return null;
    }
    return sameContact(p.contact, contact) ? p : null;
  }

  static Future<void> clear(PendingOtpKind kind) async {
    final all = await _readAll();
    if (all.remove(kind.name) != null) await _writeAll(all);
  }
}
