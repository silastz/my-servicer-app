import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../screens/map_tracking_screen.dart';
import '../widgets/login_modal.dart';
import '../security/secure_http.dart';
import 'api_service.dart';
import 'session_manager.dart';
import 'app_log.dart';

/// Phone and in-app calling.
///
/// In-app calls use a private Jitsi room. The other person is invited through
/// the app chat (the invite message contains the room link and shows a
/// "Join call" button). Audio calls start with the camera off.
class CallService {
  static bool get _isEn => AppStrings.isEnglish;

  static void _snack(BuildContext context, String msg, {Color? color}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: color));
  }

  /// Normal phone call through the phone dialer.
  static Future<void> mobileCall(BuildContext context, String phone) async {
    final number = phone.replaceAll(RegExp(r'[^0-9+]'), '');
    if (number.isEmpty) return;
    final ok = await launchUrl(Uri(scheme: 'tel', path: number));
    if (!ok && context.mounted) {
      _snack(context, _isEn ? 'Could not open the phone dialer' : 'Imeshindwa kufungua simu');
    }
  }

  /// Opens a WhatsApp chat with the number.
  static Future<void> whatsapp(BuildContext context, String phone) async {
    final digits = phone.replaceAll(RegExp(r'\D'), '');
    if (digits.isEmpty) return;
    final ok = await launchUrl(Uri.parse('https://wa.me/$digits'), mode: LaunchMode.externalApplication);
    if (!ok && context.mounted) {
      _snack(context, _isEn ? 'Could not open WhatsApp' : 'Imeshindwa kufungua WhatsApp');
    }
  }

  /// Opens in-app turn-by-turn navigation to the provider (no external maps app).
  /// Uses the provider's coordinates when known, otherwise looks up [query].
  static Future<void> navigate(
    BuildContext context, {
    double? lat,
    double? lng,
    String? query,
    String providerName = '',
    String serviceTitle = '',
    int? providerId,
  }) async {
    final hasCoords = lat != null && lng != null;
    final hasQuery = query != null && query.trim().isNotEmpty;
    if (!hasCoords && !hasQuery) {
      _snack(context, _isEn ? 'No location available for this provider.' : 'Hakuna eneo la mtoa huduma huyu.');
      return;
    }
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => MapTrackingScreen(
          providerName: providerName,
          serviceTitle: serviceTitle,
          address: hasQuery ? query.trim() : '',
          providerLat: lat,
          providerLng: lng,
          providerId: providerId,
          startNavigating: true,
        ),
      ),
    );
  }

  /// Starts an in-app audio or video call with the provider.
  static Future<void> inAppCall(
    BuildContext context, {
    required int? recipientId,
    required String name,
    required bool video,
  }) async {
    var wantVideo = video;
    if (recipientId == null || recipientId == 0) {
      _snack(context, _isEn ? 'Calls are not available for this provider yet.' : 'Simu hazipatikani kwa mtoa huduma huyu bado.');
      return;
    }
    if (!SessionManager.isLoggedIn()) {
      final ok = await LoginModal.show(context);
      if (ok != true || !SessionManager.isLoggedIn()) return;
    }
    if (!context.mounted) return;

    final me = SessionManager.getUserIdValue();
    if (me == recipientId) {
      _snack(context, _isEn ? "You can't call yourself." : 'Huwezi kujipigia simu.');
      return;
    }

    // Weak network: check first, so a call is not started into a dead line.
    _snack(context, _isEn ? 'Checking your connection...' : 'Inakagua mtandao wako...');
    final net = await _probe();
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    if (net == _Net.none) {
      _snack(
        context,
        _isEn ? 'No internet connection. Try again when you are back online.' : 'Hakuna mtandao. Jaribu tena ukipata mtandao.',
        color: AppColors.danger,
      );
      return;
    }
    if (wantVideo && net == _Net.weak) {
      final audio = await _askAudioInstead(context, joining: false);
      if (!context.mounted) return;
      if (audio) wantVideo = false;
    }

    final lo = me < recipientId ? me : recipientId;
    final hi = me < recipientId ? recipientId : me;
    final room = 'nearbyservices-$lo-$hi-${DateTime.now().millisecondsSinceEpoch}';
    final myName = Uri.encodeComponent('"${SessionManager.getStageName()}"');
    final config = _lowDataConfig(video: wantVideo);
    final url = 'https://meet.jit.si/$room#$config&userInfo.displayName=$myName';

    final label = wantVideo ? (_isEn ? 'video' : 'video') : (_isEn ? 'audio' : 'sauti');
    final invite = _isEn
        ? '📞 Incoming $label call from ${SessionManager.getStageName()}. Tap to join: $url'
        : '📞 Simu ya $label inakupigia kutoka kwa ${SessionManager.getStageName()}. Bonyeza kujiunga: $url';

    _snack(context, _isEn ? 'Calling $name...' : 'Inampigia $name...');
    final sent = await _sendInvite(recipientId, invite);
    if (!context.mounted) return;
    if (!sent) {
      _snack(
        context,
        _isEn ? 'Could not reach $name. Check your connection and try again.' : 'Imeshindwa kumfikia $name. Angalia mtandao kisha jaribu tena.',
        color: AppColors.danger,
      );
      return;
    }
    await joinCall(context, url);
  }

  /// Opens a call room link (used by the caller, and by the "Join call" button in chat).
  static Future<void> joinCall(BuildContext context, String url) async {
    final uri = Uri.tryParse(url);
    // Only ever open our own Jitsi rooms.
    if (uri == null || uri.scheme != 'https' || uri.host != 'meet.jit.si') return;

    // My own connection may be weaker than the caller's: check before opening the room.
    var target = uri;
    final net = await _probe();
    if (!context.mounted) return;
    if (net == _Net.none) {
      _snack(
        context,
        _isEn ? 'No internet connection. Try again when you are back online.' : 'Hakuna mtandao. Jaribu tena ukipata mtandao.',
        color: AppColors.danger,
      );
      return;
    }
    final isVideoRoom = !uri.fragment.contains('config.startAudioOnly=true');
    if (net == _Net.weak && isVideoRoom) {
      final audio = await _askAudioInstead(context, joining: true);
      if (!context.mounted) return;
      if (audio) target = _audioOnly(uri);
    }

    var ok = false;
    for (var i = 0; i < 2 && !ok; i++) {
      try {
        ok = await launchUrl(target, mode: LaunchMode.externalApplication);
      } catch (caught, trace) { AppLog.e('call_service.joinCall', caught, trace); }
      if (!ok && i == 0) await Future<void>.delayed(const Duration(seconds: 1));
    }
    if (!ok && context.mounted) {
      _snack(context, _isEn ? 'Could not open the call' : 'Imeshindwa kufungua simu');
    }
  }

  // ---------------------------------------------------------------------------
  // Weak network
  // ---------------------------------------------------------------------------

  /// Quick check of the connection (two tiny requests at once to our own server).
  /// none = no answer, weak = slow or one failed, good = both answered fast.
  static Future<_Net> _probe() async {
    Future<int?> ping() async {
      final t = Stopwatch()..start();
      try {
        final r = await SecureHttp.client.get(Uri.parse('${ApiService.baseUrl}/health')).timeout(const Duration(seconds: 5));
        return r.statusCode < 500 ? t.elapsedMilliseconds : null;
      } catch (caught, trace) {
        AppLog.e('call_service.ping', caught, trace);
        return null;
      }
    }

    final r = await Future.wait([ping(), ping()]);
    final ok = r.whereType<int>().toList();
    if (ok.isEmpty) return _Net.none;
    if (ok.length < 2 || ok.any((ms) => ms > 1500)) return _Net.weak;
    return _Net.good;
  }

  /// Low-data settings for the call room (Jitsi options in the link): small video, a low audio
  /// bit-rate, a direct line between the two phones, and video that pauses itself when the line is poor.
  static String _lowDataConfig({required bool video}) {
    final common = [
      'config.p2p.enabled=true',
      'config.disableAudioLevels=true',
      'config.enableNoisyMicDetection=false',
      'config.enableLayerSuspension=true',
      'config.audioQuality.opusMaxAverageBitrate=24000',
    ];
    final v = video
        ? [
            'config.startWithVideoMuted=false',
            'config.resolution=360',
            'config.constraints.video.height.ideal=360',
            'config.constraints.video.height.max=480',
            'config.constraints.video.frameRate.max=20',
          ]
        : [
            'config.startAudioOnly=true',
            'config.startWithVideoMuted=true',
          ];
    return [...v, ...common].join('&');
  }

  /// The same room, but joined without video.
  static Uri _audioOnly(Uri uri) {
    final frag = uri.fragment;
    if (frag.contains('config.startAudioOnly=true')) return uri;
    final extra = 'config.startAudioOnly=true&config.startWithVideoMuted=true';
    return uri.replace(fragment: frag.isEmpty ? extra : '$frag&$extra');
  }

  static Future<bool> _askAudioInstead(BuildContext context, {required bool joining}) async {
    final choice = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(_isEn ? 'Weak network' : 'Mtandao dhaifu'),
        content: Text(_isEn
            ? 'Your connection looks weak, so video may freeze or cut off. ${joining ? 'Join' : 'Call'} with audio only? Audio works much better on a weak network.'
            : 'Mtandao wako unaonekana dhaifu, video inaweza kukwama au kukatika. ${joining ? 'Jiunge' : 'Piga'} kwa sauti tu? Sauti hufanya kazi vizuri zaidi kwenye mtandao dhaifu.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, 'video'), child: Text(_isEn ? 'Video anyway' : 'Video tu')),
          ElevatedButton(onPressed: () => Navigator.pop(ctx, 'audio'), child: Text(_isEn ? 'Audio only' : 'Sauti tu')),
        ],
      ),
    );
    return choice != 'video'; // closing the dialog also picks audio: the safe choice
  }

  /// Sends the call invite with up to 3 tries. One [clientId] for all tries: the other person never gets two invites.
  static Future<bool> _sendInvite(int recipientId, String invite) async {
    final clientId = 'call_${SessionManager.getUserIdValue()}_${DateTime.now().microsecondsSinceEpoch}';
    const waits = [Duration(seconds: 2), Duration(seconds: 4)];
    for (var i = 0;; i++) {
      final res = await ApiService.sendMessage(recipientId: recipientId.toString(), message: invite, clientId: clientId);
      if (res != null) return true;
      if (ApiService.lastSendRejected || i >= waits.length) return false;
      await Future<void>.delayed(waits[i]);
    }
  }
}

enum _Net { none, weak, good }
