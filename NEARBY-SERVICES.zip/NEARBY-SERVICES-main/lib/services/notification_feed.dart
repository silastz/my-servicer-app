import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import 'api_service.dart';
import 'chat_prefs.dart';
import 'chat_socket.dart';
import 'data_sync.dart';
import 'session_manager.dart';
import 'payment_flow.dart';

/// One notification entry. [id] is stable across reloads so read state sticks.
class AppNotification {
  final String id;
  final String title;
  final String subtitle;
  final String time;
  final String type; // 'Bookings' | 'Messages' | 'System'
  final IconData icon;
  final Color color;

  /// Set only for message notifications: the person to open a chat with, so each message
  /// notification is a standalone entry that opens its own chat.
  final int? chatUserId;
  final String? chatName;
  final bool chatOnline;

  /// A built-in tip, not something that happened to this user: it has no date, is never "unread" and does not count
  /// toward the Home bell badge.
  final bool isTip;

  const AppNotification({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.time,
    required this.type,
    required this.icon,
    required this.color,
    this.chatUserId,
    this.chatName,
    this.chatOnline = false,
    this.isTip = false,
  });

  bool get isMessage => type == 'Messages' && chatUserId != null;

  /// Booking / offer notifications open the Requests screen when tapped.
  bool get opensRequests => type == 'Bookings';
}

/// Single source of truth for the Notifications screen AND the Home bell badge.
///
/// Built from the same bookings / orders / conversations the Requests, Payments
/// and Chats screens show, so a new booking, an accept or a new message appears
/// everywhere together. Read state is remembered per user on this device.
class NotificationFeed {
  static final ValueNotifier<List<AppNotification>> items = ValueNotifier(const []);
  static final ValueNotifier<int> unread = ValueNotifier(0);

  /// Two always-visible tips in the current language. They carry no date and are never counted as unread.
  static List<AppNotification> get _system {
    final en = AppStrings.isEnglish;
    return [
      AppNotification(
        id: 'sys_welcome',
        title: en ? 'Welcome to Ungana' : 'Karibu Ungana',
        subtitle: en
            ? 'Discover great service providers near you.'
            : 'Gundua watoa huduma bora walio karibu nawe.',
        time: '',
        type: 'System',
        icon: Icons.verified_user_rounded,
        color: AppColors.primary,
        isTip: true,
      ),
      AppNotification(
        id: 'sys_escrow',
        title: en ? 'Your payments are protected' : 'Malipo yako yanalindwa',
        subtitle: en
            ? 'Your payments are held safely until the service is completed.'
            : 'Malipo yako yote yanalindwa kwa usalama hadi huduma inapokamilika.',
        time: '',
        type: 'System',
        icon: Icons.security_rounded,
        color: AppColors.success,
        isTip: true,
      ),
    ];
  }

  static Set<String> _read = {};
  static bool _started = false;
  static bool _loading = false;
  static bool _again = false; // a change arrived while loading: run once more
  static int _userForRead = -1;

  static String get _readKey => 'notif_read_${SessionManager.getUserIdValue()}';

  /// Call once at app start (after SessionManager.init). Safe to call again.
  static void start() {
    if (_started) return;
    _started = true;
    DataSync.changed.addListener(refresh);
    AppStrings.currentLanguage.addListener(refresh); // the tips follow the app language
    SessionManager.sessionNotifier.addListener(_onSession);
    // Live: a new / read / deleted message over the chat connection updates the bell at once
    // (a burst of events becomes one refresh).
    ChatSocket.events.listen((_) => scheduleRefresh());
    // Back from the background: pick up whatever happened meanwhile.
    WidgetsBinding.instance.addObserver(_FeedLifecycle());
    refresh();
  }

  static Timer? _debounce;

  /// Refresh soon; many calls in a short time cause one refresh.
  static void scheduleRefresh() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 400), refresh);
  }

  static void _onSession() {
    // Login / logout / switching account: reload for the new user.
    if (_userForRead != SessionManager.getUserIdValue() || !SessionManager.isLoggedIn()) refresh();
  }

  static Future<void> _loadRead() async {
    final prefs = await SharedPreferences.getInstance();
    _read = (prefs.getStringList(_readKey) ?? const <String>[]).toSet();
    _userForRead = SessionManager.getUserIdValue();
  }

  static Future<void> _saveRead() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_readKey, _read.toList());
  }

  static bool isRead(AppNotification n) => _read.contains(n.id);

  static void _publish(List<AppNotification> list) {
    items.value = list;
    unread.value = list.where((n) => !n.isTip && !_read.contains(n.id)).length;
  }

  static Future<void> markRead(AppNotification n) async {
    if (_read.add(n.id)) {
      _publish(items.value);
      await _saveRead();
    }
  }

  static Future<void> markAllRead() async {
    _read.addAll(items.value.map((n) => n.id));
    _publish(items.value);
    await _saveRead();
  }

  static String _day(dynamic v) {
    final s = v?.toString() ?? '';
    return s.length >= 10 ? s.substring(0, 10) : s;
  }

  static String _name(dynamic user, String fallback) {
    final m = user is Map ? user : const {};
    return (m['stageName'] ?? m['username'] ?? fallback).toString();
  }

  static Future<void> refresh() async {
    if (_loading) {
      _again = true;
      return;
    }
    _loading = true;
    try {
      if (!SessionManager.isLoggedIn()) {
        _read = {};
        _userForRead = -1;
        items.value = _system;
        unread.value = 0; // guests have no personal notifications to be unread
        return;
      }
      await _loadRead();

      final results = await Future.wait([
        ApiService.fetchBuyerTransactions(),
        SessionManager.isSeller() ? ApiService.fetchSellerOrders() : Future.value(<dynamic>[]),
        ApiService.fetchConversations(),
        ApiService.fetchMyOffers(),
        SessionManager.isSeller() ? ApiService.fetchIncomingOffers() : Future.value(<dynamic>[]),
      ]);

      final out = <AppNotification>[];

      for (final tx in results[0]) {
        final peerId = int.tryParse('${(tx['seller'] is Map ? tx['seller']['id'] : null) ?? tx['sellerId'] ?? ''}');
        final peerName = _name(tx['seller'], 'Provider');
        final ref = (tx['transactionRef'] ?? tx['id'] ?? '').toString();
        final status = (tx['status'] ?? 'PENDING').toString().toUpperCase();
        final name = _name(tx['seller'], 'Provider');
        final date = _day(tx['createdAt']);
        final payState = PaymentFlow.stateOf(status);
        if (payState == PayState.awaitingPayment) {
          out.add(AppNotification(
            id: 'b_${ref}_pay_requested',
            title: 'Payment Requested',
            subtitle: '$name asks you to pay first to confirm your booking. Tap Requests to pay.',
            time: date,
            type: 'Bookings',
            chatUserId: peerId,
            chatName: peerName,
            icon: Icons.payments_rounded,
            color: AppColors.warning,
          ));
        } else if (payState == PayState.paymentSent) {
          out.add(AppNotification(
            id: 'b_${ref}_pay_sent',
            title: 'Waiting for Confirmation',
            subtitle: 'You said you paid. $name will confirm once the money arrives.',
            time: date,
            type: 'Bookings',
            chatUserId: peerId,
            chatName: peerName,
            icon: Icons.hourglass_top_rounded,
            color: AppColors.primary,
          ));
        } else if (payState == PayState.disputed) {
          out.add(AppNotification(
            id: 'b_${ref}_pay_disputed',
            title: 'Payment Not Received',
            subtitle: '$name did not receive your payment. Check your reference and contact them.',
            time: date,
            type: 'Bookings',
            chatUserId: peerId,
            chatName: peerName,
            icon: Icons.error_rounded,
            color: AppColors.danger,
          ));
        } else if (status == 'ACCEPTED') {
          out.add(AppNotification(
            id: 'b_${ref}_accepted',
            title: 'Booking Accepted',
            subtitle: '$name has accepted your request. Open Requests to pay and confirm your booking.',
            time: date,
            type: 'Bookings',
            chatUserId: peerId,
            chatName: peerName,
            icon: Icons.check_circle_rounded,
            color: AppColors.success,
          ));
        } else if (status == 'PENDING_ACCEPTANCE') {
          out.add(AppNotification(
            id: 'b_${ref}_placed',
            title: 'Request Sent',
            subtitle: 'Request sent to $name. You pay after they accept.',
            time: date,
            type: 'Bookings',
            chatUserId: peerId,
            chatName: peerName,
            icon: Icons.sync_rounded,
            color: AppColors.warning,
          ));
        } else if (status == 'REJECTED' || status == 'DECLINED') {
          out.add(AppNotification(
            id: 'b_${ref}_rejected',
            title: 'Booking Declined',
            subtitle: '$name could not take your booking. Your funds are returned.',
            time: date,
            type: 'Bookings',
            chatUserId: peerId,
            chatName: peerName,
            icon: Icons.cancel_rounded,
            color: AppColors.danger,
          ));
        } else if (status == 'COMPLETED' || status == 'RELEASED') {
          out.add(AppNotification(
            id: 'b_${ref}_released',
            title: 'Payment Released',
            subtitle: 'You confirmed satisfaction and released funds for booking with $name.',
            time: date,
            type: 'Bookings',
            chatUserId: peerId,
            chatName: peerName,
            icon: Icons.account_balance_wallet_rounded,
            color: AppColors.primary,
          ));
        }
      }

      for (final ord in results[1]) {
        final peerId = int.tryParse('${(ord['buyer'] is Map ? ord['buyer']['id'] : null) ?? ord['buyerId'] ?? ''}');
        final peerName = _name(ord['buyer'], 'Client');
        final ref = (ord['transactionRef'] ?? ord['id'] ?? '').toString();
        final status = (ord['status'] ?? 'PENDING').toString().toUpperCase();
        final bName = _name(ord['buyer'], 'Client');
        final date = _day(ord['createdAt']);
        final payState = PaymentFlow.stateOf(status);
        if (payState == PayState.paymentSent) {
          out.add(AppNotification(
            id: 's_${ref}_pay_sent',
            title: 'Buyer Says They Paid',
            subtitle: '$bName marked their payment as sent. Check your account, then confirm it in Requests.',
            time: date,
            type: 'Bookings',
            chatUserId: peerId,
            chatName: peerName,
            icon: Icons.notifications_active_rounded,
            color: AppColors.warning,
          ));
        } else if (payState == PayState.awaitingPayment) {
          out.add(AppNotification(
            id: 's_${ref}_awaiting',
            title: 'Waiting for Buyer Payment',
            subtitle: PaymentFlow.payMode(ord is Map ? ord : const {}) == 'OFFLINE'
                ? 'You asked $bName to pay first. The booking is accepted once you confirm the payment.'
                : 'You asked $bName to pay first. The booking is accepted automatically when they pay in the app.',
            time: date,
            type: 'Bookings',
            chatUserId: peerId,
            chatName: peerName,
            icon: Icons.hourglass_top_rounded,
            color: AppColors.primary,
          ));
        } else if (status == 'PENDING_ACCEPTANCE') {
          out.add(AppNotification(
            id: 's_${ref}_new',
            title: 'New Service Request',
            subtitle: '$bName has placed a new order with you. Tap to Review & Accept.',
            time: date,
            type: 'Bookings',
            chatUserId: peerId,
            chatName: peerName,
            icon: Icons.notifications_active_rounded,
            color: AppColors.primary,
          ));
        } else if (status == 'COMPLETED' || status == 'RELEASED') {
          out.add(AppNotification(
            id: 's_${ref}_paid',
            title: 'Payment Received',
            subtitle: '$bName confirmed satisfaction. Funds were released to your wallet.',
            time: date,
            type: 'Bookings',
            chatUserId: peerId,
            chatName: peerName,
            icon: Icons.payments_rounded,
            color: AppColors.success,
          ));
        }
      }

      // Price offers: a seller sees new offers to answer; a buyer sees the answer to their offer.
      for (final o in results[4]) {
        if (o is! Map) continue;
        final peerId = int.tryParse('${(o['buyer'] is Map ? o['buyer']['id'] : null) ?? o['buyerId'] ?? ''}');
        final peerName = _name(o['buyer'], 'A customer');
        final id = (o['id'] ?? '').toString();
        final status = (o['status'] ?? '').toString().toUpperCase();
        if (id.isEmpty || status != 'OFFERED') continue;
        final who = _name(o['buyer'], 'A customer');
        final title = (o['serviceTitle'] ?? '').toString();
        out.add(AppNotification(
          id: 'o_${id}_new',
          title: 'New price offer',
          subtitle: '$who made an offer${title.isEmpty ? '' : ' for $title'}. Open Offers to accept or decline.',
          time: _day(o['createdAt']),
          type: 'Bookings',
            chatUserId: peerId,
            chatName: peerName,
          icon: Icons.local_offer_rounded,
          color: AppColors.primary,
        ));
      }
      for (final o in results[3]) {
        if (o is! Map) continue;
        final peerId = int.tryParse('${(o['seller'] is Map ? o['seller']['id'] : null) ?? o['sellerId'] ?? ''}');
        final peerName = _name(o['seller'], 'The provider');
        final id = (o['id'] ?? '').toString();
        final status = (o['status'] ?? '').toString().toUpperCase();
        if (id.isEmpty) continue;
        final who = _name(o['seller'], 'The provider');
        final title = (o['serviceTitle'] ?? '').toString();
        if (status == 'AGREED') {
          out.add(AppNotification(
            id: 'o_${id}_agreed',
            title: 'Your offer was accepted',
            subtitle: '$who agreed to your price${title.isEmpty ? '' : ' for $title'}. Book it before the offer expires.',
            time: _day(o['createdAt']),
            type: 'Bookings',
            chatUserId: peerId,
            chatName: peerName,
            icon: Icons.local_offer_rounded,
            color: AppColors.success,
          ));
        } else if (status == 'REJECTED') {
          out.add(AppNotification(
            id: 'o_${id}_rejected',
            title: 'Your offer was declined',
            subtitle: '$who did not accept your price${title.isEmpty ? '' : ' for $title'}. You can try a different price.',
            time: _day(o['createdAt']),
            type: 'Bookings',
            chatUserId: peerId,
            chatName: peerName,
            icon: Icons.local_offer_outlined,
            color: AppColors.danger,
          ));
        }
      }

      for (final c in results[2]) {
        final unreadMsgs = (c['unreadCount'] as num?)?.toInt() ?? 0;
        if (unreadMsgs <= 0) continue;
        final other = c['recipient'] ?? c['sender'] ?? {};
        final otherId = int.tryParse('${(other is Map ? other['id'] : null) ?? c['otherUserId'] ?? ''}');
        if (ChatPrefs.isMuted(otherId)) continue; // muted: no bell entry
        final cid = (c['id'] ?? c['conversationId'] ?? '').toString();
        final otherName = _name(other, 'User');
        final last = ApiService.chatPreview((c['lastMessage'] ?? c['content'] ?? '').toString());
        // The id includes the count so a NEW message re-marks the entry unread.
        out.add(AppNotification(
          id: 'm_${cid}_$unreadMsgs',
          title: 'New message from $otherName',
          subtitle: last.isEmpty ? '$unreadMsgs unread' : last,
          time: (c['time'] ?? '').toString(),
          type: 'Messages',
          icon: Icons.chat_bubble_rounded,
          color: AppColors.primary,
          chatUserId: otherId,
          chatName: otherName,
          chatOnline: ApiService.parseOnline((other is Map ? (other['isOnline'] ?? other['online']) : null) ?? c['isOnline']),
        ));
      }

      _publish([...out, ..._system]);
    } finally {
      _loading = false;
      if (_again) {
        _again = false;
        refresh();
      }
    }
  }
}

class _FeedLifecycle with WidgetsBindingObserver {
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) NotificationFeed.scheduleRefresh();
  }
}
