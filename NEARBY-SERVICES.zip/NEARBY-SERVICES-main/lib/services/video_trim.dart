import 'dart:io';

import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import 'app_log.dart';

/// Cuts a video down to its first part so the file fits a size limit, without re-encoding
/// (fast, no quality loss). Native code: MediaMuxer on Android, AVAssetExportSession on iOS.
class VideoTrim {
  VideoTrim._();

  static const MethodChannel _channel = MethodChannel('ungana/video');

  /// How much of a [length] video, of [size] bytes, to keep to land 7% under [maxBytes].
  static Duration keepFor(Duration length, int size, int maxBytes) {
    if (size <= maxBytes || size <= 0) return length;
    return Duration(milliseconds: (length.inMilliseconds * (maxBytes * 0.93) / size).floor());
  }

  static Future<Duration?> _duration(String path) async {
    final probe = VideoPlayerController.file(File(path));
    try {
      await probe.initialize();
      return probe.value.duration;
    } catch (caught, trace) {
      AppLog.e('video_trim._duration', caught, trace);
      return null;
    } finally {
      await probe.dispose();
    }
  }

  /// The path to upload: [path] itself when the file is already within [maxBytes] (or its length
  /// cannot be read, or cutting failed), otherwise a new file holding the first part of the video.
  /// The first cut aims 7% under the limit; if the result is still too big it cuts again,
  /// up to 3 times. Never throws; the caller checks the final size.
  static Future<String> fitSize(String path, int maxBytes) async {
    try {
      var size = await File(path).length();
      if (size <= maxBytes) return path;
      final length = await _duration(path);
      if (length == null || length.inMilliseconds <= 0) return path;

      var keepMs = length.inMilliseconds;
      var result = path;
      for (var i = 0; i < 3; i++) {
        keepMs = keepFor(Duration(milliseconds: keepMs), size, maxBytes).inMilliseconds;
        if (keepMs < 1000) break; // less than a second would be left: give up
        final out = await _channel.invokeMethod<String>('trim', {'path': path, 'maxMs': keepMs});
        if (out == null || out.isEmpty) break;
        result = out;
        size = await File(out).length();
        if (size <= maxBytes) break;
      }
      return result;
    } catch (e) {
      AppLog.d('Video trim skipped: $e');
      return path;
    }
  }
}
