import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'api_service.dart';
import 'session_manager.dart';
import 'app_log.dart';

/// Per-account chat settings kept on the phone:
///   - muted conversations (no push banner / bell entry for that person),
///   - "clear chat" marks (messages up to that moment are hidden on this device).
///
/// Local-first: both take effect immediately. Muting is also told to the server
/// (best effort) so it can stop sending that person's push notifications.
///
/// Backend endpoints used (optional, failures are ignored):
///   POST   /chats/{userId}/mute
///   DELETE /chats/{userId}/mute
class ChatPrefs {
  ChatPrefs._();

  /// Bumped on every change so screens can refresh.
  static final ValueNotifier<int> changed = ValueNotifier<int>(0);

  static final Set<int> _muted = {};
  static final Map<int, int> _clearedAt = {}; // userId -> millisecondsSinceEpoch
  static SharedPreferences? _prefs;
  static int _loadedFor = -1;
  static bool _started = false;

  static int get _uid => SessionManager.getUserIdValue();
  static String get _kMuted => 'chat_muted_$_uid';
  static String get _kCleared => 'chat_cleared_$_uid';

  static Future<void> start() async {
    if (_started) return;
    _started = true;
    await _loadLocal();
    SessionManager.sessionNotifier.addListener(() {
      if (_loadedFor != _uid) _loadLocal();
    });
  }

  /// Makes sure the saved values for the signed-in account are loaded.
  static Future<void> ensureLoaded() async {
    if (_prefs == null || _loadedFor != _uid) await _loadLocal();
  }

  static Future<void> _loadLocal() async {
    _prefs ??= await SharedPreferences.getInstance();
    _loadedFor = _uid;
    _muted.clear();
    _clearedAt.clear();
    if (_uid != 0) {
      _muted.addAll((_prefs!.getStringList(_kMuted) ?? []).map(int.tryParse).whereType<int>());
      try {
        final raw = _prefs!.getString(_kCleared);
        if (raw != null) {
          (json.decode(raw) as Map).forEach((k, v) {
            final id = int.tryParse('$k');
            final at = v is num ? v.toInt() : int.tryParse('$v');
            if (id != null && at != null) _clearedAt[id] = at;
          });
        }
      } catch (caught, trace) { AppLog.e('chat_prefs._loadLocal', caught, trace); }
    }
    changed.value++;
  }

  // ---- mute ----------------------------------------------------------------

  static bool isMuted(int? userId) => userId != null && _muted.contains(userId);

  static Future<void> setMuted(int userId, bool muted) async {
    if (_uid == 0) return;
    if (muted) {
      _muted.add(userId);
    } else {
      _muted.remove(userId);
    }
    changed.value++;
    _prefs ??= await SharedPreferences.getInstance();
    await _prefs!.setStringList(_kMuted, _muted.map((e) => '$e').toList());
    // Best effort: lets the server skip push notifications from this person.
    ApiService.setChatMuted(userId, muted);
  }

  // ---- clear chat ----------------------------------------------------------

  /// Messages sent at or before this moment are hidden (null = nothing cleared).
  static DateTime? clearedAt(int? userId) {
    final ms = userId == null ? null : _clearedAt[userId];
    return ms == null ? null : DateTime.fromMillisecondsSinceEpoch(ms);
  }

  static Future<void> clearUpTo(int userId, DateTime moment) async {
    if (_uid == 0) return;
    _clearedAt[userId] = moment.millisecondsSinceEpoch;
    changed.value++;
    _prefs ??= await SharedPreferences.getInstance();
    await _prefs!.setString(_kCleared, json.encode(_clearedAt.map((k, v) => MapEntry('$k', v))));
  }
}
