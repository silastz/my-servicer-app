import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import 'currency_service.dart';

/// Where a booking is in the "pay first" flow.
enum PayState { none, awaitingPayment, paymentSent, disputed }

/// Status vocabulary + helpers for the pay-first / offline-payment flow.
///
/// Server statuses used by this flow (in addition to PENDING_ACCEPTANCE,
/// ACCEPTED, COMPLETED, REJECTED, CANCELLED):
///   AWAITING_PAYMENT   provider asked the buyer to pay before the booking is accepted
///   PAYMENT_SENT       buyer says they paid (offline); provider must confirm
///   PAYMENT_DISPUTED   provider says the money did not arrive
class PaymentFlow {
  PaymentFlow._();

  static String _up(dynamic v) => (v ?? '').toString().toUpperCase();

  static PayState stateOf(dynamic status) {
    final s = _up(status).replaceAll(' ', '_');
    if (s.contains('PAYMENT_DISPUTED') || s.contains('PAYMENT_NOT_RECEIVED')) return PayState.disputed;
    if (s.contains('PAYMENT_SENT')) return PayState.paymentSent;
    if (s.contains('AWAITING_PAYMENT')) return PayState.awaitingPayment;
    return PayState.none;
  }

  /// True while the booking is somewhere in the pay-first flow.
  static bool isOpen(dynamic status) => stateOf(status) != PayState.none;

  static bool isOfflineMethod(Map tx) => _up(tx['paymentMethod']).contains('OFFLINE');

  /// What the buyer chose on the request form: 'HELD' (online payment kept in escrow until the
  /// buyer is satisfied), 'DIRECT' (online payment released to the provider as soon as it is paid)
  /// or '' when the booking carries no choice (older bookings, offline bookings).
  static String payPreference(Map tx) {
    if (isOfflineMethod(tx)) return '';
    final p = _up(tx['paymentPreference']);
    if (p.contains('DIRECT')) return 'DIRECT';
    if (p.contains('HELD') || p.contains('ESCROW')) return 'HELD';
    return '';
  }

  /// How the provider wants to be paid: 'ONLINE' (in the app) or 'OFFLINE' (directly).
  static String payMode(Map tx) {
    final explicit = _up(tx['paymentMode']);
    if (explicit == 'ONLINE' || explicit == 'OFFLINE') return explicit;
    return isOfflineMethod(tx) ? 'OFFLINE' : 'ONLINE';
  }

  /// An online booking (Pocket Fund / mobile money / card) the server says is not paid yet.
  /// Only true when the server actually sends a payment status.
  static bool isUnpaidOnline(Map tx) {
    if (isOfflineMethod(tx)) return false;
    final p = _up(tx['paymentStatus']);
    if (p.isEmpty) return false;
    return p == 'UNPAID' || p == 'NOT_PAID' || p == 'FAILED' || p == 'PENDING_PAYMENT';
  }

  /// An online booking the provider has accepted and the buyer has paid for: the buyer
  /// can now confirm the job is done, which releases the held money to the provider.
  /// Offline bookings are settled directly between the two people, so nothing is held.
  static bool canRelease(Map tx) {
    // Offline bookings hold no money, but the buyer still confirms the job is done: the server then marks the
    // booking COMPLETED, and only a COMPLETED booking can be rated.
    // Paid directly: nothing is held, so there is nothing for the buyer to release.
    if (payPreference(tx) == 'DIRECT') return false;
    if (isUnpaidOnline(tx)) return false;
    final s = _up(tx['status']);
    if (!s.contains('ACCEPTED')) return false;
    const done = ['COMPLETED', 'RELEASED', 'SATISFIED', 'CANCEL', 'REJECT', 'DISPUTE', 'REFUND'];
    for (final d in done) {
      if (s.contains(d)) return false;
    }
    final p = _up(tx['paymentStatus']);
    return !(p.contains('RELEASED') || p.contains('COMPLETED') || p.contains('SATISFIED') || p.contains('REFUND'));
  }

  /// The provider accepted the request and the buyer has not paid yet (online booking).
  /// This is the normal "pay after accept" step: the buyer is asked to pay now.
  static bool awaitingPayAfterAccept(Map tx) {
    final s = _up(tx['status']);
    if (!s.contains('ACCEPTED')) return false;
    for (final d in const ['COMPLETED', 'RELEASED', 'SATISFIED', 'CANCEL', 'REJECT', 'DISPUTE', 'REFUND']) {
      if (s.contains(d)) return false;
    }
    return isUnpaidOnline(tx);
  }

  /// Where the request is on its way: [done] = how many of the 4 steps are finished
  /// (Request sent, Accepted, Paid, Completed); [ended] is 'rejected' / 'cancelled' when it stopped.
  static ({int done, String? ended}) progress(Map tx) {
    final s = _up(tx['status']).replaceAll(' ', '_');
    if (s.contains('REJECT') || s.contains('DECLINE')) return (done: 1, ended: 'rejected');
    if (s.contains('CANCEL')) return (done: 1, ended: 'cancelled');
    if (s.contains('COMPLETED') || s.contains('RELEASED') || s.contains('SATISFIED')) return (done: 4, ended: null);
    if (s.contains('ACCEPTED')) return (done: isUnpaidOnline(tx) ? 2 : 3, ended: null);
    return (done: 1, ended: null); // still waiting for the provider (or the provider asked to pay first)
  }

  static String label(dynamic status) {
    final en = AppStrings.isEnglish;
    switch (stateOf(status)) {
      case PayState.awaitingPayment:
        return en ? 'Awaiting payment' : 'Inasubiri malipo';
      case PayState.paymentSent:
        return en ? 'Payment sent' : 'Malipo yametumwa';
      case PayState.disputed:
        return en ? 'Payment issue' : 'Tatizo la malipo';
      case PayState.none:
        return '';
    }
  }

  static Color color(dynamic status) {
    switch (stateOf(status)) {
      case PayState.awaitingPayment:
        return AppColors.warning;
      case PayState.paymentSent:
        return AppColors.primary;
      case PayState.disputed:
        return AppColors.danger;
      case PayState.none:
        return AppColors.textSecondary;
    }
  }

  static String money(num v) =>
      CurrencyService.format(v);
}
