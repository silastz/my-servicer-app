import 'dart:async';

import 'package:unity_levelplay_mediation/unity_levelplay_mediation.dart';

import '../../models/ads_config.dart';
import 'rewarded_source.dart';
import '../app_log.dart';

/// ironSource / Unity LevelPlay start-up and rewarded video.
///
/// LevelPlay is a mediation layer: besides its own network it can fill with the networks whose
/// adapters are in the app (Meta and AdMob here, see android/app/build.gradle.kts and ADS.md).
/// What it mixes together is decided in the LevelPlay dashboard, not here.
class LevelPlayAds {
  LevelPlayAds._();

  static Future<bool>? _init;

  /// Starts LevelPlay once per app run (a different app key needs an app restart).
  /// Completes true when the SDK is ready. Never throws.
  static Future<bool> init({required String appKey, bool debug = false}) {
    return _init ??= _start(appKey, debug);
  }

  static Future<bool> _start(String appKey, bool debug) async {
    final done = Completer<bool>();
    try {
      await LevelPlay.init(
        initRequest: LevelPlayInitRequest.builder(appKey).build(),
        initListener: _InitListener(done),
      );
      if (debug) {
        // Prints a checklist of the adapters found in the build (Android logcat / Xcode console).
        unawaited(LevelPlay.validateIntegration().catchError((Object _) {}));
      }
    } catch (e) {
      AppLog.d('LevelPlay init threw: $e');
      return false;
    }
    final ok = await done.future.timeout(const Duration(seconds: 30), onTimeout: () => false);
    if (!ok) _init = null; // allow a retry on the next config change
    return ok;
  }
}

class _InitListener implements LevelPlayInitListener {
  _InitListener(this._done);

  final Completer<bool> _done;

  @override
  void onInitFailed(LevelPlayInitError error) {
    AppLog.d('LevelPlay init failed: $error');
    if (!_done.isCompleted) _done.complete(false);
  }

  @override
  void onInitSuccess(LevelPlayConfiguration configuration) {
    if (!_done.isCompleted) _done.complete(true);
  }
}

class LevelPlayRewarded implements RewardedSource, LevelPlayRewardedAdListener {
  LevelPlayRewarded(this.adUnitId);

  final String adUnitId;
  LevelPlayRewardedAd? _ad;
  bool _ready = false;
  bool _earned = false;
  Completer<bool>? _loaded;
  Completer<RewardedResult>? _showDone;

  @override
  AdProvider get provider => AdProvider.ironsource;

  @override
  bool get isReady => _ready;

  @override
  Future<bool> load() async {
    final loaded = Completer<bool>();
    _loaded = loaded;
    final ad = LevelPlayRewardedAd(adUnitId: adUnitId);
    ad.setListener(this);
    _ad = ad;
    try {
      await ad.loadAd();
    } catch (e) {
      AppLog.d('LevelPlay rewarded load threw: $e');
      if (!loaded.isCompleted) loaded.complete(false);
    }
    return loaded.future;
  }

  @override
  Future<RewardedResult> show() async {
    final ad = _ad;
    if (ad == null || !_ready) return RewardedResult.unavailable;
    try {
      if (!await ad.isAdReady()) return RewardedResult.unavailable;
      _ready = false; // an ad can only be shown once
      final done = Completer<RewardedResult>();
      _showDone = done;
      await ad.showAd();
      return done.future.timeout(rewardedShowTimeout, onTimeout: () => RewardedResult.unavailable);
    } catch (e) {
      AppLog.d('LevelPlay rewarded show threw: $e');
      return RewardedResult.unavailable;
    }
  }

  @override
  void dispose() {
    final ad = _ad;
    _ad = null;
    _ready = false;
    if (ad != null) unawaited(ad.dispose().catchError((Object _) {}));
  }

  void _finish(RewardedResult r) {
    final done = _showDone;
    if (done != null && !done.isCompleted) done.complete(r);
  }

  // ---- LevelPlayRewardedAdListener ----

  @override
  void onAdLoaded(LevelPlayAdInfo adInfo) {
    _ready = true;
    final l = _loaded;
    if (l != null && !l.isCompleted) l.complete(true);
  }

  @override
  void onAdLoadFailed(LevelPlayAdError error) {
    AppLog.d('LevelPlay rewarded failed to load: $error');
    final l = _loaded;
    if (l != null && !l.isCompleted) l.complete(false);
  }

  @override
  void onAdDisplayed(LevelPlayAdInfo adInfo) {}

  @override
  void onAdDisplayFailed(LevelPlayAdError error, LevelPlayAdInfo adInfo) {
    AppLog.d('LevelPlay rewarded failed to show: $error');
    _finish(RewardedResult.unavailable);
  }

  @override
  void onAdClicked(LevelPlayAdInfo adInfo) {}

  @override
  void onAdClosed(LevelPlayAdInfo adInfo) => _finish(_earned ? RewardedResult.rewarded : RewardedResult.skipped);

  @override
  void onAdInfoChanged(LevelPlayAdInfo adInfo) {}

  @override
  void onAdRewarded(LevelPlayReward reward, LevelPlayAdInfo adInfo) => _earned = true;
}
