import 'dart:async';

import 'package:flutter/material.dart';

import '../../models/ads_config.dart';
import '../../models/house_ads.dart';
import '../../widgets/house_rewarded_screen.dart';
import 'rewarded_source.dart';
import '../app_log.dart';

/// The admin's own rewarded ad (see lib/models/house_ads.dart): a full-screen page with the ad's
/// picture, title, text and button. The reward is earned after [HouseAd.rewardSeconds]; closing
/// before that counts as "skipped" (the provider video does not play), like any other network.
///
/// Needs no ad network: [load] only downloads the picture, so the ad opens at once when shown.
class HouseRewarded implements RewardedSource {
  HouseRewarded(this.ad, this._navKey);

  final HouseAd ad;
  final GlobalKey<NavigatorState>? _navKey;

  ImageProvider? _image;
  bool _ready = false;

  @override
  AdProvider get provider => AdProvider.inhouse;

  @override
  bool get isReady => _ready;

  @override
  Future<bool> load() {
    final done = Completer<bool>();
    final image = NetworkImage(ad.imageUrl);
    final stream = image.resolve(ImageConfiguration.empty);
    late final ImageStreamListener listener;
    listener = ImageStreamListener(
      (info, sync) {
        stream.removeListener(listener);
        _image = image;
        _ready = true;
        if (!done.isCompleted) done.complete(true);
      },
      onError: (error, stack) {
        AppLog.d('House rewarded image failed: $error');
        stream.removeListener(listener);
        if (!done.isCompleted) done.complete(false);
      },
    );
    stream.addListener(listener);
    return done.future;
  }

  @override
  Future<RewardedResult> show() async {
    final nav = _navKey?.currentState;
    final image = _image;
    if (!_ready || nav == null || !nav.mounted || image == null) return RewardedResult.unavailable;
    _ready = false; // an ad can only be shown once
    try {
      final result = await nav.push<RewardedResult>(
        MaterialPageRoute(
          fullscreenDialog: true,
          builder: (_) => HouseRewardedScreen(ad: ad, image: image),
        ),
      );
      return (result ?? RewardedResult.skipped);
    } catch (e) {
      AppLog.d('House rewarded show failed: $e');
      return RewardedResult.unavailable;
    }
  }

  @override
  void dispose() {
    _ready = false;
    _image = null;
  }
}
