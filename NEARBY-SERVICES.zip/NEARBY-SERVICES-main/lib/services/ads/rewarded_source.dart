import '../../models/ads_config.dart';

/// Outcome of [AdService.showRewarded]:
///  * [unavailable] - no ad could be shown (ads off, not loaded, or a show error).
///    The caller should let the user continue anyway.
///  * [rewarded]    - the user watched it and earned the reward.
///  * [skipped]     - the user closed it before the reward.
enum RewardedResult { rewarded, skipped, unavailable }

/// One rewarded video ad of one network. [AdService] asks the networks in order until one has
/// an ad ready; each network implements this the same way.
abstract class RewardedSource {
  AdProvider get provider;

  /// An ad is loaded and can be shown right now.
  bool get isReady;

  /// Starts loading. Completes true when an ad is ready, false when the network has none.
  Future<bool> load();

  /// Shows the ad and reports what the user did. Call only when [isReady].
  Future<RewardedResult> show();

  /// Frees the ad. Call once it was shown or is no longer wanted.
  void dispose();
}

/// How long a rewarded ad may stay on screen before we give up waiting for its "closed" event
/// (a safety net so a lost callback can never block the video the user asked for).
const Duration rewardedShowTimeout = Duration(minutes: 3);
