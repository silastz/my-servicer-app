import 'dart:async';

import 'package:google_mobile_ads/google_mobile_ads.dart';

import '../../models/ads_config.dart';
import 'rewarded_source.dart';
import '../app_log.dart';

/// Google AdMob start-up and rewarded video.
class AdmobAds {
  AdmobAds._();

  /// Never throws: the app works the same without ads.
  static Future<bool> init() async {
    try {
      await MobileAds.instance.updateRequestConfiguration(
        RequestConfiguration(
          // The app has some 18+ listings: keep ads family-friendly. Change to
          // MaxAdContentRating.t or .ma if you want more ad demand.
          maxAdContentRating: MaxAdContentRating.pg,
        ),
      );
      await MobileAds.instance.initialize();
      return true;
    } catch (e) {
      AppLog.d('AdMob init failed: $e');
      return false;
    }
  }
}

class AdmobRewarded implements RewardedSource {
  AdmobRewarded(this.unitId);

  final String unitId;
  RewardedAd? _ad;

  @override
  AdProvider get provider => AdProvider.admob;

  @override
  bool get isReady => _ad != null;

  @override
  Future<bool> load() {
    final done = Completer<bool>();
    RewardedAd.load(
      adUnitId: unitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _ad = ad;
          if (!done.isCompleted) done.complete(true);
        },
        onAdFailedToLoad: (error) {
          AppLog.d('AdMob rewarded failed to load: $error');
          if (!done.isCompleted) done.complete(false);
        },
      ),
    );
    return done.future;
  }

  @override
  Future<RewardedResult> show() async {
    final ad = _ad;
    if (ad == null) return RewardedResult.unavailable;
    _ad = null; // an ad can only be shown once
    final done = Completer<RewardedResult>();
    var earned = false;

    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        if (!done.isCompleted) done.complete(earned ? RewardedResult.rewarded : RewardedResult.skipped);
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        AppLog.d('AdMob rewarded failed to show: $error');
        ad.dispose();
        if (!done.isCompleted) done.complete(RewardedResult.unavailable);
      },
    );

    try {
      await ad.show(onUserEarnedReward: (_, _) => earned = true);
    } catch (e) {
      AppLog.d('AdMob rewarded show threw: $e');
      ad.dispose();
      if (!done.isCompleted) done.complete(RewardedResult.unavailable);
    }
    return done.future.timeout(rewardedShowTimeout, onTimeout: () => RewardedResult.unavailable);
  }

  @override
  void dispose() {
    _ad?.dispose();
    _ad = null;
  }
}
