import 'dart:async';

import 'package:easy_audience_network/easy_audience_network.dart' as fan;

import '../../models/ads_config.dart';
import 'rewarded_source.dart';
import '../app_log.dart';

/// Facebook (Meta) Audience Network start-up and rewarded video.
/// Uses the vendored plugin in packages/easy_audience_network.
class FacebookAds {
  FacebookAds._();

  /// [testMode] asks Facebook for test ads on this device. Never throws.
  static Future<bool> init({required bool testMode}) async {
    try {
      final ok = await fan.EasyAudienceNetwork.init(testMode: testMode);
      return ok == true;
    } catch (e) {
      AppLog.d('Facebook Audience Network init failed: $e');
      return false;
    }
  }
}

class FacebookRewarded implements RewardedSource {
  FacebookRewarded(this.placementId);

  final String placementId;
  fan.RewardedAd? _ad;
  bool _ready = false;
  bool _earned = false;
  bool _destroyed = false;
  Completer<RewardedResult>? _showDone;

  @override
  AdProvider get provider => AdProvider.facebook;

  @override
  bool get isReady => _ready;

  @override
  Future<bool> load() {
    final loaded = Completer<bool>();
    final ad = fan.RewardedAd(placementId);
    _ad = ad;
    ad.listener = fan.RewardedAdListener(
      onLoaded: () {
        _ready = true;
        if (!loaded.isCompleted) loaded.complete(true);
      },
      onError: (code, message) {
        AppLog.d('Facebook rewarded error $code: $message');
        if (!loaded.isCompleted) loaded.complete(false);
        // An error while the ad is on screen must not leave the caller waiting.
        final show = _showDone;
        if (show != null && !show.isCompleted) show.complete(RewardedResult.unavailable);
      },
      onVideoComplete: () => _earned = true,
      onVideoClosed: () {
        final show = _showDone;
        if (show != null && !show.isCompleted) {
          show.complete(_earned ? RewardedResult.rewarded : RewardedResult.skipped);
        }
      },
    );
    ad.load().catchError((Object e) {
      AppLog.d('Facebook rewarded load threw: $e');
      if (!loaded.isCompleted) loaded.complete(false);
    });
    return loaded.future;
  }

  @override
  Future<RewardedResult> show() async {
    final ad = _ad;
    if (ad == null || !_ready) return RewardedResult.unavailable;
    _ready = false; // an ad can only be shown once
    final done = Completer<RewardedResult>();
    _showDone = done;
    try {
      await ad.show();
    } catch (e) {
      AppLog.d('Facebook rewarded show threw: $e');
      if (!done.isCompleted) done.complete(RewardedResult.unavailable);
    }
    return done.future.timeout(rewardedShowTimeout, onTimeout: () => RewardedResult.unavailable);
  }

  @override
  void dispose() {
    final ad = _ad;
    _ad = null;
    _ready = false;
    if (ad == null || _destroyed) return;
    _destroyed = true;
    ad.destroy().catchError((Object e) => AppLog.d('Facebook rewarded destroy threw: $e'));
  }
}
