import 'app_policy.dart';
import 'notification_service.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'currency_service.dart';
import 'chat_socket.dart';
import 'app_log.dart';

class SessionManager {
  static const String _keyToken = 'auth_token';
  static const String _keyUserId = 'user_id';
  static const String _keyUsername = 'username';
  static const String _keyStageName = 'stage_name';
  static const String _keyRole = 'user_role';
  static const String _keyBadge = 'user_badge';
  static const String _keyCity = 'user_city';
  static const String _keyPhone = 'user_phone';
  static const String _keyEmail = 'user_email';
  static const String _keyAvatar = 'user_avatar_url';
  static const String _keyCover = 'user_cover_url';
  static const String _keyBio = 'user_bio';

  static SharedPreferences? _prefs;

  // The auth token lives in encrypted storage (Android Keystore / iOS Keychain),
  // never in plain SharedPreferences. It is mirrored in memory for sync reads.
  static const FlutterSecureStorage _secure = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );
  static String? _token;

  static Future<void> init() async {
    _prefs ??= await SharedPreferences.getInstance();
    try {
      _token = await _secure.read(key: _keyToken);
      // One-time migration of tokens saved by older versions in plain prefs.
      final legacy = _prefs!.getString(_keyToken);
      if (legacy != null) {
        if (_token == null || _token!.isEmpty) {
          _token = legacy;
          await _secure.write(key: _keyToken, value: legacy);
        }
        await _prefs!.remove(_keyToken);
      }
    } catch (e) {
      AppLog.d('Secure storage unavailable: $e');
      _token = null; // fail closed: user simply signs in again
    }
  }

  /// The server sent a renewed token (sliding login). Kept only when the login that made the
  /// request is still the signed-in one, so a late reply can never bring back a signed-out account.
  static Future<void> replaceToken(String fresh, {required String? sentWith}) async {
    if (fresh.isEmpty || sentWith == null || _token != sentWith) return;
    await _writeToken(fresh);
  }

  static Future<void> _writeToken(String token) async {
    _token = token;
    try {
      await _secure.write(key: _keyToken, value: token);
    } catch (e) {
      AppLog.d('Secure storage write failed: $e');
    }
  }

  static Future<void> saveSession({
    required String token,
    required int userId,
    required String username,
    required String stageName,
    required String role,
    required String badge,
    String? currency, // wallet currency the server says this account uses (country 'KE' or code 'KES')
  }) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await _writeToken(token);
    await prefs.setInt(_keyUserId, userId);
    await prefs.setString(_keyUsername, username);
    await prefs.setString(_keyStageName, stageName);
    await prefs.setString(_keyRole, role);
    await prefs.setString(_keyBadge, badge);
    NotificationService.login(userId.toString(), role: role);
    // Money: the server's account currency wins; otherwise keep what was detected from now on.
    if (currency != null && currency.trim().isNotEmpty && currency.trim() != 'null') {
      await CurrencyService.setAccountCurrency(currency);
    } else {
      await CurrencyService.lockCurrent();
    }
    ChatSocket.start(); // live chat as soon as someone signs in
    notifySessionChanged();
  }

  static String? getToken() {
    return _token;
  }

  static bool isLoggedIn() {
    final token = getToken();
    return token != null && token.isNotEmpty;
  }

  static String getStageName() {
    return _prefs?.getString(_keyStageName) ?? 'Guest User';
  }

  static String getUsername() {
    return _prefs?.getString(_keyUsername) ?? 'guest';
  }

  static int getUserIdValue() {
    return _prefs?.getInt(_keyUserId) ?? 0;
  }

  static String getRole() {
    return _prefs?.getString(_keyRole) ?? 'ROLE_BUYER';
  }

  static String getBadge() {
    return _prefs?.getString(_keyBadge) ?? 'NONE';
  }

  /// Badge model: GREEN_BADGE = identity fully verified (ID + selfie, or a trusted
  /// invitation); BLUE_TICK = Verified Business (always on top of an identity).
  /// Either one means the identity is verified.
  static bool isIdentityVerified() {
    final b = getBadge();
    return b == 'GREEN_BADGE' || b == 'BLUE_TICK';
  }

  /// Green and Blue providers can invite someone they know. An invitation only
  /// covers identity: the invitee gets Green, never Blue.
  static bool canInvite() => isIdentityVerified();

  static String getUserCity() {
    return _prefs?.getString(_keyCity) ?? '';
  }

  static bool hasUserCity() {
    return (_prefs?.getString(_keyCity) ?? '').trim().isNotEmpty;
  }

  static String getPhone() {
    return _prefs?.getString(_keyPhone) ?? '';
  }

  static String getEmail() => _prefs?.getString(_keyEmail) ?? '';

  static Future<void> saveEmail(String email) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setString(_keyEmail, email);
    notifySessionChanged();
  }

  /// The display (stage) name shown on the profile and to other users.
  static Future<void> saveStageName(String name) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setString(_keyStageName, name);
    notifySessionChanged();
  }

  static Future<void> savePhone(String phone) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setString(_keyPhone, phone);
  }

  /// The signed-in user's profile photo URL ('' when none). Cleared on sign-out.
  static String getAvatarUrl() => _prefs?.getString(_keyAvatar) ?? '';

  /// The provider's own cover photo (empty = none).
  static String getCoverUrl() => _prefs?.getString(_keyCover) ?? '';

  static Future<void> saveCoverUrl(String url) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    if (url.trim().isEmpty) {
      await prefs.remove(_keyCover);
    } else {
      await prefs.setString(_keyCover, url.trim());
    }
    notifySessionChanged();
  }

  /// The "About me" text shown on the provider's public profile.
  static String getBio() => _prefs?.getString(_keyBio) ?? '';

  static Future<void> saveBio(String bio) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    if (bio.trim().isEmpty) {
      await prefs.remove(_keyBio);
    } else {
      await prefs.setString(_keyBio, bio.trim());
    }
    notifySessionChanged();
  }

  static Future<void> saveAvatarUrl(String url) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    if (url.trim().isEmpty) {
      await prefs.remove(_keyAvatar);
    } else {
      await prefs.setString(_keyAvatar, url.trim());
    }
    notifySessionChanged(); // pages showing your own photo (profile, seller page) update at once, like cover and About me
  }

  /// Verified photo (face check). The server decides the status; this is its last known copy.
  /// Status: 'NONE' | 'PENDING' | 'VERIFIED' | 'REJECTED'. Cleared on sign-out.
  static String getVerifiedPhotoUrl() => _prefs?.getString('user_verified_photo_url') ?? '';
  static String getVerifiedPhotoStatus() => _prefs?.getString('user_verified_photo_status') ?? 'NONE';

  static Future<void> saveVerifiedPhoto({String? url, required String status}) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    final u = (url ?? '').trim();
    if (u.isEmpty) {
      await prefs.remove('user_verified_photo_url');
    } else {
      await prefs.setString('user_verified_photo_url', u);
    }
    await prefs.setString('user_verified_photo_status', status.toUpperCase());
  }

  /// Name read from the user's ID by the server ('' when none) and its status:
  /// 'NONE' | 'PENDING' | 'VERIFIED' | 'REJECTED'. Cleared on sign-out.
  static String getVerifiedName() => _prefs?.getString('user_verified_name') ?? '';
  static String getVerifiedNameStatus() => _prefs?.getString('user_verified_name_status') ?? 'NONE';

  /// The NIN was saved with the legal name (only this flag is kept, never the number). Cleared on sign-out.
  static bool isNinSaved() => _prefs?.getBool('user_nin_saved') ?? false;
  static Future<void> saveNinSaved(bool v) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setBool('user_nin_saved', v);
  }

  /// The ID front (and back, when the ID has one) is approved by the server. Saved by the Identity
  /// Verification screen; the selfie is NOT needed for this. Cleared on sign-out.
  static bool isIdDocsApproved() => _prefs?.getBool('user_id_docs_approved') ?? false;
  static Future<void> saveIdDocsApproved(bool v) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setBool('user_id_docs_approved', v);
  }

  /// The ID front/back is approved (or identity is already verified) but the legal name is not
  /// VERIFIED yet: the server confirms the name with the ID by itself, so the user types nothing.
  static bool isLegalNameConfirming() =>
      (isIdDocsApproved() || isIdentityVerified()) && getVerifiedNameStatus() != 'VERIFIED';

  static Future<void> saveVerifiedName({String? name, required String status}) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    final n = (name ?? '').trim();
    if (n.isEmpty) {
      await prefs.remove('user_verified_name');
    } else {
      await prefs.setString('user_verified_name', n);
    }
    await prefs.setString('user_verified_name_status', status.toUpperCase());
  }

  /// The legal name the user typed in Identity Verification (a claim, not verified). Prefills the field.
  static String getIdFullName() => _prefs?.getString('user_id_full_name') ?? '';
  static Future<void> saveIdFullName(String name) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setString('user_id_full_name', name.trim());
  }

  /// Last known Verified Business status (the server decides). Cleared on sign-out.
  static String getVerifiedBusinessStatus() => _prefs?.getString('user_verified_business_status') ?? 'NONE';
  static Future<void> saveVerifiedBusinessStatus(String status) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setString('user_verified_business_status', status.toUpperCase());
  }

  // Own social handles, shown on the profile when it is Unlocked.
  static const List<String> socialKeys = ['whatsapp', 'instagram', 'facebook', 'x', 'tiktok', 'youtube'];

  static String getSocial(String key) => _prefs?.getString('user_social_$key') ?? '';

  static Future<void> saveSocial(String key, String value) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    final v = value.trim();
    if (v.isEmpty) {
      await prefs.remove('user_social_$key');
    } else {
      await prefs.setString('user_social_$key', v);
    }
  }

  /// Country (ISO code, e.g. 'KE') detected from the device's network location.
  static String getCountryIso() => _prefs?.getString('detected_country_iso') ?? '';

  static Future<void> saveCountryIso(String iso) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setString('detected_country_iso', iso);
  }

  static Future<void> saveUserCity(String city) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setString(_keyCity, city);
    notifySessionChanged();
  }

  static Future<void> saveBadge(String badge) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setString(_keyBadge, badge);
    notifySessionChanged();
  }

  // Verification documents this provider has uploaded from this device
  // (the server stays the source of truth for approval status).
  static String get _docsKey => 'docs_submitted_${getUserIdValue()}';

  static Set<String> getSubmittedDocs() => (_prefs?.getStringList(_docsKey) ?? const <String>[]).toSet();

  static Future<void> addSubmittedDoc(String type) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    final set = getSubmittedDocs()..add(type);
    await prefs.setStringList(_docsKey, set.toList());
    notifySessionChanged();
  }

  // How this provider works and how far they cover: [type, radius km, area].
  // Saved per user on this device by the "Service Radius" sheet.
  static String get _coverageKey => 'service_coverage_${getUserIdValue()}';

  /// Null until the user has saved it once.
  static ({String type, double radiusKm, String area})? getServiceCoverage() {
    final v = _prefs?.getStringList(_coverageKey);
    if (v == null || v.length != 3) return null;
    final km = double.tryParse(v[1]);
    if (km == null) return null;
    return (type: v[0], radiusKm: km, area: v[2]);
  }

  static Future<void> saveServiceCoverage({required String type, required double radiusKm, required String area}) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setStringList(_coverageKey, [type, radiusKm.toString(), area]);
    notifySessionChanged();
  }

  // Which identity document the user verifies with (nida, voter, ...).
  static String get _idKindKey => 'id_kind_${getUserIdValue()}';

  static String getIdKind() => _prefs?.getString(_idKindKey) ?? 'nida';

  static Future<void> saveIdKind(String kind) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setString(_idKindKey, kind);
  }

  // Provider one-time registration fee (TSh). Stored per user on this device;
  // null = unknown (older accounts), the server is asked in that case.
  static int get registrationFee => AppPolicy.registrationFee ?? 10000;

  /// True once the server's policy gave the real fee. Until then [registrationFee] is only a placeholder
  /// that screens must not show as an amount.
  static bool get registrationFeeKnown => AppPolicy.registrationFee != null;

  // The registration fee covers this many services. Every service after that costs [serviceFee] (TSh).
  // The server is the source of truth for both numbers. The admin's policy (docs/app_policy_api_contract.md)
  // or, failing that, the built-in defaults are only what the screen shows before the server answers.
  static int get freeServiceLimit => AppPolicy.freeServiceLimit ?? 2;
  static int get serviceFee => AppPolicy.serviceFee ?? 5000;

  static String get _feeKey => 'reg_fee_paid_${getUserIdValue()}';

  static bool? getRegFeePaid() {
    final prefs = _prefs;
    if (prefs == null || !prefs.containsKey(_feeKey)) return null;
    return prefs.getBool(_feeKey);
  }

  static Future<void> setRegFeePaid(bool paid) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setBool(_feeKey, paid);
    notifySessionChanged();
  }

  static bool isSeller() {
    return getRole() == 'ROLE_SELLER';
  }

  /// Only decides whether the admin entry is SHOWN. The role is stored on the phone, so it
  /// proves nothing: every /admin/* call is checked again by the server (403 for non-admins).
  static bool isAdmin() {
    return isLoggedIn() && getRole() == 'ROLE_ADMIN';
  }

  static final ValueNotifier<int> sessionNotifier = ValueNotifier<int>(0);

  static void notifySessionChanged() {
    sessionNotifier.value++;
  }

  /// Bumped when the server rejected our token (401): the app closes open pages and tells the user.
  static final ValueNotifier<int> sessionExpired = ValueNotifier<int>(0);
  static bool _expiring = false;

  /// The server said the login is no longer valid. Clears the session once (many requests can
  /// fail with 401 at the same moment) and signals [sessionExpired].
  static Future<void> expireSession() async {
    if (_expiring || _token == null || _token!.isEmpty) return;
    _expiring = true;
    try {
      await clearSession();
      sessionExpired.value++;
    } finally {
      _expiring = false;
    }
  }

  static Future<void> updateRole(String newRole) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setString(_keyRole, newRole);
    NotificationService.setRole(newRole);
    notifySessionChanged();
  }

  static const String _keyStartupPermissionsPrompted = 'startup_permissions_prompted';

  static bool hasPromptedStartupPermissions() {
    return _prefs?.getBool(_keyStartupPermissionsPrompted) ?? false;
  }

  static Future<void> markStartupPermissionsPrompted() async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    await prefs.setBool(_keyStartupPermissionsPrompted, true);
  }

  static const String _keyFavorites = 'user_favorite_services';

  static List<String> getFavoriteIds() {
    return _prefs?.getStringList(_keyFavorites) ?? [];
  }

  static bool isFavorite(String serviceId) {
    return getFavoriteIds().contains(serviceId);
  }

  static Future<bool> toggleFavorite(String serviceId) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    final list = List<String>.from(getFavoriteIds());
    bool isNowFav;
    if (list.contains(serviceId)) {
      list.remove(serviceId);
      isNowFav = false;
    } else {
      list.add(serviceId);
      isNowFav = true;
    }
    await prefs.setStringList(_keyFavorites, list);
    notifySessionChanged();
    return isNowFav;
  }

  static const String _keyHiddenServices = 'user_hidden_services';

  static List<String> getHiddenServiceIds() => _prefs?.getStringList(_keyHiddenServices) ?? [];

  static bool isServiceHidden(String serviceId) => getHiddenServiceIds().contains(serviceId);

  /// "Not interested": the service is left out of lists on this device.
  static Future<void> setServiceHidden(String serviceId, bool hidden) async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    final list = List<String>.from(getHiddenServiceIds());
    if (hidden) {
      if (!list.contains(serviceId)) list.add(serviceId);
    } else {
      list.remove(serviceId);
    }
    await prefs.setStringList(_keyHiddenServices, list);
    notifySessionChanged();
  }

  static Future<void> clearSession() async {
    final prefs = _prefs ?? await SharedPreferences.getInstance();
    _token = null;
    try {
      await _secure.delete(key: _keyToken);
    } catch (caught, trace) { AppLog.e('session_manager.clearSession', caught, trace); }
    await prefs.remove(_keyToken);
    await prefs.remove(_keyPhone);
    await prefs.remove(_keyEmail);
    await prefs.remove(_keyAvatar);
    await prefs.remove(_keyCover);
    await prefs.remove(_keyBio);
    await prefs.remove('user_verified_photo_url');
    await prefs.remove('user_verified_photo_status');
    await prefs.remove('user_verified_name');
    await prefs.remove('user_verified_name_status');
    await prefs.remove('user_id_docs_approved');
    await prefs.remove('user_nin_saved');
    await prefs.remove('user_id_full_name');
    await prefs.remove('user_verified_business_status');
    for (final k in socialKeys) {
      await prefs.remove('user_social_$k');
    }
    await prefs.remove(_keyUserId);
    await prefs.remove(_keyUsername);
    await prefs.remove(_keyStageName);
    await prefs.remove(_keyRole);
    await prefs.remove(_keyBadge);
    await CurrencyService.reset(); // signed out: money follows the detected country again
    NotificationService.logout();
    ChatSocket.stop();
    notifySessionChanged();
  }
}

