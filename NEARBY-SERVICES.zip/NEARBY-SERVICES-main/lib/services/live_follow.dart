import 'dart:math' as math;

import 'package:latlong2/latlong.dart';

import 'navigation_engine.dart';

const Distance _dist = Distance();

/// Signed shortest turn (degrees, -180..180) that takes compass angle [a] to [b].
double angleDelta(double a, double b) => ((b - a + 540) % 360) - 180;

/// Interpolates between two compass angles the short way round (degrees, 0..360).
double lerpAngle(double a, double b, double t) => (a + angleDelta(a, b) * t + 360) % 360;

/// Compass bearing from [a] to [b], 0..360 (0 = north, clockwise).
double bearingDeg(LatLng a, LatLng b) => (_dist.bearing(a, b) + 360) % 360;

/// Makes a map marker glide from one reported GPS fix to the next instead of jumping.
///
/// Call [push] whenever a NEW fix arrives and [tick] on every animation frame; read [position]
/// and [heading] to draw the marker. Time is passed in, so it is easy to test.
///
/// - The glide lasts as long as the gap between the last two fixes (clamped), so the marker is
///   always moving, one fix behind reality, which is what makes it look continuous.
/// - A jump bigger than [snapAboveM] (reconnect, GPS glitch) snaps instead of flying across the map.
/// - The heading comes from the device when given, otherwise from the direction of travel, and
///   turns the short way round with a little easing.
class LiveGlide {
  LiveGlide({
    this.minGlide = const Duration(milliseconds: 1200),
    this.maxGlide = const Duration(seconds: 8),
    this.snapAboveM = 600,
    this.bearingFromMovement = true,
  });

  final Duration minGlide;
  final Duration maxGlide;
  final double snapAboveM;

  /// When the device gives no heading, derive one from the movement between fixes.
  final bool bearingFromMovement;

  LatLng? _from;
  LatLng? _to;
  LatLng? _pos;
  DateTime _t0 = DateTime.fromMillisecondsSinceEpoch(0);
  Duration _dur = const Duration(seconds: 1);
  DateTime? _lastFix;
  DateTime? _lastTick;
  double _heading = 0;
  double _targetHeading = 0;
  bool _hasHeading = false;
  double _speed = 0; // m/s, smoothed between fixes

  /// Where to draw the marker right now.
  LatLng? get position => _pos;

  /// The newest reported fix (where the marker is gliding to).
  LatLng? get target => _to;

  /// Smoothed heading in degrees (0 = north, clockwise).
  double get heading => _heading;
  bool get hasHeading => _hasHeading;

  /// Ground speed in m/s from the last fixes; 0 when no new fix arrived for a while.
  double speed([DateTime? now]) {
    final last = _lastFix;
    if (last == null) return 0;
    final t = now ?? DateTime.now();
    return t.difference(last) > const Duration(seconds: 8) ? 0 : _speed;
  }

  /// True while the person is actually travelling (not just standing with GPS noise).
  bool moving([DateTime? now]) => speed(now) > 0.8;

  /// Forget everything; the next [push] places the marker directly.
  void reset() {
    _from = _to = _pos = null;
    _lastFix = _lastTick = null;
    _speed = 0;
    _hasHeading = false;
    _heading = _targetHeading = 0;
  }

  void _aim(double h) {
    _targetHeading = h % 360;
    if (!_hasHeading) {
      _hasHeading = true;
      _heading = _targetHeading; // first heading: no sweep from north
    }
  }

  /// A new fix. Identical repeats are ignored, so callers may push on every poll.
  void push(LatLng p, {double? heading, DateTime? now}) {
    final t = now ?? DateTime.now();
    final cur = _pos;
    final last = _to;
    if (cur == null || last == null) {
      _from = _to = _pos = p;
      _lastFix = t;
      _lastTick = t;
      if (heading != null && heading >= 0) _aim(heading);
      return;
    }
    final moved = _dist.as(LengthUnit.Meter, last, p);
    if (heading != null && heading >= 0) _aim(heading);
    if (moved < 0.5) return;

    if (moved > snapAboveM) {
      _from = _to = _pos = p;
      _lastFix = t;
      _lastTick = t;
      _speed = 0;
      return;
    }

    final since = _lastFix == null ? maxGlide : t.difference(_lastFix!);
    var dur = since;
    if (dur < minGlide) dur = minGlide;
    if (dur > maxGlide) dur = maxGlide;

    if (since.inMilliseconds >= 800) {
      final inst = math.min(60.0, moved / (since.inMilliseconds / 1000.0));
      _speed = _speed == 0 ? inst : _speed * 0.6 + inst * 0.4;
    }
    if (bearingFromMovement && (heading == null || heading < 0) && moved >= 3) {
      _aim(bearingDeg(last, p));
    }

    _from = cur; // glide on from where the marker is drawn now, never from a stale fix
    _to = p;
    _t0 = t;
    _dur = dur;
    _lastFix = t;
    _lastTick = t;
  }

  /// Advances the animation. Returns true while something is still moving.
  bool tick([DateTime? now]) {
    final t = now ?? DateTime.now();
    final from = _from;
    final to = _to;
    if (from == null || to == null) return false;

    final ms = math.max(1, _dur.inMilliseconds);
    final k = (t.difference(_t0).inMilliseconds / ms).clamp(0.0, 1.0).toDouble();
    _pos = k >= 1
        ? to
        : LatLng(
            from.latitude + (to.latitude - from.latitude) * k,
            from.longitude + (to.longitude - from.longitude) * k,
          );

    final dt = _lastTick == null ? 0.016 : math.min(0.1, t.difference(_lastTick!).inMicroseconds / 1e6);
    _lastTick = t;
    final diff = angleDelta(_heading, _targetHeading);
    if (diff.abs() < 0.5) {
      _heading = _targetHeading;
    } else {
      _heading = lerpAngle(_heading, _targetHeading, 1 - math.exp(-dt / 0.22));
    }
    return k < 1 || angleDelta(_heading, _targetHeading).abs() > 0.5;
  }
}

/// How far someone is from the other person, and how long it will take them.
class LiveEta {
  final double remainingM;
  final double seconds;

  /// True when it is only a straight-line guess (no road route available).
  final bool approximate;

  const LiveEta(this.remainingM, this.seconds, {this.approximate = false});

  /// Remaining road distance divided by a speed that blends the route's own average speed
  /// with how fast the person is really travelling. Someone stuck at a standstill falls back
  /// to the route speed, so the ETA does not shoot to infinity at a traffic light.
  static double secondsFor(double remainingM, {required double routeSpeedMps, double observedMps = 0}) {
    if (remainingM <= 0) return 0;
    var v = (routeSpeedMps.isFinite && routeSpeedMps > 0) ? routeSpeedMps : 8.3;
    if (observedMps >= 1.0) v = 0.5 * v + 0.5 * observedMps;
    v = v.clamp(1.5, 35.0).toDouble();
    return remainingM / v;
  }

  static double routeSpeed(NavRoute r) => r.durationS > 0 ? r.distanceM / r.durationS : 8.3;

  factory LiveEta.fromRoute(
    NavRoute route, {
    required double remainingM,
    double observedMps = 0,
    bool approximate = false,
  }) =>
      LiveEta(
        remainingM,
        secondsFor(remainingM, routeSpeedMps: routeSpeed(route), observedMps: observedMps),
        approximate: approximate,
      );

  /// Before any road route is known: straight line at ~30 km/h.
  factory LiveEta.straight(double metres, {double observedMps = 0}) => LiveEta(
        metres,
        secondsFor(metres, routeSpeedMps: 8.3, observedMps: observedMps),
        approximate: true,
      );
}

/// Wording for the live status ("8 min away · 2.4 km"), English and Swahili.
class LiveText {
  /// Within this distance we say the person is "right here".
  static const double hereM = 40;

  static String away(LiveEta e, bool en) {
    if (e.remainingM < hereM) return en ? 'Right here' : 'Yuko hapa';
    final tilde = e.approximate ? '~' : '';
    final dist = NavText.distance(e.remainingM, en);
    if (e.seconds < 60) return en ? '$tilde< 1 min away · $dist' : 'Yuko chini ya dak 1 · $dist';
    final dur = NavText.duration(e.seconds, en);
    return en ? '$tilde$dur away · $dist' : 'Yuko $tilde$dur mbali · $dist';
  }

  /// Short label for the bubble above the marker, e.g. "8 min".
  static String chip(LiveEta e, bool en) {
    if (e.remainingM < hereM) return en ? 'Here' : 'Hapa';
    final tilde = e.approximate ? '~' : '';
    if (e.seconds < 60) return en ? '$tilde< 1 min' : '$tilde< dak 1';
    return '$tilde${NavText.duration(e.seconds, en)}';
  }

  static String lastSeen(int ageSeconds, bool en) {
    if (ageSeconds < 60) return en ? 'Last seen ${ageSeconds}s ago' : 'Alionekana sek $ageSeconds zilizopita';
    final m = ageSeconds ~/ 60;
    return en ? 'Last seen $m min ago' : 'Alionekana dak $m zilizopita';
  }
}
