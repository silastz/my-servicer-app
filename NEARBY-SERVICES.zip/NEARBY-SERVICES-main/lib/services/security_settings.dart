import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../security/client_security_config.dart';
import 'app_log.dart';

/// On-device security preferences: App Lock (PIN), lock timeout, Remember Me,
/// Notification switches.
///
/// The PIN lives in encrypted storage (Keystore / Keychain); the rest are plain prefs.
class SecuritySettings {
  static const _kAppLock = 'sec_app_lock';
  static const _kTimeout = 'sec_lock_timeout';
  static const _kRemember = 'sec_remember_me';
  static const _kPin = 'sec_app_lock_pin';
  static const _kBiometric = 'sec_biometric';
  static const _kProfileLocked = 'priv_profile_locked';
  static const _kAllowSensitive = 'priv_allow_sensitive';
  static const _kHideMyId = 'priv_hide_my_id';
  static const _kAdminCapture = 'adm_screen_capture'; // 'on' | 'off' | absent

  static SharedPreferences? _prefs;
  static const FlutterSecureStorage _secure = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );
  static String? _pin;

  /// Bumped whenever a setting changes so the lock gate / settings page can refresh.
  static final ValueNotifier<int> changed = ValueNotifier<int>(0);

  static Future<void> init() async {
    _prefs ??= await SharedPreferences.getInstance();
    try {
      _pin = await _secure.read(key: _kPin);
    } catch (e) {
      AppLog.d('Secure storage unavailable: $e');
      _pin = null;
    }
    await applyScreenCapture();
  }

  static void _notify() => changed.value++;

  // ---- App Lock -----------------------------------------------------------
  static bool get appLockEnabled =>
      (_prefs?.getBool(_kAppLock) ?? false) && (_pin != null && _pin!.isNotEmpty);

  /// Seconds the app may stay in the background before it locks (0 = immediately).
  static int get lockTimeoutSeconds => _prefs?.getInt(_kTimeout) ?? 30;

  static Future<void> setLockTimeout(int seconds) async {
    await _prefs?.setInt(_kTimeout, seconds);
    _notify();
  }

  /// Fingerprint / Face unlock (only meaningful while App Lock is on).
  static bool get biometricEnabled => appLockEnabled && (_prefs?.getBool(_kBiometric) ?? false);
  static Future<void> setBiometricEnabled(bool v) async {
    await _prefs?.setBool(_kBiometric, v);
    _notify();
  }

  static bool verifyPin(String pin) => _pin != null && _pin == pin;

  /// Returns false when the PIN could not be stored safely.
  static Future<bool> enableAppLock(String pin) async {
    try {
      await _secure.write(key: _kPin, value: pin);
    } catch (e) {
      AppLog.d('Could not store PIN: $e');
      return false;
    }
    _pin = pin;
    await _prefs?.setBool(_kAppLock, true);
    _notify();
    return true;
  }

  static Future<bool> changePin(String pin) => enableAppLock(pin);

  static Future<void> disableAppLock() async {
    _pin = null;
    try {
      await _secure.delete(key: _kPin);
    } catch (caught, trace) { AppLog.e('security_settings.disableAppLock', caught, trace); }
    await _prefs?.setBool(_kAppLock, false);
    await _prefs?.setBool(_kBiometric, false);
    _notify();
  }

  // ---- Other switches -----------------------------------------------------
  static bool get rememberMe => _prefs?.getBool(_kRemember) ?? true;
  static Future<void> setRememberMe(bool v) async {
    await _prefs?.setBool(_kRemember, v);
    _notify();
  }

  // ---- Privacy -------------------------------------------------------------
  /// Profile Locked (default) hides your contact number and social links on your
  /// profile; Unlocked shows them.
  static bool get profileLocked => _prefs?.getBool(_kProfileLocked) ?? true;
  static Future<void> setProfileLocked(bool v) async {
    await _prefs?.setBool(_kProfileLocked, v);
    _notify();
  }

  /// Hide My ID: providers see only your stage name (never your real name or photo)
  /// on your requests and profile, together with the Safe badge. Off by default.
  /// The server is the one that enforces it; this is the copy the app shows.
  static bool get hideMyId => _prefs?.getBool(_kHideMyId) ?? false;
  static Future<void> setHideMyId(bool v) async {
    await _prefs?.setBool(_kHideMyId, v);
    _notify();
  }

  /// When on, sensitive (18+) services are shown on the landing page, categories,
  /// search and favorites. Off by default.
  static bool get allowSensitive => _prefs?.getBool(_kAllowSensitive) ?? false;
  static Future<void> setAllowSensitive(bool v) async {
    await _prefs?.setBool(_kAllowSensitive, v);
    _notify();
  }

  /// Screenshots and screen recording are controlled ONLY by the admin (backend switch,
  /// see docs/app_policy_api_contract.md). The user has no setting for it.
  /// true = allowed for everyone; false / not set = blocked (the default).
  /// Saved on the phone so it also applies at the next start and while offline.
  static bool? get adminScreenCapture {
    final v = _prefs?.getString(_kAdminCapture);
    if (v == 'on') return true;
    if (v == 'off') return false;
    return null;
  }

  /// What is really in force: only an explicit admin "allowed" lets screenshots through.
  static bool get captureAllowedNow => adminScreenCapture ?? false;

  static Future<void> setAdminScreenCapture(bool? v) async {
    if (v == adminScreenCapture) return;
    if (v == null) {
      await _prefs?.remove(_kAdminCapture);
    } else {
      await _prefs?.setString(_kAdminCapture, v ? 'on' : 'off');
    }
    await applyScreenCapture();
    _notify();
  }

  static const MethodChannel _securityChannel = MethodChannel('ungana/security');

  /// Tells the native side whether to block screenshots / recording right now.
  static Future<void> applyScreenCapture() async {
    final block = ClientSecurityConfig.blockScreenCapture && !captureAllowedNow;
    try {
      await _securityChannel.invokeMethod('setSecure', block);
    } on MissingPluginException {
      // iOS / web / desktop: no native handler.
    } catch (e) {
      AppLog.d('Screen capture setting failed: $e');
    }
  }

  /// Generic boolean preference (used by notification switches).
  static bool flag(String key, {bool defaultValue = false}) => _prefs?.getBool('flag_$key') ?? defaultValue;
  static Future<void> setFlag(String key, bool v) async {
    await _prefs?.setBool('flag_$key', v);
    _notify();
  }
}
