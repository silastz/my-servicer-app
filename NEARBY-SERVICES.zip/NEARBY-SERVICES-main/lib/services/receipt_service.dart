import 'package:flutter/foundation.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import 'currency_service.dart';

/// Everything printed on one payment receipt.
class ReceiptData {
  final String reference; // transaction ref, e.g. the escrow transactionRef
  final String serviceTitle;
  final String buyerName;
  final String sellerName;
  final double amount;
  final String statusLabel;
  final String paymentMethod;
  final String date; // yyyy-MM-dd
  final bool isEnglish;

  const ReceiptData({
    required this.reference,
    required this.serviceTitle,
    required this.buyerName,
    required this.sellerName,
    required this.amount,
    required this.statusLabel,
    required this.paymentMethod,
    required this.date,
    required this.isEnglish,
  });
}

/// Builds a PDF receipt on the phone and opens the system preview, where the
/// user can print, save, or share it (WhatsApp, email...).
class ReceiptService {
  ReceiptService._();

  static const _brand = PdfColor.fromInt(0xFF0D6EFD);
  static const _muted = PdfColor.fromInt(0xFF64748B);
  static const _line = PdfColor.fromInt(0xFFE2E8F0);

  static Future<Uint8List> build(ReceiptData d) async {
    final en = d.isEnglish;
    final doc = pw.Document(title: 'Receipt ${d.reference}', author: 'Ungana');

    pw.Widget row(String label, String value, {bool bold = false}) => pw.Padding(
          padding: const pw.EdgeInsets.symmetric(vertical: 7),
          child: pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.SizedBox(width: 130, child: pw.Text(label, style: const pw.TextStyle(fontSize: 11, color: _muted))),
              pw.Expanded(
                child: pw.Text(
                  value.isEmpty ? '-' : value,
                  style: pw.TextStyle(fontSize: 11, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal),
                ),
              ),
            ],
          ),
        );

    doc.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a5,
        margin: const pw.EdgeInsets.all(28),
        build: (_) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Text('Ungana',
                    style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold, color: _brand)),
                pw.Text(en ? 'PAYMENT RECEIPT' : 'RISITI YA MALIPO',
                    style: pw.TextStyle(fontSize: 11, fontWeight: pw.FontWeight.bold, color: _muted)),
              ],
            ),
            pw.SizedBox(height: 10),
            pw.Divider(color: _line, thickness: 1),
            pw.SizedBox(height: 6),
            row(en ? 'Receipt no.' : 'Namba ya risiti', d.reference, bold: true),
            row(en ? 'Date' : 'Tarehe', d.date),
            row(en ? 'Service' : 'Huduma', d.serviceTitle),
            row(en ? 'Paid by' : 'Mlipaji', d.buyerName),
            row(en ? 'Service provider' : 'Mtoa huduma', d.sellerName),
            row(en ? 'Payment method' : 'Njia ya malipo', d.paymentMethod),
            row(en ? 'Status' : 'Hali', d.statusLabel),
            pw.SizedBox(height: 6),
            pw.Divider(color: _line, thickness: 1),
            pw.SizedBox(height: 10),
            pw.Container(
              padding: const pw.EdgeInsets.all(14),
              decoration: pw.BoxDecoration(
                color: const PdfColor.fromInt(0xFFEFF6FF),
                borderRadius: pw.BorderRadius.circular(8),
              ),
              child: pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Text(en ? 'Amount' : 'Kiasi',
                      style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
                  pw.Text(CurrencyService.format(d.amount),
                      style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold, color: _brand)),
                ],
              ),
            ),
            pw.Spacer(),
            pw.Text(
              en
                  ? 'Thank you for using Ungana. This receipt was generated in the app.'
                  : 'Asante kwa kutumia Ungana. Risiti hii imetengenezwa ndani ya programu.',
              style: const pw.TextStyle(fontSize: 9, color: _muted),
            ),
          ],
        ),
      ),
    );
    return doc.save();
  }

  /// Opens the preview with print / save / share buttons.
  static Future<void> show(ReceiptData d) async {
    final safeRef = d.reference.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '');
    await Printing.layoutPdf(
      name: 'receipt-${safeRef.isEmpty ? 'ungana' : safeRef}.pdf',
      format: PdfPageFormat.a5,
      onLayout: (_) => build(d),
    );
  }
}
