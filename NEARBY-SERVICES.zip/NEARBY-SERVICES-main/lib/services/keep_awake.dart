import 'package:flutter/foundation.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

/// Keeps the screen on while a video is playing, and lets it sleep again afterwards.
/// A player calls [follow] with its playing state on every update; the plugin is only
/// touched when the state changes. Always call [release] in dispose().
class KeepAwake {
  KeepAwake._();

  static bool _on = false;

  static void follow(bool playing) {
    if (playing == _on) return;
    _on = playing;
    _apply(playing);
  }

  static void release() => follow(false);

  static void _apply(bool on) {
    try {
      (on ? WakelockPlus.enable() : WakelockPlus.disable()).catchError((Object e) {
        if (kDebugMode) debugPrint('KeepAwake: $e');
      });
    } catch (e) {
      if (kDebugMode) debugPrint('KeepAwake: $e');
    }
  }
}
