import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/boost.dart';
import '../models/payment_gateway.dart';
import '../models/provider_fees.dart';
import 'app_log.dart';

/// One service category the admin keeps switched on (from /app/policy -> categories).
/// [id] is the value the server stores and validates ("Plumbing"); the names are display text.
class PolicyCategory {
  final String id;
  final String nameEn;
  final String nameSw;
  const PolicyCategory({required this.id, required this.nameEn, required this.nameSw});

  /// The name in the language the app is showing; never empty (falls back to the id).
  String name(bool english) {
    final t = (english ? nameEn : nameSw).trim();
    if (t.isNotEmpty) return t;
    final other = (english ? nameSw : nameEn).trim();
    return other.isNotEmpty ? other : id;
  }

  Map<String, dynamic> toJson() => {'id': id, 'nameEn': nameEn, 'nameSw': nameSw};

  /// Null when [raw] has no usable id.
  static PolicyCategory? tryParse(dynamic raw) {
    if (raw is! Map) return null;
    final id = (raw['id'] ?? '').toString().trim();
    if (id.isEmpty || id.length > 80) return null;
    return PolicyCategory(
      id: id,
      nameEn: (raw['nameEn'] ?? '').toString().trim(),
      nameSw: (raw['nameSw'] ?? '').toString().trim(),
    );
  }
}

/// Values the admin sets on the backend (see docs/app_policy_api_contract.md):
/// fees, wallet limits and security switches.
///
/// - The last answer is saved on the phone, so it applies at the next start and offline.
/// - Anything the admin leaves out falls back to the app's built-in default.
/// - Fees shown here are for DISPLAY and input limits only. The server must charge and
///   enforce them itself; the app can never be trusted with prices.
class AppPolicy {
  AppPolicy._();

  static const String _key = 'app_policy_v1';

  // Fees (TSh)
  static int? registrationFee;
  static int? serviceFee;
  static int? freeServiceLimit;
  static List<BoostPlan>? boostPlans;

  // Provider fees: VAT % of the withdrawn amount with the flat payout fee inside it, taken only at withdrawal; null = none announced
  static ProviderFees? providerFees;

  // Wallet limits (TSh)
  static double? topUpMin;
  static double? topUpMax;
  static double? withdrawMin; // old key fees.withdrawMin, still honoured when the admin sets no limit in fees.provider

  /// Lowest withdrawal: the admin's limit, else the old key, else 1,000.
  static double get withdrawMinEffective {
    final m = providerFees?.withdrawMin ?? 0;
    return m > 0 ? m.toDouble() : (withdrawMin ?? 1000);
  }

  /// Highest withdrawal the admin allows, or null = no maximum.
  static double? get withdrawMaxEffective {
    final m = providerFees?.withdrawMax ?? 0;
    return m > 0 ? m.toDouble() : null;
  }

  // Payment gateway chosen by the admin (null = SNIPPE, the default)
  static PaymentGateway? _gateway;
  static PaymentGateway get paymentGateway => _gateway ?? PaymentGateway.defaultGateway;

  /// Card payments are OFF until the admin switches them on (server policy payments.cardEnabled).
  static bool? _card;
  static bool get cardPaymentsEnabled => _card ?? false;

  /// Minutes a sent sign-up / reset code stays "pending": reopen the app within this time, type the same
  /// phone/email, and you land on the code screen (admin setting auth.otpPendingMinutes; null = 4).
  static int? otpPendingMinutes;
  static const int otpPendingDefault = 4;
  static const int otpPendingMin = 1;
  static const int otpPendingMax = 10; // a code lives 10 minutes on the server

  static int get otpPendingMinutesEffective => otpPendingMinutes ?? otpPendingDefault;

  /// Service categories the admin keeps switched on, in the admin's order.
  /// Null = the server sent none ("Empty = app uses its built-in list").
  static List<PolicyCategory>? categories;

  // Support contacts for the Help screen. Null = the admin has not set it, and the screen hides it.
  static String? supportPhone;
  static String? supportWhatsapp;
  static String? supportEmail;

  // Full Terms / Privacy pages (https) the admin published. Null = show the short in-app text.
  static String? termsUrl;
  static String? privacyUrl;

  // Security switches (null = use the build default)
  static bool? blockCompromisedDevice;
  static bool? playIntegrity;
  static bool? blockVpn;

  /// Bumped whenever a new policy is applied, so the security guard can re-check at once.
  static final ValueNotifier<int> changed = ValueNotifier<int>(0);

  /// Reads the saved policy. Call once, early (before the device scan).
  static Future<void> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_key);
      if (raw == null) return;
      _set(jsonDecode(raw));
    } catch (e) {
      AppLog.d('Saved policy unreadable: $e');
    }
  }

  /// Keeps only valid values from a server answer ({data:{...}} or {...}).
  /// Returns null when the body is not a policy object at all.
  @visibleForTesting
  static Map<String, dynamic>? sanitize(dynamic body) {
    if (body is! Map) return null;
    final d = body['data'] is Map ? body['data'] as Map : body;
    final fees = d['fees'] is Map ? d['fees'] as Map : const {};
    final sec = d['security'] is Map ? d['security'] as Map : const {};

    num? num_(dynamic v, num min, num max) {
      final n = v is num ? v : (v is String ? num.tryParse(v) : null);
      return (n != null && n.isFinite && n >= min && n <= max) ? n : null;
    }

    final out = <String, dynamic>{};
    void put(String k, dynamic v) {
      if (v != null) out[k] = v;
    }

    put('registrationFee', num_(fees['registrationFee'], 1, 1000000)?.toInt());
    put('serviceFee', num_(fees['serviceFee'], 1, 1000000)?.toInt());
    put('freeServiceLimit', num_(fees['freeServiceLimit'], 0, 100)?.toInt());
    final plans = fees['boostPlans'];
    if (plans is List) {
      final ok = plans.map(BoostPlan.tryParse).whereType<BoostPlan>().toList();
      if (ok.isNotEmpty) {
        put('boostPlans', [for (final p in ok) {'id': p.id, 'days': p.days, 'price': p.price}]);
      }
    }
    final tMin = num_(fees['topUpMin'], 100, 100000000)?.toDouble();
    final tMax = num_(fees['topUpMax'], 100, 100000000)?.toDouble();
    if (tMin != null && tMax != null && tMax < tMin) {
      // contradictory: ignore both
    } else {
      put('topUpMin', tMin);
      put('topUpMax', tMax);
    }
    put('withdrawMin', num_(fees['withdrawMin'], 100, 100000000)?.toDouble());
    put('providerFees', ProviderFees.tryParse(fees['provider'])?.toJson());

    final pay = d['payments'] is Map ? d['payments'] as Map : const {};
    final gw = PaymentGateway.tryParse(pay['gateway'] ?? d['paymentGateway']);
    if (gw != null) out['paymentGateway'] = gw.id; // unknown / missing -> default (SNIPPE)
    final cardOn = pay['cardEnabled'] ?? d['cardPaymentsEnabled'];
    if (cardOn is bool) out['cardPaymentsEnabled'] = cardOn; // missing -> off

    final cats = d['categories'];
    if (cats is List) {
      final seen = <String>{};
      final ok = <PolicyCategory>[];
      for (final c in cats) {
        final parsed = PolicyCategory.tryParse(c);
        if (parsed != null && seen.add(parsed.id.toLowerCase())) ok.add(parsed);
      }
      // Missing or empty -> the app keeps its built-in list.
      if (ok.isNotEmpty) put('categories', [for (final c in ok) c.toJson()]);
    }

    final auth = d['auth'] is Map ? d['auth'] as Map : const {};
    put('otpPendingMinutes', num_(auth['otpPendingMinutes'], otpPendingMin, otpPendingMax)?.toInt());

    final support = d['support'] is Map ? d['support'] as Map : const {};
    String? cleanNumber(dynamic v) {
      final t = (v ?? '').toString().replaceAll(RegExp(r'[\s-]'), '');
      return RegExp(r'^\+?[0-9]{9,15}$').hasMatch(t) ? t : null;
    }

    final mail = (support['email'] ?? '').toString().trim();
    put('supportPhone', cleanNumber(support['phone']));
    put('supportWhatsapp', cleanNumber(support['whatsapp']));
    put('supportEmail', RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]{2,}$').hasMatch(mail) ? mail : null);

    final legal = d['legal'] is Map ? d['legal'] as Map : const {};
    String? httpsUrl(dynamic v) {
      final u = Uri.tryParse((v ?? '').toString().trim());
      return (u != null && u.scheme == 'https' && u.host.isNotEmpty) ? u.toString() : null;
    }

    put('termsUrl', httpsUrl(legal['termsUrl']));
    put('privacyUrl', httpsUrl(legal['privacyUrl']));

    final bc = sec['blockCompromisedDevice'];
    final pi = sec['playIntegrity'];
    if (bc is bool) out['blockCompromisedDevice'] = bc;
    if (pi is bool) out['playIntegrity'] = pi;
    final vpn = sec['blockVpn'];
    if (vpn is bool) out['blockVpn'] = vpn;
    return out;
  }

  /// Uses a sanitized policy and saves it. Fields the admin did not send go back to defaults.
  static Future<void> apply(Map<String, dynamic> clean) async {
    _set(clean);
    changed.value++;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_key, jsonEncode(clean));
    } catch (e) {
      AppLog.d('Could not save policy: $e');
    }
  }

  static void _set(dynamic raw) {
    final m = raw is Map ? Map<String, dynamic>.from(raw) : <String, dynamic>{};
    registrationFee = (m['registrationFee'] as num?)?.toInt();
    serviceFee = (m['serviceFee'] as num?)?.toInt();
    freeServiceLimit = (m['freeServiceLimit'] as num?)?.toInt();
    topUpMin = (m['topUpMin'] as num?)?.toDouble();
    topUpMax = (m['topUpMax'] as num?)?.toDouble();
    withdrawMin = (m['withdrawMin'] as num?)?.toDouble();
    otpPendingMinutes = (m['otpPendingMinutes'] as num?)?.toInt();
    blockCompromisedDevice = m['blockCompromisedDevice'] is bool ? m['blockCompromisedDevice'] as bool : null;
    playIntegrity = m['playIntegrity'] is bool ? m['playIntegrity'] as bool : null;
    blockVpn = m['blockVpn'] is bool ? m['blockVpn'] as bool : null;
    supportPhone = m['supportPhone'] is String ? m['supportPhone'] as String : null;
    supportWhatsapp = m['supportWhatsapp'] is String ? m['supportWhatsapp'] as String : null;
    supportEmail = m['supportEmail'] is String ? m['supportEmail'] as String : null;
    termsUrl = m['termsUrl'] is String ? m['termsUrl'] as String : null;
    privacyUrl = m['privacyUrl'] is String ? m['privacyUrl'] as String : null;
    _gateway = PaymentGateway.tryParse(m['paymentGateway']);
    _card = m['cardPaymentsEnabled'] is bool ? m['cardPaymentsEnabled'] as bool : null;
    providerFees = ProviderFees.tryParse(m['providerFees']);
    final cats = m['categories'];
    final parsedCats = cats is List ? cats.map(PolicyCategory.tryParse).whereType<PolicyCategory>().toList() : <PolicyCategory>[];
    categories = parsedCats.isEmpty ? null : parsedCats;
    final plans = m['boostPlans'];
    boostPlans = plans is List
        ? (plans.map(BoostPlan.tryParse).whereType<BoostPlan>().toList()..sort((a, b) => a.days.compareTo(b.days)))
        : null;
    if (boostPlans != null && boostPlans!.isEmpty) boostPlans = null;
  }
}
