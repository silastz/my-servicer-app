import 'package:flutter/foundation.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import '../constants/notification_config.dart';
import 'api_service.dart';
import 'chat_prefs.dart';
import 'data_sync.dart';
import 'security_settings.dart';
import 'app_log.dart';

/// Push notifications through OneSignal (Android + iOS).
///
/// - Manual notifications: send from the OneSignal dashboard (Messages -> New Push),
///   to everyone or to segments / tags (role, city, language).
/// - Auto notifications: your server calls the OneSignal REST API for a user by
///   their external id (= the app user id). See docs/onesignal_send.php.
class NotificationService {
  static bool _ready = false;

  /// The three switches in Settings > Notification Preferences (name -> default when never touched).
  static const Map<String, bool> _prefDefaults = {
    'notif_bookings': true,
    'notif_messages': true,
    'notif_promos': true,
  };

  static bool _prefOn(String key) => SecuritySettings.flag(key, defaultValue: _prefDefaults[key] ?? true);

  /// Which switch a push belongs to, from its `type`. Null (unknown) pushes are always shown.
  static String? _prefFor(Map<String, dynamic> data) {
    final t = '${data['type'] ?? ''}'.toLowerCase();
    if (t.isEmpty) return null;
    if (t.contains('chat') || t.contains('message') || t.contains('call')) return 'notif_messages';
    if (t.contains('promo') || t.contains('news') || t.contains('announce')) return 'notif_promos';
    if (t.contains('booking') || t.contains('request') || t.contains('payment') || t.contains('escrow') || t.contains('offer')) {
      return 'notif_bookings';
    }
    return null;
  }

  /// Publishes the switches as OneSignal tags ('1' / '0') so segments and the server
  /// can skip a category the user turned off. Call after every change and at start-up.
  ///
  /// [server] false = the caller already saved the switches on the server (and knows it worked), so only
  /// the tags are updated.
  static Future<void> syncPreferences({bool server = true}) async {
    // The server is the one that decides whether a push is sent, so tell it first (works even without OneSignal tags).
    if (server) {
      ApiService.updateNotificationPrefs(
        bookings: _prefOn('notif_bookings'),
        messages: _prefOn('notif_messages'),
        promos: _prefOn('notif_promos'),
      );
    }
    if (!_ready) return;
    try {
      for (final key in _prefDefaults.keys) {
        await OneSignal.User.addTagWithKey(key, _prefOn(key) ? '1' : '0');
      }
    } catch (e) {
      AppLog.d('[Push] preference sync failed: $e');
    }
  }

  /// Callback for when the user taps a notification. Receives the custom
  /// `data` map sent with the push (e.g. {"type": "booking", "id": "12"}).
  static void Function(Map<String, dynamic> data)? onNotificationTap;

  static Future<void> init() async {
    if (!NotificationConfig.isConfigured) {
      AppLog.d('[Push] OneSignal App ID not set - push disabled.');
      return;
    }
    try {
      if (kDebugMode) OneSignal.Debug.setLogLevel(OSLogLevel.warn);
      OneSignal.initialize(NotificationConfig.oneSignalAppId);

      OneSignal.Notifications.addClickListener((event) {
        final extra = Map<String, dynamic>.from(event.notification.additionalData ?? <String, dynamic>{});
        // For a message push the title is the sender's name: the chat opens with it.
        extra['_title'] = event.notification.title ?? '';
        onNotificationTap?.call(extra);
      });

      // A push that arrives while the app is open means server data changed
      // (new booking, accept, message): refresh every screen and the bell badge.
      OneSignal.Notifications.addForegroundWillDisplayListener((event) {
        DataSync.bump();
        // A muted conversation shows no banner while the app is open.
        final extra = event.notification.additionalData ?? const <String, dynamic>{};
        // A category the user switched off shows no banner while the app is open.
        final pref = _prefFor(Map<String, dynamic>.from(extra));
        if (pref != null && !_prefOn(pref)) {
          event.preventDefault();
          return;
        }
        for (final key in const ['senderId', 'fromUserId', 'otherUserId', 'chatUserId']) {
          final id = int.tryParse('${extra[key] ?? ''}');
          if (id != null && ChatPrefs.isMuted(id)) {
            event.preventDefault();
            break;
          }
        }
      });

      _ready = true;
      syncPreferences();
    } catch (e) {
      AppLog.d('[Push] init failed: $e');
    }
  }

  /// Ask for the OS notification permission through OneSignal (iOS + Android 13+).
  /// The startup prompt already requests it; this is a safe fallback.
  static Future<bool> requestPermission() async {
    if (!_ready) return false;
    try {
      return await OneSignal.Notifications.requestPermission(true);
    } catch (caught, trace) {
      AppLog.e('notification_service.requestPermission', caught, trace);
      return false;
    }
  }

  /// Link this device to the logged-in user so the server can target them.
  static Future<void> login(String userId, {String? role}) async {
    if (!_ready || userId.isEmpty || userId == '0') return;
    try {
      await OneSignal.login(userId);
      if (role != null && role.isNotEmpty) await OneSignal.User.addTagWithKey('role', role);
    } catch (e) {
      AppLog.d('[Push] login failed: $e');
    }
  }

  static Future<void> logout() async {
    if (!_ready) return;
    try {
      await OneSignal.logout();
      await OneSignal.User.removeTag('role');
    } catch (caught, trace) { AppLog.e('notification_service.logout', caught, trace); }
  }

  static Future<void> setRole(String role) async {
    if (!_ready || role.isEmpty) return;
    try {
      await OneSignal.User.addTagWithKey('role', role);
    } catch (caught, trace) { AppLog.e('notification_service.setRole', caught, trace); }
  }

  /// Tags let you send manual pushes to a city or language from the dashboard.
  static Future<void> setCity(String city) async {
    if (!_ready || city.isEmpty) return;
    try {
      await OneSignal.User.addTagWithKey('city', city);
    } catch (caught, trace) { AppLog.e('notification_service.setCity', caught, trace); }
  }

  static Future<void> setLanguage(String code) async {
    if (!_ready || code.isEmpty) return;
    try {
      await OneSignal.User.setLanguage(code);
      await OneSignal.User.addTagWithKey('lang', code);
    } catch (caught, trace) { AppLog.e('notification_service.setLanguage', caught, trace); }
  }
}
