import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'session_manager.dart';
import 'app_log.dart';

/// Service drafts, kept on this device (one list per signed-in user).
/// A draft is a map shaped like a service from the API, plus `draftId` and `savedAt`,
/// so the Add / Edit screen can pre-fill from it the same way it does for a live service.
class DraftService {
  static String get _key => 'service_drafts_${SessionManager.getUserIdValue()}';

  static Future<List<Map<String, dynamic>>> list() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_key);
      if (raw == null || raw.isEmpty) return [];
      final decoded = jsonDecode(raw);
      if (decoded is! List) return [];
      final drafts = decoded.whereType<Map>().map((m) => Map<String, dynamic>.from(m)).toList();
      drafts.sort((a, b) => '${b['savedAt']}'.compareTo('${a['savedAt']}'));
      return drafts;
    } catch (caught, trace) {
      AppLog.e('draft_service:21', caught, trace);
      return [];
    }
  }

  /// Adds the draft, or replaces the one with the same `draftId`.
  static Future<bool> save(Map<String, dynamic> draft) async {
    try {
      final id = draft['draftId']?.toString() ?? '';
      if (id.isEmpty) return false;
      final all = await list();
      all.removeWhere((d) => d['draftId']?.toString() == id);
      all.add(draft);
      final prefs = await SharedPreferences.getInstance();
      return prefs.setString(_key, jsonEncode(all));
    } catch (caught, trace) {
      AppLog.e('draft_service.save', caught, trace);
      return false;
    }
  }

  static Future<void> delete(String draftId) async {
    try {
      final all = await list();
      all.removeWhere((d) => d['draftId']?.toString() == draftId);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_key, jsonEncode(all));
    } catch (caught, trace) { AppLog.e('draft_service.delete', caught, trace); }
  }
}
