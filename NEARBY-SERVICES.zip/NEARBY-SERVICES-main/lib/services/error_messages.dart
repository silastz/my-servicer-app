import '../constants/app_strings.dart';

/// Plain-language text for the error codes the backend sends as the error "message"
/// (ApiException.badRequest("TOO_MANY_PHOTOS"), "NOT_PAYABLE:ACCEPTED", ...).
/// Without this the user would see the raw code. Codes are matched exactly (the part before
/// a ':' is the code). Unknown codes fall back to a readable sentence, never the raw code.
class ErrorMessages {
  ErrorMessages._();

  /// The text for [raw] when it is a known backend code, otherwise null.
  static String? lookup(String? raw) {
    final code = codeOf(raw);
    if (code == null) return null;
    final m = _texts[code];
    if (m == null) return null;
    return AppStrings.isEnglish ? m.$1 : m.$2;
  }

  /// A readable sentence for any backend-looking code ("SERVICE_NOT_ACTIVE" -> "Service not active").
  /// Text that is not a code is returned unchanged.
  static String friendly(String raw) {
    final known = lookup(raw);
    if (known != null) return known;
    final code = codeOf(raw);
    if (code == null) return raw;
    final words = code.toLowerCase().replaceAll('_', ' ');
    return words[0].toUpperCase() + words.substring(1);
  }

  /// "NOT_PAYABLE:ACCEPTED" -> "NOT_PAYABLE"; null when [raw] is not shaped like a code.
  static String? codeOf(String? raw) {
    if (raw == null) return null;
    final head = raw.trim().split(':').first.trim().toUpperCase();
    return RegExp(r'^[A-Z][A-Z0-9]*(_[A-Z0-9]+)+$').hasMatch(head) || _texts.containsKey(head) ? head : null;
  }

  static const _adminValue = (
    'That value is not allowed. Check it and try again.',
    'Thamani hiyo hairuhusiwi. Iangalie kisha ujaribu tena.',
  );
  static const _adsValue = (
    'The ad settings contain a value that is not allowed. Check them and try again.',
    'Mipangilio ya matangazo ina thamani isiyoruhusiwa. Iangalie kisha ujaribu tena.',
  );
  static const _noMatch = (
    'The payment does not match. Please start again.',
    'Malipo hayalingani. Tafadhali anza upya.',
  );
  static const _notYourService = ('This is not your service.', 'Hii si huduma yako.');
  static const _noPaymentOptions = (
    'Payments are not available right now. Please try again later.',
    'Malipo hayapatikani kwa sasa. Tafadhali jaribu tena baadaye.',
  );
  static const _payNotDone = ('The payment is not completed yet.', 'Malipo bado hayajakamilika.');
  static const _planUnavailable = ('This boost plan is not available.', 'Kifurushi hiki cha kuongeza hakipatikani.');
  static const _badLocation = ('The location is not valid.', 'Eneo si sahihi.');
  static const _badRef = ('The payment reference is not valid.', 'Namba ya rejea ya malipo si sahihi.');
  static const _planInUse = ('Another plan already uses this value.', 'Kifurushi kingine tayari kinatumia thamani hii.');

  static const Map<String, (String, String)> _texts = {
    // Deleting the account
    'WRONG_PASSWORD': ('That password is not correct.', 'Nenosiri hilo si sahihi.'),
    'WALLET_NOT_EMPTY': (
      'Your pocket fund still holds money. Withdraw or spend it first.',
      'Mfuko wako bado una pesa. Itoe au uitumie kwanza.'
    ),
    'OPEN_BOOKINGS': (
      'You still have bookings in progress. Finish or cancel them first.',
      'Bado una maombi yanayoendelea. Yamalize au yaghairi kwanza.'
    ),
    'PAYMENT_PENDING': (
      'A payment is still waiting. Try again when it is finished.',
      'Kuna malipo bado yanasubiriwa. Jaribu tena yakikamilika.'
    ),
    'ADMIN_ACCOUNT': ('An admin account cannot be deleted here.', 'Akaunti ya msimamizi haiwezi kufutwa hapa.'),
    // Admin: managing user accounts
    'ACCOUNT_SUSPENDED': (
      'This account has been suspended. Please contact support.',
      'Akaunti hii imesimamishwa. Tafadhali wasiliana na msaada.'
    ),
    'INVALID_PREFERENCE': ('That setting value is not valid.', 'Thamani ya mpangilio huo si sahihi.'),
    'ACCOUNT_DELETED': ('This account was already deleted.', 'Akaunti hii tayari imefutwa.'),
    'REASON_TOO_LONG': ('The reason is too long (500 letters at most).', 'Sababu ni ndefu mno (herufi 500 kwa juu).'),
    // Booking and payment
    'ALREADY_PAID': ('This is already paid.', 'Tayari imelipwa.'),
    'AMOUNT_BELOW_GATEWAY_MIN': (
      'The amount is below the minimum the payment provider accepts.',
      'Kiasi ni chini ya kiwango cha chini ambacho mtoa huduma wa malipo anakubali.'
    ),
    'AMOUNT_MISMATCH': _noMatch,
    'PAYMENT_AMOUNT_MISMATCH': _noMatch,
    'GATEWAY_MISMATCH': _noMatch,
    'GATEWAY_REFERENCE_MISMATCH': _noMatch,
    'PAYMENT_METHOD_MISMATCH': ('This payment method does not match the booking.', 'Njia hii ya malipo hailingani na ombi.'),
    'BOOKING_NOT_FOUND': ('This booking was not found.', 'Ombi hili halikupatikana.'),
    'TRANSACTION_NOT_FOUND': ('This booking was not found.', 'Ombi hili halikupatikana.'),
    'TRANSACTION_NOT_COMPLETED': ('You can review only after the booking is completed.', 'Unaweza kutathmini tu baada ya ombi kukamilika.'),
    'BOOKING_NOT_PAID': ('This booking is not paid yet.', 'Ombi hili bado halijalipiwa.'),
    'NOT_YOUR_BOOKING': ('This is not your booking.', 'Hili si ombi lako.'),
    'NOT_PAYABLE': ('This booking cannot be paid right now.', 'Ombi hili haliwezi kulipiwa kwa sasa.'),
    'NOT_AN_OFFLINE_PAYMENT': (
      'This booking is not paid directly to the provider.',
      'Ombi hili halilipwi moja kwa moja kwa mtoa huduma.'
    ),
    'NO_PAYMENT_TO_PROVE': ('There is no payment to confirm yet.', 'Bado hakuna malipo ya kuthibitisha.'),
    'INVALID_PROOF': ('The payment proof is not valid.', 'Uthibitisho wa malipo si sahihi.'),
    'INSTRUCTIONS_REQUIRED': ('Add the payment instructions first.', 'Weka maelekezo ya malipo kwanza.'),
    'INVALID_MODE': ('Choose how you want to pay.', 'Chagua jinsi unavyotaka kulipa.'),
    'INVALID_PAYMENT_METHOD': ('Choose how you want to pay.', 'Chagua jinsi unavyotaka kulipa.'),
    'INVALID_PURPOSE': ('This payment cannot be made.', 'Malipo haya hayawezi kufanyika.'),
    'INVALID_REFERENCE': _badRef,
    'REFERENCE_REQUIRED': _badRef,
    'REFERENCE_IN_USE': ('This payment reference was already used.', 'Namba hii ya rejea tayari imetumika.'),
    'INVALID_DEADLINE': ('The payment deadline is not valid.', 'Muda wa mwisho wa malipo si sahihi.'),
    'PAYMENT_DEADLINE_PASSED': ('The payment deadline has passed.', 'Muda wa kulipa umepita.'),
    'PAYMENT_NOT_COMPLETED': _payNotDone,
    'PAYMENT_NOT_CONFIRMED': _payNotDone,
    'PAYMENT_NOT_FOUND': ('Payment not found.', 'Malipo hayakupatikana.'),
    'PAYMENT_REJECTED': ('The payment was declined.', 'Malipo yamekataliwa.'),
    'PAYMENT_REQUIRED': ('Payment is required first.', 'Malipo yanahitajika kwanza.'),
    'PAYMENT_GATEWAY_BUSY': (
      'The payment service is busy. Try again in a moment.',
      'Huduma ya malipo ina shughuli nyingi. Jaribu tena baada ya muda.'
    ),
    'PAYMENT_GATEWAY_ERROR': (
      'The payment service had a problem. Nothing was charged. Try again.',
      'Huduma ya malipo ilipata tatizo. Hakuna kilichokatwa. Jaribu tena.'
    ),
    'PAYMENT_GATEWAY_NOT_AVAILABLE': _noPaymentOptions,
    'PAYMENT_GATEWAY_NOT_CONFIGURED': _noPaymentOptions,
    'CARD_NOT_SUPPORTED': ('Card payment is not available for this payment.', 'Malipo ya kadi hayapatikani kwa malipo haya.'),
    'CARD_PAYMENTS_DISABLED': (
      'Card payments are switched off right now. Use mobile money.',
      'Malipo ya kadi yamezimwa kwa sasa. Tumia pesa ya simu.'
    ),
    'INSUFFICIENT_BALANCE': ('Your Pocket Fund balance is not enough.', 'Salio lako la Pocket Fund halitoshi.'),
    'INSUFFICIENT_PLATFORM_BALANCE': ('There is not enough balance for this.', 'Salio halitoshi kwa hili.'),
    'INVALID_AMOUNT': ('Enter a whole amount.', 'Weka kiasi kamili.'),
    'TOPUP_BELOW_MIN': (
      'The amount is below the minimum top-up. Enter a higher amount.',
      'Kiasi ni chini ya kiwango cha chini cha kuweka pesa. Weka kiasi kikubwa zaidi.'
    ),
    'TOPUP_ABOVE_MAX': (
      'The amount is above the maximum top-up. Enter a lower amount.',
      'Kiasi ni juu ya kiwango cha juu cha kuweka pesa. Weka kiasi kidogo zaidi.'
    ),
    'INVALID_PHONE': (
      'This phone number is not valid for mobile money. Check it and try again.',
      'Namba hii ya simu si sahihi kwa pesa ya simu. Iangalie kisha ujaribu tena.'
    ),
    'DUPLICATE_WITHDRAWAL': ('This withdrawal was already sent.', 'Utoaji huu tayari umetumwa.'),
    'INVALID_CURRENCY': ('This currency is not supported.', 'Sarafu hii haitumiki.'),
    'REGISTRATION_FEE_REQUIRED': ('Pay the registration fee first.', 'Lipa ada ya usajili kwanza.'),
    'SERVICE_FEE_REQUIRED': ('Pay the service fee first to post more services.', 'Lipa ada ya huduma kwanza ili kuongeza huduma zaidi.'),
    'TRACKING_NOT_ACTIVE': (
      'Live tracking is not active for this booking.',
      'Ufuatiliaji wa moja kwa moja haujawashwa kwa ombi hili.'
    ),

    // Booking request details
    'TOO_MANY_PHOTOS': ('You can attach up to 5 photos.', 'Unaweza kuambatisha hadi picha 5.'),
    'TASK_REQUIRED': ('Pick at least one task.', 'Chagua angalau kazi moja.'),
    'INVALID_SCHEDULE': ('The day or time you picked is not valid.', 'Siku au saa uliyochagua si sahihi.'),
    'INVALID_TIME': ('The time you picked is not valid.', 'Saa uliyochagua si sahihi.'),
    'SERVICE_REQUIRED': ('Choose a service first.', 'Chagua huduma kwanza.'),
    'SERVICE_NOT_ACTIVE': ('This service is not available right now.', 'Huduma hii haipatikani kwa sasa.'),
    'SERVICE_NOT_FOUND': ('This service was not found.', 'Huduma hii haikupatikana.'),
    'USER_BLOCKED': ('You cannot do this with this person.', 'Huwezi kufanya hili na mtu huyu.'),
    'USER_REQUIRED': ('Choose a person first.', 'Chagua mtu kwanza.'),
    'REASON_REQUIRED': ('Please give a reason.', 'Tafadhali toa sababu.'),
    'INVALID_LATITUDE': _badLocation,
    'INVALID_LONGITUDE': _badLocation,
    'INVALID_LOCATION': _badLocation,

    // Offers
    'OFFERS_NOT_ALLOWED': (
      'This provider does not take offers. Pay the listed price.',
      'Mtoa huduma huyu hapokei ofa. Lipa bei iliyoorodheshwa.'
    ),
    'OFFER_ABOVE_PRICE': ('Your offer must be lower than the listed price.', 'Ofa yako lazima iwe chini ya bei iliyoorodheshwa.'),
    'OFFER_ALREADY_OPEN': ('You already have an open offer on this service.', 'Tayari una ofa iliyo wazi kwenye huduma hii.'),
    'OFFER_ALREADY_USED': ('This offer was already used for a booking.', 'Ofa hii tayari imetumika kwenye ombi.'),
    'OFFER_EXPIRED': ('This offer has expired.', 'Ofa hii imeisha muda.'),
    'OFFER_MISMATCH': ('This offer does not match the booking.', 'Ofa hii hailingani na ombi.'),
    'OFFER_NOT_AGREED': ('This offer has not been agreed yet.', 'Ofa hii bado haijakubaliwa.'),
    'OFFER_NOT_FOUND': ('Offer not found.', 'Ofa haikupatikana.'),
    'OFFER_NOT_OPEN': ('This offer is no longer open.', 'Ofa hii haipo wazi tena.'),
    'TOO_MANY_OFFERS': (
      'Too many offers. Please wait before sending another.',
      'Ofa nyingi mno. Tafadhali subiri kabla ya kutuma nyingine.'
    ),
    'CANNOT_OFFER_ON_OWN_SERVICE': ('You cannot make an offer on your own service.', 'Huwezi kutoa ofa kwenye huduma yako mwenyewe.'),
    'MIN_OFFER_ABOVE_PRICE': ('The lowest offer cannot be above the price.', 'Ofa ya chini kabisa haiwezi kuwa juu ya bei.'),
    'AUTO_ACCEPT_BELOW_MIN_OFFER': (
      'The auto-accept price cannot be lower than the lowest offer.',
      'Bei ya kukubali moja kwa moja haiwezi kuwa chini ya ofa ya chini kabisa.'
    ),

    // Posting a service
    'INVALID_PRICE': ('Enter a valid price.', 'Weka bei sahihi.'),
    'INVALID_PRICE_TYPE': ('Choose a valid price type.', 'Chagua aina sahihi ya bei.'),
    'INVALID_SERVICE_MODE': ('Choose where the service takes place.', 'Chagua huduma itafanyikia wapi.'),
    'INVALID_TASKS': ('Check the tasks you added.', 'Angalia kazi ulizoongeza.'),
    'INVALID_TASK_NAME': ('Every task needs a name.', 'Kila kazi inahitaji jina.'),
    'INVALID_TASK_PRICE': ('Every task needs a valid price.', 'Kila kazi inahitaji bei sahihi.'),
    'DUPLICATE_TASK': ('Two tasks have the same name.', 'Kazi mbili zina jina moja.'),
    'TOO_MANY_TASKS': ('You can add up to 3 tasks.', 'Unaweza kuongeza hadi kazi 3.'),
    'DISCOUNT_END_IN_PAST': ('The discount end date must be in the future.', 'Tarehe ya mwisho ya punguzo lazima iwe ya baadaye.'),
    'INVALID_MEDIA_URL': (
      'One of the photos or videos is not valid. Upload it again.',
      'Picha au video moja si sahihi. Ipakie tena.'
    ),
    'NOT_SERVICE_OWNER': _notYourService,
    'NOT_YOUR_SERVICE': _notYourService,

    // Categories (admin)
    'INVALID_CATEGORY_ID': _adminValue,
    'INVALID_CATEGORY_NAME': _adminValue,
    'INVALID_SORT_ORDER': _adminValue,
    'CATEGORY_ID_IN_USE': ('Another category already uses this ID.', 'Kundi lingine tayari linatumia kitambulisho hiki.'),
    'CATEGORY_IN_USE': (
      'Services still use this category. Switch it off instead of deleting it.',
      'Bado kuna huduma zinazotumia kundi hili. Lizime badala ya kulifuta.'
    ),
    'CATEGORY_NOT_FOUND': ('Category not found.', 'Kundi halikupatikana.'),

    // Boosts
    'INVALID_PLAN': _planUnavailable,
    'INVALID_PLAN_ID': _planUnavailable,
    'PLAN_NOT_FOUND': _planUnavailable,
    'INVALID_DAYS': ('Choose a valid number of days.', 'Chagua idadi sahihi ya siku.'),
    'PLAN_DAYS_IN_USE': _planInUse,
    'PLAN_ID_IN_USE': _planInUse,
    'PLAN_PRICE_IN_USE': _planInUse,

    // Chat, reviews, reports, blocking
    'MESSAGE_NOT_FOUND': ('This message was not found.', 'Ujumbe huu haukupatikana.'),
    'NOT_YOUR_MESSAGE': ('This is not your message.', 'Huu si ujumbe wako.'),
    'EDIT_WINDOW_PASSED': ('It is too late to edit this message.', 'Muda wa kuhariri ujumbe huu umepita.'),
    'ONLY_TEXT_CAN_BE_EDITED': ('Only text messages can be edited.', 'Ujumbe wa maandishi pekee ndio unaweza kuhaririwa.'),
    'ALREADY_REVIEWED': ('You already reviewed this booking.', 'Tayari umetathmini ombi hili.'),
    'CANNOT_REVIEW_YOURSELF': ('You cannot review yourself.', 'Huwezi kujitathmini mwenyewe.'),
    'INVALID_SUPPORT_PHONE': ('The support phone number is not valid (e.g. +255712345678).', 'Namba ya simu ya msaada si sahihi (mf. +255712345678).'),
    'INVALID_SUPPORT_WHATSAPP': ('The support WhatsApp number is not valid (e.g. +255712345678).', 'Namba ya WhatsApp ya msaada si sahihi (mf. +255712345678).'),
    'INVALID_SUPPORT_EMAIL': ('The support email is not valid.', 'Barua pepe ya msaada si sahihi.'),
    'CANNOT_REPORT_YOURSELF': ('You cannot report yourself.', 'Huwezi kujiripoti mwenyewe.'),
    'CANNOT_BLOCK_YOURSELF': ('You cannot block yourself.', 'Huwezi kujizuia mwenyewe.'),
    'INVALID_REPORT_TYPE': ('Choose a reason for the report.', 'Chagua sababu ya ripoti.'),
    'TOO_MANY_REPORTS': ('Too many reports. Please try again later.', 'Ripoti nyingi mno. Tafadhali jaribu tena baadaye.'),
    'DETAILS_TOO_LONG': ('The details are too long. Shorten them.', 'Maelezo ni marefu mno. Yafupishe.'),
    'REPORT_NOT_FOUND': ('Report not found.', 'Ripoti haikupatikana.'),

    // Profile, files and verification
    'BIO_TOO_LONG': ('Your bio is too long.', 'Maelezo yako ni marefu mno.'),
    'INVALID_STAGE_NAME': ('Enter a valid display name.', 'Weka jina sahihi la kuonyesha.'),
    'INVALID_EMAIL': ('Enter a valid email address.', 'Weka barua pepe sahihi.'),
    'INVALID_PHONE_NUMBER': ('Enter a valid phone number.', 'Weka namba sahihi ya simu.'),
    'INVALID_SOCIAL': (
      'A social link is not valid. Use the username only, no spaces, up to 100 characters.',
      'Kiungo cha mtandao si sahihi. Tumia jina la mtumiaji tu, bila nafasi, hadi herufi 100.'
    ),
    'TOO_MANY_ATTEMPTS': (
      'Too many wrong tries. Request a new code and try again.',
      'Umekosea mara nyingi. Omba msimbo mpya kisha ujaribu tena.'
    ),
    'USER_NOT_FOUND': ('This account was not found.', 'Akaunti hii haikupatikana.'),
    'SAME_AS_CURRENT': ('That is the same as your current one.', 'Hiyo ni sawa na ya sasa.'),
    'NO_PENDING_CHANGE': ('There is no pending change. Start again.', 'Hakuna mabadiliko yanayosubiri. Anza upya.'),
    'INVALID_CODE': ('That code is not correct.', 'Msimbo huo si sahihi.'),
    'CODE_EXPIRED': ('This code has expired. Request a new one.', 'Msimbo huu umeisha muda. Omba mpya.'),
    'WAIT_BEFORE_NEW_CODE': (
      'Please wait a moment before asking for a new code.',
      'Tafadhali subiri kidogo kabla ya kuomba msimbo mpya.'
    ),
    'USE_IDENTITY_VERIFICATION': (
      'Use Identity Verification to change your legal name.',
      'Tumia Uthibitisho wa Utambulisho kubadilisha jina lako la kisheria.'
    ),
    'BUSINESS_NAME_INVALID': ('Enter a valid business name.', 'Weka jina sahihi la biashara.'),
    'BUSINESS_NAME_REQUIRED': ('Enter your business name.', 'Weka jina la biashara yako.'),
    'IDENTITY_REQUIRED': ('Verify your identity first.', 'Thibitisha utambulisho wako kwanza.'),
    'INVALID_DOCUMENT_TYPE': ('Choose a valid document type.', 'Chagua aina sahihi ya hati.'),
    'INVALID_ID_KIND': ('Choose a valid ID type.', 'Chagua aina sahihi ya kitambulisho.'),
    'EXPIRY_DATE_PAST': ('The expiry date must be in the future.', 'Tarehe ya kuisha lazima iwe ya baadaye.'),
    'EXPIRY_DATE_REQUIRED': ('Enter the expiry date.', 'Weka tarehe ya kuisha.'),
    'DOCUMENT_LOCKED': ('This document can no longer be changed.', 'Hati hii haiwezi kubadilishwa tena.'),
    'DOCUMENT_NOT_FOUND': ('Document not found.', 'Hati haikupatikana.'),
    'NO_PHOTO': ('Add a photo first.', 'Weka picha kwanza.'),
    'INVITE_CODE_UNAVAILABLE': (
      'Could not create an invitation code right now. Please try again.',
      'Imeshindwa kutengeneza msimbo wa mwaliko sasa. Tafadhali jaribu tena.'
    ),
    'INVITE_INVALID': ('This invitation code is not valid or has expired.', 'Msimbo wa mwaliko si sahihi au umeisha muda.'),
    'INVITE_LIMIT_REACHED': ('You have reached your invitation limit for now.', 'Umefikia kikomo cha mialiko kwa sasa.'),
    'PORTFOLIO_PHOTO_LIMIT': ('Your portfolio is full (40 photos). Remove one to add another.', 'Kazi zako zimejaa (picha 40). Futa moja ili kuongeza nyingine.'),
    'PORTFOLIO_VIDEO_LIMIT': ('Your portfolio is full (10 videos). Remove one to add another.', 'Kazi zako zimejaa (video 10). Futa moja ili kuongeza nyingine.'),
    'PORTFOLIO_ITEM_NOT_FOUND': ('This item is already gone.', 'Kipengee hiki hakipo tena.'),
    'PROVIDER_ONLY': ('Only providers can add to a portfolio.', 'Watoa huduma pekee ndio wanaweza kuongeza kazi zao.'),
    'FILE_EMPTY': ('The file is empty.', 'Faili ni tupu.'),
    'FILE_TOO_LARGE': ('The file is too large. Try a smaller one.', 'Faili ni kubwa mno. Jaribu ndogo zaidi.'),
    'FILE_TYPE_NOT_ALLOWED': ('This file type is not allowed.', 'Aina hii ya faili hairuhusiwi.'),
    'FILE_UNREADABLE': ('The file could not be read. Try another.', 'Faili haikuweza kusomwa. Jaribu nyingine.'),

    // Sign-up and sign-in
    'PASSWORD_TOO_SHORT': ('Your password is too short.', 'Nenosiri lako ni fupi mno.'),
    'PASSWORD_TOO_LONG': ('Your password is too long.', 'Nenosiri lako ni refu mno.'),
    'REQUIRED_IDENTIFIER': ('Enter your phone number or email.', 'Weka namba yako ya simu au barua pepe.'),
    'ROLE_NOT_ALLOWED': ('This account type cannot be created here.', 'Aina hii ya akaunti haiwezi kufunguliwa hapa.'),

    // General
    'FORBIDDEN': ('You are not allowed to do this.', 'Huruhusiwi kufanya hivi.'),
    'NOT_FOUND': ('Not found.', 'Hakipatikani.'),
    'INVALID_REQUEST': ('The request is not valid. Please try again.', 'Ombi si sahihi. Tafadhali jaribu tena.'),
    // Sent as INVALID_STATUS:<current status> when a booking has already moved on (cancelled,
    // refunded, completed...) and also as plain INVALID_STATUS for a bad filter value, so the
    // text must fit both: say what happened, not that a "status is not allowed".
    'INVALID_STATUS': (
      'This can no longer be done because the status has changed. Refresh and check the latest status.',
      'Hili haliwezi kufanyika tena kwa sababu hali imebadilika. Onyesha upya kisha uangalie hali ya sasa.'
    ),
    'INVALID_CATEGORY': (
      'This category is switched off right now. Choose another category.',
      'Kundi hili limezimwa kwa sasa. Chagua kundi lingine.'
    ),

    // Admin settings (the admin sees these when a value is out of range)
    'INVALID_COLLECTION_PERCENT': _adminValue,
    'INVALID_VAT_PERCENT': _adminValue,
    'INVALID_PAYOUT_FEE': _adminValue,
    'INVALID_WITHDRAW_MIN': _adminValue,
    'INVALID_WITHDRAW_MAX': _adminValue,
    'WITHDRAW_MAX_BELOW_MIN': ('The highest withdrawal cannot be below the lowest.', 'Kiwango cha juu cha kutoa hakiwezi kuwa chini ya cha chini.'),
    'INVALID_OTP_PENDING_MINUTES': _adminValue,
    'INVALID_PROMO_PUSH_INTERVAL': _adminValue,
    'INVALID_SERVICE_FEE': _adminValue,
    'INVALID_FREE_QUOTA': _adminValue,
    'COST_INVALID': _adminValue,
    'INVALID_LATEST_VERSION': ('The latest version must look like 1.2.0.', 'Toleo jipya lazima lifanane na 1.2.0.'),
    'INVALID_MIN_VERSION': ('The lowest version must look like 1.2.0.', 'Toleo la chini kabisa lazima lifanane na 1.2.0.'),
    'INVALID_STORE_URL': ('The store link must start with https://.', 'Kiungo cha duka lazima kianze na https://.'),
    'INVALID_PLATFORM': ('Choose android or ios.', 'Chagua android au ios.'),
    'INVALID_PROVIDER': _adsValue,
    'INVALID_FIELD': _adsValue,
    'INVALID_AD_ID': _adsValue,
    'AD_ID_TOO_LONG': _adsValue,
    'UNKNOWN_AD_NETWORK': _adsValue,
    'UNKNOWN_AD_PAGE': _adsValue,
    'UNKNOWN_AD_PLATFORM': _adsValue,
  };
}
