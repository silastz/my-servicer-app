import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'session_manager.dart';
import 'app_log.dart';

/// One supported country: its money, phone format and rounding step.
class Currency {
  final String iso; // country, e.g. 'KE'
  final String code; // ISO 4217, e.g. 'KES'
  final String symbol; // shown before amounts, e.g. 'KSh'
  final String dial; // digits only, e.g. '254'
  final int nationalLength; // mobile number digits after the country code
  final RegExp mobile; // what a valid national mobile number looks like
  final bool trunkZero; // people also type a leading 0 (0712...)
  final int roundStep; // nice price step used for discounted prices
  const Currency(this.iso, this.code, this.symbol, this.dial, this.nationalLength, this.mobile,
      {this.trunkZero = true, this.roundStep = 100});

  String get plusDial => '+$dial';

  /// Country name for screen text ('Kenya', 'DR Congo'...).
  String get name => const {
        'TZ': 'Tanzania',
        'KE': 'Kenya',
        'UG': 'Uganda',
        'RW': 'Rwanda',
        'BI': 'Burundi',
        'CD': 'DR Congo',
      }[iso] ?? iso;
}

/// The country's money for the whole app: auto-detected from the country the app
/// already detects (see LocationService.refreshCountry), used by every price, fee,
/// wallet amount and mobile-money number.
///
/// Rules that keep wallets safe:
///  - Before sign-in the currency follows the detected country.
///  - Once signed in it is FIXED (saved), so a VPN or a trip across the border can't
///    turn 50,000 TSh into 50,000 KSh. Only the server can change it, through
///    [setAccountCurrency] (the user's account/wallet currency).
///  - A country that is not in [supported] keeps Tanzania's TZS (the app's home market).
class CurrencyService {
  CurrencyService._();

  static const String _kSaved = 'account_currency_iso';

  static final Map<String, Currency> supported = {
    'TZ': Currency('TZ', 'TZS', 'TSh', '255', 9, RegExp(r'^[67]\d{8}$')),
    'KE': Currency('KE', 'KES', 'KSh', '254', 9, RegExp(r'^[71]\d{8}$'), roundStep: 5),
    'UG': Currency('UG', 'UGX', 'USh', '256', 9, RegExp(r'^7\d{8}$')),
    'RW': Currency('RW', 'RWF', 'FRw', '250', 9, RegExp(r'^7\d{8}$'), roundStep: 10),
    'BI': Currency('BI', 'BIF', 'FBu', '257', 8, RegExp(r'^[67]\d{7}$'), trunkZero: false),
    'CD': Currency('CD', 'CDF', 'FC', '243', 9, RegExp(r'^[89]\d{8}$'), trunkZero: false),
  };

  static final Currency _home = supported['TZ']!;

  static final ValueNotifier<Currency> notifier = ValueNotifier<Currency>(_home);

  static Currency get current => notifier.value;
  static String get symbol => current.symbol;

  /// Country name of the app's money country (follows the detected / account country).
  static String get countryName => current.name;

  /// "Enter a valid ... number" error for the current country (was hard-coded to Tanzania).
  static String badNumberMessage(bool en) => en
      ? 'Enter a valid ${current.name} mobile number'
      : 'Weka namba sahihi ya simu ya ${current.name}';
  static String get code => current.code;

  static String get _token => SessionManager.getToken() ?? '';

  /// Call once at start (after SessionManager.init()).
  static Future<void> init() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getString(_kSaved);
      if (saved != null && supported.containsKey(saved)) {
        notifier.value = supported[saved]!;
      } else if (_token.isNotEmpty) {
        // Signed in before this feature existed: they have always used TSh.
        notifier.value = _home;
        await prefs.setString(_kSaved, _home.iso);
      } else {
        notifier.value = fromCountry(SessionManager.getCountryIso());
      }
    } catch (e) {
      AppLog.d('CurrencyService.init: $e');
    }
  }

  static Currency fromCountry(String? iso) => supported[(iso ?? '').toUpperCase()] ?? _home;

  /// True once the person chose a country at sign-up: from then on detection (IP lookups)
  /// must not change the currency any more, up to sign-in / sign-out.
  static bool _pickedAtSignup = false;

  /// Called whenever the country is (re)detected. Signed-in accounts and a country the
  /// person already chose at sign-up ignore it.
  static void applyDetectedCountry(String iso) {
    if (_token.isNotEmpty || _pickedAtSignup) return;
    final c = supported[iso.toUpperCase()];
    if (c != null) notifier.value = c;
  }

  /// The currency of the country a phone number / country code belongs to
  /// ('+254712345678', '254712345678' or just '+254'), or null when it is not supported.
  static Currency? fromPhone(String? phoneOrDial) {
    final d = (phoneOrDial ?? '').replaceAll(RegExp(r'[^0-9]'), '');
    if (d.isEmpty) return null;
    for (final c in supported.values) {
      if (d.startsWith(c.dial)) return c;
    }
    return null;
  }

  /// Sign-up: the money is the one of the country code the person selected / typed,
  /// not the one an IP lookup guessed. Does nothing for signed-in accounts (their
  /// wallet currency never changes) or an unsupported code.
  static void selectForSignup(String phoneOrDial) {
    if (_token.isNotEmpty) return;
    final c = fromPhone(phoneOrDial);
    if (c == null) return;
    _pickedAtSignup = true;
    notifier.value = c;
  }

  @visibleForTesting
  static void clearSignupPick() => _pickedAtSignup = false;

  /// Save the current currency for the account (call right after sign-in / sign-up,
  /// when the server did not send one).
  static Future<void> lockCurrent() async {
    _pickedAtSignup = false;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kSaved, current.iso);
  }

  /// The currency the server says the account's wallet uses (country code 'KE' or
  /// currency code 'KES'). Always wins over detection.
  static Future<void> setAccountCurrency(String value) async {
    final v = value.trim().toUpperCase();
    final c = supported[v] ?? supported.values.cast<Currency?>().firstWhere((e) => e!.code == v, orElse: () => null);
    if (c == null) return;
    _pickedAtSignup = false;
    notifier.value = c;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kSaved, c.iso);
  }

  /// Settings, signed OUT: the person picked a country themselves. It is saved and beats
  /// automatic detection from now on (until they pick again).
  static Future<void> chooseManually(String iso) async {
    final c = supported[iso.toUpperCase()];
    if (c == null) return;
    _pickedAtSignup = true;
    notifier.value = c;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kSaved, c.iso);
  }

  /// Back to detection (sign-out).
  static Future<void> reset() async {
    _pickedAtSignup = false;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_kSaved);
    notifier.value = fromCountry(SessionManager.getCountryIso());
  }

  // ---- Money ------------------------------------------------------------------

  /// 50000 -> 'TSh 50,000' (or 'KSh 50,000' ...). Whole units, thousands separated.
  static String format(num v, {Currency? currency}) => '${(currency ?? current).symbol} ${group(v)}';

  /// 50000 -> '50,000' (no symbol).
  static String group(num v) {
    // Keep cents when the amount has them (KES etc.); whole amounts stay "50,000".
    final cents = (v.abs() * 100).round();
    final whole = cents ~/ 100;
    final frac = cents % 100;
    final s = whole.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]},');
    final body = frac == 0 ? s : '$s.${frac.toString().padLeft(2, '0')}';
    return (v < 0 && cents != 0) ? '-$body' : body;
  }

  /// Nearest nice step of the current currency (TSh 100, KSh 5, FRw 10...).
  static int roundToStep(num v) {
    final step = current.roundStep;
    return (v / step).round() * step;
  }

  // ---- Mobile-money numbers ---------------------------------------------------

  /// A mobile number -> digits with the country code (255712345678), or null when invalid.
  /// Local forms (712345678 / 0712345678) are read in the CURRENT country; international
  /// forms (+254712345678 / 254712345678) of any supported country are accepted as typed.
  static String? normalizePhone(String input) {
    final d = input.replaceAll(RegExp(r'[^0-9]'), '');
    if (d.isEmpty) return null;
    for (final c in supported.values) {
      if (d.length == c.dial.length + c.nationalLength && d.startsWith(c.dial)) {
        final national = d.substring(c.dial.length);
        if (c.mobile.hasMatch(national)) return '${c.dial}$national';
      }
    }
    final c = current;
    String? national;
    if (d.length == c.nationalLength) {
      national = d;
    } else if (c.trunkZero && d.length == c.nationalLength + 1 && d.startsWith('0')) {
      national = d.substring(1);
    }
    if (national == null || !c.mobile.hasMatch(national)) return null;
    return '${c.dial}$national';
  }

  /// 255712345678 -> +255 71• •••• 678 (keeps the number off the screen).
  static String maskPhone(String normalized) {
    for (final c in supported.values) {
      if (normalized.startsWith(c.dial) && normalized.length == c.dial.length + c.nationalLength) {
        final n = normalized.substring(c.dial.length);
        return '+${c.dial} ${n.substring(0, 2)}• •••• ${n.substring(n.length - 3)}';
      }
    }
    return normalized;
  }
}
