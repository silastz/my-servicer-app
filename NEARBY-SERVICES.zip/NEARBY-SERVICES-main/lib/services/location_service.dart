import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../security/secure_http.dart';
import 'gps_service.dart';
import 'session_manager.dart';
import 'currency_service.dart';
import 'app_log.dart';

class LocationService {
  static const String _defaultCity = 'Dar es Salaam';

  /// Selectable regions per country (ISO code). The FIRST entry of each list is
  /// the capital / main hub and is used as that country's default.
  /// Labels may carry a town in brackets, e.g. 'Uasin Gishu (Eldoret)'; both the
  /// name and the town are used when matching what IP detection returns.
  static const Map<String, List<String>> regionsByCountry = {
    'TZ': [
      'Dar es Salaam', 'Arusha', 'Dodoma', 'Mwanza', 'Zanzibar', 'Kilimanjaro (Moshi)',
      'Mbeya', 'Morogoro', 'Tanga', 'Iringa', 'Kigoma', 'Tabora', 'Mtwara',
      'Ruvuma (Songea)', 'Shinyanga', 'Kagera (Bukoba)', 'Mara (Musoma)', 'Singida',
      'Manyara (Babati)', 'Geita', 'Katavi', 'Njombe', 'Songwe', 'Simiyu', 'Lindi',
      'Pwani (Kibaha)', 'Rukwa (Sumbawanga)',
    ],
    'KE': [
      'Nairobi', 'Mombasa', 'Kisumu', 'Nakuru', 'Uasin Gishu (Eldoret)', 'Kiambu (Thika)',
      'Machakos', 'Kajiado', 'Kilifi (Malindi)', 'Kwale (Ukunda)', 'Lamu', 'Taita-Taveta (Voi)',
      'Tana River', 'Garissa', 'Wajir', 'Mandera', 'Marsabit', 'Isiolo', 'Meru',
      'Tharaka-Nithi', 'Embu', 'Kitui', 'Makueni', 'Nyandarua', 'Nyeri', 'Kirinyaga (Kerugoya)',
      "Murang'a", 'Turkana (Lodwar)', 'West Pokot (Kapenguria)', 'Samburu (Maralal)',
      'Trans-Nzoia (Kitale)', 'Elgeyo-Marakwet (Iten)', 'Nandi (Kapsabet)', 'Baringo (Kabarnet)',
      'Laikipia (Nanyuki)', 'Narok', 'Kericho', 'Bomet', 'Kakamega', 'Vihiga', 'Bungoma',
      'Busia', 'Siaya', 'Homa Bay', 'Migori', 'Kisii', 'Nyamira',
    ],
    'UG': [
      'Kampala', 'Wakiso (Entebbe)', 'Mukono', 'Jinja', 'Gulu', 'Mbarara', 'Mbale',
      'Lira', 'Kabarole (Fort Portal)', 'Masaka', 'Arua', 'Kabale', 'Soroti', 'Hoima',
      'Kasese', 'Tororo', 'Iganga', 'Kitgum', 'Moroto', 'Masindi', 'Busia', 'Kamuli',
      'Mityana', 'Mubende', 'Bushenyi', 'Ntungamo', 'Rukungiri', 'Kisoro', 'Moyo',
      'Nebbi', 'Apac', 'Adjumani', 'Kapchorwa', 'Luwero', 'Kayunga', 'Mpigi', 'Lugazi (Buikwe)',
    ],
    'RW': [
      'Kigali', 'Musanze', 'Huye (Butare)', 'Rubavu (Gisenyi)', 'Rusizi (Cyangugu)',
      'Muhanga (Gitarama)', 'Nyagatare', 'Rwamagana', 'Karongi (Kibuye)', 'Kayonza',
      'Bugesera', 'Nyanza', 'Kirehe', 'Gicumbi (Byumba)', 'Ngoma (Kibungo)',
    ],
    'BI': [
      'Bujumbura', 'Gitega', 'Ngozi', 'Muyinga', 'Kayanza', 'Rumonge', 'Makamba',
      'Bururi', 'Cibitoke', 'Kirundo', 'Ruyigi', 'Cankuzo', 'Muramvya', 'Mwaro',
      'Karuzi', 'Rutana', 'Bubanza',
    ],
    'CD': [
      'Kinshasa', 'Haut-Katanga (Lubumbashi)', 'Nord-Kivu (Goma)', 'Sud-Kivu (Bukavu)',
      'Tshopo (Kisangani)', 'Kasaï-Oriental (Mbuji-Mayi)', 'Kasaï-Central (Kananga)',
      'Lualaba (Kolwezi)', 'Kongo Central (Matadi)', 'Ituri (Bunia)', 'Équateur (Mbandaka)',
      'Kwilu (Kikwit)', 'Tanganyika (Kalemie)', 'Maniema (Kindu)', 'Kasaï (Tshikapa)',
      'Haut-Lomami (Kamina)', 'Lomami (Kabinda)', 'Sankuru (Lodja)', 'Kwango (Kenge)',
      'Mai-Ndombe (Inongo)', 'Haut-Uélé (Isiro)', 'Bas-Uélé (Buta)', 'Nord-Ubangi (Gbadolite)',
      'Sud-Ubangi (Gemena)', 'Mongala (Lisala)', 'Tshuapa (Boende)',
    ],
  };

  /// Province / area names that IP lookups return which are not in a list verbatim.
  /// Keys are in normalized form (lowercase, no 'region/county/province/city/district').
  static const Map<String, Map<String, String>> _regionAliases = {
    'RW': {
      'eastern': 'Rwamagana',
      'northern': 'Musanze',
      'southern': 'Huye (Butare)',
      'western': 'Rubavu (Gisenyi)',
    },
    'UG': {'central': 'Kampala', 'kampala capital authority': 'Kampala'},
    'KE': {'elgeyo marakwet': 'Elgeyo-Marakwet (Iten)'},
  };

  /// Country whose regions are offered: the one detected from the device's network
  /// location. Unsupported / not-yet-detected countries fall back to Tanzania.
  static String get regionCountryIso {
    final iso = SessionManager.getCountryIso().toUpperCase();
    return regionsByCountry.containsKey(iso) ? iso : 'TZ';
  }

  /// Regions for the detected country (drives every region picker / dropdown).
  static List<String> get supportedRegions => regionsFor(SessionManager.getCountryIso());

  static List<String> regionsFor(String? iso) =>
      regionsByCountry[(iso ?? '').toUpperCase()] ?? regionsByCountry['TZ']!;

  /// Capital / main hub of a country, used when nothing more specific is detected.
  static String defaultRegionFor(String? iso) {
    final list = regionsFor(iso);
    return list.isNotEmpty ? list.first : _defaultCity;
  }

  static final ValueNotifier<String> activeLocationNotifier =
      ValueNotifier<String>(SessionManager.getUserCity());

  static String get currentCity => activeLocationNotifier.value;

  // ---- Country / phone code ---------------------------------------------------
  static const Map<String, ({String dial, String name})> _countries = {
    'TZ': (dial: '+255', name: 'Tanzania'),
    'KE': (dial: '+254', name: 'Kenya'),
    'UG': (dial: '+256', name: 'Uganda'),
    'RW': (dial: '+250', name: 'Rwanda'),
    'BI': (dial: '+257', name: 'Burundi'),
    'CD': (dial: '+243', name: 'DRC'),
  };

  /// Dial code of the country the app was launched in (Tanzania when unknown).
  static final ValueNotifier<String> dialCodeNotifier = ValueNotifier<String>(_dialFor(SessionManager.getCountryIso()));

  static String _dialFor(String? iso) => _countries[(iso ?? '').toUpperCase()]?.dial ?? '+255';

  static String get dialCode => dialCodeNotifier.value;

  static String get countryName {
    final iso = SessionManager.getCountryIso().toUpperCase();
    return _countries[iso]?.name ?? 'Tanzania';
  }

  static const String _kManualCountry = 'country_manual_iso';

  /// Settings: the person picked their country themselves (phone code, regions, money).
  /// From now on automatic detection (IP lookups) no longer replaces it.
  static Future<void> chooseCountry(String iso) async {
    final code = iso.trim().toUpperCase();
    if (!_countries.containsKey(code)) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kManualCountry, code);
    await SessionManager.saveCountryIso(code);
    dialCodeNotifier.value = _dialFor(code);
  }

  static Future<void> _saveCountry(String? iso) async {
    if (iso == null || iso.trim().isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    if (prefs.getString(_kManualCountry) != null) return; // chosen in Settings: detection must not undo it
    final code = iso.trim().toUpperCase();
    await SessionManager.saveCountryIso(code);
    dialCodeNotifier.value = _dialFor(code);
    CurrencyService.applyDetectedCountry(code); // prices / fees / wallet follow the country (until sign-in)
  }

  /// Checks the country on every launch (even when a city is already saved),
  /// so registration uses the right phone code, e.g. +254 in Kenya.
  static Future<void> refreshCountry() async {
    try {
      final r = await SecureHttp.client.get(Uri.parse('https://ipwho.is/')).timeout(const Duration(seconds: 4));
      if (r.statusCode == 200) {
        final d = json.decode(r.body);
        if (d['success'] == true && d['country_code'] is String) {
          await _saveCountry(d['country_code'] as String);
          return;
        }
      }
    } catch (e) {
      AppLog.d('Country detection (ipwho.is) error: $e');
    }
    try {
      final r = await SecureHttp.client.get(Uri.parse('https://ipapi.co/json/')).timeout(const Duration(seconds: 4));
      if (r.statusCode == 200) {
        final d = json.decode(r.body);
        if (d['error'] != true && d['country_code'] is String) {
          await _saveCountry(d['country_code'] as String);
        }
      }
    } catch (e) {
      AppLog.d('Country detection (ipapi.co) error: $e');
    }
  }

  // ---- GPS -> region (Tanzania) -----------------------------------------------
  // IP lookups are wrong on mobile data (the carrier's gateway can sit in another city, e.g. Zanzibar
  // for a phone in Dar es Salaam), so when the phone's GPS is available the region comes from the
  // coordinates: the nearest of these anchor points. A region can have several anchors (islands).
  static const List<({String label, double lat, double lng})> _tzAnchors = [
    (label: 'Dar es Salaam', lat: -6.7924, lng: 39.2083),
    (label: 'Pwani (Kibaha)', lat: -6.7700, lng: 38.9200),
    (label: 'Pwani (Kibaha)', lat: -7.3100, lng: 39.0000), // Mkuranga side
    (label: 'Zanzibar', lat: -6.1659, lng: 39.2026), // Unguja (Stone Town)
    (label: 'Zanzibar', lat: -6.1000, lng: 39.3600), // Unguja north-east
    (label: 'Zanzibar', lat: -5.2455, lng: 39.7686), // Pemba (Chake Chake)
    (label: 'Arusha', lat: -3.3869, lng: 36.6830),
    (label: 'Dodoma', lat: -6.1630, lng: 35.7516),
    (label: 'Mwanza', lat: -2.5164, lng: 32.9175),
    (label: 'Kilimanjaro (Moshi)', lat: -3.3349, lng: 37.3404),
    (label: 'Mbeya', lat: -8.9094, lng: 33.4608),
    (label: 'Morogoro', lat: -6.8211, lng: 37.6612),
    (label: 'Tanga', lat: -5.0689, lng: 39.0988),
    (label: 'Iringa', lat: -7.7700, lng: 35.6900),
    (label: 'Kigoma', lat: -4.8769, lng: 29.6266),
    (label: 'Tabora', lat: -5.0167, lng: 32.8000),
    (label: 'Mtwara', lat: -10.2736, lng: 40.1828),
    (label: 'Ruvuma (Songea)', lat: -10.6833, lng: 35.6500),
    (label: 'Shinyanga', lat: -3.6618, lng: 33.4231),
    (label: 'Kagera (Bukoba)', lat: -1.3317, lng: 31.8122),
    (label: 'Mara (Musoma)', lat: -1.5000, lng: 33.8000),
    (label: 'Singida', lat: -4.8167, lng: 34.7500),
    (label: 'Manyara (Babati)', lat: -4.2167, lng: 35.7500),
    (label: 'Geita', lat: -2.8700, lng: 32.2300),
    (label: 'Katavi', lat: -6.3400, lng: 31.0700),
    (label: 'Njombe', lat: -9.3300, lng: 34.7700),
    (label: 'Songwe', lat: -9.1000, lng: 33.0000),
    (label: 'Simiyu', lat: -2.8000, lng: 33.9800),
    (label: 'Lindi', lat: -9.9970, lng: 39.7140),
    (label: 'Rukwa (Sumbawanga)', lat: -7.9667, lng: 31.6167),
  ];

  /// Rough box around Tanzania, used only to decide whether a GPS point is worth mapping.
  static bool _inTanzaniaBox(double lat, double lng) => lat >= -11.8 && lat <= -0.9 && lng >= 29.3 && lng <= 40.6;

  static double _km(double lat1, double lng1, double lat2, double lng2) {
    const r = 6371.0;
    double rad(double d) => d * math.pi / 180;
    final dLat = rad(lat2 - lat1), dLng = rad(lng2 - lng1);
    final a = math.pow(math.sin(dLat / 2), 2) +
        math.cos(rad(lat1)) * math.cos(rad(lat2)) * math.pow(math.sin(dLng / 2), 2);
    return 2 * r * math.asin(math.sqrt(a));
  }

  /// The region of [iso]'s list nearest to the GPS point, or null when [iso] has no coordinate
  /// table (only Tanzania has one), the point is far from every region (over 250 km), or
  /// the point is not a real coordinate.
  @visibleForTesting
  static String? regionFromCoordinates(String? iso, double lat, double lng) {
    if ((iso ?? '').toUpperCase() != 'TZ') return null;
    if (!lat.isFinite || !lng.isFinite || !_inTanzaniaBox(lat, lng)) return null;
    String? best;
    var bestKm = double.infinity;
    for (final a in _tzAnchors) {
      final d = _km(lat, lng, a.lat, a.lng);
      if (d < bestKm) {
        bestKm = d;
        best = a.label;
      }
    }
    return bestKm <= 250 ? best : null;
  }

  /// Region from the phone's GPS, or null (permission not granted, GPS off, no fix, outside
  /// Tanzania). Never asks for permission (the start-up permission screen does that).
  static Future<String?> _regionFromGps() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) return null;
      final perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) return null;
      double? lat, lng;
      try {
        final pos = await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(accuracy: LocationAccuracy.medium, timeLimit: Duration(seconds: 6)),
        );
        lat = pos.latitude;
        lng = pos.longitude;
      } catch (caught, trace) {
        AppLog.e('location_service._regionFromGps', caught, trace);
        lat = GpsService.lat; // last fix kept by GpsService
        lng = GpsService.lng;
      }
      if (lat == null || lng == null || !_inTanzaniaBox(lat, lng)) return null;
      await refreshCountry(); // the GPS point can also be Kenya / Uganda...: only Tanzania has a table
      return regionFromCoordinates(SessionManager.getCountryIso(), lat, lng);
    } catch (e) {
      AppLog.d('GPS region detection error: $e');
      return null;
    }
  }

  /// Detect user's current city based on network location/IP with multi-provider fallback.
  /// If already saved in SessionManager, keeps saved choice unless forceRefresh is true.
  static Future<String> detectCurrentLocation({bool forceRefresh = false}) async {
    final saved = SessionManager.getUserCity();
    if (!forceRefresh && saved.isNotEmpty && saved != _defaultCity) {
      activeLocationNotifier.value = saved;
      refreshCountry(); // keep the phone code in step with where the app is opened
      return saved;
    }

    // Best source: the phone's GPS (the IP can point at another city on mobile data).
    final gps = await _regionFromGps();
    if (gps != null) {
      await setLocation(gps);
      return gps;
    }

    // Provider 1: ipwho.is (fast, generous limits, returns detailed country & city)
    try {
      final response = await SecureHttp.client
          .get(Uri.parse('https://ipwho.is/'))
          .timeout(const Duration(seconds: 4));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          final city = data['city'] as String?;
          final region = data['region'] as String?;
          final countryCode = data['country_code'] as String?;
          final countryName = data['country'] as String?;

          await _saveCountry(countryCode);
          final detected = resolveDetectedLocation(
            iso: countryCode,
            city: city,
            region: region,
            countryName: countryName,
          );

          await setLocation(detected);
          return detected;
        }
      }
    } catch (e) {
      AppLog.d('Primary location detection (ipwho.is) error: $e');
    }

    // Provider 2: ipapi.co (backup)
    try {
      final response = await SecureHttp.client
          .get(Uri.parse('https://ipapi.co/json/'))
          .timeout(const Duration(seconds: 4));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['error'] != true) {
          final city = data['city'] as String?;
          final region = data['region'] as String?;
          final country = data['country_name'] as String?;
          final countryCode = data['country_code'] as String?;

          await _saveCountry(countryCode);
          final detected = resolveDetectedLocation(
            iso: countryCode,
            city: city,
            region: region,
            countryName: country,
          );

          await setLocation(detected);
          return detected;
        }
      }
    } catch (e) {
      AppLog.d('Backup location detection (ipapi.co) error: $e');
    }

    // Fallback to saved or default
    final fallback = saved.isNotEmpty ? saved : defaultRegionFor(SessionManager.getCountryIso());
    activeLocationNotifier.value = fallback;
    return fallback;
  }

  /// Manually update and persist selected region
  static Future<void> setLocation(String regionName) async {
    activeLocationNotifier.value = regionName;
    await SessionManager.saveUserCity(regionName);
  }

  /// Turns an IP-lookup result into the location label we store.
  /// Supported countries resolve to an entry of that country's region list
  /// (or the raw city if it is not in the list); other countries become "City, Country".
  @visibleForTesting
  static String resolveDetectedLocation({
    required String? iso,
    String? city,
    String? region,
    String? countryName,
  }) {
    final code = (iso ?? '').toUpperCase();
    final c = (city ?? '').trim();
    final r = (region ?? '').trim();

    if (code.isEmpty || regionsByCountry.containsKey(code)) {
      final key = code.isEmpty ? 'TZ' : code;
      final matched = matchRegion(key, [c, r]);
      if (matched != null) return matched;
      if (c.isNotEmpty) return c;
      if (r.isNotEmpty) return r;
      return defaultRegionFor(key);
    }

    // Connecting from a country we have no region list for (e.g. USA, UK, or a VPN)
    final locName = c.isNotEmpty ? c : (r.isNotEmpty ? r : (countryName ?? 'International'));
    return (countryName != null && countryName.isNotEmpty) ? '$locName, $countryName' : locName;
  }

  /// Finds the entry of [iso]'s region list that matches the first matching
  /// candidate (city first, then region). Returns null when none match.
  @visibleForTesting
  static String? matchRegion(String iso, List<String> candidates) {
    final list = regionsFor(iso);
    final aliases = _regionAliases[iso.toUpperCase()] ?? const <String, String>{};
    final entries = <({String label, List<String> keys})>[
      for (final label in list) (label: label, keys: _keysFor(label)),
    ];

    for (final raw in candidates) {
      final cand = _normalize(raw);
      if (cand.isEmpty) continue;
      if (aliases.containsKey(cand)) return aliases[cand];
      for (final e in entries) {
        if (e.keys.contains(cand)) return e.label; // exact name or town
      }
    }
    for (final raw in candidates) {
      final cand = _normalize(raw);
      if (cand.length < 4) continue;
      for (final e in entries) {
        for (final k in e.keys) {
          if (k.length >= 4 && (cand.contains(k) || k.contains(cand))) return e.label;
        }
      }
    }
    return null;
  }

  /// 'Uasin Gishu (Eldoret)' -> ['uasin gishu', 'eldoret'] (normalized).
  static List<String> _keysFor(String label) {
    final m = RegExp(r'^(.*?)\s*\((.*?)\)\s*$').firstMatch(label);
    if (m == null) return [_normalize(label)];
    return [_normalize(m.group(1)!), _normalize(m.group(2)!)];
  }

  static const Map<String, String> _accents = {
    'à': 'a', 'á': 'a', 'â': 'a', 'ä': 'a', 'è': 'e', 'é': 'e', 'ê': 'e', 'ë': 'e',
    'ì': 'i', 'í': 'i', 'î': 'i', 'ï': 'i', 'ò': 'o', 'ó': 'o', 'ô': 'o', 'ö': 'o',
    'ù': 'u', 'ú': 'u', 'û': 'u', 'ü': 'u', 'ç': 'c',
  };

  static String _normalize(String raw) {
    var s = raw.toLowerCase();
    _accents.forEach((k, v) => s = s.replaceAll(k, v));
    s = s
        .replaceAll(RegExp(r"['’]"), '')
        .replaceAll(RegExp(r'[^a-z0-9 ]'), ' ')
        .replaceAll(RegExp(r'\b(region|county|province|district|city|state|prefecture)\b'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    return s;
  }
}
