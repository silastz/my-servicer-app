import 'package:flutter/material.dart';

import '../constants/app_strings.dart';

/// Stops an older, slower response from overwriting a newer one.
///
///   final id = _guard.next();
///   final data = await fetch();
///   if (!mounted || !_guard.isLatest(id)) return;
class LoadGuard {
  int _id = 0;

  int next() => ++_id;

  bool isLatest(int id) => id == _id;
}

/// "Could not load" notice with a Retry button. Used when a fetch fails, so a
/// weak connection is never shown as an empty list.
void showLoadFailed(BuildContext context, VoidCallback retry) {
  final en = AppStrings.isEnglish;
  final messenger = ScaffoldMessenger.of(context);
  messenger.hideCurrentSnackBar();
  messenger.showSnackBar(
    SnackBar(
      content: Text(en ? 'Could not load. Check your connection.' : 'Imeshindwa kupakia. Angalia mtandao wako.'),
      action: SnackBarAction(label: en ? 'Retry' : 'Jaribu tena', onPressed: retry),
    ),
  );
}
