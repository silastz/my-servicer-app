import 'package:flutter/foundation.dart';

/// One shared "server data changed" signal.
///
/// Every successful write to the backend (booking, accept/reject, release,
/// wallet, review, service post, message ...) bumps [changed]. Screens that
/// show the same data (Requests, Payments, Pocket Fund, Notifications, Reviews,
/// Earnings, My Services, Chats, Home bell) listen and re-fetch, so they never
/// show different numbers for the same thing.
class DataSync {
  static final ValueNotifier<int> changed = ValueNotifier<int>(0);

  static void bump() => changed.value++;
}
