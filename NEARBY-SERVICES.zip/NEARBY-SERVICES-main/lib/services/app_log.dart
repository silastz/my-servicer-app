import 'package:flutter/foundation.dart';

/// The one place the app logs from.
///
/// * Debug builds print to the console, so development is unchanged.
/// * Release builds print NOTHING (so a log line can never leak a phone number, token or server answer),
///   but a handled error is not lost either: [e] keeps the last [maxRecent] "where: ErrorType" lines in memory
///   (never the message text) and hands each one to [onError], where a crash reporter can be plugged in:
///
///     AppLog.onError = (where, error, stack) => MyCrashReporter.record(error, stack, reason: where);
class AppLog {
  AppLog._();

  static const int maxRecent = 50;

  /// Set once at start-up to forward handled errors to a crash-reporting service. Null = nothing is forwarded.
  static void Function(String where, Object error, StackTrace? stack)? onError;

  static final List<String> _recent = <String>[];

  /// The latest handled errors, oldest first, as "where: ErrorType". Safe to show in a support screen.
  static List<String> get recent => List.unmodifiable(_recent);

  /// A debug message. Printed in debug builds only.
  static void d(String message) {
    if (kDebugMode) debugPrint(message);
  }

  /// A handled error: [where] says which action failed, e.g. "ChatThread.send".
  static void e(String where, Object error, [StackTrace? stack]) {
    _recent.add('$where: ${error.runtimeType}');
    if (_recent.length > maxRecent) _recent.removeAt(0);
    if (kDebugMode) debugPrint('[$where] $error');
    try {
      onError?.call(where, error, stack);
    } catch (_) {
      // a broken reporter must never break the app
    }
  }

  @visibleForTesting
  static void resetForTest() {
    _recent.clear();
    onError = null;
  }
}
