import 'dart:async';
import 'dart:convert';
import 'dart:io' show Platform;
import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import '../security/secure_http.dart';
import '../security/client_security_config.dart';
import 'app_policy.dart';
import 'security_settings.dart';
import 'app_log.dart';

/// Everything the admin controls from the backend (see docs/app_policy_api_contract.md):
/// fees, wallet limits and security switches (screenshots, root block, Play Integrity).
/// Users have no setting for any of it.
///
/// The last answer is kept on the phone ([AppPolicy] + [SecuritySettings]), so it also applies
/// at the next start and offline. If the server cannot be reached, nothing changes.
class AppPolicyService with WidgetsBindingObserver {
  AppPolicyService._();
  static final AppPolicyService _i = AppPolicyService._();

  static const Duration _minGap = Duration(minutes: 10);
  static DateTime? _lastCheck;
  static bool _started = false;

  /// Call once after the app is on screen.
  static void start() {
    if (_started) return;
    _started = true;
    WidgetsBinding.instance.addObserver(_i);
    refresh();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) refresh();
  }

  /// Screenshots / screen recording: allowed only when the admin says `true`
  /// (`security.screenCaptureAllowed`, or top level `screenCaptureAllowed`).
  @visibleForTesting
  static bool? parseScreenCapture(dynamic body) {
    if (body is! Map) return null;
    final d = body['data'] is Map ? body['data'] as Map : body;
    final sec = d['security'] is Map ? d['security'] as Map : const {};
    final v = sec['screenCaptureAllowed'] ?? d['screenCaptureAllowed'];
    return v is bool ? v : null;
  }

  static Future<void> refresh({bool force = false}) async {
    final now = DateTime.now();
    if (!force && _lastCheck != null && now.difference(_lastCheck!) < _minGap) return;
    _lastCheck = now;
    try {
      final platform = kIsWeb ? 'web' : (Platform.isIOS ? 'ios' : 'android');
      final res = await SecureHttp.client
          .get(Uri.parse('${ClientSecurityConfig.apiBase}/app/policy?platform=$platform'))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode != 200) return;
      final body = jsonDecode(res.body);
      final clean = AppPolicy.sanitize(body);
      if (clean == null) return;
      await AppPolicy.apply(clean);
      await SecuritySettings.setAdminScreenCapture(parseScreenCapture(body));
    } catch (e) {
      _lastCheck = null; // offline or endpoint missing: keep the saved policy, try again next time
      AppLog.d('Policy refresh failed: $e');
    }
  }
}
