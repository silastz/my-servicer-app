import 'package:flutter/services.dart';

/// Amount fields: shows thousands separators while the person types (2000 -> 2,000).
/// Only digits are kept; [maxDigits] counts digits, not the commas.
/// Read the value back with [MoneyInput.parse], set it from code with [MoneyInput.text].
class MoneyInputFormatter extends TextInputFormatter {
  final int maxDigits;
  const MoneyInputFormatter({this.maxDigits = 9});

  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    final raw = newValue.text;
    final cursor = newValue.selection.baseOffset.clamp(0, raw.length);

    // How many digits sit before the cursor, so the cursor can be put back after the commas move.
    var digitsBeforeCursor = 0;
    final digits = StringBuffer();
    for (var i = 0; i < raw.length; i++) {
      final code = raw.codeUnitAt(i);
      if (code >= 0x30 && code <= 0x39) {
        digits.write(raw[i]);
        if (i < cursor) digitsBeforeCursor++;
      }
    }

    var d = digits.toString();
    if (d.length > maxDigits) {
      d = d.substring(0, maxDigits);
      if (digitsBeforeCursor > maxDigits) digitsBeforeCursor = maxDigits;
    }
    // No leading zeros ("007" -> "7"); a lone "0" stays.
    var stripped = 0;
    while (d.length > 1 && d.startsWith('0')) {
      d = d.substring(1);
      stripped++;
    }
    digitsBeforeCursor = (digitsBeforeCursor - stripped).clamp(0, d.length);

    final formatted = MoneyInput.group(d);

    // Cursor: after the same number of digits as before.
    var pos = 0;
    var seen = 0;
    while (pos < formatted.length && seen < digitsBeforeCursor) {
      if (formatted[pos] != ',') seen++;
      pos++;
    }
    return TextEditingValue(
      text: formatted,
      selection: TextSelection.collapsed(offset: pos),
    );
  }
}

class MoneyInput {
  MoneyInput._();

  /// "2000" -> "2,000" (digits only in, grouped text out).
  static String group(String digits) =>
      digits.replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+$)'), (m) => '${m[1]},');

  /// Amount for a controller set from code: 50000 -> "50,000"; 0 or null -> "".
  static String text(num? v, {bool blankZero = true}) {
    if (v == null || (blankZero && v == 0)) return '';
    return group(v.round().toString());
  }

  /// What the person typed ("2,000", "2 000") as a number; null when empty or not a number.
  static double? parse(String? s) {
    if (s == null) return null;
    final clean = s.replaceAll(RegExp(r'[,\s]'), '');
    return clean.isEmpty ? null : double.tryParse(clean);
  }
}
