import 'dart:async';
import 'dart:convert';
import 'dart:io' show SocketException, HandshakeException;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../security/attestation.dart';
import '../security/secure_http.dart';
import '../security/client_security_config.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/boost.dart';
import '../models/portfolio_item.dart';
import '../models/models.dart';
import '../models/payment_gateway.dart';
import '../models/sms_gateway.dart';
import '../models/identity_lookup.dart';
import '../models/ads_config.dart';
import '../models/provider_fees.dart';
import '../models/service_search.dart';
import 'app_policy.dart';
import 'block_service.dart';
import 'data_sync.dart';
import 'gps_service.dart';
import 'pending_otp.dart';
import 'security_settings.dart';
import 'session_manager.dart';
import 'currency_service.dart';
import 'error_messages.dart';
import 'app_log.dart';

/// Debug-only logging; never prints in release builds and callers must not pass
/// response bodies, tokens, OTPs or phone numbers.
void _log(String message) {
  if (kDebugMode) AppLog.d(message);
}

/// What a chat message carries besides text. Attachments travel as a link to our
/// own server in the message text, so /chats/send needs no change.
enum ChatAttachmentKind { image, audio, file }

/// A multipart request that reports how much of the body has been handed to the network (0..1).
class _ProgressMultipartRequest extends http.MultipartRequest {
  final void Function(double progress) onProgress;
  _ProgressMultipartRequest(super.method, super.url, this.onProgress);

  @override
  http.ByteStream finalize() {
    final total = contentLength;
    var sent = 0;
    final body = super.finalize();
    return http.ByteStream(body.transform(StreamTransformer<List<int>, List<int>>.fromHandlers(
      handleData: (chunk, sink) {
        sent += chunk.length;
        sink.add(chunk);
        if (total > 0) onProgress((sent / total).clamp(0.0, 1.0));
      },
    )));
  }
}

/// Result of a media upload: [ok] with the file's public [url] (when the
/// endpoint returns one), or a readable [error].
class UploadResult {
  final String? url;
  final String? error;

  /// True when trying again can work (weak network, timeout, server busy); false for a real refusal.
  final bool retryable;
  const UploadResult({this.url, this.error, this.retryable = false});
  bool get ok => error == null;
}

/// Result of an invitation call: [ok] with the server's [data], or a readable
/// [error] already worded for the user.
class InviteResult {
  final Map<String, dynamic> data;
  final String? error;
  const InviteResult({this.data = const {}, this.error});
  bool get ok => error == null;
}

/// Thin wrapper over package:http that signs the user out when the server says
/// the token is invalid/expired (401), so a stolen/expired token is not kept.
class _Http {
  static Future<http.Response> get(Uri url, {Map<String, String>? headers}) async =>
      _check(headers, await SecureHttp.client.get(url, headers: headers));

  static Future<http.Response> post(Uri url, {Map<String, String>? headers, Object? body}) async {
    final h = await Attestation.attach(url, headers); // Play Integrity token on sensitive calls
    return _written(_check(h, await SecureHttp.client.post(url, headers: h, body: body)));
  }

  static Future<http.Response> put(Uri url, {Map<String, String>? headers, Object? body}) async =>
      _written(_check(headers, await SecureHttp.client.put(url, headers: headers, body: body)));

  static Future<http.Response> delete(Uri url, {Map<String, String>? headers, Object? body}) async =>
      _written(_check(headers, await SecureHttp.client.delete(url, headers: headers, body: body)));

  /// A successful write means server data changed: tell every listening screen.
  static http.Response _written(http.Response r) {
    if (r.statusCode >= 200 && r.statusCode < 300) DataSync.bump();
    return r;
  }

  static http.Response _check(Map<String, String>? headers, http.Response r) {
    final hadToken = headers?.containsKey('Authorization') ?? false;
    if (hadToken) {
      // Sliding login: the server hands out a fresh token now and then, so an active user never expires.
      final fresh = r.headers['x-refreshed-token'];
      if (fresh != null && fresh.isNotEmpty) {
        unawaited(SessionManager.replaceToken(fresh, sentWith: _bearerOf(headers)));
      }
      if (r.statusCode == 401) unawaited(_confirmSessionDead(headers));
    }
    return r;
  }

  static String? _bearerOf(Map<String, String>? headers) {
    final h = headers?['Authorization'];
    return h != null && h.startsWith('Bearer ') ? h.substring(7) : null;
  }

  static bool _confirming = false;

  /// One 401 is not proof: it can be a hiccup. The user is signed out only when the server also
  /// refuses the same token on /users/me. Offline, a timeout or a server error never signs anyone out.
  static Future<void> _confirmSessionDead(Map<String, String>? headers) async {
    if (_confirming) return;
    _confirming = true;
    try {
      final sent = _bearerOf(headers);
      if (sent == null || SessionManager.getToken() != sent) return;
      final r = await SecureHttp.client
          .get(Uri.parse('${ApiService.baseUrl}/users/me'), headers: headers)
          .timeout(const Duration(seconds: 10));
      if (r.statusCode == 401 && SessionManager.getToken() == sent) {
        await SessionManager.expireSession();
      }
    } catch (_) {
      // no network answer: stay signed in
    } finally {
      _confirming = false;
    }
  }
}

class ApiService {
  static String get baseUrl => ClientSecurityConfig.apiBase;

  /// Converts backend error code or message into dynamically localized text based on AppStrings
  static String normalizeError(dynamic rawError) {
    if (rawError == null) return AppStrings.error;
    final msg = rawError.toString().trim();
    if (msg.isEmpty) return AppStrings.error;

    if (msg.contains('ACCOUNT_NOT_VERIFIED') || msg.toLowerCase().contains('haijathibitishwa') || msg.toLowerCase().contains('not verified')) {
      return AppStrings.authAccountNotVerifiedError;
    }
    if (msg.contains('INVALID_CREDENTIALS') || msg.toLowerCase().contains('bad credentials') || msg.toLowerCase().contains('invalid login credentials')) {
      return AppStrings.authInvalidCredentialsError;
    }
    if (msg.contains('PHONE_VERIFICATION_PENDING')) {
      return AppStrings.authSignupPendingError;
    }
    if (msg.contains('PHONE_ALREADY_REGISTERED') || msg.toLowerCase().contains('phone number is already registered')) {
      return AppStrings.authPhoneExistsError;
    }
    if (msg.contains('EMAIL_ALREADY_REGISTERED') || msg.toLowerCase().contains('email is already registered')) {
      return AppStrings.authEmailExistsError;
    }
    if (msg.contains('USER_NOT_FOUND') || msg.toLowerCase().contains('user not found') || msg.toLowerCase().contains('hajapatikana')) {
      return AppStrings.authUserNotFoundError;
    }
    if (msg.contains('INVALID_PHONE_NUMBER') || msg.toLowerCase().contains('invalid phone')) {
      return AppStrings.authInvalidPhoneError;
    }
    if (msg.contains('INVALID_OR_EXPIRED_OTP') || msg.contains('INVALID_OTP_FORMAT') || msg.toLowerCase().contains('invalid or expired otp')) {
      return AppStrings.authInvalidOtpError;
    }
    if (msg.contains('SocketException') || msg.contains('TimeoutException') || msg.toLowerCase().contains('network') || msg.toLowerCase().contains('haikuweza kuunganisha')) {
      return AppStrings.authNetworkError;
    }
    // Any other backend code (TOO_MANY_PHOTOS, OFFER_EXPIRED, ...) becomes a sentence, never the raw code.
    return ErrorMessages.friendly(msg);
  }

  static Map<String, String> _getHeaders() {
    final headers = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      // Lets the server price, charge and pay out in the user's own country money.
      'X-Country': CurrencyService.current.iso,
      'X-Currency': CurrencyService.code,
    };
    final token = SessionManager.getToken();
    if (token != null && token.isNotEmpty) {
      headers['Authorization'] = 'Bearer $token';
    }
    return headers;
  }

  // ---------------------------------------------------------------------------
  // AUTH (register / OTP / forgot + reset password / login)
  // ---------------------------------------------------------------------------

  /// Why the LAST auth call did not get a real answer from the server:
  /// 'network' (offline / timeout), 'server' (5xx / unreadable reply), 'ratelimit' (429), or null.
  /// Screens use it to show the right message and NOT to count it as a wrong password / OTP.
  static String? lastAuthProblem;

  /// The user-facing text for [lastAuthProblem].
  static String authProblemMessage([String? problem]) {
    switch (problem ?? lastAuthProblem) {
      case 'ratelimit':
        return AppStrings.authRateLimitedError;
      case 'server':
        return AppStrings.authServerBusyError;
      default:
        return AppStrings.authNetworkError;
    }
  }

  /// Decodes a JSON object body; returns null (never throws) for HTML / empty / non-object replies.
  static Map<String, dynamic>? _decodeObj(String body) {
    try {
      final d = json.decode(body);
      if (d is Map<String, dynamic>) return d;
      if (d is Map) return Map<String, dynamic>.from(d);
    } catch (caught, trace) { AppLog.e('api_service.authProblemMessage', caught, trace); }
    return null;
  }

  /// Sets [lastAuthProblem] from a status code; true when the reply is NOT a real answer.
  static bool _flagProblem(http.Response r) {
    if (r.statusCode == 429) {
      lastAuthProblem = 'ratelimit';
      return true;
    }
    if (r.statusCode >= 500) {
      lastAuthProblem = 'server';
      return true;
    }
    return false;
  }

  static bool _isOk(int code) => code == 200 || code == 201;

  static String _msgOf(Map<String, dynamic>? d, String fallback) {
    final v = d?['message'] ?? d?['error'];
    return (v is String && v.trim().isNotEmpty) ? v : fallback;
  }

  static const Duration _authTimeout = Duration(seconds: 25);

  /// Register a new user
  static Future<Map<String, dynamic>?> register({
    required String username,
    required String phone,
    String? email,
    required String password,
    required String stageName,
    String role = 'ROLE_BUYER',
  }) async {
    lastAuthProblem = null;
    _signup = null; // a new attempt replaces any earlier one
    // Last line of defence (the screens validate first): refuse impossible input
    // instead of sending it, and never let a caller pick any role but these two.
    if (phone.trim().isEmpty ||
        password.isEmpty ||
        password.length > 128 ||
        stageName.trim().isEmpty ||
        stageName.length > 120 ||
        username.length > 60 ||
        (role != 'ROLE_BUYER' && role != 'ROLE_SELLER')) {
      return {'success': false, 'error': AppStrings.error};
    }
    try {
      final payload = <String, dynamic>{
        'username': username,
        'phone': phone,
        'password': password,
        'stageName': stageName,
        'role': role,
      };
      if (email != null && email.trim().isNotEmpty) {
        payload['email'] = email.trim();
      }

      final response = await _Http.post(
        Uri.parse('$baseUrl/auth/register'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(payload),
      ).timeout(_authTimeout);

      if (_flagProblem(response)) {
        return {'success': false, 'error': authProblemMessage(), 'problem': lastAuthProblem};
      }
      final data = _decodeObj(response.body);
      if (_isOk(response.statusCode)) {
        // Do NOT establish session here. User must verify OTP first!
        // The server saved NOTHING: it only texted the code and returned a signed challenge. The sign-up form
        // stays here, in memory, and goes back to the server together with the code (see verifyPhoneOtp).
        final challenge = data?['signupChallenge']?.toString() ?? '';
        if (challenge.isNotEmpty) {
          _signup = _PendingSignup(
            phone: (data?['phone']?.toString().trim().isNotEmpty ?? false) ? data!['phone'].toString().trim() : phone.trim(),
            challenge: challenge,
            password: password,
            stageName: stageName.trim(),
            role: role,
            email: (email != null && email.trim().isNotEmpty) ? email.trim() : null,
          );
          // Also kept (encrypted) for the admin's "pending minutes": if the app is closed and reopened in time,
          // typing the same phone goes straight back to the code screen (see restorePendingSignup).
          await PendingOtpStore.save(PendingOtpKind.signup, _signup!.phone, form: _signup!.toJson());
        }
        return {'success': true, 'data': data ?? <String, dynamic>{}};
      }
      return {'success': false, 'error': normalizeError(_msgOf(data, 'Registration failed (${response.statusCode})'))};
    } catch (e) {
      _log('Registration error: ${e.runtimeType}');
      lastAuthProblem = 'network';
      return {'success': false, 'error': AppStrings.authNetworkError, 'problem': 'network'};
    }
  }

  /// Shared body of the four "send / verify a code" calls.
  static Future<Map<String, dynamic>?> _otpCall(String path, Map<String, String> body) async {
    lastAuthProblem = null;
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl$path'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(body),
      ).timeout(_authTimeout);
      if (_flagProblem(response)) return null;
      final data = _decodeObj(response.body);
      if (_isOk(response.statusCode) && data != null && data['success'] == true) return data;
      return null;
    } catch (e) {
      _log('OTP call error: ${e.runtimeType}');
      lastAuthProblem = 'network';
      return null;
    }
  }

  /// Verify 6-digit OTP sent to user's email
  static Future<bool> verifyEmailOtp(String email, String otp) async =>
      await _otpCall('/auth/verify-otp', {'email': email.trim(), 'otp': otp.trim()}) != null;

  /// Resend 6-digit OTP code to user's email
  static Future<bool> resendEmailOtp(String email) async =>
      await _otpCall('/auth/resend-otp', {'email': email.trim()}) != null;

  /// Verify 6-digit OTP sent to user's phone via SMS Gateway Pro.
  /// Returns null on failure; check [lastAuthProblem] to tell "wrong code" from "no connection".
  static Future<Map<String, dynamic>?> verifyPhoneOtp(String phone, String otp) async {
    final s = _signup;
    if (s != null && _sameNumber(s.phone, phone)) {
      // New sign-up: the account does not exist yet. The code and the form go to the server together and the
      // server creates the account only if the code is right.
      final res = await _otpCall('/auth/phone/complete-signup', {
        'phone': s.phone,
        'otp': otp.trim(),
        'challenge': s.challenge,
        'password': s.password,
        'stageName': s.stageName,
        'role': s.role,
        if (s.email != null) 'email': s.email!,
      });
      if (res != null) {
        _signup = null; // account created: forget the form (and the password) at once
        await PendingOtpStore.clear(PendingOtpKind.signup);
      }
      return res;
    }
    return _otpCall('/auth/phone/verify-otp', {'phone': phone.trim(), 'otp': otp.trim()});
  }

  /// Resend 6-digit OTP code to user's phone via SMS Gateway Pro
  static Future<bool> resendPhoneOtp(String phone) async {
    final s = _signup;
    if (s != null && _sameNumber(s.phone, phone)) {
      // New sign-up: nothing is saved on the server, so "resend" sends the form again for a fresh code.
      final res = await register(
        username: '',
        phone: s.phone,
        email: s.email,
        password: s.password,
        stageName: s.stageName,
        role: s.role,
      );
      return res != null && res['success'] == true;
    }
    return await _otpCall('/auth/phone/resend-otp', {'phone': phone.trim()}) != null;
  }

  /// The sign-up the server has texted a code for. Memory only; never written to disk.
  static _PendingSignup? _signup;

  /// Forget a half-finished sign-up (the person left the code screen).
  static void cancelPendingSignup() {
    _signup = null;
    PendingOtpStore.clear(PendingOtpKind.signup);
  }

  /// Brings a saved sign-up back after the app was closed ([form] from [PendingOtpStore]) so the code can be
  /// confirmed. Optional values typed again on the form replace the saved ones. The code's clock is NOT
  /// restarted. Returns false when [form] is not a usable saved sign-up.
  static Future<bool> restorePendingSignup(
    Map<String, dynamic>? form, {
    DateTime? sentAt,
    String? stageName,
    String? password,
    String? email,
  }) async {
    final saved = _PendingSignup.tryParse(form);
    if (saved == null) return false;
    final restored = saved.copyWith(
      stageName: (stageName != null && stageName.trim().isNotEmpty) ? stageName.trim() : null,
      password: (password != null && password.isNotEmpty) ? password : null,
      email: (email != null && email.trim().isNotEmpty) ? email.trim() : null,
    );
    _signup = restored;
    final overridden = stageName != null || password != null || email != null;
    if (sentAt != null && overridden) {
      await PendingOtpStore.save(PendingOtpKind.signup, restored.phone, form: restored.toJson(), sentAt: sentAt);
    }
    return true;
  }

  static bool _sameNumber(String a, String b) {
    String tail(String x) {
      final d = x.replaceAll(RegExp(r'\D'), '');
      return d.length > 9 ? d.substring(d.length - 9) : d;
    }
    return tail(a).isNotEmpty && tail(a) == tail(b);
  }

  /// Request OTP for password reset (via SMS or Email).
  ///
  /// Anti-enumeration: "no such account" and "account not verified" are reported exactly like
  /// success ("if this account exists, a code was sent"), so nobody can use this screen to find
  /// out which phone numbers or emails are registered.
  static Future<Map<String, dynamic>> forgotPassword(String identifier) async {
    lastAuthProblem = null;
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/auth/forgot-password'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'identifier': identifier.trim()}),
      ).timeout(_authTimeout);

      if (_flagProblem(response)) {
        return {'success': false, 'message': authProblemMessage(), 'problem': lastAuthProblem};
      }
      final data = _decodeObj(response.body);
      if (_isOk(response.statusCode) && data?['success'] == true) {
        return {'success': true, 'message': AppStrings.authResetIfExists};
      }
      final raw = _msgOf(data, '');
      if (raw.contains('USER_NOT_FOUND') ||
          raw.contains('ACCOUNT_NOT_VERIFIED') ||
          response.statusCode == 404) {
        return {'success': true, 'message': AppStrings.authResetIfExists, 'generic': true};
      }
      return {'success': false, 'message': normalizeError(raw.isEmpty ? AppStrings.error : raw), 'rawCode': raw};
    } catch (e) {
      _log('Forgot Password error: ${e.runtimeType}');
      lastAuthProblem = 'network';
      return {'success': false, 'message': AppStrings.authNetworkError, 'problem': 'network'};
    }
  }

  /// Reset password using OTP
  static Future<Map<String, dynamic>> resetPassword(String identifier, String otp, String newPassword) async {
    lastAuthProblem = null;
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/auth/reset-password'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'identifier': identifier.trim(),
          'otp': otp.trim(),
          'newPassword': newPassword,
        }),
      ).timeout(_authTimeout);

      if (_flagProblem(response)) {
        return {'success': false, 'message': authProblemMessage(), 'problem': lastAuthProblem};
      }
      final data = _decodeObj(response.body);
      if (_isOk(response.statusCode) && data?['success'] == true) {
        return {'success': true, 'message': _msgOf(data, 'Password reset successfully')};
      }
      // Any server-side refusal (wrong/expired code, unknown account, weak password) -> one safe message,
      // unless the server clearly says the password itself is the problem.
      final raw = _msgOf(data, 'INVALID_OR_EXPIRED_OTP');
      final weak = raw.toLowerCase().contains('password');
      return {
        'success': false,
        'message': weak ? raw : AppStrings.authInvalidOtpError,
      };
    } catch (e) {
      _log('Reset Password error: ${e.runtimeType}');
      lastAuthProblem = 'network';
      return {'success': false, 'message': AppStrings.authNetworkError, 'problem': 'network'};
    }
  }

  /// Authenticate user via phone number or email and password
  static Future<Map<String, dynamic>?> login(String login, String password) async {
    lastAuthProblem = null;
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/auth/login'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'login': login, 'password': password}),
      ).timeout(_authTimeout);

      // Too many wrong passwords for this account: the screen sends the user to "forgot password".
      if (response.statusCode == 429 &&
          (_decodeObj(response.body)?['message']?.toString() ?? '').contains('TOO_MANY_LOGIN_ATTEMPTS')) {
        lastAuthProblem = 'ratelimit';
        return {
          'success': false,
          'error': AppStrings.authLoginLockedError,
          'problem': 'ratelimit',
          'rawCode': 'TOO_MANY_LOGIN_ATTEMPTS',
        };
      }

      if (_flagProblem(response)) {
        return {'success': false, 'error': authProblemMessage(), 'problem': lastAuthProblem};
      }
      final data = _decodeObj(response.body);
      if (_isOk(response.statusCode)) {
        final token = data?['token'];
        if (data == null || token is! String || token.isEmpty) {
          // 200 without a usable token: never half-login.
          lastAuthProblem = 'server';
          return {'success': false, 'error': AppStrings.authServerBusyError, 'problem': 'server'};
        }
        final idRaw = data['id'];
        await SessionManager.saveSession(
          token: token,
          userId: idRaw is int ? idRaw : (int.tryParse('${idRaw ?? ''}') ?? 0),
          username: (data['username'] ?? login).toString(),
          stageName: (data['stageName'] ?? 'User').toString(),
          role: (data['role'] ?? 'ROLE_BUYER').toString(),
          badge: (data['verificationBadge'] ?? 'NONE').toString(),
          currency: (data['currency'] ?? data['countryCode'] ?? data['country'])?.toString(),
        );
        // Restore the registered phone / email on a new phone (when the server sends them).
        final regPhone = data['phone']?.toString().trim() ?? '';
        if (regPhone.isNotEmpty && regPhone != 'null') await SessionManager.savePhone(regPhone);
        final regEmail = data['email']?.toString().trim() ?? '';
        if (regEmail.isNotEmpty && regEmail != 'null') await SessionManager.saveEmail(regEmail);
        // Restore the profile photo on a new phone (when the server sends it).
        final avatar = (data['avatarUrl'] ?? data['profileImage'] ?? data['profilePhoto'])?.toString().trim() ?? '';
        if (avatar.isNotEmpty && avatar != 'null') await SessionManager.saveAvatarUrl(absoluteUrl(avatar));
        // Restore the Hide My ID choice on a new phone (when the server sends it).
        if (data['hideMyId'] is bool) await SecuritySettings.setHideMyId(data['hideMyId'] as bool);
        // Restore the Profile Locked choice too (the server hides phone and socials by it, so the phone must agree).
        if (data['profileLocked'] is bool) await SecuritySettings.setProfileLocked(data['profileLocked'] as bool);
        // Restore the notification switches on a new phone (when the server sends them).
        if (data['notifBookings'] is bool) await SecuritySettings.setFlag('notif_bookings', data['notifBookings'] as bool);
        if (data['notifMessages'] is bool) await SecuritySettings.setFlag('notif_messages', data['notifMessages'] as bool);
        if (data['notifPromos'] is bool) await SecuritySettings.setFlag('notif_promos', data['notifPromos'] as bool);
        // Do not hand the raw token back to screens.
        return {'success': true, 'data': ({...data}..remove('token'))};
      }

      final rawCode = (data?['message'] is String) ? data!['message'] as String : '';
      final msg = _msgOf(data, 'Login failed (${response.statusCode})');
      // Anti-enumeration: "unknown user" and "wrong password" look the same. Only the
      // "not verified" state keeps its own message because the app must guide the user to verify.
      final notVerified = rawCode.contains('ACCOUNT_NOT_VERIFIED') || msg.toLowerCase().contains('not verified');
      final generic = !notVerified &&
          (response.statusCode == 400 ||
              response.statusCode == 401 ||
              response.statusCode == 404 ||
              rawCode.contains('USER_NOT_FOUND') ||
              rawCode.contains('INVALID_CREDENTIALS') ||
              msg.toLowerCase().contains('bad credentials'));
      return {
        'success': false,
        'error': generic ? AppStrings.authInvalidCredentialsError : normalizeError(msg),
        'rawCode': notVerified ? 'ACCOUNT_NOT_VERIFIED' : rawCode,
      };
    } catch (e) {
      _log('Login error: ${e.runtimeType}');
      lastAuthProblem = 'network';
      return {'success': false, 'error': AppStrings.authNetworkError, 'problem': 'network'};
    }
  }

  /// Fetch wallet balance for the authenticated user
  static Future<Map<String, dynamic>?> getWallet() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/wallet'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body);
      }
      return null;
    } catch (e) {
      _log('Wallet fetch error: $e');
      return null;
    }
  }

  /// Deposit funds into Pocket Fund
  /// [reference] (the payment reference) lets the server credit the same payment only once.
  static Future<Map<String, dynamic>?> depositWallet(double amount, {String? reference, String? method}) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/wallet/deposit'),
        headers: _getHeaders(),
        body: json.encode({
          'amount': amount,
          if (reference != null) 'reference': reference,
          if (method != null) 'method': method,
        }),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body);
      }
      return null;
    } catch (e) {
      _log('Deposit error: $e');
      return null;
    }
  }

  /// Withdraw funds from Pocket Fund
  static Future<Map<String, dynamic>?> withdrawWallet(double amount, String phone) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/wallet/withdraw'),
        headers: _getHeaders(),
        body: json.encode({'amount': amount, 'phone': phone}),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        lastPaymentError = null;
        return json.decode(response.body);
      }
      lastPaymentError = _withdrawErrorText(response.statusCode, response.body);
      return null;
    } catch (e) {
      lastPaymentError = _exceptionText(e);
      _log('Withdraw error: $e');
      return null;
    }
  }

  /// Turns the backend's withdrawal codes (WalletService.withdraw) into a sentence for the user.
  static String _withdrawErrorText(int status, String body) {
    final en = AppStrings.isEnglish;
    String code = '';
    try {
      final d = json.decode(body);
      if (d is Map) code = (d['message'] ?? '').toString().toUpperCase();
    } catch (caught, trace) { AppLog.e('api_service._withdrawErrorText', caught, trace); }
    if (code.contains('WITHDRAW_BELOW_MIN')) return en ? 'That is below the minimum you can withdraw.' : 'Kiasi hiki ni chini ya kiwango cha chini cha kutoa.';
    if (code.contains('WITHDRAW_ABOVE_MAX')) return en ? 'That is above the most you can withdraw at once.' : 'Kiasi hiki kinazidi kiwango cha juu cha kutoa kwa mara moja.';
    if (code.contains('WITHDRAW_TOO_SMALL_FOR_FEES')) return en ? 'Too small: the fee would take all of it.' : 'Ndogo mno: ada ingechukua yote.';
    if (code.contains('INSUFFICIENT_BALANCE')) return en ? 'More than your available balance.' : 'Zaidi ya salio lako.';
    if (code.contains('INVALID_AMOUNT')) return en ? 'Enter a whole amount.' : 'Weka kiasi kamili.';
    return _httpErrorText(status, body);
  }

  // ---- Wallet: history -------------------------------------------------------
  // NOTE: this endpoint must exist on the backend (see WALLET_PAGES_FLOW.md):
  //   GET  /wallet/transactions  -> [{id, type, amount, status, title, reference, createdAt}]

  /// Wallet activity (top ups, withdrawals, sent / received, bookings). Null when unavailable.
  static Future<List<dynamic>?> fetchWalletTransactions() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/wallet/transactions'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data is List) return data;
        if (data is Map && data['transactions'] is List) return data['transactions'] as List;
      }
      return null;
    } catch (e) {
      _log('Wallet transactions error: $e');
      return null;
    }
  }

  /// Legacy NIDA-number-only request. Not used by any screen: Green now means full identity
  /// verification (ID + selfie upload, or a trusted invitation).
  static Future<Map<String, dynamic>?> applyGreenBadge({
    required String nidaNumber,
    String? officialFirstName,
    String? officialLastName,
  }) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/verification/green-badge'),
        headers: _getHeaders(),
        body: json.encode({
          'nidaNumber': nidaNumber.trim(),
          'officialFirstName': officialFirstName?.trim(),
          'officialLastName': officialLastName?.trim(),
        }),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body);
      }
      return null;
    } catch (e) {
      _log('Apply green badge error: $e');
      return null;
    }
  }

  /// Legacy request, not used by any screen. Blue is now Verified Business (see fetchVerifiedBusiness).
  static Future<Map<String, dynamic>?> applyBlueTick({
    String? nidaNumber,
    String? idPhotoUrl,
    String? selfieWithIdUrl,
    int? inviterUserId,
  }) async {
    try {
      final payload = <String, dynamic>{};
      if (nidaNumber != null) payload['nidaNumber'] = nidaNumber.trim();
      if (idPhotoUrl != null) payload['idPhotoUrl'] = idPhotoUrl;
      if (selfieWithIdUrl != null) payload['selfieWithIdUrl'] = selfieWithIdUrl;
      if (inviterUserId != null) payload['inviterUserId'] = inviterUserId;

      final response = await _Http.post(
        Uri.parse('$baseUrl/verification/blue-tick'),
        headers: _getHeaders(),
        body: json.encode(payload),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body);
      }
      return null;
    } catch (e) {
      _log('Apply blue tick error: $e');
      return null;
    }
  }

  // ---------------------------------------------------------------------------
  // Trusted invitations (a Green or Blue provider vouches for someone they know;
  // the invitee gets Green, identity only)
  // ---------------------------------------------------------------------------
  // Backend contract: docs/invitation_api_contract.md. The server decides who
  // may invite and who gets the tick; the app only shows the outcome.

  /// Worded, localized message for an invitation error code from the server.
  static String _inviteError(int status, dynamic body) {
    final isEn = AppStrings.isEnglish;
    var raw = '';
    if (body is Map) raw = (body['message'] ?? body['error'] ?? body['code'] ?? '').toString();
    final up = raw.toUpperCase();
    // Checked first: these also come with 403 / 404 and must not look like "only verified providers can invite".
    if (up.contains('INVITE_PHONE_MISMATCH')) {
      return isEn ? 'This invitation was sent to a different phone number.' : 'Mwaliko huu ulitumwa kwa namba nyingine ya simu.';
    }
    // The backend sends these with 429 / 503, so they must be checked before the generic answers below.
    if (up.contains('INVITE_LIMIT')) {
      return isEn ? 'You have reached your invitation limit for now.' : 'Umefikia kikomo cha mialiko kwa sasa.';
    }
    if (up.contains('INVITE_CODE_UNAVAILABLE')) {
      return isEn
          ? 'Could not create an invitation code right now. Please try again.'
          : 'Imeshindwa kutengeneza msimbo wa mwaliko sasa. Tafadhali jaribu tena.';
    }
    if (up.contains('TOO_MANY_ATTEMPTS') || status == 429) {
      return isEn ? 'Too many attempts. Please try again in an hour.' : 'Majaribio mengi sana. Tafadhali jaribu tena baada ya saa moja.';
    }
    if (up.contains('INVALID_PHONE')) {
      return isEn ? 'Enter a valid phone number with the country code.' : 'Weka namba sahihi ya simu pamoja na msimbo wa nchi.';
    }
    if (up.contains('REQUEST_NOT_FOUND')) {
      return isEn ? 'This request is no longer available.' : 'Ombi hili halipatikani tena.';
    }
    if (up.contains('INVITER_NOT_BLUE_TICK') || up.contains('INVITER_NOT_VERIFIED') || status == 403) {
      return isEn ? 'Only verified providers (Green Badge or Blue) can invite others.' : 'Ni watoa huduma waliothibitishwa (Green Badge au Blue) pekee wanaoweza kualika wengine.';
    }
    if (up.contains('ALREADY_INVITED')) {
      return isEn ? 'You already invited this number.' : 'Umeshamwalika namba hii.';
    }
    if (up.contains('ALREADY_VERIFIED')) {
      return isEn ? 'This person already has a verification badge.' : 'Mtu huyu tayari ana beji ya uthibitisho.';
    }
    if (up.contains('PROVIDER_NOT_VERIFIED')) {
      return isEn ? 'That person is not a verified provider yet.' : 'Mtu huyo bado si mtoa huduma aliyethibitishwa.';
    }
    if (up.contains('REQUEST_ALREADY_SENT')) {
      return isEn ? 'You already asked this person. Wait for their answer.' : 'Tayari umemwomba mtu huyu. Subiri jibu lake.';
    }
    if (up.contains('SELF_INVITE')) {
      return isEn ? 'You cannot invite yourself.' : 'Huwezi kujialika mwenyewe.';
    }
    if (up.contains('NAME_MISMATCH')) {
      return isEn
          ? 'The names do not match the name registered for this NIN. Type your names exactly as on your ID.'
          : 'Majina hayalingani na jina lililosajiliwa kwa NIN hii. Andika majina yako kama yalivyo kwenye kitambulisho.';
    }
    if (up.contains('NIN_NOT_FOUND')) {
      return isEn ? 'The NIN you saved was not found. Check it in Identity Verification.' : 'NIN uliyohifadhi haikupatikana. Iangalie kwenye Uthibitisho wa Utambulisho.';
    }
    if (up.contains('NAME_REQUIRED')) {
      return isEn ? 'Save your legal name and NIN in Identity Verification first.' : 'Hifadhi jina lako la kisheria na NIN kwenye Uthibitisho wa Utambulisho kwanza.';
    }
    if (up.contains('IDENTITY_SERVICE_UNAVAILABLE') || status == 503) {
      return isEn ? 'The ID check is not available right now. Please try again later.' : 'Uhakiki wa kitambulisho haupatikani sasa. Tafadhali jaribu tena baadaye.';
    }
    if (up.contains('INVALID_NIN')) {
      return isEn ? 'The NIN must be exactly 20 digits.' : 'NIN lazima iwe na tarakimu 20.';
    }
    if (up.contains('NIN_ALREADY_USED')) {
      return isEn ? 'This NIN is already used on another account.' : 'NIN hii tayari inatumika kwenye akaunti nyingine.';
    }
    if (up.contains('INVITE_PHONE_MISMATCH')) {
      return isEn ? 'This invitation was sent to a different phone number.' : 'Mwaliko huu ulitumwa kwa namba nyingine ya simu.';
    }
    if (up.contains('INVITE_INVALID') || up.contains('INVITE_EXPIRED') || up.contains('INVITE_NOT_FOUND') || status == 404) {
      return isEn ? 'This invitation code is not valid or has expired.' : 'Msimbo wa mwaliko si sahihi au umeisha muda.';
    }
    if (raw.isNotEmpty && !RegExp(r'^[A-Z_]+$').hasMatch(raw)) return raw;
    return isEn ? 'Something went wrong. Please try again.' : 'Kuna tatizo. Tafadhali jaribu tena.';
  }

  static Future<InviteResult> _inviteCall(Future<http.Response> Function() send, String tag) async {
    try {
      final response = await send().timeout(const Duration(seconds: 15));
      dynamic body;
      try {
        body = json.decode(response.body);
      } catch (caught, trace) { AppLog.e('api_service._inviteError', caught, trace); }
      if (response.statusCode >= 200 && response.statusCode < 300) {
        return InviteResult(data: body is Map ? Map<String, dynamic>.from(body) : const {});
      }
      return InviteResult(error: _inviteError(response.statusCode, body));
    } catch (e) {
      _log('$tag error: $e');
      return InviteResult(error: AppStrings.authNetworkError);
    }
  }

  /// A verified provider (Green or Blue) invites someone by phone. Returns {code, ...}.
  /// POST /verification/invitations  {inviteePhone}
  static Future<InviteResult> createInvitation({required String inviteePhone}) {
    return _inviteCall(
      () => _Http.post(
        Uri.parse('$baseUrl/verification/invitations'),
        headers: _getHeaders(),
        body: json.encode({'inviteePhone': inviteePhone.trim()}),
      ),
      'Create invitation',
    );
  }

  /// Invitations I sent (and received); each {code, status, direction, name?, phone?}.
  /// Returns null when the list could not be loaded.
  /// GET /verification/invitations
  static Future<List<dynamic>?> fetchInvitations() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/verification/invitations'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final d = json.decode(response.body);
        if (d is List) return d;
        if (d is Map && d['invitations'] is List) return d['invitations'] as List;
      }
      return null;
    } catch (e) {
      _log('Fetch invitations error: $e');
      return null;
    }
  }

  /// Invitations addressed to me that are still waiting: {code, inviterName?}.
  /// Empty when none or when the list could not be loaded.
  static Future<List<Map<String, dynamic>>> fetchPendingReceivedInvitations() async {
    final raw = await fetchInvitations();
    if (raw == null) return const [];
    return [
      for (final e in raw)
        if (e is Map &&
            e['direction']?.toString().toUpperCase() == 'RECEIVED' &&
            (e['status'] ?? 'PENDING').toString().toUpperCase() == 'PENDING')
          Map<String, dynamic>.from(e),
    ];
  }

  /// The invited person accepts with the code only: the NIN and legal name were saved in Identity Verification.
  /// On success the server grants the Green Badge (identity only) and records both people as
  /// knowing and trusting each other. POST /verification/invitations/accept
  /// The server checks the saved legal name against the name registered for the saved NIN.
  static Future<InviteResult> acceptInvitation({required String code}) async {
    final res = await _inviteCall(
      () => _Http.post(
        Uri.parse('$baseUrl/verification/invitations/accept'),
        headers: _getHeaders(),
        body: json.encode({'code': code.trim()}),
      ),
      'Accept invitation',
    );
    if (res.ok && SessionManager.getBadge() != 'BLUE_TICK') await SessionManager.saveBadge('GREEN_BADGE');
    return res;
  }

  /// Someone who is not verified yet asks a verified provider who knows them to vouch for them.
  /// POST /verification/invitation-requests  {providerPhone}
  static Future<InviteResult> requestVouch({required String providerPhone}) {
    return _inviteCall(
      () => _Http.post(
        Uri.parse('$baseUrl/verification/invitation-requests'),
        headers: _getHeaders(),
        body: json.encode({'providerPhone': providerPhone.trim()}),
      ),
      'Request vouch',
    );
  }

  /// Vouch requests I sent or received: {id, status: PENDING|APPROVED|DECLINED|EXPIRED,
  /// direction: SENT|RECEIVED, name?, phone?}. Null when the list could not be loaded.
  /// GET /verification/invitation-requests
  static Future<List<Map<String, dynamic>>?> fetchVouchRequests() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/verification/invitation-requests'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final d = json.decode(response.body);
        final list = d is List ? d : (d is Map && d['requests'] is List ? d['requests'] as List : null);
        if (list != null) return [for (final e in list) if (e is Map) Map<String, dynamic>.from(e)];
      }
      return null;
    } catch (e) {
      _log('Fetch vouch requests error: $e');
      return null;
    }
  }

  /// A verified provider answers a request. Approving makes the server create a normal invitation
  /// for the requester's phone (they accept it with one tap).
  /// POST /verification/invitation-requests/{id}/approve  or  /decline
  static Future<InviteResult> answerVouchRequest({required String id, required bool approve}) {
    return _inviteCall(
      () => _Http.post(
        Uri.parse('$baseUrl/verification/invitation-requests/${Uri.encodeComponent(id)}/${approve ? 'approve' : 'decline'}'),
        headers: _getHeaders(),
        body: json.encode({}),
      ),
      'Answer vouch request',
    );
  }

  /// Optional service fields; only sent when filled in.
  static Map<String, dynamic> _serviceExtras({
    String? area,
    int? serviceRadiusKm,
    String? priceType,
    String? serviceMode,
    int? durationMinutes,
    List<String> availableDays = const [],
    String? availableFrom,
    String? availableTo,
    String? instagramUsername,
    String? facebookUsername,
    String? tiktokUsername,
    String? xUsername,
    String? youtubeUsername,
    double? latitude, // exact pin of where the service is (optional)
    double? longitude,
    List<String> features = const [],
    List<Map<String, dynamic>> tasks = const [], // up to 3 tasks, each {name, price}
    String? featuredImageUrl,
    String? shortDescription,
    String? otherLanguage,
  }) {
    String? clean(String? v) {
      final t = v?.trim().replaceFirst(RegExp(r'^@'), '') ?? '';
      return t.isEmpty ? null : t;
    }

    final m = <String, dynamic>{};
    // Always sent (even empty) so clearing it on edit works.
    m['shortDescription'] = shortDescription?.trim() ?? '';
    // Search-only words in another language; always sent so clearing it on edit works.
    m['otherLanguage'] = otherLanguage?.trim() ?? '';
    final a = area?.trim() ?? '';
    if (a.isNotEmpty) m['area'] = a;
    if (serviceRadiusKm != null) m['serviceRadiusKm'] = serviceRadiusKm;
    if (priceType != null && priceType.isNotEmpty) m['priceType'] = priceType;
    if (serviceMode != null && serviceMode.isNotEmpty) m['serviceMode'] = serviceMode;
    // Always sent: a number = price per that duration, null = price only (also clears an old duration on edit).
    m['durationMinutes'] = (durationMinutes != null && durationMinutes > 0) ? durationMinutes : null;
    if (availableDays.isNotEmpty) m['availableDays'] = availableDays;
    if (availableFrom != null) m['availableFrom'] = availableFrom;
    if (availableTo != null) m['availableTo'] = availableTo;
    // Always sent (even empty) so removing every feature on edit clears them.
    m['features'] = features;
    // Always sent (even empty) so removing every task on edit clears them.
    m['tasks'] = tasks;
    if (featuredImageUrl != null && featuredImageUrl.isNotEmpty) m['featuredImageUrl'] = featuredImageUrl;
    if (latitude != null && longitude != null) {
      m['latitude'] = latitude;
      m['longitude'] = longitude;
    }
    final socials = {
      'instagramUsername': clean(instagramUsername),
      'facebookUsername': clean(facebookUsername),
      'tiktokUsername': clean(tiktokUsername),
      'xUsername': clean(xUsername),
      'youtubeUsername': clean(youtubeUsername),
    };
    // Always sent (empty clears the link on edit; the server stores an empty one as none).
    socials.forEach((k, v) {
      m[k] = v ?? '';
    });
    return m;
  }

  /// Create a new Service Post (Seller)
  static Future<Map<String, dynamic>?> createServicePost({
    required String title,
    required String description,
    required String category,
    required double price,
    String? city,
    String? phone,
    String? whatsappPhone,
    String? email,
    bool isInfoLocked = true,
    List<String> imageUrls = const [],
    List<String> videoUrls = const [],
    bool is18Plus = false,
    String? area,
    int? serviceRadiusKm,
    String? priceType,
    String? serviceMode,
    int? durationMinutes,
    List<String> availableDays = const [],
    String? availableFrom,
    String? availableTo,
    String? instagramUsername,
    String? facebookUsername,
    String? tiktokUsername,
    String? xUsername,
    String? youtubeUsername,
    double? latitude, // exact pin of where the service is (optional)
    double? longitude,
    List<String> features = const [],
    List<Map<String, dynamic>> tasks = const [], // up to 3 tasks, each {name, price}
    String? featuredImageUrl,
    String? shortDescription,
    String? otherLanguage,
    Map<String, dynamic> pricing = const {}, // discount + offer settings (see NEGOTIATION_FLOW.md)
  }) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/services'),
        headers: _getHeaders(),
        body: json.encode({
          'title': title.trim(),
          'description': description.trim(),
          'category': category.trim(),
          'price': price,
          'city': (city ?? '').trim().isEmpty ? null : city!.trim(),
          'phone': phone?.trim(),
          'whatsappPhone': whatsappPhone?.trim(),
          'email': email?.trim(),
          'isInfoLocked': isInfoLocked,
          'imageUrls': imageUrls,
          'videoUrls': videoUrls,
          'is18Plus': is18Plus,
          ..._serviceExtras(
            shortDescription: shortDescription,
            otherLanguage: otherLanguage,
            area: area,
            serviceRadiusKm: serviceRadiusKm,
            priceType: priceType,
            serviceMode: serviceMode,
            durationMinutes: durationMinutes,
            availableDays: availableDays,
            availableFrom: availableFrom,
            availableTo: availableTo,
            instagramUsername: instagramUsername,
            facebookUsername: facebookUsername,
            tiktokUsername: tiktokUsername,
            xUsername: xUsername,
            youtubeUsername: youtubeUsername,
            latitude: latitude,
            longitude: longitude,
            features: features,
            tasks: tasks,
            featuredImageUrl: featuredImageUrl,
          ),
          ...pricing,
        }),
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200 || response.statusCode == 201) {
        lastServiceError = null;
        return _decodeMap(response.body);
      }
      lastServiceStatus = response.statusCode;
      lastServiceNeedsRegistration = response.statusCode == 402 && response.body.contains('REGISTRATION_FEE_REQUIRED');
      lastServiceError = _httpErrorText(response.statusCode, response.body);
      _log('Create service failed: ${response.statusCode}');
      return null;
    } catch (e) {
      lastServiceError = _exceptionText(e);
      _log('Create service error: $e');
      return null;
    }
  }

  /// Update an existing Service Post (Seller) - used by the Edit Service page
  static Future<Map<String, dynamic>?> updateServicePost({
    required String id,
    required String title,
    required String description,
    required String category,
    required double price,
    String? city,
    String? phone,
    String? whatsappPhone,
    String? email,
    bool isInfoLocked = true,
    List<String> imageUrls = const [],
    List<String> videoUrls = const [],
    bool is18Plus = false,
    String? area,
    int? serviceRadiusKm,
    String? priceType,
    String? serviceMode,
    int? durationMinutes,
    List<String> availableDays = const [],
    String? availableFrom,
    String? availableTo,
    String? instagramUsername,
    String? facebookUsername,
    String? tiktokUsername,
    String? xUsername,
    String? youtubeUsername,
    double? latitude, // exact pin of where the service is (optional)
    double? longitude,
    List<String> features = const [],
    List<Map<String, dynamic>> tasks = const [], // up to 3 tasks, each {name, price}
    String? featuredImageUrl,
    String? shortDescription,
    String? otherLanguage,
    Map<String, dynamic> pricing = const {},
  }) async {
    try {
      final response = await _Http.put(
        Uri.parse('$baseUrl/services/$id'),
        headers: _getHeaders(),
        body: json.encode({
          'title': title.trim(),
          'description': description.trim(),
          'category': category.trim(),
          'price': price,
          'city': (city ?? '').trim().isEmpty ? null : city!.trim(),
          'phone': phone?.trim(),
          'whatsappPhone': whatsappPhone?.trim(),
          'email': email?.trim(),
          'isInfoLocked': isInfoLocked,
          'imageUrls': imageUrls,
          'videoUrls': videoUrls,
          'is18Plus': is18Plus,
          ..._serviceExtras(
            shortDescription: shortDescription,
            otherLanguage: otherLanguage,
            area: area,
            serviceRadiusKm: serviceRadiusKm,
            priceType: priceType,
            serviceMode: serviceMode,
            durationMinutes: durationMinutes,
            availableDays: availableDays,
            availableFrom: availableFrom,
            availableTo: availableTo,
            instagramUsername: instagramUsername,
            facebookUsername: facebookUsername,
            tiktokUsername: tiktokUsername,
            xUsername: xUsername,
            youtubeUsername: youtubeUsername,
            latitude: latitude,
            longitude: longitude,
            features: features,
            tasks: tasks,
            featuredImageUrl: featuredImageUrl,
          ),
          ...pricing,
        }),
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200 || response.statusCode == 201) {
        lastServiceError = null;
        return _decodeMap(response.body);
      }
      lastServiceStatus = response.statusCode;
      lastServiceError = _httpErrorText(response.statusCode, response.body);
      _log('Update service failed: ${response.statusCode}');
      return null;
    } catch (e) {
      lastServiceError = _exceptionText(e);
      _log('Update service error: $e');
      return null;
    }
  }

  /// Fetch Seller's published services
  /// Null when the server could not be reached or refused (so screens keep what they show).
  static Future<List<dynamic>?> fetchSellerServicesOrNull() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/services/seller/my-services'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body) as List;
      }
      return null;
    } catch (e) {
      _log('Fetch seller services error: $e');
      return null;
    }
  }

  static Future<List<dynamic>> fetchSellerServices() async => await fetchSellerServicesOrNull() ?? <dynamic>[];

  /// The signed-in provider's own services as [ServiceItem]s (same shape the lists use).
  /// Empty when offline or when they have none.
  static Future<List<ServiceItem>> fetchMyServiceItems() async {
    final raw = await fetchSellerServices();
    final out = <ServiceItem>[];
    for (final r in raw) {
      if (r is! Map) continue;
      try {
        final it = _mapJsonToServiceItem(Map<String, dynamic>.from(r));
        out.add(it);
        if (it.sellerId != null) knownServices[it.id] = it;
      } catch (e) {
        _log('Map own service error: $e');
      }
    }
    return out;
  }

  // ---- Card payments (hosted checkout) --------------------------------------
  // The app NEVER sees or stores card numbers: the backend creates a checkout
  // session with the payment gateway and the customer pays on the gateway's own
  // https page. NOTE: these two endpoints must exist on the backend:
  //   POST /payments/card/checkout        {amount, purpose, reference, description, phone?}
  //                                       -> {checkoutUrl, reference}
  //   GET  /payments/card/status/{ref}    -> {status: PAID | PENDING | FAILED | CANCELLED}
  static Future<Map<String, dynamic>?> createCardCheckout({
    required double amount,
    required String purpose, // e.g. PROVIDER_REGISTRATION, BOOKING
    required String reference,
    String? description,
    String? phone,
  }) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/payments/card/checkout'),
        headers: _getHeaders(),
        body: json.encode({
          'amount': amount,
          'purpose': purpose,
          'reference': reference,
          'description': description,
          'phone': phone,
          'gateway': AppPolicy.paymentGateway.id,
        }),
      ).timeout(const Duration(seconds: 15));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data is Map<String, dynamic> && (data['checkoutUrl'] ?? '').toString().isNotEmpty) {
          lastPaymentError = null;
          return data;
        }
      }
      // Keep the server's reason (e.g. CARD_PAYMENTS_DISABLED) so the screen can show it.
      lastPaymentError = _httpErrorText(response.statusCode, response.body);
      _log('Card checkout failed: ${response.statusCode}');
      return null;
    } catch (e) {
      lastPaymentError = _exceptionText(e);
      _log('Card checkout error: $e');
      return null;
    }
  }

  /// Returns PAID, PENDING, FAILED or CANCELLED (PENDING on any network problem).
  static Future<String> getCardPaymentStatus(String reference) async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/payments/card/status/${Uri.encodeComponent(reference)}'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return (data['status'] ?? 'PENDING').toString().toUpperCase();
      }
    } catch (e) {
      _log('Card status error: $e');
    }
    return 'PENDING';
  }

  // ---- Admin: payment gateway -------------------------------------------------
  // Backend (must exist, ROLE_ADMIN only, answer 403 to everyone else):
  //   GET /admin/payments/gateway -> {gateway: "SNIPPE", available: ["DPO","SNIPPE","CLICKPESA","SELCOM","PESAPAL"]}
  //   PUT /admin/payments/gateway {gateway: "SELCOM"} -> {gateway: "SELCOM"}
  // The value saved here is the one /app/policy then returns as payments.gateway.

  /// The gateway the admin has switched on. `forbidden` is true when the server says this
  /// account is not an admin; `gateway` is null when it could not be loaded.
  static Future<({PaymentGateway? gateway, bool forbidden, Set<PaymentGateway>? available})> getAdminPaymentGateway() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/admin/payments/gateway'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 401 || response.statusCode == 403) return (gateway: null, forbidden: true, available: null);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final d = data is Map && data['data'] is Map ? data['data'] as Map : data;
        if (d is Map) {
          // The server lists only the gateways it really has an implementation for; offer just those.
          Set<PaymentGateway>? available;
          final raw = d['available'];
          if (raw is List) {
            available = {for (final a in raw) if (PaymentGateway.tryParse(a) != null) PaymentGateway.tryParse(a)!};
          }
          return (gateway: PaymentGateway.tryParse(d['gateway']), forbidden: false, available: available);
        }
      }
    } catch (e) {
      _log('Admin gateway load error: ${e.runtimeType}');
    }
    return (gateway: null, forbidden: false, available: null);
  }

  /// Saves the active gateway. Returns the gateway the server now uses, or null on failure
  /// ([lastAdminError] says why).
  static String? lastAdminError;
  static Future<PaymentGateway?> setAdminPaymentGateway(PaymentGateway gateway) async {
    lastAdminError = null;
    try {
      final response = await _Http.put(
        Uri.parse('$baseUrl/admin/payments/gateway'),
        headers: _getHeaders(),
        body: json.encode({'gateway': gateway.id}),
      ).timeout(const Duration(seconds: 15));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final d = data is Map && data['data'] is Map ? data['data'] as Map : data;
        final saved = d is Map ? PaymentGateway.tryParse(d['gateway']) : null;
        return saved ?? gateway;
      }
      lastAdminError = (response.statusCode == 401 || response.statusCode == 403) ? 'forbidden' : 'failed';
    } catch (e) {
      _log('Admin gateway save error: ${e.runtimeType}');
      lastAdminError = 'network';
    }
    return null;
  }

  /// Card payments on/off (default OFF). GET/PUT /admin/payments/card {"enabled": bool}. Null = failed.
  static Future<bool?> getAdminCardEnabled() async {
    try {
      final r = await _Http.get(Uri.parse('$baseUrl/admin/payments/card'), headers: _getHeaders())
          .timeout(const Duration(seconds: 10));
      if (r.statusCode == 200) {
        final d = json.decode(r.body);
        if (d is Map && d['enabled'] is bool) return d['enabled'] as bool;
      }
    } catch (e) {
      _log('Admin card switch load error: ${e.runtimeType}');
    }
    return null;
  }

  static Future<bool?> setAdminCardEnabled(bool enabled) async {
    try {
      final r = await _Http.put(
        Uri.parse('$baseUrl/admin/payments/card'),
        headers: _getHeaders(),
        body: json.encode({'enabled': enabled}),
      ).timeout(const Duration(seconds: 15));
      if (r.statusCode == 200) {
        final d = json.decode(r.body);
        return d is Map && d['enabled'] is bool ? d['enabled'] as bool : enabled;
      }
    } catch (e) {
      _log('Admin card switch save error: ${e.runtimeType}');
    }
    return null;
  }

  // ---- Admin: SMS gateway (Meseji / Beem) -------------------------------------
  // Backend (must exist, ROLE_ADMIN only, answer 403 to everyone else). Secrets are
  // write-only: the server stores them (encrypted) and never returns them.
  //   GET  /admin/sms/config -> {defaultProvider:"MESEJI", meseji:{apiKeySet,passwordSet,senderId,email,costPerSms},
  //                              beem:{apiKeySet,secretSet,senderId,costPerSms}}
  //   PUT  /admin/sms/config {defaultProvider, meseji:{apiKey?,senderId,email,password?,costPerSms},
  //                           beem:{apiKey?,secretKey?,senderId,costPerSms}} -> same shape as GET
  //   POST /admin/sms/test-connection {provider} -> {success, message, balance?}
  //   POST /admin/sms/test-send {provider, phone} -> {success, message}
  // See docs/sms_gateway_api_contract.md.

  static Future<({SmsGatewayConfig? config, bool forbidden})> getAdminSmsConfig() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/admin/sms/config'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 401 || response.statusCode == 403) return (config: null, forbidden: true);
      if (response.statusCode == 200) {
        return (config: SmsGatewayConfig.tryParse(json.decode(response.body)), forbidden: false);
      }
    } catch (e) {
      _log('Admin SMS config load error: ${e.runtimeType}');
    }
    return (config: null, forbidden: false);
  }

  /// Saves the SMS settings. Returns what the server now has, or null on failure
  /// ([lastAdminError] says why). Never logs the request body (it holds secrets).
  static Future<SmsGatewayConfig?> setAdminSmsConfig(SmsGatewayUpdate update) async {
    lastAdminError = null;
    try {
      final response = await _Http.put(
        Uri.parse('$baseUrl/admin/sms/config'),
        headers: _getHeaders(),
        body: json.encode(update.toJson()),
      ).timeout(const Duration(seconds: 15));
      if (response.statusCode == 200) {
        return SmsGatewayConfig.tryParse(json.decode(response.body));
      }
      lastAdminError = (response.statusCode == 401 || response.statusCode == 403) ? 'forbidden' : 'failed';
    } catch (e) {
      _log('Admin SMS config save error: ${e.runtimeType}');
      lastAdminError = 'network';
    }
    return null;
  }

  // ---- Admin: ads (AdMob / Facebook / ironSource) ------------------------------
  // Backend (must exist, ROLE_ADMIN only, answer 403 to everyone else). Nothing here is secret
  // (ad unit IDs are inside every app), so the same shape is read and written.
  //   GET /admin/ads/config -> AdsConfig JSON (see docs/ads_config_api_contract.md)
  //   PUT /admin/ads/config  AdsConfig JSON -> AdsConfig JSON as saved
  // Users read the saved settings from the public GET /app/ads (AdsConfigService).

  static Future<({AdsConfig? config, bool forbidden})> getAdminAdsConfig() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/admin/ads/config'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 401 || response.statusCode == 403) return (config: null, forbidden: true);
      if (response.statusCode == 200) {
        return (config: AdsConfig.tryParse(json.decode(response.body)), forbidden: false);
      }
    } catch (e) {
      _log('Admin ads config load error: ${e.runtimeType}');
    }
    return (config: null, forbidden: false);
  }

  /// Saves the ad settings. Returns what the server now has, or null on failure
  /// ([lastAdminError] says why).
  static Future<AdsConfig?> setAdminAdsConfig(AdsConfig config) async {
    lastAdminError = null;
    try {
      final response = await _Http.put(
        Uri.parse('$baseUrl/admin/ads/config'),
        headers: _getHeaders(),
        body: json.encode(config.toJson()),
      ).timeout(const Duration(seconds: 15));
      if (response.statusCode == 200) {
        // Some servers answer 200 with an empty body: then what we sent is what is saved.
        if (response.body.trim().isEmpty) return config;
        return AdsConfig.tryParse(json.decode(response.body)) ?? config;
      }
      lastAdminError = (response.statusCode == 401 || response.statusCode == 403) ? 'forbidden' : 'failed';
    } catch (e) {
      _log('Admin ads config save error: ${e.runtimeType}');
      lastAdminError = 'network';
    }
    return null;
  }

  static Future<SmsTestResult> _adminSmsTest(String path, Map<String, dynamic> body) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/admin/sms/$path'),
        headers: _getHeaders(),
        body: json.encode(body),
      ).timeout(const Duration(seconds: 30));
      if (response.statusCode == 401 || response.statusCode == 403) return const SmsTestResult(false, 'forbidden');
      final data = json.decode(response.body);
      final d = data is Map && data['data'] is Map ? data['data'] as Map : data;
      if (d is Map) {
        return SmsTestResult(d['success'] == true && response.statusCode == 200, d['message']?.toString());
      }
    } catch (e) {
      _log('Admin SMS test error: ${e.runtimeType}');
      return const SmsTestResult(false, 'network');
    }
    return const SmsTestResult(false);
  }

  /// Logs in to the provider with the saved credentials and reads the balance (sends no SMS).
  static Future<SmsTestResult> adminSmsTestConnection(SmsProvider provider) =>
      _adminSmsTest('test-connection', {'provider': provider.id});

  /// Sends one real test SMS (uses 1 credit) with the saved credentials.
  static Future<SmsTestResult> adminSmsTestSend(SmsProvider provider, String phoneE164) =>
      _adminSmsTest('test-send', {'provider': provider.id, 'phone': phoneE164});

  // ---- Admin: ID name check login (BRELA) ---------------------------------------
  // Backend (must exist, ROLE_ADMIN only, answer 403 to everyone else). The password is
  // write-only: the server stores it encrypted and never returns it.
  //   GET  /admin/identity-lookup -> {username, passwordSet, source:"ADMIN"|"CONFIG"|"NONE", updatedAt}
  //   PUT  /admin/identity-lookup {username?, password?} -> same shape as GET (a missing field keeps the saved one)
  //   POST /admin/identity-lookup/test -> {success, message}   (logs in with the saved login, sends no NIN)
  // See docs/identity_lookup_admin_api_contract.md.

  static Future<({IdentityLookupConfig? config, bool forbidden})> getAdminIdentityLookup() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/admin/identity-lookup'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 401 || response.statusCode == 403) return (config: null, forbidden: true);
      if (response.statusCode == 200) {
        return (config: IdentityLookupConfig.tryParse(json.decode(response.body)), forbidden: false);
      }
    } catch (e) {
      _log('Admin identity lookup load error: ${e.runtimeType}');
    }
    return (config: null, forbidden: false);
  }

  /// Saves the login. Blank fields are left out so the server keeps the saved value.
  /// Returns what the server now has, or null ([lastAdminError] says why: forbidden, network, failed,
  /// or the server code USERNAME_INVALID / PASSWORD_INVALID / CREDENTIALS_INCOMPLETE / NO_CHANGES).
  /// Never logs the request body (it holds the password).
  static Future<IdentityLookupConfig?> setAdminIdentityLookup({String? username, String? password}) async {
    lastAdminError = null;
    final body = <String, dynamic>{};
    if (username != null && username.trim().isNotEmpty) body['username'] = username.trim();
    if (password != null && password.isNotEmpty) body['password'] = password;
    try {
      final response = await _Http.put(
        Uri.parse('$baseUrl/admin/identity-lookup'),
        headers: _getHeaders(),
        body: json.encode(body),
      ).timeout(const Duration(seconds: 15));
      if (response.statusCode == 200) {
        return IdentityLookupConfig.tryParse(json.decode(response.body));
      }
      if (response.statusCode == 401 || response.statusCode == 403) {
        lastAdminError = 'forbidden';
      } else {
        final code = (_decodeObj(response.body)?['message'] ?? '').toString().toUpperCase();
        lastAdminError = code.isEmpty ? 'failed' : code;
      }
    } catch (e) {
      _log('Admin identity lookup save error: ${e.runtimeType}');
      lastAdminError = 'network';
    }
    return null;
  }

  /// Logs in to the lookup service with the saved login (sends no NIN).
  static Future<IdentityLookupTestResult> adminIdentityLookupTest() async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/admin/identity-lookup/test'),
        headers: _getHeaders(),
        body: '{}',
      ).timeout(const Duration(seconds: 30));
      if (response.statusCode == 401 || response.statusCode == 403) return const IdentityLookupTestResult(false, 'forbidden');
      final data = json.decode(response.body);
      final d = data is Map && data['data'] is Map ? data['data'] as Map : data;
      if (d is Map) {
        return IdentityLookupTestResult(d['success'] == true && response.statusCode == 200, d['message']?.toString());
      }
    } catch (e) {
      _log('Admin identity lookup test error: ${e.runtimeType}');
      return const IdentityLookupTestResult(false, 'network');
    }
    return const IdentityLookupTestResult(false);
  }

  // ---- Admin: pending minutes of a sent code ----------------------------------------------------------
  // Backend (ROLE_ADMIN only, 403 to everyone else):
  //   GET /admin/otp-settings            -> {pendingMinutes: 4, min: 1, max: 10}
  //   PUT /admin/otp-settings {pendingMinutes: 6} -> same shape (400 INVALID_OTP_PENDING_MINUTES outside min..max)
  // The app reads the live value from GET /app/policy -> data.auth.otpPendingMinutes.

  static Future<({int? minutes, bool forbidden})> getAdminOtpPendingMinutes() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/admin/otp-settings'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 401 || response.statusCode == 403) return (minutes: null, forbidden: true);
      if (response.statusCode == 200) {
        final d = _decodeObj(response.body);
        final m = d?['pendingMinutes'];
        if (m is num) return (minutes: m.toInt(), forbidden: false);
      }
    } catch (e) {
      _log('Admin OTP settings load error: ${e.runtimeType}');
    }
    return (minutes: null, forbidden: false);
  }

  /// Saves the minutes. Returns what the server now uses, or null ([lastAdminError] says why).
  static Future<int?> setAdminOtpPendingMinutes(int minutes) async {
    lastAdminError = null;
    try {
      final response = await _Http.put(
        Uri.parse('$baseUrl/admin/otp-settings'),
        headers: _getHeaders(),
        body: json.encode({'pendingMinutes': minutes}),
      ).timeout(const Duration(seconds: 15));
      if (response.statusCode == 200) {
        final m = _decodeObj(response.body)?['pendingMinutes'];
        return m is num ? m.toInt() : minutes;
      }
      lastAdminError = (response.statusCode == 401 || response.statusCode == 403) ? 'forbidden' : 'failed';
    } catch (e) {
      _log('Admin OTP settings save error: ${e.runtimeType}');
      lastAdminError = 'network';
    }
    return null;
  }

  // ---- Admin: promo push (boosted services pushed to users) --------------------------------------------
  // Backend (ROLE_ADMIN only, 403 to everyone else), see PROMO_PUSH.md:
  //   GET /admin/promo-push -> {enabled: true, intervalHours: 6, min: 1, max: 72}
  //   PUT /admin/promo-push {enabled?, intervalHours?} -> same shape (400 INVALID_PROMO_PUSH_INTERVAL outside min..max)

  static Future<({bool? enabled, int? hours, int min, int max, bool forbidden})> getAdminPromoPush() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/admin/promo-push'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 401 || response.statusCode == 403) {
        return (enabled: null, hours: null, min: 1, max: 72, forbidden: true);
      }
      if (response.statusCode == 200) {
        final d = _decodeObj(response.body);
        final e = d?['enabled'];
        final h = d?['intervalHours'];
        if (e is bool && h is num) {
          return (
            enabled: e,
            hours: h.toInt(),
            min: (d?['min'] as num?)?.toInt() ?? 1,
            max: (d?['max'] as num?)?.toInt() ?? 72,
            forbidden: false,
          );
        }
      }
    } catch (e) {
      _log('Admin promo push load error: ${e.runtimeType}');
    }
    return (enabled: null, hours: null, min: 1, max: 72, forbidden: false);
  }

  /// Saves the switch and/or the hours. Returns true when the server accepted it ([lastAdminError] says why not).
  static Future<bool> setAdminPromoPush({bool? enabled, int? hours}) async {
    lastAdminError = null;
    try {
      final response = await _Http.put(
        Uri.parse('$baseUrl/admin/promo-push'),
        headers: _getHeaders(),
        body: json.encode({
          if (enabled != null) 'enabled': enabled,
          if (hours != null) 'intervalHours': hours,
        }),
      ).timeout(const Duration(seconds: 15));
      if (response.statusCode == 200) return true;
      lastAdminError = (response.statusCode == 401 || response.statusCode == 403) ? 'forbidden' : 'failed';
    } catch (e) {
      _log('Admin promo push save error: ${e.runtimeType}');
      lastAdminError = 'network';
    }
    return false;
  }

  // ---- Admin: provider fees ---------------------------------------------------
  // Backend (must exist, ROLE_ADMIN only, answer 403 to everyone else):
  //   GET /admin/payments/provider-fees -> {collectionPercent: 3, vatPercent: 18, payoutFee: 1500, withdrawMin: 1000, withdrawMax: 5000000}
  //   PUT /admin/payments/provider-fees {collectionPercent, vatPercent, payoutFee, withdrawMin, withdrawMax} -> same shape
  // Two charges taken only when the provider withdraws: collectionPercent on its own, plus vatPercent (payout fee inside it). See PROVIDER_FEES_FLOW.md.

  static Future<({ProviderFees? fees, bool forbidden})> getAdminProviderFees() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/admin/payments/provider-fees'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 401 || response.statusCode == 403) return (fees: null, forbidden: true);
      if (response.statusCode == 200) {
        final body = json.decode(response.body);
        final d = body is Map && body['data'] is Map ? body['data'] : body;
        return (fees: ProviderFees.tryParse(d) ?? const ProviderFees(), forbidden: false);
      }
    } catch (e) {
      _log('Admin provider fees load error: ${e.runtimeType}');
    }
    return (fees: null, forbidden: false);
  }

  /// Saves the fees. Returns what the server now uses, or null ([lastAdminError] says why).
  static Future<ProviderFees?> setAdminProviderFees(ProviderFees fees) async {
    lastAdminError = null;
    try {
      final response = await _Http.put(
        Uri.parse('$baseUrl/admin/payments/provider-fees'),
        headers: _getHeaders(),
        body: json.encode(fees.toJson()),
      ).timeout(const Duration(seconds: 15));
      if (response.statusCode == 200) {
        final body = json.decode(response.body);
        final d = body is Map && body['data'] is Map ? body['data'] : body;
        return ProviderFees.tryParse(d) ?? fees;
      }
      lastAdminError = (response.statusCode == 401 || response.statusCode == 403) ? 'forbidden' : 'failed';
    } catch (e) {
      _log('Admin provider fees save error: ${e.runtimeType}');
      lastAdminError = 'network';
    }
    return null;
  }

  // ---- Admin: platform wallet (display; withdrawing is the call below) -------------------------------------
  // Backend (must exist, ROLE_ADMIN only, answer 403 to everyone else):
  //   GET /admin/wallet               -> {balance, held, totalIn, totalOut,
  //                                       income: {registrationFees, serviceFees, boosts, commissions,
  //                                                withdrawalFees, collectionFees, vat}}
  //   GET /admin/wallet/transactions?limit=50
  //                                   -> [{id, type, amount, direction: IN|OUT, title, status, reference, createdAt}]
  // These two calls only DISPLAY numbers. Money moves only through POST /admin/wallet/withdraw.

  /// Platform wallet summary. `forbidden` = the server says this account is not an admin.
  static Future<({Map<String, dynamic>? data, bool forbidden})> getAdminWallet() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/admin/wallet'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 401 || response.statusCode == 403) return (data: null, forbidden: true);
      if (response.statusCode == 200) {
        final body = json.decode(response.body);
        final d = body is Map && body['data'] is Map ? body['data'] : body;
        if (d is Map) return (data: Map<String, dynamic>.from(d), forbidden: false);
      }
    } catch (e) {
      _log('Admin wallet load error: ${e.runtimeType}');
    }
    return (data: null, forbidden: false);
  }

  /// Latest platform wallet activity (newest first). Empty list on any problem.
  static Future<List<Map<String, dynamic>>> getAdminWalletTransactions({int limit = 50}) async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/admin/wallet/transactions?limit=${limit.clamp(1, 200)}'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final body = json.decode(response.body);
        final list = body is Map && body['data'] is List ? body['data'] : body;
        if (list is List) {
          return [for (final e in list) if (e is Map) Map<String, dynamic>.from(e)];
        }
      }
    } catch (e) {
      _log('Admin wallet transactions error: ${e.runtimeType}');
    }
    return [];
  }

  // ---- Admin: withdraw from the platform wallet -------------------------------
  // Backend (ROLE_ADMIN only, 403 to everyone else):
  //   POST /admin/wallet/withdraw {amount, phone}
  //     -> {fee, netAmount, reference, balance}   (fee = the flat payout fee ONLY)
  // The server takes the payout fee from its own current setting (never from the request),
  // debits `amount` from the platform wallet and sends `amount - fee` to the phone.
  // See ADMIN_WITHDRAWAL_FLOW.md. `error` is 'forbidden' | 'invalid' | 'failed' | 'network'.

  static Future<({Map<String, dynamic>? data, String? error})> adminWithdrawWallet(double amount, String phone) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/admin/wallet/withdraw'),
        headers: _getHeaders(),
        body: json.encode({'amount': amount, 'phone': phone}),
      ).timeout(const Duration(seconds: 15));
      if (response.statusCode == 401 || response.statusCode == 403) return (data: null, error: 'forbidden');
      if (response.statusCode == 400 || response.statusCode == 422) return (data: null, error: 'invalid');
      if (response.statusCode == 200 || response.statusCode == 201) {
        final body = json.decode(response.body);
        final d = body is Map && body['data'] is Map ? body['data'] : body;
        return (data: d is Map ? Map<String, dynamic>.from(d) : <String, dynamic>{}, error: null);
      }
      return (data: null, error: 'failed');
    } catch (e) {
      _log('Admin withdraw error: ${e.runtimeType}');
      return (data: null, error: 'network');
    }
  }

  /// Create an Escrow booking transaction (lock funds)
  static Future<Map<String, dynamic>?> createEscrow({
    required int sellerId,
    int? serviceId,
    required double amount,
    required String paymentMethod, // 'POCKET_FUND', 'DIRECT' or 'OFFLINE'
    String? notes,
    String? directChannel, // mobile_money | card (when paymentMethod is DIRECT)
    String? offlineChannel, // cash | transfer (when paymentMethod is OFFLINE)
    String? offerId, // an AGREED offer: the server then takes the price from the offer
    String? paymentPreference, // 'HELD' (kept in escrow until the buyer is satisfied) or 'DIRECT' (released to the provider on payment)
    DateTime? scheduledAt, // the date and time the customer picked (sent as local time, no zone)
    String? customerAddress, // where the provider should come (provider-travels bookings)
    double? buyerLatitude, // the customer's GPS position when sending (safety record)
    double? buyerLongitude,
    double? buyerAccuracyMeters,
    List<int> taskIndexes = const [], // positions of the service's tasks the customer picked (the server works out the price)
    List<String> photoUrls = const [], // photos the customer attached (up to 5)
    bool asap = false, // "as soon as possible": no fixed date and time
  }) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/escrow/create'),
        headers: _getHeaders(),
        body: json.encode({
          'sellerId': sellerId,
          'serviceId': serviceId,
          'amount': amount,
          'paymentMethod': paymentMethod,
          'notes': notes,
          if (directChannel != null) 'directChannel': directChannel,
          if (offlineChannel != null) 'offlineChannel': offlineChannel,
          if (offerId != null && offerId.isNotEmpty) 'offerId': offerId,
          if (paymentPreference != null) 'paymentPreference': paymentPreference,
          if (customerAddress != null && customerAddress.trim().isNotEmpty) 'customerAddress': customerAddress.trim(),
          if (buyerLatitude != null && buyerLongitude != null) ...{
            'buyerLatitude': buyerLatitude,
            'buyerLongitude': buyerLongitude,
            if (buyerAccuracyMeters != null) 'buyerAccuracyMeters': buyerAccuracyMeters,
          },
          if (taskIndexes.isNotEmpty) 'taskIndexes': taskIndexes,
          if (photoUrls.isNotEmpty) 'photoUrls': photoUrls,
          if (asap) 'asap': true,
          if (!asap && scheduledAt != null) 'scheduledAt': scheduledAt.toIso8601String().split('.').first,
        }),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        lastPaymentError = null;
        return json.decode(response.body);
      } else {
        // Keep the server's reason (e.g. insufficient Pocket Fund balance) for the UI.
        lastPaymentError = _httpErrorText(response.statusCode, response.body);
        _log('Failed to create escrow: ${response.statusCode}');
        return null;
      }
    } catch (e) {
      lastPaymentError = _exceptionText(e);
      _log('Create escrow error: $e');
      return null;
    }
  }

  /// Why the last offer call failed (shown to the user), or null after a success.
  static String? lastOfferError;

  /// Buyer proposes their own price for a service.
  /// Backend: POST /offers {serviceId, sellerId, amount, listedPrice, message}
  /// The reply is the offer: {id, status: OFFERED | AGREED (seller's auto-accept price), agreedAmount,
  /// expiresAt ...}. An offer below the seller's private minimum fails with a message
  /// (the minimum itself is never sent to the app).
  static Future<Map<String, dynamic>?> makeOffer({
    int? serviceId,
    int? sellerId,
    required double amount,
    required double listedPrice,
    String? message,
  }) =>
      _offerCall(
        '/offers',
        {
          'serviceId': serviceId,
          'sellerId': sellerId,
          'amount': amount,
          'listedPrice': listedPrice,
          if (message != null && message.isNotEmpty) 'message': message,
        },
      );

  /// Seller accepts the buyer's price -> AGREED.   POST /offers/{id}/accept
  static Future<Map<String, dynamic>?> acceptOffer(String id) => _offerCall('/offers/${Uri.encodeComponent(id)}/accept');

  /// Seller turns the offer down.                  POST /offers/{id}/reject {reason}
  static Future<Map<String, dynamic>?> rejectOffer(String id, {String? reason}) => _offerCall(
        '/offers/${Uri.encodeComponent(id)}/reject',
        {if (reason != null && reason.trim().isNotEmpty) 'reason': reason.trim()},
      );

  /// Buyer takes the offer back.                   POST /offers/{id}/withdraw
  static Future<Map<String, dynamic>?> withdrawOffer(String id) => _offerCall('/offers/${Uri.encodeComponent(id)}/withdraw');

  static Future<Map<String, dynamic>?> _offerCall(String path, [Map<String, dynamic>? body]) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl$path'),
        headers: _getHeaders(),
        body: json.encode(body ?? const <String, dynamic>{}),
      ).timeout(const Duration(seconds: 12));
      if (response.statusCode == 200 || response.statusCode == 201 || response.statusCode == 204) {
        lastOfferError = null;
        if (response.body.isEmpty) return <String, dynamic>{};
        return _decodeMap(response.body);
      }
      lastOfferError = _httpErrorText(response.statusCode, response.body);
      _log('Offer call $path failed: ${response.statusCode}');
      return null;
    } catch (e) {
      lastOfferError = _exceptionText(e);
      _log('Offer call $path error: $e');
      return null;
    }
  }

  /// Offers the signed-in user sent as a buyer.      GET /offers/mine
  static Future<List<dynamic>> fetchMyOffers() => _offerList('/offers/mine');

  /// Offers buyers sent on the signed-in seller's services.   GET /offers/incoming
  static Future<List<dynamic>> fetchIncomingOffers() => _offerList('/offers/incoming');

  static Future<List<dynamic>?> _offerListOrNull(String path) async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl$path'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final d = json.decode(response.body);
        if (d is List) return d;
        if (d is Map && d['content'] is List) return d['content'] as List;
      }
      return null;
    } catch (e) {
      _log('Fetch offers $path error: $e');
      return null;
    }
  }

  static Future<List<dynamic>> _offerList(String path) async => await _offerListOrNull(path) ?? <dynamic>[];

  /// Null when the offers could not be loaded.
  static Future<List<dynamic>?> fetchMyOffersOrNull() => _offerListOrNull('/offers/mine');
  static Future<List<dynamic>?> fetchIncomingOffersOrNull() => _offerListOrNull('/offers/incoming');

  /// Seller accepts a booking request (unlocks contact details)
  static Future<Map<String, dynamic>?> acceptEscrowRequest(String transactionRef) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/escrow/accept/$transactionRef'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body);
      }
      return null;
    } catch (e) {
      _log('Accept escrow error: $e');
      return null;
    }
  }

  /// Seller rejects a booking request (refunds Buyer)
  static Future<Map<String, dynamic>?> rejectEscrowRequest(String transactionRef) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/escrow/reject/$transactionRef'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body);
      }
      return null;
    } catch (e) {
      _log('Reject escrow error: $e');
      return null;
    }
  }

  /// Cancel a booking / request (buyer, or provider after accepting).
  /// Backend: POST /escrow/cancel/{transactionRef}  {reason}
  static Future<Map<String, dynamic>?> cancelEscrowRequest(String transactionRef, {String? reason}) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/escrow/cancel/$transactionRef'),
        headers: _getHeaders(),
        body: json.encode({if (reason != null && reason.isNotEmpty) 'reason': reason}),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200 || response.statusCode == 201 || response.statusCode == 204) {
        if (response.body.isEmpty) return <String, dynamic>{};
        final d = json.decode(response.body);
        return d is Map<String, dynamic> ? d : <String, dynamic>{};
      }
      _log('Cancel escrow failed: ${response.statusCode}');
      return null;
    } catch (e) {
      _log('Cancel escrow error: $e');
      return null;
    }
  }

  // ---- Pay-first / offline payment flow (Remitano-style) ---------------------
  // NOTE: these endpoints must exist on the backend. Statuses they move a booking through:
  //   PENDING_ACCEPTANCE -> AWAITING_PAYMENT   POST /escrow/request-payment/{ref}
  //                           {mode: ONLINE|OFFLINE, instructions, deadlineMinutes}
  //   AWAITING_PAYMENT   -> PAYMENT_SENT       POST /escrow/mark-paid/{ref}   {reference, note, proofUrl?}
  //   PAYMENT_SENT       -> ACCEPTED           POST /escrow/confirm-payment/{ref}   (provider)
  //   PAYMENT_SENT       -> PAYMENT_DISPUTED   POST /escrow/payment-not-received/{ref} {reason}
  //   AWAITING_PAYMENT   -> ACCEPTED           POST /escrow/pay/{ref} {paymentMethod}  (online, paid in app)
  // The server must only unlock contacts / accept once payment is confirmed, and must only let
  // the provider confirm (never the buyer). The booking JSON should carry paymentMode,
  // paymentInstructions, paymentDeadline (ISO-8601), paymentReference, paymentNote, paymentProofUrl, paymentStatus.

  /// Last error text from a pay-first call (null after a success).
  static String? lastPaymentError;

  static Future<Map<String, dynamic>?> _escrowAction(String path, [Map<String, dynamic>? body]) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl$path'),
        headers: _getHeaders(),
        body: json.encode(body ?? const <String, dynamic>{}),
      ).timeout(const Duration(seconds: 15));
      if (response.statusCode == 200 || response.statusCode == 201 || response.statusCode == 204) {
        lastPaymentError = null;
        if (response.body.isEmpty) return <String, dynamic>{};
        final d = json.decode(response.body);
        return d is Map<String, dynamic> ? d : <String, dynamic>{};
      }
      lastPaymentError = _httpErrorText(response.statusCode, response.body);
      _log('Escrow action $path failed: ${response.statusCode}');
      return null;
    } catch (e) {
      lastPaymentError = _exceptionText(e);
      _log('Escrow action $path error: $e');
      return null;
    }
  }

  /// Provider asks the buyer to pay before the booking is accepted.
  static Future<Map<String, dynamic>?> requestPayment(
    String transactionRef, {
    required String mode, // 'ONLINE' (pay in the app) or 'OFFLINE' (pay the provider directly)
    String? instructions,
    int? deadlineMinutes,
  }) =>
      _escrowAction('/escrow/request-payment/${Uri.encodeComponent(transactionRef)}', {
        'mode': mode,
        if (instructions != null && instructions.trim().isNotEmpty) 'instructions': instructions.trim(),
        if (deadlineMinutes != null) 'deadlineMinutes': deadlineMinutes,
      });

  /// Buyer tells the provider they have paid offline ("I have paid").
  static Future<Map<String, dynamic>?> markPaymentSent(
    String transactionRef, {
    String? reference,
    String? note,
    String? proofUrl,
  }) =>
      _escrowAction('/escrow/mark-paid/${Uri.encodeComponent(transactionRef)}', {
        if (reference != null && reference.trim().isNotEmpty) 'reference': reference.trim(),
        if (note != null && note.trim().isNotEmpty) 'note': note.trim(),
        if (proofUrl != null && proofUrl.trim().isNotEmpty) 'proofUrl': proofUrl.trim(),
      });

  /// Upload the buyer's payment screenshot/receipt (optional). The returned URL is then
  /// sent as `proofUrl` in [markPaymentSent].
  /// Backend (must exist): POST /escrow/payment-proof  (field "file")  ->  {"url": "https://..."}
  /// Only the buyer of a booking may upload; the file is shown to that booking's provider only.
  static Future<UploadResult> uploadPaymentProof(String filePath) => _uploadMedia(
        endpoint: '/escrow/payment-proof',
        filePath: filePath,
        timeout: const Duration(seconds: 60),
        urlKeys: const ['url', 'imageUrl', 'path', 'location'],
        imageOnly: true,
      );

  /// Provider confirms the money arrived; the booking becomes ACCEPTED.
  static Future<Map<String, dynamic>?> confirmPaymentReceived(String transactionRef) =>
      _escrowAction('/escrow/confirm-payment/${Uri.encodeComponent(transactionRef)}');

  /// Provider says the money did not arrive.
  static Future<Map<String, dynamic>?> reportPaymentNotReceived(String transactionRef, {String? reason}) =>
      _escrowAction('/escrow/payment-not-received/${Uri.encodeComponent(transactionRef)}', {
        if (reason != null && reason.trim().isNotEmpty) 'reason': reason.trim(),
      });

  /// Buyer pays an existing booking online (Pocket Fund). Mobile money and card go through
  /// [requestMobilePayment] / the card checkout against the booking reference instead.
  static Future<Map<String, dynamic>?> payEscrow(String transactionRef, {required String paymentMethod}) =>
      _escrowAction('/escrow/pay/${Uri.encodeComponent(transactionRef)}', {'paymentMethod': paymentMethod});

  /// Buyer marks satisfied / releases funds to Seller
  /// Goes through [_escrowAction] so a failure sets [lastPaymentError] for the UI.
  static Future<Map<String, dynamic>?> releaseEscrowFunds(String transactionRef) =>
      _escrowAction('/escrow/release/${Uri.encodeComponent(transactionRef)}');

  /// Fetch Buyer's booking transactions
  /// Null when the server could not be reached or refused (so screens keep what they show).
  static Future<List<dynamic>?> fetchBuyerTransactionsOrNull() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/escrow/buyer/my-transactions'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body) as List;
      }
      return null;
    } catch (e) {
      _log('Fetch buyer transactions error: $e');
      return null;
    }
  }

  static Future<List<dynamic>> fetchBuyerTransactions() async => await fetchBuyerTransactionsOrNull() ?? <dynamic>[];

  /// Fetch Seller's incoming orders
  /// Null when the server could not be reached or refused (so screens keep what they show).
  static Future<List<dynamic>?> fetchSellerOrdersOrNull() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/escrow/seller/my-orders'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        return json.decode(response.body) as List;
      }
      return null;
    } catch (e) {
      _log('Fetch seller orders error: $e');
      return null;
    }
  }

  static Future<List<dynamic>> fetchSellerOrders() async => await fetchSellerOrdersOrNull() ?? <dynamic>[];

  // ---------------------------------------------------------------------------
  // Provider one-time registration fee
  // ---------------------------------------------------------------------------
  // NOTE: these endpoints must exist on the backend:
  //   GET  /payments/registration-fee   -> {paid: bool, amount: number}
  //   POST /payments/mobile/request     {amount, purpose, reference, phone}
  //                                     -> {reference}   (sends a payment prompt to the phone)
  //   GET  /payments/status/{ref}       -> {status: PAID | PENDING | FAILED | CANCELLED}

  /// Server view of the provider's registration fee. Null when it can't be loaded.
  static Future<Map<String, dynamic>?> getRegistrationFeeStatus() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/payments/registration-fee'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data is Map<String, dynamic>) return data;
      }
      return null;
    } catch (e) {
      _log('Registration fee status error: $e');
      return null;
    }
  }

  /// Server view of the per-service fee. The registration fee covers `freeLimit` services;
  /// each one after that needs one paid fee (a credit). Null when it can't be loaded.
  /// Backend (must exist): GET /payments/service-fee
  ///   -> {freeLimit: 2, used: <services posted>, credits: <paid fees not yet used>, amount: <TSh>, needsPayment: bool}
  /// The server must also refuse POST /services (HTTP 402) when needsPayment is true, and spend one
  /// credit when a service is created. See SERVICE_FEE_FLOW.md.
  static Future<Map<String, dynamic>?> getServiceFeeStatus() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/payments/service-fee'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data is Map<String, dynamic>) return data;
      }
      return null;
    } catch (e) {
      _log('Service fee status error: $e');
      return null;
    }
  }

  /// Sends a mobile-money payment prompt to [phone]. Returns {reference} or null.
  static Future<Map<String, dynamic>?> requestMobilePayment({
    required double amount,
    required String purpose,
    required String reference,
    required String phone,
  }) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/payments/mobile/request'),
        headers: _getHeaders(),
        body: json.encode({
          'amount': amount,
          'purpose': purpose,
          'reference': reference,
          'phone': phone,
          'gateway': AppPolicy.paymentGateway.id,
        }),
      ).timeout(const Duration(seconds: 15));
      if (response.statusCode == 200 || response.statusCode == 201) {
        final data = json.decode(response.body);
        if (data is Map<String, dynamic>) {
          lastPaymentError = null;
          return data;
        }
      }
      // Keep the server's reason (TOPUP_BELOW_MIN, INVALID_PHONE, ...) so the screen can show it.
      lastPaymentError = _httpErrorText(response.statusCode, response.body);
      _log('Mobile payment request failed: ${response.statusCode}');
      return null;
    } catch (e) {
      lastPaymentError = _exceptionText(e);
      _log('Mobile payment request error: $e');
      return null;
    }
  }

  /// PAID, PENDING, FAILED or CANCELLED (PENDING on any network problem).
  static Future<String> getPaymentStatus(String reference) async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/payments/status/${Uri.encodeComponent(reference)}'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return (data['status'] ?? 'PENDING').toString().toUpperCase();
      }
    } catch (e) {
      _log('Payment status error: $e');
    }
    return 'PENDING';
  }

  // ---------------------------------------------------------------------------
  // Service boost (provider pays to rank a service higher)
  // ---------------------------------------------------------------------------
  // NOTE: these endpoints must exist on the backend (see BOOST_FLOW.md):
  //   GET  /boosts/plans              -> [{id, days, price}]
  //   POST /boosts/activate           {serviceId, planId, days, paymentMethod, reference?}
  //                                   -> {boostedUntil, ...}   (idempotent per reference)
  // Mobile money / card are paid first through the normal payment endpoints with
  // purpose SERVICE_BOOST, then /boosts/activate is called with that reference.

  /// Boost packages from the server, or null when they cannot be loaded.
  static Future<List<BoostPlan>?> fetchBoostPlans() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/boosts/plans'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final raw = data is List ? data : (data is Map ? (data['plans'] ?? data['content']) : null);
        if (raw is List) {
          final plans = raw.map(BoostPlan.tryParse).whereType<BoostPlan>().toList()
            ..sort((a, b) => a.days.compareTo(b.days));
          if (plans.isNotEmpty) return plans;
        }
      }
      return null;
    } catch (e) {
      _log('Boost plans error: $e');
      return null;
    }
  }

  /// Why the last [activateBoost] failed (shown to the user), or null.
  static String? lastBoostError;

  /// Starts (or extends) the boost once the payment is done. [paymentMethod] is
  /// MOBILE_MONEY, CARD or POCKET_FUND; [reference] is the payment reference for
  /// mobile money / card. Returns the server's JSON (with `boostedUntil`) or null.
  static Future<Map<String, dynamic>?> activateBoost({
    required String serviceId,
    required BoostPlan plan,
    required String paymentMethod,
    String? reference,
  }) async {
    lastBoostError = null;
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/boosts/activate'),
        headers: _getHeaders(),
        body: json.encode({
          'serviceId': int.tryParse(serviceId) ?? serviceId,
          'planId': plan.id,
          'days': plan.days,
          'paymentMethod': paymentMethod,
          if (reference != null) 'reference': reference,
        }),
      ).timeout(const Duration(seconds: 15));
      if (response.statusCode == 200 || response.statusCode == 201) {
        final data = json.decode(response.body);
        return data is Map<String, dynamic> ? data : <String, dynamic>{};
      }
      try {
        final body = json.decode(response.body);
        if (body is Map) lastBoostError = (body['message'] ?? body['error'])?.toString();
      } catch (caught, trace) { AppLog.e('api_service.fetchBoostPlans', caught, trace); }
      _log('Activate boost failed: ${response.statusCode}');
      return null;
    } catch (e) {
      lastBoostError = _exceptionText(e);
      _log('Activate boost error: $e');
      return null;
    }
  }

  // ---------------------------------------------------------------------------
  // Verification documents (provider)
  // ---------------------------------------------------------------------------

  /// Documents the provider already uploaded, each {type, status, reason?}.
  /// Returns null when the list could not be loaded.
  static Future<List<dynamic>?> fetchVerificationDocuments() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/verification/documents'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) return json.decode(response.body) as List;
      return null;
    } catch (e) {
      _log('Fetch documents error: $e');
      return null;
    }
  }

  /// Why the last create/update service call failed (shown to the user), or null.
  static String? lastServiceError;
  /// HTTP status of the last create / update service call (402 = a service fee is due).
  static int? lastServiceStatus;
  /// True when the last create answered 402 REGISTRATION_FEE_REQUIRED (the one-time registration fee is unpaid).
  static bool lastServiceNeedsRegistration = false;

  static String get _origin => ClientSecurityConfig.origin;

  /// A 200/201 with an empty or non-object body still counts as success.
  static Map<String, dynamic> _decodeMap(String body) {
    try {
      final d = json.decode(body);
      if (d is Map<String, dynamic>) return d;
      if (d is Map) return Map<String, dynamic>.from(d);
    } catch (caught, trace) { AppLog.e('api_service.fetchVerificationDocuments', caught, trace); }
    return <String, dynamic>{'success': true};
  }

  /// Makes a server-relative path ("/uploads/a.jpg") a full URL so it can be shown.
  /// Full URLs and bundled assets are returned unchanged.
  static String absoluteUrl(String raw) {
    final u = raw.trim();
    // Cleartext traffic is blocked in the app, so use https for our own server.
    if (u.startsWith('http://${ClientSecurityConfig.host}')) return 'https://${u.substring(7)}';
    if (u.isEmpty || u.startsWith('http://') || u.startsWith('https://') || u.startsWith('assets/')) return u;
    if (u.startsWith('//')) return 'https:$u';
    if (u.startsWith('/')) return '$_origin$u';
    if (u.contains('/')) return '$_origin/$u';
    return u;
  }

  /// Human readable text for a failed HTTP response.
  static String _httpErrorText(int status, String body) {
    final en = AppStrings.isEnglish;
    String? serverMsg;
    try {
      final d = json.decode(body);
      if (d is Map) serverMsg = (d['message'] ?? d['error'] ?? d['detail'])?.toString().trim();
    } catch (caught, trace) { AppLog.e('api_service._httpErrorText', caught, trace); }
    // A code the backend sent on purpose (SERVICE_NOT_FOUND, NOT_YOUR_BOOKING, ...) gets its own sentence,
    // instead of the generic 403 / 404 text below.
    if (status != 401 && status < 500) {
      final known = ErrorMessages.lookup(serverMsg);
      if (known != null) return known;
    }
    switch (status) {
      case 401:
        return en ? 'Your session expired. Please log in again.' : 'Muda wa kuingia umeisha. Tafadhali ingia tena.';
      case 403:
        return en
            ? 'Not allowed. Make sure you are registered as a Seller.'
            : 'Hairuhusiwi. Hakikisha umesajiliwa kama Muuzaji.';
      case 404:
        return en ? 'This feature is not available on the server yet (404).' : 'Huduma hii bado haipo kwenye seva (404).';
      case 413:
        return en
            ? 'The file is too large for the server. Try a smaller file.'
            : 'Faili ni kubwa mno kwa seva. Jaribu faili ndogo zaidi.';
      case 415:
        return en ? 'The server does not accept this file type.' : 'Seva haikubali aina hii ya faili.';
    }
    if (status >= 500) {
      return en ? 'Server error ($status). Please try again later.' : 'Hitilafu ya seva ($status). Jaribu tena baadaye.';
    }
    if (serverMsg != null && serverMsg.isNotEmpty) return normalizeError(serverMsg);
    return en ? 'Request failed ($status).' : 'Ombi limeshindwa ($status).';
  }

  static String _exceptionText(Object e) {
    final en = AppStrings.isEnglish;
    if (e is TimeoutException) {
      return en ? 'The connection timed out. Check your internet and try again.' : 'Muda umeisha. Angalia mtandao kisha jaribu tena.';
    }
    final t = e.toString();
    if (t.contains('SocketException') || t.contains('ClientException') || t.contains('Failed host lookup')) {
      return en ? 'No internet connection.' : 'Hakuna mtandao.';
    }
    return en ? 'Something went wrong. Please try again.' : 'Kuna hitilafu. Tafadhali jaribu tena.';
  }

  /// Pulls the file URL out of whatever the upload endpoint answers with.
  static String? _extractUrl(String body, List<String> keys) {
    String? fromMap(Map m) {
      for (final k in keys) {
        final v = m[k]?.toString().trim() ?? '';
        if (v.isNotEmpty && v != 'null') return v;
      }
      return null;
    }

    try {
      final d = json.decode(body);
      if (d is Map) {
        final direct = fromMap(d);
        if (direct != null) return direct;
        final nested = d['data'] ?? d['file'] ?? d['result'];
        if (nested is Map) return fromMap(nested);
        if (nested is String && nested.trim().isNotEmpty) return nested.trim();
      } else if (d is List && d.isNotEmpty) {
        final f = d.first;
        if (f is Map) return fromMap(f);
        if (f is String && f.trim().isNotEmpty) return f.trim();
      } else if (d is String && d.trim().isNotEmpty) {
        return d.trim();
      }
    } catch (caught, trace) {
      AppLog.e('api_service.fromMap', caught, trace);
      final t = body.trim();
      if (t.startsWith('http') || t.startsWith('/')) return t;
    }
    return null;
  }

  /// The single multipart upload path used by every screen (service photos and
  /// videos, verification documents, profile photo, chat images). Adds auth,
  /// timeout, 401 sign-out and one set of readable error messages.
  static Future<UploadResult> _uploadMedia({
    required String endpoint,
    required String filePath,
    required Duration timeout,
    List<String> urlKeys = const ['url', 'path', 'location'],
    Map<String, String> fields = const {},
    bool requireUrl = true,
    bool bumpOnSuccess = false,
    bool imageOnly = false,
    void Function(double progress)? onProgress,
  }) async {
    try {
      final request = onProgress == null
          ? http.MultipartRequest('POST', Uri.parse('$baseUrl$endpoint'))
          : _ProgressMultipartRequest('POST', Uri.parse('$baseUrl$endpoint'), onProgress);
      final token = SessionManager.getToken();
      if (token != null && token.isNotEmpty) request.headers['Authorization'] = 'Bearer $token';
      request.headers['Accept'] = 'application/json';
      request.headers['X-Country'] = CurrencyService.current.iso;
      request.headers['X-Currency'] = CurrencyService.code;
      request.fields.addAll(fields);
      final part = await http.MultipartFile.fromPath('file', filePath);
      if (imageOnly) {
        // Fail fast on the device: wrong file type or too big (saves data and gives a clear reason).
        final ext = filePath.toLowerCase().split('.').last;
        const okExt = {'jpg', 'jpeg', 'png', 'webp', 'heic', 'heif'};
        if (!okExt.contains(ext)) {
          return UploadResult(
            error: AppStrings.isEnglish
                ? 'Only photos (JPG, PNG, WEBP) are allowed.'
                : 'Picha pekee (JPG, PNG, WEBP) ndizo zinaruhusiwa.',
          );
        }
        if (part.length <= 0) {
          return UploadResult(error: AppStrings.isEnglish ? 'The photo is empty. Pick another one.' : 'Picha haina kitu. Chagua nyingine.');
        }
        if (part.length > 10 * 1024 * 1024) {
          return UploadResult(
            error: AppStrings.isEnglish ? 'The photo is too large (max 10 MB).' : 'Picha ni kubwa mno (juu MB 10).',
          );
        }
      }
      request.files.add(part);
      final streamed = await SecureHttp.client.send(request).timeout(timeout);
      final response = await http.Response.fromStream(streamed);
      if (response.statusCode == 401) unawaited(_Http._confirmSessionDead(_getHeaders()));
      if (response.statusCode == 200 || response.statusCode == 201) {
        if (bumpOnSuccess) DataSync.bump();
        final url = _extractUrl(response.body, urlKeys);
        if (url != null) return UploadResult(url: absoluteUrl(url));
        if (!requireUrl) return const UploadResult();
        return UploadResult(
          error: AppStrings.isEnglish
              ? 'Uploaded, but the server did not return a file link.'
              : 'Imepakiwa, lakini seva haikurudisha kiungo cha faili.',
        );
      }
      _log('Upload $endpoint failed: ${response.statusCode}');
      return UploadResult(
        error: _httpErrorText(response.statusCode, response.body),
        retryable: response.statusCode >= 500 || response.statusCode == 408 || response.statusCode == 429,
      );
    } catch (e) {
      _log('Upload $endpoint error: $e');
      return UploadResult(error: _exceptionText(e), retryable: _isNetworkError(e));
    }
  }

  /// Upload one service photo (multipart).
  /// Backend: POST /services/images  (field "file")  ->  {"url": "https://..."}
  static Future<UploadResult> uploadServiceImage(String filePath) => _uploadMedia(
        endpoint: '/services/images',
        filePath: filePath,
        timeout: const Duration(seconds: 90),
        urlKeys: const ['url', 'imageUrl', 'path', 'location'],
      );

  /// Upload one service video (multipart).
  /// Backend: POST /services/videos  (field "file")  ->  {"url": "https://..."}
  static Future<UploadResult> uploadServiceVideo(String filePath) => _uploadMedia(
        endpoint: '/services/videos',
        filePath: filePath,
        timeout: const Duration(minutes: 5),
        urlKeys: const ['url', 'videoUrl', 'path', 'location'],
      );

  // ---- Provider portfolio (separate from service media) -------------------------------------
  // Backend: GET /portfolio/user/{id}, POST /portfolio/images|videos (file, caption), PUT /portfolio/{id}, DELETE /portfolio/{id}

  /// A provider's portfolio, newest first. Null when the server could not be reached.
  static Future<List<PortfolioItem>?> fetchPortfolio(int userId) async {
    try {
      final r = await _Http.get(Uri.parse('$baseUrl/portfolio/user/$userId'), headers: _getHeaders())
          .timeout(const Duration(seconds: 15));
      if (r.statusCode != 200) return null;
      final d = json.decode(r.body);
      if (d is! List) return null;
      return [
        for (final e in d)
          if (e is Map) PortfolioItem.fromJson(Map<String, dynamic>.from(e), fixUrl: absoluteUrl),
      ];
    } catch (e) {
      _log('Fetch portfolio error: ${e.runtimeType}');
      return null;
    }
  }

  /// Add one photo or video to the signed-in provider's portfolio.
  static Future<UploadResult> uploadPortfolioItem(
    String filePath, {
    required bool video,
    String? caption,
    void Function(double progress)? onProgress,
  }) =>
      _uploadMedia(
        endpoint: video ? '/portfolio/videos' : '/portfolio/images',
        filePath: filePath,
        timeout: video ? const Duration(minutes: 5) : const Duration(seconds: 90),
        imageOnly: !video,
        fields: {if (caption != null && caption.trim().isNotEmpty) 'caption': caption.trim()},
        onProgress: onProgress,
      );

  static Future<bool> deletePortfolioItem(int id) async {
    try {
      final r = await _Http.delete(Uri.parse('$baseUrl/portfolio/$id'), headers: _getHeaders())
          .timeout(const Duration(seconds: 15));
      return r.statusCode == 200 || r.statusCode == 204;
    } catch (e) {
      _log('Delete portfolio item error: ${e.runtimeType}');
      return false;
    }
  }

  /// Upload one verification document image (multipart).
  /// Backend: POST /verification/documents  (fields "type" + "file", and
  /// "idKind" - nida | voter | driving_licence | passport - for id_front / id_back).
  static Future<UploadResult> uploadVerificationDocument({
    required String type,
    required String filePath,
    String? idKind,
    Map<String, String> extraFields = const {},
  }) =>
      _uploadMedia(
        endpoint: '/verification/documents',
        filePath: filePath,
        timeout: const Duration(seconds: 60),
        fields: {'type': type, if (idKind != null) 'idKind': idKind, ...extraFields},
        requireUrl: false,
        bumpOnSuccess: true,
        imageOnly: true,
      );

  /// Upload the signed-in user's profile photo and remember its URL.
  /// Backend (must exist): POST /users/me/avatar  (field "file")  ->  {"url": "https://..."}
  /// The server is expected to save the photo on the user and return it as
  /// "avatarUrl" from /auth/login and in seller JSON.
  static Future<UploadResult> uploadAvatar(String filePath) async {
    final res = await _uploadMedia(
      endpoint: '/users/me/avatar',
      filePath: filePath,
      timeout: const Duration(seconds: 60),
      urlKeys: const ['avatarUrl', 'url', 'profileImage', 'imageUrl', 'path', 'location'],
      bumpOnSuccess: true,
      imageOnly: true,
    );
    if (res.url != null) await SessionManager.saveAvatarUrl(res.url!);
    return res;
  }

  /// Upload the provider's cover photo (the wide picture on top of their public profile).
  /// Backend (must exist): POST /users/me/cover  (field "file")  ->  {"url": "https://..."}
  /// The server saves it on the user and returns it as "coverUrl" in seller JSON.
  static Future<UploadResult> uploadCover(String filePath) async {
    final res = await _uploadMedia(
      endpoint: '/users/me/cover',
      filePath: filePath,
      timeout: const Duration(seconds: 60),
      urlKeys: const ['coverUrl', 'url', 'coverImage', 'imageUrl', 'path', 'location'],
      bumpOnSuccess: true,
      imageOnly: true,
    );
    if (res.url != null) await SessionManager.saveCoverUrl(res.url!);
    return res;
  }

  /// Remove the cover photo. Backend (must exist): DELETE /users/me/cover
  static Future<bool> removeCover() async {
    try {
      final r = await _Http.delete(Uri.parse('$baseUrl/users/me/cover'), headers: _getHeaders())
          .timeout(const Duration(seconds: 15));
      final ok = r.statusCode == 200 || r.statusCode == 204;
      if (ok) {
        await SessionManager.saveCoverUrl('');
        DataSync.bump(); // like an upload: every screen showing the photo re-reads it
      }
      return ok;
    } catch (e) {
      _log('Remove cover error: $e');
      return false;
    }
  }

  /// Send a live face photo to be verified.
  /// Backend (must exist): POST /users/me/verified-photo  (field "file")
  ///   -> {"status": "PENDING"|"VERIFIED"|"REJECTED", "url": "https://..."}
  /// See docs/verified_photo_api_contract.md. The server (never the app) decides the status.
  static Future<UploadResult> uploadVerifiedPhoto(String filePath) async {
    final res = await _uploadMedia(
      endpoint: '/users/me/verified-photo',
      filePath: filePath,
      timeout: const Duration(seconds: 60),
      urlKeys: const ['url', 'photoUrl', 'verifiedPhotoUrl'],
      requireUrl: false,
      imageOnly: true,
    );
    if (res.ok) await fetchVerifiedPhoto();
    return res;
  }

  /// Read the verified-photo status. Backend (must exist): GET /users/me/verified-photo
  ///   -> {"status": "NONE"|"PENDING"|"VERIFIED"|"REJECTED", "url": "...", "reason": "..."}
  /// Returns the status, or null when it could not be read (the cached copy stays).
  static Future<({String status, String? url, String? reason})?> fetchVerifiedPhoto() async {
    if (!SessionManager.isLoggedIn()) return null;
    try {
      final r = await _Http.get(Uri.parse('$baseUrl/users/me/verified-photo'), headers: _getHeaders())
          .timeout(const Duration(seconds: 15));
      if (r.statusCode < 200 || r.statusCode >= 300) return null;
      final data = _decodeObj(r.body);
      if (data == null) return null;
      final status = (data['status'] ?? 'NONE').toString().toUpperCase();
      final raw = (data['url'] ?? data['photoUrl'])?.toString().trim() ?? '';
      final url = raw.isEmpty || raw == 'null' ? null : absoluteUrl(raw);
      // Only a VERIFIED photo is kept as the photo providers will see.
      await SessionManager.saveVerifiedPhoto(url: url, status: status);
      final reason = data['reason']?.toString().trim();
      return (status: status, url: url, reason: (reason == null || reason.isEmpty) ? null : reason);
    } catch (e) {
      _log('Fetch verified photo error: $e');
      return null;
    }
  }

  /// Read the name the server verified from the user's ID documents.
  /// Backend (must exist): GET /users/me/verified-name
  ///   -> {"status": "NONE"|"PENDING"|"VERIFIED"|"REJECTED", "name": "...", "reason": "..."}
  /// The user types it in Identity Verification (submitFullName); the server verifies it against the ID.
  static Future<({String status, String? name, String? reason})?> fetchVerifiedName() async {
    if (!SessionManager.isLoggedIn()) return null;
    try {
      final r = await _Http.get(Uri.parse('$baseUrl/users/me/verified-name'), headers: _getHeaders())
          .timeout(const Duration(seconds: 15));
      if (r.statusCode < 200 || r.statusCode >= 300) return null;
      final data = _decodeObj(r.body);
      if (data == null) return null;
      final status = (data['status'] ?? 'NONE').toString().toUpperCase();
      final rawName = data['name']?.toString().trim() ?? '';
      final name = rawName.isEmpty || rawName == 'null' ? null : rawName;
      await SessionManager.saveVerifiedName(name: name, status: status);
      final reason = data['reason']?.toString().trim();
      return (status: status, name: name, reason: (reason == null || reason.isEmpty) ? null : reason);
    } catch (e) {
      _log('Fetch legal name error: $e');
      return null;
    }
  }

  /// The user types their legal name exactly as on their ID (Identity Verification screen).
  /// Backend (must exist): POST /users/me/verified-name  {"fullName": "..."} -> 2xx, or {"message": "<CODE>"}.
  /// With a NIN, the server looks up the name registered for it: if the typed name matches, the status is
  /// VERIFIED right away (the app re-reads it after saving); NAME_MISMATCH / NIN_NOT_FOUND are returned as
  /// errors and nothing is saved. Without a match source (service down) it stays PENDING for the ID check.
  /// This is only a claim: the server compares it with the registry / approved ID and sets the
  /// verified-name status. The app never shows the typed name as verified by itself.
  /// Returns null on success, else a readable error.
  static Future<String?> submitFullName(String fullName, {String? nin}) async {
    final en = AppStrings.isEnglish;
    try {
      final r = await _Http.post(
        Uri.parse('$baseUrl/users/me/verified-name'),
        headers: _getHeaders(),
        body: json.encode({'fullName': fullName.trim(), if (nin != null && nin.isNotEmpty) 'nidaNumber': nin.trim()}),
      ).timeout(const Duration(seconds: 15));
      if (r.statusCode >= 200 && r.statusCode < 300) {
        await SessionManager.saveIdFullName(fullName.trim());
        if (nin != null && nin.isNotEmpty) await SessionManager.saveNinSaved(true);
        await fetchVerifiedName();
        return null;
      }
      final msg = (_decodeObj(r.body)?['message'] ?? '').toString().toUpperCase();
      if (msg.contains('ALREADY_VERIFIED')) {
        return en ? 'Your name is already verified and cannot be changed here.' : 'Jina lako tayari limethibitishwa na haliwezi kubadilishwa hapa.';
      }
      if (msg.contains('INVALID_NIN')) {
        return en ? 'The NIN must be exactly 20 digits.' : 'NIN lazima iwe na tarakimu 20.';
      }
      if (msg.contains('NIN_ALREADY_USED')) {
        return en ? 'This NIN is already used on another account.' : 'NIN hii tayari inatumika kwenye akaunti nyingine.';
      }
      if (msg.contains('NAME_INVALID')) {
        return en ? 'Enter your legal name using letters only.' : 'Weka jina lako la kisheria kwa herufi tu.';
      }
      // The server checked the NIN against the official record and the names did not match.
      if (msg.contains('NAME_MISMATCH')) {
        return en
            ? 'The name does not match the name registered for this NIN. Type your names exactly as on your ID.'
            : 'Jina halilingani na jina lililosajiliwa kwa NIN hii. Andika majina yako kama yalivyo kwenye kitambulisho.';
      }
      if (msg.contains('TOO_MANY_ATTEMPTS')) {
        return en ? 'Too many attempts. Please try again in an hour.' : 'Majaribio mengi sana. Tafadhali jaribu tena baada ya saa moja.';
      }
      if (msg.contains('IDENTITY_SERVICE_UNAVAILABLE') || r.statusCode == 503) {
        return en
            ? 'The ID check service is not available right now. Nothing was saved. Please try again later.'
            : 'Huduma ya kuhakiki kitambulisho haipatikani sasa hivi. Hakuna kilichohifadhiwa. Tafadhali jaribu tena baadaye.';
      }
      if (msg.contains('NIN_NOT_FOUND')) {
        return en ? 'This NIN was not found. Check the 20 digits and try again.' : 'NIN hii haikupatikana. Angalia tarakimu 20 na ujaribu tena.';
      }
      return en ? 'Could not save your name. Try again.' : 'Imeshindwa kuhifadhi jina lako. Jaribu tena.';
    } catch (e) {
      _log('Submit legal name error: $e');
      return AppStrings.authNetworkError;
    }
  }

  /// Provider's Verified Business application.
  /// Backend (must exist): GET /verification/business
  ///   -> {"status": "NONE"|"PENDING"|"VERIFIED"|"REJECTED"|"EXPIRED", "businessName": "...",
  ///       "reason": "...", "expiresAt": "2027-01-31"}
  /// Needs a Green Badge first (server refuses otherwise). When it is VERIFIED the provider gets the Blue badge. Documents go through POST /verification/documents.
  static Future<({String status, String? name, String? reason, DateTime? expiresAt})?> fetchVerifiedBusiness() async {
    if (!SessionManager.isLoggedIn()) return null;
    try {
      final r = await _Http.get(Uri.parse('$baseUrl/verification/business'), headers: _getHeaders())
          .timeout(const Duration(seconds: 15));
      if (r.statusCode < 200 || r.statusCode >= 300) return null;
      final data = _decodeObj(r.body);
      if (data == null) return null;
      final status = (data['status'] ?? 'NONE').toString().toUpperCase();
      String? clean(dynamic v) {
        final t = v?.toString().trim() ?? '';
        return (t.isEmpty || t == 'null') ? null : t;
      }
      await SessionManager.saveVerifiedBusinessStatus(status);
      // Blue = Verified Business on top of a verified identity.
      if (status == 'VERIFIED') {
        await SessionManager.saveBadge('BLUE_TICK');
      } else if (SessionManager.getBadge() == 'BLUE_TICK') {
        await SessionManager.saveBadge('GREEN_BADGE');
      }
      return (
        status: status,
        name: clean(data['businessName']),
        reason: clean(data['reason']),
        expiresAt: DateTime.tryParse(clean(data['expiresAt']) ?? ''),
      );
    } catch (e) {
      _log('Fetch verified business error: $e');
      return null;
    }
  }

  /// Save the business name for the application. Backend (must exist):
  /// POST /verification/business  {"businessName": "..."}  -> 2xx, or {"message": "<CODE>"} on error.
  static Future<String?> saveBusinessName(String name) async {
    try {
      final r = await _Http.post(
        Uri.parse('$baseUrl/verification/business'),
        headers: _getHeaders(),
        body: json.encode({'businessName': name.trim()}),
      ).timeout(const Duration(seconds: 15));
      if (r.statusCode >= 200 && r.statusCode < 300) return null;
      final msg = _decodeObj(r.body)?['message']?.toString() ?? '';
      if (msg.contains('IDENTITY_REQUIRED') || r.statusCode == 403) {
        return AppStrings.isEnglish ? 'Verify your identity first (Green Badge).' : 'Thibitisha utambulisho wako kwanza (Green Badge).';
      }
      final known = ErrorMessages.lookup(msg); // BUSINESS_NAME_INVALID, ALREADY_VERIFIED, ...
      if (known != null) return known;
      return AppStrings.isEnglish ? 'Could not save the business name.' : 'Imeshindwa kuhifadhi jina la biashara.';
    } catch (e) {
      _log('Save business name error: $e');
      return AppStrings.isEnglish ? 'Check your connection and try again.' : 'Angalia mtandao kisha jaribu tena.';
    }
  }

  /// Remove the signed-in user's profile photo. Backend (must exist): DELETE /users/me/avatar
  static Future<bool> removeAvatar() async {
    try {
      final r = await _Http.delete(Uri.parse('$baseUrl/users/me/avatar'), headers: _getHeaders())
          .timeout(const Duration(seconds: 15));
      final ok = r.statusCode == 200 || r.statusCode == 204;
      if (ok) {
        await SessionManager.saveAvatarUrl('');
        DataSync.bump(); // like an upload: every screen showing the photo re-reads it
      }
      return ok;
    } catch (e) {
      _log('Remove avatar error: $e');
      return false;
    }
  }

  /// Why the account cannot be deleted right now (WALLET_NOT_EMPTY, OPEN_BOOKINGS, PAYMENT_PENDING, ADMIN_ACCOUNT),
  /// or null when it can. Backend: GET /users/me/delete-check. On a failed call it answers null: the real
  /// DELETE below still checks everything on the server.
  static Future<String?> accountDeleteBlocker() async {
    try {
      final r = await _Http.get(Uri.parse('$baseUrl/users/me/delete-check'), headers: _getHeaders())
          .timeout(const Duration(seconds: 15));
      if (r.statusCode != 200) return null;
      final d = json.decode(r.body);
      if (d is Map && d['canDelete'] == false) return d['reason']?.toString();
    } catch (e) {
      _log('Delete check error: $e');
    }
    return null;
  }

  /// Deletes the signed-in account for good (Google Play / App Store requirement). Backend: DELETE /users/me
  /// with {"password"}. Returns null when it worked (the local session is cleared), else a readable error.
  static Future<String?> deleteAccount(String password) async {
    final en = AppStrings.isEnglish;
    try {
      final r = await _Http.delete(
        Uri.parse('$baseUrl/users/me'),
        headers: _getHeaders(),
        body: json.encode({'password': password}),
      ).timeout(const Duration(seconds: 30));
      if (r.statusCode == 200 || r.statusCode == 204) {
        await SessionManager.clearSession();
        return null;
      }
      if (r.statusCode == 429) {
        return en ? 'Too many tries. Please wait a few minutes.' : 'Majaribio mengi mno. Subiri dakika chache.';
      }
      return _httpErrorText(r.statusCode, r.body);
    } catch (e) {
      _log('Delete account error: $e');
      return en ? 'Check your connection and try again.' : 'Angalia mtandao kisha jaribu tena.';
    }
  }

  /// A failure caused by the connection (weak signal, timeout, dropped line), not by the request itself.
  static bool _isNetworkError(Object e) =>
      e is TimeoutException || e is SocketException || e is HandshakeException || e is http.ClientException;

  /// Upload one chat picture. The returned URL is then sent as the message
  /// text (the same way call links are), so /chats/send does not change.
  /// Backend (must exist): POST /chats/images  (field "file")  ->  {"url": "https://..."}
  static Future<UploadResult> uploadChatImage(String filePath, {void Function(double progress)? onProgress}) => _uploadMedia(
        endpoint: '/chats/images',
        filePath: filePath,
        onProgress: onProgress,
        timeout: const Duration(seconds: 90),
        urlKeys: const ['url', 'imageUrl', 'path', 'location'],
      );

  /// Upload one chat voice note (.m4a) or document (pdf, docx, xlsx, ...).
  /// Like pictures, the returned URL is then sent as the message text.
  /// Backend (must exist): POST /chats/files  (field "file")  ->  {"url": "https://..."}
  static Future<UploadResult> uploadChatFile(String filePath, {void Function(double progress)? onProgress}) => _uploadMedia(
        endpoint: '/chats/files',
        filePath: filePath,
        onProgress: onProgress,
        timeout: const Duration(minutes: 2),
        urlKeys: const ['url', 'fileUrl', 'audioUrl', 'path', 'location'],
      );

  static const List<String> _audioExt = ['m4a', 'aac', 'mp3', 'wav', 'ogg', 'opus', 'amr'];

  /// Document types allowed in chat (also used by the file picker).
  static const List<String> chatFileExtensions = [
    'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'csv', 'rtf', 'odt', 'ods', 'zip',
  ];

  /// Small extras kept after the "#" of an attachment link: k = kind (a/f),
  /// name = original file name, d = voice length in seconds.
  static Map<String, String> _chatMeta(String text) {
    final i = text.indexOf('#');
    if (i < 0) return const {};
    try {
      return Uri.splitQueryString(text.substring(i + 1).trim());
    } catch (caught, trace) {
      AppLog.e('api_service.deleteAccount', caught, trace);
      return const {};
    }
  }

  static String _extOf(String path) {
    final seg = path.split('/').last;
    final dot = seg.lastIndexOf('.');
    return dot < 0 ? '' : seg.substring(dot + 1).toLowerCase();
  }

  /// What kind of attachment [text] is, or null for a normal text message.
  /// Only links to our own server count, so nobody can use a message to make
  /// the other person's phone load a file from somewhere else.
  static ChatAttachmentKind? chatAttachmentKind(String text) {
    final t = text.trim();
    if (t.isEmpty || t.contains(RegExp(r'\s'))) return null;
    final uri = Uri.tryParse(absoluteUrl(t));
    if (uri == null || !uri.isAbsolute || uri.host != Uri.parse(_origin).host) return null;
    final k = _chatMeta(t)['k'];
    if (k == 'a') return ChatAttachmentKind.audio;
    if (k == 'f') return ChatAttachmentKind.file;
    final ext = _extOf(uri.path);
    if (_audioExt.contains(ext)) return ChatAttachmentKind.audio;
    if (chatFileExtensions.contains(ext)) return ChatAttachmentKind.file;
    if (uri.path.startsWith('/uploads/') ||
        RegExp(r'\.(jpe?g|png|webp|gif|heic)$', caseSensitive: false).hasMatch(uri.path)) {
      return ChatAttachmentKind.image;
    }
    return null;
  }

  /// True when [text] is a link to a picture hosted on our own server.
  static bool isOwnImageUrl(String text) => chatAttachmentKind(text) == ChatAttachmentKind.image;

  /// Message text for an uploaded voice note / document.
  static String chatAttachmentLink(
    String url, {
    required ChatAttachmentKind kind,
    String? name,
    int? seconds,
  }) {
    final parts = <String>[
      if (kind == ChatAttachmentKind.audio) 'k=a',
      if (kind == ChatAttachmentKind.file) 'k=f',
      if (name != null && name.trim().isNotEmpty) 'name=${Uri.encodeQueryComponent(name.trim())}',
      if (seconds != null && seconds > 0) 'd=$seconds',
    ];
    final base = url.split('#').first;
    return parts.isEmpty ? base : '$base#${parts.join('&')}';
  }

  /// The plain, absolute file link of an attachment message (no extras).
  static String chatAttachmentUrl(String text) => absoluteUrl(text.trim().split('#').first);

  /// Original file name of a document message (falls back to the link's name).
  static String? chatAttachmentName(String text) {
    final n = _chatMeta(text.trim())['name']?.trim();
    if (n != null && n.isNotEmpty) return n;
    final segs = Uri.tryParse(chatAttachmentUrl(text))?.pathSegments ?? const <String>[];
    return (segs.isEmpty || segs.last.isEmpty) ? null : segs.last;
  }

  /// Length in seconds of a voice note message, when the sender included it.
  static int? chatAudioSeconds(String text) => int.tryParse(_chatMeta(text.trim())['d'] ?? '');

  /// Short text for lists (chat list, notifications): attachments show a label
  /// instead of their link.
  static String chatPreview(String text) {
    final en = AppStrings.isEnglish;
    switch (chatAttachmentKind(text)) {
      case ChatAttachmentKind.image:
        return en ? '📷 Photo' : '📷 Picha';
      case ChatAttachmentKind.audio:
        return en ? '🎤 Voice message' : '🎤 Ujumbe wa sauti';
      case ChatAttachmentKind.file:
        return '📎 ${chatAttachmentName(text) ?? (en ? 'Document' : 'Faili')}';
      case null:
        return text;
    }
  }

  // ---------------------------------------------------------------------------
  // Reviews
  // ---------------------------------------------------------------------------

  /// Reviews customers left for the signed-in provider.
  /// Null when the server could not be reached or refused (so screens keep what they show).
  static Future<List<dynamic>?> fetchReviewsReceivedOrNull() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/reviews/received'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) return json.decode(response.body) as List;
      return null;
    } catch (e) {
      _log('Fetch received reviews error: $e');
      return null;
    }
  }

  static Future<List<dynamic>> fetchReviewsReceived() async => await fetchReviewsReceivedOrNull() ?? <dynamic>[];

  /// Public reviews customers left for one provider. Backend: GET /users/{id}/reviews
  /// (a plain list, or {content: [...]}). Null when it can't be loaded.
  static Future<List<dynamic>?> fetchProviderReviews(int sellerId) async {
    try {
      final r = await _Http.get(Uri.parse('$baseUrl/users/$sellerId/reviews'), headers: _getHeaders())
          .timeout(const Duration(seconds: 12));
      if (r.statusCode == 200) {
        final d = json.decode(r.body);
        if (d is List) return d;
        if (d is Map && d['content'] is List) return d['content'] as List;
        if (d is Map && d['reviews'] is List) return d['reviews'] as List;
        return [];
      }
      return null;
    } catch (e) {
      _log('Fetch provider reviews error: $e');
      return null;
    }
  }

  /// Reviews the signed-in buyer wrote for providers.
  /// Null when the server could not be reached or refused (so screens keep what they show).
  static Future<List<dynamic>?> fetchReviewsWrittenOrNull() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/reviews/written'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) return json.decode(response.body) as List;
      return null;
    } catch (e) {
      _log('Fetch written reviews error: $e');
      return null;
    }
  }

  static Future<List<dynamic>> fetchReviewsWritten() async => await fetchReviewsWrittenOrNull() ?? <dynamic>[];

  /// Why the last [submitReview] was refused (null after a success or a network problem).
  static String? lastReviewError;

  static String? _reviewError(int status, String body) {
    final en = AppStrings.isEnglish;
    String code = '';
    try {
      final d = json.decode(body);
      if (d is Map) code = (d['message'] ?? '').toString().toUpperCase();
    } catch (caught, trace) { AppLog.e('api_service._reviewError', caught, trace); }
    if (code.contains('ALREADY_REVIEWED')) return en ? 'You already reviewed this booking.' : 'Tayari umeshatoa maoni kwa oda hii.';
    if (code.contains('TRANSACTION_NOT_COMPLETED')) return en ? 'You can review once the booking is completed.' : 'Unaweza kutoa maoni oda ikishakamilika.';
    if (code.contains('TRANSACTION_NOT_FOUND')) return en ? 'This booking was not found.' : 'Oda hii haikupatikana.';
    if (code.contains('RATING') || status == 400) return en ? 'Choose a rating from 1 to 5 stars.' : 'Chagua ukadiriaji wa nyota 1 hadi 5.';
    return null;
  }

  /// Rate a completed booking (buyer).
  static Future<Map<String, dynamic>?> submitReview({
    required String transactionRef,
    required int rating,
    String? comment,
  }) async {
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/reviews'),
        headers: _getHeaders(),
        body: json.encode({
          'transactionRef': transactionRef,
          'rating': rating,
          if (comment != null && comment.trim().isNotEmpty) 'comment': comment.trim(),
        }),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200 || response.statusCode == 201) {
        lastReviewError = null;
        return json.decode(response.body) as Map<String, dynamic>;
      }
      lastReviewError = _reviewError(response.statusCode, response.body);
      return null;
    } catch (e) {
      lastReviewError = null;
      _log('Submit review error: $e');
      return null;
    }
  }

  /// Report a service, a user, or a general problem. Backend: POST /reports
  /// body: {type: SERVICE|USER|GENERAL, reason, details, serviceId?, reportedUserId?}
  /// Returns true when the server accepted the report.
  /// Why the last [submitReport] failed (friendly text from the server's answer), null when it did not fail.
  static String? lastReportError;

  static Future<bool> submitReport({
    required String type,
    required String reason,
    String details = '',
    String? serviceId,
    int? reportedUserId,
  }) async {
    lastReportError = null;
    try {
      final body = <String, dynamic>{
        'type': type,
        'reason': reason,
        'details': details.trim(),
        if (serviceId != null && serviceId.isNotEmpty)
          'serviceId': int.tryParse(serviceId) ?? serviceId,
        if (reportedUserId != null && reportedUserId != 0) 'reportedUserId': reportedUserId,
      };
      final r = await _Http.post(Uri.parse('$baseUrl/reports'), headers: _getHeaders(), body: json.encode(body))
          .timeout(const Duration(seconds: 15));
      if (r.statusCode == 200 || r.statusCode == 201 || r.statusCode == 204) return true;
      lastReportError = _httpErrorText(r.statusCode, r.body);
      return false;
    } catch (e) {
      lastReportError = _exceptionText(e);
      _log('Submit report error: $e');
      return false;
    }
  }

  /// Block a user. Backend: POST /users/{id}/block
  /// Optional body: {reason, details} (why the user is being blocked).
  static Future<bool> blockUser(int userId, {String? reason, String? details}) async {
    try {
      final hasBody = (reason ?? '').isNotEmpty;
      final r = await _Http.post(
        Uri.parse('$baseUrl/users/$userId/block'),
        headers: _getHeaders(),
        body: hasBody
            ? json.encode({'reason': reason, if ((details ?? '').trim().isNotEmpty) 'details': details!.trim()})
            : null,
      )
          .timeout(const Duration(seconds: 10));
      return r.statusCode == 200 || r.statusCode == 201 || r.statusCode == 204;
    } catch (e) {
      _log('Block user error: $e');
      return false;
    }
  }

  /// Unblock a user. Backend: DELETE /users/{id}/block
  static Future<bool> unblockUser(int userId) async {
    try {
      final r = await _Http.delete(Uri.parse('$baseUrl/users/$userId/block'), headers: _getHeaders())
          .timeout(const Duration(seconds: 10));
      return r.statusCode == 200 || r.statusCode == 204;
    } catch (e) {
      _log('Unblock user error: $e');
      return false;
    }
  }

  /// Tell the server a conversation is muted / unmuted so it can skip push
  /// notifications from that person. Best effort. Backend: POST|DELETE /chats/{userId}/mute
  static Future<bool> setChatMuted(int userId, bool muted) async {
    try {
      final url = Uri.parse('$baseUrl/chats/$userId/mute');
      final r = muted
          ? await _Http.post(url, headers: _getHeaders()).timeout(const Duration(seconds: 10))
          : await _Http.delete(url, headers: _getHeaders()).timeout(const Duration(seconds: 10));
      return r.statusCode >= 200 && r.statusCode < 300;
    } catch (e) {
      _log('Mute chat error: $e');
      return false;
    }
  }

  /// Users the signed-in account blocked. Null when it can't be loaded. Backend: GET /users/blocked
  static Future<List<dynamic>?> fetchBlockedUsers() async {
    try {
      final r = await _Http.get(Uri.parse('$baseUrl/users/blocked'), headers: _getHeaders())
          .timeout(const Duration(seconds: 10));
      if (r.statusCode == 200) {
        final d = json.decode(r.body);
        if (d is List) return d;
        if (d is Map && d['content'] is List) return d['content'] as List;
      }
      return null;
    } catch (e) {
      _log('Fetch blocked users error: $e');
      return null;
    }
  }

  /// Fetch user conversations list
  /// Reads an 'online' flag the server may send as bool, 0/1 or 'true'/'1'.
  static bool parseOnline(dynamic v) => v == true || v == 1 || v == '1' || v.toString().toLowerCase() == 'true';

  static Future<List<dynamic>> fetchConversations() async => await fetchConversationsOrNull() ?? [];

  /// Like [fetchConversations], but null when the server could not be reached (weak network), so a
  /// screen can keep what it already shows instead of wiping the list.
  static Future<List<dynamic>?> fetchConversationsOrNull() async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/chats/conversations'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 20));

      if (response.statusCode == 200) {
        return json.decode(response.body) as List;
      }
      return null;
    } catch (e) {
      _log('Fetch conversations error: $e');
      return null;
    }
  }

  /// Fetch messages for a specific conversation or user
  /// Null when the server could not be reached: the chat then keeps the messages it already has
  /// (an empty list from a failed call used to wipe the whole conversation on a weak network).
  static Future<List<dynamic>?> fetchMessages(String conversationId) async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/chats/$conversationId/messages'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 20));

      if (response.statusCode == 200) {
        return json.decode(response.body) as List;
      }
      return null;
    } catch (e) {
      _log('Fetch messages error: $e');
      return null;
    }
  }

  /// Send a real message to another user or conversation
  /// [replyToId] makes it an answer to that earlier message of the same chat.
  /// After a failed [sendMessage]: true when the server ANSWERED with a refusal (blocked, bad request:
  /// retrying is pointless), false when no answer came (weak network: retrying is right).
  static bool lastSendRejected = false;

  /// [clientId] is an app-made id: sending the same one again after a lost reply never creates a duplicate.
  static Future<Map<String, dynamic>?> sendMessage({
    required String recipientId,
    required String message,
    int? replyToId,
    String? clientId,
  }) async {
    lastSendRejected = false;
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/chats/send'),
        headers: _getHeaders(),
        body: json.encode({
          'recipientId': recipientId,
          'message': message,
          if (replyToId != null) 'replyToId': replyToId,
          if (clientId != null) 'clientId': clientId,
        }),
      ).timeout(const Duration(seconds: 25));

      if (response.statusCode == 200) {
        return json.decode(response.body);
      }
      // 5xx / busy server: worth another try; anything else is a real refusal
      lastSendRejected = !(response.statusCode >= 500 || response.statusCode == 408 || response.statusCode == 429);
      return null;
    } catch (e) {
      _log('Send message error: $e');
      return null;
    }
  }

  /// Change the text of one of my own messages (text only, first 15 minutes).
  /// Backend: PUT /chats/messages/{id} {"message": "..."}  -> the updated message, null when refused.
  static Future<Map<String, dynamic>?> editMessage(int id, String message) async {
    try {
      final r = await _Http.put(
        Uri.parse('$baseUrl/chats/messages/$id'),
        headers: _getHeaders(),
        body: json.encode({'message': message}),
      ).timeout(const Duration(seconds: 10));
      if (r.statusCode == 200) return _decodeObj(r.body);
      return null;
    } catch (e) {
      _log('Edit message error: $e');
      return null;
    }
  }

  /// Delete a message for me only. When both people have deleted it the server removes it
  /// for good. Backend: DELETE /chats/messages/{id}
  static Future<bool> deleteMessage(int id) async {
    try {
      final r = await _Http.delete(
        Uri.parse('$baseUrl/chats/messages/$id'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      return r.statusCode >= 200 && r.statusCode < 300;
    } catch (e) {
      _log('Delete message error: $e');
      return false;
    }
  }

  /// Saves the signed-in user's GPS position in the database (used to rank nearby services).
  /// Backend: PUT /users/me/location  {latitude, longitude}
  /// Turn Hide My ID on or off for the signed-in user.
  /// Backend (must exist): PUT /users/me/privacy  {"hideMyId": true|false}  -> 2xx
  /// See docs/hide_my_id_api_contract.md. Returns false when the server did not accept it,
  /// so the app never shows "on" while the server still shares the real identity.
  static Future<bool> updateHideMyId(bool hide) async {
    if (!SessionManager.isLoggedIn()) return false;
    try {
      final response = await _Http.put(
        Uri.parse('$baseUrl/users/me/privacy'),
        headers: _getHeaders(),
        body: json.encode({'hideMyId': hide}),
      ).timeout(const Duration(seconds: 15));
      return response.statusCode >= 200 && response.statusCode < 300;
    } catch (e) {
      _log('Update Hide My ID error: $e');
      return false;
    }
  }

  /// Lock or unlock the profile (hides phone and social links from the public). Saved on the server first.
  /// Backend: PUT /users/me/privacy  {"profileLocked": true|false}  -> 2xx
  static Future<bool> updateProfileLocked(bool locked) async {
    if (!SessionManager.isLoggedIn()) return false;
    try {
      final response = await _Http.put(
        Uri.parse('$baseUrl/users/me/privacy'),
        headers: _getHeaders(),
        body: json.encode({'profileLocked': locked}),
      ).timeout(const Duration(seconds: 15));
      final ok = response.statusCode >= 200 && response.statusCode < 300;
      if (ok) dropMyCachedServices();
      return ok;
    } catch (e) {
      _log('Update profile lock error: $e');
      return false;
    }
  }

  /// Saves the profile social links on the server (they are the fallback contacts of the user's services, shown to
  /// the public only while the profile is Unlocked). Keys: whatsapp, instagram, facebook, x, tiktok, youtube.
  /// Backend: PUT /users/me/socials {key: text}  -> 2xx. An empty text clears that link.
  static Future<bool> saveSocials(Map<String, String> socials) async {
    lastProfileError = null;
    lastSavedSocials = null;
    if (!SessionManager.isLoggedIn()) {
      lastProfileError = 'Sign in first';
      return false;
    }
    try {
      final response = await _Http.put(
        Uri.parse('$baseUrl/users/me/socials'),
        headers: _getHeaders(),
        body: json.encode(socials),
      ).timeout(const Duration(seconds: 15));
      final ok = response.statusCode >= 200 && response.statusCode < 300;
      if (ok) {
        // The server cleans the links (leading @ removed, trimmed): keep exactly what it stored.
        final raw = _decodeObj(response.body)?['socials'];
        if (raw is Map) {
          lastSavedSocials = {for (final k in SessionManager.socialKeys) k: (raw[k] ?? '').toString().trim()};
        }
        dropMyCachedServices();
      } else {
        lastProfileError = _httpErrorText(response.statusCode, response.body);
      }
      return ok;
    } catch (e) {
      lastProfileError = _exceptionText(e);
      _log('Save socials error: ${e.runtimeType}');
      return false;
    }
  }

  /// The links the server stored on the last successful [saveSocials] (null when it did not say).
  static Map<String, String>? lastSavedSocials;

  /// Makes this phone and the server agree on the profile (GET /users/me): photo, cover, About me, stage name,
  /// registered phone / email, Profile Locked, Hide My ID and the social links. The server is the truth, so a new
  /// phone or a reinstall shows what the account really has (login only brings back part of it). Also refreshes the
  /// role and verification badge, which Home's tabs depend on; main.dart calls this at start-up and on app resume. A value the
  /// server did not send (an older server) is left as it is. A phone that still holds social links the server has
  /// never seen (saved before they were stored there) sends them up once.
  static Future<void> syncMyProfile() async {
    if (!SessionManager.isLoggedIn()) return;
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/users/me'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode != 200) return;
      final d = _decodeObj(response.body);
      if (d == null) return;

      String? text(String key) => d[key] == null ? null : d[key].toString().trim();

      // Role and verification badge: the server decides them (an admin can approve a seller, or the role can
      // change on another phone), so a restored session must not keep the values saved at login.
      final role = text('role');
      if (role != null && role.isNotEmpty && role != 'null' && role != SessionManager.getRole()) {
        await SessionManager.updateRole(role);
      }
      final badge = text('verificationBadge');
      if (badge != null && badge.isNotEmpty && badge != 'null' && badge != SessionManager.getBadge()) {
        await SessionManager.saveBadge(badge);
      }

      final avatar = text('avatarUrl');
      if (avatar != null) {
        final next = (avatar.isEmpty || avatar == 'null') ? '' : absoluteUrl(avatar);
        if (next != SessionManager.getAvatarUrl()) await SessionManager.saveAvatarUrl(next);
      }
      final cover = text('coverUrl');
      if (cover != null) {
        final next = (cover.isEmpty || cover == 'null') ? '' : absoluteUrl(cover);
        if (next != SessionManager.getCoverUrl()) await SessionManager.saveCoverUrl(next);
      }
      final bio = text('bio');
      if (bio != null && bio != SessionManager.getBio()) await SessionManager.saveBio(bio);
      final stage = text('stageName');
      if (stage != null && stage.isNotEmpty && stage != SessionManager.getStageName()) {
        await SessionManager.saveStageName(stage);
      }
      final phone = text('phone');
      if (phone != null && phone.isNotEmpty && phone != 'null' && phone != SessionManager.getPhone()) {
        await SessionManager.savePhone(phone);
      }
      final email = text('email');
      if (email != null && email.isNotEmpty && email != 'null' && email != SessionManager.getEmail()) {
        await SessionManager.saveEmail(email);
      }
      if (d['profileLocked'] is bool && d['profileLocked'] != SecuritySettings.profileLocked) {
        await SecuritySettings.setProfileLocked(d['profileLocked'] as bool);
      }
      if (d['hideMyId'] is bool && d['hideMyId'] != SecuritySettings.hideMyId) {
        await SecuritySettings.setHideMyId(d['hideMyId'] as bool);
      }

      final raw = d['socials'];
      if (raw is! Map) return; // an older server: keep the local copy
      final remote = {for (final k in SessionManager.socialKeys) k: (raw[k] ?? '').toString().trim()};
      final local = {for (final k in SessionManager.socialKeys) k: SessionManager.getSocial(k)};
      if (remote.values.every((v) => v.isEmpty)) {
        if (local.values.any((v) => v.isNotEmpty)) await saveSocials(local);
        return;
      }
      for (final k in SessionManager.socialKeys) {
        if (remote[k] != local[k]) await SessionManager.saveSocial(k, remote[k]!);
      }
    } catch (e) {
      _log('Sync profile error: ${e.runtimeType}');
    }
  }

  /// Older name of [syncMyProfile], kept so nothing else breaks.
  static Future<void> syncMySocials() => syncMyProfile();

  /// Forgets the signed-in provider's cached services, so a contact or lock change shows at once instead of the old copy.
  static void dropMyCachedServices() {
    final me = SessionManager.getUserIdValue();
    knownServices.removeWhere((_, s) => s.sellerId != null && s.sellerId == me);
  }

  /// Tells the server which notification categories this user wants, so it never sends the others
  /// (even when the app is closed). Backend: PUT /users/me/notifications {bookings, messages, promos} -> 2xx
  static Future<bool> updateNotificationPrefs({bool? bookings, bool? messages, bool? promos}) async {
    if (!SessionManager.isLoggedIn()) return false;
    final body = <String, dynamic>{
      if (bookings != null) 'bookings': bookings,
      if (messages != null) 'messages': messages,
      if (promos != null) 'promos': promos,
    };
    if (body.isEmpty) return false;
    try {
      final response = await _Http.put(
        Uri.parse('$baseUrl/users/me/notifications'),
        headers: _getHeaders(),
        body: json.encode(body),
      ).timeout(const Duration(seconds: 15));
      return response.statusCode >= 200 && response.statusCode < 300;
    } catch (e) {
      _log('Update notification prefs error: $e');
      return false;
    }
  }

  /// What the server has saved for the Hide My ID and notification switches (GET /users/me), so a new phone or a
  /// reinstall shows the real state. A value the server did not send is null. Returns null when there is no answer.
  static Future<({bool? hideMyId, bool? profileLocked, bool? bookings, bool? messages, bool? promos})?> getMySwitches() async {
    if (!SessionManager.isLoggedIn()) return null;
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/users/me'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode != 200) return null;
      final d = _decodeObj(response.body);
      if (d == null) return null;
      bool? b(dynamic v) => v is bool ? v : null;
      return (
        hideMyId: b(d['hideMyId']),
        profileLocked: b(d['profileLocked']),
        bookings: b(d['notifBookings']),
        messages: b(d['notifMessages']),
        promos: b(d['notifPromos']),
      );
    } catch (e) {
      _log('Load my switches error: ${e.runtimeType}');
      return null;
    }
  }

  /// Why the last [updateProfile] call failed (null when it succeeded).
  static String? lastProfileError;

  /// Change the signed-in user's display name (phone and email use [requestContactChange] instead).
  /// Backend (must exist): PUT /users/me/profile  {"stageName"?, "bio"?}  -> 2xx
  /// Returns false when the server did not accept it; [lastProfileError] says why.
  static Future<bool> updateProfile({String? stageName, String? bio}) async {
    lastProfileError = null;
    if (!SessionManager.isLoggedIn()) {
      lastProfileError = 'Sign in first';
      return false;
    }
    final body = <String, dynamic>{
      if (stageName != null) 'stageName': stageName,
      if (bio != null) 'bio': bio,
    };
    if (body.isEmpty) return true;
    try {
      final response = await _Http.put(
        Uri.parse('$baseUrl/users/me/profile'),
        headers: _getHeaders(),
        body: json.encode(body),
      ).timeout(const Duration(seconds: 15));
      if (response.statusCode >= 200 && response.statusCode < 300) return true;
      lastProfileError = _httpErrorText(response.statusCode, response.body);
      return false;
    } catch (e) {
      lastProfileError = _exceptionText(e);
      _log('Update profile error: $e');
      return false;
    }
  }

  /// Phone and email are the identities the account was registered with, so changing one needs a code
  /// sent to the NEW value. Step 1: ask the server to send the code.
  /// Backend (must exist): POST /users/me/{phone|email}/request-change  {"phone"|"email": value}  -> 2xx
  static Future<bool> requestContactChange({required bool isPhone, required String value}) =>
      _contactCall(isPhone, 'request-change', {isPhone ? 'phone' : 'email': value.trim()});

  /// Step 2: confirm with the code. The server switches the registered phone/email only if the code is right.
  /// Backend (must exist): POST /users/me/{phone|email}/confirm-change  {"phone"|"email": value, "otp": "123456"}  -> 2xx
  static Future<bool> confirmContactChange({required bool isPhone, required String value, required String otp}) =>
      _contactCall(isPhone, 'confirm-change', {isPhone ? 'phone' : 'email': value.trim(), 'otp': otp.trim()});

  static Future<bool> _contactCall(bool isPhone, String step, Map<String, String> body) async {
    lastProfileError = null;
    if (!SessionManager.isLoggedIn()) {
      lastProfileError = 'Sign in first';
      return false;
    }
    try {
      final response = await _Http.post(
        Uri.parse('$baseUrl/users/me/${isPhone ? 'phone' : 'email'}/$step'),
        headers: _getHeaders(),
        body: json.encode(body),
      ).timeout(const Duration(seconds: 15));
      if (response.statusCode >= 200 && response.statusCode < 300) return true;
      lastProfileError = _httpErrorText(response.statusCode, response.body);
      return false;
    } catch (e) {
      lastProfileError = _exceptionText(e);
      _log('Contact change error: ${e.runtimeType}');
      return false;
    }
  }

  /// Change the signed-in account's country / wallet currency (Settings -> Country & currency).
  /// Backend (must exist): PUT /users/me/currency  {"country": "KE", "currency": "KES"}  -> 2xx
  /// The server decides (it may refuse, e.g. while the wallet still holds a balance) and says why;
  /// the app switches its own display only after a 2xx. [lastProfileError] has the reason.
  static Future<bool> updateAccountCurrency(String iso) async {
    lastProfileError = null;
    if (!SessionManager.isLoggedIn()) {
      lastProfileError = 'Sign in first';
      return false;
    }
    final c = CurrencyService.supported[iso.toUpperCase()];
    if (c == null) {
      lastProfileError = 'Country not supported';
      return false;
    }
    try {
      final response = await _Http.put(
        Uri.parse('$baseUrl/users/me/currency'),
        headers: _getHeaders(),
        body: json.encode({'country': c.iso, 'currency': c.code}),
      ).timeout(const Duration(seconds: 15));
      if (response.statusCode >= 200 && response.statusCode < 300) return true;
      lastProfileError = _httpErrorText(response.statusCode, response.body);
      return false;
    } catch (e) {
      lastProfileError = _exceptionText(e);
      _log('Update currency error: ${e.runtimeType}');
      return false;
    }
  }

  // ---- Live location on an active booking (both people follow each other) ----
  // POST   /escrow/{ref}/live-location {latitude, longitude, heading?} -> 200, or 409 TRACKING_NOT_ACTIVE
  // GET    /escrow/{ref}/live-location -> {active, latitude?, longitude?, heading?, ageSeconds?, reason?}
  // DELETE /escrow/{ref}/live-location  (stop sharing)

  /// Sends my position. Returns the HTTP status (0 = no network).
  static Future<int> sendLiveLocation(String ref, double lat, double lng, double? heading) async {
    try {
      final r = await _Http.post(
        Uri.parse('$baseUrl/escrow/${Uri.encodeComponent(ref)}/live-location'),
        headers: _getHeaders(),
        body: json.encode({'latitude': lat, 'longitude': lng, if (heading != null) 'heading': heading}),
      ).timeout(const Duration(seconds: 8));
      return r.statusCode;
    } catch (caught, trace) {
      AppLog.e('api_service.sendLiveLocation', caught, trace);
      return 0;
    }
  }

  /// The other person's last position, or null when the request failed.
  static Future<Map<String, dynamic>?> fetchOtherLiveLocation(String ref) async {
    try {
      final r = await _Http.get(
        Uri.parse('$baseUrl/escrow/${Uri.encodeComponent(ref)}/live-location'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 8));
      if (r.statusCode != 200) return null;
      final d = json.decode(r.body);
      return d is Map<String, dynamic> ? d : null;
    } catch (caught, trace) {
      AppLog.e('api_service.sendLiveLocation', caught, trace);
      return null;
    }
  }

  static Future<void> stopLiveLocation(String ref) async {
    try {
      await _Http.delete(
        Uri.parse('$baseUrl/escrow/${Uri.encodeComponent(ref)}/live-location'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 8));
    } catch (caught, trace) { AppLog.e('api_service.stopLiveLocation', caught, trace); }
  }

  static Future<bool> updateUserLocation(double latitude, double longitude) async {
    if (!SessionManager.isLoggedIn()) return false;
    try {
      final response = await _Http.put(
        Uri.parse('$baseUrl/users/me/location'),
        headers: _getHeaders(),
        body: json.encode({'latitude': latitude, 'longitude': longitude}),
      ).timeout(const Duration(seconds: 10));
      return response.statusCode >= 200 && response.statusCode < 300;
    } catch (e) {
      _log('Update location error: $e');
      return false;
    }
  }

  /// Fetch active services from the backend with optional pagination
  /// Every service seen so far (Home, Category, Search, Favorites), by id, so a
  /// saved service can be shown anywhere even when it is not on the current page.
  static final Map<String, ServiceItem> knownServices = {};

  static Future<List<ServiceItem>> fetchServices({
    String? category,
    String? query,
    String? city,
    int? radiusKm,
    int page = 0,
    int size = 20,
  }) async {
    final r = await fetchServicesPage(
      category: category, query: query, city: city, radiusKm: radiusKm, page: page, size: size,
    );
    return r.items;
  }

  /// Same as [fetchServices] but also tells the caller whether another page
  /// exists and whether the request worked (so "Load more" can retry on a
  /// network error instead of wrongly deciding the list has ended).
  /// `hasMore` uses the server's `last` flag, else a full raw page; the raw
  /// count is used because blocked / 18+ items are removed from [items] afterwards.
  static Future<({List<ServiceItem> items, bool hasMore, bool ok})> fetchServicesPage({
    String? category,
    String? query,
    String? city,
    int? radiusKm,
    int page = 0,
    int size = 20,
  }) async {
    try {
      final queryParams = <String, String>{
        'page': page.toString(),
        'size': size.toString(),
      };
      if (category != null && category.isNotEmpty && category != 'All') {
        queryParams['category'] = category;
      }
      if (query != null && query.isNotEmpty) {
        queryParams['query'] = query;
      }
      if (city != null && city.isNotEmpty) {
        queryParams['city'] = city;
      }
      // With a GPS fix the server can rank/filter by distance.
      if (GpsService.hasFix) {
        queryParams['lat'] = GpsService.lat!.toStringAsFixed(6);
        queryParams['lng'] = GpsService.lng!.toStringAsFixed(6);
        if (radiusKm != null) queryParams['radiusKm'] = radiusKm.toString();
      }
      final allowSensitive = SecuritySettings.allowSensitive;
      queryParams['includeSensitive'] = allowSensitive.toString();

      final uri = Uri.parse('$baseUrl/services').replace(queryParameters: queryParams.isEmpty ? null : queryParams);
      final response = await _Http.get(uri, headers: _getHeaders()).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final List content = data['content'] ?? [];
        final last = data['last'];
        final hasMore = last is bool ? !last : content.length >= size;

        final items = content.map((jsonItem) => _mapJsonToServiceItem(jsonItem)).toList();
        for (final it in items) {
          knownServices[it.id] = it;
        }
        // Nearest first (items without a known distance keep their order, after the rest).
        if (GpsService.hasFix && items.any((s) => s.distanceKm != null)) {
          final indexed = items.asMap().entries.toList()
            ..sort((a, b) {
              final x = a.value.distanceKm, y = b.value.distanceKm;
              if (x == null && y == null) return a.key.compareTo(b.key);
              if (x == null) return 1;
              if (y == null) return -1;
              final c = x.compareTo(y);
              return c != 0 ? c : a.key.compareTo(b.key);
            });
          items
            ..clear()
            ..addAll(indexed.map((e) => e.value));
        }
        // Boosted services first (stable: keeps the nearest-first order inside each group).
        if (items.any((s) => s.isBoosted)) {
          final boosted = items.where((s) => s.isBoosted).toList();
          final rest = items.where((s) => !s.isBoosted).toList();
          items
            ..clear()
            ..addAll(boosted)
            ..addAll(rest);
        }
        // Hide sensitive (18+) services unless the user allowed them in Settings.
        // Hide services from sellers the user blocked.
        final visible = items.where((s) => !BlockService.isBlocked(s.sellerId));
        final shown = allowSensitive ? visible.toList() : visible.where((s) => !s.is18Plus).toList();
        // Sensitive services only appear for a whole-word match of the search text
        // ("Utu" must not find "Utumbo umetoka", "Utumbo" does).
        final out = shown.where((s) => StrictMatch.allows(s, query)).toList();
        // The server may only look at titles. On the first page also add services the app already
        // holds whose description, features, provider name, category or city match the words typed.
        if (page == 0 && query != null && query.trim().isNotEmpty) {
          final have = out.map((s) => s.id).toSet();
          final extra = ServiceText.localMatches(
            knownServices.values,
            query,
            category: category,
            city: city,
            exclude: (s) => have.contains(s.id) || BlockService.isBlocked(s.sellerId) || (!allowSensitive && s.is18Plus),
          );
          out.addAll(extra);
        }
        return (items: out, hasMore: hasMore, ok: true);
      } else {
        _log('Failed to load services: ${response.statusCode}');
        return (items: <ServiceItem>[], hasMore: true, ok: false);
      }
    } catch (e) {
      _log('Error fetching services: $e');
      return (items: <ServiceItem>[], hasMore: true, ok: false);
    }
  }

  /// One public service by id (used when a shared link is opened), or null.
  /// GET /services/{id}
  static Future<ServiceItem?> fetchServiceById(String id) async {
    try {
      final response = await _Http.get(
        Uri.parse('$baseUrl/services/${Uri.encodeComponent(id)}'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final d = json.decode(response.body);
        if (d is Map) return _mapJsonToServiceItem(Map<String, dynamic>.from(d));
      }
      return null;
    } catch (e) {
      _log('Fetch service by id error: $e');
      return null;
    }
  }

  /// 90 -> '1 hr 30 min', 60 -> '1 hr', 45 -> '45 min'; '' when no duration is set.
  static String formatDuration(int? minutes) {
    if (minutes == null || minutes <= 0) return '';
    if (minutes < 60) return '$minutes min';
    final h = minutes ~/ 60, m = minutes % 60;
    return m == 0 ? '$h hr' : '$h hr $m min';
  }

  static ServiceItem _mapJsonToServiceItem(Map<String, dynamic> json) {
    final seller = json['seller'] ?? {};
    final String stageName = (seller['stageName'] ?? '').toString().trim().isNotEmpty
        ? seller['stageName'].toString().trim()
        : (AppStrings.isEnglish ? 'Provider' : 'Mtoa huduma'); // never a made-up "Verified Pro"
    final int? sellerId = seller['id'] != null ? (seller['id'] as num).toInt() : null;
    final String badge = seller['verificationBadge'] ?? 'NONE';

    VerificationLevel vLevel = VerificationLevel.none;
    if (badge == 'GREEN_BADGE') {
      vLevel = VerificationLevel.greenIdentity;
    } else if (badge == 'BLUE_TICK') {
      vLevel = VerificationLevel.blueBusiness;
    }

    final double? svcLat = (json['latitude'] ?? seller['latitude']) is num ? ((json['latitude'] ?? seller['latitude']) as num).toDouble() : null;
    final double? svcLng = (json['longitude'] ?? seller['longitude']) is num ? ((json['longitude'] ?? seller['longitude']) as num).toDouble() : null;
    // Prefer the server's distance; otherwise work it out from GPS + the service's coordinates.
    final double? distKm = (json['distanceKm'] is num)
        ? (json['distanceKm'] as num).toDouble()
        : GpsService.distanceKmTo(svcLat, svcLng);
    final String cityText = (json['city'] ?? '').toString().trim(); // no invented city
    final String distanceText = distKm == null
        ? cityText
        : (distKm < 1 ? '${(distKm * 1000).round()} m' : '${distKm.toStringAsFixed(distKm < 10 ? 1 : 0)} km');

    final category = json['category'] ?? 'General';
    final listed = (json['price'] as num?)?.toInt() ?? 0; // no invented price
    // Discount: the server may send the final price (salePrice) or just a percent.
    // The server stays the authority at booking time; this only decides what to show.
    final DateTime? discountEnds = DateTime.tryParse('${json['discountValidUntil'] ?? json['discountEndsAt'] ?? ''}');
    final bool discountExpired = discountEnds != null && !discountEnds.isAfter(DateTime.now());
    final int pct = ((_num(json['discountPercent']) ?? 0).toInt()).clamp(0, 90).toInt();
    final int? sale = _num(json['salePrice'] ?? json['discountedPrice'])?.toInt();
    int price = listed;
    if (!discountExpired) {
      if (sale != null && sale > 0 && sale < listed) {
        price = sale;
      } else if (pct > 0) {
        price = CurrencyService.roundToStep(listed * (100 - pct) / 100); // nearest nice step of the country's money
      }
    }
    final bool isInfoLocked = json['isInfoLocked'] ?? false;
    final bool profileLocked = seller['profileLocked'] == true || json['profileLocked'] == true;
    final bool contactsVisible = json['contactsVisible'] ?? !(isInfoLocked || profileLocked);
    final bool isOnline = parseOnline(seller['isOnline'] ?? seller['online'] ?? json['isOnline'] ?? json['sellerOnline']);

    // An unlocked service with no contact of its own uses the provider's profile
    // contacts: from the server's seller object, or from this device when it is
    // the signed-in provider's own service (and their profile is Unlocked).
    final bool isMine = sellerId != null && SessionManager.isLoggedIn() && sellerId == SessionManager.getUserIdValue();
    final bool useProfile = contactsVisible && !(isMine && SecuritySettings.profileLocked);
    String? pick(String key, {String? localKey}) {
      String? clean(dynamic v) {
        final t = v?.toString().trim() ?? '';
        return t.isEmpty ? null : t;
      }

      final own = clean(json[key]);
      if (own != null || !useProfile) return own;
      return clean(seller[key]) ?? (isMine && localKey != null ? clean(SessionManager.getSocial(localKey)) : null);
    }

    final String? phone = pick('phone') ??
        (useProfile && isMine && SessionManager.getPhone().trim().isNotEmpty ? SessionManager.getPhone().trim() : null);

    return ServiceItem(
      id: json['id'].toString(),
      sellerId: sellerId,
      title: json['title'] ?? 'Huduma',
      subtitle: json['description'] ?? '',
      shortDescription: (json['shortDescription'] ?? json['shortDesc'] ?? '').toString().trim(),
      otherLanguage: (json['otherLanguage'] ?? json['searchTerms'] ?? '').toString().trim(),
      category: category,
      distance: distanceText,
      distanceKm: distKm,
      rating: _num(json['rating'] ?? json['averageRating'] ?? seller['rating'] ?? seller['averageRating'])?.toDouble() ?? 0.0,
      reviewsCount: _num(json['reviewsCount'] ?? json['reviewCount'] ?? seller['reviewsCount'] ?? seller['reviewCount'])?.toInt() ?? 0,
      priceText: CurrencyService.format(price),
      priceAmount: price,
      listedPriceAmount: price < listed ? listed : 0,
      discountPercent: price < listed ? pct : 0,
      discountEndsAt: price < listed ? discountEnds : null,
      allowOffers: json['allowOffers'] != false,
      durationText: formatDuration(_num(json['durationMinutes'])?.toInt()),
      stageName: stageName,
      sellerAvatar: _firstText([seller['avatarUrl'], seller['profileImage'], seller['profilePhoto'], seller['avatar']]),
      sellerCover: _firstText([seller['coverUrl'], seller['coverImage'], seller['coverPhoto'], json['sellerCover']]),
      verificationLevel: vLevel,
      isSponsored: BoostInfo.fromJson(json).active,
      boostedUntil: BoostInfo.fromJson(json).until,
      themeColor: _getCategoryColor(category),
      icon: _getCategoryIcon(category),
      isInfoLocked: isInfoLocked,
      profileLocked: profileLocked,
      contactsVisible: contactsVisible,
      is18Plus: json['is18Plus'] == true,
      features: _featureList(json['features'] ?? json['menuItems']),
      tasks: ServiceTask.listFrom(json['tasks']),
      badges: _badgeKeys(seller['badges'] ?? json['sellerBadges'] ?? json['badges']),
      phone: phone,
      whatsappPhone: pick('whatsappPhone', localKey: 'whatsapp'),
      email: pick('email'),
      instagramUsername: pick('instagramUsername', localKey: 'instagram'),
      facebookUsername: pick('facebookUsername', localKey: 'facebook'),
      xUsername: pick('xUsername', localKey: 'x'),
      tiktokUsername: pick('tiktokUsername', localKey: 'tiktok'),
      youtubeUsername: pick('youtubeUsername', localKey: 'youtube'),
      imageUrls: _featuredFirst(
        _urlList(json['imageUrls'] ?? json['images'] ?? json['photos']),
        (json['featuredImageUrl'] ?? json['featuredImage'] ?? json['coverImage'])?.toString(),
      ),
      videoUrls: _urlList(json['videoUrls'] ?? json['videos']),
      isOnline: isOnline,
      availableDays: json['availableDays'] is List
          ? (json['availableDays'] as List).map((e) => e.toString().trim()).where((e) => e.isNotEmpty).toList()
          : const [],
      availableFrom: json['availableFrom']?.toString(),
      availableTo: json['availableTo']?.toString(),
      serviceMode: _serviceModeOf(json),
      sellerSince: DateTime.tryParse(_firstText([
            seller['createdAt'],
            seller['memberSince'],
            seller['joinedAt'],
            seller['registeredAt'],
            json['sellerSince'],
          ]) ??
          ''),
      sellerBio: _firstText([seller['bio'], seller['about'], seller['aboutMe'], seller['description'], json['sellerBio']]),
      completedJobs: _num(seller['completedJobs'] ?? seller['completedBookings'] ?? seller['jobsCompleted'] ?? json['completedJobs'])?.toInt(),
      totalBookings: _num(seller['totalBookings'] ?? seller['bookingsCount'] ?? json['totalBookings'])?.toInt(),
      businessVerified: seller['businessVerified'] == true || json['businessVerified'] == true,
      businessName: _firstText([seller['businessName'], json['businessName']]),
      latitude: svcLat,
      longitude: svcLng,
      city: (json['city'] ?? '').toString().trim().isEmpty ? null : json['city'].toString().trim(),
      area: (json['area'] ?? '').toString().trim().isEmpty ? null : json['area'].toString().trim(),
      serviceRadiusKm: (json['serviceRadiusKm'] is num) ? (json['serviceRadiusKm'] as num).toInt() : null,
      priceType: (json['priceType'] ?? '').toString().trim().isEmpty ? null : json['priceType'].toString().trim().toUpperCase(),
    );
  }

  /// Normalises whatever the server sends for "where is the service done".
  static String? _serviceModeOf(Map<String, dynamic> json) {
    final raw = (json['serviceMode'] ?? json['serviceType'] ?? json['locationType'] ?? json['serviceLocation'])
        ?.toString()
        .toLowerCase()
        .trim();
    if (raw == null || raw.isEmpty) return null;
    if (raw.contains('both')) return 'both';
    if (raw.contains('travel') || raw.contains('mobile') || raw.contains('home') || raw.contains('visit')) {
      return 'provider_travels';
    }
    if (raw.contains('customer') || raw.contains('studio') || raw.contains('shop') || raw.contains('salon') || raw.contains('site')) {
      return 'customer_comes';
    }
    return null;
  }

  /// Earned-badge keys from the server: ['TOP_RATED'], [{key: 'TOP_RATED'}] or 'TOP_RATED,PROFESSIONAL'.
  static List<String> _badgeKeys(dynamic raw) {
    Iterable<dynamic> items;
    if (raw is List) {
      items = raw;
    } else if (raw is String) {
      items = raw.split(',');
    } else {
      return const [];
    }
    final out = <String>[];
    for (final it in items) {
      final t = (it is Map ? (it['key'] ?? it['code'] ?? it['name'] ?? it['label']) : it)?.toString().trim() ?? '';
      if (t.isNotEmpty && !out.any((e) => e.toLowerCase() == t.toLowerCase())) out.add(t);
    }
    return out;
  }

  /// Accepts ['Soup', ...], [{name: 'Soup'}, ...] or 'Soup, Pizza'; drops blanks and duplicates.
  static List<String> _featureList(dynamic raw) {
    Iterable<dynamic> items;
    if (raw is List) {
      items = raw;
    } else if (raw is String) {
      items = raw.split(',');
    } else {
      return const [];
    }
    final out = <String>[];
    for (final it in items) {
      final t = (it is Map ? (it['name'] ?? it['title'] ?? it['label']) : it)?.toString().trim() ?? '';
      if (t.isNotEmpty && !out.any((e) => e.toLowerCase() == t.toLowerCase())) out.add(t);
    }
    return out;
  }

  /// Moves the featured image to the front so every screen that shows the
  /// first image (cards, favorites, gallery) shows the featured one.
  static List<String> _featuredFirst(List<String> urls, String? featured) {
    final f = featured?.trim() ?? '';
    if (f.isEmpty || urls.isEmpty) return urls;
    final i = urls.indexOf(f);
    if (i <= 0) return urls;
    return [f, ...urls.sublist(0, i), ...urls.sublist(i + 1)];
  }

  /// Accepts ['url', ...] or [{url: '...'}, ...]; drops blanks.
  static List<String> _urlList(dynamic raw) {
    if (raw is! List) return const [];
    final out = <String>[];
    for (final e in raw) {
      final t = (e is Map ? (e['url'] ?? e['path'] ?? e['src']) : e)?.toString().trim() ?? '';
      if (t.isNotEmpty && t != 'null') out.add(absoluteUrl(t));
    }
    return out;
  }

  static String? _firstText(List<dynamic> options) {
    for (final v in options) {
      final t = v?.toString().trim() ?? '';
      if (t.isNotEmpty && t != 'null') return t;
    }
    return null;
  }

  static num? _num(dynamic v) => v is num ? v : (v is String ? num.tryParse(v) : null);

  static Color _getCategoryColor(String category) {
    switch (category.toLowerCase()) {
      case 'cleaning':
      case 'usafi':
        return AppColors.categoryBlue;
      case 'beauty':
      case 'saloon':
        return AppColors.categoryBeauty;
      case 'plumbing':
      case 'fundi bomba':
        return AppColors.categoryTeal;
      case 'electrical':
      case 'umeme':
        return AppColors.categoryElectrical;
      case 'repair':
      case 'urekebishaji':
        return AppColors.categoryMechanic;
      case 'food':
      case 'chakula':
        return AppColors.warning;
      default:
        return AppColors.categoryBlue;
    }
  }

  static IconData _getCategoryIcon(String category) {
    switch (category.toLowerCase()) {
      case 'food':
      case 'chakula':
        return Icons.restaurant_rounded;
      case 'cleaning':
      case 'usafi':
        return Icons.cleaning_services_rounded;
      case 'beauty':
      case 'saloon':
        return Icons.spa_rounded;
      case 'plumbing':
      case 'fundi bomba':
        return Icons.plumbing_rounded;
      case 'electrical':
      case 'umeme':
        return Icons.bolt_rounded;
      case 'repair':
      case 'urekebishaji':
        return Icons.build_rounded;
      default:
        return Icons.design_services_rounded;
    }
  }

  // ---- Admin: review queues, reports, bookings, boost plans, settings, app version -------------
  // Every call is checked again by the server (ROLE_ADMIN only, 401/403 to everyone else).
  // Routes: /admin/verification/*, /admin/reports, /escrow/admin/*, /admin/escrow/{ref}/evidence,
  //         /admin/boosts/plans, /admin/settings, /admin/app/version.

  /// Headers for loading an admin-only picture (ID papers are private and need the login token).
  static Map<String, String> adminHeaders() => _getHeaders();

  /// GET a JSON list. [forbidden] = not an admin; [items] null = could not be loaded.
  static Future<({List<Map<String, dynamic>>? items, bool forbidden})> adminGetList(String path) async {
    try {
      final r = await _Http.get(Uri.parse('$baseUrl$path'), headers: _getHeaders()).timeout(const Duration(seconds: 15));
      if (r.statusCode == 401 || r.statusCode == 403) return (items: null, forbidden: true);
      if (r.statusCode == 200) {
        final d = json.decode(r.body);
        final list = d is List ? d : (d is Map && d['content'] is List ? d['content'] as List : null);
        if (list != null) {
          return (items: <Map<String, dynamic>>[for (final e in list) if (e is Map) Map<String, dynamic>.from(e)], forbidden: false);
        }
      }
    } catch (e) {
      _log('Admin list error: ${e.runtimeType}');
    }
    return (items: null, forbidden: false);
  }

  /// GET a JSON object. Same meaning of [forbidden] / null as [adminGetList].
  static Future<({Map<String, dynamic>? data, bool forbidden})> adminGetObject(String path) async {
    try {
      final r = await _Http.get(Uri.parse('$baseUrl$path'), headers: _getHeaders()).timeout(const Duration(seconds: 15));
      if (r.statusCode == 401 || r.statusCode == 403) return (data: null, forbidden: true);
      if (r.statusCode == 200) return (data: _decodeObj(r.body), forbidden: false);
    } catch (e) {
      _log('Admin get error: ${e.runtimeType}');
    }
    return (data: null, forbidden: false);
  }

  /// POST or PUT. [error] is a readable text when it failed; [data] is the JSON answer (may be empty).
  static Future<({Map<String, dynamic>? data, String? error})> adminSend(String method, String path, [Map<String, dynamic>? body]) async {
    try {
      final uri = Uri.parse('$baseUrl$path');
      final enc = json.encode(body ?? const <String, dynamic>{});
      final r = method == 'PUT'
          ? await _Http.put(uri, headers: _getHeaders(), body: enc).timeout(const Duration(seconds: 20))
          : await _Http.post(uri, headers: _getHeaders(), body: enc).timeout(const Duration(seconds: 20));
      if (r.statusCode >= 200 && r.statusCode < 300) {
        return (data: r.body.isEmpty ? <String, dynamic>{} : (_decodeObj(r.body) ?? <String, dynamic>{}), error: null);
      }
      return (data: null, error: _httpErrorText(r.statusCode, r.body));
    } catch (e) {
      _log('Admin send error: ${e.runtimeType}');
      return (data: null, error: _exceptionText(e));
    }
  }

}


/// Sign-up form kept in memory between "send code" and "confirm code".
class _PendingSignup {
  final String phone;
  final String challenge;
  final String password;
  final String stageName;
  final String role;
  final String? email;
  const _PendingSignup({
    required this.phone,
    required this.challenge,
    required this.password,
    required this.stageName,
    required this.role,
    this.email,
  });

  Map<String, dynamic> toJson() => {
        'phone': phone,
        'challenge': challenge,
        'password': password,
        'stageName': stageName,
        'role': role,
        if (email != null) 'email': email,
      };

  static _PendingSignup? tryParse(Map<String, dynamic>? m) {
    if (m == null) return null;
    final phone = m['phone'], challenge = m['challenge'], password = m['password'];
    final stageName = m['stageName'], role = m['role'], email = m['email'];
    if (phone is! String || phone.isEmpty || challenge is! String || challenge.isEmpty) return null;
    if (password is! String || password.isEmpty || stageName is! String || stageName.isEmpty) return null;
    if (role != 'ROLE_BUYER' && role != 'ROLE_SELLER') return null;
    return _PendingSignup(
      phone: phone,
      challenge: challenge,
      password: password,
      stageName: stageName,
      role: role as String,
      email: email is String && email.isNotEmpty ? email : null,
    );
  }

  _PendingSignup copyWith({String? stageName, String? password, String? email}) => _PendingSignup(
        phone: phone,
        challenge: challenge,
        password: password ?? this.password,
        stageName: stageName ?? this.stageName,
        role: role,
        email: email ?? this.email,
      );
}
