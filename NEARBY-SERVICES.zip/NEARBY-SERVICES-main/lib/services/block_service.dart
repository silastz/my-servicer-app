import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'api_service.dart';
import 'session_manager.dart';
import 'app_log.dart';

/// Why someone is blocked. Codes go to the server; labels are for the person.
class BlockReasons {
  static const List<String> codes = ['HARASSMENT', 'SPAM', 'SCAM', 'INAPPROPRIATE', 'NOT_INTERESTED', 'OTHER'];

  static String label(String? code, {required bool en}) {
    switch (code) {
      case 'HARASSMENT':
        return en ? 'Harassment or abuse' : 'Unyanyasaji au matusi';
      case 'SPAM':
        return en ? 'Spam or unwanted messages' : 'Ujumbe usiotakiwa';
      case 'SCAM':
        return en ? 'Scam or fraud' : 'Utapeli';
      case 'INAPPROPRIATE':
        return en ? 'Inappropriate content' : 'Maudhui yasiyofaa';
      case 'NOT_INTERESTED':
        return en ? "I don't want to see them" : 'Sitaki kumuona';
      case 'OTHER':
        return en ? 'Something else' : 'Jingine';
      default:
        return '';
    }
  }
}

class BlockedUser {
  final int id;
  final String name;
  final DateTime? blockedAt;
  final String? reason; // one of BlockReasons.codes, when known

  const BlockedUser({required this.id, required this.name, this.blockedAt, this.reason});

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'blockedAt': blockedAt?.toIso8601String(), 'reason': reason};

  static BlockedUser? fromJson(dynamic j) {
    if (j is! Map) return null;
    final u = j['blockedUser'] is Map ? j['blockedUser'] as Map : j;
    final rawId = u['id'] ?? j['blockedUserId'] ?? j['userId'];
    final id = rawId is num ? rawId.toInt() : int.tryParse('${rawId ?? ''}');
    if (id == null || id == 0) return null;
    final name = (u['stageName'] ?? u['name'] ?? u['username'] ?? j['name'] ?? '').toString().trim();
    final at = DateTime.tryParse('${j['blockedAt'] ?? j['createdAt'] ?? ''}');
    final rawReason = (j['reason'] ?? '').toString().trim();
    return BlockedUser(id: id, name: name.isEmpty ? 'User' : name, blockedAt: at, reason: rawReason.isEmpty ? null : rawReason);
  }
}

/// Blocked users for the signed-in account.
///
/// Local-first: blocking / unblocking takes effect on the phone immediately and
/// is sent to the server. If the server call fails (offline), it is queued and
/// retried on the next [sync].
///
/// Backend endpoints used:
///   POST   /users/{id}/block
///   DELETE /users/{id}/block
///   GET    /users/blocked   -> [{id | userId | blockedUser:{id,stageName}, blockedAt}]
class BlockService {
  BlockService._();

  /// Bumped on every change so screens can refresh.
  static final ValueNotifier<int> changed = ValueNotifier<int>(0);

  static List<BlockedUser> _list = [];
  static final Set<int> _pendingBlock = {};
  static final Set<int> _pendingUnblock = {};
  // reason + note kept for blocks that still have to reach the server
  static final Map<int, Map<String, String>> _pendingReason = {};
  static int _loadedFor = -1;
  static SharedPreferences? _prefs;
  static bool _started = false;

  static int get _uid => SessionManager.getUserIdValue();
  static String get _kList => 'blocked_users_$_uid';
  static String get _kPendB => 'blocked_pending_add_$_uid';
  static String get _kPendU => 'blocked_pending_remove_$_uid';
  static String get _kPendR => 'blocked_pending_reason_$_uid';

  static List<BlockedUser> get blocked => List.unmodifiable(_list);
  static int get count => _list.length;

  static bool isBlocked(int? userId) {
    if (userId == null || userId == 0) return false;
    return _list.any((b) => b.id == userId);
  }

  static Future<void> start() async {
    if (_started) return;
    _started = true;
    _prefs = await SharedPreferences.getInstance();
    await _loadLocal();
    SessionManager.sessionNotifier.addListener(() async {
      if (_loadedFor != _uid) {
        await _loadLocal();
        if (SessionManager.isLoggedIn()) sync();
      }
    });
    if (SessionManager.isLoggedIn()) sync();
  }

  static Future<void> _loadLocal() async {
    _prefs ??= await SharedPreferences.getInstance();
    _loadedFor = _uid;
    _list = [];
    _pendingBlock.clear();
    _pendingUnblock.clear();
    _pendingReason.clear();
    if (_uid != 0) {
      try {
        final raw = _prefs!.getString(_kList);
        if (raw != null) {
          for (final j in json.decode(raw) as List) {
            final b = BlockedUser.fromJson(j);
            if (b != null) _list.add(b);
          }
        }
      } catch (caught, trace) { AppLog.e('block_service._loadLocal', caught, trace); }
      _pendingBlock.addAll((_prefs!.getStringList(_kPendB) ?? []).map(int.tryParse).whereType<int>());
      _pendingUnblock.addAll((_prefs!.getStringList(_kPendU) ?? []).map(int.tryParse).whereType<int>());
      try {
        final rr = _prefs!.getString(_kPendR);
        if (rr != null) {
          (json.decode(rr) as Map).forEach((k, v) {
            final id = int.tryParse('$k');
            if (id != null && v is Map) _pendingReason[id] = v.map((a, c) => MapEntry('$a', '$c'));
          });
        }
      } catch (caught, trace) { AppLog.e('block_service._loadLocal', caught, trace); }
    }
    changed.value++;
  }

  static Future<void> _save() async {
    if (_uid == 0) return;
    _prefs ??= await SharedPreferences.getInstance();
    await _prefs!.setString(_kList, json.encode(_list.map((b) => b.toJson()).toList()));
    await _prefs!.setStringList(_kPendB, _pendingBlock.map((e) => '$e').toList());
    await _prefs!.setStringList(_kPendU, _pendingUnblock.map((e) => '$e').toList());
    await _prefs!.setString(_kPendR, json.encode(_pendingReason.map((k, v) => MapEntry('$k', v))));
  }

  /// Blocks [userId]. Takes effect immediately on this phone.
  /// [reason] is one of [BlockReasons.codes]; [details] is an optional note.
  static Future<void> block(int userId, String name, {String? reason, String? details}) async {
    if (userId == 0 || userId == _uid) return;
    if (!isBlocked(userId)) {
      _list.insert(
        0,
        BlockedUser(id: userId, name: name.trim().isEmpty ? 'User' : name.trim(), blockedAt: DateTime.now(), reason: reason),
      );
    }
    _pendingUnblock.remove(userId);
    final ok = await ApiService.blockUser(userId, reason: reason, details: details);
    if (!ok) {
      _pendingBlock.add(userId);
      if ((reason ?? '').isNotEmpty) _pendingReason[userId] = {'reason': reason!, 'details': details ?? ''};
    }
    await _save();
    changed.value++;
  }

  static Future<void> unblock(int userId) async {
    _list.removeWhere((b) => b.id == userId);
    _pendingBlock.remove(userId);
    _pendingReason.remove(userId);
    final ok = await ApiService.unblockUser(userId);
    if (!ok) _pendingUnblock.add(userId);
    await _save();
    changed.value++;
  }

  /// Sends queued changes, then replaces the local list with the server's.
  static Future<void> sync() async {
    if (!SessionManager.isLoggedIn()) return;
    for (final id in _pendingBlock.toList()) {
      final pr = _pendingReason[id];
      if (await ApiService.blockUser(id, reason: pr?['reason'], details: pr?['details'])) {
        _pendingBlock.remove(id);
        _pendingReason.remove(id);
      }
    }
    for (final id in _pendingUnblock.toList()) {
      if (await ApiService.unblockUser(id)) _pendingUnblock.remove(id);
    }
    final remote = await ApiService.fetchBlockedUsers();
    if (remote != null) {
      final names = {for (final b in _list) b.id: b.name};
      final reasons = {for (final b in _list) b.id: b.reason};
      final merged = <BlockedUser>[];
      for (final j in remote) {
        final b = BlockedUser.fromJson(j);
        if (b == null || _pendingUnblock.contains(b.id)) continue;
        merged.add(BlockedUser(
          id: b.id,
          name: b.name == 'User' && names[b.id] != null ? names[b.id]! : b.name,
          blockedAt: b.blockedAt,
          reason: b.reason ?? reasons[b.id],
        ));
      }
      for (final id in _pendingBlock) {
        if (!merged.any((b) => b.id == id)) {
          merged.add(BlockedUser(id: id, name: names[id] ?? 'User', blockedAt: DateTime.now(), reason: reasons[id]));
        }
      }
      _list = merged;
    }
    await _save();
    changed.value++;
  }
}
