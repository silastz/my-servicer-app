import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';

import '../security/secure_http.dart';
import '../security/client_security_config.dart';
import 'session_manager.dart';
import 'app_log.dart';

/// "Something changed in a conversation." No message text travels over the socket: screens
/// answer an event by re-reading the chat through the normal authenticated REST call.
class ChatEvent {
  /// message | edited | deleted | read | reconnected (the line came back: refresh everything)
  final String event;
  final int? from;
  final int? to;
  const ChatEvent(this.event, {this.from, this.to});

  bool get isReconnect => event == 'reconnected';

  /// True when this event belongs to the conversation with [userId] (or is a reconnect).
  bool involves(int? userId) => isReconnect || (userId != null && (from == userId || to == userId));
}

/// Live connection to wss://host/ws/chat. Stays open while the app is in the foreground,
/// reconnects by itself (back-off), and closes on sign-out. The app keeps a slow timer refresh
/// as a safety net, so a dropped line never loses a message.
class ChatSocket {
  ChatSocket._();

  /// True while the server has accepted our token and the line is open.
  static final ValueNotifier<bool> connected = ValueNotifier(false);

  static final StreamController<ChatEvent> _events = StreamController<ChatEvent>.broadcast();
  static Stream<ChatEvent> get events => _events.stream;

  static WebSocket? _ws;
  static Timer? _retry;
  static int _attempt = 0;
  static bool _wanted = false;
  static bool _paused = false;
  static bool _connecting = false;
  static int _generation = 0; // a late callback of an old connection must not act
  static _Lifecycle? _lifecycle;

  /// Opens the line (no-op when signed out or already open). Safe to call from any screen.
  static void start() {
    _wanted = true;
    if (_lifecycle == null) {
      _lifecycle = _Lifecycle();
      WidgetsBinding.instance.addObserver(_lifecycle!);
    }
    unawaited(_connect());
  }

  /// Closes the line for good (sign-out).
  static void stop() {
    _wanted = false;
    _retry?.cancel();
    _closeCurrent();
    final l = _lifecycle;
    if (l != null) {
      WidgetsBinding.instance.removeObserver(l);
      _lifecycle = null;
    }
  }

  static Future<void> _connect() async {
    if (!_wanted || _paused || _connecting || _ws != null) return;
    final token = SessionManager.getToken();
    if (token == null || token.isEmpty) return;

    _connecting = true;
    final gen = ++_generation;
    WebSocket? ws;
    try {
      final origin = Uri.parse(ClientSecurityConfig.origin);
      if (origin.scheme != 'https') return; // never over cleartext
      final url = Uri(
        scheme: 'wss',
        host: origin.host,
        port: origin.hasPort ? origin.port : null,
        path: '/ws/chat',
      );
      ws = await WebSocket.connect(url.toString(), customClient: SecureHttp.client.socketClientFor(url))
          .timeout(const Duration(seconds: 15));
      if (gen != _generation || !_wanted || _paused) {
        await ws.close();
        return;
      }
      ws.pingInterval = const Duration(seconds: 25); // also detects a silently dead line
      _ws = ws;
      // the token goes in the first frame, never in the URL
      ws.add('auth $token');
      ws.listen(
        (data) => _onFrame(gen, data),
        onDone: () => _onClosed(gen),
        onError: (_) => _onClosed(gen),
        cancelOnError: true,
      );
    } catch (e) {
      if (kDebugMode) AppLog.d('[ChatSocket] connect failed: $e');
      try {
        await ws?.close();
      } catch (caught, trace) { AppLog.e('chat_socket._connect', caught, trace); }
      _ws = null;
      _scheduleRetry();
    } finally {
      _connecting = false;
    }
  }

  static void _onFrame(int gen, dynamic data) {
    if (gen != _generation || data is! String || !data.startsWith('{')) return;
    try {
      final m = jsonDecode(data);
      if (m is! Map) return;
      switch (m['type']) {
        case 'ready':
          _attempt = 0;
          connected.value = true;
          // messages that arrived while the line was down
          _events.add(const ChatEvent('reconnected'));
        case 'chat':
          _events.add(ChatEvent(
            '${m['event']}',
            from: (m['from'] as num?)?.toInt(),
            to: (m['to'] as num?)?.toInt(),
          ));
      }
    } catch (caught, trace) { AppLog.e('chat_socket._onFrame', caught, trace); }
  }

  static void _onClosed(int gen) {
    if (gen != _generation) return;
    _ws = null;
    connected.value = false;
    _scheduleRetry();
  }

  static void _closeCurrent() {
    _generation++; // callbacks of the old connection are now ignored
    final ws = _ws;
    _ws = null;
    connected.value = false;
    if (ws != null) {
      try {
        unawaited(ws.close());
      } catch (caught, trace) { AppLog.e('chat_socket._closeCurrent', caught, trace); }
    }
  }

  static void _scheduleRetry() {
    _retry?.cancel();
    if (!_wanted || _paused) return;
    // 1s, 2s, 4s ... capped at 30s, plus a little randomness so phones do not all return together
    final secs = min(30, 1 << min(_attempt, 5));
    _attempt++;
    _retry = Timer(Duration(milliseconds: secs * 1000 + Random().nextInt(700)), () => unawaited(_connect()));
  }

  static void _onForeground() {
    _paused = false;
    if (!_wanted) return;
    _attempt = 0;
    _retry?.cancel();
    unawaited(_connect());
  }

  static void _onBackground() {
    // Android / iOS freeze sockets in the background anyway; push notifications cover that time.
    _paused = true;
    _retry?.cancel();
    _closeCurrent();
  }
}

class _Lifecycle with WidgetsBindingObserver {
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      ChatSocket._onForeground();
    } else if (state == AppLifecycleState.paused) {
      ChatSocket._onBackground();
    }
  }
}
