import 'package:flutter/foundation.dart';
import 'package:in_app_review/in_app_review.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'app_log.dart';

/// Shows the Google Play (Android) / App Store (iOS) rating card INSIDE the app,
/// so people rate Ungana without leaving it.
///
/// The card itself is drawn by the store and cannot be restyled. The store also
/// limits how often it will show, and may show nothing at all, so this only
/// decides WHEN to ask:
///  - after the person just left a good review (4 or 5 stars),
///  - at most once every [_cooldown], and never again after [_maxAsks] asks.
class AppRatingService {
  AppRatingService._();

  static const _kLastAsk = 'rate_app_last_ask_ms';
  static const _kAskCount = 'rate_app_ask_count';
  static const _cooldown = Duration(days: 90);
  static const _maxAsks = 3;
  static const minStars = 4;

  /// Pure rule, kept separate so it can be unit tested.
  static bool shouldAsk({
    required int stars,
    required int askCount,
    required DateTime? lastAsk,
    required DateTime now,
  }) {
    if (stars < minStars) return false;
    if (askCount >= _maxAsks) return false;
    if (lastAsk != null && now.difference(lastAsk) < _cooldown) return false;
    return true;
  }

  /// Call right after a review was sent. Safe to call every time: it does nothing
  /// unless [shouldAsk] allows it, and never throws.
  static Future<void> maybeAsk(int stars) async {
    try {
      if (kIsWeb) return;
      final prefs = await SharedPreferences.getInstance();
      final lastMs = prefs.getInt(_kLastAsk);
      final now = DateTime.now();
      final ok = shouldAsk(
        stars: stars,
        askCount: prefs.getInt(_kAskCount) ?? 0,
        lastAsk: lastMs == null ? null : DateTime.fromMillisecondsSinceEpoch(lastMs),
        now: now,
      );
      if (!ok) return;
      final review = InAppReview.instance;
      if (!await review.isAvailable()) return;
      // Count the ask first: the store does not tell us whether the card was shown.
      await prefs.setInt(_kLastAsk, now.millisecondsSinceEpoch);
      await prefs.setInt(_kAskCount, (prefs.getInt(_kAskCount) ?? 0) + 1);
      await review.requestReview();
    } catch (e) {
      AppLog.d('Rate app prompt skipped: $e');
    }
  }
}
