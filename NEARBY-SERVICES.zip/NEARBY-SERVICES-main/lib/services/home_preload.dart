import 'dart:async';
import '../models/models.dart';
import 'api_service.dart';
import 'location_service.dart';
import 'security_settings.dart';
import 'app_log.dart';

typedef ServicesPage = ({List<ServiceItem> items, bool hasMore, bool ok});

/// Loads the Home feed's first page while the splash is still showing, so Home
/// opens already filled instead of starting with skeletons.
///
/// Home takes the result once, and only when its request is the same one
/// (same city, no radius, same page size, same sensitive-content setting) and
/// the result is still fresh. Anything else (pull-to-refresh, GPS fix, radius
/// change, a failed preload) fetches normally, so Home never shows stale or
/// wrong data because of this.
class HomePreload {
  HomePreload._();

  static const int pageSize = 10; // must match HomeScreen._pageSize
  static const Duration _maxAge = Duration(seconds: 45);

  static Future<ServicesPage>? _future;
  static String? _city;
  static bool? _sensitive;
  static DateTime? _at;

  /// Starts the first-page request (no-op if one is already running).
  static void start() {
    if (_future != null) return;
    _city = LocationService.activeLocationNotifier.value;
    _sensitive = SecuritySettings.allowSensitive;
    _at = DateTime.now();
    _future = ApiService.fetchServicesPage(
      city: _city!.isEmpty ? null : _city,
      page: 0,
      size: pageSize,
    );
  }

  /// Waits for the preload, but never longer than [max] (the splash must not hang).
  static Future<void> waitUpTo(Duration max) async {
    final f = _future;
    if (f == null) return;
    try {
      await f.timeout(max);
    } catch (caught, trace) {
      AppLog.e('home_preload.waitUpTo', caught, trace);
      // Timed out or failed: Home will simply load by itself.
    }
  }

  /// The preloaded first page if it matches this request, else null. Single use.
  static Future<ServicesPage>? take({required String? city, required int? radiusKm, required int page, required int size}) {
    final f = _future;
    _future = null; // single use, whatever the outcome
    if (f == null || page != 0 || radiusKm != null || size != pageSize) return null;
    if ((city ?? '') != (_city ?? '')) return null;
    if (SecuritySettings.allowSensitive != _sensitive) return null;
    final at = _at;
    if (at == null || DateTime.now().difference(at) > _maxAge) return null;
    return f.then((r) => r.ok ? r : ApiService.fetchServicesPage(city: city, page: page, size: size));
  }
}
