/// What the admin charges a provider. Both charges are taken ONLY when the provider WITHDRAWS (the
/// wallet shows the full amount a buyer paid).
///
/// - [collectionPercent]: collection fee, a % of the withdrawn amount, charged ON ITS OWN, e.g. 3
/// - [vatPercent]: the main charge as a % of the withdrawn amount, e.g. 18
/// - [payoutFee]: flat TSh that is INSIDE the VAT charge (not added on top), e.g. 1500
///
/// Example, provider withdraws 20,000 (3%, 18%, payout fee 1,500):
///   collection fee = 3% of 20,000 = 600
///   charge         = 18% of 20,000 = 3,600  = payout fee 1,500 + VAT 2,100
///   provider receives 20,000 - 600 - 3,600 = 15,800
///   admin wallet: +600 collection fee, +1,500 payout fee income, +2,100 VAT (to remit)
///
/// Withdraw 10,000: 300 + 1,800 (1,500 payout + 300 VAT) -> provider receives 7,900.
///
/// Small amounts: if 18% of the amount is less than the payout fee, the charge is the payout fee
/// (the payout cost is always covered) and there is no VAT part. Withdraw 5,000: collection 150,
/// charge 1,500 (18% = 900), provider receives 3,350.
///
/// REFUNDS to a buyer carry only the charge, not the collection fee: refunding 10,000 pays back
/// 8,200 ([refund]).
///
/// The app only uses this class to SHOW those numbers. The server takes the real fees at
/// withdrawal time and its answers always win.
class ProviderFees {
  final double collectionPercent;
  final double vatPercent;
  final int payoutFee;

  /// Lowest / highest amount a provider may withdraw, set by the admin. 0 = not set
  /// (no minimum from the admin -> the app's default; no maximum -> only the balance limits it).
  final int withdrawMin;
  final int withdrawMax;
  const ProviderFees({
    this.collectionPercent = 0,
    this.vatPercent = 0,
    this.payoutFee = 0,
    this.withdrawMin = 0,
    this.withdrawMax = 0,
  });

  /// True when NO fee is set. (The withdrawal limits are not fees and do not count here.)
  bool get isZero => collectionPercent <= 0 && vatPercent <= 0 && payoutFee <= 0;

  /// Collection fee for a withdrawal of [amount], whole TSh, rounded half up.
  int collectionFee(num amount) => (amount * collectionPercent / 100).round();

  /// The 18% charge (payout fee inside it) for [amount]. This is the part a refund also carries.
  int chargeFee(num amount) {
    if (vatPercent <= 0 && payoutFee <= 0) return 0;
    final pct = (amount * vatPercent / 100).round();
    return pct > payoutFee ? pct : payoutFee;
  }

  /// EVERYTHING taken from a withdrawal of [amount]: collection fee + charge.
  int totalFee(num amount) => collectionFee(amount) + chargeFee(amount);

  /// Payout fee part of the charge (admin fee income).
  int payoutAmount(num amount) => (vatPercent <= 0 && payoutFee <= 0) ? 0 : payoutFee;

  /// VAT part of the charge (what is left after the payout fee). Goes to the admin wallet as VAT to remit.
  int vatAmount(num amount) => chargeFee(amount) - payoutAmount(amount);

  /// What the provider receives when withdrawing [amount]. Never below 0.
  int net(num amount) {
    final n = amount.round() - totalFee(amount);
    return n < 0 ? 0 : n;
  }

  /// What a buyer gets back when a booking of [paid] is refunded (the charge only, no collection fee).
  int refund(num paid) {
    final n = paid.round() - chargeFee(paid);
    return n < 0 ? 0 : n;
  }

  /// True when [amount] pays the fees and still leaves something.
  bool covers(num amount) => amount.round() - totalFee(amount) > 0;

  // ---- Admin withdrawal (platform wallet -> admin's mobile money) ----------------------------
  // The ONLY fee is the flat payout fee. No collection fee, no VAT charge (the admin is not a
  // provider, and nothing is owed to the tax authority on moving the platform's own money).
  // Example: admin withdraws 20,000 with payout fee 1,500 -> fee 1,500, receives 18,500.

  /// Fee on an admin withdrawal: the flat payout fee, whatever the amount.
  int adminWithdrawFee(num amount) => payoutFee;

  /// What the admin receives when withdrawing [amount]. Never below 0.
  int adminWithdrawNet(num amount) {
    final n = amount.round() - adminWithdrawFee(amount);
    return n < 0 ? 0 : n;
  }

  /// True when [amount] pays the payout fee and still leaves something.
  bool adminWithdrawCovers(num amount) => amount.round() - adminWithdrawFee(amount) > 0;

  /// Smallest admin withdrawal that leaves at least 1 TSh after the payout fee.
  int get adminSmallestUsable => payoutFee + 1;

  /// Smallest whole-TSh withdrawal that still leaves at least 1 TSh after the fees.
  int get smallestUsable {
    if (vatPercent + collectionPercent >= 100) return 1 << 30;
    var a = payoutFee + 1;
    final limit = payoutFee + 1000000;
    while (!covers(a) && a < limit) {
      a++;
    }
    return a;
  }

  static const double maxCollection = 20;
  static const double maxVat = 50;
  static const int maxPayoutFee = 1000000;
  static const int maxWithdrawLimit = 100000000;
  static const int minWithdrawFloor = 100;

  /// Valid values only, or null (admin sent nothing usable). Unknown keys are ignored.
  static ProviderFees? tryParse(dynamic raw) {
    if (raw is! Map) return null;
    double? vat(dynamic v) {
      final n = v is num ? v.toDouble() : (v is String ? double.tryParse(v) : null);
      return (n != null && n.isFinite && n >= 0 && n <= maxVat) ? n : null;
    }

    int? flat(dynamic v) {
      final n = v is num ? v : (v is String ? num.tryParse(v) : null);
      return (n != null && n.isFinite && n >= 0 && n <= maxPayoutFee) ? n.round() : null;
    }

    double? coll(dynamic v) {
      final n = vat(v);
      return (n != null && n <= maxCollection) ? n : null;
    }

    int? limit(dynamic v) {
      final n = v is num ? v : (v is String ? num.tryParse(v) : null);
      if (n == null || !n.isFinite || n < 0 || n > maxWithdrawLimit) return null;
      final i = n.round();
      return (i == 0 || i >= minWithdrawFloor) ? i : null; // 0 = not set
    }

    final c = coll(raw['collectionPercent']);
    final v = vat(raw['vatPercent']);
    final f = flat(raw['payoutFee']);
    var lo = limit(raw['withdrawMin']);
    var hi = limit(raw['withdrawMax']);
    if (lo != null && hi != null && lo > 0 && hi > 0 && hi < lo) {
      lo = null; // contradictory: ignore both
      hi = null;
    }
    if (c == null && v == null && f == null && lo == null && hi == null) return null;
    return ProviderFees(
      collectionPercent: c ?? 0,
      vatPercent: v ?? 0,
      payoutFee: f ?? 0,
      withdrawMin: lo ?? 0,
      withdrawMax: hi ?? 0,
    );
  }

  Map<String, dynamic> toJson() => {
        'collectionPercent': collectionPercent,
        'vatPercent': vatPercent,
        'payoutFee': payoutFee,
        'withdrawMin': withdrawMin,
        'withdrawMax': withdrawMax,
      };
}
