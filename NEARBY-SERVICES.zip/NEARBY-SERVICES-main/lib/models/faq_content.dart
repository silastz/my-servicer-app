/// The Help & Support FAQs, in English and Swahili.
///
/// Every answer describes what the app and the server really do (escrow flow, fees, offers, verification,
/// privacy). Numbers the admin controls are written as tokens such as `{regFee}`; the Help screen fills them from
/// the live policy ([FaqContent.render]) and falls back to plain words when the server has not sent them.
/// Pure Dart on purpose, so it can be unit-tested.
class FaqItem {
  final String qEn;
  final String qSw;
  final String aEn;
  final String aSw;
  const FaqItem(this.qEn, this.qSw, this.aEn, this.aSw);

  String q(bool en) => en ? qEn : qSw;
  String a(bool en) => en ? aEn : aSw;
}

class FaqCategory {
  final String id;
  final String titleEn;
  final String titleSw;
  final List<FaqItem> items;
  const FaqCategory(this.id, this.titleEn, this.titleSw, this.items);

  String title(bool en) => en ? titleEn : titleSw;
}

class FaqHit {
  final FaqCategory category;
  final FaqItem item;
  const FaqHit(this.category, this.item);
}

class FaqContent {
  FaqContent._();

  /// Tokens the Help screen may fill in. Anything else inside braces is a mistake (the test checks).
  static const Set<String> tokens = {'regFee', 'svcFee', 'freeLimit', 'collection', 'withdrawRange', 'topUpRange'};

  /// Replaces `{token}` with its value. A token with no value is left out safely (never shown as raw text).
  static String render(String text, Map<String, String> values) {
    final filled = text.replaceAllMapped(RegExp(r'\{([a-zA-Z]+)\}'), (m) => values[m.group(1)] ?? '');
    // A value that is not known leaves "()" behind: remove it.
    return filled.replaceAll(RegExp(r'\s*\(\s*\)'), '');
  }

  /// Items whose question or answer contains every word of [query]. Empty query = nothing (the screen shows all).
  static List<FaqHit> search(String query, bool en, Map<String, String> values) {
    final words = query.toLowerCase().split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    if (words.isEmpty) return const [];
    final out = <FaqHit>[];
    for (final c in categories) {
      for (final i in c.items) {
        final hay = '${i.q(en)} ${render(i.a(en), values)}'.toLowerCase();
        if (words.every(hay.contains)) out.add(FaqHit(c, i));
      }
    }
    return out;
  }

  static const List<FaqCategory> categories = [
    // ------------------------------------------------------------------ 1
    FaqCategory('start', 'Getting started & account', 'Kuanza na akaunti', [
      FaqItem(
        'What is Ungana?',
        'Ungana ni nini?',
        'Ungana connects you with trusted service providers near you. You can search, chat, book and pay inside the app, and providers can post their services and get paid.',
        'Ungana inakuunganisha na watoa huduma wanaoaminika karibu nawe. Unaweza kutafuta, kuongea, kuweka oda na kulipa ndani ya app, na watoa huduma wanaweza kutangaza huduma zao na kulipwa.',
      ),
      FaqItem(
        'Do I need an account to browse?',
        'Je, ninahitaji akaunti ili kuangalia huduma?',
        'No. Anyone can browse services. You need to sign in to chat, send a booking request, make an offer, save favourites, report someone or use your Pocket Fund.',
        'Hapana. Mtu yeyote anaweza kuangalia huduma. Unahitaji kuingia ili kuongea, kutuma ombi la huduma, kutoa ofa, kuhifadhi vipendwa, kuripoti mtu au kutumia Pocket Fund yako.',
      ),
      FaqItem(
        'How do I sign up and verify my number?',
        'Ninawezaje kujisajili na kuthibitisha namba yangu?',
        'Enter your details and we send a 6-digit code by SMS (or to your email). Type it in the app within 10 minutes. You have 5 wrong tries, and you can ask for only a few new codes in a short time, so enter the code carefully.',
        'Weka taarifa zako na tutakutumia namba ya siri ya tarakimu 6 kwa SMS (au barua pepe). Iandike kwenye app ndani ya dakika 10. Una nafasi 5 za kukosea, na unaweza kuomba namba mpya mara chache tu kwa muda mfupi, kwa hiyo iandike kwa makini.',
      ),
      FaqItem(
        "I did not get my code. What now?",
        'Sikupata namba ya siri. Nifanye nini?',
        'Check that the phone number or email is correct and that you have network. Wait a moment, then tap Resend OTP. If you close the app after a code was sent, reopen it within a few minutes and type the same phone or email: you go straight to the code screen without a new SMS. After too many requests you must wait before asking again.',
        'Hakikisha namba ya simu au barua pepe ni sahihi na una mtandao. Subiri kidogo kisha bonyeza Tuma tena (Resend OTP). Ukifunga app baada ya namba kutumwa, ifungue tena ndani ya dakika chache na uandike simu au barua pepe ile ile: utaenda moja kwa moja kwenye skrini ya namba bila SMS mpya. Ukiomba mara nyingi mno utalazimika kusubiri kabla ya kuomba tena.',
      ),
      FaqItem(
        'I forgot my password.',
        'Nimesahau nenosiri langu.',
        'On the sign-in screen tap Forgot password, enter your phone or email, type the code we send, then choose a new password. If you are signed in you can also use Settings > Change Password. Passwords can be at most 72 characters.',
        'Kwenye skrini ya kuingia bonyeza Umesahau nenosiri, weka simu au barua pepe, andika namba tunayotuma kisha chagua nenosiri jipya. Ukiwa umeingia unaweza pia kutumia Mipangilio > Badilisha Nenosiri. Nenosiri lisizidi herufi 72.',
      ),
      FaqItem(
        'Why does it say too many attempts when I sign in?',
        'Kwa nini inasema majaribio mengi ninapoingia?',
        'After 5 wrong passwords or wrong codes the account is paused for a while to stop people guessing. Wait about 30 minutes (10 minutes for wrong codes) and try again, or reset your password.',
        'Baada ya nenosiri au namba kukosewa mara 5, akaunti husimamishwa kwa muda ili kuzuia kubahatisha. Subiri takriban dakika 30 (dakika 10 kwa namba za siri) kisha ujaribu tena, au weka nenosiri jipya.',
      ),
      FaqItem(
        'How do I change my phone number or email?',
        'Ninabadilishaje namba ya simu au barua pepe?',
        'Open your profile and choose to change your phone or email. We send a 6-digit code to the NEW number or address; type it within 10 minutes (5 tries). You stay signed in. A number or email already used by another account cannot be taken.',
        'Fungua wasifu wako na uchague kubadilisha simu au barua pepe. Tutatuma namba ya tarakimu 6 kwenye namba au anwani MPYA; iandike ndani ya dakika 10 (majaribio 5). Hutatolewa nje ya akaunti. Namba au barua pepe inayotumiwa na akaunti nyingine haiwezi kuchukuliwa.',
      ),
      FaqItem(
        'Can I use the app in Swahili or English?',
        'Naweza kutumia app kwa Kiswahili au Kiingereza?',
        'Yes. Change the language from the language option in the app. Notifications also arrive in the language of your phone.',
        'Ndiyo. Badilisha lugha kupitia chaguo la lugha kwenye app. Arifa pia hufika kwa lugha ya simu yako.',
      ),
      FaqItem(
        'Which countries and currencies are supported?',
        'Nchi na sarafu gani zinaungwa mkono?',
        'Tanzania (TZS), Kenya (KES), Uganda (UGX), Rwanda (RWF), Burundi (BIF) and DR Congo (CDF). The app never converts money. You can switch country only when your Pocket Fund is empty, nothing is in progress (no booking, no payment waiting) and you have no services posted, because their prices are in the old currency.',
        'Tanzania (TZS), Kenya (KES), Uganda (UGX), Rwanda (RWF), Burundi (BIF) na DR Congo (CDF). App haibadilishi pesa kutoka sarafu moja hadi nyingine. Unaweza kubadilisha nchi tu pale Pocket Fund yako haina pesa, hakuna oda au malipo yanayoendelea, na huna huduma ulizotangaza, kwa sababu bei zake ziko kwenye sarafu ya zamani.',
      ),
      FaqItem(
        'How do I stay signed in, or lock the app?',
        'Nabaki nimeingia vipi, au kufunga app?',
        'In Settings & Security you can turn Remember Me on (stay signed in when you reopen the app) or off (sign in every time), and turn on biometric unlock (fingerprint or face) if your phone supports it.',
        'Kwenye Mipangilio na Usalama unaweza kuwasha Nikumbuke (ubaki umeingia unapofungua app tena) au kuzima (uingie kila mara), na kuwasha kufungua kwa alama ya kidole au uso kama simu yako inaunga mkono.',
      ),
      FaqItem(
        'Which notifications will I get, and can I turn them off?',
        'Nitapata arifa gani, na naweza kuzizima?',
        'There are three switches in Settings > Notification Preferences: Bookings & requests, Messages & calls, and Offers & news. Booking and offer updates, payments, reviews and chat messages are sent as push notifications.',
        'Kuna swichi tatu kwenye Mipangilio > Mipangilio ya Arifa: Oda na maombi, Ujumbe na simu, na Ofa na habari. Mabadiliko ya oda na ofa, malipo, tathmini na ujumbe wa chat hutumwa kama arifa.',
      ),
      FaqItem(
        'How do I delete my account?',
        'Ninafutaje akaunti yangu?',
        'There is no delete button in the app yet. Use Contact Support (if shown) or Report a Problem and tell us you want the account closed. Withdraw your Pocket Fund balance first.',
        'Bado hakuna kitufe cha kufuta akaunti kwenye app. Tumia Wasiliana na Msaada (ikionekana) au Ripoti Tatizo na utuambie unataka akaunti ifungwe. Toa kwanza salio la Pocket Fund yako.',
      ),
    ]),

    // ------------------------------------------------------------------ 2
    FaqCategory('find', 'Finding services', 'Kutafuta huduma', [
      FaqItem(
        'How do I find a provider near me?',
        'Ninampataje mtoa huduma aliye karibu nami?',
        'Use the Home page, tap a category, or use Search and its filters. The app uses your location to show how far each service is. You can also set a service radius to see only providers within a distance you choose.',
        'Tumia ukurasa wa Mwanzo, bonyeza kundi, au tumia Utafutaji na vichujio vyake. App hutumia eneo lako kuonyesha umbali wa kila huduma. Unaweza pia kuweka eneo la huduma ili uone watoa huduma walio ndani ya umbali unaochagua.',
      ),
      FaqItem(
        'Who can see my location?',
        'Nani anaweza kuona eneo langu?',
        'Nobody. Your position is stored privately to work out distances and is never shown to other people. Your exact position is shared only if you choose to share live location on a booking (see Safety & privacy).',
        'Hakuna. Eneo lako huhifadhiwa kwa siri ili kukokotoa umbali na halionyeshwi kwa watu wengine. Eneo lako kamili hushirikiwa tu ukichagua kushiriki eneo la moja kwa moja kwenye oda (tazama Usalama na faragha).',
      ),
      FaqItem(
        'What does the "Boosted" tag mean?',
        'Alama ya "Boosted" ina maana gani?',
        'A provider paid to have that service shown first (Home, category and search) for a number of days. It is an advertisement, not a recommendation. Check ratings, badges and reviews before you book.',
        'Mtoa huduma amelipia huduma hiyo ionekane kwanza (Mwanzo, kundi na utafutaji) kwa siku kadhaa. Ni tangazo, si pendekezo. Angalia nyota, beji na tathmini kabla ya kuweka oda.',
      ),
      FaqItem(
        'What is the "You may need" section?',
        'Sehemu ya "Unaweza kuhitaji" ni nini?',
        'A guess of services you may need soon, worked out only on your phone from what you search, open, favourite and book. Nothing is sent to our servers. It stays hidden until the app is fairly confident.',
        'Ni makadirio ya huduma unazoweza kuhitaji hivi karibuni, yanayokokotolewa kwenye simu yako tu kutokana na unachotafuta, kufungua, kupenda na kuweka oda. Hakuna kinachotumwa kwenye seva zetu. Hubaki imefichwa hadi app iwe na uhakika wa kutosha.',
      ),
      FaqItem(
        'Why can I not see some services or a provider?',
        'Kwa nini siwezi kuona baadhi ya huduma au mtoa huduma?',
        'A service can be paused or removed by its owner. Also, if you blocked a person, or they blocked you, their services do not appear for you in either direction.',
        'Huduma inaweza kusimamishwa au kuondolewa na mmiliki wake. Pia, ukimzuia mtu, au akikuzuia, huduma zake hazionekani kwako, na zako kwake.',
      ),
      FaqItem(
        'How do ratings and badges work?',
        'Nyota na beji hufanyaje kazi?',
        'Ratings come only from buyers who completed a booking. Badges are awarded automatically from real reviews: Top Rated (4.8 or more with 10+ reviews), Customer Favourite (4.6 or more with 25+ reviews) and Professional (4.5 or more with 5+ reviews). They disappear if the provider no longer qualifies. A green "Available now" dot shows only while the provider is online.',
        'Nyota hutoka tu kwa wanunuzi waliokamilisha oda. Beji hutolewa kiotomatiki kutokana na tathmini halisi: Top Rated (4.8 au zaidi na tathmini 10+), Customer Favourite (4.6 au zaidi na tathmini 25+) na Professional (4.5 au zaidi na tathmini 5+). Huondolewa mtoa huduma asipostahili tena. Kidoti cha kijani "Available now" huonekana tu mtoa huduma akiwa mtandaoni.',
      ),
    ]),

    // ------------------------------------------------------------------ 3
    FaqCategory('booking', 'Booking & paying', 'Kuweka oda na kulipa', [
      FaqItem(
        'How does a booking work, step by step?',
        'Oda inafanyaje kazi, hatua kwa hatua?',
        '1) You send a request. Nothing is charged yet.\n2) The provider accepts or declines.\n3) After acceptance you pay (Pocket Fund, mobile money, or card when available). The provider\'s phone and exact location unlock for you.\n4) The provider does the job.\n5) You tap "Satisfied? Release Escrow" and the provider is paid. Then you can rate each other.',
        '1) Unatuma ombi. Hakuna kinachokatwa bado.\n2) Mtoa huduma anakubali au anakataa.\n3) Baada ya kukubali unalipa (Pocket Fund, pesa za simu, au kadi ikipatikana). Simu na eneo kamili la mtoa huduma vinafunguka kwako.\n4) Mtoa huduma anafanya kazi.\n5) Unabonyeza "Umeridhika? Toa Malipo" na mtoa huduma analipwa. Kisha mnaweza kupeana tathmini.',
      ),
      FaqItem(
        'How does Escrow protection work?',
        'Ulinzi wa Escrow unafanyaje kazi?',
        'When you pay online with the default "held" choice, the money is locked by Ungana and is not given to the provider until you confirm the job is done. If the booking is called off before the work, you are refunded. This protects you only when you pay inside the app.',
        'Unapolipa mtandaoni kwa chaguo la kawaida la "kushikiliwa", pesa zinafungiwa na Ungana na hazipewi mtoa huduma hadi uthibitishe kazi imekamilika. Oda ikifutwa kabla ya kazi, unarudishiwa. Ulinzi huu unakulinda tu unapolipa ndani ya app.',
      ),
      FaqItem(
        'What is the difference between "held" and "direct" payment?',
        'Kuna tofauti gani kati ya malipo ya "kushikiliwa" na "moja kwa moja"?',
        'On the request form you choose. Held (default): the money waits in escrow until you confirm the job. Direct: as soon as your online payment is received it goes to the provider and the booking is completed, so there is no confirm step and no escrow protection. Choose Held unless you fully trust the provider. You cannot change the choice after you send the request.',
        'Kwenye fomu ya ombi unachagua. Kushikiliwa (kawaida): pesa hukaa kwenye escrow hadi uthibitishe kazi. Moja kwa moja: malipo yako ya mtandaoni yakipokelewa huenda kwa mtoa huduma na oda inakamilika, kwa hiyo hakuna hatua ya kuthibitisha na hakuna ulinzi wa escrow. Chagua Kushikiliwa isipokuwa unamwamini kabisa mtoa huduma. Huwezi kubadilisha chaguo baada ya kutuma ombi.',
      ),
      FaqItem(
        'Which payment methods can I use?',
        'Ninaweza kutumia njia gani za kulipa?',
        'Pocket Fund (your in-app wallet) and mobile money (you get a prompt on your phone to approve). Card works only when it has been switched on for the app. The price is always set by the server: the amount on screen is what you pay (a sale price or an agreed offer price counts).',
        'Pocket Fund (pochi yako ndani ya app) na pesa za simu (utapata ujumbe kwenye simu kuthibitisha). Kadi inafanya kazi tu pale imewashwa kwenye app. Bei huwekwa na seva kila mara: kiasi unachoona ndicho unacholipa (bei ya punguzo au ofa iliyokubaliwa huhesabiwa).',
      ),
      FaqItem(
        'The provider asked me to pay first. Is that safe?',
        'Mtoa huduma ameniomba nilipe kwanza. Ni salama?',
        'A provider can ask you to pay before accepting, either online or offline (cash, bank or mobile transfer) with their own instructions and a deadline (from 5 minutes up to 7 days, usually 24 hours). Online payments are protected as above. Offline payments go straight to the provider: Ungana holds no money and has no escrow protection for them, so only pay people you trust. After paying offline tap "I have paid" (a screenshot or receipt is optional). The provider confirms, and the booking is accepted.',
        'Mtoa huduma anaweza kukuomba ulipe kabla ya kukubali, mtandaoni au nje ya app (pesa taslimu, benki au uhamisho wa simu) kwa maelekezo yake na muda wa mwisho (dakika 5 hadi siku 7, kwa kawaida saa 24). Malipo ya mtandaoni yanalindwa kama ilivyoelezwa. Malipo ya nje huenda moja kwa moja kwa mtoa huduma: Ungana haishikilii pesa wala haina ulinzi wa escrow kwa hayo, kwa hiyo lipa watu unaowaamini tu. Baada ya kulipa nje bonyeza "Nimelipa" (picha ya muamala si lazima). Mtoa huduma anathibitisha, kisha oda inakubaliwa.',
      ),
      FaqItem(
        'What if I do not pay before the deadline?',
        'Nisipolipa kabla ya muda wa mwisho itakuwaje?',
        'The request is cancelled automatically and both of you are told. Nothing is charged. If your online payment arrived in time, the booking is accepted instead.',
        'Ombi hufutwa kiotomatiki na ninyi wawili mnaarifiwa. Hakuna kinachokatwa. Kama malipo yako ya mtandaoni yalifika kwa wakati, oda hukubaliwa badala yake.',
      ),
      FaqItem(
        'The provider says they did not receive my offline payment.',
        'Mtoa huduma anasema hajapokea malipo yangu ya nje.',
        'The booking shows "payment disputed". You can send your payment details or proof again, or the provider can confirm once they see the money. If you cannot agree, use Report a Problem or Contact Support with the booking reference so our team can look at it.',
        'Oda inaonyesha "malipo yanabishaniwa". Unaweza kutuma tena maelezo au uthibitisho wa malipo, au mtoa huduma anaweza kuthibitisha akiona pesa. Msipokubaliana, tumia Ripoti Tatizo au Wasiliana na Msaada ukiwa na namba ya oda ili timu yetu iangalie.',
      ),
      FaqItem(
        'My mobile money payment went through but the booking did not update.',
        'Malipo yangu ya pesa za simu yamepita lakini oda haijabadilika.',
        'Wait a minute and open the Requests tab again: the app checks the payment status, and the server also notices a paid booking by itself. If it is still not updated after a few minutes, contact support with the booking reference and the payment SMS.',
        'Subiri dakika moja kisha fungua kichupo cha Maombi tena: app hukagua hali ya malipo, na seva pia hugundua oda iliyolipwa yenyewe. Isipobadilika baada ya dakika chache, wasiliana na msaada ukiwa na namba ya oda na ujumbe wa malipo.',
      ),
      FaqItem(
        'How do I confirm the job and release the payment?',
        'Ninathibitishaje kazi na kuachilia malipo?',
        'When the work is fully done and you are satisfied, open the booking and tap "Satisfied? Release Escrow". The provider is paid at that moment and you cannot undo it, so never confirm early. For offline bookings the button reads "Confirm completed" and just completes the booking, because the app holds no money.',
        'Kazi ikikamilika kikamilifu na umeridhika, fungua oda na ubonyeze "Umeridhika? Toa Malipo". Mtoa huduma hulipwa papo hapo na huwezi kubatilisha, kwa hiyo usithibitishe mapema. Kwa oda za malipo ya nje kitufe huandika "Thibitisha imekamilika" na kinakamilisha oda tu, kwa sababu app haishikilii pesa.',
      ),
      FaqItem(
        'How do I cancel a booking?',
        'Ninafutaje oda?',
        'You can cancel while the request is waiting for the provider, while payment is awaited, or after acceptance but before you paid. Nothing is charged for an unpaid booking. Once the booking is accepted AND paid it cannot be cancelled in the app: contact support so the team can decide (they can refund or release).',
        'Unaweza kufuta ombi likiwa linasubiri mtoa huduma, likisubiri malipo, au baada ya kukubaliwa lakini kabla hujalipa. Oda isiyolipwa haikatwi chochote. Oda ikishakubaliwa NA kulipwa haiwezi kufutwa ndani ya app: wasiliana na msaada ili timu iamue (wanaweza kurudisha pesa au kuziachilia).',
      ),
      FaqItem(
        'What happens if the provider declines or cancels?',
        'Itakuwaje mtoa huduma akikataa au akighairi?',
        'If you had already paid from Pocket Fund or online, you are refunded. Nothing is refunded for an unpaid booking because nothing was taken. A small processing charge (if the platform has set one) is kept from refunds (it is part of the platform fees, not a penalty from the provider).',
        'Kama ulikuwa umeshalipa kutoka Pocket Fund au mtandaoni, unarudishiwa. Oda isiyolipwa haina marejesho kwa sababu hakuna kilichokatwa. Ada ndogo ya uchakataji (kama jukwaa imeiweka) hukatwa kwenye marejesho (ni sehemu ya ada za jukwaa, si adhabu kutoka kwa mtoa huduma).',
      ),
      FaqItem(
        'Where does a refund go?',
        'Marejesho yanaenda wapi?',
        'Always to your Pocket Fund, even if you paid by mobile money or card. It does not go back to your phone or card automatically. You can withdraw it from the Pocket Fund.',
        'Daima kwenye Pocket Fund yako, hata ukilipa kwa pesa za simu au kadi. Hayarudi kwenye simu au kadi yako kiotomatiki. Unaweza kuyatoa kutoka kwenye Pocket Fund.',
      ),
      FaqItem(
        'Why are contact details hidden on some services?',
        'Kwa nini mawasiliano yamefichwa kwenye huduma fulani?',
        'To prevent fraud and protect privacy, a provider can lock the phone, WhatsApp, social links and exact location of a service or of their whole profile. They are shown to you once your booking is accepted (and paid, when payment is required).',
        'Ili kuzuia ulaghai na kulinda faragha, mtoa huduma anaweza kufunga simu, WhatsApp, mitandao ya kijamii na eneo kamili la huduma au la wasifu wake wote. Vinaonyeshwa kwako oda yako ikikubaliwa (na kulipwa, pale malipo yanapohitajika).',
      ),
      FaqItem(
        'Where can I see my booking history and receipts?',
        'Naweza kuona wapi historia ya oda na risiti?',
        'Open the Requests tab to see every request and its progress (Request sent, Accepted, Paid, Completed). The history on the Pocket Fund page lists top-ups, bookings, refunds, boosts and withdrawals with their references.',
        'Fungua kichupo cha Maombi kuona kila ombi na maendeleo yake (Ombi limetumwa, Limekubaliwa, Limelipwa, Limekamilika). Historia kwenye ukurasa wa Pocket Fund inaorodhesha uwekaji pesa, oda, marejesho, boost na utoaji pesa pamoja na namba za rejea.',
      ),
    ]),

    // ------------------------------------------------------------------ 4
    FaqCategory('offers', 'Offers & discounts', 'Ofa na punguzo', [
      FaqItem(
        'How do I make a price offer?',
        'Ninatoaje ofa ya bei?',
        'On a service page tap Make an Offer (only shown when the provider allows offers). Enter your price and an optional message. It must be above 0, not higher than the current price and at least 30% of it. You may have one open offer per service and send at most 5 new offers in 24 hours.',
        'Kwenye ukurasa wa huduma bonyeza Toa Ofa (inaonekana tu mtoa huduma anaporuhusu ofa). Weka bei yako na ujumbe si lazima. Lazima iwe zaidi ya 0, isizidi bei ya sasa na iwe angalau 30% yake. Unaweza kuwa na ofa moja wazi kwa kila huduma na kutuma ofa mpya zisizozidi 5 ndani ya saa 24.',
      ),
      FaqItem(
        'What happens after I send an offer?',
        'Nini kinafuata baada ya kutuma ofa?',
        'The provider has 24 hours to accept or decline. If accepted (or accepted automatically because your price reached their automatic-accept price) you have 48 hours to book at the agreed price. You get a reminder about 2 hours before it ends. You can withdraw an offer while it is waiting.',
        'Mtoa huduma ana saa 24 kukubali au kukataa. Ikikubaliwa (au kukubaliwa kiotomatiki kwa sababu bei yako imefikia bei ya kukubali kiotomatiki) una saa 48 kuweka oda kwa bei iliyokubaliwa. Utapata ukumbusho takriban saa 2 kabla muda haujaisha. Unaweza kuondoa ofa ikiwa bado inasubiri.',
      ),
      FaqItem(
        'Why was my offer refused as "too low"?',
        'Kwa nini ofa yangu imekataliwa kuwa "ndogo mno"?',
        'Providers can set a private lowest price. For fairness the app shows the same message whether you are below that price or below the 30% limit, so the minimum is never revealed. Try a higher price.',
        'Watoa huduma wanaweza kuweka bei ya chini ya siri. Kwa usawa, app huonyesha ujumbe ule ule ukiwa chini ya bei hiyo au chini ya kikomo cha 30%, ili kiwango cha chini kisifichuke. Jaribu bei ya juu zaidi.',
      ),
      FaqItem(
        'I booked with an agreed offer and then it was cancelled. Can I use the offer again?',
        'Nimeweka oda kwa ofa iliyokubaliwa kisha ikafutwa. Naweza kutumia ofa hiyo tena?',
        'No. An offer can be used for one booking only. If that booking is cancelled or rejected, make a new offer.',
        'Hapana. Ofa hutumika kwa oda moja tu. Oda hiyo ikifutwa au kukataliwa, toa ofa mpya.',
      ),
      FaqItem(
        'How do sales (discounts) work?',
        'Punguzo la bei hufanyaje kazi?',
        'A provider can put a percentage off a service until an end date. You see the new price with the normal price struck through, and the booking is charged at the sale price. The sale disappears automatically when it ends.',
        'Mtoa huduma anaweza kuweka asilimia ya punguzo kwenye huduma hadi tarehe ya mwisho. Unaona bei mpya na bei ya kawaida ikiwa imekatwa mstari, na oda inatozwa kwa bei ya punguzo. Punguzo hupotea kiotomatiki likiisha.',
      ),
    ]),

    // ------------------------------------------------------------------ 5
    FaqCategory('wallet', 'Pocket Fund & withdrawals', 'Pocket Fund na kutoa pesa', [
      FaqItem(
        'What is the Pocket Fund?',
        'Pocket Fund ni nini?',
        'Your wallet inside the app. You can top it up, pay bookings and boosts from it, receive refunds into it, and (for providers) receive earnings in it. Its history shows every movement.',
        'Ni pochi yako ndani ya app. Unaweza kuiongezea pesa, kulipia oda na boost kutoka humo, kupokea marejesho humo, na (kwa watoa huduma) kupokea mapato humo. Historia yake inaonyesha kila mwendo wa pesa.',
      ),
      FaqItem(
        'How do I top up?',
        'Naongezaje pesa?',
        'Open the Pocket Fund page, tap Top Up, enter an amount ({topUpRange}), choose mobile money (or card when available) and approve the prompt on your phone. The wallet is credited once, only after the payment is confirmed. If you paid but see no balance, wait a minute and check again; if it is still missing, contact support with the payment reference.',
        'Fungua ukurasa wa Pocket Fund, bonyeza Weka Pesa, weka kiasi ({topUpRange}), chagua pesa za simu (au kadi ikipatikana) na uthibitishe ujumbe kwenye simu yako. Pochi huongezwa mara moja tu, baada ya malipo kuthibitishwa. Ukilipa lakini usione salio, subiri dakika moja kisha uangalie tena; ikiendelea kukosekana, wasiliana na msaada ukiwa na namba ya rejea ya malipo.',
      ),
      FaqItem(
        'How do I withdraw money?',
        'Natoaje pesa?',
        'Open the Pocket Fund page, tap Withdraw, enter the amount ({withdrawRange}) and the phone number to receive it. The request is saved as Pending and our team sends the money to that number, then marks it Completed. If it cannot be sent, the whole amount returns to your wallet and the fees are cancelled. Use whole shillings only.',
        'Fungua ukurasa wa Pocket Fund, bonyeza Toa Pesa, weka kiasi ({withdrawRange}) na namba ya simu ya kupokea. Ombi huhifadhiwa kama Linasubiri na timu yetu hutuma pesa kwenye namba hiyo, kisha huweka alama Imekamilika. Ikishindikana kutuma, kiasi chote hurudi kwenye pochi yako na ada hufutwa. Tumia shilingi kamili tu.',
      ),
      FaqItem(
        'What fees are taken when I withdraw?',
        'Ada gani hukatwa ninapotoa pesa?',
        'Fees are taken only at withdrawal, never when a buyer pays you: a collection fee ({collection}) and a further fee. The withdraw screen shows "You withdraw / Collection fee / Fee / You receive" before you confirm, and the server\'s final figure is what counts. A very small amount may be refused because it would not cover the fees.',
        'Ada hukatwa wakati wa kutoa pesa tu, si mnunuzi anapokulipa: ada ya ukusanyaji ({collection}) na ada nyingine. Skrini ya kutoa pesa inaonyesha "Unatoa / Ada ya ukusanyaji / Ada / Unapokea" kabla hujathibitisha, na kiasi cha mwisho cha seva ndicho kinachohesabiwa. Kiasi kidogo mno kinaweza kukataliwa kwa sababu hakitatosha ada.',
      ),
      FaqItem(
        'How long does a withdrawal take?',
        'Kutoa pesa huchukua muda gani?',
        'Withdrawals are paid by our team, not instantly by the app, so there is no fixed minute count. Your Pocket Fund history shows the line as Pending until it is paid. If it stays Pending for long, contact support with the reference.',
        'Utoaji pesa hulipwa na timu yetu, si papo hapo na app, kwa hiyo hakuna idadi maalum ya dakika. Historia ya Pocket Fund inaonyesha mstari kama Unasubiri hadi ulipwe. Ukikaa muda mrefu, wasiliana na msaada ukiwa na namba ya rejea.',
      ),
      FaqItem(
        'When does a provider get paid for a job?',
        'Mtoa huduma hulipwa lini kwa kazi?',
        'With the Held choice, the full amount is added to the provider\'s wallet when the buyer confirms the job (or when an admin releases it). With Direct, it is added as soon as the online payment arrives. Offline payments are paid directly by the buyer and never pass through the wallet.',
        'Kwa chaguo la Kushikiliwa, kiasi kamili huongezwa kwenye pochi ya mtoa huduma mnunuzi anapothibitisha kazi (au admin anapoiachilia). Kwa Moja kwa moja, huongezwa mara malipo ya mtandaoni yanapofika. Malipo ya nje hulipwa na mnunuzi moja kwa moja na hayapiti kwenye pochi.',
      ),
    ]),

    // ------------------------------------------------------------------ 6
    FaqCategory('sell', 'Selling & providers', 'Kuuza na watoa huduma', [
      FaqItem(
        'How do I become a provider and post a service?',
        'Ninakuwaje mtoa huduma na kutangaza huduma?',
        'Open the Sell tab, register as a provider and pay the one-time registration fee ({regFee}). Then add a service with a title, description, category, price, photos or video and your location. You must have paid the registration fee before posting your first service.',
        'Fungua kichupo cha Uza, jisajili kama mtoa huduma na ulipe ada ya usajili ya mara moja ({regFee}). Kisha ongeza huduma yenye kichwa, maelezo, kundi, bei, picha au video na eneo lako. Lazima uwe umelipa ada ya usajili kabla ya kutangaza huduma ya kwanza.',
      ),
      FaqItem(
        'Is there a fee for each service I post?',
        'Kuna ada kwa kila huduma ninayotangaza?',
        'You can post {freeLimit} services for free. After that each extra service needs a listing fee ({svcFee}); paying it gives you one credit that is used when you publish. Editing an existing service never costs anything.',
        'Unaweza kutangaza huduma {freeLimit} bila malipo. Baada ya hapo kila huduma ya ziada inahitaji ada ya tangazo ({svcFee}); ukilipa unapata mkopo mmoja unaotumika unapochapisha. Kuhariri huduma iliyopo hakugharimu chochote.',
      ),
      FaqItem(
        'How do I accept or decline a request?',
        'Nakubali au kukataa ombi vipi?',
        'Open the Requests tab. You can Accept, Decline, or ask the buyer to pay first (online, or offline with your own instructions and a deadline). Accepting does not take money; the buyer pays after acceptance (unless they already paid). Respond quickly: buyers can cancel while waiting.',
        'Fungua kichupo cha Maombi. Unaweza Kukubali, Kukataa, au kumwomba mnunuzi alipe kwanza (mtandaoni, au nje ya app kwa maelekezo yako na muda wa mwisho). Kukubali hakuchukui pesa; mnunuzi hulipa baada ya kukubali (isipokuwa ameshalipa). Jibu haraka: wanunuzi wanaweza kufuta wakisubiri.',
      ),
      FaqItem(
        'I asked for an offline payment. How do I confirm it?',
        'Nimeomba malipo ya nje. Ninathibitishaje?',
        'When the buyer taps "I have paid" you see their note and optional proof. Tap Confirm payment once the money is really in your hands or account, or Payment not received if it is not. Only you, the provider, can confirm. Never confirm before you have the money.',
        'Mnunuzi akibonyeza "Nimelipa" unaona ujumbe wake na uthibitisho (ukiwepo). Bonyeza Thibitisha malipo pale pesa zinapokuwa mikononi mwako au kwenye akaunti, au Malipo hayajafika kama hayajafika. Wewe tu, mtoa huduma, ndiye unaweza kuthibitisha. Usithibitishe kabla ya kupata pesa.',
      ),
      FaqItem(
        'How do locked and unlocked contacts work for me?',
        'Mawasiliano yaliyofungwa na yaliyofunguliwa yananihusuje?',
        'Locked (default): your phone, WhatsApp, social links and exact location are hidden from the public and revealed only to a buyer whose booking you accepted. Unlocked: they are visible to everyone. You can lock a single service, or your whole profile in Settings.',
        'Yamefungwa (kawaida): simu, WhatsApp, mitandao ya kijamii na eneo lako kamili vimefichwa kwa umma na hufunuliwa tu kwa mnunuzi ambaye uliikubali oda yake. Yamefunguliwa: yanaonekana kwa kila mtu. Unaweza kufunga huduma moja, au wasifu wako wote kupitia Mipangilio.',
      ),
      FaqItem(
        'Can I let buyers send offers or run a sale?',
        'Naweza kuruhusu wanunuzi watume ofa au kuweka punguzo?',
        'Yes, when adding or editing a service. Choose a discount percentage and end date, allow offers, and optionally set two private prices: a lowest price (offers below it are refused) and an automatic-accept price (offers at or above it are accepted immediately). Buyers never see those two numbers.',
        'Ndiyo, wakati wa kuongeza au kuhariri huduma. Chagua asilimia ya punguzo na tarehe ya mwisho, ruhusu ofa, na hiari weka bei mbili za siri: bei ya chini (ofa chini yake hukataliwa) na bei ya kukubali kiotomatiki (ofa kuanzia bei hiyo hukubaliwa mara moja). Wanunuzi hawaoni namba hizo mbili.',
      ),
      FaqItem(
        'How do I boost a service?',
        'Ninaboost huduma vipi?',
        'Open your service and tap "Boost service", pick a plan (a number of days at a set price shown in the app) and pay from Pocket Fund or mobile money. The service is ranked first on Home, categories and search with a "Boosted" tag. Boosting again extends the time. The boost ends by itself, and while it runs the service may also be pushed to users who allowed promotional notifications.',
        'Fungua huduma yako na ubonyeze "Tangaza huduma", chagua kifurushi (idadi ya siku kwa bei iliyoonyeshwa kwenye app) na ulipe kwa Pocket Fund au pesa za simu. Huduma huonekana kwanza kwenye Mwanzo, makundi na utafutaji ikiwa na alama ya "Boosted". Ukiboost tena muda huongezwa. Boost huisha yenyewe, na ikiendelea huduma inaweza pia kutumwa kama arifa kwa watumiaji walioruhusu arifa za matangazo.',
      ),
      FaqItem(
        'How do reviews work?',
        'Tathmini hufanyaje kazi?',
        'After a booking is completed, the buyer and the provider can each leave one rating (1 to 5) and a comment for that booking. Only buyers\' reviews of the provider count toward the public rating and badges. Reviews show only the stage name, never the real name or phone.',
        'Oda ikikamilika, mnunuzi na mtoa huduma wanaweza kila mmoja kuacha tathmini moja (1 hadi 5) na maoni kwa oda hiyo. Tathmini za wanunuzi kwa mtoa huduma tu ndizo huhesabiwa kwenye nyota za umma na beji. Tathmini huonyesha jina la kikazi tu, kamwe si jina halisi wala simu.',
      ),
      FaqItem(
        'Why can I not publish: "registration fee required" or "service fee required"?',
        'Kwa nini siwezi kuchapisha: "ada ya usajili inahitajika" au "ada ya huduma inahitajika"?',
        'Registration fee: you have not paid the one-time fee yet. Service fee: you have used your free listings and need to pay the listing fee for another. Pay it from the prompt and publish again.',
        'Ada ya usajili: bado hujalipa ada ya mara moja. Ada ya huduma: umetumia matangazo yako ya bure na unahitaji kulipa ada ya tangazo kwa jingine. Lipa kupitia ujumbe huo kisha uchapishe tena.',
      ),
    ]),

    // ------------------------------------------------------------------ 7
    FaqCategory('verify', 'Verification & badges', 'Uthibitisho na beji', [
      FaqItem(
        'What do the Green and Blue badges mean?',
        'Beji ya Kijani na Blue zina maana gani?',
        'Green = identity verified. Blue = Verified Business (business papers approved); you need Green first. Badges are decided by the server and our team, never by the app.',
        'Kijani = utambulisho umethibitishwa. Blue = Biashara Iliyothibitishwa (nyaraka za biashara zimeidhinishwa); unahitaji Kijani kwanza. Beji huamuliwa na seva na timu yetu, kamwe si na app.',
      ),
      FaqItem(
        'How do I get the Green Badge?',
        'Ninapataje Beji ya Kijani?',
        'Open "Verify your identity" from the Sell tab or your Profile. Step 1: save your legal name and 20-digit NIDA number. Step 2: upload the front and back of your ID (or the passport photo page) and a selfie holding it. When our team approves them you get the Green Badge. One approved document alone is not enough.',
        'Fungua "Thibitisha utambulisho wako" kutoka kichupo cha Uza au Wasifu wako. Hatua 1: hifadhi jina lako halali na namba ya NIDA ya tarakimu 20. Hatua 2: pakia mbele na nyuma ya kitambulisho (au ukurasa wa picha wa pasipoti) na selfie ukikishika. Timu yetu ikiidhinisha unapata Beji ya Kijani. Hati moja iliyoidhinishwa pekee haitoshi.',
      ),
      FaqItem(
        'I have no ID photo. Is there another way to get Green?',
        'Sina picha ya kitambulisho. Kuna njia nyingine ya kupata Kijani?',
        'Yes: an invitation. A Green or Blue provider who knows you can invite you (or you can send them a request to vouch for you). You accept with the code and your NIDA number; the server checks that your saved legal name matches the name registered for that number. An invitation gives Green only, never Blue.',
        'Ndiyo: mwaliko. Mtoa huduma wa Kijani au Blue anayekujua anaweza kukualika (au unaweza kumtumia ombi akudhamini). Unakubali kwa msimbo na namba yako ya NIDA; seva hukagua kuwa jina lako halali ulilohifadhi linalingana na jina lililosajiliwa kwa namba hiyo. Mwaliko hutoa Kijani tu, kamwe si Blue.',
      ),
      FaqItem(
        'How many people can I invite?',
        'Naweza kualika watu wangapi?',
        'Verified providers (Green or Blue) can have up to 5 open invitations at a time, and each one is valid for 14 days. Only invite people you really know: your name is behind them.',
        'Watoa huduma waliothibitishwa (Kijani au Blue) wanaweza kuwa na mialiko wazi isiyozidi 5 kwa wakati mmoja, na kila mmoja ni halali kwa siku 14. Alika watu unaowajua kweli: jina lako liko nyuma yao.',
      ),
      FaqItem(
        'How do I get the Blue badge?',
        'Ninapataje beji ya Blue?',
        'Finish "Verified Business": enter your business name and upload your business papers (such as business registration, TIN certificate and business licence). When our team approves them you get Blue. It lasts until the expiry date set at approval; after that you drop back to Green until you renew.',
        'Kamilisha "Biashara Iliyothibitishwa": weka jina la biashara na upakie nyaraka zako (kama usajili wa biashara, cheti cha TIN na leseni ya biashara). Timu yetu ikiidhinisha unapata Blue. Hudumu hadi tarehe ya mwisho iliyowekwa wakati wa kuidhinisha; baada ya hapo unarudi Kijani hadi usasishe.',
      ),
      FaqItem(
        'My verification was rejected or says "name mismatch".',
        'Uthibitisho wangu umekataliwa au unasema "jina halilingani".',
        'A rejected document shows the reason: usually a blurry or cropped photo, an expired ID, or a name that differs from the ID. Name mismatch means the name you typed does not match the name registered for that NIDA number. Correct it exactly as on your ID and upload clear photos again.',
        'Hati iliyokataliwa huonyesha sababu: mara nyingi picha isiyo wazi au iliyokatwa, kitambulisho kilichoisha muda, au jina tofauti na kitambulisho. Jina kutolingana kunamaanisha jina ulilolandika halilingani na jina lililosajiliwa kwa namba hiyo ya NIDA. Liweke kama ilivyo kwenye kitambulisho na upakie picha safi tena.',
      ),
      FaqItem(
        'Who can see my ID documents?',
        'Nani anaweza kuona nyaraka zangu za kitambulisho?',
        'They are stored in a private area, not on public links, and can only be opened by our verification team. Buyers and the public never see your legal name, NIDA number or ID photos: they see your stage name and badge.',
        'Huhifadhiwa kwenye eneo la siri, si kwenye viungo vya umma, na zinaweza kufunguliwa na timu yetu ya uthibitisho pekee. Wanunuzi na umma hawaoni jina lako halali, namba ya NIDA wala picha za kitambulisho: wanaona jina lako la kikazi na beji.',
      ),
    ]),

    // ------------------------------------------------------------------ 8
    FaqCategory('safety', 'Safety & privacy', 'Usalama na faragha', [
      FaqItem(
        'How can I stay safe?',
        'Ninawezaje kuwa salama?',
        'Keep payments inside Ungana. Do not confirm completion before the work is done. Prefer providers with a Green or Blue badge and good reviews. Be careful with anyone who asks to pay outside the app or to move the chat elsewhere, and report them.',
        'Weka malipo ndani ya Ungana. Usithibitishe kukamilika kabla kazi haijaisha. Pendelea watoa huduma wenye beji ya Kijani au Blue na tathmini nzuri. Kuwa mwangalifu na yeyote anayeomba kulipwa nje ya app au kuhamishia mazungumzo kwingine, na umripoti.',
      ),
      FaqItem(
        'What is "Hide My ID"?',
        '"Ficha Utambulisho Wangu" ni nini?',
        'A buyer privacy switch. When on, providers see only your stage name and profile photo with a Safe badge (if you are verified), not the name from your ID or your verified photo. Your phone and exact address stay private until a booking is accepted either way.',
        'Ni swichi ya faragha kwa mnunuzi. Ikiwa imewashwa, watoa huduma wanaona jina lako la kikazi na picha ya wasifu pamoja na beji ya Safe (ukiwa umethibitishwa), si jina la kitambulisho wala picha iliyothibitishwa. Simu na anwani yako kamili hubaki siri hadi oda ikubaliwe, vyovyote iwavyo.',
      ),
      FaqItem(
        'What does locking my profile do?',
        'Kufunga wasifu wangu kunafanya nini?',
        'A locked profile hides your phone number and social links from people who have no accepted booking with you. Unlocking shows them on your profile to everyone. It is on by default.',
        'Wasifu uliofungwa huficha namba yako ya simu na mitandao ya kijamii kwa watu wasio na oda iliyokubaliwa nawe. Kuufungua kunavionyesha kwa kila mtu kwenye wasifu wako. Umefungwa kwa kawaida.',
      ),
      FaqItem(
        'How do I report a service, a person or a problem?',
        'Naripotije huduma, mtu au tatizo?',
        'Use the Report option on a service or profile, or Help & Support > Report a Problem for anything else (bugs, scams, abuse, payment outside the app). Pick a reason and add details. Our safety team reviews it. The person you report is never told, and you never see admin notes. You can send up to 20 reports a day.',
        'Tumia chaguo la Ripoti kwenye huduma au wasifu, au Msaada na Usaidizi > Ripoti Tatizo kwa jambo lolote jingine (hitilafu, ulaghai, matusi, malipo nje ya app). Chagua sababu na ongeza maelezo. Timu yetu ya usalama inaipitia. Unayemripoti haambiwi, na wewe huoni maelezo ya admin. Unaweza kutuma ripoti hadi 20 kwa siku.',
      ),
      FaqItem(
        'What happens when I block someone?',
        'Nini hutokea nikimzuia mtu?',
        'In both directions you cannot message each other, cannot book each other, and each other\'s services are hidden. They are not told. Existing bookings already in progress continue. You can unblock any time from Blocked users, and the chat history returns.',
        'Pande zote mbili hamwezi kutumiana ujumbe, kuwekeana oda, na huduma za kila mmoja zimefichwa. Hawaambiwi. Oda zinazoendelea tayari zinaendelea. Unaweza kumfungulia wakati wowote kupitia Watumiaji Waliozuiwa, na historia ya chat inarudi.',
      ),
      FaqItem(
        'Is live location sharing safe?',
        'Kushiriki eneo la moja kwa moja ni salama?',
        'Sharing is optional and only on an active booking. Your position is kept only for about 90 seconds, no history is saved, and it is deleted when you stop sharing or the booking is no longer active.',
        'Kushiriki ni hiari na ni kwenye oda inayoendelea tu. Eneo lako huhifadhiwa kwa takriban sekunde 90 tu, hakuna historia inayohifadhiwa, na hufutwa ukiacha kushiriki au oda isipokuwa hai tena.',
      ),
      FaqItem(
        'Why does the app block screenshots, VPN or my phone?',
        'Kwa nini app inazuia picha za skrini, VPN au simu yangu?',
        'For security, the app owner can switch on protections: blocking screenshots, blocking rooted or modified phones, requiring a genuine app install (Play Integrity) or blocking VPN use. If you are blocked, turn off the VPN or use an unmodified phone.',
        'Kwa usalama, mmiliki wa app anaweza kuwasha ulinzi: kuzuia picha za skrini, simu zilizobadilishwa (root), kuhitaji app halisi (Play Integrity) au kuzuia VPN. Ukizuiwa, zima VPN au tumia simu isiyobadilishwa.',
      ),
      FaqItem(
        'Which data does Ungana keep about me?',
        'Ungana inatunza taarifa gani kunihusu?',
        'Your account details, bookings, chats, reviews and wallet history; ID papers only if you verify; your last known position (private, used for distance). Phone and email codes are stored only as one-way hashes. For the full details read the Privacy Policy in Help & Support.',
        'Taarifa za akaunti yako, oda, chat, tathmini na historia ya pochi; nyaraka za kitambulisho tu ukithibitisha; eneo lako la mwisho (siri, hutumika kwa umbali). Namba za siri za simu na barua pepe huhifadhiwa kama alama isiyorudishika tu. Kwa maelezo kamili soma Sera ya Faragha kwenye Msaada na Usaidizi.',
      ),
    ]),

    // ------------------------------------------------------------------ 9
    FaqCategory('chat', 'Chat, calls & navigation', 'Chat, simu na uelekezi', [
      FaqItem(
        'How do I chat with a provider?',
        'Naongea vipi na mtoa huduma?',
        'Open the service or provider and tap Message. You can send text, pictures, files (PDF, Office documents, ZIP up to 25 MB) and voice notes, and edit or delete a message you sent. You can mute a conversation to stop its alerts.',
        'Fungua huduma au mtoa huduma na ubonyeze Ujumbe. Unaweza kutuma maandishi, picha, faili (PDF, hati za Office, ZIP hadi MB 25) na ujumbe wa sauti, na kuhariri au kufuta ujumbe uliotuma. Unaweza kunyamazisha mazungumzo ili kuacha arifa zake.',
      ),
      FaqItem(
        'Why can I not message someone?',
        'Kwa nini siwezi kumtumia mtu ujumbe?',
        'One of you has blocked the other. The app does not say who. If you did not block them, they may have blocked you.',
        'Mmoja wenu amemzuia mwingine. App haisemi nani. Kama wewe hukumzuia, huenda yeye amekuzuia.',
      ),
      FaqItem(
        'How does navigation and "Track on Map" work?',
        '"Elekeza" na "Fuatilia kwenye Ramani" hufanyaje kazi?',
        'After the booking is accepted you can open the in-app map for a route preview, turn-by-turn directions, ETA, automatic re-routing and arrival detection, or switch to Google Maps. You can message the provider from the map with quick replies like "I am on my way". Location permission is needed.',
        'Oda ikikubaliwa unaweza kufungua ramani ya ndani ya app kuona njia, maelekezo hatua kwa hatua, muda wa kufika, kurekebisha njia kiotomatiki na kugundua ulipofika, au kubadili kwenda Google Maps. Unaweza kumtumia mtoa huduma ujumbe kutoka kwenye ramani kwa majibu ya haraka kama "Niko njiani". Ruhusa ya eneo inahitajika.',
      ),
      FaqItem(
        'Why do I see ads?',
        'Kwa nini naona matangazo?',
        'Ads help keep Ungana free to use. They are marked "Ad". Some videos play after a short rewarded ad that asks you first. Ads never ask for your payment details; report any ad that looks like a scam.',
        'Matangazo husaidia Ungana iendelee kutumika bila malipo. Yameandikwa "Ad". Baadhi ya video huchezwa baada ya tangazo fupi la zawadi linalokuuliza kwanza. Matangazo hayaombi taarifa zako za malipo; ripoti tangazo lolote linaloonekana kuwa ulaghai.',
      ),
      FaqItem(
        'The app asks me to update.',
        'App inaniomba nisasishe.',
        'A newer version is available (or required for security). Tap Update and install it from the store. Your account and data are not lost.',
        'Toleo jipya linapatikana (au linahitajika kwa usalama). Bonyeza Sasisha na ulisakinishe kutoka dukani. Akaunti na taarifa zako hazipotei.',
      ),
    ]),

    // ------------------------------------------------------------------ 10
    FaqCategory('trouble', 'Troubleshooting & contact', 'Matatizo na mawasiliano', [
      FaqItem(
        'The app says "Check your connection" or something failed.',
        'App inasema "Angalia mtandao" au kitu kimeshindwa.',
        'Check your internet and try again. Prices, limits and payment options are loaded from the server at start, so reopen the app once you are online. If the problem remains, use Report a Problem and describe what you were doing.',
        'Angalia intaneti na ujaribu tena. Bei, vikomo na njia za malipo hupakiwa kutoka kwenye seva wakati wa kuanza, kwa hiyo fungua app tena ukiwa mtandaoni. Tatizo likiendelea, tumia Ripoti Tatizo na ueleze ulichokuwa unafanya.',
      ),
      FaqItem(
        'I paid but money is missing or charged twice.',
        'Nimelipa lakini pesa hazipo au nimekatwa mara mbili.',
        'Each payment has its own reference and is applied only once, so a retry does not charge you twice. Check the Pocket Fund history for the reference. If a payment left your phone but nothing appears after a few minutes, contact support with the reference, the amount and the SMS from your mobile money provider.',
        'Kila malipo yana namba yake ya rejea na hutekelezwa mara moja tu, kwa hiyo kujaribu tena hakukukati mara mbili. Angalia historia ya Pocket Fund kwa namba ya rejea. Kama malipo yaliondoka kwenye simu yako lakini hakuna kinachoonekana baada ya dakika chache, wasiliana na msaada ukiwa na namba ya rejea, kiasi na ujumbe kutoka kwa mtoa huduma wa pesa za simu.',
      ),
      FaqItem(
        'How do I contact Ungana support?',
        'Ninawasiliana vipi na msaada wa Ungana?',
        'Open Help & Support. When our support contacts are set up you will see Contact Support (WhatsApp, email, phone) and a Call us banner. For anything else use Report a Problem. When you write, include your booking reference, the amount and the time so we can help faster.',
        'Fungua Msaada na Usaidizi. Mawasiliano ya msaada yakiwa yamewekwa utaona Wasiliana na Msaada (WhatsApp, barua pepe, simu) na bango la Tupigie. Kwa jambo lingine tumia Ripoti Tatizo. Ukiandika, weka namba ya oda, kiasi na muda ili tukusaidie haraka.',
      ),
    ]),
  ];
}
