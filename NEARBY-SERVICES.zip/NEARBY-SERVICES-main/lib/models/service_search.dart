import 'models.dart';

/// Category keywords (English + Swahili) so typing "plumber" or "kinyozi" in the
/// search box behaves exactly like picking the Plumbing / Barber category.
class ServiceCategories {
  static const List<String> keys = [
    'Massage', 'Beauty', 'Barber', 'Cleaning', 'Plumbing',
    'Electrical', 'Mechanic', 'Photography', 'Repair', 'General',
  ];

  static const Map<String, List<String>> _keywords = {
    'Massage': ['massage', 'masaji', 'spa'],
    'Beauty': ['beauty', 'urembo', 'saloon', 'salon', 'makeup', 'hair'],
    'Barber': ['barber', 'barbershop', 'kinyozi'],
    'Cleaning': ['cleaning', 'cleaner', 'clean', 'usafi'],
    'Plumbing': ['plumbing', 'plumber', 'bomba', 'fundi bomba'],
    'Electrical': ['electrical', 'electrician', 'umeme', 'fundi umeme'],
    'Mechanic': ['mechanic', 'garage', 'gereji', 'fundi gari'],
    'Photography': ['photography', 'photographer', 'photo', 'photos', 'picha'],
    'Repair': ['repair', 'repairs', 'ukarabati'],
  };

  /// The category api key when [input] is just a category word, otherwise null.
  static String? match(String input) {
    final q = input.trim().toLowerCase();
    if (q.isEmpty) return null;
    for (final e in _keywords.entries) {
      if (e.value.contains(q)) return e.key;
    }
    return null;
  }

  /// Turns a free-text search into (category, text query):
  /// a pure category word becomes a category search, anything else stays a
  /// service-name search inside the chosen category.
  static ({String? category, String? query}) resolve(String text, String? category) {
    final q = text.trim();
    final hasCategory = category != null && category.isNotEmpty && category != 'All';
    if (!hasCategory) {
      final m = match(q);
      if (m != null) return (category: m, query: null);
    }
    return (category: hasCategory ? category : null, query: q.isEmpty ? null : q);
  }
}

/// Strict matching for sensitive (18+) services.
///
/// Normal search is forgiving (the server matches partial text). Sensitive
/// services must NOT surface from a fragment of a word, so a query matches
/// only when at least one of its words is a WHOLE WORD of the service text
/// (any order, extra words in the query are fine):
///
///   sensitive text "Utumbo umetoka"
///     "Utu"                 -> no   (part of a word)
///     "Utumbo"              -> yes  (a whole word)
///     "Utumbo umetoka"      -> yes
///     "Utumbo umetoka sana" -> yes
///     "umetoka Utumbo"      -> yes
///
/// Case, accents and punctuation are ignored.
class StrictMatch {
  static final RegExp _nonWord = RegExp(r'[^\p{L}\p{N}]+', unicode: true);

  static const Map<String, String> _fold = {
    'à': 'a', 'á': 'a', 'â': 'a', 'ã': 'a', 'ä': 'a', 'å': 'a',
    'ç': 'c', 'è': 'e', 'é': 'e', 'ê': 'e', 'ë': 'e',
    'ì': 'i', 'í': 'i', 'î': 'i', 'ï': 'i', 'ñ': 'n',
    'ò': 'o', 'ó': 'o', 'ô': 'o', 'õ': 'o', 'ö': 'o',
    'ù': 'u', 'ú': 'u', 'û': 'u', 'ü': 'u',
  };

  /// Lower-case words with accents folded and punctuation removed.
  static List<String> words(String text) {
    final lower = text.toLowerCase();
    final b = StringBuffer();
    for (final r in lower.runes) {
      final ch = String.fromCharCode(r);
      b.write(_fold[ch] ?? ch);
    }
    return b.toString().split(_nonWord).where((w) => w.isNotEmpty).toList();
  }

  /// True when at least one word of [query] is a whole word of [text].
  /// An empty query matches nothing (strict).
  static bool phrase(String query, String text) {
    final q = words(query);
    if (q.isEmpty) return false;
    final t = words(text).toSet();
    return q.any(t.contains);
  }

  /// Everything a person can search a service by.
  static List<String> searchableText(ServiceItem s) => [
        s.title,
        s.subtitle,
        s.shortDescription,
        s.stageName,
        s.otherLanguage,
        ...s.features,
      ];

  /// Normal services: always pass. Sensitive (18+) services: must match strictly.
  static bool allows(ServiceItem s, String? query) {
    final q = query?.trim() ?? '';
    if (q.isEmpty || !s.is18Plus) return true;
    return searchableText(s).any((t) => phrase(q, t));
  }
}

/// Forgiving search over everything a person can describe a service by: title, full description,
/// short description, the seller's search-only "other language" words, provider name, category, city and every feature (Soup, Pizza, Eggs ...).
///
/// A query matches when EVERY word of it is found inside some word of that text (partial words
/// work: "plum" finds "Plumbing", "pizz" finds the feature "Pizza"; order does not matter; case,
/// accents and punctuation are ignored). Sensitive (18+) services never use this: they keep the
/// strict whole-word rule of [StrictMatch].
class ServiceText {
  ServiceText._();

  /// Everything searched, in one list.
  static List<String> haystack(ServiceItem s) => [
        s.title,
        s.subtitle,
        s.shortDescription,
        s.otherLanguage,
        s.stageName,
        s.businessName ?? '',
        s.category,
        s.city ?? '',
        ...s.features,
      ];

  static bool matches(ServiceItem s, String? query) {
    final q = StrictMatch.words(query ?? '');
    if (q.isEmpty) return false;
    final hay = StrictMatch.words(haystack(s).join(' '));
    return q.every((w) => hay.any((h) => h.contains(w)));
  }

  /// Services the app already holds ([known]) that match [query] by description, features and the
  /// rest, to add to what the server returned (the server may only look at titles). Respects the
  /// chosen [category] and [city] and the caller's [exclude] rule (blocked sellers, 18+ switched
  /// off). Sensitive services must pass the strict whole-word rule. At most [max], best-known first.
  static List<ServiceItem> localMatches(
    Iterable<ServiceItem> known,
    String? query, {
    String? category,
    String? city,
    bool Function(ServiceItem)? exclude,
    int max = 20,
  }) {
    final q = (query ?? '').trim();
    if (q.isEmpty) return const [];
    final cat = (category ?? '').trim().toLowerCase();
    final where = (city ?? '').trim().toLowerCase();
    final out = <ServiceItem>[];
    for (final s in known) {
      if (out.length >= max) break;
      if (exclude != null && exclude(s)) continue;
      if (cat.isNotEmpty && cat != 'all' && s.category.toLowerCase() != cat) continue;
      if (where.isNotEmpty && (s.city ?? s.distance).toLowerCase().trim() != where) continue;
      final hit = s.is18Plus ? StrictMatch.allows(s, q) : matches(s, q);
      if (hit) out.add(s);
    }
    return out;
  }
}

/// Search results split into "near you" and "available elsewhere".
class ServiceSearchResult {
  final List<ServiceItem> nearby;
  final List<ServiceItem> elsewhere;
  const ServiceSearchResult(this.nearby, this.elsewhere);

  bool get isEmpty => nearby.isEmpty && elsewhere.isEmpty;
  bool get hasBoth => nearby.isNotEmpty && elsewhere.isNotEmpty;
  int get total => nearby.length + elsewhere.length;
}

class ServiceSearch {
  /// Radius used for "nearby" when the user did not pick one.
  static const double defaultNearbyKm = 20;

  /// Inside the radius when the distance is known; otherwise same city/region.
  static bool isNearby(ServiceItem s, {required double radiusKm, required String userCity}) {
    final d = s.distanceKm;
    if (d != null) return d <= radiusKm;
    final city = userCity.toLowerCase().trim();
    final c = (s.city ?? s.distance).toLowerCase().trim();
    return city.isNotEmpty && c.isNotEmpty && (c.contains(city) || city.contains(c));
  }

  /// Keeps the incoming order inside each group.
  static ServiceSearchResult split(
    List<ServiceItem> items, {
    required double radiusKm,
    required String userCity,
  }) {
    final near = <ServiceItem>[];
    final far = <ServiceItem>[];
    for (final s in items) {
      (isNearby(s, radiusKm: radiusKm, userCity: userCity) ? near : far).add(s);
    }
    return ServiceSearchResult(near, far);
  }

  /// [primary] first, then anything in [extra] not already present (by id).
  static List<ServiceItem> mergeById(List<ServiceItem> primary, List<ServiceItem> extra) {
    final seen = <String>{};
    final out = <ServiceItem>[];
    for (final s in [...primary, ...extra]) {
      if (seen.add(s.id)) out.add(s);
    }
    return out;
  }
}
