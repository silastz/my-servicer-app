import 'dart:math' as math;

/// What the customer did. Each kind says something different about intent.
enum NeedSignalType { search, categoryOpen, serviceView, favorite, booking }

/// Why a need was predicted (the app turns these into a short sentence).
enum NeedReason { searched, browsed, saved, booked, dueAgain, related, timeOfDay, urgent }

/// One thing the customer did, kept on the phone only.
class NeedEvent {
  final NeedSignalType type;

  /// Category api key ('Plumbing', 'Barber', ...).
  final String category;
  final DateTime at;

  /// Search text (searches only).
  final String? text;

  /// The words used sounded urgent ("emergency", "haraka", ...).
  final bool urgent;

  const NeedEvent({
    required this.type,
    required this.category,
    required this.at,
    this.text,
    this.urgent = false,
  });

  Map<String, dynamic> toJson() => {
        't': type.index,
        'c': category,
        'a': at.millisecondsSinceEpoch,
        if (text != null) 'q': text,
        if (urgent) 'u': 1,
      };

  static NeedEvent? fromJson(Object? raw) {
    if (raw is! Map) return null;
    final t = raw['t'];
    final c = raw['c'];
    final a = raw['a'];
    if (t is! int || t < 0 || t >= NeedSignalType.values.length) return null;
    if (c is! String || c.isEmpty || a is! int) return null;
    return NeedEvent(
      type: NeedSignalType.values[t],
      category: c,
      at: DateTime.fromMillisecondsSinceEpoch(a),
      text: raw['q'] is String ? raw['q'] as String : null,
      urgent: raw['u'] == 1,
    );
  }
}

/// A guess about what the customer needs right now.
class NeedPrediction {
  final String category;

  /// Raw strength (sum of weighted, time-decayed signals).
  final double score;

  /// 0..1, how sure the engine is. Saturates, so one weak hint never looks certain.
  final double confidence;

  /// Strongest reason first.
  final List<NeedReason> reasons;

  /// The customer's most recent search words for this category, if any.
  final String? evidence;

  /// Days since the last booking in this category (for "due again").
  final int? daysSinceBooking;

  /// Recent urgent wording for this category.
  final bool urgent;

  const NeedPrediction({
    required this.category,
    required this.score,
    required this.confidence,
    required this.reasons,
    this.evidence,
    this.daysSinceBooking,
    this.urgent = false,
  });

  NeedReason get topReason => reasons.first;
}

/// Infers what a customer is probably thinking about from what they do.
///
/// Pure Dart, no network, no personal data leaves the phone. The idea:
///  1. every action is a signal with a weight (a booking says more than a view),
///  2. signals fade with a 14-day half-life, so recent thinking wins,
///  3. a finished booking "consumes" the earlier signals in that category
///     (the need is met) and, for repeat services (haircut, cleaning...), the
///     need comes back once the usual gap has passed,
///  4. a booking or favorite also nudges related services (photo -> beauty),
///  5. urgent wording boosts a signal, and time of day / weekday breaks ties.
class NeedEngine {
  NeedEngine._();

  static const double halfLifeDays = 14;
  static const double minConfidence = 0.3;

  static const Map<NeedSignalType, double> _weight = {
    NeedSignalType.search: 3,
    NeedSignalType.categoryOpen: 2,
    NeedSignalType.serviceView: 1.5,
    NeedSignalType.favorite: 4,
    NeedSignalType.booking: 0, // bookings drive cadence + related, not raw interest
  };

  /// Usual days between bookings for services people repeat. Others are omitted.
  static const Map<String, int> _cadenceDays = {
    'Barber': 14,
    'Cleaning': 10,
    'Massage': 30,
    'Beauty': 21,
    'General': 45,
  };

  /// Services that tend to be needed next to each other.
  static const Map<String, List<String>> _related = {
    'Photography': ['Beauty', 'Barber'],
    'Beauty': ['Photography'],
    'Barber': ['Beauty'],
    'Massage': ['Beauty'],
    'Cleaning': ['Repair'],
    'Plumbing': ['Cleaning', 'Repair'],
    'Electrical': ['Repair'],
    'Repair': ['Electrical', 'Plumbing'],
  };

  // ---------------------------------------------------------------------------
  // Reading free text (English + Swahili)
  // ---------------------------------------------------------------------------

  /// phrase -> weight. A phrase matches when a word in the text starts with it
  /// (words of 3 letters or fewer must match exactly).
  static const Map<String, Map<String, double>> _phrases = {
    'Plumbing': {
      'plumb': 1, 'pipe': 1, 'leak': 1, 'tap': 0.8, 'drain': 1, 'toilet': 1,
      'sink': 0.8, 'water heater': 1, 'blocked': 0.6, 'bomba': 1, 'linavuja': 1,
      'choo': 0.8, 'maji': 0.5, 'shower': 0.6, 'tank': 0.4,
    },
    'Electrical': {
      'electric': 1, 'wiring': 1, 'socket': 1, 'power': 0.6, 'blackout': 1,
      'light': 0.5, 'bulb': 0.8, 'fuse': 1, 'umeme': 1, 'taa': 0.7,
      'soketi': 1, 'tanesco': 0.8, 'luku': 0.8, 'solar': 0.8,
    },
    'Mechanic': {
      'mechanic': 1, 'garage': 1, 'engine': 1, 'brake': 1, 'tyre': 1, 'tire': 1,
      'car': 0.6, 'oil change': 1, 'battery': 0.5, 'gari': 0.8, 'gereji': 1,
      'injini': 1, 'breki': 1, 'gurudumu': 1, 'pikipiki': 0.8, 'motorbike': 0.8,
    },
    'Cleaning': {
      'clean': 1, 'laundry': 1, 'sofa': 0.8, 'carpet': 1, 'dirty': 0.7,
      'move out': 0.8, 'usafi': 1, 'kufua': 1, 'zulia': 1, 'chafu': 0.7,
      'fumigat': 0.8, 'pest': 0.8, 'mende': 0.6,
    },
    'Barber': {
      'barber': 1, 'haircut': 1, 'shave': 1, 'beard': 1, 'fade': 0.8,
      'kinyozi': 1, 'kunyoa': 1, 'nyoa': 0.8, 'ndevu': 1, 'nywele': 0.5,
    },
    'Beauty': {
      'beauty': 1, 'makeup': 1, 'nails': 1, 'nail': 0.7, 'braid': 1, 'weave': 1,
      'wig': 1, 'facial': 1, 'manicure': 1, 'pedicure': 1, 'urembo': 1,
      'kusuka': 1, 'rasta': 0.8, 'kucha': 1, 'salon': 1, 'saloon': 1,
      'bridal': 0.8, 'hair': 0.6, 'lashes': 1,
    },
    'Massage': {
      'massage': 1, 'spa': 1, 'back pain': 0.9, 'relax': 0.8, 'stress': 0.5,
      'masaji': 1, 'kupumzika': 0.8, 'uchovu': 0.7, 'sauna': 0.8,
    },
    'Photography': {
      'photo': 1, 'wedding': 0.8, 'video': 0.7, 'shoot': 0.8, 'camera': 0.8,
      'picha': 1, 'harusi': 0.8, 'sherehe': 0.6, 'birthday': 0.5, 'event': 0.4,
      'drone': 0.8,
    },
    'Repair': {
      'repair': 1, 'fix': 0.6, 'broken': 0.8, 'screen': 0.7, 'fridge': 0.9,
      'washing machine': 1, 'ukarabati': 1, 'haifanyi kazi': 0.8, 'friji': 0.9,
      'runinga': 0.8, 'simu': 0.5, 'phone': 0.4, 'imeharibika': 1,
      'kuharibika': 1, 'tv': 0.5,
    },
  };

  static const List<String> _urgentWords = [
    'urgent', 'emergency', 'asap', 'immediately', 'right now', 'tonight',
    'haraka', 'dharura', 'sasa hivi', 'leo hii', 'usiku huu',
  ];

  static String _normalize(String s) =>
      ' ${s.toLowerCase().replaceAll(RegExp(r'[^a-z0-9À-ɏ ]+'), ' ').replaceAll(RegExp(r'\s+'), ' ').trim()} ';

  static bool _hasPhrase(String padded, String phrase) {
    if (phrase.contains(' ')) return padded.contains(' $phrase');
    return phrase.length <= 3 ? padded.contains(' $phrase ') : padded.contains(' $phrase');
  }

  /// category api key -> strength 0..1 for a piece of free text.
  /// Empty map = the words say nothing about a service.
  static Map<String, double> classify(String text) {
    final padded = _normalize(text);
    if (padded.trim().isEmpty) return const {};
    final out = <String, double>{};
    _phrases.forEach((cat, words) {
      var best = 0.0;
      var sum = 0.0;
      words.forEach((phrase, w) {
        if (_hasPhrase(padded, phrase)) {
          best = math.max(best, w);
          sum += w;
        }
      });
      if (best > 0) {
        // strongest phrase decides, extra phrases add a little certainty
        out[cat] = math.min(1.0, best + 0.15 * (sum - best));
      }
    });
    return out;
  }

  /// The single most likely category for [text], or null when unclear.
  static String? bestCategory(String text) {
    final m = classify(text);
    if (m.isEmpty) return null;
    final sorted = m.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    if (sorted.first.value < 0.5) return null;
    if (sorted.length > 1 && sorted.first.value - sorted[1].value < 0.1) return null;
    return sorted.first.key;
  }

  static bool isUrgent(String text) {
    final padded = _normalize(text);
    return _urgentWords.any((w) => padded.contains(' $w'));
  }

  // ---------------------------------------------------------------------------
  // Predicting
  // ---------------------------------------------------------------------------

  static double _decay(Duration age) {
    final days = math.max(0, age.inMinutes) / 1440.0;
    return math.pow(0.5, days / halfLifeDays).toDouble();
  }

  /// Ranked needs, most likely first. Empty when there is not enough history
  /// (the home screen then shows nothing rather than guessing).
  static List<NeedPrediction> predict(
    List<NeedEvent> events, {
    DateTime? now,
    int limit = 3,
    double minConf = minConfidence,
  }) {
    final t = now ?? DateTime.now();
    final usable = events.where((e) => !e.at.isAfter(t.add(const Duration(minutes: 5)))).toList();
    if (usable.isEmpty) return const [];

    // last booking per category: the need was met at that moment
    final lastBooking = <String, DateTime>{};
    for (final e in usable) {
      if (e.type != NeedSignalType.booking) continue;
      final prev = lastBooking[e.category];
      if (prev == null || e.at.isAfter(prev)) lastBooking[e.category] = e.at;
    }

    final score = <String, double>{};
    final why = <String, Map<NeedReason, double>>{};
    final evidence = <String, ({DateTime at, String text})>{};
    final urgentFor = <String>{};

    void add(String cat, NeedReason r, double v) {
      if (v <= 0) return;
      score[cat] = (score[cat] ?? 0) + v;
      final m = why.putIfAbsent(cat, () => {});
      m[r] = (m[r] ?? 0) + v;
    }

    for (final e in usable) {
      final age = t.difference(e.at);
      final decay = _decay(age);

      // related services: only strong, deliberate actions spread to neighbours
      if (e.type == NeedSignalType.booking || e.type == NeedSignalType.favorite) {
        final w = e.type == NeedSignalType.booking ? 4.0 : 4.0 * 0.5;
        for (final rel in _related[e.category] ?? const <String>[]) {
          add(rel, NeedReason.related, 0.35 * w * decay);
        }
      }

      var w = _weight[e.type] ?? 0;
      if (w == 0) continue;
      // Urgent wording matters for a couple of days only.
      if (e.urgent && age.inDays <= 3) {
        w *= 1.5;
        urgentFor.add(e.category);
      }
      // Signals from before the last booking in this category are already served.
      final booked = lastBooking[e.category];
      if (booked != null && !e.at.isAfter(booked)) w *= 0.2;

      final reason = switch (e.type) {
        NeedSignalType.search => NeedReason.searched,
        NeedSignalType.favorite => NeedReason.saved,
        _ => NeedReason.browsed,
      };
      add(e.category, e.urgent && age.inDays <= 3 ? NeedReason.urgent : reason, w * decay);

      final q = e.text;
      if (e.type == NeedSignalType.search && q != null && q.trim().isNotEmpty) {
        final prev = evidence[e.category];
        if (prev == null || e.at.isAfter(prev.at)) evidence[e.category] = (at: e.at, text: q.trim());
      }
    }

    // "Due again": haircut / cleaning / massage... come back after their usual gap.
    final daysSince = <String, int>{};
    lastBooking.forEach((cat, at) {
      final days = t.difference(at).inDays;
      daysSince[cat] = days;
      final cad = _cadenceDays[cat];
      if (cad == null) return;
      final start = cad * 0.8;
      if (days < start || days > cad * 3) return;
      final ramp = math.min(1.0, (days - start) / (cad * 0.4));
      final fade = days <= cad * 1.5 ? 1.0 : math.max(0.0, 1 - (days - cad * 1.5) / (cad * 1.5));
      add(cat, NeedReason.dueAgain, 3.0 * ramp * fade);
    });

    if (score.isEmpty) return const [];

    // Gentle context prior: only breaks ties between categories already in play.
    for (final c in score.keys.toList()) {
      final p = _contextPrior(c, t);
      if (p > 0) add(c, NeedReason.timeOfDay, p);
    }

    final out = <NeedPrediction>[];
    score.forEach((cat, s) {
      final conf = s / (s + 3.0);
      if (conf < minConf) return;
      final reasons = why[cat]!.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
      out.add(NeedPrediction(
        category: cat,
        score: s,
        confidence: conf,
        reasons: reasons.map((e) => e.key).toList(),
        evidence: evidence[cat]?.text,
        daysSinceBooking: daysSince[cat],
        urgent: urgentFor.contains(cat),
      ));
    });
    out.sort((a, b) => b.score.compareTo(a.score));
    return out.take(limit).toList();
  }

  static double _contextPrior(String cat, DateTime t) {
    final weekend = t.weekday == DateTime.saturday || t.weekday == DateTime.sunday;
    final friday = t.weekday == DateTime.friday;
    switch (cat) {
      case 'Beauty':
      case 'Barber':
      case 'Photography':
        return (weekend || friday) ? 0.4 : 0;
      case 'Cleaning':
        return (weekend && t.hour < 12) ? 0.4 : 0;
      case 'Massage':
        return (t.hour >= 17 && t.hour <= 22) ? 0.3 : 0;
      default:
        return 0;
    }
  }
}
