import 'dart:convert';
import 'dart:math';

import 'house_ads.dart';

/// Ad networks the admin can choose from. AdMob is the default whenever the admin has not
/// chosen one or the server sends an unknown value (that is what the app did before this
/// setting existed).
///
/// Facebook = Meta Audience Network, called directly. ironSource = Unity LevelPlay mediation;
/// the Meta and AdMob adapters are bundled with it, so LevelPlay can also fill with their demand.
enum AdProvider {
  admob('ADMOB', 'Google AdMob'),
  facebook('FACEBOOK', 'Facebook Audience Network'),
  ironsource('IRONSOURCE', 'ironSource LevelPlay'),

  /// Our own promotions, pasted by the admin as JSON (see house_ads.dart). Needs no ad network
  /// and no IDs; it can be the default, the choice of one page, or the last network tried.
  /// Handles banner, native and rewarded, can be limited to countries and written per country.
  inhouse('INHOUSE', 'In-house ads'),

  /// Not a network: "show ads from every network". Each ad spot starts with a random one of the
  /// networks that are set up (AdMob, Facebook, ironSource, in-house) and falls back to the others.
  /// It is never requested itself; [AdsConfig.chain] expands it into the real networks.
  all('ALL', 'All networks (mixed)');

  /// Value sent to / received from the backend.
  final String id;

  /// Name for display.
  final String label;

  const AdProvider(this.id, this.label);

  static const AdProvider defaultProvider = AdProvider.admob;

  /// Everything that can really serve an ad: the three networks and the in-house ads ([all] is not one).
  static const List<AdProvider> concrete = [AdProvider.admob, AdProvider.facebook, AdProvider.ironsource, AdProvider.inhouse];

  /// The three real ad networks (the ones that have ad IDs). [inhouse] has none.
  static const List<AdProvider> networks = [AdProvider.admob, AdProvider.facebook, AdProvider.ironsource];

  /// Accepts "admob", "ADMOB", "Facebook", "FAN", "meta", "iron_source", "LevelPlay"... Null if unknown.
  static AdProvider? tryParse(dynamic raw) {
    if (raw is! String) return null;
    final key = raw.toUpperCase().replaceAll(RegExp(r'[\s_\-]'), '');
    switch (key) {
      case 'ADMOB':
      case 'GOOGLE':
      case 'GOOGLEADMOB':
        return AdProvider.admob;
      case 'FACEBOOK':
      case 'FAN':
      case 'META':
      case 'AUDIENCENETWORK':
      case 'FACEBOOKAUDIENCENETWORK':
      case 'METAAUDIENCENETWORK':
        return AdProvider.facebook;
      case 'IRONSOURCE':
      case 'IRONSRC':
      case 'LEVELPLAY':
      case 'UNITYLEVELPLAY':
      case 'IRONSOURCELEVELPLAY':
        return AdProvider.ironsource;
      case 'ALL':
      case 'ALLNETWORKS':
      case 'EVERYTHING':
      case 'MIX':
      case 'MIXED':
        return AdProvider.all;
      case 'INHOUSE':
      case 'INHOUSEADS':
      case 'HOUSE':
      case 'HOUSEADS':
      case 'OWN':
        return AdProvider.inhouse;
    }
    return null;
  }
}

/// The kinds of ad the app shows.
enum AdFormat { banner, native, rewarded }

/// Ad IDs are per platform (an Android ad unit does not work on iOS).
enum AdPlatform { android, ios }

/// The app pages that show ads. The admin can switch the network (and turn ads off) for each.
enum AdPage {
  home('home', 'Home', 'Nyumbani', 'Banner under the hero, native ad in the feed', 'Banner chini ya picha kuu, tangazo kwenye orodha', [AdFormat.banner, AdFormat.native]),
  serviceDetails('serviceDetails', 'Service details', 'Maelezo ya huduma', 'Two banners', 'Mabango mawili', [AdFormat.banner]),
  search('search', 'Search results', 'Matokeo ya utafutaji', 'Native ad between results', 'Tangazo kati ya matokeo', [AdFormat.native]),
  providerProfile('providerProfile', 'Provider profile', 'Wasifu wa mtoa huduma', 'Banner and native ad', 'Bango na tangazo', [AdFormat.banner, AdFormat.native]),
  chats('chats', 'Chats', 'Mazungumzo', 'Native ad in the chat list', 'Tangazo kwenye orodha ya mazungumzo', [AdFormat.native]),
  videoReward('videoReward', 'Video play', 'Kucheza video', 'Rewarded video ad before a provider video', 'Tangazo la video kabla ya video ya mtoa huduma', [AdFormat.rewarded]);

  final String id;
  final String labelEn;
  final String labelSw;
  final String noteEn;
  final String noteSw;

  /// Ad formats this page uses.
  final List<AdFormat> formats;

  const AdPage(this.id, this.labelEn, this.labelSw, this.noteEn, this.noteSw, this.formats);

  static AdPage? tryParse(dynamic raw) {
    if (raw is! String) return null;
    final key = raw.toLowerCase().replaceAll(RegExp(r'[\s_\-]'), '');
    for (final p in AdPage.values) {
      if (p.id.toLowerCase() == key) return p;
    }
    return null;
  }
}

/// One page's switch: on/off, and which network it uses ([provider] null = follow the default).
class AdPageSetting {
  final bool enabled;
  final AdProvider? provider;

  const AdPageSetting({this.enabled = true, this.provider});

  AdPageSetting copyWith({bool? enabled, AdProvider? provider, bool clearProvider = false}) =>
      AdPageSetting(enabled: enabled ?? this.enabled, provider: clearProvider ? null : (provider ?? this.provider));

  Map<String, dynamic> toJson() => {'enabled': enabled, 'provider': provider?.id ?? 'DEFAULT'};

  /// "DEFAULT", missing or an unknown value all mean "follow the default network".
  factory AdPageSetting.fromJson(dynamic j) {
    if (j is! Map) return const AdPageSetting();
    return AdPageSetting(enabled: j['enabled'] != false, provider: AdProvider.tryParse(j['provider']));
  }
}

/// Which text field of an ad network a value belongs to.
class AdIdRules {
  AdIdRules._();

  static const int maxLength = 64;

  static final RegExp _admobUnit = RegExp(r'^ca-app-pub-\d{16}/\d{10}$');
  // Facebook placement: 1234567890123456_1234567890123456, optionally with a test prefix
  // such as IMG_16_9_APP_INSTALL#.
  static final RegExp _fbPlacement = RegExp(r'^(?:[A-Za-z0-9_]{3,40}#)?\d{8,20}_\d{8,20}$');
  static final RegExp _lpKey = RegExp(r'^[A-Za-z0-9]{5,40}$');
  static final RegExp _lpPlacement = RegExp(r'^[A-Za-z0-9 _\-]{1,40}$');

  /// A blank value is always fine (it means "not set"). Otherwise it must look like a real ID of
  /// that network, which also catches an AdMob app ID (it has a "~") pasted where a unit ID goes.
  static bool valid(AdProvider p, AdFormat f, String raw) {
    final v = raw.trim();
    if (v.isEmpty) return true;
    if (v.length > maxLength) return false;
    switch (p) {
      case AdProvider.admob:
        return _admobUnit.hasMatch(v);
      case AdProvider.facebook:
        return _fbPlacement.hasMatch(v);
      case AdProvider.ironsource:
        // ironSource ad unit IDs for banner / rewarded; the native "ID" is an optional placement name.
        return f == AdFormat.native ? _lpPlacement.hasMatch(v) : _lpKey.hasMatch(v);
      case AdProvider.inhouse:
      case AdProvider.all:
        return true; // in-house ads have no IDs; "all" is not a network
    }
  }

  /// ironSource app key.
  static bool validAppKey(String raw) {
    final v = raw.trim();
    return v.isEmpty || _lpKey.hasMatch(v);
  }
}

/// Google's official test ad units (always safe to show).
class AdmobTestIds {
  AdmobTestIds._();

  static String of(AdPlatform platform, AdFormat format) {
    final android = platform == AdPlatform.android;
    switch (format) {
      case AdFormat.banner:
        return android ? 'ca-app-pub-3940256099942544/6300978111' : 'ca-app-pub-3940256099942544/2934735716';
      case AdFormat.native:
        return android ? 'ca-app-pub-3940256099942544/2247696110' : 'ca-app-pub-3940256099942544/3986624511';
      case AdFormat.rewarded:
        return android ? 'ca-app-pub-3940256099942544/5224354917' : 'ca-app-pub-3940256099942544/1712485313';
    }
  }
}

/// The IDs of one network on one platform. [appKey] is used by ironSource only.
class AdUnitIds {
  final String appKey;
  final String banner;
  final String native;
  final String rewarded;

  const AdUnitIds({this.appKey = '', this.banner = '', this.native = '', this.rewarded = ''});

  String of(AdFormat f) {
    switch (f) {
      case AdFormat.banner:
        return banner;
      case AdFormat.native:
        return native;
      case AdFormat.rewarded:
        return rewarded;
    }
  }

  AdUnitIds copyWith({String? appKey, String? banner, String? native, String? rewarded}) => AdUnitIds(
        appKey: appKey ?? this.appKey,
        banner: banner ?? this.banner,
        native: native ?? this.native,
        rewarded: rewarded ?? this.rewarded,
      );

  Map<String, dynamic> toJson(AdProvider p) => {
        if (p == AdProvider.ironsource) 'appKey': appKey.trim(),
        'banner': banner.trim(),
        'native': native.trim(),
        'rewarded': rewarded.trim(),
      };

  /// Keeps only values that look like real IDs of [p]: anything else becomes blank
  /// (= that format is not available on this network).
  factory AdUnitIds.fromJson(AdProvider p, dynamic j) {
    if (j is! Map) return const AdUnitIds();
    String id(AdFormat f, String key) {
      final v = (j[key] ?? '').toString().trim();
      return AdIdRules.valid(p, f, v) ? v : '';
    }

    final key = (j['appKey'] ?? '').toString().trim();
    return AdUnitIds(
      appKey: p == AdProvider.ironsource && AdIdRules.validAppKey(key) ? key : '',
      banner: id(AdFormat.banner, 'banner'),
      native: id(AdFormat.native, 'native'),
      rewarded: id(AdFormat.rewarded, 'rewarded'),
    );
  }
}

/// Everything the admin controls about ads (see docs/ads_config_api_contract.md):
/// the master switch, test mode, the default network, the network for each page and
/// the ad IDs of each network. None of it is secret: ad unit IDs are inside every app anyway.
///
/// The app downloads it, keeps the last answer on the phone and falls back to [defaults]
/// (AdMob test ads) when it has never heard from the server.
class AdsConfig {
  /// Master switch: false = no ads anywhere.
  final bool enabled;

  /// true = safe test ads: Google sample ads for AdMob, test requests for Facebook.
  /// (ironSource has no test IDs: use a test device in the LevelPlay dashboard.)
  final bool testMode;

  /// Network used by every page that has no choice of its own.
  final AdProvider defaultProvider;

  /// When the chosen network has no ID or no ad to show, try the other networks.
  final bool autoFallback;

  final Map<AdPage, AdPageSetting> pages;
  final Map<AdProvider, Map<AdPlatform, AdUnitIds>> units;

  /// The admin's own ads (JSON), shown by [AdProvider.inhouse].
  final List<HouseAd> house;

  const AdsConfig({
    this.enabled = true,
    this.testMode = true,
    this.defaultProvider = AdProvider.admob,
    this.autoFallback = true,
    this.pages = const {},
    this.units = const {},
    this.house = const [],
  });

  /// What the app does before it has heard from the server (same as the old fixed setup).
  static const AdsConfig defaults = AdsConfig();

  AdPageSetting page(AdPage p) => pages[p] ?? const AdPageSetting();

  /// The network a page asks for first.
  AdProvider providerFor(AdPage p) => page(p).provider ?? defaultProvider;

  AdUnitIds idsOf(AdProvider p, AdPlatform platform) => units[p]?[platform] ?? const AdUnitIds();

  /// The ID to request for [format]. AdMob in test mode always uses Google's test units.
  String unitId(AdProvider p, AdPlatform platform, AdFormat format) {
    if (p == AdProvider.admob && testMode) return AdmobTestIds.of(platform, format);
    return idsOf(p, platform).of(format).trim();
  }

  /// [p] has what it needs to request [format] on [platform].
  bool hasUnit(AdProvider p, AdPlatform platform, AdFormat format) {
    if (p == AdProvider.ironsource) {
      // The native ad is requested by placement name (optional), the others by ad unit ID.
      if (idsOf(p, platform).appKey.trim().isEmpty) return false;
      return format == AdFormat.native || unitId(p, platform, format).isNotEmpty;
    }
    return unitId(p, platform, format).isNotEmpty;
  }

  /// A page set to [AdProvider.all] starts with a random network (use [random] to fix it in tests).
  ///
  /// The networks to try for [page] / [format], best first: the page's own choice, then the
  /// default, then the rest. Only networks that [hasUnit] and are [available] stay in. Without
  /// [autoFallback] the list has at most the page's own choice.
  ///
  /// [country] (ISO code of the person's country) decides which in-house ads qualify.
  List<AdProvider> chain(AdPage page, AdFormat format, AdPlatform platform,
      {bool Function(AdProvider)? available, String? country, Random? random}) {
    if (!enabled || !this.page(page).enabled) return const [];
    final order = <AdProvider>[..._expand(providerFor(page), random)];
    if (autoFallback) {
      order
        ..addAll(_expand(defaultProvider, random))
        ..addAll(AdProvider.concrete);
    }
    final seen = <AdProvider>{};
    return [
      for (final p in order)
        if (seen.add(p) &&
            (p == AdProvider.inhouse
                ? houseFor(page, format, platform, country: country).isNotEmpty
                : hasUnit(p, platform, format)) &&
            (available?.call(p) ?? true))
          p,
    ];
  }

  /// [AdProvider.all] becomes every real network in a random order; any other choice stays itself.
  static List<AdProvider> _expand(AdProvider p, Random? random) =>
      p == AdProvider.all ? ([...AdProvider.concrete]..shuffle(random)) : [p];

  /// [p] can show something on [platform]: it has an ID for some format, there is an in-house ad
  /// for that platform, or ([AdProvider.all]) any of those is true for some network.
  bool canShow(AdProvider p, AdPlatform platform) {
    switch (p) {
      case AdProvider.all:
        return AdProvider.concrete.any((x) => canShow(x, platform));
      case AdProvider.inhouse:
        return house.any((a) => a.enabled && a.platforms.contains(platform));
      default:
        return AdFormat.values.any((f) => hasUnit(p, platform, f));
    }
  }

  /// The admin's own ads that may show on [page] as [format] on [platform] right now
  /// (enabled, inside their dates, listed for that page / format / platform / [country]).
  List<HouseAd> houseFor(AdPage page, AdFormat format, AdPlatform platform, {DateTime? now, String? country}) {
    final t = now ?? DateTime.now();
    return [for (final a in house) if (a.matches(page, format, platform, t, country: country)) a];
  }

  AdsConfig copyWith({
    bool? enabled,
    bool? testMode,
    AdProvider? defaultProvider,
    bool? autoFallback,
    Map<AdPage, AdPageSetting>? pages,
    Map<AdProvider, Map<AdPlatform, AdUnitIds>>? units,
    List<HouseAd>? house,
  }) =>
      AdsConfig(
        enabled: enabled ?? this.enabled,
        testMode: testMode ?? this.testMode,
        defaultProvider: defaultProvider ?? this.defaultProvider,
        autoFallback: autoFallback ?? this.autoFallback,
        pages: pages ?? this.pages,
        units: units ?? this.units,
        house: house ?? this.house,
      );

  Map<String, dynamic> toJson() => {
        'enabled': enabled,
        'testMode': testMode,
        'defaultProvider': defaultProvider.id,
        'autoFallback': autoFallback,
        'pages': {for (final p in AdPage.values) p.id: page(p).toJson()},
        'units': {
          for (final p in AdProvider.networks)
            p.name: {
              for (final pl in AdPlatform.values) pl.name: idsOf(p, pl).toJson(p),
            },
        },
        'house': [for (final a in house) a.toJson()],
      };

  /// Same settings (ignores how the maps were built).
  bool sameAs(AdsConfig other) => jsonEncode(toJson()) == jsonEncode(other.toJson());

  /// Accepts the object itself or `{data: {...}}`. Invalid values are dropped, so a bad server
  /// answer can never put a malformed ID into an ad request. Null when [raw] is not an object.
  static AdsConfig? tryParse(dynamic raw) {
    final d = raw is Map && raw['data'] is Map ? raw['data'] : raw;
    if (d is! Map) return null;

    final pagesJson = d['pages'] is Map ? d['pages'] as Map : const {};
    final pages = <AdPage, AdPageSetting>{};
    pagesJson.forEach((k, v) {
      final page = AdPage.tryParse(k);
      if (page != null) pages[page] = AdPageSetting.fromJson(v);
    });

    final unitsJson = d['units'] is Map ? d['units'] as Map : const {};
    final units = <AdProvider, Map<AdPlatform, AdUnitIds>>{};
    unitsJson.forEach((k, v) {
      final provider = AdProvider.tryParse(k);
      if (provider == null || v is! Map) return;
      units[provider] = {
        for (final pl in AdPlatform.values) pl: AdUnitIds.fromJson(provider, v[pl.name]),
      };
    });

    return AdsConfig(
      enabled: d['enabled'] != false, // missing = on
      testMode: d['testMode'] != false, // missing = test ads (safe)
      defaultProvider: AdProvider.tryParse(d['defaultProvider']) ?? AdProvider.defaultProvider,
      autoFallback: d['autoFallback'] != false, // missing = on
      pages: pages,
      units: units,
      house: HouseAds.parse(d['house']).ads, // an invalid ad is skipped, the valid ones stay
    );
  }

  /// [raw] (a server answer) carries at least one ad setting. A phone uses this before applying an
  /// answer, so an unrelated reply (`{}`, an error body sent with 200) never resets the settings.
  static bool looksLikeConfig(dynamic raw) {
    final d = raw is Map && raw['data'] is Map ? raw['data'] : raw;
    if (d is! Map) return false;
    const keys = ['enabled', 'testMode', 'defaultProvider', 'autoFallback', 'pages', 'units', 'house'];
    return keys.any(d.containsKey);
  }
}
