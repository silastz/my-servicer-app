/// Admin: the login the server uses to look up the name registered for a NIN (Verify My Legal Name).
/// The password is write-only: the server never returns it, only [passwordSet].
class IdentityLookupConfig {
  final String username;
  final bool passwordSet;

  /// ADMIN = saved in the app, CONFIG = the server's own first-install login, NONE = nothing yet.
  final String source;
  final DateTime? updatedAt;

  const IdentityLookupConfig({
    required this.username,
    required this.passwordSet,
    this.source = 'NONE',
    this.updatedAt,
  });

  bool get isComplete => username.trim().isNotEmpty && passwordSet;

  /// Reads the server answer (also accepts a {"data": {...}} wrapper). Null when it is not an object.
  static IdentityLookupConfig? tryParse(dynamic raw) {
    final d = raw is Map && raw['data'] is Map ? raw['data'] as Map : raw;
    if (d is! Map) return null;
    final user = d['username']?.toString().trim() ?? '';
    final at = d['updatedAt'] == null ? null : DateTime.tryParse(d['updatedAt'].toString());
    final src = (d['source'] ?? 'NONE').toString().toUpperCase();
    return IdentityLookupConfig(
      username: user == 'null' ? '' : user,
      passwordSet: d['passwordSet'] == true,
      source: (src == 'ADMIN' || src == 'CONFIG') ? src : 'NONE',
      updatedAt: at,
    );
  }
}

/// Result of "Test login".
class IdentityLookupTestResult {
  final bool success;
  final String? message;
  const IdentityLookupTestResult(this.success, [this.message]);
}

/// Checks done on the phone before saving (the server checks again).
class IdentityLookupRules {
  IdentityLookupRules._();

  static final RegExp _userOk = RegExp(r'^[\p{L}\p{N}._@+\-]{1,100}$', unicode: true);

  /// null = fine, 'empty' = nothing typed, 'invalid' = characters not allowed.
  static String? username(String raw) {
    final t = raw.trim();
    if (t.isEmpty) return 'empty';
    return _userOk.hasMatch(t) ? null : 'invalid';
  }

  /// A blank password is fine (it means "keep the saved one"). Otherwise: max 200, no control characters.
  static String? password(String raw) {
    if (raw.isEmpty) return null;
    if (raw.length > 200) return 'invalid';
    for (final unit in raw.runes) {
      if (unit < 32 || unit == 127) return 'invalid';
    }
    return null;
  }
}
