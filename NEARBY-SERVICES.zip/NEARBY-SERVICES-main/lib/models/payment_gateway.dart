/// Payment gateways the admin can choose from. The admin picks the active one in the
/// admin panel (sent in the app policy as `payments.gateway`); [snippe] is the default
/// whenever the admin has not chosen one or sends an unknown value.
///
/// The app only passes the choice along: the backend creates the real checkout / mobile
/// prompt with that gateway and must verify the result itself.
enum PaymentGateway {
  dpo('DPO', 'DPO'),
  snippe('SNIPPE', 'Snippe'),
  clickPesa('CLICKPESA', 'ClickPesa'),
  selcom('SELCOM', 'Selcom'),
  pesaPal('PESAPAL', 'PesaPal');

  /// Value sent to / received from the backend.
  final String id;

  /// Name for display.
  final String label;

  const PaymentGateway(this.id, this.label);

  /// The gateway used when the admin has not set one.
  static const PaymentGateway defaultGateway = PaymentGateway.snippe;

  /// Accepts "snippe", "SNIPPE", "Click Pesa", "click_pesa", "pesa-pal"... Null if unknown.
  static PaymentGateway? tryParse(dynamic raw) {
    if (raw is! String) return null;
    final key = raw.toUpperCase().replaceAll(RegExp(r'[\s_\-]'), '');
    for (final g in PaymentGateway.values) {
      if (g.id == key) return g;
    }
    return null;
  }
}
