import 'dart:convert';
import 'dart:math';

import 'ads_config.dart';

/// In-house ads: our own promotions that the admin pastes as JSON in Profile > Admin > Ads.
/// They need no ad network and no ad IDs, and they handle **every ad format the app has**:
/// `banner`, `native` and `rewarded` (the full-screen ad before a provider video).
///
/// JSON the admin pastes (either `{ "ads": [ ... ] }` or just the list):
/// ```json
/// {
///   "ads": [
///     {
///       "id": "summer-promo",
///       "title": "Plumbers near you",
///       "body": "Book a verified plumber today.",
///       "imageUrl": "https://example.com/promo.jpg",
///       "cta": "Book now",
///       "url": "https://example.com/plumbers",
///       "formats": ["banner", "native", "rewarded"],
///       "pages": ["home", "search", "videoReward"],
///       "platforms": ["android", "ios"],
///       "countries": ["TZ", "KE"],
///       "title_TZ": "Mafundi bomba karibu nawe",
///       "cta_TZ": "Weka oda",
///       "title_KE": "Plumbers in Nairobi",
///       "cta_KE": "Book now",
///       "rewardSeconds": 5,
///       "weight": 3,
///       "start": "2026-11-01T00:00:00Z",
///       "end": "2026-11-30T23:59:59Z",
///       "enabled": true
///     }
///   ]
/// }
/// ```
/// Only `id`, `title`, `imageUrl` and `url` are required. Everything else has a default: banner +
/// native, every page that shows those formats, both platforms, every country, weight 1, no dates,
/// enabled.
///
/// **Countries.** `countries` (ISO codes like "TZ", "KE") limits who sees the ad: only people whose
/// country is listed. No `countries` = every country. An ad with a country list is never shown
/// while the person's country is unknown.
///
/// **Text per country.** Any of `title`, `body`, `cta`, `imageUrl` and `url` can be overridden for
/// one country with a suffix: `title_TZ`, `body_KE`, `cta_TZ`, `imageUrl_KE`, `url_TZ` (`TZtitle`,
/// `TZ_cta` also work). A person in that country sees the override; everyone else sees the plain
/// field. The plain `title`, `imageUrl` and `url` stay required.
class HouseAd {
  final String id;
  final String title;
  final String body;
  final String cta;
  final String imageUrl;
  final String url;
  final Set<AdFormat> formats;
  final Set<AdPage> pages;
  final Set<AdPlatform> platforms;

  /// Countries (upper-case ISO codes) that may see the ad. Empty = every country.
  final Set<String> countries;

  /// Text overrides per country: `{'TZ': {'title': ..., 'cta': ...}}` (see [forCountry]).
  final Map<String, Map<String, String>> local;

  /// Rewarded format: seconds on screen before the reward is earned.
  final int rewardSeconds;
  final int weight;
  final DateTime? start;
  final DateTime? end;
  final bool enabled;

  const HouseAd({
    required this.id,
    required this.title,
    required this.imageUrl,
    required this.url,
    this.body = '',
    this.cta = 'Open',
    this.formats = const {AdFormat.banner, AdFormat.native},
    this.pages = const {AdPage.home, AdPage.serviceDetails, AdPage.search, AdPage.providerProfile, AdPage.chats},
    this.platforms = const {AdPlatform.android, AdPlatform.ios},
    this.countries = const {},
    this.local = const {},
    this.rewardSeconds = HouseAds.defaultRewardSeconds,
    this.weight = 1,
    this.start,
    this.end,
    this.enabled = true,
  });

  /// This ad may be shown on [page] as [format] on [platform] at time [now] to a person in
  /// [country] (ISO code; null / empty = not known).
  bool matches(AdPage page, AdFormat format, AdPlatform platform, DateTime now, {String? country}) {
    if (!enabled) return false;
    if (!formats.contains(format) || !pages.contains(page) || !platforms.contains(platform)) return false;
    if (!inCountry(country)) return false;
    if (start != null && now.isBefore(start!)) return false;
    if (end != null && now.isAfter(end!)) return false;
    return true;
  }

  /// No country list, or [country] is on it.
  bool inCountry(String? country) {
    if (countries.isEmpty) return true;
    final c = (country ?? '').trim().toUpperCase();
    return c.isNotEmpty && countries.contains(c);
  }

  /// The ad as a person in [country] should see it: the country's own title / body / cta / image /
  /// link where the admin wrote them, the plain fields everywhere else.
  HouseAd forCountry(String? country) {
    final o = local[(country ?? '').trim().toUpperCase()];
    if (o == null || o.isEmpty) return this;
    return HouseAd(
      id: id,
      title: o['title'] ?? title,
      body: o['body'] ?? body,
      cta: o['cta'] ?? cta,
      imageUrl: o['imageUrl'] ?? imageUrl,
      url: o['url'] ?? url,
      formats: formats,
      pages: pages,
      platforms: platforms,
      countries: countries,
      local: local,
      rewardSeconds: rewardSeconds,
      weight: weight,
      start: start,
      end: end,
      enabled: enabled,
    );
  }

  Map<String, dynamic> toJson() {
    final codes = local.keys.toList()..sort();
    return {
      'id': id,
      'title': title,
      if (body.isNotEmpty) 'body': body,
      'cta': cta,
      'imageUrl': imageUrl,
      'url': url,
      'formats': [for (final f in AdFormat.values) if (formats.contains(f)) f.name],
      'pages': [for (final p in AdPage.values) if (pages.contains(p)) p.id],
      'platforms': [for (final p in AdPlatform.values) if (platforms.contains(p)) p.name],
      if (countries.isNotEmpty) 'countries': (countries.toList()..sort()),
      for (final c in codes)
        for (final f in HouseAds.localFields)
          if (local[c]![f] != null) '${f}_$c': local[c]![f],
      if (formats.contains(AdFormat.rewarded)) 'rewardSeconds': rewardSeconds,
      'weight': weight,
      if (start != null) 'start': start!.toUtc().toIso8601String(),
      if (end != null) 'end': end!.toUtc().toIso8601String(),
      'enabled': enabled,
    };
  }
}

/// Result of reading the admin's JSON: the ads that are valid and a plain-language list of what is wrong.
class HouseParse {
  final List<HouseAd> ads;
  final List<String> errors;
  const HouseParse(this.ads, this.errors);

  bool get ok => errors.isEmpty;
}

class HouseAds {
  HouseAds._();

  /// Most ads one JSON may hold, and the longest JSON text the admin screen accepts.
  static const int maxAds = 20;
  static const int maxJsonChars = 60000;

  /// Rewarded format: seconds before the reward, default and allowed range.
  static const int defaultRewardSeconds = 5;
  static const int minRewardSeconds = 3;
  static const int maxRewardSeconds = 30;

  static final RegExp _id = RegExp(r'^[A-Za-z0-9_\-]{1,40}$');
  static final RegExp _country = RegExp(r'^[A-Za-z]{2}$');

  /// Fields that can be written once per country (`title_TZ`).
  static const List<String> localFields = ['title', 'body', 'cta', 'imageUrl', 'url'];

  static const Map<String, int> _localMax = {'title': 60, 'body': 140, 'cta': 24, 'imageUrl': 500, 'url': 500};

  static const String _fieldAlt = 'title|body|cta|imageUrl|url';
  // title_TZ, titleTZ, title-tz  /  TZ_title, TZtitle
  static final RegExp _localSuffix = RegExp('^($_fieldAlt)[_\\-]?([A-Za-z]{2})\$', caseSensitive: false);
  static final RegExp _localPrefix = RegExp('^([A-Za-z]{2})[_\\-]?($_fieldAlt)\$', caseSensitive: false);
  // Looks like a per-country key (title_...) but is not a valid one: reported instead of ignored.
  static final RegExp _localAttempt = RegExp('^($_fieldAlt)[_\\-]', caseSensitive: false);

  /// Pages that house ads can appear on: every page that shows an ad.
  static const List<AdPage> pagesWithHouse = [
    AdPage.home,
    AdPage.serviceDetails,
    AdPage.search,
    AdPage.providerProfile,
    AdPage.chats,
    AdPage.videoReward,
  ];

  /// The pages an ad is shown on when the admin gives no `pages`: every page that shows at least
  /// one of the ad's [formats]. (Banner + native: the five normal pages; rewarded: the video page.)
  static Set<AdPage> defaultPages(Set<AdFormat> formats) =>
      {for (final p in pagesWithHouse) if (p.formats.any(formats.contains)) p};

  /// An image or link the app will open: https only, no user:password@, sensible length.
  static bool validUrl(String v) {
    if (v.length > 500) return false;
    final u = Uri.tryParse(v);
    return u != null && u.scheme == 'https' && u.host.contains('.') && u.userInfo.isEmpty;
  }

  /// Reads the text the admin typed. Empty text = no house ads, no errors.
  static HouseParse parseText(String text) {
    final t = text.trim();
    if (t.isEmpty) return const HouseParse([], []);
    if (t.length > maxJsonChars) return HouseParse(const [], ['The JSON is too long (max $maxJsonChars characters).']);
    try {
      return parse(jsonDecode(t));
    } on FormatException catch (e) {
      return HouseParse(const [], ['Not valid JSON: ${e.message}']);
    }
  }

  /// Reads decoded JSON: a list of ads, or an object with an `ads` (or `house`) list.
  /// Valid ads are kept even when others are wrong, so a phone never loses all house ads for one typo;
  /// the admin screen refuses to save while [HouseParse.errors] is not empty.
  static HouseParse parse(dynamic raw) {
    dynamic list = raw;
    if (raw is Map) list = raw['ads'] ?? raw['house'];
    if (list == null) return const HouseParse([], []);
    if (list is! List) return const HouseParse([], ['Expected a list of ads, for example {"ads": [ ... ]}.']);

    final errors = <String>[];
    final ads = <HouseAd>[];
    final seen = <String>{};
    if (list.length > maxAds) errors.add('Too many ads (${list.length}). The most allowed is $maxAds.');

    for (var i = 0; i < list.length && i < maxAds; i++) {
      final j = list[i];
      final at = 'Ad ${i + 1}';
      if (j is! Map) {
        errors.add('$at: must be an object { ... }.');
        continue;
      }
      final before = errors.length;

      /// Reads text from [source] under [key] (named [label] in messages).
      String textOf(Map source, String key, {String? label, int max = 100, bool must = false}) {
        final name = label ?? key;
        final v = source[key];
        if (v == null) {
          if (must) errors.add('$at: "$name" is required.');
          return '';
        }
        if (v is! String) {
          errors.add('$at: "$name" must be text.');
          return '';
        }
        final s = v.trim();
        if (must && s.isEmpty) errors.add('$at: "$name" is required.');
        if (s.length > max) {
          errors.add('$at: "$name" is too long (max $max characters).');
          return '';
        }
        return s;
      }

      String text(String key, {int max = 100, bool must = false}) => textOf(j, key, max: max, must: must);

      final id = text('id', max: 40, must: true);
      if (id.isNotEmpty && !_id.hasMatch(id)) errors.add('$at: "id" may only use letters, numbers, - and _.');
      if (id.isNotEmpty && !seen.add(id)) errors.add('$at: id "$id" is used twice.');
      final title = text('title', max: 60, must: true);
      final body = text('body', max: 140);
      var cta = text('cta', max: 24);
      if (cta.isEmpty) cta = 'Open';
      final image = text('imageUrl', max: 500, must: true);
      if (image.isNotEmpty && !validUrl(image)) errors.add('$at: "imageUrl" must be a full https:// link.');
      final url = text('url', max: 500, must: true);
      if (url.isNotEmpty && !validUrl(url)) errors.add('$at: "url" must be a full https:// link.');

      Set<T> choose<T>(String key, Iterable<T> all, String Function(T) name, Set<T>? fallback) {
        final v = j[key];
        if (v == null) return fallback ?? {};
        if (v is! List || v.isEmpty) {
          errors.add('$at: "$key" must be a list like ["${name(all.first)}"].');
          return fallback ?? {};
        }
        final out = <T>{};
        for (final x in v) {
          T? hit;
          for (final a in all) {
            if (x is String && name(a).toLowerCase() == x.toLowerCase()) hit = a;
          }
          if (hit == null) {
            errors.add('$at: "$x" is not valid in "$key". Use: ${all.map(name).join(', ')}.');
          } else {
            out.add(hit);
          }
        }
        return out.isEmpty ? (fallback ?? {}) : out;
      }

      const defaults = HouseAd(id: '', title: '', imageUrl: '', url: '');
      final formats = choose<AdFormat>('formats', AdFormat.values, (f) => f.name, defaults.formats);
      final pages = choose<AdPage>('pages', pagesWithHouse, (p) => p.id, defaultPages(formats));
      final platforms = choose<AdPlatform>('platforms', AdPlatform.values, (p) => p.name, defaults.platforms);

      // Countries that may see the ad (none listed = everyone).
      final countries = <String>{};
      final cs = j['countries'];
      if (cs != null) {
        if (cs is! List || cs.isEmpty) {
          errors.add('$at: "countries" must be a list like ["TZ", "KE"].');
        } else {
          for (final x in cs) {
            if (x is String && _country.hasMatch(x.trim())) {
              countries.add(x.trim().toUpperCase());
            } else {
              errors.add('$at: "$x" is not a country code in "countries". Use 2 letters like TZ or KE.');
            }
          }
        }
      }

      // Text per country: title_TZ, cta_KE, TZbody ...
      final local = <String, Map<String, String>>{};
      for (final key in j.keys) {
        if (key is! String) continue;
        final m = _localSuffix.firstMatch(key);
        final p = m == null ? _localPrefix.firstMatch(key) : null;
        if (m == null && p == null) {
          if (_localAttempt.hasMatch(key)) {
            errors.add('$at: "$key" is not understood. Write a field and a 2-letter country, like title_TZ or cta_KE.');
          }
          continue;
        }
        final fieldRaw = (m ?? p)!.group(m != null ? 1 : 2)!;
        final country = (m ?? p)!.group(m != null ? 2 : 1)!.toUpperCase();
        final field = localFields.firstWhere((f) => f.toLowerCase() == fieldRaw.toLowerCase());
        final v = textOf(j, key, max: _localMax[field]!);
        if (v.isEmpty) continue; // blank = use the plain field
        if ((field == 'imageUrl' || field == 'url') && !validUrl(v)) {
          errors.add('$at: "$key" must be a full https:// link.');
          continue;
        }
        final slot = local.putIfAbsent(country, () => {});
        if (slot.containsKey(field)) {
          errors.add('$at: "$field" for $country is written twice ("$key").');
          continue;
        }
        slot[field] = v;
      }

      var rewardSeconds = defaultRewardSeconds;
      final rs = j['rewardSeconds'];
      if (rs != null) {
        if (rs is num && rs == rs.roundToDouble() && rs >= minRewardSeconds && rs <= maxRewardSeconds) {
          rewardSeconds = rs.toInt();
        } else {
          errors.add('$at: "rewardSeconds" must be a whole number from $minRewardSeconds to $maxRewardSeconds.');
        }
      }

      var weight = 1;
      final w = j['weight'];
      if (w != null) {
        if (w is num && w == w.roundToDouble() && w >= 1 && w <= 100) {
          weight = w.toInt();
        } else {
          errors.add('$at: "weight" must be a whole number from 1 to 100.');
        }
      }

      DateTime? date(String key) {
        final v = j[key];
        if (v == null) return null;
        final d = v is String ? DateTime.tryParse(v) : null;
        if (d == null) errors.add('$at: "$key" must be a date like 2026-11-30T23:59:59Z.');
        return d;
      }

      final start = date('start');
      final end = date('end');
      if (start != null && end != null && !end.isAfter(start)) errors.add('$at: "end" must be after "start".');

      final enabled = j['enabled'];
      if (enabled != null && enabled is! bool) errors.add('$at: "enabled" must be true or false.');

      if (errors.length == before) {
        ads.add(HouseAd(
          id: id,
          title: title,
          body: body,
          cta: cta,
          imageUrl: image,
          url: url,
          formats: formats,
          pages: pages,
          platforms: platforms,
          countries: countries,
          local: local,
          rewardSeconds: rewardSeconds,
          weight: weight,
          start: start,
          end: end,
          enabled: enabled != false,
        ));
      }
    }
    return HouseParse(ads, errors);
  }

  /// The admin's example (also what the "Insert example" button writes): one banner / native ad
  /// with its own text for Tanzania and Kenya, and one rewarded video-page ad for everyone.
  static const String example = '''{
  "ads": [
    {
      "id": "plumbers-promo",
      "title": "Plumbers near you",
      "body": "Book a verified plumber today.",
      "imageUrl": "https://example.com/promo.jpg",
      "cta": "Book now",
      "url": "https://example.com/plumbers",
      "formats": ["banner", "native"],
      "pages": ["home", "search"],
      "countries": ["TZ", "KE"],
      "title_TZ": "Mafundi bomba karibu nawe",
      "body_TZ": "Weka oda ya fundi aliyethibitishwa leo.",
      "cta_TZ": "Weka oda",
      "title_KE": "Plumbers in Nairobi",
      "cta_KE": "Book in Nairobi",
      "weight": 3,
      "start": "2026-11-01T00:00:00Z",
      "end": "2026-11-30T23:59:59Z"
    },
    {
      "id": "video-promo",
      "title": "Grow your business",
      "body": "Become a provider and get customers near you.",
      "imageUrl": "https://example.com/video-promo.jpg",
      "cta": "Join now",
      "url": "https://example.com/join",
      "formats": ["rewarded"],
      "rewardSeconds": 5
    }
  ]
}''';

  /// The text shown in the admin box for ads already saved.
  static String toText(List<HouseAd> ads) =>
      ads.isEmpty ? '' : const JsonEncoder.withIndent('  ').convert({'ads': [for (final a in ads) a.toJson()]});

  /// One ad out of [candidates], chosen at random in proportion to its weight.
  static HouseAd? pick(List<HouseAd> candidates, [Random? random]) {
    if (candidates.isEmpty) return null;
    final total = candidates.fold<int>(0, (s, a) => s + a.weight);
    var n = (random ?? Random()).nextInt(total);
    for (final a in candidates) {
      if (n < a.weight) return a;
      n -= a.weight;
    }
    return candidates.last;
  }
}
