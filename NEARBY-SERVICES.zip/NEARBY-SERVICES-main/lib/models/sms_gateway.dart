/// SMS providers the admin can choose from. Meseji is the default whenever the admin has
/// not chosen one or the server sends an unknown value.
///
/// The app is only a remote control: the real credentials live on the server, which sends
/// the SMS (OTP, alerts) with the provider chosen here. The server NEVER returns a secret to
/// the app, only whether one is saved (`apiKeySet`, `secretSet`, `passwordSet`).
enum SmsProvider {
  meseji('MESEJI', 'Meseji'),
  beem('BEEM', 'Beem Africa');

  /// Value sent to / received from the backend.
  final String id;

  /// Name for display.
  final String label;

  const SmsProvider(this.id, this.label);

  static const SmsProvider defaultProvider = SmsProvider.meseji;

  /// Accepts "meseji", "MESEJI", "Beem Africa", "beem_africa"... Null if unknown.
  static SmsProvider? tryParse(dynamic raw) {
    if (raw is! String) return null;
    final key = raw.toUpperCase().replaceAll(RegExp(r'[\s_\-]'), '');
    if (key == 'MESEJI') return SmsProvider.meseji;
    if (key == 'BEEM' || key == 'BEEMAFRICA') return SmsProvider.beem;
    return null;
  }
}

/// Saved Meseji settings as the server reports them (no secrets).
class MesejiSmsConfig {
  final bool apiKeySet;
  final bool passwordSet;
  final String senderId;
  final String email;
  final double costPerSms;

  const MesejiSmsConfig({
    this.apiKeySet = false,
    this.passwordSet = false,
    this.senderId = '',
    this.email = '',
    this.costPerSms = 15,
  });

  /// Everything the app needs to send is saved.
  bool get isComplete => apiKeySet && senderId.isNotEmpty;

  factory MesejiSmsConfig.fromJson(dynamic j) {
    if (j is! Map) return const MesejiSmsConfig();
    return MesejiSmsConfig(
      apiKeySet: j['apiKeySet'] == true,
      passwordSet: j['passwordSet'] == true,
      senderId: (j['senderId'] ?? '').toString(),
      email: (j['email'] ?? '').toString(),
      costPerSms: _num(j['costPerSms'], 15),
    );
  }
}

/// Saved Beem settings as the server reports them (no secrets).
class BeemSmsConfig {
  final bool apiKeySet;
  final bool secretSet;
  final String senderId;
  final double costPerSms;

  const BeemSmsConfig({
    this.apiKeySet = false,
    this.secretSet = false,
    this.senderId = 'INFO',
    this.costPerSms = 15,
  });

  bool get isComplete => apiKeySet && secretSet && senderId.isNotEmpty;

  factory BeemSmsConfig.fromJson(dynamic j) {
    if (j is! Map) return const BeemSmsConfig();
    final sender = (j['senderId'] ?? '').toString();
    return BeemSmsConfig(
      apiKeySet: j['apiKeySet'] == true,
      secretSet: j['secretSet'] == true,
      senderId: sender.isEmpty ? 'INFO' : sender,
      costPerSms: _num(j['costPerSms'], 15),
    );
  }
}

double _num(dynamic v, double fallback) {
  if (v is num) return v.toDouble();
  return double.tryParse(v?.toString() ?? '') ?? fallback;
}

/// What the server has saved now.
class SmsGatewayConfig {
  final SmsProvider defaultProvider;

  /// When the default provider fails to send, the server retries the same SMS with the
  /// other provider (if its credentials are saved). On unless the admin turns it off.
  final bool autoFailover;
  final MesejiSmsConfig meseji;
  final BeemSmsConfig beem;

  const SmsGatewayConfig({
    this.defaultProvider = SmsProvider.meseji,
    this.autoFailover = true,
    this.meseji = const MesejiSmsConfig(),
    this.beem = const BeemSmsConfig(),
  });

  /// The other provider.
  SmsProvider get backupProvider => defaultProvider == SmsProvider.beem ? SmsProvider.meseji : SmsProvider.beem;

  /// Automatic switching is on AND the backup provider could really send.
  bool get failoverReady =>
      autoFailover && (backupProvider == SmsProvider.beem ? beem.isComplete : meseji.isComplete);

  /// True when the chosen default provider has all its credentials saved.
  bool get defaultIsReady =>
      defaultProvider == SmsProvider.beem ? beem.isComplete : meseji.isComplete;

  /// Accepts the object itself or `{data: {...}}`. Null when [raw] is not an object.
  static SmsGatewayConfig? tryParse(dynamic raw) {
    final d = raw is Map && raw['data'] is Map ? raw['data'] : raw;
    if (d is! Map) return null;
    return SmsGatewayConfig(
      defaultProvider: SmsProvider.tryParse(d['defaultProvider'] ?? d['provider']) ?? SmsProvider.defaultProvider,
      autoFailover: d['autoFailover'] != false, // missing = on
      meseji: MesejiSmsConfig.fromJson(d['meseji']),
      beem: BeemSmsConfig.fromJson(d['beem']),
    );
  }
}

/// What the admin typed. Blank secrets mean "keep the saved one" and are left out of the
/// request, so a secret is only ever sent when the admin deliberately typed a new value.
class SmsGatewayUpdate {
  final SmsProvider defaultProvider;
  final bool autoFailover;

  final String mesejiApiKey; // blank = keep
  final String mesejiSenderId;
  final String mesejiEmail;
  final String mesejiPassword; // blank = keep
  final double mesejiCost;

  final String beemApiKey; // blank = keep
  final String beemSecretKey; // blank = keep
  final String beemSenderId;
  final double beemCost;

  const SmsGatewayUpdate({
    required this.defaultProvider,
    this.autoFailover = true,
    this.mesejiApiKey = '',
    this.mesejiSenderId = '',
    this.mesejiEmail = '',
    this.mesejiPassword = '',
    this.mesejiCost = 15,
    this.beemApiKey = '',
    this.beemSecretKey = '',
    this.beemSenderId = 'INFO',
    this.beemCost = 15,
  });

  Map<String, dynamic> toJson() {
    String? secret(String v) => v.trim().isEmpty ? null : v.trim();
    return {
      'defaultProvider': defaultProvider.id,
      'autoFailover': autoFailover,
      'meseji': {
        if (secret(mesejiApiKey) != null) 'apiKey': secret(mesejiApiKey),
        'senderId': mesejiSenderId.trim(),
        'email': mesejiEmail.trim(),
        if (secret(mesejiPassword) != null) 'password': secret(mesejiPassword),
        'costPerSms': mesejiCost,
      },
      'beem': {
        if (secret(beemApiKey) != null) 'apiKey': secret(beemApiKey),
        if (secret(beemSecretKey) != null) 'secretKey': secret(beemSecretKey),
        'senderId': beemSenderId.trim(),
        'costPerSms': beemCost,
      },
    };
  }
}

/// Result of "Test connection" / "Send test SMS".
class SmsTestResult {
  final bool success;
  final String? message;
  const SmsTestResult(this.success, [this.message]);
}

/// Checks done on the phone before anything is sent (the server checks again).
class SmsGatewayRules {
  SmsGatewayRules._();

  static const int beemSenderMax = 11;
  static const double costMax = 100000;

  /// Beem: up to 11 letters, numbers or spaces. Null = fine, otherwise a code the screen
  /// turns into text: 'empty' or 'shape'.
  static String? beemSender(String raw) {
    final v = raw.trim();
    if (v.isEmpty) return 'empty';
    return RegExp(r'^[A-Za-z0-9 ]{1,11}$').hasMatch(v) ? null : 'shape';
  }

  /// Meseji sender ID or phone number: required, letters/numbers/space/+/-/., max 20.
  static String? mesejiSender(String raw) {
    final v = raw.trim();
    if (v.isEmpty) return 'empty';
    return RegExp(r'^[A-Za-z0-9 +\-.]{1,20}$').hasMatch(v) ? null : 'shape';
  }

  /// Cost per SMS in TSh: a number from 0 to [costMax]. Accepts "15" and "15,5".
  static double? parseCost(String raw) {
    final v = double.tryParse(raw.trim().replaceAll(',', '.'));
    if (v == null || v.isNaN || v < 0 || v > costMax) return null;
    return v;
  }
}
