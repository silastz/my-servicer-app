import 'models.dart';

enum AvailabilityFilter { any, now, today, tomorrow, weekend }

enum ServiceTypeFilter { both, customerComes, iTravel }

enum SortOption { nearest, lowestPrice, highestRating, mostPopular }

/// Everything the Search & Filter screen can set. Applied to the services the
/// API returns (see [apply]) so every dropdown really changes the results.
class ServiceFilters {
  final double? maxDistanceKm; // null = any distance
  final int? minPrice; // TSh, inclusive
  final int? maxPrice; // TSh, inclusive
  final double? minRating;
  final AvailabilityFilter availability;
  final ServiceTypeFilter serviceType;
  final SortOption sort;
  final bool verifiedOnly;

  const ServiceFilters({
    this.maxDistanceKm,
    this.minPrice,
    this.maxPrice,
    this.minRating,
    this.availability = AvailabilityFilter.any,
    this.serviceType = ServiceTypeFilter.both,
    this.sort = SortOption.nearest,
    this.verifiedOnly = false,
  });

  /// Same filters without the distance limit: the radius becomes a divider
  /// between "near you" and "available elsewhere" instead of hiding results.
  ServiceFilters withoutDistance() => ServiceFilters(
        minPrice: minPrice,
        maxPrice: maxPrice,
        minRating: minRating,
        availability: availability,
        serviceType: serviceType,
        sort: sort,
        verifiedOnly: verifiedOnly,
      );

  /// True when anything differs from the defaults.
  bool get isActive =>
      maxDistanceKm != null ||
      minPrice != null ||
      maxPrice != null ||
      minRating != null ||
      availability != AvailabilityFilter.any ||
      serviceType != ServiceTypeFilter.both ||
      sort != SortOption.nearest ||
      verifiedOnly;

  static const _dayKeys = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  List<ServiceItem> apply(List<ServiceItem> items, {DateTime? now}) {
    final n = now ?? DateTime.now();
    final out = items.where((s) {
      if (verifiedOnly && !s.isVerified) return false;
      // Unknown distance can't be judged, so those stay in the list.
      if (maxDistanceKm != null && s.distanceKm != null && s.distanceKm! > maxDistanceKm!) return false;
      if (minPrice != null && s.priceAmount < minPrice!) return false;
      if (maxPrice != null && s.priceAmount > maxPrice!) return false;
      if (minRating != null && s.rating < minRating!) return false;
      if (!_matchesAvailability(s, n)) return false;
      if (!_matchesServiceType(s)) return false;
      return true;
    }).toList();

    // Stable sort (List.sort isn't guaranteed stable).
    final indexed = out.asMap().entries.toList();
    int byIndex(MapEntry<int, ServiceItem> a, MapEntry<int, ServiceItem> b) => a.key.compareTo(b.key);
    indexed.sort((a, b) {
      final x = a.value, y = b.value;
      int c;
      // Boosted services lead the default (nearest) order; an explicit sort the user
      // chose (price, rating, popularity) is never overridden.
      if (sort == SortOption.nearest && x.isBoosted != y.isBoosted) {
        return x.isBoosted ? -1 : 1;
      }
      switch (sort) {
        case SortOption.nearest:
          final dx = x.distanceKm, dy = y.distanceKm;
          if (dx == null && dy == null) return byIndex(a, b);
          if (dx == null) return 1;
          if (dy == null) return -1;
          c = dx.compareTo(dy);
          break;
        case SortOption.lowestPrice:
          c = x.priceAmount.compareTo(y.priceAmount);
          break;
        case SortOption.highestRating:
          c = y.rating.compareTo(x.rating);
          break;
        case SortOption.mostPopular:
          c = y.reviewsCount.compareTo(x.reviewsCount);
          break;
      }
      return c != 0 ? c : byIndex(a, b);
    });
    return indexed.map((e) => e.value).toList();
  }

  bool _matchesServiceType(ServiceItem s) {
    if (serviceType == ServiceTypeFilter.both) return true;
    final mode = s.serviceMode;
    if (mode == null || mode == 'both') return true; // unknown or offers both
    return serviceType == ServiceTypeFilter.customerComes
        ? mode == 'customer_comes'
        : mode == 'provider_travels';
  }

  bool _dayListed(ServiceItem s, DateTime d) =>
      s.availableDays.isEmpty || s.availableDays.contains(_dayKeys[d.weekday - 1]);

  static int? _minutes(String? t) {
    if (t == null) return null;
    final m = RegExp(r'(\d{1,2}):(\d{2})').firstMatch(t);
    if (m == null) return null;
    return int.parse(m.group(1)!) * 60 + int.parse(m.group(2)!);
  }

  bool _matchesAvailability(ServiceItem s, DateTime n) {
    switch (availability) {
      case AvailabilityFilter.any:
        return true;
      case AvailabilityFilter.now:
        if (s.isOnline) return true;
        final from = _minutes(s.availableFrom), to = _minutes(s.availableTo);
        final hasSchedule = s.availableDays.isNotEmpty || (from != null && to != null);
        if (!hasSchedule) return false; // nothing says they're available right now
        if (!_dayListed(s, n)) return false;
        if (from == null || to == null) return true;
        final cur = n.hour * 60 + n.minute;
        return from <= to ? (cur >= from && cur <= to) : (cur >= from || cur <= to);
      case AvailabilityFilter.today:
        return _dayListed(s, n);
      case AvailabilityFilter.tomorrow:
        return _dayListed(s, n.add(const Duration(days: 1)));
      case AvailabilityFilter.weekend:
        if (s.availableDays.isEmpty) return true;
        return s.availableDays.contains('Sat') || s.availableDays.contains('Sun');
    }
  }
}
