/// One photo or video in a provider's own portfolio (separate from their services' media).
class PortfolioItem {
  final int id;
  final bool isVideo;
  final String url; // absolute
  final String? caption;
  final DateTime? createdAt;

  const PortfolioItem({
    required this.id,
    required this.isVideo,
    required this.url,
    this.caption,
    this.createdAt,
  });

  factory PortfolioItem.fromJson(Map<String, dynamic> j, {String Function(String)? fixUrl}) {
    final raw = (j['url'] ?? '').toString();
    final cap = j['caption']?.toString().trim();
    return PortfolioItem(
      id: (j['id'] as num?)?.toInt() ?? 0,
      isVideo: (j['type'] ?? '').toString().toUpperCase() == 'VIDEO',
      url: fixUrl == null ? raw : fixUrl(raw),
      caption: (cap == null || cap.isEmpty) ? null : cap,
      createdAt: DateTime.tryParse((j['createdAt'] ?? '').toString()),
    );
  }
}
