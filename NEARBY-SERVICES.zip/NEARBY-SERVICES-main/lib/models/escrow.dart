/// One status enum for escrow bookings. Mirrors the backend `EscrowStatus`.
/// A status this app version does not know becomes [unknown] instead of breaking a screen.
enum EscrowStatus {
  pendingAcceptance('PENDING_ACCEPTANCE'),
  accepted('ACCEPTED'),
  funded('FUNDED'),
  completed('COMPLETED'),
  disputed('DISPUTED'),
  refunded('REFUNDED'),
  rejected('REJECTED'),
  cancelled('CANCELLED'),
  awaitingPayment('AWAITING_PAYMENT'),
  paymentSent('PAYMENT_SENT'),
  paymentDisputed('PAYMENT_DISPUTED'),
  unknown('UNKNOWN');

  final String wire;
  const EscrowStatus(this.wire);

  static EscrowStatus parse(Object? raw) {
    final s = raw?.toString().trim().toUpperCase();
    if (s == null || s.isEmpty) return EscrowStatus.pendingAcceptance;
    // Older servers/screens also said RELEASED for a finished booking.
    if (s == 'RELEASED') return EscrowStatus.completed;
    for (final v in values) {
      if (v.wire == s) return v;
    }
    return EscrowStatus.unknown;
  }

  /// Money has reached the provider.
  bool get isReleased => this == completed;

  /// Nothing more will happen to this booking.
  bool get isFinal => const {completed, refunded, rejected, cancelled}.contains(this);

  /// Still moving: waiting on a person or on payment.
  bool get isOpen => !isFinal && this != unknown;
}

/// A booking/escrow transaction as the screens need it. `raw` keeps the full server JSON
/// so fields not modelled yet are still reachable during migration.
class EscrowTransaction {
  final int? id;
  final String ref;
  final EscrowStatus status;
  final String rawStatus;
  final double amount; // never truncated: KES has cents
  final String? paymentMethod;
  final String? paymentMode;
  final String? paymentPreference;
  final String? paymentStatus;
  final DateTime? createdAt;
  final DateTime? paymentDeadline;
  final String? serviceTitle;
  final int? buyerId;
  final int? sellerId;
  final String? buyerName;
  final String? sellerName;
  final Map<String, dynamic> raw;

  const EscrowTransaction({
    required this.id,
    required this.ref,
    required this.status,
    required this.rawStatus,
    required this.amount,
    required this.raw,
    this.paymentMethod,
    this.paymentMode,
    this.paymentPreference,
    this.paymentStatus,
    this.createdAt,
    this.paymentDeadline,
    this.serviceTitle,
    this.buyerId,
    this.sellerId,
    this.buyerName,
    this.sellerName,
  });

  factory EscrowTransaction.fromJson(Map<String, dynamic> j) {
    Map<String, dynamic> m(Object? v) => v is Map ? Map<String, dynamic>.from(v) : const {};
    String? name(Map<String, dynamic> u) {
      final n = u['stageName'] ?? u['username'];
      return n?.toString();
    }

    final buyer = m(j['buyer']);
    final seller = m(j['seller']);
    final rawStatus = (j['status'] ?? '').toString();
    return EscrowTransaction(
      id: (j['id'] as num?)?.toInt(),
      ref: (j['transactionRef'] ?? j['id'] ?? '').toString(),
      status: EscrowStatus.parse(j['status']),
      rawStatus: rawStatus,
      amount: (j['amount'] as num?)?.toDouble() ?? 0,
      paymentMethod: j['paymentMethod']?.toString(),
      paymentMode: j['paymentMode']?.toString(),
      paymentPreference: j['paymentPreference']?.toString(),
      paymentStatus: j['paymentStatus']?.toString(),
      createdAt: DateTime.tryParse(j['createdAt']?.toString() ?? ''),
      paymentDeadline: DateTime.tryParse(j['paymentDeadline']?.toString() ?? ''),
      serviceTitle: m(j['service'])['title']?.toString(),
      buyerId: (buyer['id'] as num?)?.toInt(),
      sellerId: (seller['id'] as num?)?.toInt(),
      buyerName: name(buyer),
      sellerName: name(seller),
      raw: Map<String, dynamic>.from(j),
    );
  }
}
