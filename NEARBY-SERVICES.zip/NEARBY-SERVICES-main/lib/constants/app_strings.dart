import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../l10n/base_strings.dart';
import '../l10n/en.dart';
import '../l10n/sw.dart';

enum AppLanguage { english, swahili }

/// AppStrings: Entry point for application internationalization.
/// Seamlessly provides the active dictionary based on the selected language.
/// Backed by individual per-language files (en.dart, sw.dart, etc.) for clean maintainability.
class AppStrings {
  AppStrings._();

  static const String _prefLanguageKey = 'app_language';
  static const BaseStrings _en = EnStrings();
  static const BaseStrings _sw = SwStrings();

  static final ValueNotifier<AppLanguage> currentLanguage =
      ValueNotifier<AppLanguage>(AppLanguage.english);

  static BaseStrings get current =>
      currentLanguage.value == AppLanguage.english ? _en : _sw;

  static bool get isEnglish => currentLanguage.value == AppLanguage.english;

  static Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    final savedCode = prefs.getString(_prefLanguageKey);
    if (savedCode == 'sw') {
      currentLanguage.value = AppLanguage.swahili;
    } else {
      currentLanguage.value = AppLanguage.english;
    }
  }

  static Future<void> setLanguage(AppLanguage lang) async {
    currentLanguage.value = lang;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefLanguageKey, lang == AppLanguage.swahili ? 'sw' : 'en');
  }

  // Common shortcuts proxying directly to current dictionary
  static String get appName => current.appName;
  static String get cancel => current.cancel;
  static String get close => current.close;
  static String get save => current.save;
  static String get submit => current.submit;
  static String get confirm => current.confirm;
  static String get back => current.back;
  static String get retry => current.retry;
  static String get search => current.search;
  static String get loading => current.loading;
  static String get success => current.success;
  static String get error => current.error;
  static String get guest => current.guest;
  static String get active => current.active;
  static String get pending => current.pending;
  static String get completed => current.completed;
  static String get currency => current.currency;
  static String get selectRegionTitle => current.selectRegionTitle;
  static String get detectingLocation => current.detectingLocation;
  static String get searchRegionHint => current.searchRegionHint;
  static String get nearYouRadius => current.nearYouRadius;
  static String get noServicesNearby => current.noServicesNearby;
  static String get bookNow => current.bookNow;
  static String get bannerRelaxTitle => current.bannerRelaxTitle;
  static String get bannerRelaxSubtitle => current.bannerRelaxSubtitle;
  static String get chipAll => current.chipAll;
  static String get chipNearby => current.chipNearby;
  static String get chipTopRated => current.chipTopRated;
  static String get chipVerified => current.chipVerified;
  static String get viewAll => current.viewAll;
  static String get watchAdTitle => current.watchAdTitle;
  static String get watchAdMessage => current.watchAdMessage;
  static String get watchAdButton => current.watchAdButton;
  static String get watchAdIncomplete => current.watchAdIncomplete;
  static String get adRewardIn => current.adRewardIn;
  static String get adRewardReady => current.adRewardReady;
  static String get adClose => current.adClose;

  // Navigation
  static String get navHome => current.navHome;
  static String get authNumberNotVerifiedNotice => current.authNumberNotVerifiedNotice;
  static String get authTooManyAttempts => current.authTooManyAttempts;
  static String get exitAppTitle => current.exitAppTitle;
  static String get exitAppMessage => current.exitAppMessage;
  static String get exitAppCancel => current.exitAppCancel;
  static String get exitAppConfirm => current.exitAppConfirm;
  static String get exitAppPressAgain => current.exitAppPressAgain;
  static String get loadingServices => current.loadingServices;
  static String get navChats => current.navChats;
  static String get navRequests => current.navRequests;
  static String get navSell => current.navSell;
  static String get navServices => current.navServices;
  static String get navEarnings => current.navEarnings;
  static String get navProfile => current.navProfile;
  static String get navSearch => current.navSearch;

  // Home Screen
  static String get homeHeaderLocationTitle => current.homeHeaderLocationTitle;
  static String get homeGreeting => current.homeGreeting;
  static String get homeGreetingSubtitle => current.homeGreetingSubtitle;
  static String get homeSearchPlaceholder => current.homeSearchPlaceholder;
  static String get homeChangeLocation => current.homeChangeLocation;
  static String get bannerExploreNow => current.bannerExploreNow;
  static String get homeCategoriesTitle => current.homeCategoriesTitle;
  static String get homePopularServices => current.homePopularServices;
  static String get homeNearbyProviders => current.homeNearbyProviders;
  static String get homeFeaturedProviders => current.homeFeaturedProviders;
  static String get homeVerifiedBadge => current.homeVerifiedBadge;
  static String get homeStartingFrom => current.homeStartingFrom;
  static String get homeAllServicesSeen => current.homeAllServicesSeen;

  // Categories
  static String get catMassage => current.catMassage;
  static String get catBeauty => current.catBeauty;
  static String get catBarber => current.catBarber;
  static String get catCleaning => current.catCleaning;
  static String get catPlumbing => current.catPlumbing;
  static String get catElectrical => current.catElectrical;
  static String get catMechanic => current.catMechanic;
  static String get catPhotography => current.catPhotography;
  static String get catRepair => current.catRepair;
  static String get catGeneral => current.catGeneral;

  // Auth & Login / Registration
  static String get authWelcomeBack => current.authWelcomeBack;
  static String get authWelcomeSubtitle => current.authWelcomeSubtitle;
  static String get authCreateAccount => current.authCreateAccount;
  static String get authCreateSubtitle => current.authCreateSubtitle;
  static String get authLoginTab => current.authLoginTab;
  static String get authRegisterTab => current.authRegisterTab;
  static String get authFullNameLabel => current.authFullNameLabel;
  static String get authFullNameHint => current.authFullNameHint;
  static String get authPhoneLabel => current.authPhoneLabel;
  static String get authPhoneHint => current.authPhoneHint;
  static String get authEmailLabel => current.authEmailLabel;
  static String get authEmailHint => current.authEmailHint;
  static String get authPasswordLabel => current.authPasswordLabel;
  static String get authPasswordHint => current.authPasswordHint;
  static String get authPasswordWeakError => current.authPasswordWeakError;
  static String get authServerBusyError => current.authServerBusyError;
  static String get authRateLimitedError => current.authRateLimitedError;
  static String get authResetSuccess => current.authResetSuccess;
  static String get authEmailInvalid => current.authEmailInvalid;
  static String get authResetIfExists => current.authResetIfExists;
  static String get authSellerAccountSwitch => current.authSellerAccountSwitch;
  static String get authSellerSubtitle => current.authSellerSubtitle;
  static String get authSignInButton => current.authSignInButton;
  static String get authRegisterButton => current.authRegisterButton;
  static String get authVerifyOtpTitle => current.authVerifyOtpTitle;
  static String get authVerifyPhoneOtpTitle => current.authVerifyPhoneOtpTitle;
  static String get authOtpSentSubtitle => current.authOtpSentSubtitle;
  static String get authPhoneOtpSentSubtitle => current.authPhoneOtpSentSubtitle;
  static String get authOtpHint => current.authOtpHint;
  static String get authOtpStillValid => current.authOtpStillValid;
  static String get authVerifyButton => current.authVerifyButton;
  static String get authResendOtp => current.authResendOtp;
  static String get authInvalidOtpError => current.authInvalidOtpError;
  static String get authLoginSuccess => current.authLoginSuccess;
  static String get authRegisterSuccess => current.authRegisterSuccess;
  static String get authAlreadyHaveAccount => current.authAlreadyHaveAccount;
  static String get authDontHaveAccount => current.authDontHaveAccount;

  // Multi-step Service Provider Registration
  static String get regProviderTitle => current.regProviderTitle;
  static String get regStepBasic => current.regStepBasic;
  static String get regStepBusiness => current.regStepBusiness;
  static String get regStepDocuments => current.regStepDocuments;
  static String get regStepPayment => current.regStepPayment;
  static String get regBasicTitle => current.regBasicTitle;
  static String get regBasicSubtitle => current.regBasicSubtitle;
  static String get regBusinessTitle => current.regBusinessTitle;
  static String get regBusinessSubtitle => current.regBusinessSubtitle;
  static String get regBusinessNameLabel => current.regBusinessNameLabel;
  static String get regBusinessNameHint => current.regBusinessNameHint;
  static String get regCategoryLabel => current.regCategoryLabel;
  static String get regCategoryHint => current.regCategoryHint;
  static String get regDescLabel => current.regDescLabel;
  static String get regDescHint => current.regDescHint;
  static String get regLocationLabel => current.regLocationLabel;
  static String get regLocationHint => current.regLocationHint;
  static String get regRadiusLabel => current.regRadiusLabel;
  static String get regRadiusHint => current.regRadiusHint;
  static String get regDocumentsTitle => current.regDocumentsTitle;
  static String get regDocumentsSubtitle => current.regDocumentsSubtitle;
  static String get regNidaDocTitle => current.regNidaDocTitle;
  static String get regNidaDocSubtitle => current.regNidaDocSubtitle;
  static String get regLicenseDocTitle => current.regLicenseDocTitle;
  static String get regLicenseDocSubtitle => current.regLicenseDocSubtitle;
  static String get regProfilePhotoTitle => current.regProfilePhotoTitle;
  static String get regProfilePhotoSubtitle => current.regProfilePhotoSubtitle;
  static String get regUploadPhoto => current.regUploadPhoto;
  static String get regUploadDoc => current.regUploadDoc;
  static String get regDocSafeNotice => current.regDocSafeNotice;
  static String get regPaymentTitle => current.regPaymentTitle;
  static String get regPaymentSubtitle => current.regPaymentSubtitle;
  static String get regFeeLabel => current.regFeeLabel;
  static String get regFeeOneTime => current.regFeeOneTime;
  static String get regSelectPaymentMethod => current.regSelectPaymentMethod;
  static String get regPaymentActivationNotice => current.regPaymentActivationNotice;
  static String get regBtnContinue => current.regBtnContinue;
  static String get regBtnPayAndContinue => current.regBtnPayAndContinue;
  static String get regUpgradeFromBuyerBanner => current.regUpgradeFromBuyerBanner;
  static String get regSuccessTitle => current.regSuccessTitle;
  static String get regSuccessMsg => current.regSuccessMsg;
  static String get profileBecomeSeller => current.profileBecomeSeller;
  static String get profileBecomeSellerSubtitle => current.profileBecomeSellerSubtitle;
  static String get authForgotPasswordLink => current.authForgotPasswordLink;
  static String get authForgotPasswordTitle => current.authForgotPasswordTitle;
  static String get authForgotPasswordSubtitle => current.authForgotPasswordSubtitle;
  static String get authSendResetCodeButton => current.authSendResetCodeButton;
  static String get authResetPasswordTitle => current.authResetPasswordTitle;
  static String get authNewPasswordLabel => current.authNewPasswordLabel;
  static String get authResetPasswordButton => current.authResetPasswordButton;
  static String get authBackToLogin => current.authBackToLogin;
  static String get authAccountNotVerifiedError => current.authAccountNotVerifiedError;
  static String get authInvalidCredentialsError => current.authInvalidCredentialsError;
  static String get authPhoneExistsError => current.authPhoneExistsError;
  static String get authSignupPendingError => current.authSignupPendingError;
  static String get authVerifyWithPhoneError => current.authVerifyWithPhoneError;
  static String get authEmailExistsError => current.authEmailExistsError;
  static String get authUsernameExistsError => current.authUsernameExistsError;
  static String get authUserNotFoundError => current.authUserNotFoundError;
  static String get authInvalidPhoneError => current.authInvalidPhoneError;
  static String get authNetworkError => current.authNetworkError;

  // Guest Access State
  static String get guestTitle => current.guestTitle;
  static String get guestSubtitle => current.guestSubtitle;
  static String get guestAction => current.guestAction;
  static String get guestChatsDesc => current.guestChatsDesc;
  static String get guestRequestsDesc => current.guestRequestsDesc;
  static String get guestSellDesc => current.guestSellDesc;

  // Profile
  static String get profileTitle => current.profileTitle;
  static String get profileGuestTitle => current.profileGuestTitle;
  static String get profileGuestSubtitle => current.profileGuestSubtitle;
  static String get profileSignInAction => current.profileSignInAction;
  static String get profileSignOutAction => current.profileSignOutAction;
  static String get profileWalletTitle => current.profileWalletTitle;
  static String get profileWalletSubtitle => current.profileWalletSubtitle;
  static String get profileNidaTitle => current.profileNidaTitle;
  static String get profileNidaSubtitle => current.profileNidaSubtitle;
  static String get profileLocationTitle => current.profileLocationTitle;
  static String get profileLocationSubtitle => current.profileLocationSubtitle;
  static String get profileFavoritesTitle => current.profileFavoritesTitle;
  static String get profileFavoritesSubtitle => current.profileFavoritesSubtitle;
  static String get profilePrivacyTitle => current.profilePrivacyTitle;
  static String get profilePrivacySubtitle => current.profilePrivacySubtitle;
  static String get profileHelpTitle => current.profileHelpTitle;
  static String get profileHelpSubtitle => current.profileHelpSubtitle;
  static String get profileLanguageTitle => current.profileLanguageTitle;

  // Badges
  static String get badgeBlueTick => current.badgeBlueTick;
  static String get badgeGreenBadge => current.badgeGreenBadge;
  static String get badgeUnverified => current.badgeUnverified;

  // Sell & Manage Services
  static String get sellMyServicesTitle => current.sellMyServicesTitle;
  static String get sellAddService => current.sellAddService;
  static String get sellTabActive => current.sellTabActive;
  static String get sellTabPending => current.sellTabPending;
  static String get sellTabInactive => current.sellTabInactive;
  static String get sellNoServicesTitle => current.sellNoServicesTitle;
  static String get sellNoServicesSubtitle => current.sellNoServicesSubtitle;
  static String get sellPostNewTitle => current.sellPostNewTitle;
  static String get sellServiceTitleLabel => current.sellServiceTitleLabel;
  static String get sellServiceTitleHint => current.sellServiceTitleHint;
  static String get sellDescLabel => current.sellDescLabel;
  static String get sellDescHint => current.sellDescHint;
  static String get sellCategoryLabel => current.sellCategoryLabel;
  static String get sellPriceLabel => current.sellPriceLabel;
  static String get sellPriceHint => current.sellPriceHint;
  static String get sellPhoneLabel => current.sellPhoneLabel;
  static String get sellPrivacyLockTitle => current.sellPrivacyLockTitle;
  static String get sellPrivacyLockSubtitle => current.sellPrivacyLockSubtitle;
  static String get sellPublishButton => current.sellPublishButton;
  static String get sellPublishSuccess => current.sellPublishSuccess;
  static String get sellPublishError => current.sellPublishError;
  static String get sellContactsLockedBadge => current.sellContactsLockedBadge;

  // Requests & Bookings
  static String get requestsTitle => current.requestsTitle;
  static String get requestsTabIncoming => current.requestsTabIncoming;
  static String get requestsTabOutgoing => current.requestsTabOutgoing;
  static String get requestsNoRequests => current.requestsNoRequests;
  static String get requestsAcceptButton => current.requestsAcceptButton;
  static String get requestsRejectButton => current.requestsRejectButton;
  static String get requestsReleaseButton => current.requestsReleaseButton;
  static String get requestsAcceptedNotice => current.requestsAcceptedNotice;
  static String get requestsReleasedNotice => current.requestsReleasedNotice;
  static String get requestsRejectedNotice => current.requestsRejectedNotice;
  static String get requestsEscrowSecured => current.requestsEscrowSecured;

  // Pocket Fund (Wallet)
  static String get walletTitle => current.walletTitle;
  static String get walletAvailableBalance => current.walletAvailableBalance;
  static String get walletLockedEscrow => current.walletLockedEscrow;
  static String get walletDepositAction => current.walletDepositAction;
  static String get walletWithdrawAction => current.walletWithdrawAction;
  static String get walletHistoryTitle => current.walletHistoryTitle;
  static String get walletNoTransactions => current.walletNoTransactions;
  static String get walletTopUpSheetTitle => current.walletTopUpSheetTitle;
  static String get walletTopUpPhoneHint => current.walletTopUpPhoneHint;
  static String get walletTopUpAmountHint => current.walletTopUpAmountHint;
  static String get walletWithdrawSheetTitle => current.walletWithdrawSheetTitle;
  static String get walletWithdrawSuccess => current.walletWithdrawSuccess;
  static String get walletDepositSuccess => current.walletDepositSuccess;
  static String get walletEscrowPolicy => current.walletEscrowPolicy;
  static String get walletSelectPaymentNetwork => current.walletSelectPaymentNetwork;
  static String get walletWithdrawPhonePrompt => current.walletWithdrawPhonePrompt;
  static String get walletWithdrawAmountPrompt => current.walletWithdrawAmountPrompt;
  static String get walletWithdrawFailed => current.walletWithdrawFailed;
  static String get walletDepositFailed => current.walletDepositFailed;
  static String get walletConfirmWithdraw => current.walletConfirmWithdraw;

  // NIDA Verification
  static String get nidaScreenTitle => current.nidaScreenTitle;
  static String get nidaHeaderTitle => current.nidaHeaderTitle;
  static String get nidaHeaderSubtitle => current.nidaHeaderSubtitle;
  static String get nidaNumberLabel => current.nidaNumberLabel;
  static String get nidaFirstNameLabel => current.nidaFirstNameLabel;
  static String get nidaLastNameLabel => current.nidaLastNameLabel;
  static String get nidaGuarantorCodeLabel => current.nidaGuarantorCodeLabel;
  static String get nidaUploadIdPhoto => current.nidaUploadIdPhoto;
  static String get nidaUploadSelfie => current.nidaUploadSelfie;
  static String get nidaSubmitButton => current.nidaSubmitButton;
  static String get nidaSuccessGreen => current.nidaSuccessGreen;
  static String get nidaSuccessBlue => current.nidaSuccessBlue;

  // Booking Request
  static String get bookingTitle => current.bookingTitle;
  static String get bookingSummaryTitle => current.bookingSummaryTitle;
  static String get bookingEscrowGuarantee => current.bookingEscrowGuarantee;
  static String get bookingSelectDate => current.bookingSelectDate;
  static String get bookingSelectTime => current.bookingSelectTime;
  static String get bookingNotesLabel => current.bookingNotesLabel;
  static String get bookingNotesHint => current.bookingNotesHint;
  static String get bookingConfirmButton => current.bookingConfirmButton;
  static String get bookingSuccessTitle => current.bookingSuccessTitle;
  static String get bookingSuccessSubtitle => current.bookingSuccessSubtitle;

  // Chats
  static String get chatsTitle => current.chatsTitle;
  static String get chatsNoMessages => current.chatsNoMessages;
  static String get chatsTypePlaceholder => current.chatsTypePlaceholder;
  static String get chatsOnline => current.chatsOnline;
  static String get chatsSearchHint => current.chatsSearchHint;
  static String get chatsTabAll => current.chatsTabAll;
  static String get chatsTabBookings => current.chatsTabBookings;
  static String get chatsTabRequests => current.chatsTabRequests;

  // Notifications
  static String get notificationsTitle => current.notificationsTitle;
  static String get notificationsNoItems => current.notificationsNoItems;
  static String get notificationsMarkAllRead => current.notificationsMarkAllRead;

  // Search & Filter
  static String get searchFilterTitle => current.searchFilterTitle;
  static String get searchFilterRadius => current.searchFilterRadius;
  static String get searchFilterRating => current.searchFilterRating;
  static String get searchFilterApply => current.searchFilterApply;
  static String get searchFilterReset => current.searchFilterReset;
  static String get searchFilterBy => current.searchFilterBy;
  static String get searchFilterAll => current.searchFilterAll;
  static String get searchFilterAvailableNow => current.searchFilterAvailableNow;
  static String get searchFilterVerifiedOnly => current.searchFilterVerifiedOnly;
  static String get searchFilterDistance => current.searchFilterDistance;
  static String get searchFilterAnyDistance => current.searchFilterAnyDistance;
  static String get searchFilterPriceRange => current.searchFilterPriceRange;
  static String get searchFilterAnyPrice => current.searchFilterAnyPrice;
  static String get searchFilterAnyRating => current.searchFilterAnyRating;
  static String get searchFilterCategory => current.searchFilterCategory;
  static String get searchFilterAvailability => current.searchFilterAvailability;
  static String get searchFilterAnyTime => current.searchFilterAnyTime;
  static String get searchFilterServiceType => current.searchFilterServiceType;
  static String get searchFilterServiceTypeBoth => current.searchFilterServiceTypeBoth;
  static String get searchFilterSortBy => current.searchFilterSortBy;
  static String get searchFilterNearestFirst => current.searchFilterNearestFirst;

  // Location & Radius
  static String get locationRadiusTitle => current.locationRadiusTitle;
  static String get locationRadiusSubtitle => current.locationRadiusSubtitle;
  static String get locationRadiusKm => current.locationRadiusKm;
  static String get locationSaveButton => current.locationSaveButton;

  // Startup Permissions Modal
  static String get permWelcomeTitle => current.permWelcomeTitle;
  static String get permWelcomeSubtitle => current.permWelcomeSubtitle;
  static String get permLocationTitle => current.permLocationTitle;
  static String get permLocationDesc => current.permLocationDesc;
  static String get permNotificationTitle => current.permNotificationTitle;
  static String get permNotificationDesc => current.permNotificationDesc;
  static String get permAllowButton => current.permAllowButton;
  static String get permMaybeLaterButton => current.permMaybeLaterButton;

  // Favorites
  static String get favoritesTitle => current.favoritesTitle;
  static String get favoritesNoItems => current.favoritesNoItems;

  // Details & Seller Profile
  static String get detailsAboutService => current.detailsAboutService;
  static String get detailsPricingOptions => current.detailsPricingOptions;
  static String get detailsCustomerReviews => current.detailsCustomerReviews;
  static String get detailsBookNow => current.detailsBookNow;
  static String get detailsCallNow => current.detailsCallNow;
  static String get detailsWhatsApp => current.detailsWhatsApp;
  static String get detailsSellerProfile => current.detailsSellerProfile;
  static String get detailsExperience => current.detailsExperience;
  static String get detailsTotalOrders => current.detailsTotalOrders;
  static String get detailsVerifiedProvider => current.detailsVerifiedProvider;
  static String get detailsPerSession => current.detailsPerSession;
  static String get detailsProfessional => current.detailsProfessional;
  static String get detailsCleanSafe => current.detailsCleanSafe;
  static String get detailsAvailableNow => current.detailsAvailableNow;
  static String get detailsMemberSince => current.detailsMemberSince;
  static String get detailsViewProfile => current.detailsViewProfile;
  static String get detailsTabOverview => current.detailsTabOverview;
  static String get detailsTabPortfolio => current.detailsTabPortfolio;
  static String get detailsTabReviews => current.detailsTabReviews;
  static String get detailsTabAvailability => current.detailsTabAvailability;
  static String get detailsTabLocation => current.detailsTabLocation;
  static String get detailsServiceDurationPrice => current.detailsServiceDurationPrice;
  static String get detailsChat => current.detailsChat;
  static String get detailsLocked => current.detailsLocked;
  static String get detailsContactLockedAlert => current.detailsContactLockedAlert;
  static String get nidaPrivacyGuarantee => current.nidaPrivacyGuarantee;
  static String get nidaOption1Title => current.nidaOption1Title;
  static String get nidaOption1Subtitle => current.nidaOption1Subtitle;
  static String get nidaOption2Title => current.nidaOption2Title;
  static String get nidaOption2Subtitle => current.nidaOption2Subtitle;
  static String get nidaOption3Title => current.nidaOption3Title;
  static String get nidaOption3Subtitle => current.nidaOption3Subtitle;
  static String get nidaIdPhotoCard => current.nidaIdPhotoCard;
  static String get nidaSelfieCard => current.nidaSelfieCard;
  static String get nidaUploaded => current.nidaUploaded;
  static String get nidaGuarantorHint => current.nidaGuarantorHint;
  static String get nidaFailedGreen => current.nidaFailedGreen;
  static String get nidaFailedBlue => current.nidaFailedBlue;
}
