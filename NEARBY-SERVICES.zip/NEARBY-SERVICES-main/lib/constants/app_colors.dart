import 'package:flutter/material.dart';

/// AppColors provides a centralized, design-system compliant color palette.
/// Never hardcode Color(0xFF...) anywhere in the app; reference AppColors instead.
class AppColors {
  AppColors._();

  // Primary Brand Colors
  static const Color primary = Color(0xFF0D6EFD);
  static const Color primaryDark = Color(0xFF0A58CA);
  static const Color primaryLight = Color(0xFFEFF6FF);

  // Status & Feedback Colors
  static const Color success = Color(0xFF00C853);
  static const Color successDark = Color(0xFF16A34A);
  static const Color successLight = Color(0xFFE8F5E9);

  static const Color danger = Color(0xFFEF4444);
  static const Color dangerDark = Color(0xFFDC2626);
  static const Color dangerLight = Color(0xFFFEE2E2);

  static const Color warning = Color(0xFFF59E0B);
  static const Color warningDark = Color(0xFFD97706);
  static const Color warningLight = Color(0xFFFEF3C7);

  static const Color info = Color(0xFF0284C7);
  static const Color infoLight = Color(0xFFE0F2FE);

  // Neutral Colors & Text
  static const Color textPrimary = Color(0xFF0F172A);
  static const Color textSecondary = Color(0xFF64748B);
  static const Color textMuted = Color(0xFF94A3B8);
  static const Color textDisabled = Color(0xFFCBD5E1);

  // Background & Surfaces
  static const Color background = Color(0xFFF8FAFC);
  static const Color surface = Colors.white;
  static const Color card = Colors.white;
  static const Color border = Color(0xFFE2E8F0);
  static const Color borderLight = Color(0xFFF1F5F9);
  static const Color divider = Color(0xFFE2E8F0);

  // Category Accent Colors
  static const Color categoryMassage = Color(0xFF4ADE80);
  static const Color categoryBeauty = Color(0xFFFB7185);
  static const Color categoryBarber = Color(0xFF38BDF8);
  static const Color categoryCleaning = Color(0xFF34D399);
  static const Color categoryPlumbing = Color(0xFF60A5FA);
  static const Color categoryElectrical = Color(0xFFFBBF24);
  static const Color categoryMechanic = Color(0xFFC084FC);
  static const Color categoryPhotography = Color(0xFF818CF8);
  static const Color categoryTeal = Color(0xFF0D9488);
  static const Color categoryBlue = Color(0xFF2563EB);

  // Hero / Forest Banner
  static const Color heroDark = Color(0xFF1B3D2F);
  static const Color heroDarker = Color(0xFF163226);

  // Mobile Money Brand Colors
  static const Color mpesaRed = Color(0xFFE11D48);
  static const Color tigoBlue = Color(0xFF0284C7);
  static const Color airtelRed = Color(0xFFDC2626);
  static const Color haloGreen = Color(0xFF16A34A);

  // Micro-badges & Highlights
  static const Color onlineGreen = Color(0xFF10B981);
  static const Color goldStar = Color(0xFFF59E0B);
  static const Color slateMuted = Color(0xFF475569);
  static const Color slateDark = Color(0xFF1E293B);
  static const Color navy = Color(0xFF14307A);
}
