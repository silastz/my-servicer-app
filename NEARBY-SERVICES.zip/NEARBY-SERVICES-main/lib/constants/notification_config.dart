/// OneSignal configuration.
///
/// 1. Create an app at https://onesignal.com (Android = FCM, iOS = APNs key).
/// 2. Pass the App ID at build time (App Settings -> Keys & IDs):
///      --dart-define=ONESIGNAL_APP_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
///    (tool/build_release.sh does this from the ONESIGNAL_APP_ID env var).
/// The REST API key must NEVER be put in the app - it stays on your server
/// (see docs/onesignal_send.php).
class NotificationConfig {
  // The App ID is public (it is not the REST API key), so it is safe to keep as the default.
  // A --dart-define=ONESIGNAL_APP_ID=... still overrides it (e.g. for a staging OneSignal app).
  static const String oneSignalAppId =
      String.fromEnvironment('ONESIGNAL_APP_ID', defaultValue: 'd735e239-78de-40bb-8eae-90ae6b64c534');

  static bool get isConfigured =>
      oneSignalAppId.isNotEmpty && oneSignalAppId != 'YOUR_ONESIGNAL_APP_ID';
}
