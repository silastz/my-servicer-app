import 'dart:async';
import 'security/device_integrity.dart';
import 'security/integrity_guard.dart';
import 'security/secure_http.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'screens/home_screen.dart';
import 'screens/chats_screen.dart';
import 'screens/requests_screen.dart';
import 'screens/sell_manage_services_screen.dart';
import 'constants/app_colors.dart';
import 'constants/app_strings.dart';
import 'services/chat_socket.dart';
import 'services/session_manager.dart';
import 'services/attempt_limiter.dart';
import 'services/security_settings.dart';
import 'widgets/app_lock_gate.dart';
import 'services/location_service.dart';
import 'services/gps_service.dart';
import 'services/block_service.dart';
import 'services/chat_prefs.dart';
import 'services/notification_service.dart';
import 'services/notification_feed.dart';
import 'services/data_sync.dart';
import 'services/deep_link_service.dart';
import 'services/app_update_service.dart';
import 'security/vpn_blocked_screen.dart';
import 'services/app_policy.dart';
import 'services/app_policy_service.dart';
import 'screens/notifications_screen.dart';
import 'screens/admin_reports_screen.dart';
import 'screens/admin_bookings_screen.dart';
import 'screens/admin_wallet_screen.dart';
import 'screens/admin_payment_gateway_screen.dart';
import 'screens/chat_thread_screen.dart';
import 'screens/service_details_screen.dart';
import 'services/api_service.dart';
import 'services/permission_service.dart';
import 'services/home_preload.dart';
import 'services/ad_service.dart';
import 'services/ads_config_service.dart';

import 'screens/profile_screen.dart';
import 'screens/splash_screen.dart';
import 'screens/search_filter_screen.dart';
import 'services/currency_service.dart';
import 'services/app_log.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // Show the splash immediately; all start-up work runs behind it (see _AppBootstrap).
  runApp(const _AppBootstrap());
}

/// Shows [SplashScreen] while the app initialises, then fades into the real app.
class _AppBootstrap extends StatefulWidget {
  const _AppBootstrap();

  @override
  State<_AppBootstrap> createState() => _AppBootstrapState();
}

class _AppBootstrapState extends State<_AppBootstrap> with WidgetsBindingObserver {
  /// The splash stays at least this long so the logo animation is not a flash.
  static const Duration _minSplash = Duration(milliseconds: 1500);

  bool _ready = false;
  bool _blocked = false;
  bool _vpnBlocked = false;
  Completer<void>? _vpnRetry;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    SessionManager.sessionExpired.addListener(_onSessionExpired);
    _boot();
  }

  @override
  void dispose() {
    SessionManager.sessionExpired.removeListener(_onSessionExpired);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  /// The server rejected the saved login: close pages that can no longer load, and say why.
  void _onSessionExpired() {
    appNavigatorKey.currentState?.popUntil((route) => route.isFirst);
    final ctx = appNavigatorKey.currentContext;
    if (ctx == null) return;
    final en = AppStrings.isEnglish;
    ScaffoldMessenger.maybeOf(ctx)?.showSnackBar(SnackBar(
      content: Text(en ? 'Your session expired. Please sign in again.' : 'Muda wa kuingia umeisha. Tafadhali ingia tena.'),
    ));
  }

  DateTime? _lastProfileSync;

  /// Refreshes role, badge and profile from /users/me (at most once a minute) so Home's tabs and the
  /// verification badge never stay stale on a restored session. Silent when signed out or offline.
  void _syncProfile({bool force = false}) {
    if (!SessionManager.isLoggedIn()) return;
    final last = _lastProfileSync;
    if (!force && last != null && DateTime.now().difference(last) < const Duration(minutes: 1)) return;
    _lastProfileSync = DateTime.now();
    unawaited(ApiService.syncMyProfile());
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && _ready) _syncProfile();
  }

  Future<void> _boot() async {
    final started = DateTime.now();
    unawaited(AdService.init()); // AdMob starts in the background; never delays the splash
    try {
      await AppPolicy.load(); // admin's saved fees / security switches (needed by the device scan)
      await SecureHttp.init(); // pinned-certificate HTTPS client (no proxy, no cleartext)
      final integrity = await DeviceIntegrity.scan();
      if (integrity.mustBlock) {
        if (mounted) setState(() => _blocked = true);
        return;
      }
      await _waitUntilNoVpn(); // only when the admin switched "block VPN" on (default: off)
      if (!mounted) return;
      await SessionManager.init();
      await CurrencyService.init(); // country money (TSh / KSh / USh...) before any price is drawn
      await SecuritySettings.init();
      await AttemptLimiter.init(); // lock-outs survive an app restart
      // "Remember Me" off: sign in again on every fresh app start.
      if (SessionManager.isLoggedIn() && !SecuritySettings.rememberMe) {
        await SessionManager.clearSession();
      }
      await AppStrings.init();
      LocationService.detectCurrentLocation(forceRefresh: true); // re-check the user's location on EVERY launch (keeps the saved city if the check fails)
      _syncProfile(force: true); // role + badge from the server, in the background (never delays the splash)
      await BlockService.start(); // blocked users: local cache is loaded first so the preloaded feed hides them (server sync continues in background)
      HomePreload.start(); // fetch Home's first page now, in parallel with the rest of start-up
      ChatPrefs.start(); // muted chats + cleared chats (local)
      ChatSocket.start(); // live chat (does nothing while signed out; sign-in starts it)
      GpsService.start(); // GPS fix (if permitted) -> saved to the user's profile in the database
      await _initPush();
      NotificationFeed.start(); // Home bell badge + Notifications screen share this feed
      await HomePreload.waitUpTo(const Duration(seconds: 3)); // splash waits for Home's data, but never more than 3 s
    } catch (e) {
      AppLog.d('Start-up error: $e'); // never leave the user stuck on the splash
    }

    final left = _minSplash - DateTime.now().difference(started);
    if (left > Duration.zero) await Future.delayed(left);
    if (!mounted) return;
    setState(() => _ready = true);

    // Needs the real navigator, so only after the app is on screen.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      DeepLinkService.start(appNavigatorKey); // links from WhatsApp / SMS open the invitation or service
      AppPolicyService.start(); // admin switches (screenshots / screen recording on or off for everyone)
      AdsConfigService.start(); // admin's ad settings: default network, network per page, ad IDs
      AdService.attachNavigator(appNavigatorKey); // lets in-house rewarded ads open full screen
      AppUpdateService.start(appNavigatorKey); // "Update available" dialog when the backend has a newer version
    });
  }

  /// Holds the start-up on a "turn off your VPN" screen until the VPN is off.
  Future<void> _waitUntilNoVpn() async {
    while (mounted && (await DeviceIntegrity.scan()).vpnBlocked) {
      setState(() => _vpnBlocked = true);
      _vpnRetry = Completer<void>();
      await _vpnRetry!.future; // completed by the "Try again" button
    }
    if (mounted && _vpnBlocked) setState(() => _vpnBlocked = false);
  }

  @override
  Widget build(BuildContext context) {
    final Widget child;
    if (_vpnBlocked) {
      child = MaterialApp(
        key: const ValueKey('vpn'),
        debugShowCheckedModeBanner: false,
        home: VpnBlockedScreen(onRetry: () async {
          // Only continue start-up once a fresh scan shows the VPN is really off.
          final off = !(await DeviceIntegrity.scan()).vpnBlocked;
          final c = _vpnRetry;
          if (off && c != null && !c.isCompleted) c.complete();
        }),
      );
    } else if (_blocked) {
      child = const _BlockedApp(key: ValueKey('blocked'));
    } else if (_ready) {
      child = const NearbyServicesApp(key: ValueKey('app'));
    } else {
      child = const MaterialApp(
        key: ValueKey('splash'),
        debugShowCheckedModeBanner: false,
        home: SplashScreen(),
      );
    }
    return AnimatedSwitcher(duration: const Duration(milliseconds: 350), child: child);
  }
}

final GlobalKey<NavigatorState> appNavigatorKey = GlobalKey<NavigatorState>();

/// OneSignal push setup: link device to the user, tag city/language,
/// and open the notifications screen when a push is tapped.
Future<void> _initPush() async {
  await NotificationService.init();

  if (SessionManager.isLoggedIn()) {
    NotificationService.login(
      SessionManager.getUserIdValue().toString(),
      role: SessionManager.getRole(),
    );
  }

  NotificationService.setCity(LocationService.currentCity);
  LocationService.activeLocationNotifier.addListener(() {
    NotificationService.setCity(LocationService.currentCity);
  });

  void syncLang() =>
      NotificationService.setLanguage(AppStrings.isEnglish ? 'en' : 'sw');
  syncLang();
  AppStrings.currentLanguage.addListener(syncLang);

  // A tapped push opens what it is about: a message opens that chat, a booking / payment / offer
  // opens Requests, anything else (or a signed-out user) opens the Notifications screen.
  NotificationService.onNotificationTap = (data) {
    final nav = appNavigatorKey.currentState;
    if (nav == null) return;
    final type = '${data['type'] ?? ''}'.toLowerCase();
    final signedIn = SessionManager.isLoggedIn();

    if (signedIn && (type.contains('message') || type.contains('chat'))) {
      final id = int.tryParse('${data['id'] ?? data['senderId'] ?? ''}');
      if (id != null && id != 0 && id != SessionManager.getUserIdValue()) {
        final name = '${data['_title'] ?? ''}'.trim();
        nav.push(MaterialPageRoute(
          builder: (_) => ChatThreadScreen(otherUserId: id.toString(), otherName: name.isEmpty ? 'Chat' : name),
        ));
        DataSync.bump();
        return;
      }
    }

    // An admin alert (new report, payment dispute, withdrawal to pay out) opens the screen that handles it.
    // Only for a signed-in admin; anyone else falls through to the Notifications screen.
    if (signedIn && type.startsWith('admin_') && SessionManager.isAdmin()) {
      final Widget? target = switch (type) {
        'admin_report' => const AdminReportsScreen(),
        'admin_dispute' => const AdminBookingsScreen(),
        'admin_withdrawal' => const AdminWalletScreen(),
        'admin_pay_error' => const AdminPaymentGatewayScreen(),
        _ => null,
      };
      if (target != null) {
        nav.push(MaterialPageRoute(builder: (_) => target));
        return;
      }
    }

    // A promo push (a boosted service) opens that service. If it is gone, the Notifications screen opens instead.
    if (type == 'promo_service') {
      final serviceId = '${data['id'] ?? ''}'.trim();
      if (serviceId.isNotEmpty) {
        _openPromoService(nav, serviceId);
        return;
      }
    }

    final isRequest = type.contains('booking') ||
        type.contains('request') ||
        type.contains('payment') ||
        type.contains('escrow') ||
        type.contains('offer');
    nav.push(MaterialPageRoute(
      builder: (_) => signedIn && isRequest ? const RequestsScreen() : const NotificationsScreen(),
    ));
  };
}

Future<void> _openPromoService(NavigatorState nav, String serviceId) async {
  final item = await ApiService.fetchServiceById(serviceId);
  if (!nav.mounted) return;
  nav.push(MaterialPageRoute(
    builder: (_) => item == null ? const NotificationsScreen() : ServiceDetailsScreen(service: item),
  ));
}

class NearbyServicesApp extends StatelessWidget {
  const NearbyServicesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppLanguage>(
      valueListenable: AppStrings.currentLanguage,
      builder: (context, lang, _) {
        return MaterialApp(
          title: 'Ungana',
          navigatorKey: appNavigatorKey,
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            useMaterial3: true,
            scaffoldBackgroundColor: Colors.white,
            snackBarTheme: SnackBarThemeData(
              behavior: SnackBarBehavior.floating,
              backgroundColor: AppColors.slateDark,
              contentTextStyle: const TextStyle(fontSize: 13, color: Colors.white),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            switchTheme: SwitchThemeData(
              thumbColor: WidgetStateProperty.all(Colors.white),
              trackColor: WidgetStateProperty.resolveWith(
                (states) => states.contains(WidgetState.selected) ? AppColors.primary : AppColors.textDisabled,
              ),
              trackOutlineColor: WidgetStateProperty.all(Colors.transparent),
            ),
          ),
          builder: (context, child) =>
              IntegrityGuard(child: AppLockGate(child: child ?? const SizedBox.shrink())),
          home: const MainTabScaffold(),
        );
      },
    );
  }
}

// -------------------------------------------------------------
// MAIN TAB SCAFFOLD (Bottom navigation orchestrator)
// -------------------------------------------------------------
class MainTabScaffold extends StatefulWidget {
  const MainTabScaffold({super.key});

  @override
  State<MainTabScaffold> createState() => _MainTabScaffoldState();
}

class _MainTabScaffoldState extends State<MainTabScaffold> {
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    // Real OS permission prompts only (no custom dialog), once the first frame is up.
    WidgetsBinding.instance.addPostFrameCallback((_) => PermissionService.requestStartupPermissions());
  }

  // Double back to exit: first back on Home shows a hint, a second back within
  // [_exitWindow] closes the app.
  static const Duration _exitWindow = Duration(seconds: 2);
  DateTime? _lastBackPress;

  void _handleExitBack() {
    final now = DateTime.now();
    final last = _lastBackPress;
    if (last != null && now.difference(last) <= _exitWindow) {
      SystemNavigator.pop();
      return;
    }
    _lastBackPress = now;
    final messenger = ScaffoldMessenger.of(context);
    messenger.hideCurrentSnackBar();
    messenger.showSnackBar(
      SnackBar(
        content: Text(AppStrings.exitAppPressAgain, textAlign: TextAlign.center),
        duration: _exitWindow,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppLanguage>(
      valueListenable: AppStrings.currentLanguage,
      builder: (context, currentLang, _) {
        return ValueListenableBuilder<int>(
          valueListenable: SessionManager.sessionNotifier,
          builder: (context, sessionTick, child) {
            final isLoggedIn = SessionManager.isLoggedIn();
            final isSeller = SessionManager.isSeller();

            // Defined menus per role:
            // 1. Guest: Home, Chats, Sell, Search, Profile
            // 2. Buyer: Home, Chats, Requests, Sell, Profile
            // 3. Provider/Seller: Home, Chats, Requests, Services, Profile (Earnings = top icon on Home)
            final List<Widget> pages = [];
            final List<Map<String, dynamic>> navItems = [];

            // Tab 1: Home (All roles)
            pages.add(const HomeScreen());
            navItems.add({
              'icon': Icons.home_rounded,
              'label': AppStrings.navHome,
            });

            // Tab 2: Chats (All roles)
            pages.add(const ChatsScreen());
            navItems.add({
              'icon': Icons.chat_bubble_outline_rounded,
              'label': AppStrings.navChats,
            });

            if (!isLoggedIn) {
              // GUEST: [Home, Chats, Sell, Search, Profile]
              pages.add(SellManageServicesScreen(
                onBackToHome: () => setState(() => _currentIndex = 0),
              ));
              navItems.add({
                'icon': Icons.storefront_rounded,
                'label': AppStrings.navSell,
              });

              pages.add(SearchFilterScreen(
                onBackToHome: () => setState(() => _currentIndex = 0),
              ));
              navItems.add({
                'icon': Icons.search_rounded,
                'label': AppStrings.navSearch,
              });

              pages.add(const ProfileScreen());
              navItems.add({
                'icon': Icons.person_outline_rounded,
                'label': AppStrings.navProfile,
              });
            } else if (!isSeller) {
              // BUYER: [Home, Chats, Requests, Sell, Profile]
              pages.add(const RequestsScreen());
              navItems.add({
                'icon': Icons.receipt_long_rounded,
                'label': AppStrings.navRequests,
              });

              pages.add(SellManageServicesScreen(
                onBackToHome: () => setState(() => _currentIndex = 0),
              ));
              navItems.add({
                'icon': Icons.storefront_rounded,
                'label': AppStrings.navSell,
              });

              pages.add(const ProfileScreen());
              navItems.add({
                'icon': Icons.person_outline_rounded,
                'label': AppStrings.navProfile,
              });
            } else {
              // PROVIDER / SELLER: [Home, Chats, Requests, Services, Profile]
              pages.add(const RequestsScreen());
              navItems.add({
                'icon': Icons.receipt_long_rounded,
                'label': AppStrings.navRequests,
              });

              pages.add(SellManageServicesScreen(
                onBackToHome: () => setState(() => _currentIndex = 0),
              ));
              navItems.add({
                'icon': Icons.storefront_rounded,
                'label': AppStrings.navServices,
              });

              pages.add(const ProfileScreen());
              navItems.add({
                'icon': Icons.person_outline_rounded,
                'label': AppStrings.navProfile,
              });
            }

            // Ensure current index is within bounds when switching auth/role
            if (_currentIndex >= pages.length) {
              _currentIndex = 0;
            }
            final effectiveIndex = _currentIndex;

            return PopScope(
              // Always intercept back: go to Home first, then press back twice to exit.
              canPop: false,
              onPopInvokedWithResult: (didPop, result) {
                if (didPop) return;
                if (effectiveIndex != 0) {
                  setState(() => _currentIndex = 0);
                } else {
                  _handleExitBack();
                }
              },
              child: Scaffold(
                backgroundColor: Colors.white,
                body: IndexedStack(
                  index: effectiveIndex,
                  children: pages,
                ),
              bottomNavigationBar: Container(
                decoration: const BoxDecoration(
                  color: AppColors.surface,
                  border: Border(
                    top: BorderSide(
                      color: AppColors.borderLight,
                      width: 1,
                    ),
                  ),
                ),
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: List.generate(navItems.length, (idx) {
                        final item = navItems[idx];
                        return _buildNavItem(
                          idx,
                          effectiveIndex,
                          item['icon'] as IconData,
                          item['icon'] as IconData,
                          item['label'] as String,
                        );
                      }),
                    ),
                  ),
                ),
              ),
            ),
          );
          },
        );
      },
    );
  }

  Widget _buildNavItem(int index, int activeIndex, IconData activeIcon, IconData inactiveIcon, String label) {
    final isSelected = activeIndex == index;
    const activeColor = AppColors.primary;
    const inactiveColor = AppColors.textSecondary;

    return InkWell(
      onTap: () => setState(() => _currentIndex = index),
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              isSelected ? activeIcon : inactiveIcon,
              size: 22,
              color: isSelected ? activeColor : inactiveColor,
            ),
            const SizedBox(height: 3),
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                color: isSelected ? activeColor : inactiveColor,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Shown instead of the app on a rooted / hooked / debugged device.
class _BlockedApp extends StatelessWidget {
  const _BlockedApp({super.key});

  @override
  Widget build(BuildContext context) => const MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          body: Center(
            child: Padding(
              padding: EdgeInsets.all(32),
              child: Text(
                'For your security, Ungana cannot run on this device.\n'
                'Kwa usalama wako, Ungana haiwezi kufanya kazi kwenye kifaa hiki.',
                textAlign: TextAlign.center,
              ),
            ),
          ),
        ),
      );
}
