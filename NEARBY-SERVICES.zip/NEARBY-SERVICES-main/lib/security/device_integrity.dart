import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import '../services/app_policy.dart';
import 'client_security_config.dart';
import '../services/app_log.dart';

/// What the device scan found (Android; other platforms report all-clear).
class IntegrityReport {
  final bool rooted, debugger, hooking, proxy, vpn, userCa, tampered;
  const IntegrityReport({
    this.rooted = false,
    this.debugger = false,
    this.hooking = false,
    this.proxy = false,
    this.vpn = false,
    this.userCa = false,
    this.tampered = false,
  });

  /// Serious: someone can read memory/traffic or modify the app. App refuses to run.
  bool get compromised => rooted || debugger || hooking || tampered;

  /// A VPN is active AND blocking VPNs is switched on (admin policy, default OFF).
  /// Unlike [mustBlock] this is not a compromised device: the user can fix it by turning the VPN off.
  bool get vpnBlocked =>
      ClientSecurityConfig.enforce && (AppPolicy.blockVpn ?? ClientSecurityConfig.blockVpn) && vpn;

  /// Sniffing tools present on the device. Traffic is already protected (pinning,
  /// no proxy, system-CA only), so these only warn and are logged in debug.
  bool get sniffingSetup => proxy || vpn || userCa;

  bool get mustBlock =>
      ClientSecurityConfig.enforce && (AppPolicy.blockCompromisedDevice ?? ClientSecurityConfig.blockCompromisedDevice) && compromised;
}

class DeviceIntegrity {
  DeviceIntegrity._();
  static const MethodChannel _ch = MethodChannel('ungana/security');
  static IntegrityReport last = const IntegrityReport();

  /// True only when an expected signer is configured AND the installed APK is signed by someone else
  /// (repackaged / modified copy). Unconfigured = never flags anyone.
  static Future<bool> _tampered() async {
    final expected = ClientSecurityConfig.expectedSigners
        .toLowerCase()
        .split(',')
        .map((e) => e.replaceAll(':', '').trim())
        .where((e) => e.isNotEmpty)
        .toSet();
    if (expected.isEmpty) return false;
    try {
      final have = (await _ch.invokeListMethod<String>('signer')) ?? const <String>[];
      if (have.isEmpty) return false; // could not read -> do not punish the user
      return !have.any(expected.contains);
    } catch (caught, trace) {
      AppLog.e('device_integrity._tampered', caught, trace);
      return false;
    }
  }

  static Future<IntegrityReport> scan() async {
    try {
      final m = await _ch.invokeMapMethod<String, bool>('scan');
      if (m == null) return last;
      last = IntegrityReport(
        rooted: m['rooted'] ?? false,
        debugger: m['debugger'] ?? false,
        hooking: m['hooking'] ?? false,
        proxy: m['proxy'] ?? false,
        vpn: m['vpn'] ?? false,
        userCa: m['userCa'] ?? false,
        tampered: await _tampered(),
      );
    } on MissingPluginException {
      // iOS / web / desktop: no native scanner.
    } catch (e) {
      if (kDebugMode) AppLog.d('[Security] scan failed: $e');
    }
    return last;
  }
}
