import 'package:flutter/material.dart';

import '../services/app_policy.dart';
import 'device_integrity.dart';
import 'vpn_blocked_screen.dart';

/// Re-scans the device whenever the app returns to the foreground or the admin's policy changes (someone could attach
/// Frida / a debugger after launch). Normal users never see anything: it only reacts to
/// root / hooks / debugger / repackaged app, never to VPN, developer options or USB debugging.
class IntegrityGuard extends StatefulWidget {
  final Widget child;
  const IntegrityGuard({super.key, required this.child});

  @override
  State<IntegrityGuard> createState() => _IntegrityGuardState();
}

class _IntegrityGuardState extends State<IntegrityGuard> with WidgetsBindingObserver {
  bool _blocked = false;
  bool _vpn = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    AppPolicy.changed.addListener(_scan); // the admin just switched something (e.g. block VPN)
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    AppPolicy.changed.removeListener(_scan);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) return;
    _scan();
  }

  Future<void> _scan() async {
    final r = await DeviceIntegrity.scan();
    if (!mounted) return;
    final vpn = r.vpnBlocked;
    if ((r.mustBlock && !_blocked) || vpn != _vpn) {
      setState(() {
        if (r.mustBlock) _blocked = true;
        _vpn = vpn;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_blocked && _vpn) return VpnBlockedScreen(onRetry: _scan);
    if (!_blocked) return widget.child;
    return const Scaffold(
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Text(
            'For your security, Ungana cannot run on this device.\n'
            'Kwa usalama wako, Ungana haiwezi kufanya kazi kwenye kifaa hiki.',
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
