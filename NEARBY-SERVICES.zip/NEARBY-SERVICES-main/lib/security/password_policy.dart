import '../constants/app_strings.dart';

/// Rules for NEW passwords (sign-up and reset). Login never applies them, so old accounts still work.
///
/// Any format is allowed (letters, numbers, symbols, in any mix): the only rule is the length.
/// The longest allowed password is set in [InputValidation.passwordMax].
class PasswordPolicy {
  PasswordPolicy._();

  static const int minLength = 4;

  /// Returns an error message (already translated) or null when the password is acceptable.
  /// [phoneOrId] is kept so existing callers do not change; it is no longer used.
  static String? validate(String password, {String? phoneOrId}) {
    if (password.length < minLength) return AppStrings.authPasswordHint;
    return null;
  }
}
