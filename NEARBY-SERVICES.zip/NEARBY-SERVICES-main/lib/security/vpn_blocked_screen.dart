import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

/// Shown while a VPN is on and the admin has switched "block VPN" on.
/// Bilingual on purpose: it can appear before the app's language is loaded.
class VpnBlockedScreen extends StatefulWidget {
  /// Re-scans the device; the screen disappears by itself once the VPN is off.
  final Future<void> Function() onRetry;
  const VpnBlockedScreen({super.key, required this.onRetry});

  @override
  State<VpnBlockedScreen> createState() => _VpnBlockedScreenState();
}

class _VpnBlockedScreenState extends State<VpnBlockedScreen> {
  bool _busy = false;
  bool _stillOn = false;

  Future<void> _retry() async {
    setState(() => _busy = true);
    await widget.onRetry();
    if (mounted) setState(() {
      _busy = false;
      _stillOn = true; // if we are still here, the VPN is still on
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.vpn_lock_rounded, size: 56, color: AppColors.primary),
                const SizedBox(height: 20),
                const Text(
                  'VPN detected / VPN imegunduliwa',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                ),
                const SizedBox(height: 12),
                const Text(
                  'For your security, turn off your VPN to use Ungana.\n'
                  'Kwa usalama wako, zima VPN ili kutumia Ungana.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 14, height: 1.45, color: AppColors.textSecondary),
                ),
                if (_stillOn && !_busy) ...[
                  const SizedBox(height: 12),
                  const Text(
                    'VPN is still on / VPN bado imewashwa',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.danger),
                  ),
                ],
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton(
                    onPressed: _busy ? null : _retry,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    child: _busy
                        ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
                        : const Text('Try again / Jaribu tena',
                            style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w800)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
