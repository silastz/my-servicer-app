import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import 'app_ui.dart';

enum UpdateChoice { update, later }

/// "New version available" dialog. When [mustUpdate] is true it cannot be
/// dismissed (no Later button, tapping outside and the back button do nothing).
class UpdateDialog {
  static Future<UpdateChoice?> show(
    BuildContext context, {
    required String installed,
    required String latest,
    required bool mustUpdate,
    String? messageEn,
    String? messageSw,
  }) {
    final en = AppStrings.isEnglish;
    final custom = (en ? messageEn : messageSw) ?? messageEn;
    final message = custom ??
        (mustUpdate
            ? (en
                ? 'This version is no longer supported. Please update to keep using Ungana.'
                : 'Toleo hili halitumiki tena. Tafadhali sasisha ili uendelee kutumia Ungana.')
            : (en
                ? 'A new version of Ungana is ready with improvements and fixes.'
                : 'Toleo jipya la Ungana liko tayari na maboresho na marekebisho.'));

    return showDialog<UpdateChoice>(
      context: context,
      barrierDismissible: !mustUpdate,
      builder: (ctx) => PopScope(
        canPop: !mustUpdate,
        child: Dialog(
          backgroundColor: AppColors.surface,
          insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(color: AppColors.primary.withValues(alpha: 0.12), shape: BoxShape.circle),
                  child: const Icon(Icons.system_update_rounded, color: AppColors.primary, size: 28),
                ),
                const SizedBox(height: 16),
                Text(
                  mustUpdate ? (en ? 'Update required' : 'Sasisho linahitajika') : (en ? 'Update available' : 'Sasisho linapatikana'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                ),
                const SizedBox(height: 8),
                Text(
                  message,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 13, height: 1.45, color: AppColors.textSecondary),
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(color: AppColors.primaryLight, borderRadius: BorderRadius.circular(20)),
                  child: Text(
                    '$installed  →  $latest',
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.primary),
                  ),
                ),
                const SizedBox(height: 20),
                AppButton.primary(
                  label: en ? 'Update now' : 'Sasisha sasa',
                  onPressed: () => Navigator.pop(ctx, UpdateChoice.update),
                ),
                if (!mustUpdate) ...[
                  const SizedBox(height: 10),
                  AppButton.outlined(
                    label: en ? 'Later' : 'Baadaye',
                    onPressed: () => Navigator.pop(ctx, UpdateChoice.later),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
