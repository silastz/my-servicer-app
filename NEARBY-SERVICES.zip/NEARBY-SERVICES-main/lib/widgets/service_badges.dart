import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';

/// How one earned badge looks. Badges are awarded by the server (admin rules based on
/// the provider's reviews); the app only draws what the server sent.
class ServiceBadgeInfo {
  final String label;
  final IconData icon;
  final Color iconColor;
  final Color bgColor;
  const ServiceBadgeInfo(this.label, this.icon, this.iconColor, this.bgColor);

  /// Known keys get their own look; any other key the admin adds still shows, with its name.
  static ServiceBadgeInfo of(String key) {
    final en = AppStrings.isEnglish;
    switch (key.trim().toUpperCase().replaceAll(RegExp(r'[\s-]+'), '_')) {
      case 'TOP_RATED':
        return ServiceBadgeInfo(en ? 'Top Rated' : 'Ukadiriaji wa Juu', Icons.star_rounded, AppColors.goldStar, AppColors.warningLight);
      case 'PROFESSIONAL':
        return ServiceBadgeInfo(en ? 'Professional' : 'Mtaalamu', Icons.check_circle_rounded, AppColors.success, AppColors.successLight);
      case 'CLEAN_SAFE':
      case 'CLEAN_AND_SAFE':
        return ServiceBadgeInfo(en ? 'Clean & Safe' : 'Safi na Salama', Icons.auto_awesome_rounded, AppColors.primary, AppColors.primaryLight);
      case 'LOVED_BY_CUSTOMERS':
      case 'CUSTOMER_FAVORITE':
        return ServiceBadgeInfo(en ? 'Customer Favorite' : 'Pendwa na Wateja', Icons.favorite_rounded, AppColors.danger, AppColors.dangerLight);
      case 'RELIABLE':
      case 'ON_TIME':
        return ServiceBadgeInfo(en ? 'Reliable' : 'Anaaminika', Icons.schedule_rounded, AppColors.info, AppColors.infoLight);
      default:
        final pretty = key
            .trim()
            .replaceAll(RegExp(r'[_-]+'), ' ')
            .toLowerCase()
            .split(' ')
            .where((w) => w.isNotEmpty)
            .map((w) => '${w[0].toUpperCase()}${w.substring(1)}')
            .join(' ');
        return ServiceBadgeInfo(pretty, Icons.workspace_premium_rounded, AppColors.primary, AppColors.primaryLight);
    }
  }
}

/// Badges worked out by the app itself from the provider's real review numbers, so they
/// appear and disappear automatically as reviews come in. Badges the server also sent
/// (e.g. an admin award) are kept and merged in.
class ServiceBadgeRules {
  static const double topRatedMinRating = 4.8;
  static const int topRatedMinReviews = 10;
  static const double professionalMinRating = 4.5;
  static const int professionalMinReviews = 5;
  static const double favoriteMinRating = 4.6;
  static const int favoriteMinReviews = 25;

  static List<String> earned({
    required double rating,
    required int reviewsCount,
    List<String> fromServer = const [],
  }) {
    final out = <String>[...fromServer];
    void add(String key) {
      if (!out.any((e) => e.toUpperCase() == key)) out.add(key);
    }

    if (reviewsCount >= topRatedMinReviews && rating >= topRatedMinRating) add('TOP_RATED');
    if (reviewsCount >= professionalMinReviews && rating >= professionalMinRating) add('PROFESSIONAL');
    if (reviewsCount >= favoriteMinReviews && rating >= favoriteMinRating) add('CUSTOMER_FAVORITE');
    return out;
  }
}
