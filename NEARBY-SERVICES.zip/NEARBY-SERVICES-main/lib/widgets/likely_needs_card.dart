import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/customer_needs.dart';
import '../screens/category_detail_screen.dart';
import '../services/need_signals.dart';

/// Home section: "Looks like you need..." built by [NeedEngine] from what the
/// customer searched, opened, saved and booked. Takes no space until it has a
/// confident guess, so new customers just see the normal home screen.
class LikelyNeedsCard extends StatefulWidget {
  const LikelyNeedsCard({super.key});

  @override
  State<LikelyNeedsCard> createState() => _LikelyNeedsCardState();
}

class _LikelyNeedsCardState extends State<LikelyNeedsCard> {
  List<NeedPrediction> _needs = const [];
  final Set<String> _dismissed = {}; // hidden for this session only

  @override
  void initState() {
    super.initState();
    NeedSignals.changed.addListener(_refresh);
    _refresh();
  }

  @override
  void dispose() {
    NeedSignals.changed.removeListener(_refresh);
    super.dispose();
  }

  Future<void> _refresh() async {
    final p = await NeedSignals.predict(limit: 4);
    if (!mounted) return;
    setState(() => _needs = p);
  }

  static const Map<String, IconData> _icons = {
    'Massage': Icons.spa_rounded,
    'Beauty': Icons.face_retouching_natural_rounded,
    'Barber': Icons.content_cut_rounded,
    'Cleaning': Icons.cleaning_services_rounded,
    'Plumbing': Icons.plumbing_rounded,
    'Electrical': Icons.bolt_rounded,
    'Mechanic': Icons.build_rounded,
    'Photography': Icons.photo_camera_rounded,
    'Repair': Icons.handyman_rounded,
  };

  static const Map<String, Color> _colors = {
    'Massage': AppColors.categoryMassage,
    'Beauty': AppColors.categoryBeauty,
    'Barber': AppColors.categoryBarber,
    'Cleaning': AppColors.categoryCleaning,
    'Plumbing': AppColors.categoryPlumbing,
    'Electrical': AppColors.categoryElectrical,
    'Mechanic': AppColors.categoryMechanic,
    'Photography': AppColors.categoryPhotography,
    'Repair': AppColors.categoryTeal,
  };

  String _t(String en, String sw) => AppStrings.isEnglish ? en : sw;

  String _label(String key) {
    switch (key) {
      case 'Massage': return AppStrings.catMassage;
      case 'Beauty': return AppStrings.catBeauty;
      case 'Barber': return AppStrings.catBarber;
      case 'Cleaning': return AppStrings.catCleaning;
      case 'Plumbing': return AppStrings.catPlumbing;
      case 'Electrical': return AppStrings.catElectrical;
      case 'Mechanic': return AppStrings.catMechanic;
      case 'Photography': return AppStrings.catPhotography;
      case 'Repair': return AppStrings.catRepair;
      default: return AppStrings.catGeneral;
    }
  }

  /// One short, honest sentence about why this is suggested.
  String _why(NeedPrediction p) {
    switch (p.topReason) {
      case NeedReason.urgent:
        return _t('Needed soon? Find someone fast', 'Unahitaji haraka? Pata mtoa huduma upesi');
      case NeedReason.searched:
        final q = p.evidence;
        return q != null && q.length <= 22
            ? _t('You searched "$q"', 'Ulitafuta "$q"')
            : _t('You searched for this recently', 'Ulitafuta hii hivi karibuni');
      case NeedReason.saved:
        return _t('You saved one like this', 'Ulihifadhi huduma kama hii');
      case NeedReason.browsed:
        return _t('You looked at these lately', 'Umeangalia hizi hivi karibuni');
      case NeedReason.dueAgain:
        final d = p.daysSinceBooking;
        return d == null
            ? _t('Time for another one?', 'Muda wa nyingine?')
            : _t('Last booked $d days ago', 'Uliweka oda siku $d zilizopita');
      case NeedReason.related:
        return _t('Goes well with your recent booking', 'Inaendana na oda yako ya karibuni');
      case NeedReason.timeOfDay:
        return _t('Popular right now', 'Maarufu kwa sasa');
    }
  }

  void _open(NeedPrediction p) {
    NeedSignals.recordCategoryOpen(p.category);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CategoryDetailScreen(
          categoryTitle: _label(p.category),
          categoryApiKey: p.category,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppLanguage>(
      valueListenable: AppStrings.currentLanguage,
      builder: (context, _, __) {
        final shown = _needs.where((n) => !_dismissed.contains(n.category)).toList();
        if (shown.isEmpty) return const SizedBox.shrink();
        return Padding(
          padding: const EdgeInsets.only(bottom: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _t('You may need', 'Huenda unahitaji'),
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  color: AppColors.textPrimary,
                  letterSpacing: -0.3,
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                height: 92,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: shown.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 10),
                  itemBuilder: (_, i) => _tile(shown[i]),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _tile(NeedPrediction p) {
    final color = _colors[p.category] ?? AppColors.primary;
    return Semantics(
      button: true,
      label: '${_label(p.category)}. ${_why(p)}',
      child: InkWell(
        onTap: () => _open(p),
        borderRadius: BorderRadius.circular(16),
        child: Container(
          width: 224,
          padding: const EdgeInsets.fromLTRB(12, 10, 4, 10),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: p.urgent ? color : AppColors.border),
          ),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.16),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(_icons[p.category] ?? Icons.miscellaneous_services_rounded, color: color),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _label(p.category),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      _why(p),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 11.5,
                        color: AppColors.textSecondary,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                visualDensity: VisualDensity.compact,
                tooltip: _t('Not now', 'Si sasa'),
                icon: const Icon(Icons.close_rounded, size: 16, color: AppColors.textMuted),
                onPressed: () => setState(() => _dismissed.add(p.category)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
