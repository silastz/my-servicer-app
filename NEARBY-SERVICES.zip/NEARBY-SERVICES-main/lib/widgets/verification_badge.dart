import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/models.dart';

/// Single source of truth for the provider verification marks.
/// A provider has exactly ONE level, so only ONE mark is ever drawn and the
/// blue and green marks can never appear together for the same provider:
///   greenIdentity -> green  (identity fully verified; can invite)
///   blueBusiness  -> blue   (Verified Business, on top of Green; can invite)
///   none          -> nothing
class VerificationBadge extends StatelessWidget {
  final VerificationLevel level;
  final double size;

  /// Set false to hide the green badge on a surface that only wants the blue one.
  final bool showGreen;

  const VerificationBadge({
    super.key,
    required this.level,
    this.size = 14,
    this.showGreen = true,
  });

  @override
  Widget build(BuildContext context) {
    switch (level) {
      case VerificationLevel.blueBusiness:
        return Icon(Icons.verified_rounded, size: size, color: AppColors.primary);
      case VerificationLevel.greenIdentity:
        if (!showGreen) return const SizedBox.shrink();
        return Icon(Icons.verified_rounded, size: size, color: AppColors.success);
      case VerificationLevel.none:
        return const SizedBox.shrink();
    }
  }
}

/// Pill version ("Verified") driven by the provider's real level.
/// Renders nothing for unverified providers, blue for blue tick, green for green badge.
class VerificationPill extends StatelessWidget {
  final VerificationLevel level;
  final String? label;

  /// Small variant for thumbnails/list cards.
  final bool compact;

  const VerificationPill({super.key, required this.level, this.label, this.compact = false});

  @override
  Widget build(BuildContext context) {
    if (level == VerificationLevel.none) return const SizedBox.shrink();
    final isBlue = level == VerificationLevel.blueBusiness;
    return Container(
      padding: compact
          ? const EdgeInsets.symmetric(horizontal: 5, vertical: 2)
          : const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: isBlue ? AppColors.primary : AppColors.success,
        borderRadius: BorderRadius.circular(compact ? 6 : 20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.verified_rounded, color: Colors.white, size: compact ? 9 : 14),
          SizedBox(width: compact ? 2 : 4),
          Text(
            label ?? AppStrings.detailsVerifiedProvider,
            style: TextStyle(color: Colors.white, fontSize: compact ? 8 : 11, fontWeight: FontWeight.w700),
          ),
        ],
      ),
    );
  }
}

/// "Verified Business" chip: the provider's business documents were checked.
/// A separate mark from the green/blue identity badges (gold, so it never clashes).
class VerifiedBusinessChip extends StatelessWidget {
  final bool compact;
  const VerifiedBusinessChip({super.key, this.compact = false});

  @override
  Widget build(BuildContext context) {
    final en = AppStrings.isEnglish;
    // The badge only says "Verified Business"; the business name is shown next to it by the caller.
    final label = en ? 'Verified Business' : 'Biashara Iliyothibitishwa';
    return Container(
      padding: EdgeInsets.symmetric(horizontal: compact ? 6 : 10, vertical: compact ? 2 : 4),
      decoration: BoxDecoration(
        color: AppColors.warningLight,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.warning.withValues(alpha: 0.5)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.business_center_rounded, size: compact ? 11 : 13, color: AppColors.warningDark),
          const SizedBox(width: 4),
          Flexible(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: compact ? 10 : 11.5, fontWeight: FontWeight.w800, color: AppColors.warningDark),
            ),
          ),
        ],
      ),
    );
  }
}
