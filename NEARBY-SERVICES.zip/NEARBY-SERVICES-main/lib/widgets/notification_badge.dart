import 'package:flutter/material.dart';

import '../constants/app_colors.dart';

/// Unread-count badge for the notification bell.
///  * One digit: a 20px circle. Two or more digits ("12", "99+"): widens into a pill.
///  * Pops in (small bounce) whenever the count changes.
///  * A soft red ring pulses outward every 2 seconds.
///  * Hidden at 0. Both animations stop when the device has animations turned off.
class NotificationBadge extends StatefulWidget {
  const NotificationBadge({super.key, required this.count});

  final int count;

  @override
  State<NotificationBadge> createState() => _NotificationBadgeState();
}

class _NotificationBadgeState extends State<NotificationBadge> with TickerProviderStateMixin {
  late final AnimationController _pop = AnimationController(vsync: this, duration: const Duration(milliseconds: 450));
  late final AnimationController _pulse = AnimationController(vsync: this, duration: const Duration(seconds: 2));

  @override
  void initState() {
    super.initState();
    if (widget.count > 0) {
      _pop.forward();
      _pulse.repeat();
    }
  }

  @override
  void didUpdateWidget(NotificationBadge old) {
    super.didUpdateWidget(old);
    if (widget.count == old.count) return;
    if (widget.count > 0) {
      _pop.forward(from: 0);
      if (!_pulse.isAnimating) _pulse.repeat();
    } else {
      _pulse.stop();
    }
  }

  @override
  void dispose() {
    _pop.dispose();
    _pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final count = widget.count;
    if (count <= 0) return const SizedBox.shrink();

    final still = MediaQuery.disableAnimationsOf(context);
    final label = count > 99 ? '99+' : '$count';
    final wide = label.length > 1;

    final badge = Container(
      height: 20,
      constraints: BoxConstraints(minWidth: wide ? 26 : 20),
      padding: EdgeInsets.symmetric(horizontal: wide ? 5 : 0),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: AppColors.danger,
        shape: wide ? BoxShape.rectangle : BoxShape.circle,
        borderRadius: wide ? BorderRadius.circular(10) : null,
        border: Border.all(color: Colors.white, width: 2),
      ),
      child: Text(
        label,
        style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800, height: 1.0),
      ),
    );

    if (still) return Semantics(label: '$count unread', child: badge);

    return Semantics(
      label: '$count unread',
      child: ScaleTransition(
        scale: CurvedAnimation(parent: _pop, curve: Curves.elasticOut),
        child: AnimatedBuilder(
          animation: _pulse,
          builder: (context, child) {
            // Ring grows from 0 to 8px and fades out over the first 70% of the cycle.
            final t = (_pulse.value / 0.7).clamp(0.0, 1.0);
            return DecoratedBox(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.danger.withValues(alpha: 0.55 * (1 - t)),
                    spreadRadius: 8 * t,
                  ),
                ],
              ),
              child: child,
            );
          },
          child: badge,
        ),
      ),
    );
  }
}
