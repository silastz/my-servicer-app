import 'dart:async';

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/house_ads.dart';
import '../services/ads/rewarded_source.dart';
import '../services/app_log.dart';

/// Full-screen in-house rewarded ad. Counts down [HouseAd.rewardSeconds]; when it reaches zero the
/// reward is earned and the close button returns [RewardedResult.rewarded]. Closing earlier (the
/// X or the back button) returns [RewardedResult.skipped]. The button opens the ad's https link
/// without closing the ad. The ad always carries the "Ad" label.
class HouseRewardedScreen extends StatefulWidget {
  const HouseRewardedScreen({super.key, required this.ad, required this.image});

  final HouseAd ad;
  final ImageProvider image;

  @override
  State<HouseRewardedScreen> createState() => _HouseRewardedScreenState();
}

class _HouseRewardedScreenState extends State<HouseRewardedScreen> {
  late int _left = widget.ad.rewardSeconds;
  Timer? _timer;

  bool get _earned => _left <= 0;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      setState(() => _left--);
      if (_left <= 0) t.cancel();
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _close() => Navigator.of(context).pop(_earned ? RewardedResult.rewarded : RewardedResult.skipped);

  Future<void> _open() async {
    final url = widget.ad.url;
    if (!HouseAds.validUrl(url)) return;
    try {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (e) {
      AppLog.d('House ad link failed: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final ad = widget.ad;
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _close();
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 4, 12, 0),
                child: Row(
                  children: [
                    IconButton(
                      onPressed: _close,
                      tooltip: AppStrings.adClose,
                      icon: const Icon(Icons.close_rounded, color: Colors.white),
                    ),
                    const _Chip(),
                    const Spacer(),
                    Text(
                      _earned ? AppStrings.adRewardReady : '${AppStrings.adRewardIn} ${_left}s',
                      style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: GestureDetector(
                  onTap: _open,
                  child: Image(
                    image: widget.image,
                    fit: BoxFit.contain,
                    width: double.infinity,
                    errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
                child: Column(
                  children: [
                    Text(ad.title,
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
                    if (ad.body.isNotEmpty) ...[
                      const SizedBox(height: 6),
                      Text(ad.body,
                          textAlign: TextAlign.center,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: Colors.white70, fontSize: 14, height: 1.35)),
                    ],
                    const SizedBox(height: 14),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                        onPressed: _open,
                        style: FilledButton.styleFrom(backgroundColor: AppColors.primary, padding: const EdgeInsets.symmetric(vertical: 14)),
                        child: Text(ad.cta, maxLines: 1, overflow: TextOverflow.ellipsis),
                      ),
                    ),
                    if (_earned) ...[
                      const SizedBox(height: 8),
                      TextButton(
                        onPressed: _close,
                        child: Text(AppStrings.adClose, style: const TextStyle(color: Colors.white)),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  const _Chip();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(color: AppColors.warning, borderRadius: BorderRadius.circular(4)),
      child: const Text('Ad', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: Colors.white)),
    );
  }
}
