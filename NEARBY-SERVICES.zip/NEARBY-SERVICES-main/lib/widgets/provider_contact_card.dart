import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/models.dart';
import 'call_options_sheet.dart';
import 'social_links_row.dart';

/// Contact + socials block for a provider profile.
/// Locked (provider's profile lock or service lock): shows a lock notice only.
/// Unlocked: shows round icon buttons only (call, then WhatsApp and the other socials,
/// same style as the Service Details page) plus the email the provider added.
/// Phone and WhatsApp numbers are never printed. Nothing is invented when a field is empty.
class ProviderContactCard extends StatelessWidget {
  final ServiceItem provider;
  const ProviderContactCard({super.key, required this.provider});

  static bool _has(String? v) => v != null && v.trim().isNotEmpty;

  Widget _row(IconData icon, Color color, String text) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Row(
          children: [
            Icon(icon, size: 15, color: color),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                text,
                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
              ),
            ),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    final isEn = AppStrings.isEnglish;
    final locked = provider.isContactLocked;
    final hasAny = _has(provider.phone) || _has(provider.whatsappPhone) || _has(provider.email);

    return Container(
      margin: const EdgeInsets.fromLTRB(20, 14, 20, 0),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: locked ? AppColors.background : AppColors.primaryLight.withValues(alpha: 0.3),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: locked ? AppColors.border : AppColors.primary.withValues(alpha: 0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(locked ? Icons.lock_outline_rounded : Icons.lock_open_rounded,
                  size: 18, color: locked ? AppColors.textSecondary : AppColors.primary),
              const SizedBox(width: 8),
              Text(
                isEn ? 'Contact & Socials' : 'Mawasiliano na Mitandao',
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (locked)
            Text(
              isEn
                  ? 'This provider\'s contact details are private. They unlock once your service request is accepted.'
                  : 'Mawasiliano ya mtoa huduma ni siri. Yatafunguka ombi lako likikubaliwa.',
              style: const TextStyle(fontSize: 11, height: 1.4, color: AppColors.textSecondary),
            )
          else ...[
            if (_has(provider.email)) _row(Icons.email_outlined, AppColors.textSecondary, provider.email!.trim()),
            if (!hasAny)
              Text(
                isEn ? 'This provider has not added contact details yet.' : 'Mtoa huduma bado hajaweka mawasiliano.',
                style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
              ),
            // Call button + the provider's social buttons (WhatsApp included), icons only.
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (_has(provider.phone)) ...[
                  Tooltip(
                    message: isEn ? 'Call' : 'Piga simu',
                    child: GestureDetector(
                      onTap: () => CallOptionsSheet.show(context, provider),
                      child: Container(
                        width: 36,
                        height: 36,
                        decoration: const BoxDecoration(shape: BoxShape.circle, color: AppColors.primary),
                        child: const Center(child: Icon(Icons.phone_rounded, size: 18, color: Colors.white)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                ],
                Expanded(child: SocialLinksRow(service: provider, padding: EdgeInsets.zero)),
              ],
            ),
          ],
        ],
      ),
    );
  }
}
