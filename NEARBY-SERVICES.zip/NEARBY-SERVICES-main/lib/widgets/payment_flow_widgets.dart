import '../services/app_policy.dart';
import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart' show XFile;
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/api_service.dart';
import '../services/data_sync.dart';
import '../services/media_picker.dart';
import '../services/payment_flow.dart';
import '../services/payment_methods_service.dart';
import 'card_payment_dialog.dart';
import 'country_code_picker.dart';
import 'fullscreen_image_viewer.dart';
import '../services/app_log.dart';
import '../services/currency_service.dart';

bool get _en => AppStrings.isEnglish;

void _toast(BuildContext context, String msg, {bool error = false}) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    backgroundColor: error ? AppColors.danger : null,
    content: Text(msg),
  ));
}

String _failText() =>
    ApiService.lastPaymentError ?? (_en ? 'Something went wrong. Please try again.' : 'Kuna hitilafu. Tafadhali jaribu tena.');

/// Shared rounded sheet frame that lifts above the keyboard.
class _SheetFrame extends StatelessWidget {
  final String title;
  final String? subtitle;
  final List<Widget> children;
  const _SheetFrame({required this.title, this.subtitle, required this.children});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        decoration: const BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
        ),
        child: SafeArea(
          top: false,
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(18, 10, 18, 18),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 38,
                    height: 4,
                    decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)),
                  ),
                ),
                const SizedBox(height: 14),
                Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                if (subtitle != null) ...[
                  const SizedBox(height: 4),
                  Text(subtitle!, style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textSecondary)),
                ],
                const SizedBox(height: 14),
                ...children,
              ],
            ),
          ),
        ),
      ),
    );
  }
}

InputDecoration _fieldDecoration(String hint, {Widget? suffixIcon}) => InputDecoration(
      hintText: hint,
      suffixIcon: suffixIcon,
      hintStyle: const TextStyle(fontSize: 13, color: AppColors.textMuted),
      isDense: true,
      contentPadding: const EdgeInsets.all(12),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
    );

Widget _primaryButton({required String label, required VoidCallback? onPressed, required bool busy, Color color = AppColors.primary}) {
  return SizedBox(
    width: double.infinity,
    height: 46,
    child: ElevatedButton(
      onPressed: busy ? null : onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        foregroundColor: Colors.white,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
      child: busy
          ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
          : Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
    ),
  );
}

// ---------------------------------------------------------------------------
// Provider: "Ask buyer to pay first"
// ---------------------------------------------------------------------------
class AskPaymentSheet extends StatefulWidget {
  final String transactionRef;
  final String amountText;
  const AskPaymentSheet({super.key, required this.transactionRef, required this.amountText});

  /// Resolves to true when the request for payment was sent.
  static Future<bool> show(BuildContext context, {required String transactionRef, required String amountText}) async {
    final r = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => AskPaymentSheet(transactionRef: transactionRef, amountText: amountText),
    );
    return r == true;
  }

  @override
  State<AskPaymentSheet> createState() => _AskPaymentSheetState();
}

class _AskPaymentSheetState extends State<AskPaymentSheet> {
  String _mode = 'OFFLINE'; // OFFLINE = pay me directly, ONLINE = pay in the app
  int _minutes = 60;
  final _instructions = TextEditingController();
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _prefill();
  }

  /// Pre-fill with the wallet numbers this user already saved on the device.
  Future<void> _prefill() async {
    try {
      final numbers = await PaymentMethodsService.loadNumbers();
      final lines = <String>[];
      for (final m in PaymentMethodsService.methods) {
        final n = numbers[m.id];
        if (m.isMobileMoney && n != null && n.trim().isNotEmpty) lines.add('${m.nameEn}: $n');
      }
      if (mounted && _instructions.text.isEmpty && lines.isNotEmpty) {
        setState(() => _instructions.text = lines.join('\n'));
      }
    } catch (caught, trace) { AppLog.e('payment_flow_widgets._prefill', caught, trace); }
  }

  @override
  void dispose() {
    _instructions.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_mode == 'OFFLINE' && _instructions.text.trim().length < 5) {
      _toast(context, _en ? 'Add the number or account the buyer should pay to.' : 'Weka namba au akaunti ambayo mnunuzi atalipa.', error: true);
      return;
    }
    setState(() => _busy = true);
    final res = await ApiService.requestPayment(
      widget.transactionRef,
      mode: _mode,
      instructions: _mode == 'OFFLINE' ? _instructions.text : null,
      deadlineMinutes: _minutes,
    );
    if (!mounted) return;
    setState(() => _busy = false);
    if (res == null) {
      _toast(context, _failText(), error: true);
      return;
    }
    DataSync.bump();
    Navigator.pop(context, true);
  }

  Widget _modeTile(String id, String title, String sub, IconData icon) {
    final selected = _mode == id;
    return GestureDetector(
      onTap: () => setState(() => _mode = id),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: selected ? AppColors.primaryLight : AppColors.background,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: selected ? AppColors.primary : AppColors.border, width: selected ? 1.5 : 1),
        ),
        child: Row(
          children: [
            Icon(selected ? Icons.radio_button_checked : Icons.radio_button_off, size: 18, color: AppColors.primary),
            const SizedBox(width: 10),
            Icon(icon, size: 20, color: AppColors.textSecondary),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                  const SizedBox(height: 2),
                  Text(sub, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.3)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const options = <int, String>{30: '30 min', 60: '1 h', 180: '3 h', 1440: '24 h'};
    return _SheetFrame(
      title: _en ? 'Ask buyer to pay first' : 'Mwombe mnunuzi alipe kwanza',
      subtitle: _en
          ? 'The request stays unaccepted until payment is confirmed. Amount: ${widget.amountText}.'
          : 'Ombi halikubaliwi hadi malipo yathibitishwe. Kiasi: ${widget.amountText}.',
      children: [
        _modeTile(
          'OFFLINE',
          _en ? 'Pay me directly' : 'Nilipe moja kwa moja',
          _en ? 'Buyer sends money to your number/account, taps "I have paid", then you confirm.' : 'Mnunuzi anatuma pesa kwenye namba/akaunti yako, anabonyeza "Nimelipa", kisha unathibitisha.',
          Icons.swap_horiz_rounded,
        ),
        _modeTile(
          'ONLINE',
          _en ? 'Pay in the app' : 'Alipe ndani ya app',
          _en ? 'Buyer pays with Pocket Fund, mobile money or card. Held safely until the job is done.' : 'Mnunuzi analipa kwa Pocket Fund, pesa za simu au kadi. Inashikiliwa salama hadi kazi iishe.',
          Icons.shield_outlined,
        ),
        if (_mode == 'OFFLINE') ...[
          const SizedBox(height: 6),
          Text(_en ? 'Where should the buyer pay?' : 'Mnunuzi alipe wapi?',
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
          const SizedBox(height: 6),
          TextField(
            controller: _instructions,
            maxLines: 3,
            decoration: _fieldDecoration(_en ? 'e.g. M-Pesa 0712 345 678 (Asha M.)' : 'Mfano: M-Pesa 0712 345 678 (Asha M.)'),
          ),
        ],
        const SizedBox(height: 12),
        Text(_en ? 'Time to pay' : 'Muda wa kulipa',
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
        const SizedBox(height: 6),
        Wrap(
          spacing: 8,
          children: options.entries
              .map((e) => ChoiceChip(
                    label: Text(e.value),
                    selected: _minutes == e.key,
                    onSelected: (_) => setState(() => _minutes = e.key),
                  ))
              .toList(),
        ),
        const SizedBox(height: 16),
        _primaryButton(
          label: _en ? 'Send payment request' : 'Tuma ombi la malipo',
          onPressed: _submit,
          busy: _busy,
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Buyer: "I have paid"
// ---------------------------------------------------------------------------
class MarkPaidSheet extends StatefulWidget {
  final String transactionRef;
  final String amountText;
  const MarkPaidSheet({super.key, required this.transactionRef, required this.amountText});

  static Future<bool> show(BuildContext context, {required String transactionRef, required String amountText}) async {
    final r = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => MarkPaidSheet(transactionRef: transactionRef, amountText: amountText),
    );
    return r == true;
  }

  @override
  State<MarkPaidSheet> createState() => _MarkPaidSheetState();
}

class _MarkPaidSheetState extends State<MarkPaidSheet> {
  final _reference = TextEditingController();
  final _note = TextEditingController();
  bool _confirmed = false;
  bool _busy = false;
  XFile? _proof;
  int _proofBytes = 0;

  @override
  void dispose() {
    _reference.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_confirmed) {
      _toast(context, _en ? 'Tick the box to confirm you sent the money.' : 'Weka tiki kuthibitisha umetuma pesa.', error: true);
      return;
    }
    setState(() => _busy = true);
    // Optional proof: upload first, then send its link with the "I have paid" call.
    String? proofUrl;
    if (_proof != null) {
      final up = await ApiService.uploadPaymentProof(_proof!.path);
      if (!mounted) return;
      if (!up.ok || up.url == null) {
        setState(() => _busy = false);
        _toast(context, up.error ?? _failText(), error: true);
        return;
      }
      proofUrl = up.url;
    }
    final res = await ApiService.markPaymentSent(widget.transactionRef, reference: _reference.text, note: _note.text, proofUrl: proofUrl);
    if (!mounted) return;
    setState(() => _busy = false);
    if (res == null) {
      _toast(context, _failText(), error: true);
      return;
    }
    DataSync.bump();
    Navigator.pop(context, true);
  }

  Future<void> _pickProof() async {
    final f = await MediaPicker.pickImage(
      context,
      title: _en ? 'Attach payment proof' : 'Ambatisha uthibitisho wa malipo',
      subtitle: _en ? 'Add a screenshot of the payment SMS or receipt.' : 'Weka picha ya SMS ya malipo au risiti.',
    );
    if (f == null || !mounted) return;
    final n = await f.length();
    if (!mounted) return;
    if (n > 10 * 1024 * 1024) {
      _toast(context, _en ? 'The photo is too large (max 10 MB).' : 'Picha ni kubwa mno (juu MB 10).', error: true);
      return;
    }
    setState(() {
      _proof = f;
      _proofBytes = n;
    });
  }

  String _sizeText(int b) => b >= 1024 * 1024 ? '${(b / (1024 * 1024)).toStringAsFixed(1)} MB' : '${(b / 1024).round()} KB';

  Widget _proofChip() {
    final f = _proof!;
    final name = f.name.isNotEmpty ? f.name : f.path.split(Platform.pathSeparator).last;
    return Container(
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: AppColors.background,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.file(File(f.path), width: 44, height: 44, fit: BoxFit.cover),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                Text('${_sizeText(_proofBytes)} \u00b7 ${_en ? 'Attached' : 'Imeambatishwa'}',
                    style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
              ],
            ),
          ),
          Semantics(
            button: true,
            label: _en ? 'Remove attachment' : 'Ondoa kiambatisho',
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: _busy ? null : () => setState(() => _proof = null),
              child: SizedBox(
                width: 44,
                height: 44,
                child: Center(
                  child: Container(
                    width: 32,
                    height: 32,
                    decoration: const BoxDecoration(color: AppColors.dangerLight, shape: BoxShape.circle),
                    child: const Icon(Icons.close_rounded, size: 18, color: AppColors.dangerDark),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return _SheetFrame(
      title: _en ? 'I have paid' : 'Nimelipa',
      subtitle: _en
          ? 'The provider is alerted and will confirm once the money arrives. Only tap this after you have really paid.'
          : 'Mtoa huduma atapewa taarifa na atathibitisha pesa zikifika. Bonyeza hii baada ya kulipa kweli tu.',
      children: [
        Text(_en ? 'Payment reference (from the SMS)' : 'Namba ya muamala (kutoka SMS)',
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
        const SizedBox(height: 6),
        TextField(
          controller: _reference,
          decoration: _fieldDecoration(
            _en ? 'e.g. QJ47XK92LA' : 'Mfano: QJ47XK92LA',
            suffixIcon: IconButton(
              tooltip: _en ? 'Attach screenshot or receipt' : 'Ambatisha picha au risiti',
              icon: const Icon(Icons.attach_file_rounded, color: AppColors.primaryDark),
              onPressed: _busy ? null : _pickProof,
            ),
          ),
        ),
        if (_proof != null) _proofChip(),
        Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Text(
            _en ? 'Optional proof: a screenshot of the payment SMS or receipt (photo, up to 10 MB).' : 'Uthibitisho (si lazima): picha ya SMS ya malipo au risiti (hadi MB 10).',
            style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
          ),
        ),
        const SizedBox(height: 12),
        Text(_en ? 'Note (optional)' : 'Maelezo (si lazima)',
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
        const SizedBox(height: 6),
        TextField(
          controller: _note,
          maxLines: 2,
          decoration: _fieldDecoration(_en ? 'Name used to pay, time sent...' : 'Jina lililotumika kulipa, muda ulipotuma...'),
        ),
        const SizedBox(height: 10),
        InkWell(
          onTap: () => setState(() => _confirmed = !_confirmed),
          child: Row(
            children: [
              Checkbox(value: _confirmed, onChanged: (v) => setState(() => _confirmed = v == true), activeColor: AppColors.primary),
              Expanded(
                child: Text(
                  _en ? 'I sent ${widget.amountText} to the provider.' : 'Nimetuma ${widget.amountText} kwa mtoa huduma.',
                  style: const TextStyle(fontSize: 12, color: AppColors.textPrimary),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        _primaryButton(label: _en ? 'Notify provider' : 'Mjulishe mtoa huduma', onPressed: _submit, busy: _busy),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Provider: "Not received"
// ---------------------------------------------------------------------------
class NotReceivedSheet extends StatefulWidget {
  final String transactionRef;
  const NotReceivedSheet({super.key, required this.transactionRef});

  static Future<bool> show(BuildContext context, {required String transactionRef}) async {
    final r = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => NotReceivedSheet(transactionRef: transactionRef),
    );
    return r == true;
  }

  @override
  State<NotReceivedSheet> createState() => _NotReceivedSheetState();
}

class _NotReceivedSheetState extends State<NotReceivedSheet> {
  int _reason = 0;
  final _note = TextEditingController();
  bool _busy = false;

  List<String> get _reasons => _en
      ? ['Nothing received', 'Wrong amount', 'Other']
      : ['Sijapokea chochote', 'Kiasi si sahihi', 'Nyingine'];

  @override
  void dispose() {
    _note.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    setState(() => _busy = true);
    final text = [_reasons[_reason], if (_note.text.trim().isNotEmpty) _note.text.trim()].join(': ');
    final res = await ApiService.reportPaymentNotReceived(widget.transactionRef, reason: text);
    if (!mounted) return;
    setState(() => _busy = false);
    if (res == null) {
      _toast(context, _failText(), error: true);
      return;
    }
    DataSync.bump();
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return _SheetFrame(
      title: _en ? 'Payment not received' : 'Malipo hayajapokelewa',
      subtitle: _en
          ? 'The buyer will be told. If the money arrives later you can still confirm it.'
          : 'Mnunuzi ataarifiwa. Pesa zikifika baadaye bado unaweza kuthibitisha.',
      children: [
        Wrap(
          spacing: 8,
          children: List.generate(
            _reasons.length,
            (i) => ChoiceChip(label: Text(_reasons[i]), selected: _reason == i, onSelected: (_) => setState(() => _reason = i)),
          ),
        ),
        const SizedBox(height: 12),
        TextField(controller: _note, maxLines: 2, decoration: _fieldDecoration(_en ? 'Details (optional)' : 'Maelezo (si lazima)')),
        const SizedBox(height: 14),
        _primaryButton(
          label: _en ? 'Report not received' : 'Ripoti hayajapokelewa',
          onPressed: _submit,
          busy: _busy,
          color: AppColors.danger,
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Buyer: pay an existing booking online
// ---------------------------------------------------------------------------
class PayNowSheet extends StatefulWidget {
  final String transactionRef;
  final double amount;
  final String description;
  const PayNowSheet({super.key, required this.transactionRef, required this.amount, required this.description});

  static Future<bool> show(BuildContext context,
      {required String transactionRef, required double amount, required String description}) async {
    final r = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => PayNowSheet(transactionRef: transactionRef, amount: amount, description: description),
    );
    return r == true;
  }

  @override
  State<PayNowSheet> createState() => _PayNowSheetState();
}

class _PayNowSheetState extends State<PayNowSheet> {
  String _method = 'POCKET_FUND'; // POCKET_FUND | mobile_money | card
  final _phone = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _phone.dispose();
    super.dispose();
  }

  Future<void> _pay() async {
    final nav = Navigator.of(context);
    if (_method == 'mobile_money') {
      final normalized = PaymentMethodsService.normalizeTzNumber(_phone.text);
      if (normalized == null) {
        _toast(context, CurrencyService.badNumberMessage(_en), error: true);
        return;
      }
      setState(() => _busy = true);
      final res = await ApiService.requestMobilePayment(
        amount: widget.amount,
        purpose: 'BOOKING',
        reference: widget.transactionRef,
        phone: '+$normalized',
      );
      if (!mounted) return;
      setState(() => _busy = false);
      if (res == null) {
        _toast(
            context,
            ApiService.lastPaymentError ??
                (_en ? 'Could not send the payment request. Try again.' : 'Imeshindwa kutuma ombi la malipo. Jaribu tena.'),
            error: true);
        return;
      }
      _toast(context, _en ? 'Check your phone and approve the payment.' : 'Angalia simu yako na uidhinishe malipo.');
      DataSync.bump();
      nav.pop(true);
      return;
    }

    if (_method == 'card') {
      final paid = await CardPayment.pay(
        context,
        amount: widget.amount,
        purpose: 'BOOKING',
        reference: widget.transactionRef,
        description: widget.description,
      );
      if (!mounted) return;
      if (paid) DataSync.bump();
      nav.pop(paid);
      return;
    }

    setState(() => _busy = true);
    final res = await ApiService.payEscrow(widget.transactionRef, paymentMethod: 'POCKET_FUND');
    if (!mounted) return;
    setState(() => _busy = false);
    if (res == null) {
      _toast(context, _failText(), error: true);
      return;
    }
    DataSync.bump();
    nav.pop(true);
  }

  Widget _tile(String id, String title, String sub, IconData icon) {
    final selected = _method == id;
    return GestureDetector(
      onTap: () => setState(() => _method = id),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: selected ? AppColors.primaryLight : AppColors.background,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: selected ? AppColors.primary : AppColors.border, width: selected ? 1.5 : 1),
        ),
        child: Row(
          children: [
            Icon(selected ? Icons.radio_button_checked : Icons.radio_button_off, size: 18, color: AppColors.primary),
            const SizedBox(width: 10),
            Icon(icon, size: 20, color: AppColors.textSecondary),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                  Text(sub, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return _SheetFrame(
      title: _en ? 'Pay now' : 'Lipa sasa',
      subtitle: PaymentFlow.money(widget.amount),
      children: [
        _tile('POCKET_FUND', 'Pocket Fund', _en ? 'Wallet balance' : 'Salio la wallet', Icons.account_balance_wallet_outlined),
        _tile('mobile_money', _en ? 'Mobile Money' : 'Pesa za Simu', 'M-Pesa • Airtel Money • Tigo Pesa • Halopesa', Icons.phone_android_rounded),
        if (_method == 'mobile_money') ...[
          TextField(
            controller: _phone,
            keyboardType: TextInputType.phone,
            decoration: _fieldDecoration(_en ? 'Number to pay with e.g. 0712 345 678' : 'Namba ya kulipia mf. 0712 345 678').copyWith(
              prefixIcon: CountryCodePicker(value: CurrencyService.current.plusDial, enabled: false, onChanged: (_) {}),
              prefixIconConstraints: const BoxConstraints(minWidth: 0, minHeight: 0),
            ),
          ),
          const SizedBox(height: 8),
        ],
        if (AppPolicy.cardPaymentsEnabled)
        _tile('card', _en ? 'Card' : 'Kadi', 'Visa • Mastercard', Icons.credit_card_rounded),
        const SizedBox(height: 8),
        _primaryButton(label: '${_en ? 'Pay' : 'Lipa'} ${PaymentFlow.money(widget.amount)}', onPressed: _pay, busy: _busy),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Status panel + actions, used on the buyer card, the provider card and details
// ---------------------------------------------------------------------------
class PaymentFlowPanel extends StatefulWidget {
  final Map<String, dynamic> tx;
  final bool isBuyer;

  /// Called after a successful action (refresh your list / pop the screen).
  final VoidCallback? onChanged;

  const PaymentFlowPanel({super.key, required this.tx, required this.isBuyer, this.onChanged});

  @override
  State<PaymentFlowPanel> createState() => _PaymentFlowPanelState();
}

class _PaymentFlowPanelState extends State<PaymentFlowPanel> {
  Timer? _timer;

  Map<String, dynamic> get _tx => widget.tx;
  String get _ref => (_tx['transactionRef'] ?? '').toString();
  PayState get _state => PaymentFlow.stateOf(_tx['status']);
  double get _amount => (_tx['amount'] as num?)?.toDouble() ?? 0;
  String get _amountText => PaymentFlow.money(_amount);
  bool get _offline => PaymentFlow.payMode(_tx) == 'OFFLINE';
  DateTime? get _deadline => DateTime.tryParse((_tx['paymentDeadline'] ?? '').toString())?.toLocal();
  String _text(String key) => (_tx[key] ?? '').toString().trim();

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && _state == PayState.awaitingPayment && _deadline != null) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _done(String message) {
    _toast(context, message);
    widget.onChanged?.call();
  }

  Future<void> _iPaid() async {
    final ok = await MarkPaidSheet.show(context, transactionRef: _ref, amountText: _amountText);
    if (ok && mounted) _done(_en ? 'Provider notified. Waiting for confirmation.' : 'Mtoa huduma amejulishwa. Inasubiri uthibitisho.');
  }

  Future<void> _payNow() async {
    final ok = await PayNowSheet.show(
      context,
      transactionRef: _ref,
      amount: _amount,
      description: (_tx['serviceTitle'] ?? 'Booking').toString(),
    );
    if (ok && mounted) _done(_en ? 'Payment started.' : 'Malipo yameanza.');
  }

  Future<void> _confirmReceived() async {
    final sure = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(_en ? 'Confirm payment received?' : 'Thibitisha malipo yamepokelewa?'),
        content: Text(_en
            ? 'Only confirm after $_amountText is in your account. This accepts the booking and cannot be undone.'
            : 'Thibitisha tu baada ya $_amountText kuingia kwenye akaunti yako. Hii inakubali oda na haiwezi kutenguliwa.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(_en ? 'Not yet' : 'Bado')),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.success, foregroundColor: Colors.white),
            child: Text(_en ? 'Yes, received' : 'Ndiyo, nimepokea'),
          ),
        ],
      ),
    );
    if (sure != true || !mounted) return;
    final res = await ApiService.confirmPaymentReceived(_ref);
    if (!mounted) return;
    if (res == null) {
      _toast(context, _failText(), error: true);
      return;
    }
    DataSync.bump();
    _done(_en ? 'Payment confirmed. Booking accepted.' : 'Malipo yamethibitishwa. Oda imekubaliwa.');
  }

  /// Buyer: the job is done, release the held money to the provider.
  Future<void> _release() async {
    final sure = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(_en ? 'Confirm job completed?' : 'Thibitisha kazi imekamilika?'),
        content: Text(_offline
            ? (_en
                ? 'Only confirm if the job is done. You paid the provider directly, so no money moves here. You can rate the provider afterwards.'
                : 'Thibitisha tu kama kazi imekamilika. Ulilipa mtoa huduma moja kwa moja, kwa hiyo hakuna pesa inayohamishwa hapa. Baadaye unaweza kumpa ukadiriaji.')
            : (_en
                ? 'Only confirm if you are satisfied. $_amountText will be released to the provider and this cannot be undone.'
                : 'Thibitisha tu kama umeridhika. $_amountText itatolewa kwa mtoa huduma na hili haliwezi kutenguliwa.')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(_en ? 'Not yet' : 'Bado')),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.success, foregroundColor: Colors.white),
            child: Text(_offline ? (_en ? 'Yes, job completed' : 'Ndiyo, imekamilika') : (_en ? 'Yes, release payment' : 'Ndiyo, toa malipo')),
          ),
        ],
      ),
    );
    if (sure != true || !mounted) return;
    final res = await ApiService.releaseEscrowFunds(_ref);
    if (!mounted) return;
    if (res == null) {
      _toast(context, _failText(), error: true);
      return;
    }
    DataSync.bump();
    _done(_offline
        ? (_en ? 'Booking marked as completed. You can now rate the provider.' : 'Oda imewekwa kuwa imekamilika. Sasa unaweza kumpa mtoa huduma ukadiriaji.')
        : (_en ? 'Payment released to the provider.' : 'Malipo yametolewa kwa mtoa huduma.'));
  }

  Future<void> _notReceived() async {
    final ok = await NotReceivedSheet.show(context, transactionRef: _ref);
    if (ok && mounted) _done(_en ? 'Buyer has been told the payment was not received.' : 'Mnunuzi ameambiwa malipo hayajapokelewa.');
  }

  String _countdown() {
    final d = _deadline;
    if (d == null) return '';
    final left = d.difference(DateTime.now());
    if (left.isNegative) return _en ? 'Payment window expired' : 'Muda wa kulipa umeisha';
    final h = left.inHours;
    final m = left.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = left.inSeconds.remainder(60).toString().padLeft(2, '0');
    final t = h > 0 ? '$h:$m:$s' : '$m:$s';
    return _en ? 'Time left to pay: $t' : 'Muda uliobaki kulipa: $t';
  }

  Widget _copyRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 8, 4, 8),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label, style: const TextStyle(fontSize: 10, color: AppColors.textMuted, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 2),
                  SelectableText(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textPrimary, height: 1.35)),
                ],
              ),
            ),
            IconButton(
              visualDensity: VisualDensity.compact,
              icon: const Icon(Icons.copy_rounded, size: 18, color: AppColors.primary),
              onPressed: () {
                Clipboard.setData(ClipboardData(text: value));
                _toast(context, _en ? 'Copied' : 'Imenakiliwa');
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _action(String label, VoidCallback onTap, {Color color = AppColors.primary, bool outlined = false}) {
    final shape = RoundedRectangleBorder(borderRadius: BorderRadius.circular(8));
    return SizedBox(
      height: 38,
      child: outlined
          ? OutlinedButton(
              onPressed: onTap,
              style: OutlinedButton.styleFrom(foregroundColor: color, side: BorderSide(color: color), shape: shape),
              child: Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
            )
          : ElevatedButton(
              onPressed: onTap,
              style: ElevatedButton.styleFrom(backgroundColor: color, foregroundColor: Colors.white, elevation: 0, shape: shape),
              child: Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
            ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = _state;
    final unpaidOnline = state == PayState.none && PaymentFlow.awaitingPayAfterAccept(_tx);
    final canRelease = widget.isBuyer && state == PayState.none && PaymentFlow.canRelease(_tx);
    if (state == PayState.none && !unpaidOnline && !canRelease) return const SizedBox.shrink();

    final buyer = widget.isBuyer;
    late final String title;
    late final String body;
    late final Color tone;
    late final IconData icon;

    if (canRelease) {
      tone = AppColors.success;
      icon = Icons.verified_user_outlined;
      title = _en ? 'Happy with the job?' : 'Umeridhika na kazi?';
      body = _offline
          ? (_en
              ? 'Once the job is done, confirm it here. Then you can rate the provider.'
              : 'Kazi ikiisha, thibitisha hapa. Kisha unaweza kumpa mtoa huduma ukadiriaji.')
          : (_en
              ? 'Your $_amountText is held safely. Once the job is done, confirm to release it to the provider.'
              : '$_amountText yako imeshikiliwa salama. Kazi ikiisha, thibitisha ili itolewe kwa mtoa huduma.');
    } else if (unpaidOnline) {
      tone = AppColors.warning;
      icon = Icons.payments_outlined;
      title = buyer ? (_en ? 'Request accepted: pay now' : 'Ombi limekubaliwa: lipa sasa') : (_en ? 'Waiting for buyer to pay' : 'Inasubiri mnunuzi alipe');
      body = buyer
          ? (_en ? 'The provider accepted your request. Pay now to confirm your booking. Your money is held safely until the job is done.' : 'Mtoa huduma amekubali ombi lako. Lipa sasa ili kuthibitisha oda yako. Pesa yako inashikiliwa salama hadi kazi iishe.')
          : (_en ? 'You accepted this request. The buyer pays in the app and you will be alerted.' : 'Umekubali ombi hili. Mnunuzi atalipa ndani ya app na utaarifiwa.');
    } else if (state == PayState.awaitingPayment) {
      tone = AppColors.warning;
      icon = Icons.hourglass_top_rounded;
      if (buyer) {
        title = _en ? 'Payment required' : 'Malipo yanahitajika';
        body = _offline
            ? (_en ? 'Send $_amountText to the provider, then tap "I have paid".' : 'Tuma $_amountText kwa mtoa huduma, kisha bonyeza "Nimelipa".')
            : (_en ? 'The provider asks you to pay in the app to confirm this booking.' : 'Mtoa huduma anakuomba ulipe ndani ya app ili kuthibitisha oda hii.');
      } else {
        title = _en ? 'Waiting for buyer to pay' : 'Inasubiri mnunuzi alipe';
        body = _offline
            ? (_en ? 'The booking is accepted once you confirm the payment arrived.' : 'Oda inakubaliwa ukithibitisha malipo yamefika.')
            : (_en ? 'The booking is accepted automatically when the buyer pays in the app.' : 'Oda inakubaliwa moja kwa moja mnunuzi akilipa ndani ya app.');
      }
    } else if (state == PayState.paymentSent) {
      tone = AppColors.primary;
      icon = Icons.mark_email_read_outlined;
      if (buyer) {
        title = _en ? 'Waiting for provider to confirm' : 'Inasubiri mtoa huduma athibitishe';
        body = _en ? 'You told the provider you paid. They will confirm once the money arrives.' : 'Umemwambia mtoa huduma umelipa. Atathibitisha pesa zikifika.';
      } else {
        title = _en ? 'Buyer says they have paid' : 'Mnunuzi anasema amelipa';
        body = _en ? 'Check your account. Confirm only after $_amountText has arrived.' : 'Angalia akaunti yako. Thibitisha tu baada ya $_amountText kufika.';
      }
    } else {
      tone = AppColors.danger;
      icon = Icons.error_outline_rounded;
      if (buyer) {
        title = _en ? 'Provider did not receive your payment' : 'Mtoa huduma hajapokea malipo yako';
        body = _en ? 'Check your payment reference and chat with the provider, or contact support.' : 'Angalia namba ya muamala na zungumza na mtoa huduma, au wasiliana na msaada.';
      } else {
        title = _en ? 'Marked as not received' : 'Imewekwa hayajapokelewa';
        body = _en ? 'If the money arrives later you can still confirm it.' : 'Pesa zikifika baadaye bado unaweza kuthibitisha.';
      }
    }

    final instructions = _text('paymentInstructions');
    final paidRef = _text('paymentReference');
    final paidNote = _text('paymentNote');
    final paidProof = _text('paymentProofUrl');
    final countdown = state == PayState.awaitingPayment ? _countdown() : '';

    final actions = <Widget>[];
    if (canRelease) {
      actions.add(Expanded(child: _action(_en ? 'Confirm completed' : 'Thibitisha imekamilika', _release, color: AppColors.success)));
    }
    if (buyer && (state == PayState.awaitingPayment || unpaidOnline)) {
      final online = unpaidOnline || !_offline;
      actions.add(Expanded(
        child: online
            ? _action(_en ? 'Pay now' : 'Lipa sasa', _payNow)
            : _action(_en ? 'I have paid' : 'Nimelipa', _iPaid, color: AppColors.success),
      ));
    }
    if (!buyer && (state == PayState.paymentSent || state == PayState.disputed)) {
      actions.add(Expanded(child: _action(_en ? 'Confirm received' : 'Thibitisha nimepokea', _confirmReceived, color: AppColors.success)));
      if (state == PayState.paymentSent) {
        actions.add(const SizedBox(width: 10));
        actions.add(Expanded(child: _action(_en ? 'Not received' : 'Sijapokea', _notReceived, color: AppColors.danger, outlined: true)));
      }
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: tone.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: tone.withValues(alpha: 0.35)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, size: 18, color: tone),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: tone)),
                    const SizedBox(height: 2),
                    Text(body, style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textPrimary)),
                  ],
                ),
              ),
            ],
          ),
          if (countdown.isNotEmpty) ...[
            const SizedBox(height: 6),
            Text(countdown, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: tone)),
          ],
          // Buyer: where to pay + the reference to quote (like a P2P order)
          if (buyer && state == PayState.awaitingPayment && _offline) ...[
            if (instructions.isNotEmpty) _copyRow(_en ? 'Pay to' : 'Lipa kwa', instructions),
            if (_ref.isNotEmpty) _copyRow(_en ? 'Booking reference (put it in the payment note)' : 'Kumbukumbu ya oda (iweke kwenye maelezo ya malipo)', _ref),
          ],
          // Provider: what the buyer reported
          if (!buyer && (state == PayState.paymentSent || state == PayState.disputed)) ...[
            _copyRow(_en ? 'Amount to receive' : 'Kiasi cha kupokea', _amountText),
            if (paidRef.isNotEmpty) _copyRow(_en ? "Buyer's payment reference" : 'Namba ya muamala ya mnunuzi', paidRef),
            if (paidNote.isNotEmpty) _copyRow(_en ? "Buyer's note" : 'Maelezo ya mnunuzi', paidNote),
          ],
          // Proof screenshot: the buyer sees what they sent, the provider sees what to check.
          if (paidProof.isNotEmpty && (state == PayState.paymentSent || state == PayState.disputed)) ...[
            const SizedBox(height: 8),
            InkWell(
              borderRadius: BorderRadius.circular(8),
              onTap: () => FullscreenImageViewer.open(context, images: [ApiService.absoluteUrl(paidProof)]),
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppColors.border),
                ),
                child: Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: Image.network(
                        ApiService.absoluteUrl(paidProof),
                        width: 44,
                        height: 44,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          width: 44,
                          height: 44,
                          color: AppColors.borderLight,
                          child: const Icon(Icons.image_not_supported_outlined, size: 20, color: AppColors.textMuted),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        buyer ? (_en ? 'Payment proof you attached' : 'Uthibitisho uliouambatisha') : (_en ? "Buyer's payment proof (tap to view)" : 'Uthibitisho wa mnunuzi (bonyeza kuona)'),
                        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                      ),
                    ),
                    const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted),
                  ],
                ),
              ),
            ),
          ],
          if (actions.isNotEmpty) ...[
            const SizedBox(height: 10),
            Row(children: actions),
          ],
        ],
      ),
    );
  }
}


// ---------------------------------------------------------------------------
// Progress of a request: Request sent > Accepted > Paid > Completed
// ---------------------------------------------------------------------------
class RequestProgress extends StatelessWidget {
  final Map tx;
  const RequestProgress({super.key, required this.tx});

  @override
  Widget build(BuildContext context) {
    final p = PaymentFlow.progress(tx);
    if (p.ended != null) {
      final rejected = p.ended == 'rejected';
      final label = rejected ? (_en ? 'Request declined' : 'Ombi limekataliwa') : (_en ? 'Request cancelled' : 'Ombi limeghairiwa');
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(color: AppColors.dangerLight, borderRadius: BorderRadius.circular(10)),
        child: Row(children: [
          const Icon(Icons.cancel_rounded, size: 16, color: AppColors.dangerDark),
          const SizedBox(width: 8),
          Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.dangerDark)),
        ]),
      );
    }
    final labels = [
      _en ? 'Request sent' : 'Ombi limetumwa',
      _en ? 'Accepted' : 'Limekubaliwa',
      _en ? 'Paid' : 'Umelipa',
      _en ? 'Completed' : 'Imekamilika',
    ];
    final done = p.done;
    final cells = <Widget>[];
    for (var i = 0; i < labels.length; i++) {
      final isDone = i < done;
      final isCurrent = i == done;
      final color = isDone ? AppColors.successDark : (isCurrent ? AppColors.primary : AppColors.textMuted);
      cells.add(Expanded(
        child: Column(children: [
          Row(children: [
            Expanded(child: Container(height: 2, color: i == 0 ? Colors.transparent : (i <= done ? AppColors.successDark : AppColors.border))),
            Container(
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isDone ? AppColors.successDark : Colors.white,
                border: Border.all(color: color, width: 2),
              ),
              child: isDone ? const Icon(Icons.check_rounded, size: 13, color: Colors.white) : null,
            ),
            Expanded(child: Container(height: 2, color: i == labels.length - 1 ? Colors.transparent : (i < done ? AppColors.successDark : AppColors.border))),
          ]),
          const SizedBox(height: 6),
          Text(labels[i],
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 10, fontWeight: isCurrent ? FontWeight.w800 : FontWeight.w600, color: isCurrent ? AppColors.primary : (isDone ? AppColors.textPrimary : AppColors.textSecondary))),
        ]),
      ));
    }
    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: cells);
  }
}


// ---------------------------------------------------------------------------
// How the buyer chose to pay (shown on the request card to both people)
// ---------------------------------------------------------------------------
class PaymentPreferenceBadge extends StatelessWidget {
  final Map tx;
  final bool isBuyer;
  const PaymentPreferenceBadge({super.key, required this.tx, this.isBuyer = false});

  @override
  Widget build(BuildContext context) {
    final pref = PaymentFlow.payPreference(tx);
    if (pref.isEmpty) return const SizedBox.shrink();
    final held = pref == 'HELD';
    final tone = held ? AppColors.successDark : AppColors.primaryDark;
    final title = held
        ? (_en ? 'Payment held until the buyer is satisfied' : 'Malipo yanashikiliwa hadi mnunuzi aridhike')
        : (_en ? 'Buyer pays you directly' : 'Mnunuzi anakulipa moja kwa moja');
    final body = held
        ? (isBuyer
            ? (_en ? 'You pay online. The provider is paid only after you confirm the job is done.' : 'Unalipa mtandaoni. Mtoa huduma analipwa baada tu ya wewe kuthibitisha kazi imekamilika.')
            : (_en ? 'The money is kept safe. It is released to you when the buyer confirms the job is done.' : 'Pesa zinashikiliwa salama. Zinatolewa kwako mnunuzi akithibitisha kazi imekamilika.'))
        : (isBuyer
            ? (_en ? 'You pay online. The money goes to the provider as soon as you pay, with no hold.' : 'Unalipa mtandaoni. Pesa zinaenda kwa mtoa huduma mara tu unapolipa, bila kushikiliwa.')
            : (_en ? 'The money is released to you as soon as the buyer pays. It is not held.' : 'Pesa zinakufikia mara tu mnunuzi anapolipa. Hazishikiliwi.'));
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: held ? AppColors.successLight : AppColors.primaryLight,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: tone.withValues(alpha: 0.3)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(held ? Icons.verified_user_rounded : Icons.bolt_rounded, size: 18, color: tone),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: tone)),
                const SizedBox(height: 2),
                Text(body, style: const TextStyle(fontSize: 11, height: 1.4, color: AppColors.textPrimary)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
