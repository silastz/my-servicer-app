import 'package:easy_audience_network/easy_audience_network.dart' as fan;
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:unity_levelplay_mediation/unity_levelplay_mediation.dart' as lp;
import 'package:url_launcher/url_launcher.dart';

import '../constants/app_colors.dart';
import '../models/ads_config.dart';
import '../models/house_ads.dart';
import '../services/ad_service.dart';
import '../services/app_log.dart';

// Banner and native ads for every page. The admin picks the network of each page (AdMob, Facebook
// or ironSource, see AdService / ADS.md); these widgets ask AdService for that page's list of
// networks and show the first one that has an ad. When a network has no ad they move on to the
// next one. An ad takes no space until it has loaded, and nothing shows if every network fails
// or ads are off, so screens never get a blank gap.

/// Walks the networks of one ad spot in order. Waits (listening to [AdService.revision]) until the
/// admin's first choice has started; then keeps its list for the life of the widget.
class _Waterfall {
  _Waterfall({required this.page, required this.format, required this.onChange});

  final AdPage page;
  final AdFormat format;
  final VoidCallback onChange;

  List<AdProvider> _chain = const [];
  int _i = 0;
  bool _started = false;

  /// Position in the list; part of the key of the ad widget so a new network gets a fresh widget.
  int get index => _i;

  /// The network to show now, or null while waiting / when every network failed.
  AdProvider? get current => _started && _i < _chain.length ? _chain[_i] : null;

  void start() {
    _tryStart();
    if (!_started) AdService.revision.addListener(_onRevision);
  }

  void _onRevision() {
    if (_tryStart()) {
      AdService.revision.removeListener(_onRevision);
      onChange();
    }
  }

  bool _tryStart() {
    if (_started) return false;
    final chain = AdService.chainFor(page, format);
    // The admin's first choice may still be starting: wait for it.
    if (chain.isEmpty || !AdService.isReady(chain.first)) return false;
    _chain = chain;
    _i = 0;
    _started = true;
    return true;
  }

  /// The network at [at] has no ad: move to the next one that is running.
  void failedAt(int at) {
    if (!_started || at != _i) return; // a late or repeated report from an old widget
    do {
      _i++;
    } while (_i < _chain.length && !AdService.isReady(_chain[_i]));
    onChange();
  }

  void dispose() => AdService.revision.removeListener(_onRevision);
}

// =============================================================================
// Banner
// =============================================================================

/// A banner ad (about 320x100). Takes no space until an ad has loaded.
class AdBannerView extends StatefulWidget {
  const AdBannerView({super.key, required this.page, this.topGap = 0, this.bottomGap = 0});

  /// The app page this ad belongs to (the admin's per-page switch).
  final AdPage page;

  /// Space above / below the banner, added only while an ad is showing.
  final double topGap;
  final double bottomGap;

  @override
  State<AdBannerView> createState() => _AdBannerViewState();
}

class _AdBannerViewState extends State<AdBannerView> {
  late final _Waterfall _water;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _water = _Waterfall(page: widget.page, format: AdFormat.banner, onChange: _onChange)..start();
  }

  @override
  void dispose() {
    _water.dispose();
    super.dispose();
  }

  void _onChange() {
    if (mounted) setState(() => _loaded = false);
  }

  void _onLoaded() {
    if (mounted && !_loaded) setState(() => _loaded = true);
  }

  @override
  Widget build(BuildContext context) {
    final network = _water.current;
    if (network == null) return const SizedBox.shrink();
    final at = _water.index;
    final key = ValueKey('${network.id}-$at');
    void failed() => _water.failedAt(at);
    final Widget slot;
    switch (network) {
      case AdProvider.admob:
        slot = _AdmobBannerSlot(key: key, onLoaded: _onLoaded, onFailed: failed);
      case AdProvider.facebook:
        slot = _FanBannerSlot(key: key, onLoaded: _onLoaded, onFailed: failed);
      case AdProvider.ironsource:
        slot = _LevelPlayBannerSlot(key: key, onLoaded: _onLoaded, onFailed: failed);
      case AdProvider.all:
        slot = const SizedBox.shrink(); // never in a chain (it is expanded into real networks)
      case AdProvider.inhouse:
        slot = _HouseBannerSlot(key: key, page: widget.page, onLoaded: _onLoaded, onFailed: failed);
    }
    return Padding(
      padding: EdgeInsets.only(top: _loaded ? widget.topGap : 0, bottom: _loaded ? widget.bottomGap : 0),
      child: slot,
    );
  }
}

class _AdmobBannerSlot extends StatefulWidget {
  const _AdmobBannerSlot({super.key, required this.onLoaded, required this.onFailed});

  final VoidCallback onLoaded;
  final VoidCallback onFailed;

  @override
  State<_AdmobBannerSlot> createState() => _AdmobBannerSlotState();
}

class _AdmobBannerSlotState extends State<_AdmobBannerSlot> {
  BannerAd? _ad;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    final ad = BannerAd(
      adUnitId: AdService.unitId(AdProvider.admob, AdFormat.banner),
      size: AdSize.largeBanner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) {
          if (!mounted) return;
          setState(() => _loaded = true);
          widget.onLoaded();
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          if (_ad == ad) _ad = null;
          if (mounted && !_loaded) widget.onFailed(); // a failed refresh of a showing ad keeps it
        },
      ),
    );
    _ad = ad;
    ad.load();
  }

  @override
  void dispose() {
    _ad?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ad = _ad;
    if (!_loaded || ad == null) return const SizedBox.shrink();
    return Center(
      child: SizedBox(
        width: ad.size.width.toDouble(),
        height: ad.size.height.toDouble(),
        child: AdWidget(ad: ad),
      ),
    );
  }
}

class _FanBannerSlot extends StatefulWidget {
  const _FanBannerSlot({super.key, required this.onLoaded, required this.onFailed});

  final VoidCallback onLoaded;
  final VoidCallback onFailed;

  @override
  State<_FanBannerSlot> createState() => _FanBannerSlotState();
}

class _FanBannerSlotState extends State<_FanBannerSlot> {
  bool _loaded = false;

  @override
  Widget build(BuildContext context) {
    // The plugin's banner is half a pixel high until Facebook has an ad, then 90.
    return Center(
      child: SizedBox(
        width: 320,
        child: fan.BannerAd(
          placementId: AdService.unitId(AdProvider.facebook, AdFormat.banner),
          bannerSize: fan.BannerSize.LARGE,
          listener: fan.BannerAdListener(
            onLoaded: () {
              if (!mounted) return;
              _loaded = true;
              widget.onLoaded();
            },
            onError: (code, message) {
              AppLog.d('Facebook banner error $code: $message');
              if (mounted && !_loaded) widget.onFailed(); // a failed refresh of a showing ad keeps it
            },
          ),
        ),
      ),
    );
  }
}

class _LevelPlayBannerSlot extends StatefulWidget {
  const _LevelPlayBannerSlot({super.key, required this.onLoaded, required this.onFailed});

  final VoidCallback onLoaded;
  final VoidCallback onFailed;

  @override
  State<_LevelPlayBannerSlot> createState() => _LevelPlayBannerSlotState();
}

class _LevelPlayBannerSlotState extends State<_LevelPlayBannerSlot> implements lp.LevelPlayBannerAdViewListener {
  final GlobalKey<lp.LevelPlayBannerAdViewState> _key = GlobalKey<lp.LevelPlayBannerAdViewState>();
  final lp.LevelPlayAdSize _size = lp.LevelPlayAdSize.LARGE; // 320 x 90
  bool _loaded = false;

  @override
  void dispose() {
    _key.currentState?.destroy();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // The native banner has to be on screen to load, so it sits in a 1 px box until it has an ad.
    return Center(
      child: SizedBox(
        width: _size.width.toDouble(),
        height: _loaded ? _size.height.toDouble() : 1,
        child: lp.LevelPlayBannerAdView(
          key: _key,
          adUnitId: AdService.unitId(AdProvider.ironsource, AdFormat.banner),
          adSize: _size,
          listener: this,
          onPlatformViewCreated: () => _key.currentState?.loadAd(),
        ),
      ),
    );
  }

  @override
  void onAdLoaded(lp.LevelPlayAdInfo adInfo) {
    if (!mounted) return;
    setState(() => _loaded = true);
    widget.onLoaded();
  }

  @override
  void onAdLoadFailed(lp.LevelPlayAdError error) {
    AppLog.d('LevelPlay banner failed to load: $error');
    if (mounted && !_loaded) widget.onFailed(); // a failed refresh of a showing ad keeps it
  }

  @override
  void onAdDisplayed(lp.LevelPlayAdInfo adInfo) {}

  @override
  void onAdDisplayFailed(lp.LevelPlayAdInfo adInfo, lp.LevelPlayAdError error) {
    AppLog.d('LevelPlay banner failed to display: $error');
  }

  @override
  void onAdClicked(lp.LevelPlayAdInfo adInfo) {}

  @override
  void onAdExpanded(lp.LevelPlayAdInfo adInfo) {}

  @override
  void onAdCollapsed(lp.LevelPlayAdInfo adInfo) {}

  @override
  void onAdLeftApplication(lp.LevelPlayAdInfo adInfo) {}
}

// =============================================================================
// Native
// =============================================================================

/// A native ad that sits in a list like one more row. With [card] true it has
/// the same rounded, bordered frame as a service card (Home feed, search
/// results); with [card] false it is a plain full-width row (chats list).
/// Google's "Ad" label is part of the ad itself. Hidden until loaded.
class NativeAdRow extends StatefulWidget {
  const NativeAdRow({
    super.key,
    required this.page,
    this.card = true,
    this.padding = EdgeInsets.zero,
    this.cell = false,
  });

  /// The app page this ad belongs to (the admin's per-page switch).
  final AdPage page;
  final bool card;
  final EdgeInsetsGeometry padding;

  /// true = one grid cell the size of a service card (Home feed, Android only:
  /// check [cellSupported] first). false = the wide row used everywhere else.
  final bool cell;

  static bool get cellSupported => AdService.cellAdsSupported;

  @override
  State<NativeAdRow> createState() => _NativeAdRowState();
}

class _NativeAdRowState extends State<NativeAdRow> {
  late final _Waterfall _water;

  @override
  void initState() {
    super.initState();
    _water = _Waterfall(page: widget.page, format: AdFormat.native, onChange: _onChange)..start();
  }

  @override
  void dispose() {
    _water.dispose();
    super.dispose();
  }

  void _onChange() {
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final network = _water.current;
    if (network == null) return const SizedBox.shrink();
    final at = _water.index;
    final key = ValueKey('${network.id}-$at');
    void failed() => _water.failedAt(at);
    switch (network) {
      case AdProvider.admob:
        return _AdmobNativeSlot(key: key, widgetConfig: widget, onFailed: failed);
      case AdProvider.facebook:
        return _FanNativeSlot(key: key, widgetConfig: widget, onFailed: failed);
      case AdProvider.ironsource:
        return _LevelPlayNativeSlot(key: key, widgetConfig: widget, onFailed: failed);
      case AdProvider.all:
        return const SizedBox.shrink(); // never in a chain (it is expanded into real networks)
      case AdProvider.inhouse:
        return _HouseNativeSlot(key: key, widgetConfig: widget, onFailed: failed);
    }
  }
}

/// The frame around a native ad: a service-card look (cell / card) or a plain row. The widget
/// tree has the same shape before and after the ad loads, so the native view is never rebuilt
/// when the frame appears.
class _AdFrame extends StatelessWidget {
  const _AdFrame({required this.framed, required this.config, required this.child});

  /// false until the ad has loaded: no padding, no border.
  final bool framed;
  final NativeAdRow config;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final styled = framed && (config.cell || config.card);
    final BoxDecoration decoration;
    if (!styled) {
      decoration = const BoxDecoration();
    } else if (config.cell) {
      // Same frame as a service card: square corners.
      decoration = BoxDecoration(
        color: AppColors.surface,
        border: Border.all(color: AppColors.border),
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 8, offset: const Offset(0, 2)),
        ],
      );
    } else {
      decoration = BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      );
    }
    return Padding(
      padding: framed ? config.padding : EdgeInsets.zero,
      child: DecoratedBox(
        decoration: decoration,
        child: ClipRRect(
          borderRadius: styled && !config.cell ? BorderRadius.circular(13) : BorderRadius.zero,
          child: child,
        ),
      ),
    );
  }
}

/// Height of a card-sized (cell) native ad: a square media area plus about 120 px of text, button and footer.
double _cellHeight(double width) => width + 120;

class _AdmobNativeSlot extends StatefulWidget {
  const _AdmobNativeSlot({super.key, required this.widgetConfig, required this.onFailed});

  final NativeAdRow widgetConfig;
  final VoidCallback onFailed;

  @override
  State<_AdmobNativeSlot> createState() => _AdmobNativeSlotState();
}

class _AdmobNativeSlotState extends State<_AdmobNativeSlot> {
  NativeAd? _ad;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    final cell = widget.widgetConfig.cell;
    final ad = NativeAd(
      adUnitId: AdService.unitId(AdProvider.admob, AdFormat.native),
      request: const AdRequest(),
      // Cell mode uses the custom card layout registered in MainActivity.kt.
      factoryId: cell ? AdService.cardFactoryId : null,
      listener: NativeAdListener(
        onAdLoaded: (_) {
          if (mounted) setState(() => _loaded = true);
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          if (_ad == ad) _ad = null;
          if (mounted && !_loaded) widget.onFailed();
        },
      ),
      nativeTemplateStyle: cell
          ? null
          : NativeTemplateStyle(
              templateType: TemplateType.small,
              mainBackgroundColor: AppColors.surface,
              cornerRadius: 10,
              callToActionTextStyle: NativeTemplateTextStyle(
                textColor: Colors.white,
                backgroundColor: AppColors.primary,
                style: NativeTemplateFontStyle.bold,
                size: 12,
              ),
              primaryTextStyle: NativeTemplateTextStyle(
                textColor: AppColors.textPrimary,
                style: NativeTemplateFontStyle.bold,
                size: 13,
              ),
              secondaryTextStyle: NativeTemplateTextStyle(
                textColor: AppColors.textSecondary,
                size: 11,
              ),
              tertiaryTextStyle: NativeTemplateTextStyle(
                textColor: AppColors.textSecondary,
                size: 11,
              ),
            ),
    );
    _ad = ad;
    ad.load();
  }

  @override
  void dispose() {
    _ad?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ad = _ad;
    if (!_loaded || ad == null) return const SizedBox.shrink();
    final config = widget.widgetConfig;
    final Widget content = config.cell
        ? LayoutBuilder(
            builder: (context, c) => SizedBox(height: _cellHeight(c.maxWidth), child: AdWidget(ad: ad)),
          )
        // Small template: about the height of one service row (90 to 120).
        : ConstrainedBox(
            constraints: const BoxConstraints(minWidth: 320, minHeight: 91, maxHeight: 120),
            child: AdWidget(ad: ad),
          );
    return _AdFrame(framed: true, config: config, child: content);
  }
}

class _FanNativeSlot extends StatefulWidget {
  const _FanNativeSlot({super.key, required this.widgetConfig, required this.onFailed});

  final NativeAdRow widgetConfig;
  final VoidCallback onFailed;

  @override
  State<_FanNativeSlot> createState() => _FanNativeSlotState();
}

class _FanNativeSlotState extends State<_FanNativeSlot> {
  bool _loaded = false;

  @override
  Widget build(BuildContext context) {
    final config = widget.widgetConfig;
    return LayoutBuilder(
      builder: (context, c) {
        final width = c.maxWidth.isFinite ? c.maxWidth : MediaQuery.sizeOf(context).width;
        // Row: Facebook's native banner (icon, title, button), 100 px. Cell: the full native ad.
        final height = config.cell ? _cellHeight(width) : 100.0;
        return _AdFrame(
          framed: _loaded,
          config: config,
          // The plugin keeps the ad 1 px high until Facebook has one (keepExpandedWhileLoading false).
          child: fan.NativeAd(
            placementId: AdService.unitId(AdProvider.facebook, AdFormat.native),
            adType: config.cell ? fan.NativeAdType.NATIVE_AD : fan.NativeAdType.NATIVE_BANNER_AD,
            bannerAdSize: fan.NativeBannerAdSize.HEIGHT_100,
            width: width,
            height: height,
            keepExpandedWhileLoading: false,
            backgroundColor: AppColors.surface,
            titleColor: AppColors.textPrimary,
            descriptionColor: AppColors.textSecondary,
            labelColor: AppColors.textSecondary,
            buttonColor: AppColors.primary,
            buttonTitleColor: Colors.white,
            listener: fan.NativeAdListener(
              onLoaded: () {
                if (mounted && !_loaded) setState(() => _loaded = true);
              },
              onError: (code, message) {
                AppLog.d('Facebook native error $code: $message');
                if (mounted && !_loaded) widget.onFailed();
              },
            ),
          ),
        );
      },
    );
  }
}

class _LevelPlayNativeSlot extends StatefulWidget {
  const _LevelPlayNativeSlot({super.key, required this.widgetConfig, required this.onFailed});

  final NativeAdRow widgetConfig;
  final VoidCallback onFailed;

  @override
  State<_LevelPlayNativeSlot> createState() => _LevelPlayNativeSlotState();
}

class _LevelPlayNativeSlotState extends State<_LevelPlayNativeSlot> implements lp.LevelPlayNativeAdListener {
  late final lp.LevelPlayNativeAd _ad;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    // The admin's "native" entry for ironSource is an optional placement name.
    final placement = AdService.unitId(AdProvider.ironsource, AdFormat.native);
    final builder = lp.LevelPlayNativeAd.builder().withListener(this);
    if (placement.isNotEmpty) builder.withPlacementName(placement);
    _ad = builder.build();
  }

  @override
  void dispose() {
    _ad.destroyAd();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final config = widget.widgetConfig;
    return LayoutBuilder(
      builder: (context, c) {
        final width = c.maxWidth.isFinite ? c.maxWidth : MediaQuery.sizeOf(context).width;
        final height = config.cell ? _cellHeight(width) : 120.0;
        return _AdFrame(
          framed: _loaded,
          config: config,
          // The native view has to be on screen to load, so it sits in a 1 px box until it has an ad.
          child: lp.LevelPlayNativeAdView(
            nativeAd: _ad,
            templateType: config.cell ? lp.LevelPlayTemplateType.MEDIUM : lp.LevelPlayTemplateType.SMALL,
            width: width,
            height: _loaded ? height : 1,
            onPlatformViewCreated: () => _ad.loadAd(),
          ),
        );
      },
    );
  }

  @override
  void onAdLoaded(lp.LevelPlayNativeAd nativeAd, lp.AdInfo adInfo) {
    if (mounted && !_loaded) setState(() => _loaded = true);
  }

  @override
  void onAdLoadFailed(lp.LevelPlayNativeAd nativeAd, lp.IronSourceError error) {
    AppLog.d('LevelPlay native failed to load: $error');
    if (mounted && !_loaded) widget.onFailed();
  }

  @override
  void onAdImpression(lp.LevelPlayNativeAd nativeAd, lp.AdInfo adInfo) {}

  @override
  void onAdClicked(lp.LevelPlayNativeAd nativeAd, lp.AdInfo adInfo) {}
}


// =============================================================================
// In-house ads (the admin's own JSON ads, see lib/models/house_ads.dart)
// =============================================================================

/// Opens an in-house ad's link in the browser. The link is an https URL (checked again here).
Future<void> _openHouseAd(HouseAd ad) async {
  if (!HouseAds.validUrl(ad.url)) return;
  try {
    await launchUrl(Uri.parse(ad.url), mode: LaunchMode.externalApplication);
  } catch (e) {
    AppLog.d('House ad link failed: $e');
  }
}

/// The small "Ad" label every ad carries, so people can tell it from content.
class _AdChip extends StatelessWidget {
  const _AdChip();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
      decoration: BoxDecoration(color: AppColors.warning, borderRadius: BorderRadius.circular(4)),
      child: const Text('Ad', style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w800, color: Colors.white)),
    );
  }
}

/// Loads an in-house ad's image and reports when it shows or fails. It must be in the widget tree
/// (not laid out) for the picture to load, which is why the slots hide it with [Offstage].
class _HouseImage extends StatelessWidget {
  const _HouseImage({required this.url, required this.onLoaded, required this.onFailed});

  final String url;
  final VoidCallback onLoaded;
  final VoidCallback onFailed;

  @override
  Widget build(BuildContext context) {
    return Image.network(
      url,
      fit: BoxFit.cover,
      frameBuilder: (context, child, frame, sync) {
        if (frame != null || sync) WidgetsBinding.instance.addPostFrameCallback((_) => onLoaded());
        return child;
      },
      errorBuilder: (context, error, stack) {
        AppLog.d('House ad image failed: $error');
        WidgetsBinding.instance.addPostFrameCallback((_) => onFailed());
        return const SizedBox.shrink();
      },
    );
  }
}

class _HouseCta extends StatelessWidget {
  const _HouseCta(this.label);

  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(8)),
      child: Text(label,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.white)),
    );
  }
}

/// The text part shared by the banner and the native row: title, body and the button.
Widget _houseText(HouseAd ad, {int bodyLines = 2}) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Text(ad.title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
      if (ad.body.isNotEmpty) ...[
        const SizedBox(height: 2),
        Text(ad.body,
            maxLines: bodyLines,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 11.5, height: 1.3, color: AppColors.textSecondary)),
      ],
      const SizedBox(height: 6),
      _HouseCta(ad.cta),
    ],
  );
}

/// A banner made from one in-house ad: picture on the left, text and button on the right.
class _HouseBannerSlot extends StatefulWidget {
  const _HouseBannerSlot({super.key, required this.page, required this.onLoaded, required this.onFailed});

  final AdPage page;
  final VoidCallback onLoaded;
  final VoidCallback onFailed;

  @override
  State<_HouseBannerSlot> createState() => _HouseBannerSlotState();
}

class _HouseBannerSlotState extends State<_HouseBannerSlot> {
  HouseAd? _ad;
  bool _loaded = false;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _ad = AdService.pickHouse(widget.page, AdFormat.banner);
    if (_ad == null) WidgetsBinding.instance.addPostFrameCallback((_) => _fail());
  }

  void _fail() {
    if (!mounted || _failed || _loaded) return;
    _failed = true;
    widget.onFailed();
  }

  void _ok() {
    if (!mounted || _loaded || _failed) return;
    setState(() => _loaded = true);
    widget.onLoaded();
  }

  @override
  Widget build(BuildContext context) {
    final ad = _ad;
    if (ad == null) return const SizedBox.shrink();
    return Offstage(
      offstage: !_loaded,
      child: Center(
        child: SizedBox(
          width: 320,
          height: 90,
          child: Material(
            color: AppColors.surface,
            clipBehavior: Clip.antiAlias,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10), side: const BorderSide(color: AppColors.border)),
            child: InkWell(
              onTap: () => _openHouseAd(ad),
              child: Stack(
                children: [
                  Row(
                    children: [
                      SizedBox(width: 90, height: 90, child: _HouseImage(url: ad.imageUrl, onLoaded: _ok, onFailed: _fail)),
                      Expanded(child: Padding(padding: const EdgeInsets.fromLTRB(10, 6, 30, 6), child: _houseText(ad, bodyLines: 1))),
                    ],
                  ),
                  const Positioned(top: 4, right: 4, child: _AdChip()),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// A native-style ad made from one in-house ad. In a grid cell it looks like a service card
/// (square picture, text and button under it); in a list it is a 110 px row.
class _HouseNativeSlot extends StatefulWidget {
  const _HouseNativeSlot({super.key, required this.widgetConfig, required this.onFailed});

  final NativeAdRow widgetConfig;
  final VoidCallback onFailed;

  @override
  State<_HouseNativeSlot> createState() => _HouseNativeSlotState();
}

class _HouseNativeSlotState extends State<_HouseNativeSlot> {
  HouseAd? _ad;
  bool _loaded = false;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _ad = AdService.pickHouse(widget.widgetConfig.page, AdFormat.native);
    if (_ad == null) WidgetsBinding.instance.addPostFrameCallback((_) => _fail());
  }

  void _fail() {
    if (!mounted || _failed || _loaded) return;
    _failed = true;
    widget.onFailed();
  }

  void _ok() {
    if (!mounted || _loaded || _failed) return;
    setState(() => _loaded = true);
  }

  @override
  Widget build(BuildContext context) {
    final ad = _ad;
    if (ad == null) return const SizedBox.shrink();
    final cell = widget.widgetConfig.cell;
    // LayoutBuilder is outside the Offstage: an off-stage child is never laid out, and its picture
    // would then never start loading.
    return LayoutBuilder(
      builder: (context, c) {
        final width = c.maxWidth.isFinite ? c.maxWidth : MediaQuery.of(context).size.width;
        final image = _HouseImage(url: ad.imageUrl, onLoaded: _ok, onFailed: _fail);
        final Widget body = cell
            ? SizedBox(
                height: _cellHeight(width),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    SizedBox(height: width, child: Stack(fit: StackFit.expand, children: [image, const Positioned(top: 6, left: 6, child: _AdChip())])),
                    Expanded(child: Padding(padding: const EdgeInsets.all(10), child: _houseText(ad))),
                  ],
                ),
              )
            : SizedBox(
                height: 110,
                child: Stack(
                  children: [
                    Row(
                      children: [
                        SizedBox(width: 110, height: 110, child: image),
                        Expanded(child: Padding(padding: const EdgeInsets.fromLTRB(12, 8, 34, 8), child: _houseText(ad))),
                      ],
                    ),
                    const Positioned(top: 6, right: 6, child: _AdChip()),
                  ],
                ),
              );
        return _AdFrame(
          framed: _loaded,
          config: widget.widgetConfig,
          child: Offstage(
            offstage: !_loaded,
            child: InkWell(onTap: () => _openHouseAd(ad), child: body),
          ),
        );
      },
    );
  }
}
