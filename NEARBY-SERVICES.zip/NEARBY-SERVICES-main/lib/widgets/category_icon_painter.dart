import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

class CategoryBadgePainter extends CustomPainter {
  final String category;

  CategoryBadgePainter({required this.category});

  @override
  void paint(Canvas canvas, Size size) {
    final strokePaint = Paint()
      ..color = AppColors.slateDark
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.2
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final yellowFill = Paint()
      ..color = AppColors.categoryElectrical
      ..style = PaintingStyle.fill;

    final whiteFill = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;

    final cx = size.width / 2;
    final cy = size.height / 2;

    switch (category) {
      case 'Massage':
        // Yellow head circle and upper shoulders with black outline
        canvas.drawCircle(Offset(cx, cy - 6), 6.5, yellowFill);
        canvas.drawCircle(Offset(cx, cy - 6), 6.5, strokePaint);
        // Body / shoulders
        final bodyPath = Path()
          ..moveTo(cx - 11, cy + 11)
          ..quadraticBezierTo(cx - 10, cy + 1, cx, cy + 1)
          ..quadraticBezierTo(cx + 10, cy + 1, cx + 11, cy + 11)
          ..close();
        canvas.drawPath(bodyPath, yellowFill);
        canvas.drawPath(bodyPath, strokePaint);
        break;

      case 'Beauty':
        // Pink lady face silhouette / flower mirror
        final mirror = Path()
          ..addOval(Rect.fromCircle(center: Offset(cx, cy - 3), radius: 8.5));
        canvas.drawPath(mirror, whiteFill);
        canvas.drawPath(mirror, strokePaint);
        // Handle
        canvas.drawLine(Offset(cx, cy + 5.5), Offset(cx, cy + 12), strokePaint);
        break;

      case 'Barber':
        // Crossed white hair cutting scissors with rings
        final sc1 = Path()
          ..moveTo(cx - 8, cy - 8)
          ..lineTo(cx + 8, cy + 8);
        final sc2 = Path()
          ..moveTo(cx + 8, cy - 8)
          ..lineTo(cx - 8, cy + 8);
        canvas.drawPath(sc1, strokePaint..color = Colors.white);
        canvas.drawPath(sc2, strokePaint..color = Colors.white);
        canvas.drawCircle(Offset(cx - 9, cy + 9), 3.5, strokePaint..color = Colors.white);
        canvas.drawCircle(Offset(cx + 9, cy + 9), 3.5, strokePaint..color = Colors.white);
        break;

      case 'Cleaning':
        // Yellow spray bottle with nozzle and black outline
        final bottle = Path()
          ..moveTo(cx - 5, cy - 4)
          ..lineTo(cx + 4, cy - 4)
          ..lineTo(cx + 7, cy + 11)
          ..lineTo(cx - 7, cy + 11)
          ..close();
        canvas.drawPath(bottle, yellowFill);
        canvas.drawPath(bottle, strokePaint..color = AppColors.slateDark);
        // Trigger handle
        final trig = Path()
          ..moveTo(cx, cy - 4)
          ..lineTo(cx, cy - 9)
          ..lineTo(cx + 6, cy - 9)
          ..moveTo(cx + 2, cy - 9)
          ..lineTo(cx + 7, cy - 3);
        canvas.drawPath(trig, strokePaint);
        break;

      case 'Plumbing':
        // White water tap dripping with black outline
        final tap = Path()
          ..moveTo(cx - 8, cy - 5)
          ..lineTo(cx + 4, cy - 5)
          ..lineTo(cx + 4, cy + 3)
          ..lineTo(cx + 1, cy + 3)
          ..lineTo(cx + 1, cy - 2)
          ..lineTo(cx - 8, cy - 2)
          ..close();
        canvas.drawPath(tap, whiteFill);
        canvas.drawPath(tap, strokePaint..color = AppColors.slateDark);
        // Drop
        canvas.drawCircle(Offset(cx + 2.5, cy + 8), 2.2, whiteFill);
        canvas.drawCircle(Offset(cx + 2.5, cy + 8), 2.2, strokePaint);
        break;

      case 'Electrical':
        // Yellow electric lightning bolt
        final bolt = Path()
          ..moveTo(cx + 2, cy - 11)
          ..lineTo(cx - 6, cy)
          ..lineTo(cx - 1, cy)
          ..lineTo(cx - 3, cy + 11)
          ..lineTo(cx + 6, cy - 1)
          ..lineTo(cx + 1, cy - 1)
          ..close();
        canvas.drawPath(bolt, yellowFill);
        canvas.drawPath(bolt, strokePaint..color = AppColors.slateDark);
        break;

      case 'Mechanic':
        // Crossed wrench and pliers with black outline
        final w1 = Path()
          ..moveTo(cx - 8, cy - 8)
          ..lineTo(cx + 8, cy + 8);
        final w2 = Path()
          ..moveTo(cx + 8, cy - 8)
          ..lineTo(cx - 8, cy + 8);
        canvas.drawPath(w1, strokePaint..color = AppColors.slateDark..strokeWidth = 3);
        canvas.drawPath(w2, strokePaint..color = AppColors.slateDark..strokeWidth = 3);
        break;

      case 'Photography':
        // Camera icon in white with black outlines
        final cam = Path()
          ..addRRect(RRect.fromRectAndRadius(
            Rect.fromCenter(center: Offset(cx, cy + 1), width: 22, height: 16),
            const Radius.circular(4),
          ));
        canvas.drawPath(cam, whiteFill);
        canvas.drawPath(cam, strokePaint..color = AppColors.slateDark..strokeWidth = 2);
        // Lens circle
        canvas.drawCircle(Offset(cx, cy + 1), 4.5, strokePaint);
        // Top flash notch
        canvas.drawRect(Rect.fromLTWH(cx - 4, cy - 9, 8, 3), strokePaint);
        break;

      default:
        // A category the admin added (or Repair / General / Food): a plain tag icon.
        final tag = Path()
          ..moveTo(cx - 10, cy - 3)
          ..lineTo(cx - 10, cy - 9)
          ..lineTo(cx - 4, cy - 9)
          ..lineTo(cx + 10, cy + 5)
          ..lineTo(cx + 4, cy + 11)
          ..close();
        canvas.drawPath(tag, whiteFill);
        canvas.drawPath(tag, strokePaint..color = AppColors.slateDark..strokeWidth = 2);
        canvas.drawCircle(Offset(cx - 5.5, cy - 4.5), 1.6, strokePaint);
        break;
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
