import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/models.dart';
import '../screens/booking_request_screen.dart';
import '../services/api_service.dart';
import '../services/data_sync.dart';
import '../services/offer_flow.dart';

bool get _en => AppStrings.isEnglish;

void _toast(BuildContext context, String msg, {bool error = false}) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    backgroundColor: error ? AppColors.danger : AppColors.success,
    content: Text(msg),
  ));
}

String _failText() =>
    ApiService.lastOfferError ?? (_en ? 'Something went wrong. Please try again.' : 'Kuna hitilafu. Tafadhali jaribu tena.');

/// Opens the booking screen at the price the seller agreed to.
/// Loads the service first (the offer only carries its id).
Future<void> bookAtAgreedPrice(BuildContext context, Map offer) async {
  final serviceId = '${offer['serviceId'] ?? (offer['service'] is Map ? offer['service']['id'] : '')}';
  if (serviceId.isEmpty) {
    _toast(context, _en ? 'This service is no longer available.' : 'Huduma hii haipatikani tena.', error: true);
    return;
  }
  final service = await ApiService.fetchServiceById(serviceId);
  if (!context.mounted) return;
  if (service == null) {
    _toast(context, _en ? 'Could not open the service. Try again.' : 'Imeshindikana kufungua huduma. Jaribu tena.', error: true);
    return;
  }
  final amount = OfferFlow.amountOf(offer).toInt();
  await Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) => BookingRequestScreen(
        provider: service,
        serviceTitle: service.title,
        priceText: OfferFlow.money(amount),
        durationText: service.durationText,
        agreedAmount: amount,
        offerId: '${offer['id']}',
      ),
    ),
  );
}

/// One offer in the Offers tab of Requests. The seller answers, the buyer waits, withdraws or books.
class OfferCard extends StatefulWidget {
  final Map<String, dynamic> offer;
  final bool isSeller;
  final VoidCallback? onChanged;

  const OfferCard({super.key, required this.offer, required this.isSeller, this.onChanged});

  @override
  State<OfferCard> createState() => _OfferCardState();
}

class _OfferCardState extends State<OfferCard> {
  bool _busy = false;
  String _action = ''; // which button is running, so only that one shows the spinner

  Map get _o => widget.offer;
  String get _id => '${_o['id'] ?? ''}';

  Future<void> _run(Future<Map<String, dynamic>?> Function() call, String okMsg) async {
    if (_busy) return;
    setState(() => _busy = true);
    final res = await call();
    if (!mounted) return;
    setState(() => _busy = false);
    if (res != null) {
      _toast(context, okMsg);
      DataSync.bump();
      widget.onChanged?.call();
    } else {
      _toast(context, _failText(), error: true);
    }
  }

  Future<void> _accept() async {
    final amount = OfferFlow.money(OfferFlow.amountOf(_o));
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(_en ? 'Accept this price?' : 'Kubali bei hii?'),
        content: Text(_en
            ? 'The buyer will be able to book this service for $amount. You will still confirm the booking.'
            : 'Mteja ataweza kuweka oda ya huduma hii kwa $amount. Bado utathibitisha oda.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(_en ? 'Cancel' : 'Ghairi')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(_en ? 'Accept' : 'Kubali')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    await _run(() => ApiService.acceptOffer(_id), _en ? 'Price accepted. The buyer can now book.' : 'Bei imekubaliwa. Mteja anaweza kuweka oda.');
  }

  Future<void> _reject() async {
    final reason = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(_en ? 'Decline this offer?' : 'Kataa ofa hii?'),
        content: TextField(
          controller: reason,
          maxLength: 200,
          maxLines: 2,
          decoration: InputDecoration(hintText: _en ? 'Reason (optional)' : 'Sababu (si lazima)'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(_en ? 'Back' : 'Rudi')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(_en ? 'Decline' : 'Kataa', style: const TextStyle(color: AppColors.danger)),
          ),
        ],
      ),
    );
    final text = reason.text;
    reason.dispose();
    if (ok != true || !mounted) return;
    await _run(() => ApiService.rejectOffer(_id, reason: text), _en ? 'Offer declined.' : 'Ofa imekataliwa.');
  }

  Future<void> _withdraw() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(_en ? 'Withdraw your offer?' : 'Rudisha ofa yako?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(_en ? 'Keep it' : 'Iache')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(_en ? 'Withdraw' : 'Rudisha')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    await _run(() => ApiService.withdrawOffer(_id), _en ? 'Offer withdrawn.' : 'Ofa imerudishwa.');
  }

  @override
  Widget build(BuildContext context) {
    final status = OfferFlow.shownStatus(_o);
    final state = OfferFlow.stateOf(status);
    final color = OfferFlow.color(status);
    final listed = OfferFlow.listedOf(_o);
    final amount = OfferFlow.amountOf(_o);
    final off = OfferFlow.percentOff(_o);
    final title = '${_o['serviceTitle'] ?? (_o['service'] is Map ? _o['service']['title'] : null) ?? (_en ? 'Service' : 'Huduma')}';
    final other = widget.isSeller
        ? '${(_o['buyer'] is Map ? (_o['buyer']['name'] ?? _o['buyer']['fullName']) : null) ?? _o['buyerName'] ?? (_en ? 'Buyer' : 'Mteja')}'
        : '${(_o['seller'] is Map ? _o['seller']['stageName'] : null) ?? _o['sellerName'] ?? (_en ? 'Seller' : 'Muuzaji')}';
    final message = '${_o['message'] ?? ''}'.trim();
    final left = OfferFlow.timeLeft(_o);

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
                    const SizedBox(height: 2),
                    Text(other, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(20)),
                child: Text(OfferFlow.label(status),
                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: color)),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                OfferFlow.money(amount),
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppColors.primary),
              ),
              const SizedBox(width: 8),
              if (listed > amount)
                Padding(
                  padding: const EdgeInsets.only(bottom: 2),
                  child: Text(
                    OfferFlow.money(listed),
                    style: const TextStyle(
                        fontSize: 12, color: AppColors.textMuted, decoration: TextDecoration.lineThrough),
                  ),
                ),
              if (off > 0) ...[
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(color: AppColors.successLight, borderRadius: BorderRadius.circular(6)),
                  child: Text('-$off%',
                      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.successDark)),
                ),
              ],
            ],
          ),
          if (message.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text('"$message"', style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textSecondary)),
          ],
          if (left.isNotEmpty && (state == OfferState.offered || state == OfferState.agreed)) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.schedule_rounded, size: 14, color: AppColors.textMuted),
                const SizedBox(width: 4),
                Text(left, style: const TextStyle(fontSize: 11, color: AppColors.textMuted)),
              ],
            ),
          ],
          ..._actions(state, amount),
        ],
      ),
    );
  }

  List<Widget> _actions(OfferState state, num amount) {
    final isSeller = widget.isSeller;
    if (state == OfferState.offered && isSeller) {
      return [
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: OutlinedButton(
                onPressed: _busy ? null : () { _action = 'reject'; _reject(); },
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.danger,
                  side: const BorderSide(color: AppColors.danger),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: (_busy && _action == 'reject') ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.danger)) : Text(_en ? 'Decline' : 'Kataa'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: ElevatedButton(
                onPressed: _busy ? null : () { _action = 'accept'; _accept(); },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: (_busy && _action == 'accept')
                    ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Text(_en ? 'Accept' : 'Kubali'),
              ),
            ),
          ],
        ),
      ];
    }
    if (state == OfferState.offered && !isSeller) {
      return [
        const SizedBox(height: 10),
        Align(
          alignment: Alignment.centerRight,
          child: TextButton(
            onPressed: _busy ? null : () { _action = 'withdraw'; _withdraw(); },
            child: (_busy && _action == 'withdraw') ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.primary)) : Text(_en ? 'Withdraw offer' : 'Rudisha ofa'),
          ),
        ),
      ];
    }
    if (state == OfferState.agreed && !isSeller) {
      return [
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: _busy ? null : () async {
              setState(() { _busy = true; _action = 'book'; });
              try {
                await bookAtAgreedPrice(context, _o);
              } finally {
                if (mounted) setState(() => _busy = false);
              }
            },
            icon: (_busy && _action == 'book') ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.calendar_month_rounded, size: 18),
            label: Text(_en ? 'Book at ${OfferFlow.money(amount)}' : 'Weka oda kwa ${OfferFlow.money(amount)}',
                style: const TextStyle(fontWeight: FontWeight.w800)),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
              elevation: 0,
              padding: const EdgeInsets.symmetric(vertical: 12),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
          ),
        ),
      ];
    }
    if (state == OfferState.agreed && isSeller) {
      return [
        const SizedBox(height: 8),
        Text(
          _en ? 'Waiting for the buyer to book at this price.' : 'Tunasubiri mteja aweke oda kwa bei hii.',
          style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
        ),
      ];
    }
    return const [];
  }
}

/// What the buyer sees right after sending an offer that the seller's auto-accept price accepted at once.
Future<void> showInstantlyAgreedDialog(BuildContext context, Map offer, ServiceItem service) {
  final amount = OfferFlow.money(OfferFlow.amountOf(offer));
  return showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(_en ? 'Offer accepted!' : 'Ofa imekubaliwa!'),
      content: Text(_en
          ? 'The seller agreed to $amount. Book now to lock this price.'
          : 'Muuzaji amekubali $amount. Weka oda sasa ili kufunga bei hii.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: Text(_en ? 'Later' : 'Baadaye')),
        TextButton(
          onPressed: () {
            Navigator.pop(ctx);
            bookAtAgreedPrice(context, {...offer, 'serviceId': offer['serviceId'] ?? service.id});
          },
          child: Text(_en ? 'Book now' : 'Weka oda sasa'),
        ),
      ],
    ),
  );
}
