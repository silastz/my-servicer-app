import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';

import '../constants/app_strings.dart';
import '../services/ad_service.dart';
import '../services/keep_awake.dart';
import '../models/ads_config.dart';

/// Full-screen video player.
/// On Android the `video_player` plugin is backed by ExoPlayer (Media3).
class VideoPlayerScreen extends StatefulWidget {
  final String url;
  final String title;

  const VideoPlayerScreen({super.key, required this.url, required this.title});

  /// Opens the player. Unless [skipAd] is true, the user is first asked to
  /// watch a rewarded video ad (Google requires this opt-in prompt).
  /// If no ad is available (offline, no fill, ads off) the video plays anyway,
  /// so a missing ad never blocks the content.
  static Future<void> open(
    BuildContext context, {
    required String url,
    required String title,
    bool skipAd = false,
  }) async {
    final navigator = Navigator.of(context);

    if (!skipAd && AdService.enabledFor(AdPage.videoReward)) {
      AdService.loadRewarded(); // make sure one is on its way
      if (AdService.rewardedReady) {
        final wants = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: Text(AppStrings.watchAdTitle),
            content: Text(AppStrings.watchAdMessage),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(ctx).pop(false),
                child: Text(AppStrings.cancel),
              ),
              FilledButton(
                onPressed: () => Navigator.of(ctx).pop(true),
                child: Text(AppStrings.watchAdButton),
              ),
            ],
          ),
        );
        if (wants != true) return;

        final result = await AdService.showRewarded();
        if (result == RewardedResult.skipped) {
          if (context.mounted) {
            ScaffoldMessenger.maybeOf(context)?.showSnackBar(
              SnackBar(content: Text(AppStrings.watchAdIncomplete)),
            );
          }
          return;
        }
        // rewarded or unavailable -> play the video
      }
    }

    if (!navigator.mounted) return;
    await navigator.push(
      MaterialPageRoute(builder: (_) => VideoPlayerScreen(url: url, title: title)),
    );
  }

  @override
  State<VideoPlayerScreen> createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends State<VideoPlayerScreen> {
  late final VideoPlayerController _controller;
  bool _showControls = true;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
      ..addListener(() {
        KeepAwake.follow(_controller.value.isPlaying);
        if (mounted) setState(() {});
      });
    _controller.initialize().then((_) {
      if (!mounted) return;
      _controller.play();
      setState(() {});
    }).catchError((_) {
      if (mounted) setState(() => _failed = true);
    });
  }

  @override
  void dispose() {
    KeepAwake.release();
    _controller.dispose();
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    super.dispose();
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return d.inHours > 0 ? '${d.inHours}:$m:$s' : '$m:$s';
  }

  void _togglePlay() {
    _controller.value.isPlaying ? _controller.pause() : _controller.play();
  }

  void _seekBy(int seconds) {
    final pos = _controller.value.position + Duration(seconds: seconds);
    final max = _controller.value.duration;
    _controller.seekTo(pos < Duration.zero ? Duration.zero : (pos > max ? max : pos));
  }

  @override
  Widget build(BuildContext context) {
    final v = _controller.value;

    // The status bar stays visible (network, battery, clock); its icons are made
    // white, because the default dark icons vanish on this black background.
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light, // Android: white clock / network / battery on the black screen
        statusBarBrightness: Brightness.dark, // iOS: same
        systemNavigationBarColor: Colors.black,
        systemNavigationBarIconBrightness: Brightness.light,
      ),
      child: Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => setState(() => _showControls = !_showControls),
        child: Stack(
          children: [
            Center(
              child: _failed
                  ? const Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.error_outline_rounded, color: Colors.white54, size: 48),
                        SizedBox(height: 8),
                        Text('Could not load video', style: TextStyle(color: Colors.white70)),
                      ],
                    )
                  : v.isInitialized
                      ? AspectRatio(aspectRatio: v.aspectRatio, child: VideoPlayer(_controller))
                      : const CircularProgressIndicator(color: Colors.white),
            ),
            if (v.isInitialized && v.isBuffering)
              const Center(child: CircularProgressIndicator(color: Colors.white)),

            if (_showControls) ...[
              // Top bar
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: SafeArea(
                  bottom: false,
                  child: Container(
                    height: 56,
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.black.withValues(alpha: 0.7), Colors.transparent],
                      ),
                    ),
                    child: Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                          onPressed: () => Navigator.of(context).pop(),
                        ),
                        Expanded(
                          child: Text(
                            widget.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              // Centre transport controls
              if (v.isInitialized)
                Center(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        iconSize: 36,
                        icon: const Icon(Icons.replay_10_rounded, color: Colors.white),
                        onPressed: () => _seekBy(-10),
                      ),
                      const SizedBox(width: 12),
                      Container(
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.55),
                          shape: BoxShape.circle,
                        ),
                        child: IconButton(
                          iconSize: 48,
                          icon: Icon(
                            v.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                            color: Colors.white,
                          ),
                          onPressed: _togglePlay,
                        ),
                      ),
                      const SizedBox(width: 12),
                      IconButton(
                        iconSize: 36,
                        icon: const Icon(Icons.forward_10_rounded, color: Colors.white),
                        onPressed: () => _seekBy(10),
                      ),
                    ],
                  ),
                ),

              // Bottom progress bar
              if (v.isInitialized)
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: SafeArea(
                    top: false,
                    child: Container(
                      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                          colors: [Colors.black.withValues(alpha: 0.7), Colors.transparent],
                        ),
                      ),
                      child: Row(
                        children: [
                          Text(_fmt(v.position), style: const TextStyle(color: Colors.white, fontSize: 12)),
                          const SizedBox(width: 8),
                          Expanded(
                            child: VideoProgressIndicator(
                              _controller,
                              allowScrubbing: true,
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              colors: const VideoProgressColors(
                                playedColor: Colors.white,
                                bufferedColor: Colors.white38,
                                backgroundColor: Colors.white24,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(_fmt(v.duration), style: const TextStyle(color: Colors.white, fontSize: 12)),
                          IconButton(
                            icon: const Icon(Icons.screen_rotation_rounded, color: Colors.white, size: 20),
                            onPressed: () {
                              final landscape = MediaQuery.of(context).orientation == Orientation.landscape;
                              SystemChrome.setPreferredOrientations(landscape
                                  ? [DeviceOrientation.portraitUp]
                                  : [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ],
        ),
      ),
      ),
    );
  }
}
