import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_image.dart';

/// Full-screen image gallery: black background, "n/total" counter, swipe
/// between images, pinch-to-zoom and a thumbnail strip at the bottom.
class FullscreenImageViewer extends StatefulWidget {
  final List<String> images;
  final int initialIndex;

  /// Optional share action (no share plugin is bundled, so the caller decides).
  final VoidCallback? onShare;

  /// Bookmark state shared with the caller (e.g. the service's favourite flag).
  final bool initialSaved;
  final ValueChanged<bool>? onSavedChanged;

  /// Called with the image index whenever the viewer moves to another image.
  final ValueChanged<int>? onIndexChanged;

  const FullscreenImageViewer({
    super.key,
    required this.images,
    this.initialIndex = 0,
    this.onShare,
    this.initialSaved = false,
    this.onSavedChanged,
    this.onIndexChanged,
  });

  /// Opens the viewer as a full-screen route.
  static Future<void> open(
    BuildContext context, {
    required List<String> images,
    int initialIndex = 0,
    VoidCallback? onShare,
    bool initialSaved = false,
    ValueChanged<bool>? onSavedChanged,
    ValueChanged<int>? onIndexChanged,
  }) {
    return Navigator.of(context).push(
      PageRouteBuilder(
        opaque: true,
        transitionDuration: const Duration(milliseconds: 200),
        pageBuilder: (_, __, ___) => FullscreenImageViewer(
          images: images,
          initialIndex: initialIndex,
          onShare: onShare,
          initialSaved: initialSaved,
          onSavedChanged: onSavedChanged,
          onIndexChanged: onIndexChanged,
        ),
        transitionsBuilder: (_, anim, __, child) =>
            FadeTransition(opacity: anim, child: child),
      ),
    );
  }

  @override
  State<FullscreenImageViewer> createState() => _FullscreenImageViewerState();
}

class _FullscreenImageViewerState extends State<FullscreenImageViewer> {
  late final PageController _pageController;
  late final ScrollController _thumbController;
  late int _index;
  late bool _saved = widget.initialSaved;
  bool _zoomed = false;

  static const double _thumbW = 84;
  static const double _thumbH = 58;
  static const double _thumbGap = 8;

  @override
  void initState() {
    super.initState();
    _index = widget.initialIndex.clamp(0, widget.images.length - 1);
    _pageController = PageController(initialPage: _index);
    _thumbController = ScrollController();
    WidgetsBinding.instance.addPostFrameCallback((_) => _scrollThumbToIndex(animate: false));
  }

  @override
  void dispose() {
    _pageController.dispose();
    _thumbController.dispose();
    super.dispose();
  }

  void _scrollThumbToIndex({bool animate = true}) {
    if (!_thumbController.hasClients) return;
    final viewport = _thumbController.position.viewportDimension;
    final target = (_index * (_thumbW + _thumbGap)) - (viewport - _thumbW) / 2;
    final offset = target.clamp(0.0, _thumbController.position.maxScrollExtent);
    if (animate) {
      _thumbController.animateTo(offset,
          duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
    } else {
      _thumbController.jumpTo(offset);
    }
  }

  Widget _img(String path, {BoxFit fit = BoxFit.contain}) {
    return AppImage(
      path,
      fit: fit,
      errorBuilder: (c, e, s) => const Center(
        child: Icon(Icons.broken_image_outlined, color: Colors.white38, size: 56),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final total = widget.images.length;

    // The status bar stays visible (network, battery, clock); its icons are made
    // white, because the default dark icons vanish on this black background.
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light, // Android: white clock / network / battery on the black screen
        statusBarBrightness: Brightness.dark, // iOS: same
        systemNavigationBarColor: Colors.black,
        systemNavigationBarIconBrightness: Brightness.light,
      ),
      child: Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Swipeable, zoomable images
          Positioned.fill(
            child: PageView.builder(
              controller: _pageController,
              physics: _zoomed
                  ? const NeverScrollableScrollPhysics()
                  : const PageScrollPhysics(),
              itemCount: total,
              onPageChanged: (i) {
                setState(() => _index = i);
                widget.onIndexChanged?.call(i);
                _scrollThumbToIndex();
              },
              itemBuilder: (ctx, i) => _ZoomablePage(
                onZoomChanged: (z) {
                  if (z != _zoomed) setState(() => _zoomed = z);
                },
                child: _img(widget.images[i]),
              ),
            ),
          ),

          // Top bar
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: SafeArea(
              bottom: false,
              child: Container(
                height: 56,
                padding: const EdgeInsets.symmetric(horizontal: 8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.black.withValues(alpha: 0.7), Colors.transparent],
                  ),
                ),
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                    Text(
                      '${_index + 1}/$total',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const Spacer(),
                    IconButton(
                      icon: Icon(
                        _saved ? Icons.bookmark_rounded : Icons.bookmark_border_rounded,
                        color: Colors.white,
                      ),
                      onPressed: () {
                        setState(() => _saved = !_saved);
                        widget.onSavedChanged?.call(_saved);
                      },
                    ),
                    if (widget.onShare != null)
                      IconButton(
                        icon: const Icon(Icons.share_outlined, color: Colors.white),
                        onPressed: widget.onShare,
                      ),
                  ],
                ),
              ),
            ),
          ),

          // Thumbnail strip
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: SafeArea(
              top: false,
              child: Container(
                height: _thumbH + 24,
                padding: const EdgeInsets.symmetric(vertical: 12),
                color: Colors.black,
                child: ListView.separated(
                  controller: _thumbController,
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  itemCount: total,
                  separatorBuilder: (_, __) => const SizedBox(width: _thumbGap),
                  itemBuilder: (ctx, i) {
                    final selected = i == _index;
                    return GestureDetector(
                      onTap: () => _pageController.animateToPage(
                        i,
                        duration: const Duration(milliseconds: 250),
                        curve: Curves.easeOut,
                      ),
                      child: AnimatedOpacity(
                        duration: const Duration(milliseconds: 150),
                        opacity: selected ? 1 : 0.55,
                        child: Container(
                          width: _thumbW,
                          height: _thumbH,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4),
                            border: Border.all(
                              color: selected ? Colors.white : Colors.transparent,
                              width: 2,
                            ),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(2),
                            child: SizedBox.expand(
                              child: _img(widget.images[i], fit: BoxFit.cover),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ),
        ],
      ),
      ),
    );
  }
}

/// Pinch-to-zoom + double-tap zoom; reports whether it is currently zoomed so
/// the parent PageView can stop swiping while the user pans a zoomed image.
class _ZoomablePage extends StatefulWidget {
  final Widget child;
  final ValueChanged<bool> onZoomChanged;
  const _ZoomablePage({required this.child, required this.onZoomChanged});

  @override
  State<_ZoomablePage> createState() => _ZoomablePageState();
}

class _ZoomablePageState extends State<_ZoomablePage> {
  final TransformationController _controller = TransformationController();
  TapDownDetails? _doubleTap;

  @override
  void initState() {
    super.initState();
    _controller.addListener(() {
      widget.onZoomChanged(_controller.value.getMaxScaleOnAxis() > 1.01);
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _toggleZoom() {
    if (_controller.value.getMaxScaleOnAxis() > 1.01) {
      _controller.value = Matrix4.identity();
    } else if (_doubleTap != null) {
      final p = _doubleTap!.localPosition;
      _controller.value = Matrix4.identity()
        ..translate(-p.dx * 1.5, -p.dy * 1.5)
        ..scale(2.5);
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onDoubleTapDown: (d) => _doubleTap = d,
      onDoubleTap: _toggleZoom,
      child: InteractiveViewer(
        transformationController: _controller,
        minScale: 1,
        maxScale: 4,
        child: SizedBox.expand(child: widget.child),
      ),
    );
  }
}
