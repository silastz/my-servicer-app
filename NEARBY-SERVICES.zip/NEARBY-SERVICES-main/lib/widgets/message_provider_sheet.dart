import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../screens/chat_thread_screen.dart';
import '../services/api_service.dart';
import '../services/data_sync.dart';
import '../services/session_manager.dart';
import 'login_modal.dart';

/// Bottom sheet that lets the buyer send a message to the provider without
/// leaving the screen (e.g. from navigation): quick replies + free text.
/// Messages go through the normal chat, so they also appear in the Chats tab.
class MessageProviderSheet extends StatefulWidget {
  final int? providerId;
  final String providerName;

  /// Optional extra context appended to quick messages, e.g. "ETA 12 min".
  final String? etaText;

  const MessageProviderSheet({super.key, required this.providerId, required this.providerName, this.etaText});

  /// Returns true when a message was sent.
  static Future<bool?> show(
    BuildContext context, {
    required int? providerId,
    required String providerName,
    String? etaText,
  }) async {
    final isEn = AppStrings.isEnglish;
    if (providerId == null || providerId == 0) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(isEn ? 'Messaging is not available for this provider yet.' : 'Kutuma ujumbe hakupatikani kwa mtoa huduma huyu bado.'),
      ));
      return false;
    }
    if (!SessionManager.isLoggedIn()) {
      final ok = await LoginModal.show(context);
      if (ok != true || !SessionManager.isLoggedIn() || !context.mounted) return false;
    }
    if (SessionManager.getUserIdValue() == providerId) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(isEn ? "You can't message yourself." : 'Huwezi kujitumia ujumbe.'),
      ));
      return false;
    }
    return showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => MessageProviderSheet(providerId: providerId, providerName: providerName, etaText: etaText),
    );
  }

  @override
  State<MessageProviderSheet> createState() => _MessageProviderSheetState();
}

class _MessageProviderSheetState extends State<MessageProviderSheet> {
  final TextEditingController _input = TextEditingController();
  bool _sending = false;
  bool _sent = false;
  String? _error;

  bool get _en => AppStrings.isEnglish;

  List<String> get _quick {
    final eta = (widget.etaText ?? '').trim();
    return _en
        ? [
            eta.isEmpty ? "I'm on my way." : "I'm on my way. ETA $eta.",
            "I've arrived. Where exactly are you?",
            "I'm running a few minutes late.",
            'Can you share the exact location?',
          ]
        : [
            eta.isEmpty ? 'Niko njiani.' : 'Niko njiani. Nitafika baada ya $eta.',
            'Nimefika. Uko wapi hasa?',
            'Nitachelewa dakika chache.',
            'Naomba unitumie eneo kamili.',
          ];
  }

  @override
  void dispose() {
    _input.dispose();
    super.dispose();
  }

  Future<void> _send([String? preset]) async {
    final text = (preset ?? _input.text).trim();
    if (text.isEmpty || _sending) return;
    setState(() {
      _sending = true;
      _error = null;
    });
    final res = await ApiService.sendMessage(recipientId: widget.providerId.toString(), message: text);
    if (!mounted) return;
    if (res == null) {
      setState(() {
        _sending = false;
        _error = _en ? 'Message not sent. Try again.' : 'Ujumbe haujatumwa. Jaribu tena.';
      });
      return;
    }
    DataSync.bump();
    _input.clear();
    setState(() {
      _sending = false;
      _sent = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Padding(
      padding: EdgeInsets.only(bottom: bottom),
      child: Container(
        padding: EdgeInsets.fromLTRB(20, 14, 20, 20 + MediaQuery.of(context).padding.bottom),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)),
              ),
            ),
            const SizedBox(height: 14),
            Text(
              _en ? 'Message ${widget.providerName}' : 'Tuma ujumbe kwa ${widget.providerName}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
            ),
            const SizedBox(height: 12),
            if (_sent) ...[
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: AppColors.primaryLight, borderRadius: BorderRadius.circular(12)),
                child: Row(
                  children: [
                    const Icon(Icons.check_circle_rounded, color: AppColors.success, size: 22),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        _en ? 'Message sent to the provider.' : 'Ujumbe umetumwa kwa mtoa huduma.',
                        style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => setState(() => _sent = false),
                      style: _outlineStyle,
                      child: Text(_en ? 'Send another' : 'Tuma mwingine'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        final nav = Navigator.of(context);
                        final ctx = nav.context;
                        nav.pop(true);
                        ChatThreadScreen.open(ctx, recipientId: widget.providerId, name: widget.providerName);
                      },
                      style: _filledStyle,
                      child: Text(_en ? 'Open chat' : 'Fungua mazungumzo'),
                    ),
                  ),
                ],
              ),
            ] else ...[
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final q in _quick)
                    ActionChip(
                      label: Text(q, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                      backgroundColor: AppColors.background,
                      side: const BorderSide(color: AppColors.border),
                      onPressed: _sending ? null : () => _send(q),
                    ),
                ],
              ),
              const SizedBox(height: 14),
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Expanded(
                    child: TextField(
                      controller: _input,
                      minLines: 1,
                      maxLines: 4,
                      maxLength: 500,
                      textCapitalization: TextCapitalization.sentences,
                      decoration: InputDecoration(
                        counterText: '',
                        hintText: _en ? 'Write a message…' : 'Andika ujumbe…',
                        filled: true,
                        fillColor: AppColors.background,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Material(
                    color: AppColors.primary,
                    shape: const CircleBorder(),
                    child: InkWell(
                      customBorder: const CircleBorder(),
                      onTap: _sending ? null : () => _send(),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: _sending
                            ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                            : const Icon(Icons.send_rounded, color: Colors.white, size: 20),
                      ),
                    ),
                  ),
                ],
              ),
              if (_error != null) ...[
                const SizedBox(height: 8),
                Text(_error!, style: const TextStyle(color: AppColors.danger, fontSize: 12, fontWeight: FontWeight.w600)),
              ],
            ],
          ],
        ),
      ),
    );
  }

  ButtonStyle get _outlineStyle => OutlinedButton.styleFrom(
        foregroundColor: AppColors.primary,
        side: const BorderSide(color: AppColors.border),
        padding: const EdgeInsets.symmetric(vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      );

  ButtonStyle get _filledStyle => ElevatedButton.styleFrom(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        elevation: 0,
        padding: const EdgeInsets.symmetric(vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      );
}
