import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

/// Small "18+" label shown on sensitive services (cards, details, provider profile).
class SensitiveTag extends StatelessWidget {
  final bool compact;
  const SensitiveTag({super.key, this.compact = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: compact ? 5 : 8, vertical: compact ? 1.5 : 3),
      decoration: BoxDecoration(
        color: AppColors.danger,
        borderRadius: BorderRadius.circular(compact ? 6 : 8),
      ),
      child: Text(
        '18+',
        style: TextStyle(fontSize: compact ? 9 : 11, fontWeight: FontWeight.w800, color: Colors.white),
      ),
    );
  }
}
