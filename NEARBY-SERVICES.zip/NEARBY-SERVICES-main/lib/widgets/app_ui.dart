import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show TextInputFormatter;
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';

/// Shared building blocks so every sheet, popup, field and button looks the same
/// (white surface, 24px sheet corners, 12px fields/buttons, brand blue actions).

/// Bottom sheet: handle bar, title row with close button, scrollable body.
class AppSheet {
  static Future<T?> show<T>(
    BuildContext context, {
    required String title,
    String? subtitle,
    required WidgetBuilder builder,
    bool showClose = true,
  }) {
    return showModalBottomSheet<T>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        final media = MediaQuery.of(ctx);
        return Padding(
          padding: EdgeInsets.only(bottom: media.viewInsets.bottom),
          child: Container(
            constraints: BoxConstraints(maxHeight: media.size.height * 0.92),
            decoration: const BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
            ),
            child: SafeArea(
              top: false,
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            title,
                            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                          ),
                        ),
                        if (showClose)
                          InkResponse(
                            onTap: () => Navigator.pop(ctx),
                            radius: 20,
                            child: const Padding(
                              padding: EdgeInsets.all(4),
                              child: Icon(Icons.close_rounded, color: AppColors.textSecondary, size: 22),
                            ),
                          ),
                      ],
                    ),
                    if (subtitle != null) ...[
                      const SizedBox(height: 4),
                      Text(subtitle, style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textSecondary)),
                    ],
                    const SizedBox(height: 16),
                    builder(ctx),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

/// Full-screen page with the same signature as [AppSheet]: app bar with back
/// arrow and title, scrollable body. Pop with a value to return it.
class AppPage {
  static Future<T?> show<T>(
    BuildContext context, {
    required String title,
    String? subtitle,
    required WidgetBuilder builder,
    bool showClose = true,
  }) {
    return Navigator.of(context).push<T>(MaterialPageRoute<T>(
      fullscreenDialog: false,
      builder: (ctx) => Scaffold(
        backgroundColor: AppColors.surface,
        appBar: AppBar(
          backgroundColor: AppColors.surface,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textPrimary),
            onPressed: () => Navigator.pop(ctx),
          ),
          title: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(1),
            child: Container(color: AppColors.borderLight, height: 1),
          ),
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(20, 16, 20, 20 + MediaQuery.of(ctx).viewInsets.bottom),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (subtitle != null) ...[
                  Text(subtitle, style: const TextStyle(fontSize: 13, height: 1.4, color: AppColors.textSecondary)),
                  const SizedBox(height: 16),
                ],
                builder(ctx),
              ],
            ),
          ),
        ),
      ),
    ));
  }
}

/// Centered popup with a tinted icon, short text and one or two full-width buttons.
class AppDialog {
  static Future<bool> confirm(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String message,
    required String confirmLabel,
    String? cancelLabel,
    Color color = AppColors.primary,
  }) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => _frame(
        ctx,
        icon: icon,
        color: color,
        title: title,
        message: message,
        actions: [
          Expanded(child: AppButton.outlined(label: cancelLabel ?? (AppStrings.isEnglish ? 'Cancel' : 'Ghairi'), onPressed: () => Navigator.pop(ctx, false))),
          const SizedBox(width: 10),
          Expanded(child: AppButton.primary(label: confirmLabel, color: color, onPressed: () => Navigator.pop(ctx, true))),
        ],
      ),
    );
    return ok == true;
  }

  static Future<void> info(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String message,
    String? buttonLabel,
    Color color = AppColors.primary,
    Widget? leading,
  }) {
    return showDialog<void>(
      context: context,
      builder: (ctx) => _frame(
        ctx,
        icon: icon,
        color: color,
        leading: leading,
        title: title,
        message: message,
        actions: [Expanded(child: AppButton.primary(label: buttonLabel ?? 'OK', color: color, onPressed: () => Navigator.pop(ctx)))],
      ),
    );
  }

  static Widget _frame(
    BuildContext ctx, {
    required IconData icon,
    required Color color,
    required String title,
    required String message,
    required List<Widget> actions,
    Widget? leading,
  }) {
    return Dialog(
      backgroundColor: AppColors.surface,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            leading ??
                Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(color: color.withValues(alpha: 0.12), shape: BoxShape.circle),
                  child: Icon(icon, color: color, size: 28),
                ),
            const SizedBox(height: 16),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
            ),
            const SizedBox(height: 8),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 13, height: 1.45, color: AppColors.textSecondary),
            ),
            const SizedBox(height: 20),
            Row(children: actions),
          ],
        ),
      ),
    );
  }
}

/// Same field look as the login screen: grey fill, 12px corners, icon on the left.
class AppTextField extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final IconData? icon;
  final String? label;
  final bool obscureText;
  final bool enabled;
  final TextInputType keyboardType;
  final String? errorText;
  final ValueChanged<String>? onChanged;
  final List<TextInputFormatter>? inputFormatters;
  final int maxLines;
  final int? maxLength;

  /// Shown between the icon and the text, e.g. a CountryCodePicker for phone numbers.
  final Widget? prefix;

  const AppTextField({
    super.key,
    required this.controller,
    required this.hint,
    this.icon,
    this.label,
    this.obscureText = false,
    this.enabled = true,
    this.keyboardType = TextInputType.text,
    this.errorText,
    this.onChanged,
    this.inputFormatters,
    this.maxLines = 1,
    this.maxLength,
    this.prefix,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (label != null) ...[
          Text(label!, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
          const SizedBox(height: 6),
        ],
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          decoration: BoxDecoration(
            color: enabled ? AppColors.background : AppColors.borderLight,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: errorText != null ? AppColors.danger : AppColors.border),
          ),
          child: TextField(
            controller: controller,
            obscureText: obscureText,
            enabled: enabled,
            keyboardType: maxLines > 1 ? TextInputType.multiline : keyboardType,
            maxLines: obscureText ? 1 : maxLines,
            minLines: maxLines > 1 ? 3 : null,
            maxLength: maxLength,
            onChanged: onChanged,
            inputFormatters: inputFormatters,
            enableSuggestions: !obscureText,
            autocorrect: !obscureText,
            style: const TextStyle(fontSize: 14, color: AppColors.textPrimary),
            decoration: InputDecoration(
              icon: icon == null ? null : Icon(icon, color: AppColors.textMuted, size: 20),
              prefixIcon: prefix,
              prefixIconConstraints: const BoxConstraints(minWidth: 0, minHeight: 0),
              hintText: hint,
              hintStyle: const TextStyle(fontSize: 13, color: AppColors.textMuted),
              border: InputBorder.none,
            ),
          ),
        ),
        if (errorText != null) ...[
          const SizedBox(height: 4),
          Text(errorText!, style: const TextStyle(fontSize: 11, color: AppColors.danger, fontWeight: FontWeight.w600)),
        ],
      ],
    );
  }
}

/// Full-width 48px buttons matching the login/submit buttons.
///
/// Shows a spinner AUTOMATICALLY while an `async` [onPressed] is running (no flag needed),
/// ignores taps while busy (no double submit), and can also be driven by [loading].
class AppButton extends StatefulWidget {
  final String label;
  final VoidCallback? onPressed;
  final bool loading;
  final bool outlined;
  final Color color;

  const AppButton.primary({super.key, required this.label, required this.onPressed, this.loading = false, this.color = AppColors.primary})
      : outlined = false;

  const AppButton.outlined({super.key, required this.label, required this.onPressed, this.loading = false})
      : outlined = true,
        color = AppColors.primary;

  @override
  State<AppButton> createState() => _AppButtonState();
}

class _AppButtonState extends State<AppButton> {
  bool _running = false;

  Future<void> _tap() async {
    final cb = widget.onPressed;
    if (cb == null || _running) return;
    // An `async` closure returns a Future even though the type says void: wait for it.
    final dynamic result = Function.apply(cb, const []);
    if (result is Future) {
      setState(() => _running = true);
      try {
        await result;
      } finally {
        if (mounted) setState(() => _running = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final busy = widget.loading || _running;
    final enabled = widget.onPressed != null && !busy;
    final shape = RoundedRectangleBorder(borderRadius: BorderRadius.circular(12));
    return SizedBox(
      width: double.infinity,
      height: 48,
      child: widget.outlined
          ? OutlinedButton(
              onPressed: enabled ? _tap : null,
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppColors.border),
                shape: shape,
                padding: const EdgeInsets.symmetric(horizontal: 8),
              ),
              child: busy
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.primary))
                  : Text(widget.label, maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
            )
          : ElevatedButton(
              onPressed: enabled ? _tap : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: widget.color,
                disabledBackgroundColor: widget.color.withValues(alpha: busy ? 0.6 : 0.4),
                elevation: 0,
                shape: shape,
                padding: const EdgeInsets.symmetric(horizontal: 8),
              ),
              child: busy
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : Text(widget.label, maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Colors.white)),
            ),
    );
  }
}

/// Small text button (e.g. "Resend code") that shows a spinner while [loading] and a live
/// [label] (e.g. "Resend (28s)") otherwise. Disabled when [onPressed] is null or [loading].
class LoadingTextButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final bool loading;
  const LoadingTextButton({super.key, required this.label, required this.onPressed, this.loading = false});

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null && !loading;
    return TextButton(
      onPressed: enabled ? onPressed : null,
      child: loading
          ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.primary))
          : Text(label,
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: enabled ? AppColors.primary : AppColors.textMuted)),
    );
  }
}

/// Small rounded "On / Off / Not available" pill used on switch rows.
class StatusPill extends StatelessWidget {
  final String text;
  final Color color;
  const StatusPill({super.key, required this.text, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(12)),
      child: Text(text, style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: color)),
    );
  }
}
