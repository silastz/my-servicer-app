import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../models/models.dart';
import '../services/call_service.dart';

/// Pop-up with the call choices:
///  - In-app audio call (only when the provider is online)
///  - In-app video call (only when the provider is online and contacts are unlocked)
///  - Mobile call, with the number shown on the button (only when unlocked)
class CallOptionsSheet extends StatelessWidget {
  final ServiceItem? service;

  /// Contacts the server released for an accepted booking with this person. They win over the public service's
  /// lock: once a booking is accepted the two people can always reach each other.
  final BookingContacts? booking;

  const CallOptionsSheet({super.key, this.service, this.booking}) : assert(service != null || booking != null);

  static Future<void> show(BuildContext context, ServiceItem service, {BookingContacts? booking}) {
    return showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => CallOptionsSheet(service: service, booking: booking),
    );
  }

  /// For a person with an accepted booking but no public service (e.g. a customer the provider is chatting with).
  static Future<void> showForBooking(BuildContext context, BookingContacts booking) {
    return showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => CallOptionsSheet(booking: booking),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isEn = AppStrings.isEnglish;
    final svc = service;
    final bk = booking;
    final name = bk?.name.isNotEmpty == true ? bk!.name : (svc?.stageName ?? '');
    final userId = bk?.userId ?? svc?.sellerId;
    // An accepted booking unlocks everything; otherwise the service's own lock decides.
    final locked = bk != null ? false : svc!.isContactLocked;
    final online = svc?.isOnline ?? false;
    final phone = ((bk?.phone.isNotEmpty == true ? bk!.phone : svc?.phone) ?? '').trim();
    final showMobile = !locked && phone.isNotEmpty;
    // WhatsApp falls back to the phone number (which may come from the provider's profile).
    final waRaw = ((bk?.whatsapp.isNotEmpty == true ? bk!.whatsapp : svc?.whatsappPhone) ?? '').trim();
    final wa = waRaw.isNotEmpty ? waRaw : phone;
    final showWhatsApp = !locked && wa.isNotEmpty;
    final lat = bk?.latitude ?? svc?.latitude;
    final lng = bk?.longitude ?? svc?.longitude;
    final navQuery = [name, svc?.city ?? ''].where((e) => e.trim().isNotEmpty).join(', ');
    final showNavigate = !locked && (lat != null || (svc?.city ?? '').trim().isNotEmpty);

    void run(Future<void> Function() action) {
      final nav = Navigator.of(context);
      nav.pop();
      action();
    }

    // Use the root context so snackbars/login still work after the sheet closes.
    final rootContext = Navigator.of(context, rootNavigator: true).context;

    return Container(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 24),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              locked ? '${isEn ? 'Call' : 'Piga simu kwa'} ${name}' : '${isEn ? 'Contact' : 'Wasiliana na'} ${name}',
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
            ),
            const SizedBox(height: 16),

            if (online)
            _option(
              icon: Icons.call_rounded,
              color: AppColors.primary,
              title: isEn ? 'In-app Audio Call' : 'Simu ya Sauti (ndani ya app)',
              subtitle: isEn ? 'Free voice call over the internet' : 'Simu ya sauti kupitia intaneti',
              onTap: () => run(() => CallService.inAppCall(
                    rootContext,
                    recipientId: userId,
                    name: name,
                    video: false,
                  )),
            ),

            if (online && !locked) ...[
              const SizedBox(height: 10),
              _option(
                icon: Icons.videocam_rounded,
                color: const Color(0xFF7C3AED),
                title: isEn ? 'In-app Video Call' : 'Simu ya Video (ndani ya app)',
                subtitle: isEn ? 'Face-to-face over the internet' : 'Ona uso kwa uso kupitia intaneti',
                onTap: () => run(() => CallService.inAppCall(
                      rootContext,
                      recipientId: userId,
                      name: name,
                      video: true,
                    )),
              ),
            ],

            if (showMobile) ...[
              if (online) const SizedBox(height: 10),
              _option(
                icon: Icons.phone_android_rounded,
                color: AppColors.success,
                title: isEn ? 'Mobile Call' : 'Piga Simu ya Kawaida',
                subtitle: phone, // the number is shown on the button
                onTap: () => run(() => CallService.mobileCall(rootContext, phone)),
              ),
            ],

            if (showWhatsApp) ...[
              if (online || showMobile) const SizedBox(height: 10),
              _option(
                icon: FontAwesomeIcons.whatsapp,
                color: const Color(0xFF25D366),
                brand: true,
                title: 'WhatsApp',
                subtitle: wa,
                onTap: () => run(() => CallService.whatsapp(rootContext, wa)),
              ),
            ],

            if (showNavigate) ...[
              if (online || showMobile || showWhatsApp) const SizedBox(height: 10),
              _option(
                icon: Icons.navigation_rounded,
                color: AppColors.primary,
                title: isEn ? 'Navigate' : 'Elekea Mahali',
                subtitle: isEn ? 'Turn-by-turn directions in the app' : 'Maelekezo ya safari ndani ya app',
                onTap: () => run(() => CallService.navigate(
                      rootContext,
                      lat: lat,
                      lng: lng,
                      query: navQuery,
                      providerName: name,
                      serviceTitle: svc?.title ?? '',
                      providerId: userId,
                    )),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _option({
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    bool brand = false, // solid round brand button with a white logo (same as the service page)
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            if (brand)
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(shape: BoxShape.circle, color: color),
                child: Center(child: FaIcon(icon, size: 21, color: Colors.white)),
              )
            else
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(12)),
                child: Icon(icon, color: color, size: 22),
              ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                  const SizedBox(height: 2),
                  Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted),
          ],
        ),
      ),
    );
  }
}

/// What the server released for an accepted booking (`contactsUnlocked`) about the other person.
class BookingContacts {
  final int? userId;
  final String name;
  final String phone;
  final String whatsapp;
  final double? latitude;
  final double? longitude;

  const BookingContacts({this.userId, this.name = '', this.phone = '', this.whatsapp = '', this.latitude, this.longitude});
}
