import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';
import '../services/attempt_limiter.dart';
import '../services/biometric_service.dart';
import '../services/security_settings.dart';
import '../services/session_manager.dart';

/// Wraps the whole app. Shows the PIN screen over everything when App Lock is on:
/// at launch, and after the app was in the background longer than the chosen timeout.
class AppLockGate extends StatefulWidget {
  final Widget child;
  const AppLockGate({super.key, required this.child});

  @override
  State<AppLockGate> createState() => _AppLockGateState();
}

class _AppLockGateState extends State<AppLockGate> with WidgetsBindingObserver {
  bool _locked = SecuritySettings.appLockEnabled;
  DateTime? _pausedAt;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    SecuritySettings.changed.addListener(_onSettingsChanged);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    SecuritySettings.changed.removeListener(_onSettingsChanged);
    super.dispose();
  }

  void _onSettingsChanged() {
    // Turning the lock off (or losing the PIN) must never leave the screen locked.
    if (_locked && !SecuritySettings.appLockEnabled && mounted) setState(() => _locked = false);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // The fingerprint / Face ID prompt briefly pauses the app; that is not "leaving" it.
    if (BiometricService.isBusy) {
      _pausedAt = null;
      return;
    }
    if (state == AppLifecycleState.paused || state == AppLifecycleState.hidden) {
      if (!_locked) _pausedAt ??= DateTime.now();
    } else if (state == AppLifecycleState.resumed) {
      final since = _pausedAt;
      _pausedAt = null;
      if (since != null && SecuritySettings.appLockEnabled) {
        final away = DateTime.now().difference(since).inSeconds;
        if (away >= SecuritySettings.lockTimeoutSeconds && !_locked) {
          setState(() => _locked = true);
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        widget.child,
        if (_locked) Positioned.fill(child: AppLockScreen(onUnlocked: () => setState(() => _locked = false))),
      ],
    );
  }
}

class AppLockScreen extends StatefulWidget {
  final VoidCallback onUnlocked;
  const AppLockScreen({super.key, required this.onUnlocked});

  @override
  State<AppLockScreen> createState() => _AppLockScreenState();
}

class _AppLockScreenState extends State<AppLockScreen> {
  static const _limiterKey = 'app_lock_pin';
  String _entered = '';
  String? _error;
  bool _bioReady = false; // biometric unlock is on AND usable right now
  bool _bioMissing = false; // biometric unlock is on but the phone can't do it any more
  bool _confirmReset = false; // "Forgot PIN?" popup, drawn on the lock screen itself
  bool _resetting = false;

  bool get _isEn => AppStrings.isEnglish;

  @override
  void initState() {
    super.initState();
    _initBiometric();
  }

  Future<void> _initBiometric() async {
    if (!SecuritySettings.biometricEnabled) return;
    final available = await BiometricService.isAvailable();
    if (!mounted) return;
    setState(() {
      _bioReady = available;
      _bioMissing = !available;
    });
    if (available) _tryBiometric();
  }

  Future<void> _tryBiometric() async {
    final r = await BiometricService.authenticate(_isEn ? 'Unlock Ungana' : 'Fungua Ungana');
    if (!mounted) return;
    switch (r) {
      case BiometricResult.success:
        widget.onUnlocked();
        break;
      case BiometricResult.lockedOut:
        setState(() => _error = _isEn
            ? 'Biometrics are temporarily locked. Use your PIN.'
            : 'Alama za mwili zimefungwa kwa muda. Tumia PIN yako.');
        break;
      case BiometricResult.unavailable:
        setState(() {
          _bioReady = false;
          _bioMissing = true;
        });
        break;
      case BiometricResult.failed:
        break; // cancelled or not recognised: the PIN pad stays available
    }
  }

  void _tap(String d) {
    if (_entered.length >= 4) return;
    final wait = AttemptLimiter.secondsLocked(_limiterKey);
    if (wait > 0) {
      setState(() => _error = _isEn ? 'Too many attempts. Try again in ${wait}s.' : 'Majaribio mengi. Jaribu tena baada ya sekunde $wait.');
      return;
    }
    setState(() {
      _entered += d;
      _error = null;
    });
    if (_entered.length == 4) _check();
  }

  void _check() {
    if (SecuritySettings.verifyPin(_entered)) {
      AttemptLimiter.recordSuccess(_limiterKey);
      widget.onUnlocked();
    } else {
      HapticFeedback.heavyImpact();
      AttemptLimiter.recordFailure(_limiterKey);
      setState(() {
        _entered = '';
        _error = _isEn ? 'Wrong PIN' : 'PIN si sahihi';
      });
    }
  }

  void _back() {
    if (_entered.isEmpty) return;
    setState(() => _entered = _entered.substring(0, _entered.length - 1));
  }

  // The lock screen is drawn above the app's Navigator, so a normal dialog would open
  // underneath it and only show after unlocking. The popup is drawn here instead.
  void _forgot() => setState(() => _confirmReset = true);

  Future<void> _doReset() async {
    if (_resetting) return;
    setState(() => _resetting = true);
    await SessionManager.clearSession();
    await SecuritySettings.disableAppLock();
    AttemptLimiter.recordSuccess(_limiterKey);
    widget.onUnlocked();
  }

  Widget _resetOverlay() {
    return Positioned.fill(
      child: GestureDetector(
        onTap: _resetting ? null : () => setState(() => _confirmReset = false),
        child: Container(
          color: Colors.black54,
          alignment: Alignment.center,
          padding: const EdgeInsets.symmetric(horizontal: 28),
          child: GestureDetector(
            onTap: () {},
            child: Material(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(20),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 340),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 22, 20, 16),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(color: AppColors.danger.withValues(alpha: 0.1), shape: BoxShape.circle),
                        child: const Icon(Icons.lock_reset_rounded, color: AppColors.danger, size: 28),
                      ),
                      const SizedBox(height: 14),
                      Text(
                        _isEn ? 'Forgot PIN?' : 'Umesahau PIN?',
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _isEn
                            ? 'To reset the lock you will be signed out and App Lock will be turned off. You can sign in again and set a new PIN.'
                            : 'Ili kuweka upya kufuli utatolewa kwenye akaunti na App Lock itazimwa. Unaweza kuingia tena na kuweka PIN mpya.',
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 13, height: 1.45, color: AppColors.textSecondary),
                      ),
                      const SizedBox(height: 18),
                      SizedBox(
                        width: double.infinity,
                        height: 46,
                        child: ElevatedButton(
                          onPressed: _resetting ? null : _doReset,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.danger,
                            foregroundColor: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          ),
                          child: _resetting
                              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                              : Text(_isEn ? 'Sign out & reset' : 'Toka na weka upya',
                                  style: const TextStyle(fontWeight: FontWeight.w800)),
                        ),
                      ),
                      const SizedBox(height: 4),
                      TextButton(
                        onPressed: _resetting ? null : () => setState(() => _confirmReset = false),
                        child: Text(_isEn ? 'Cancel' : 'Ghairi',
                            style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.textSecondary)),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final name = SessionManager.isLoggedIn() ? SessionManager.getStageName() : '';
    return Material(
      color: AppColors.surface,
      child: Stack(children: [
      SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) => SingleChildScrollView(
            child: ConstrainedBox(
              constraints: BoxConstraints(minHeight: constraints.maxHeight),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: Image.asset(
                        'assets/images/app_icon.png',
                        width: 72,
                        height: 72,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          width: 72,
                          height: 72,
                          color: AppColors.primaryLight,
                          child: const Icon(Icons.lock_rounded, size: 34, color: AppColors.primary),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      name.isNotEmpty ? (_isEn ? 'Welcome back, $name' : 'Karibu tena, $name') : (_isEn ? 'Welcome back' : 'Karibu tena'),
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _isEn ? 'Enter your PIN to unlock' : 'Weka PIN yako kufungua',
                      style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
                    ),
                    const SizedBox(height: 24),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        for (var i = 0; i < 4; i++)
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 120),
                            margin: const EdgeInsets.symmetric(horizontal: 8),
                            width: 16,
                            height: 16,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: i < _entered.length ? AppColors.primary : Colors.transparent,
                              border: Border.all(color: _error != null ? AppColors.danger : AppColors.primary, width: 2),
                            ),
                          ),
                      ],
                    ),
                    SizedBox(
                      height: 44,
                      child: Center(
                        child: Text(
                          _error ?? '',
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 12, color: AppColors.danger, fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                    PinKeypad(onDigit: _tap, onBackspace: _back, onBiometric: _bioReady ? _tryBiometric : null),
                    if (_bioMissing)
                      Padding(
                        padding: const EdgeInsets.only(top: 12),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          decoration: BoxDecoration(
                            color: AppColors.warningLight,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.info_outline_rounded, size: 16, color: AppColors.warningDark),
                              const SizedBox(width: 8),
                              Flexible(
                                child: Text(
                                  _isEn
                                      ? 'Fingerprint / Face unlock is not available right now. Use your PIN.'
                                      : 'Kufungua kwa kidole / uso hakupatikani sasa. Tumia PIN yako.',
                                  style: const TextStyle(fontSize: 11, color: AppColors.warningDark),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    const SizedBox(height: 8),
                    TextButton(
                      onPressed: _forgot,
                      child: Text(
                        _isEn ? 'Forgot PIN?' : 'Umesahau PIN?',
                        style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.primary),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
      if (_confirmReset) _resetOverlay(),
      ]),
    );
  }
}

/// 0-9 keypad with round keys and a backspace key.
class PinKeypad extends StatelessWidget {
  final ValueChanged<String> onDigit;
  final VoidCallback onBackspace;

  /// When set, the empty bottom-left key becomes a fingerprint button.
  final VoidCallback? onBiometric;

  /// Diameter of each round key.
  final double keySize;

  const PinKeypad({
    super.key,
    required this.onDigit,
    required this.onBackspace,
    this.onBiometric,
    this.keySize = 68,
  });

  Widget _slot(Widget? child, VoidCallback? onTap, {bool filled = true}) {
    return Padding(
      padding: const EdgeInsets.all(6),
      child: SizedBox(
        width: keySize,
        height: keySize,
        child: child == null || onTap == null
            ? null
            : Material(
                color: filled ? AppColors.background : Colors.transparent,
                shape: CircleBorder(side: BorderSide(color: filled ? AppColors.border : Colors.transparent)),
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: onTap,
                  child: Center(child: child),
                ),
              ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Widget digit(String d) => _slot(
          Text(d, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
          () => onDigit(d),
        );
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (final row in const [
          ['1', '2', '3'],
          ['4', '5', '6'],
          ['7', '8', '9'],
        ])
          Row(mainAxisSize: MainAxisSize.min, children: [for (final d in row) digit(d)]),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _slot(const Icon(Icons.fingerprint_rounded, size: 30, color: AppColors.primary), onBiometric, filled: false),
            digit('0'),
            _slot(const Icon(Icons.backspace_outlined, size: 22, color: AppColors.textPrimary), onBackspace, filled: false),
          ],
        ),
      ],
    );
  }
}
