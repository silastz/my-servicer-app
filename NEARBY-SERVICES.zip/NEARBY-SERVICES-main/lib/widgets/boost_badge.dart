import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';

/// Small "Boosted" tag shown on a service that a provider paid to promote.
class BoostBadge extends StatelessWidget {
  final bool compact;
  const BoostBadge({super.key, this.compact = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: compact ? 5 : 8, vertical: compact ? 2 : 3),
      decoration: BoxDecoration(
        color: AppColors.warning,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.bolt_rounded, size: compact ? 10 : 13, color: Colors.white),
          SizedBox(width: compact ? 1 : 3),
          Text(
            AppStrings.isEnglish ? 'Boosted' : 'Imetangazwa',
            style: TextStyle(fontSize: compact ? 8 : 10, fontWeight: FontWeight.w800, color: Colors.white),
          ),
        ],
      ),
    );
  }
}
