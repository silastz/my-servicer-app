import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';

/// Small helpers shared by the admin screens (verification, reports, bookings, boost plans, fees, app version).
String adminT(String en, String sw) => AppStrings.isEnglish ? en : sw;

void adminSnack(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
}

/// Asks for one line of text. Returns null when cancelled.
Future<String?> adminPrompt(
  BuildContext context, {
  required String title,
  required String hint,
  String initial = '',
  bool required = false,
  TextInputType? keyboard,
}) {
  final ctrl = TextEditingController(text: initial);
  String? err;
  return showDialog<String>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setS) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          keyboardType: keyboard,
          maxLines: keyboard == null ? 3 : 1,
          minLines: 1,
          decoration: InputDecoration(hintText: hint, errorText: err),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(adminT('Cancel', 'Ghairi'))),
          TextButton(
            onPressed: () {
              final v = ctrl.text.trim();
              if (required && v.isEmpty) {
                setS(() => err = adminT('Required', 'Inahitajika'));
                return;
              }
              Navigator.pop(ctx, v);
            },
            child: const Text('OK'),
          ),
        ],
      ),
    ),
  );
}

/// What to show instead of the list: spinner, "admins only", "could not load" or "nothing here".
/// Returns null when the real content should be drawn.
Widget? adminStateOrNull({
  required bool loading,
  required bool forbidden,
  required bool failed,
  required bool empty,
  required VoidCallback onRetry,
  String? emptyText,
}) {
  if (loading) return const Center(child: CircularProgressIndicator());
  if (forbidden) {
    return _centered(Icons.lock_outline_rounded, adminT('Only an admin can open this.', 'Msimamizi pekee anaweza kufungua hili.'), null);
  }
  if (failed) {
    return _centered(Icons.cloud_off_rounded, adminT('Could not load. Check your connection.', 'Imeshindwa kupakia. Angalia mtandao.'),
        TextButton(onPressed: onRetry, child: Text(adminT('Try again', 'Jaribu tena'))));
  }
  if (empty) {
    return _centered(Icons.inbox_outlined, emptyText ?? adminT('Nothing here.', 'Hakuna kitu hapa.'), null);
  }
  return null;
}

Widget _centered(IconData icon, String text, Widget? action) {
  return Center(
    child: Padding(
      padding: const EdgeInsets.all(32),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 44, color: AppColors.textMuted),
        const SizedBox(height: 12),
        Text(text, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.textSecondary, fontSize: 14)),
        if (action != null) action,
      ]),
    ),
  );
}

/// One "label: value" line; hidden when the value is empty.
Widget adminInfoLine(String label, Object? value) {
  final v = (value ?? '').toString().trim();
  if (v.isEmpty || v == 'null') return const SizedBox.shrink();
  return Padding(
    padding: const EdgeInsets.only(top: 3),
    child: RichText(
      text: TextSpan(
        style: const TextStyle(fontSize: 13, color: AppColors.textPrimary),
        children: [
          TextSpan(text: '$label: ', style: const TextStyle(color: AppColors.textSecondary)),
          TextSpan(text: v),
        ],
      ),
    ),
  );
}

BoxDecoration adminCardDecoration() => BoxDecoration(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: AppColors.border),
    );
