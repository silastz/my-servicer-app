import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';

/// One step of the "complete your profile" checklist.
class ProfileTask {
  final String title;
  final String hint;
  final IconData icon;
  final bool done;
  final VoidCallback onTap;

  const ProfileTask({
    required this.title,
    required this.hint,
    required this.icon,
    required this.done,
    required this.onTap,
  });
}

/// Progress card + checklist. Hidden automatically when everything is complete.
class ProfileCompletionCard extends StatelessWidget {
  final List<ProfileTask> tasks;

  const ProfileCompletionCard({super.key, required this.tasks});

  @override
  Widget build(BuildContext context) {
    if (tasks.isEmpty) return const SizedBox.shrink();
    final doneCount = tasks.where((t) => t.done).length;
    if (doneCount == tasks.length) return const SizedBox.shrink();

    final isEn = AppStrings.isEnglish;
    final percent = doneCount / tasks.length;

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  isEn ? 'Complete your profile' : 'Kamilisha wasifu wako',
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(color: AppColors.primaryLight, borderRadius: BorderRadius.circular(12)),
                child: Text(
                  '${(percent * 100).round()}%',
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: AppColors.primary),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            isEn ? '$doneCount of ${tasks.length} steps done' : 'Hatua $doneCount kati ya ${tasks.length} zimekamilika',
            style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
          ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: percent,
              minHeight: 8,
              backgroundColor: AppColors.borderLight,
              valueColor: const AlwaysStoppedAnimation<Color>(AppColors.primary),
            ),
          ),
          const SizedBox(height: 8),
          for (var i = 0; i < tasks.length; i++) ...[
            if (i > 0) const Divider(height: 1, color: AppColors.borderLight),
            InkWell(
              onTap: tasks[i].done ? null : tasks[i].onTap,
              borderRadius: BorderRadius.circular(10),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Row(
                  children: [
                    Container(
                      width: 34,
                      height: 34,
                      decoration: BoxDecoration(
                        color: tasks[i].done ? AppColors.successLight : AppColors.primaryLight,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(
                        tasks[i].done ? Icons.check_rounded : tasks[i].icon,
                        size: 18,
                        color: tasks[i].done ? AppColors.successDark : AppColors.primary,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            tasks[i].title,
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              color: tasks[i].done ? AppColors.textSecondary : AppColors.textPrimary,
                            ),
                          ),
                          if (!tasks[i].done)
                            Padding(
                              padding: const EdgeInsets.only(top: 2),
                              child: Text(tasks[i].hint, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                            ),
                        ],
                      ),
                    ),
                    if (!tasks[i].done) const Icon(Icons.chevron_right_rounded, size: 20, color: AppColors.textMuted),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
