import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:ungana/models/ads_config.dart';
import 'package:ungana/models/house_ads.dart';

Map<String, dynamic> _ad({String id = 'a1', Map<String, dynamic> extra = const {}}) => {
      'id': id,
      'title': 'Plumbers near you',
      'imageUrl': 'https://example.com/p.jpg',
      'url': 'https://example.com/plumbers',
      ...extra,
    };

void main() {
  group('HouseAds.parse', () {
    test('minimal ad gets safe defaults', () {
      final r = HouseAds.parse({'ads': [_ad()]});
      expect(r.ok, isTrue);
      final a = r.ads.single;
      expect(a.cta, 'Open');
      expect(a.weight, 1);
      expect(a.enabled, isTrue);
      expect(a.formats, {AdFormat.banner, AdFormat.native});
      expect(a.platforms, {AdPlatform.android, AdPlatform.ios});
      expect(a.pages, isNot(contains(AdPage.videoReward)));
    });

    test('accepts a bare list and an empty text', () {
      expect(HouseAds.parse([_ad()]).ads.length, 1);
      expect(HouseAds.parseText('').ok, isTrue);
      expect(HouseAds.parseText('   ').ads, isEmpty);
      expect(HouseAds.parse(null).ads, isEmpty);
    });

    test('reports broken JSON without throwing', () {
      final r = HouseAds.parseText('{ "ads": [ ');
      expect(r.ok, isFalse);
      expect(r.errors.single, startsWith('Not valid JSON'));
    });

    test('only https links are allowed', () {
      for (final bad in ['http://example.com/a', 'javascript:alert(1)', 'file:///etc/passwd', 'https://user:pw@example.com/', 'https://localhost/x', 'example.com']) {
        expect(HouseAds.parse([_ad(extra: {'url': bad})]).ok, isFalse, reason: bad);
        expect(HouseAds.parse([_ad(extra: {'imageUrl': bad})]).ok, isFalse, reason: bad);
      }
    });

    test('required fields, lengths and ids', () {
      expect(HouseAds.parse([{'title': 'x', 'imageUrl': 'https://a.co/i', 'url': 'https://a.co'}]).ok, isFalse); // no id
      expect(HouseAds.parse([_ad(extra: {'title': 'x' * 61})]).ok, isFalse);
      expect(HouseAds.parse([_ad(extra: {'body': 'x' * 141})]).ok, isFalse);
      expect(HouseAds.parse([_ad(id: 'bad id!')]).ok, isFalse);
      expect(HouseAds.parse([_ad(id: 'same'), _ad(id: 'same')]).errors.join(), contains('used twice'));
    });

    test('formats, pages, platforms must be known', () {
      expect(HouseAds.parse([_ad(extra: {'formats': ['video']})]).ok, isFalse);
      expect(HouseAds.parse([_ad(extra: {'pages': ['settings']})]).ok, isFalse);
      expect(HouseAds.parse([_ad(extra: {'platforms': ['windows']})]).ok, isFalse);
      final ok = HouseAds.parse([_ad(extra: {'formats': ['Banner'], 'pages': ['HOME', 'search'], 'platforms': ['ios']})]);
      expect(ok.ok, isTrue);
      expect(ok.ads.single.pages, {AdPage.home, AdPage.search});
    });

    test('weight and dates', () {
      expect(HouseAds.parse([_ad(extra: {'weight': 0})]).ok, isFalse);
      expect(HouseAds.parse([_ad(extra: {'weight': 101})]).ok, isFalse);
      expect(HouseAds.parse([_ad(extra: {'weight': 2.5})]).ok, isFalse);
      expect(HouseAds.parse([_ad(extra: {'weight': 5})]).ads.single.weight, 5);
      expect(HouseAds.parse([_ad(extra: {'start': 'tomorrow'})]).ok, isFalse);
      expect(HouseAds.parse([_ad(extra: {'start': '2026-12-01T00:00:00Z', 'end': '2026-11-01T00:00:00Z'})]).ok, isFalse);
    });

    test('one bad ad does not drop the good ones, but the admin sees the error', () {
      final r = HouseAds.parse([_ad(id: 'good'), _ad(id: 'bad', extra: {'url': 'http://x.co'})]);
      expect(r.ads.map((a) => a.id), ['good']);
      expect(r.ok, isFalse);
    });

    test('at most 20 ads', () {
      final many = [for (var i = 0; i < 21; i++) _ad(id: 'a$i')];
      final r = HouseAds.parse(many);
      expect(r.ok, isFalse);
      expect(r.ads.length, 20);
    });

    test('the built-in example is valid', () {
      expect(HouseAds.parseText(HouseAds.example).ok, isTrue);
    });

    test('toText then parseText gives the same ads', () {
      final ads = HouseAds.parse([
        _ad(extra: {'weight': 4, 'pages': ['home'], 'start': '2026-11-01T00:00:00Z', 'end': '2026-11-30T00:00:00Z', 'body': 'Hi'})
      ]).ads;
      final back = HouseAds.parseText(HouseAds.toText(ads));
      expect(back.ok, isTrue);
      expect(back.ads.single.toJson(), ads.single.toJson());
    });
  });

  group('all formats', () {
    test('rewarded is a valid format and defaults to the video page', () {
      final r = HouseAds.parse([_ad(extra: {'formats': ['rewarded']})]);
      expect(r.ok, isTrue);
      final a = r.ads.single;
      expect(a.formats, {AdFormat.rewarded});
      expect(a.pages, {AdPage.videoReward});
      expect(a.rewardSeconds, 5);
    });

    test('all three formats default to every page that shows one of them', () {
      final a = HouseAds.parse([_ad(extra: {'formats': ['banner', 'native', 'rewarded']})]).ads.single;
      expect(a.pages, HouseAds.pagesWithHouse.toSet());
      // banner + native only (the old default) still leaves the video page out
      expect(HouseAds.defaultPages({AdFormat.banner, AdFormat.native}), isNot(contains(AdPage.videoReward)));
    });

    test('the video page can be listed explicitly', () {
      final a = HouseAds.parse([_ad(extra: {'formats': ['rewarded'], 'pages': ['videoReward']})]).ads.single;
      expect(a.matches(AdPage.videoReward, AdFormat.rewarded, AdPlatform.android, DateTime.utc(2026, 11, 1)), isTrue);
      expect(a.matches(AdPage.home, AdFormat.rewarded, AdPlatform.android, DateTime.utc(2026, 11, 1)), isFalse);
    });

    test('rewardSeconds is 3 to 30', () {
      for (final bad in [0, 2, 31, 4.5, 'five']) {
        expect(HouseAds.parse([_ad(extra: {'formats': ['rewarded'], 'rewardSeconds': bad})]).ok, isFalse, reason: '$bad');
      }
      expect(HouseAds.parse([_ad(extra: {'formats': ['rewarded'], 'rewardSeconds': 12})]).ads.single.rewardSeconds, 12);
    });

    test('a rewarded in-house ad joins the video page chain', () {
      final house = HouseAds.parse([_ad(extra: {'formats': ['rewarded']})]).ads;
      final c = AdsConfig(defaultProvider: AdProvider.inhouse, autoFallback: false, house: house);
      expect(c.chain(AdPage.videoReward, AdFormat.rewarded, AdPlatform.android), [AdProvider.inhouse]);
      expect(c.chain(AdPage.home, AdFormat.banner, AdPlatform.android), isEmpty);
    });
  });

  group('countries', () {
    final now = DateTime.utc(2026, 11, 15);

    test('no list = every country, even an unknown one', () {
      final a = HouseAds.parse([_ad()]).ads.single;
      expect(a.countries, isEmpty);
      for (final c in ['TZ', 'KE', 'US', '', null]) {
        expect(a.matches(AdPage.home, AdFormat.banner, AdPlatform.android, now, country: c), isTrue, reason: '$c');
      }
    });

    test('a list limits the ad to those countries (any letter case)', () {
      final a = HouseAds.parse([_ad(extra: {'countries': ['tz', ' KE ']})]).ads.single;
      expect(a.countries, {'TZ', 'KE'});
      expect(a.matches(AdPage.home, AdFormat.banner, AdPlatform.android, now, country: 'TZ'), isTrue);
      expect(a.matches(AdPage.home, AdFormat.banner, AdPlatform.android, now, country: 'ke'), isTrue);
      expect(a.matches(AdPage.home, AdFormat.banner, AdPlatform.android, now, country: 'UG'), isFalse);
    });

    test('an ad with a country list is not shown while the country is unknown', () {
      final a = HouseAds.parse([_ad(extra: {'countries': ['TZ']})]).ads.single;
      expect(a.matches(AdPage.home, AdFormat.banner, AdPlatform.android, now), isFalse);
      expect(a.matches(AdPage.home, AdFormat.banner, AdPlatform.android, now, country: ''), isFalse);
    });

    test('bad country values are reported', () {
      for (final bad in [
        <String>[],
        ['TZA'],
        ['T'],
        ['12'],
        'TZ',
        [5],
      ]) {
        expect(HouseAds.parse([_ad(extra: {'countries': bad})]).ok, isFalse, reason: '$bad');
      }
    });

    test('the chain only holds ads for the person\'s country', () {
      final house = HouseAds.parse([_ad(extra: {'countries': ['KE']})]).ads;
      final c = AdsConfig(defaultProvider: AdProvider.inhouse, autoFallback: false, house: house);
      expect(c.chain(AdPage.home, AdFormat.banner, AdPlatform.android, country: 'KE'), [AdProvider.inhouse]);
      expect(c.chain(AdPage.home, AdFormat.banner, AdPlatform.android, country: 'TZ'), isEmpty);
      expect(c.chain(AdPage.home, AdFormat.banner, AdPlatform.android), isEmpty);
      expect(c.houseFor(AdPage.home, AdFormat.banner, AdPlatform.android, country: 'KE').length, 1);
    });
  });

  group('text per country', () {
    Map<String, dynamic> localised([Map<String, dynamic> more = const {}]) => _ad(extra: {
          'body': 'Book today',
          'cta': 'Book now',
          'title_TZ': 'Mafundi karibu nawe',
          'cta_TZ': 'Weka oda',
          'title_KE': 'Plumbers in Nairobi',
          'imageUrl_KE': 'https://example.com/ke.jpg',
          'url_KE': 'https://example.com/ke',
          ...more,
        });

    test('title, body, cta, imageUrl and url can be set per country', () {
      final r = HouseAds.parse([localised({'body_TZ': 'Weka oda leo'})]);
      expect(r.ok, isTrue, reason: r.errors.join('\n'));
      final a = r.ads.single;
      expect(a.local['TZ'], {'title': 'Mafundi karibu nawe', 'cta': 'Weka oda', 'body': 'Weka oda leo'});
      expect(a.local['KE']!['imageUrl'], 'https://example.com/ke.jpg');
      expect(a.local['KE']!['url'], 'https://example.com/ke');
    });

    test('forCountry swaps in that country\'s text and keeps the rest', () {
      final a = HouseAds.parse([localised()]).ads.single;
      final tz = a.forCountry('tz');
      expect(tz.title, 'Mafundi karibu nawe');
      expect(tz.cta, 'Weka oda');
      expect(tz.body, 'Book today'); // no body_TZ: the plain body
      expect(tz.imageUrl, 'https://example.com/p.jpg'); // no imageUrl_TZ
      final ke = a.forCountry('KE');
      expect(ke.title, 'Plumbers in Nairobi');
      expect(ke.cta, 'Book now'); // no cta_KE: the plain cta
      expect(ke.imageUrl, 'https://example.com/ke.jpg');
      expect(ke.url, 'https://example.com/ke');
    });

    test('other and unknown countries read the plain fields', () {
      final a = HouseAds.parse([localised()]).ads.single;
      for (final c in ['UG', '', null]) {
        final x = a.forCountry(c);
        expect(x.title, 'Plumbers near you', reason: '$c');
        expect(x.cta, 'Book now', reason: '$c');
      }
    });

    test('overrides do not limit who sees the ad', () {
      final a = HouseAds.parse([localised()]).ads.single;
      expect(a.countries, isEmpty);
      expect(a.matches(AdPage.home, AdFormat.banner, AdPlatform.android, DateTime.utc(2026, 11, 1), country: 'UG'), isTrue);
    });

    test('country can come before the field (TZtitle, KE_cta) and in any letter case', () {
      final r = HouseAds.parse([
        _ad(extra: {'TZtitle': 'Habari', 'KE_cta': 'Go', 'ctaug': 'Fungua', 'Title-RW': 'Muraho'})
      ]);
      expect(r.ok, isTrue, reason: r.errors.join('\n'));
      final a = r.ads.single;
      expect(a.forCountry('TZ').title, 'Habari');
      expect(a.forCountry('KE').cta, 'Go');
      expect(a.forCountry('UG').cta, 'Fungua');
      expect(a.forCountry('RW').title, 'Muraho');
    });

    test('overrides follow the same rules as the plain fields', () {
      expect(HouseAds.parse([_ad(extra: {'title_TZ': 'x' * 61})]).ok, isFalse);
      expect(HouseAds.parse([_ad(extra: {'body_TZ': 'x' * 141})]).ok, isFalse);
      expect(HouseAds.parse([_ad(extra: {'cta_TZ': 'x' * 25})]).ok, isFalse);
      expect(HouseAds.parse([_ad(extra: {'title_TZ': 5})]).ok, isFalse);
      for (final bad in ['http://example.com/a', 'javascript:alert(1)', 'example.com']) {
        expect(HouseAds.parse([_ad(extra: {'url_TZ': bad})]).ok, isFalse, reason: bad);
        expect(HouseAds.parse([_ad(extra: {'imageUrl_KE': bad})]).ok, isFalse, reason: bad);
      }
    });

    test('a blank override means "use the plain field"', () {
      final r = HouseAds.parse([_ad(extra: {'title_TZ': '  ', 'cta_TZ': ''})]);
      expect(r.ok, isTrue);
      expect(r.ads.single.local, isEmpty);
    });

    test('a misspelt country key is reported, not silently ignored', () {
      final r = HouseAds.parse([_ad(extra: {'title_TZZ': 'x'})]);
      expect(r.ok, isFalse);
      expect(r.errors.single, contains('title_TZZ'));
      expect(HouseAds.parse([_ad(extra: {'cta_': 'x'})]).ok, isFalse);
    });

    test('the same field for the same country twice is reported', () {
      final r = HouseAds.parse([_ad(extra: {'title_TZ': 'a', 'TZtitle': 'b'})]);
      expect(r.ok, isFalse);
      expect(r.errors.join(), contains('written twice'));
    });

    test('ordinary keys are never mistaken for country keys', () {
      final r = HouseAds.parse([
        _ad(extra: {'body': 'b', 'cta': 'c', 'pages': ['home'], 'platforms': ['ios'], 'weight': 2, 'enabled': true, 'countries': ['TZ']})
      ]);
      expect(r.ok, isTrue, reason: r.errors.join('\n'));
      expect(r.ads.single.local, isEmpty);
    });

    test('toText then parseText keeps countries, country text and reward seconds', () {
      final ads = HouseAds.parse([
        localised({'countries': ['TZ', 'KE'], 'formats': ['banner', 'rewarded'], 'rewardSeconds': 8})
      ]).ads;
      final text = HouseAds.toText(ads);
      expect(text, contains('"title_TZ"'));
      expect(text, contains('"countries"'));
      final back = HouseAds.parseText(text);
      expect(back.ok, isTrue, reason: back.errors.join('\n'));
      expect(back.ads.single.toJson(), ads.single.toJson());
      expect(back.ads.single.local, ads.single.local);
      expect(back.ads.single.rewardSeconds, 8);
    });

    test('they survive the ads config round trip', () {
      final house = HouseAds.parse([localised({'countries': ['TZ', 'KE']})]).ads;
      final c = AdsConfig(house: house);
      final back = AdsConfig.tryParse(c.toJson())!;
      expect(back.house.single.countries, {'TZ', 'KE'});
      expect(back.house.single.forCountry('TZ').cta, 'Weka oda');
      expect(back.sameAs(c), isTrue);
    });

    test('the built-in example uses countries and country text and is valid', () {
      final r = HouseAds.parseText(HouseAds.example);
      expect(r.ok, isTrue, reason: r.errors.join('\n'));
      expect(r.ads.first.countries, {'TZ', 'KE'});
      expect(r.ads.first.forCountry('TZ').title, isNot(r.ads.first.title));
      expect(r.ads.any((a) => a.formats.contains(AdFormat.rewarded)), isTrue);
    });
  });

  group('matching and picking', () {
    final now = DateTime.utc(2026, 11, 15);

    test('dates, enabled, page, format and platform all count', () {
      final a = HouseAds.parse([
        _ad(extra: {'pages': ['home'], 'formats': ['banner'], 'platforms': ['android'], 'start': '2026-11-01T00:00:00Z', 'end': '2026-11-30T00:00:00Z'})
      ]).ads.single;
      expect(a.matches(AdPage.home, AdFormat.banner, AdPlatform.android, now), isTrue);
      expect(a.matches(AdPage.search, AdFormat.banner, AdPlatform.android, now), isFalse);
      expect(a.matches(AdPage.home, AdFormat.native, AdPlatform.android, now), isFalse);
      expect(a.matches(AdPage.home, AdFormat.banner, AdPlatform.ios, now), isFalse);
      expect(a.matches(AdPage.home, AdFormat.banner, AdPlatform.android, DateTime.utc(2026, 10, 31)), isFalse);
      expect(a.matches(AdPage.home, AdFormat.banner, AdPlatform.android, DateTime.utc(2026, 12, 1)), isFalse);
      final off = HouseAds.parse([_ad(extra: {'enabled': false})]).ads.single;
      expect(off.matches(AdPage.home, AdFormat.banner, AdPlatform.android, now), isFalse);
    });

    test('pick follows the weights', () {
      final light = HouseAds.parse([_ad(id: 'light')]).ads.single;
      final heavy = HouseAds.parse([_ad(id: 'heavy', extra: {'weight': 9})]).ads.single;
      final rnd = Random(7);
      var heavyCount = 0;
      for (var i = 0; i < 2000; i++) {
        if (HouseAds.pick([light, heavy], rnd)!.id == 'heavy') heavyCount++;
      }
      expect(heavyCount, inInclusiveRange(1650, 1950)); // about 90%
      expect(HouseAds.pick([]), isNull);
    });
  });

  group('in the ads config', () {
    final house = HouseAds.parse([_ad(extra: {'pages': ['home'], 'formats': ['banner']})]).ads;

    test('it is part of the settings and survives toJson / tryParse', () {
      final c = AdsConfig(house: house);
      final back = AdsConfig.tryParse(c.toJson())!;
      expect(back.house.single.id, 'a1');
      expect(back.sameAs(c), isTrue);
      expect(const AdsConfig().sameAs(c), isFalse);
    });

    test('INHOUSE is understood in any spelling', () {
      for (final s in ['INHOUSE', 'in-house', 'house', 'In House Ads', 'own']) {
        expect(AdProvider.tryParse(s), AdProvider.inhouse, reason: s);
      }
    });

    test('it joins the chain only where an ad fits', () {
      final c = AdsConfig(defaultProvider: AdProvider.inhouse, autoFallback: false, house: house);
      expect(c.chain(AdPage.home, AdFormat.banner, AdPlatform.android), [AdProvider.inhouse]);
      expect(c.chain(AdPage.home, AdFormat.native, AdPlatform.android), isEmpty); // banner only
      expect(c.chain(AdPage.chats, AdFormat.banner, AdPlatform.android), isEmpty); // home only
      expect(c.chain(AdPage.videoReward, AdFormat.rewarded, AdPlatform.android), isEmpty);
    });

    test('with fallback it is the last resort after the networks', () {
      final c = AdsConfig(
        testMode: true, // AdMob test units exist
        house: house,
      );
      final chain = c.chain(AdPage.home, AdFormat.banner, AdPlatform.android);
      expect(chain.first, AdProvider.admob);
      expect(chain.last, AdProvider.inhouse);
      final noFallback = AdsConfig(testMode: true, autoFallback: false, house: house);
      expect(noFallback.chain(AdPage.home, AdFormat.banner, AdPlatform.android), [AdProvider.admob]);
    });

    test('a page can choose in-house ads; switching the page off still wins', () {
      final c = AdsConfig(
        testMode: true,
        house: house,
        pages: {AdPage.home: const AdPageSetting(provider: AdProvider.inhouse)},
      );
      expect(c.chain(AdPage.home, AdFormat.banner, AdPlatform.android).first, AdProvider.inhouse);
      final off = c.copyWith(pages: {AdPage.home: const AdPageSetting(enabled: false, provider: AdProvider.inhouse)});
      expect(off.chain(AdPage.home, AdFormat.banner, AdPlatform.android), isEmpty);
      expect(c.copyWith(enabled: false).chain(AdPage.home, AdFormat.banner, AdPlatform.android), isEmpty);
    });

    test('an expired ad is not in the chain', () {
      final expired = HouseAds.parse([_ad(extra: {'end': '2020-01-01T00:00:00Z'})]).ads;
      final c = AdsConfig(defaultProvider: AdProvider.inhouse, autoFallback: false, house: expired);
      expect(c.chain(AdPage.home, AdFormat.banner, AdPlatform.android), isEmpty);
    });

    test('looksLikeConfig rejects unrelated answers', () {
      expect(AdsConfig.looksLikeConfig({}), isFalse);
      expect(AdsConfig.looksLikeConfig({'message': 'error'}), isFalse);
      expect(AdsConfig.looksLikeConfig('x'), isFalse);
      expect(AdsConfig.looksLikeConfig({'data': {'enabled': true}}), isTrue);
      expect(AdsConfig.looksLikeConfig(const AdsConfig().toJson()), isTrue);
    });
  });

  group('show ads from: all / one network / off', () {
    // Every network has IDs (AdMob via test mode) and there is one in-house ad.
    final house = HouseAds.parse([_ad()]).ads;
    final ids = {
      for (final p in AdProvider.networks)
        p: {for (final pl in AdPlatform.values) pl: const AdUnitIds(appKey: 'abcde12345', banner: '', native: '')}
    };
    AdsConfig cfg({AdProvider def = AdProvider.all, bool fallback = true, bool enabled = true}) =>
        AdsConfig(testMode: true, enabled: enabled, defaultProvider: def, autoFallback: fallback, house: house, units: ids);

    test('ALL is understood in a few spellings and is not a real network', () {
      for (final s in ['ALL', 'all', 'All networks', 'mixed', 'mix']) {
        expect(AdProvider.tryParse(s), AdProvider.all, reason: s);
      }
      expect(AdProvider.networks, isNot(contains(AdProvider.all)));
      expect(AdProvider.concrete, isNot(contains(AdProvider.all)));
    });

    test('ALL lists only real networks, each once, and never ALL itself', () {
      final c = cfg(fallback: false);
      final chain = c.chain(AdPage.home, AdFormat.banner, AdPlatform.android, random: Random(1));
      expect(chain, isNot(contains(AdProvider.all)));
      expect(chain.toSet().length, chain.length);
      expect(chain, contains(AdProvider.admob)); // test mode: AdMob always has a unit
      expect(chain, contains(AdProvider.inhouse));
    });

    test('ALL starts with a different network from spot to spot', () {
      final c = cfg(fallback: false);
      final firsts = <AdProvider>{};
      final rnd = Random(3);
      for (var i = 0; i < 60; i++) {
        firsts.add(c.chain(AdPage.home, AdFormat.banner, AdPlatform.android, random: rnd).first);
      }
      expect(firsts.length, greaterThan(1));
    });

    test('ALL skips networks that cannot serve that spot', () {
      final c = AdsConfig(defaultProvider: AdProvider.all, autoFallback: false, house: house); // test mode, no IDs
      for (var i = 0; i < 20; i++) {
        final chain = c.chain(AdPage.home, AdFormat.banner, AdPlatform.android, random: Random(i));
        expect(chain.toSet(), {AdProvider.admob, AdProvider.inhouse}); // facebook / ironSource have no IDs
      }
    });

    test('one chosen network stays first; a page can override ALL', () {
      final c = cfg(def: AdProvider.admob).copyWith(pages: {AdPage.search: const AdPageSetting(provider: AdProvider.all)});
      expect(c.chain(AdPage.home, AdFormat.banner, AdPlatform.android).first, AdProvider.admob);
      final off = cfg(def: AdProvider.inhouse, fallback: false);
      expect(off.chain(AdPage.home, AdFormat.banner, AdPlatform.android), [AdProvider.inhouse]);
    });

    test('Off: the master switch and a page switch give nothing, whatever the choice', () {
      expect(cfg(enabled: false).chain(AdPage.home, AdFormat.banner, AdPlatform.android), isEmpty);
      final pageOff = cfg().copyWith(pages: {AdPage.home: const AdPageSetting(enabled: false, provider: AdProvider.all)});
      expect(pageOff.chain(AdPage.home, AdFormat.banner, AdPlatform.android), isEmpty);
    });

    test('ALL survives toJson / tryParse, for the default and for a page', () {
      final c = cfg().copyWith(pages: {AdPage.chats: const AdPageSetting(provider: AdProvider.all)});
      final back = AdsConfig.tryParse(c.toJson())!;
      expect(back.defaultProvider, AdProvider.all);
      expect(back.page(AdPage.chats).provider, AdProvider.all);
      expect(back.sameAs(c), isTrue);
    });

    test('canShow tells whether a choice can show anything on a platform', () {
      expect(const AdsConfig(testMode: false).canShow(AdProvider.all, AdPlatform.android), isFalse);
      expect(const AdsConfig(testMode: true).canShow(AdProvider.all, AdPlatform.android), isTrue); // AdMob test units
      expect(AdsConfig(testMode: false, house: house).canShow(AdProvider.all, AdPlatform.ios), isTrue);
      expect(const AdsConfig(testMode: false).canShow(AdProvider.inhouse, AdPlatform.ios), isFalse);
    });

    test('an in-house ad for one platform only counts for that platform', () {
      final ios = HouseAds.parse([_ad(extra: {'platforms': ['ios']})]).ads;
      final c = AdsConfig(testMode: false, house: ios);
      expect(c.canShow(AdProvider.inhouse, AdPlatform.ios), isTrue);
      expect(c.canShow(AdProvider.inhouse, AdPlatform.android), isFalse);
    });
  });
}
