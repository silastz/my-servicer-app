import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ungana/services/money_input.dart';

TextEditingValue _type(String text, {int? cursor, int maxDigits = 9}) =>
    MoneyInputFormatter(maxDigits: maxDigits).formatEditUpdate(
      TextEditingValue.empty,
      TextEditingValue(text: text, selection: TextSelection.collapsed(offset: cursor ?? text.length)),
    );

void main() {
  test('groups digits as you type', () {
    expect(_type('2000').text, '2,000');
    expect(_type('1234567').text, '1,234,567');
    expect(_type('999').text, '999');
  });

  test('drops non digits and leading zeros', () {
    expect(_type('2,0a00').text, '2,000');
    expect(_type('007').text, '7');
    expect(_type('').text, '');
  });

  test('limits digits, not commas', () {
    expect(_type('123456789012', maxDigits: 8).text, '12,345,678');
  });

  test('cursor stays after the same digit', () {
    // "2,000" typed a 5 after the 2 -> "25,000": cursor after "25"
    final v = _type('25,000', cursor: 2);
    expect(v.text, '25,000');
    expect(v.selection.baseOffset, 2);
  });

  test('parse and text round trip', () {
    expect(MoneyInput.parse('2,000'), 2000);
    expect(MoneyInput.parse(''), isNull);
    expect(MoneyInput.text(50000), '50,000');
    expect(MoneyInput.text(0), '');
  });
}
