import 'package:flutter_test/flutter_test.dart';
import 'package:ungana/services/app_policy.dart';
import 'package:ungana/services/pending_otp.dart';

void main() {
  group('pending code window', () {
    final sent = DateTime(2026, 10, 24, 21, 0, 0);
    const four = Duration(minutes: 4);

    test('fresh inside the window, stale at and after it', () {
      expect(PendingOtpStore.isFresh(sent, sent.add(const Duration(seconds: 1)), four), isTrue);
      expect(PendingOtpStore.isFresh(sent, sent.add(const Duration(minutes: 3, seconds: 59)), four), isTrue);
      expect(PendingOtpStore.isFresh(sent, sent.add(four), four), isFalse);
      expect(PendingOtpStore.isFresh(sent, sent.add(const Duration(minutes: 9)), four), isFalse);
    });

    test('a clock set back counts as stale', () {
      expect(PendingOtpStore.isFresh(sent, sent.subtract(const Duration(minutes: 1)), four), isFalse);
    });

    test('window follows the admin value, default 4', () {
      AppPolicy.otpPendingMinutes = null;
      expect(PendingOtpStore.window, const Duration(minutes: 4));
      AppPolicy.otpPendingMinutes = 7;
      expect(PendingOtpStore.window, const Duration(minutes: 7));
      AppPolicy.otpPendingMinutes = null;
    });
  });

  group('same contact', () {
    test('phone written in different ways matches', () {
      expect(PendingOtpStore.sameContact('+255712345678', '0712345678'), isTrue);
      expect(PendingOtpStore.sameContact('+255 712 345 678', '255712345678'), isTrue);
      expect(PendingOtpStore.sameContact('+255712345678', '+255712345679'), isFalse);
    });

    test('email ignores case and spaces; never matches a phone', () {
      expect(PendingOtpStore.sameContact('Ann@Mail.com', ' ann@mail.com '), isTrue);
      expect(PendingOtpStore.sameContact('ann@mail.com', 'bob@mail.com'), isFalse);
      expect(PendingOtpStore.sameContact('ann@mail.com', '+255712345678'), isFalse);
    });

    test('empty or too short never matches', () {
      expect(PendingOtpStore.sameContact('', ''), isFalse);
      expect(PendingOtpStore.sameContact('+255', '+255'), isFalse);
    });
  });

  group('saved record', () {
    test('sign-up record round-trips with its form', () {
      final p = PendingOtp(
        kind: PendingOtpKind.signup,
        contact: '+255712345678',
        sentAt: DateTime.fromMillisecondsSinceEpoch(1700000000000),
        form: {'phone': '+255712345678', 'challenge': 'c', 'password': 'pw12', 'stageName': 'Ann', 'role': 'ROLE_BUYER'},
      );
      final back = PendingOtp.tryParse(p.toJson())!;
      expect(back.kind, PendingOtpKind.signup);
      expect(back.contact, '+255712345678');
      expect(back.sentAt, p.sentAt);
      expect(back.form!['challenge'], 'c');
    });

    test('a sign-up record without its form, or garbage, is rejected', () {
      expect(PendingOtp.tryParse({'kind': 'signup', 'contact': '+255712345678', 'sentAt': 1}), isNull);
      expect(PendingOtp.tryParse({'kind': 'nope', 'contact': 'a', 'sentAt': 1}), isNull);
      expect(PendingOtp.tryParse({'kind': 'reset', 'contact': '', 'sentAt': 1}), isNull);
      expect(PendingOtp.tryParse('x'), isNull);
    });

    test('reset record needs no form', () {
      final r = PendingOtp.tryParse({'kind': 'reset', 'contact': 'ann@mail.com', 'sentAt': 5});
      expect(r!.kind, PendingOtpKind.reset);
      expect(r.form, isNull);
    });
  });

  group('admin policy value', () {
    test('otpPendingMinutes is read from data.auth and kept only inside 1-10', () {
      expect(AppPolicy.sanitize({'data': {'auth': {'otpPendingMinutes': 6}}})!['otpPendingMinutes'], 6);
      expect(AppPolicy.sanitize({'auth': {'otpPendingMinutes': 1}})!['otpPendingMinutes'], 1);
      expect(AppPolicy.sanitize({'auth': {'otpPendingMinutes': 10}})!['otpPendingMinutes'], 10);
      expect(AppPolicy.sanitize({'auth': {'otpPendingMinutes': 0}})!.containsKey('otpPendingMinutes'), isFalse);
      expect(AppPolicy.sanitize({'auth': {'otpPendingMinutes': 11}})!.containsKey('otpPendingMinutes'), isFalse);
      expect(AppPolicy.sanitize({'fees': {}})!.containsKey('otpPendingMinutes'), isFalse); // -> default (4)
    });

    test('missing value means 4', () {
      AppPolicy.apply({}); // also saves; fine in tests with no prefs
      expect(AppPolicy.otpPendingMinutesEffective, 4);
    });
  });
}
