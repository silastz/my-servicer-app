import 'package:flutter_test/flutter_test.dart';
import 'package:ungana/models/sms_gateway.dart';

void main() {
  group('SmsProvider', () {
    test('parses the ways the server may write it', () {
      expect(SmsProvider.tryParse('MESEJI'), SmsProvider.meseji);
      expect(SmsProvider.tryParse('meseji'), SmsProvider.meseji);
      expect(SmsProvider.tryParse('beem'), SmsProvider.beem);
      expect(SmsProvider.tryParse('Beem Africa'), SmsProvider.beem);
      expect(SmsProvider.tryParse('beem_africa'), SmsProvider.beem);
    });

    test('unknown values are null and the default is Meseji', () {
      expect(SmsProvider.tryParse('twilio'), isNull);
      expect(SmsProvider.tryParse(null), isNull);
      expect(SmsProvider.defaultProvider, SmsProvider.meseji);
    });
  });

  group('SmsGatewayConfig', () {
    test('reads the server shape and never needs secrets', () {
      final c = SmsGatewayConfig.tryParse({
        'defaultProvider': 'BEEM',
        'meseji': {'apiKeySet': true, 'passwordSet': false, 'senderId': 'UNGANA', 'email': 'a@b.co', 'costPerSms': 20},
        'beem': {'apiKeySet': true, 'secretSet': true, 'senderId': 'INFO', 'costPerSms': '12.5'},
      })!;
      expect(c.defaultProvider, SmsProvider.beem);
      expect(c.meseji.senderId, 'UNGANA');
      expect(c.meseji.costPerSms, 20);
      expect(c.beem.costPerSms, 12.5);
      expect(c.defaultIsReady, isTrue);
    });

    test('accepts a {data: ...} wrapper and falls back to defaults', () {
      final c = SmsGatewayConfig.tryParse({'data': {'defaultProvider': 'nope'}})!;
      expect(c.defaultProvider, SmsProvider.meseji);
      expect(c.beem.senderId, 'INFO');
      expect(c.defaultIsReady, isFalse);
    });

    test('failover is on unless the server says false, and needs a ready backup', () {
      expect(SmsGatewayConfig.tryParse({'defaultProvider': 'MESEJI'})!.autoFailover, isTrue);
      expect(SmsGatewayConfig.tryParse({'autoFailover': false})!.autoFailover, isFalse);
      final ready = SmsGatewayConfig.tryParse({
        'defaultProvider': 'MESEJI',
        'beem': {'apiKeySet': true, 'secretSet': true, 'senderId': 'INFO'},
      })!;
      expect(ready.backupProvider, SmsProvider.beem);
      expect(ready.failoverReady, isTrue);
      expect(SmsGatewayConfig.tryParse({'defaultProvider': 'MESEJI'})!.failoverReady, isFalse);
      expect(SmsGatewayConfig.tryParse({'autoFailover': false, 'beem': {'apiKeySet': true, 'secretSet': true}})!.failoverReady, isFalse);
    });

    test('not an object is null', () {
      expect(SmsGatewayConfig.tryParse('x'), isNull);
      expect(SmsGatewayConfig.tryParse(null), isNull);
    });

    test('a provider is only ready with all its credentials', () {
      expect(const MesejiSmsConfig(apiKeySet: true, senderId: 'X').isComplete, isTrue);
      expect(const MesejiSmsConfig(apiKeySet: true).isComplete, isFalse);
      expect(const BeemSmsConfig(apiKeySet: true, secretSet: false).isComplete, isFalse);
      expect(const BeemSmsConfig(apiKeySet: true, secretSet: true).isComplete, isTrue);
    });
  });

  group('SmsGatewayUpdate', () {
    test('blank secrets are left out so the saved ones are kept', () {
      final j = const SmsGatewayUpdate(
        defaultProvider: SmsProvider.beem,
        mesejiSenderId: ' UNGANA ',
        beemSenderId: 'INFO',
      ).toJson();
      expect(j['defaultProvider'], 'BEEM');
      expect((j['meseji'] as Map).containsKey('apiKey'), isFalse);
      expect((j['meseji'] as Map).containsKey('password'), isFalse);
      expect((j['beem'] as Map).containsKey('apiKey'), isFalse);
      expect((j['beem'] as Map).containsKey('secretKey'), isFalse);
      expect((j['meseji'] as Map)['senderId'], 'UNGANA');
      expect(j['autoFailover'], isTrue);
      expect(const SmsGatewayUpdate(defaultProvider: SmsProvider.meseji, autoFailover: false).toJson()['autoFailover'], isFalse);
    });

    test('a typed secret is sent, trimmed', () {
      final j = const SmsGatewayUpdate(
        defaultProvider: SmsProvider.meseji,
        mesejiApiKey: ' key123 ',
        beemSecretKey: 'sec',
      ).toJson();
      expect((j['meseji'] as Map)['apiKey'], 'key123');
      expect((j['beem'] as Map)['secretKey'], 'sec');
    });
  });

  group('SmsGatewayRules', () {
    test('Beem sender id: up to 11 letters, numbers, spaces', () {
      expect(SmsGatewayRules.beemSender('INFO'), isNull);
      expect(SmsGatewayRules.beemSender('ISHIMAX LTD'), isNull);
      expect(SmsGatewayRules.beemSender(''), 'empty');
      expect(SmsGatewayRules.beemSender('TWELVE CHARS'), 'shape');
      expect(SmsGatewayRules.beemSender('Bad!'), 'shape');
    });

    test('Meseji sender id may be a name or a phone number', () {
      expect(SmsGatewayRules.mesejiSender('UNGANA'), isNull);
      expect(SmsGatewayRules.mesejiSender('+255712345678'), isNull);
      expect(SmsGatewayRules.mesejiSender('  '), 'empty');
      expect(SmsGatewayRules.mesejiSender('a<b>'), 'shape');
    });

    test('cost per SMS', () {
      expect(SmsGatewayRules.parseCost('15'), 15);
      expect(SmsGatewayRules.parseCost('15,5'), 15.5);
      expect(SmsGatewayRules.parseCost('0'), 0);
      expect(SmsGatewayRules.parseCost('-1'), isNull);
      expect(SmsGatewayRules.parseCost('abc'), isNull);
      expect(SmsGatewayRules.parseCost('999999999'), isNull);
    });
  });
}
