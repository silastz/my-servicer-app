import 'package:flutter_test/flutter_test.dart';
import 'package:ungana/services/app_log.dart';

void main() {
  setUp(AppLog.resetForTest);

  test('a handled error is remembered by place and type, never by its message', () {
    AppLog.e('Chat.send', const FormatException('+255712345678 secret'));
    expect(AppLog.recent, ['Chat.send: FormatException']);
    expect(AppLog.recent.single.contains('255'), false);
  });

  test('only the latest errors are kept', () {
    for (var i = 0; i < AppLog.maxRecent + 10; i++) {
      AppLog.e('Spot$i', StateError('x'));
    }
    expect(AppLog.recent.length, AppLog.maxRecent);
    expect(AppLog.recent.first, 'Spot10: StateError');
    expect(AppLog.recent.last, 'Spot${AppLog.maxRecent + 9}: StateError');
  });

  test('the error reaches the crash-reporter hook, and a broken hook does not break the app', () {
    final seen = <String>[];
    AppLog.onError = (where, error, stack) => seen.add('$where/${error.runtimeType}');
    AppLog.e('Pay.start', ArgumentError('bad'));
    expect(seen, ['Pay.start/ArgumentError']);

    AppLog.onError = (where, error, stack) => throw StateError('reporter down');
    expect(() => AppLog.e('Pay.start', ArgumentError('bad')), returnsNormally);
  });
}
