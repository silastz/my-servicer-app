import 'package:flutter_test/flutter_test.dart';
import 'package:ungana/models/customer_needs.dart';

// A Wednesday at noon: no weekday/evening context boost, so scores are exact.
final DateTime _now = DateTime(2026, 10, 21, 12);

NeedEvent _e(NeedSignalType t, String cat, {double daysAgo = 0, String? text, bool urgent = false}) =>
    NeedEvent(
      type: t,
      category: cat,
      at: _now.subtract(Duration(minutes: (daysAgo * 1440).round())),
      text: text,
      urgent: urgent,
    );

void main() {
  group('reading words', () {
    test('English and Swahili phrases map to the right service', () {
      expect(NeedEngine.bestCategory('bomba linavuja'), 'Plumbing');
      expect(NeedEngine.bestCategory('my fridge is broken'), 'Repair');
      expect(NeedEngine.bestCategory('haircut'), 'Barber');
      expect(NeedEngine.bestCategory('bridal makeup'), 'Beauty');
      expect(NeedEngine.bestCategory('wedding photographer'), 'Photography');
      expect(NeedEngine.bestCategory('hakuna umeme'), 'Electrical');
    });

    test('unclear words give no guess', () {
      expect(NeedEngine.bestCategory('hello there'), isNull);
      expect(NeedEngine.bestCategory(''), isNull);
    });

    test('short words only match whole words', () {
      expect(NeedEngine.classify('tape measure').containsKey('Plumbing'), isFalse);
      expect(NeedEngine.classify('my tap is dripping')['Plumbing'], isNotNull);
    });

    test('urgent wording is detected', () {
      expect(NeedEngine.isUrgent('emergency pipe leak'), isTrue);
      expect(NeedEngine.isUrgent('nahitaji fundi haraka'), isTrue);
      expect(NeedEngine.isUrgent('pipe leak'), isFalse);
    });
  });

  group('predicting needs', () {
    test('no history, no guess', () {
      expect(NeedEngine.predict(const [], now: _now), isEmpty);
    });

    test('one fresh search is enough to suggest that service', () {
      final p = NeedEngine.predict(
        [_e(NeedSignalType.search, 'Plumbing', text: 'bomba linavuja')],
        now: _now,
      );
      expect(p.single.category, 'Plumbing');
      expect(p.single.topReason, NeedReason.searched);
      expect(p.single.evidence, 'bomba linavuja');
    });

    test('a casual view alone is not enough, two views are', () {
      expect(NeedEngine.predict([_e(NeedSignalType.serviceView, 'Barber', daysAgo: 6)], now: _now), isEmpty);
      final p = NeedEngine.predict([
        _e(NeedSignalType.serviceView, 'Barber', daysAgo: 1),
        _e(NeedSignalType.serviceView, 'Barber', daysAgo: 2),
      ], now: _now);
      expect(p.single.category, 'Barber');
      expect(p.single.topReason, NeedReason.browsed);
    });

    test('recent thinking beats old thinking', () {
      final p = NeedEngine.predict([
        _e(NeedSignalType.search, 'Plumbing', daysAgo: 40),
        _e(NeedSignalType.search, 'Barber', daysAgo: 0),
      ], now: _now);
      expect(p.map((e) => e.category), ['Barber']); // the 40-day-old search faded away
    });

    test('a finished booking consumes the earlier interest', () {
      final p = NeedEngine.predict([
        _e(NeedSignalType.search, 'Barber', daysAgo: 5),
        _e(NeedSignalType.booking, 'Barber', daysAgo: 4),
      ], now: _now);
      expect(p.where((e) => e.category == 'Barber'), isEmpty);
    });

    test('a new search after the booking counts in full', () {
      final p = NeedEngine.predict([
        _e(NeedSignalType.booking, 'Barber', daysAgo: 4),
        _e(NeedSignalType.search, 'Barber', daysAgo: 0),
      ], now: _now);
      expect(p.first.category, 'Barber');
    });

    test('repeat services come back after their usual gap', () {
      final p = NeedEngine.predict([_e(NeedSignalType.booking, 'Barber', daysAgo: 16)], now: _now);
      expect(p.first.category, 'Barber');
      expect(p.first.topReason, NeedReason.dueAgain);
      expect(p.first.daysSinceBooking, 16);
    });

    test('one-off services are not "due again"', () {
      final p = NeedEngine.predict([_e(NeedSignalType.booking, 'Plumbing', daysAgo: 60)], now: _now);
      expect(p.where((e) => e.category == 'Plumbing'), isEmpty);
    });

    test('a booking nudges related services', () {
      final p = NeedEngine.predict([_e(NeedSignalType.booking, 'Photography')], now: _now);
      final cats = p.map((e) => e.category).toSet();
      expect(cats, containsAll(['Beauty', 'Barber']));
      expect(p.first.topReason, NeedReason.related);
    });

    test('urgent wording lifts the need and flags it', () {
      final p = NeedEngine.predict([
        _e(NeedSignalType.search, 'Plumbing', text: 'emergency pipe leak', urgent: true),
      ], now: _now);
      expect(p.single.urgent, isTrue);
      expect(p.single.topReason, NeedReason.urgent);
    });

    test('results are ranked and limited', () {
      final p = NeedEngine.predict([
        _e(NeedSignalType.search, 'Plumbing'),
        _e(NeedSignalType.search, 'Electrical'),
        _e(NeedSignalType.search, 'Electrical', daysAgo: 1),
        _e(NeedSignalType.favorite, 'Cleaning'),
      ], now: _now, limit: 2);
      expect(p.length, 2);
      expect(p.first.category, 'Electrical');
      expect(p.first.score, greaterThanOrEqualTo(p.last.score));
    });

    test('events from the future are ignored', () {
      final p = NeedEngine.predict([_e(NeedSignalType.search, 'Plumbing', daysAgo: -3)], now: _now);
      expect(p, isEmpty);
    });
  });

  group('saved events', () {
    test('round trip', () {
      final e = _e(NeedSignalType.search, 'Beauty', text: 'nails', urgent: true);
      final back = NeedEvent.fromJson(e.toJson())!;
      expect(back.type, e.type);
      expect(back.category, 'Beauty');
      expect(back.text, 'nails');
      expect(back.urgent, isTrue);
      expect(back.at, e.at);
    });

    test('bad data is skipped, not thrown', () {
      expect(NeedEvent.fromJson(null), isNull);
      expect(NeedEvent.fromJson({'t': 99, 'c': 'x', 'a': 1}), isNull);
      expect(NeedEvent.fromJson({'t': 0, 'c': '', 'a': 1}), isNull);
    });
  });
}
