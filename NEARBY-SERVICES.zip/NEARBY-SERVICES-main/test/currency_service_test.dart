import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:ungana/services/currency_service.dart';

void main() {
  Currency cur(String iso) => CurrencyService.supported[iso]!;

  test('formats whole amounts with the country symbol', () {
    expect(CurrencyService.format(50000, currency: cur('TZ')), 'TSh 50,000');
    expect(CurrencyService.format(1250000, currency: cur('KE')), 'KSh 1,250,000');
    expect(CurrencyService.format(999, currency: cur('UG')), 'USh 999');
    expect(CurrencyService.format(0, currency: cur('RW')), 'FRw 0');
  });

  test('every supported country has its own currency code', () {
    final codes = CurrencyService.supported.values.map((c) => c.code).toSet();
    expect(codes, {'TZS', 'KES', 'UGX', 'RWF', 'BIF', 'CDF'});
  });

  test('unknown countries fall back to Tanzania', () {
    expect(CurrencyService.fromCountry('ZZ').code, 'TZS');
    expect(CurrencyService.fromCountry(null).code, 'TZS');
    expect(CurrencyService.fromCountry('ke').code, 'KES');
  });

  test('phone numbers: international forms work in any country', () {
    expect(CurrencyService.normalizePhone('+254 712 345 678'), '254712345678');
    expect(CurrencyService.normalizePhone('255712345678'), '255712345678');
    expect(CurrencyService.normalizePhone('+256 772 123 456'), '256772123456');
    expect(CurrencyService.normalizePhone('+250 788 123 456'), '250788123456');
    expect(CurrencyService.normalizePhone('+257 79 123 456'), '25779123456');
  });

  test('phone numbers: local forms use the current country (Tanzania by default)', () {
    expect(CurrencyService.normalizePhone('0712345678'), '255712345678');
    expect(CurrencyService.normalizePhone('712345678'), '255712345678');
    expect(CurrencyService.normalizePhone('0512345678'), isNull); // not a mobile prefix
    expect(CurrencyService.normalizePhone('12345'), isNull);
    expect(CurrencyService.normalizePhone(''), isNull);
  });

  test('masking keeps the country code and hides the middle', () {
    expect(CurrencyService.maskPhone('255712345678'), '+255 71• •••• 678');
    expect(CurrencyService.maskPhone('254712345678'), '+254 71• •••• 678');
  });

  test('rounding step follows the currency', () {
    expect(CurrencyService.roundToStep(41234), 41200); // TSh default step 100
  });

  group('sign-up uses the selected country code', () {
    setUp(() {
      CurrencyService.clearSignupPick();
      CurrencyService.notifier.value = cur('TZ');
    });
    tearDown(() {
      CurrencyService.clearSignupPick();
      CurrencyService.notifier.value = cur('TZ');
    });

    test('currency follows the code of the number', () {
      CurrencyService.selectForSignup('+254712345678');
      expect(CurrencyService.code, 'KES');
      CurrencyService.selectForSignup('+256');
      expect(CurrencyService.code, 'UGX');
    });

    test('later IP detection cannot override the choice', () {
      CurrencyService.selectForSignup('+254712345678');
      CurrencyService.applyDetectedCountry('TZ');
      expect(CurrencyService.code, 'KES');
    });

    test('before any choice, detection still works', () {
      CurrencyService.applyDetectedCountry('RW');
      expect(CurrencyService.code, 'RWF');
    });

    test('an unsupported code changes nothing', () {
      CurrencyService.selectForSignup('+1415555');
      expect(CurrencyService.code, 'TZS');
      expect(CurrencyService.fromPhone('+44 7700'), isNull);
    });
  });

  group('Settings: country chosen by the person (signed out)', () {
    setUp(() {
      SharedPreferences.setMockInitialValues({});
      CurrencyService.clearSignupPick();
      CurrencyService.notifier.value = cur('TZ');
    });
    tearDown(() {
      CurrencyService.clearSignupPick();
      CurrencyService.notifier.value = cur('TZ');
    });

    test('the choice is applied, saved, and beats detection', () async {
      await CurrencyService.chooseManually('KE');
      expect(CurrencyService.code, 'KES');
      CurrencyService.applyDetectedCountry('TZ');
      expect(CurrencyService.code, 'KES');
      final prefs = await SharedPreferences.getInstance();
      expect(prefs.getString('account_currency_iso'), 'KE');
    });

    test('an unsupported country is ignored', () async {
      await CurrencyService.chooseManually('US');
      expect(CurrencyService.code, 'TZS');
    });

    test('the server can set the account currency by country or currency code', () async {
      await CurrencyService.setAccountCurrency('UGX');
      expect(CurrencyService.current.iso, 'UG');
      await CurrencyService.setAccountCurrency('RW');
      expect(CurrencyService.code, 'RWF');
    });
  });
}
