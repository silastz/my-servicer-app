import 'package:flutter_test/flutter_test.dart';
import 'package:ungana/models/identity_lookup.dart';

void main() {
  group('IdentityLookupConfig', () {
    test('reads the server shape and never needs the password', () {
      final c = IdentityLookupConfig.tryParse({
        'username': 'bob',
        'passwordSet': true,
        'source': 'admin',
        'updatedAt': '2026-10-24T08:30:00Z',
      })!;
      expect(c.username, 'bob');
      expect(c.passwordSet, true);
      expect(c.source, 'ADMIN');
      expect(c.updatedAt, isNotNull);
      expect(c.isComplete, true);
    });

    test('accepts a data wrapper and fills safe defaults', () {
      final c = IdentityLookupConfig.tryParse({'data': {'username': null, 'passwordSet': false}})!;
      expect(c.username, '');
      expect(c.source, 'NONE');
      expect(c.updatedAt, isNull);
      expect(c.isComplete, false);
    });

    test('needs both a username and a saved password to count as set up', () {
      expect(const IdentityLookupConfig(username: 'bob', passwordSet: false).isComplete, false);
      expect(const IdentityLookupConfig(username: ' ', passwordSet: true).isComplete, false);
    });

    test('anything that is not an object is null', () {
      expect(IdentityLookupConfig.tryParse('x'), isNull);
      expect(IdentityLookupConfig.tryParse(null), isNull);
    });
  });

  group('IdentityLookupRules', () {
    test('username', () {
      expect(IdentityLookupRules.username('bob.smith@x-y'), isNull);
      expect(IdentityLookupRules.username('  bob  '), isNull);
      expect(IdentityLookupRules.username(''), 'empty');
      expect(IdentityLookupRules.username('bob smith'), 'invalid');
      expect(IdentityLookupRules.username('a' * 101), 'invalid');
    });

    test('password: blank keeps the saved one, control characters are refused', () {
      expect(IdentityLookupRules.password(''), isNull);
      expect(IdentityLookupRules.password('has space 1'), isNull);
      expect(IdentityLookupRules.password('bad\npass'), 'invalid');
      expect(IdentityLookupRules.password('x' * 201), 'invalid');
    });
  });
}
