import 'package:flutter_test/flutter_test.dart';
import 'package:ungana/models/payment_gateway.dart';
import 'package:ungana/models/provider_fees.dart';
import 'package:ungana/services/app_policy.dart';
import 'package:ungana/services/app_policy_service.dart';

void main() {
  test('keeps valid values and drops invalid ones', () {
    final r = AppPolicy.sanitize({
      'data': {
        'fees': {'registrationFee': 15000, 'serviceFee': -5, 'freeServiceLimit': 3, 'topUpMin': 500, 'topUpMax': 100},
        'security': {'blockCompromisedDevice': false, 'playIntegrity': 'yes'},
      }
    })!;
    expect(r['registrationFee'], 15000);
    expect(r.containsKey('serviceFee'), false); // negative: ignored
    expect(r['freeServiceLimit'], 3);
    expect(r.containsKey('topUpMin'), false); // max < min: both ignored
    expect(r.containsKey('topUpMax'), false);
    expect(r['blockCompromisedDevice'], false);
    expect(r.containsKey('playIntegrity'), false); // not a bool
  });

  test('accepts a flat body and rejects non-objects', () {
    expect(AppPolicy.sanitize({'fees': {'serviceFee': 7000}})!['serviceFee'], 7000);
    expect(AppPolicy.sanitize('nope'), isNull);
    expect(AppPolicy.sanitize([]), isNull);
  });

  test('screen capture is allowed only when the admin says true', () {
    expect(AppPolicyService.parseScreenCapture({'data': {'security': {'screenCaptureAllowed': true}}}), true);
    expect(AppPolicyService.parseScreenCapture({'screenCaptureAllowed': false}), false);
    expect(AppPolicyService.parseScreenCapture({'data': {}}), isNull);
  });

  test('free service limit: admin can raise or lower it, nothing set means the default', () {
    expect(AppPolicy.sanitize({'fees': {'freeServiceLimit': 5}})!['freeServiceLimit'], 5);
    expect(AppPolicy.sanitize({'fees': {'freeServiceLimit': 1}})!['freeServiceLimit'], 1);
    expect(AppPolicy.sanitize({'fees': {'freeServiceLimit': 0}})!['freeServiceLimit'], 0);
    expect(AppPolicy.sanitize({'fees': {'freeServiceLimit': 101}})!.containsKey('freeServiceLimit'), false);
    expect(AppPolicy.sanitize({'fees': {'freeServiceLimit': -1}})!.containsKey('freeServiceLimit'), false);
    expect(AppPolicy.sanitize({'fees': {}})!.containsKey('freeServiceLimit'), false); // -> default (2)
  });

  test('block VPN is only on when the admin sends true', () {
    expect(AppPolicy.sanitize({'security': {'blockVpn': true}})!['blockVpn'], true);
    expect(AppPolicy.sanitize({'security': {'blockVpn': false}})!['blockVpn'], false);
    expect(AppPolicy.sanitize({'security': {}})!.containsKey('blockVpn'), false); // -> build default (off)
    expect(AppPolicy.sanitize({'security': {'blockVpn': 'true'}})!.containsKey('blockVpn'), false);
  });

  test('payment gateway: admin choice is kept, anything else means SNIPPE', () {
    expect(AppPolicy.sanitize({'payments': {'gateway': 'selcom'}})!['paymentGateway'], 'SELCOM');
    expect(AppPolicy.sanitize({'data': {'payments': {'gateway': 'Click Pesa'}}})!['paymentGateway'], 'CLICKPESA');
    expect(AppPolicy.sanitize({'payments': {'gateway': 'pesa_pal'}})!['paymentGateway'], 'PESAPAL');
    expect(AppPolicy.sanitize({'payments': {'gateway': 'DPO'}})!['paymentGateway'], 'DPO');
    expect(AppPolicy.sanitize({'payments': {'gateway': 'stripe'}})!.containsKey('paymentGateway'), false);
    expect(AppPolicy.sanitize({'payments': {'gateway': 5}})!.containsKey('paymentGateway'), false);
    expect(AppPolicy.sanitize({'fees': {}})!.containsKey('paymentGateway'), false);
    expect(PaymentGateway.defaultGateway, PaymentGateway.snippe);
  });

  test('provider fees: 3% collection on its own, plus 18% with the 1,500 payout fee inside', () {
    const f = ProviderFees(collectionPercent: 3, vatPercent: 18, payoutFee: 1500);
    expect(f.collectionFee(20000), 600);
    expect(f.chargeFee(20000), 3600);
    expect(f.payoutAmount(20000), 1500); // admin fee income
    expect(f.vatAmount(20000), 2100); // 3,600 - 1,500 -> admin wallet VAT
    expect(f.totalFee(20000), 4200);
    expect(f.net(20000), 15800); // 20,000 - 600 - 1,500 - 2,100
    expect(f.collectionFee(10000), 300);
    expect(f.chargeFee(10000), 1800);
    expect(f.vatAmount(10000), 300);
    expect(f.net(10000), 7900);
    expect(f.refund(10000), 8200); // a refund carries the charge only, no collection fee
  });

  test('provider fees: small amounts still cover the payout fee, never go negative', () {
    const f = ProviderFees(collectionPercent: 3, vatPercent: 18, payoutFee: 1500);
    expect(f.chargeFee(5000), 1500); // 18% = 900 < 1,500 -> charge is the payout fee, no VAT part
    expect(f.vatAmount(5000), 0);
    expect(f.collectionFee(5000), 150);
    expect(f.net(5000), 3350);
    expect(f.net(1000), 0);
    expect(f.refund(1000), 0);
    expect(f.covers(1500), false);
    expect(f.covers(f.smallestUsable), true);
    expect(f.covers(f.smallestUsable - 1), false);
  });

  test('provider fees: 18% charge alone (no collection fee) matches the old numbers', () {
    const f = ProviderFees(vatPercent: 18, payoutFee: 1500);
    expect(f.totalFee(10000), 1800);
    expect(f.net(10000), 8200);
  });

  test('provider fees: only some of the three set, or nothing', () {
    expect(const ProviderFees(payoutFee: 1500).totalFee(10000), 1500);
    expect(const ProviderFees(vatPercent: 18).totalFee(10000), 1800);
    expect(const ProviderFees(vatPercent: 18).vatAmount(10000), 1800);
    expect(const ProviderFees(collectionPercent: 3).totalFee(10000), 300);
    expect(const ProviderFees(collectionPercent: 3).vatAmount(10000), 0);
    expect(const ProviderFees().isZero, true);
    expect(const ProviderFees().totalFee(10000), 0);
  });

  test('withdrawal limits: admin sets from / to', () {
    final ok = AppPolicy.sanitize({'fees': {'provider': {'vatPercent': 18, 'withdrawMin': 2000, 'withdrawMax': 500000}}})!;
    expect(ok['providerFees'], {'collectionPercent': 0.0, 'vatPercent': 18.0, 'payoutFee': 0, 'withdrawMin': 2000, 'withdrawMax': 500000});
    // max below min: both limits ignored, fees kept
    final bad = AppPolicy.sanitize({'fees': {'provider': {'vatPercent': 18, 'withdrawMin': 5000, 'withdrawMax': 1000}}})!;
    expect(bad['providerFees'], {'collectionPercent': 0.0, 'vatPercent': 18.0, 'payoutFee': 0, 'withdrawMin': 0, 'withdrawMax': 0});
    // limits alone are enough to keep the object
    expect(AppPolicy.sanitize({'fees': {'provider': {'withdrawMax': 300000}}})!['providerFees'], isNotNull);
    expect(const ProviderFees(withdrawMin: 2000, withdrawMax: 9000).isZero, true); // limits are not fees
    expect(ProviderFees.tryParse({'withdrawMin': 50}), isNull); // below the 100 floor
  });

  test('provider fees: policy keeps valid admin values only', () {
    final ok = AppPolicy.sanitize({'fees': {'provider': {'collectionPercent': 3, 'vatPercent': 18, 'payoutFee': 1500}}})!;
    expect(ok['providerFees'], {'collectionPercent': 3.0, 'vatPercent': 18.0, 'payoutFee': 1500, 'withdrawMin': 0, 'withdrawMax': 0});
    expect(AppPolicy.sanitize({'fees': {'provider': {'vatPercent': 80, 'payoutFee': -1}}})!.containsKey('providerFees'), false);
    expect(AppPolicy.sanitize({'fees': {'provider': {'payoutFee': 1500}}})!['providerFees'], {'collectionPercent': 0.0, 'vatPercent': 0.0, 'payoutFee': 1500, 'withdrawMin': 0, 'withdrawMax': 0});
    expect(AppPolicy.sanitize({'fees': {'provider': {'collectionPercent': 3}}})!['providerFees'], {'collectionPercent': 3.0, 'vatPercent': 0.0, 'payoutFee': 0, 'withdrawMin': 0, 'withdrawMax': 0});
    expect(AppPolicy.sanitize({'fees': {'provider': {'collectionPercent': 90}}})!.containsKey('providerFees'), false);
    expect(AppPolicy.sanitize({'fees': {}})!.containsKey('providerFees'), false);
  });

  test('admin withdrawal: only the payout fee, no collection fee, no VAT', () {
    const f = ProviderFees(collectionPercent: 3, vatPercent: 18, payoutFee: 1500);
    expect(f.adminWithdrawFee(20000), 1500); // not 4,200 like a provider
    expect(f.adminWithdrawNet(20000), 18500);
    expect(f.adminWithdrawFee(100000), 1500); // flat, does not grow with the amount
    expect(f.adminWithdrawNet(100000), 98500);
    expect(f.adminWithdrawCovers(1500), false);
    expect(f.adminWithdrawCovers(1501), true);
    expect(f.adminSmallestUsable, 1501);
    expect(f.adminWithdrawNet(1000), 0); // never negative
    expect(const ProviderFees(collectionPercent: 3, vatPercent: 18).adminWithdrawFee(20000), 0); // no payout fee set -> free
    expect(const ProviderFees().adminWithdrawNet(20000), 20000);
  });
  test('service categories: the admin list is kept in order, bad rows are dropped', () {
    final r = AppPolicy.sanitize({
      'data': {
        'categories': [
          {'id': 'Plumbing', 'nameEn': 'Plumbing', 'nameSw': 'Mabomba'},
          {'id': '', 'nameEn': 'No id'}, // no id: dropped
          'nonsense', // not an object: dropped
          {'id': 'plumbing', 'nameEn': 'Again'}, // same id (any case): dropped
          {'id': 'Tailoring', 'nameEn': 'Tailoring'}, // no Swahili name: falls back to English
        ],
      },
    })!;
    final cats = (r['categories'] as List).map(PolicyCategory.tryParse).whereType<PolicyCategory>().toList();
    expect(cats.map((c) => c.id), ['Plumbing', 'Tailoring']);
    expect(cats[0].name(false), 'Mabomba');
    expect(cats[1].name(false), 'Tailoring');
    expect(cats[1].name(true), 'Tailoring');
  });

  test('service categories: missing or empty means the built-in list', () {
    expect(AppPolicy.sanitize({'data': {}})!.containsKey('categories'), false);
    expect(AppPolicy.sanitize({'data': {'categories': []}})!.containsKey('categories'), false);
    expect(AppPolicy.sanitize({'data': {'categories': 'x'}})!.containsKey('categories'), false);
  });

  test('support contacts: only valid ones are kept', () {
    final r = AppPolicy.sanitize({
      'data': {
        'support': {'phone': '+255 712 345 678', 'whatsapp': 'abc', 'email': 'help@ungana.app'},
      }
    })!;
    expect(r['supportPhone'], '+255712345678');
    expect(r.containsKey('supportWhatsapp'), false);
    expect(r['supportEmail'], 'help@ungana.app');
  });

  test('terms / privacy links: only https links are kept', () {
    final r = AppPolicy.sanitize({
      'data': {
        'legal': {'termsUrl': 'https://ungana.app/terms', 'privacyUrl': 'http://ungana.app/privacy'},
      }
    })!;
    expect(r['termsUrl'], 'https://ungana.app/terms');
    expect(r.containsKey('privacyUrl'), false);
    expect(AppPolicy.sanitize({'data': {}})!.containsKey('termsUrl'), false);
  });
}
