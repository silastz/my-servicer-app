import 'package:flutter_test/flutter_test.dart';
import 'package:latlong2/latlong.dart';
import 'package:ungana/services/live_follow.dart';
import 'package:ungana/services/navigation_engine.dart';

final _t0 = DateTime(2026, 10, 25, 12, 0, 0);
DateTime _at(double seconds) => _t0.add(Duration(milliseconds: (seconds * 1000).round()));

// ~55 m per 0.0005 degrees of latitude, in Dar es Salaam.
const _a = LatLng(-6.8000, 39.2000);
LatLng _north(LatLng p, double deg) => LatLng(p.latitude + deg, p.longitude);
LatLng _east(LatLng p, double deg) => LatLng(p.latitude, p.longitude + deg);

void main() {
  group('angles', () {
    test('turn the short way round', () {
      expect(angleDelta(350, 10), closeTo(20, 1e-9));
      expect(angleDelta(10, 350), closeTo(-20, 1e-9));
      expect(lerpAngle(350, 10, 0.5), closeTo(0, 1e-9));
    });
  });

  group('LiveGlide', () {
    test('first fix is placed directly', () {
      final g = LiveGlide();
      g.push(_a, now: _at(0));
      expect(g.position, _a);
      expect(g.tick(_at(0.1)), isFalse); // nothing to animate
    });

    test('glides to the next fix over the gap between fixes', () {
      final g = LiveGlide();
      final b = _north(_a, 0.0005);
      g.push(_a, now: _at(0));
      g.push(b, now: _at(4));
      expect(g.position, _a); // still drawn at the old place until a frame runs
      expect(g.tick(_at(6)), isTrue); // 2 s into a 4 s glide: halfway
      expect(g.position!.latitude, closeTo(_a.latitude + 0.00025, 1e-7));
      expect(g.tick(_at(8)), isFalse);
      expect(g.position, b);
    });

    test('a new fix continues from where the marker is drawn, not from the old fix', () {
      final g = LiveGlide();
      g.push(_a, now: _at(0));
      g.push(_north(_a, 0.0005), now: _at(4));
      g.tick(_at(6)); // halfway
      final drawn = g.position!;
      g.push(_north(_a, 0.0010), now: _at(6));
      expect(g.position, drawn); // no jump
      expect(g.target, _north(_a, 0.0010));
    });

    test('repeating the same fix does not restart the glide', () {
      final g = LiveGlide();
      final b = _north(_a, 0.0005);
      g.push(_a, now: _at(0));
      g.push(b, now: _at(4));
      g.tick(_at(6));
      g.push(b, now: _at(6)); // poll returned the same position
      g.tick(_at(8));
      expect(g.position, b); // arrived on the original schedule
    });

    test('a huge jump snaps instead of flying across the map', () {
      final g = LiveGlide();
      g.push(_a, now: _at(0));
      final far = _north(_a, 0.05); // ~5.5 km
      g.push(far, now: _at(3));
      expect(g.position, far);
    });

    test('reset forgets the position, the next fix is placed directly', () {
      final g = LiveGlide();
      g.push(_a, now: _at(0));
      g.reset();
      expect(g.position, isNull);
      g.push(_east(_a, 0.0005), now: _at(10));
      expect(g.position, _east(_a, 0.0005));
    });

    test('heading comes from the direction of travel when the device gives none', () {
      final g = LiveGlide();
      g.push(_a, now: _at(0));
      g.push(_east(_a, 0.0005), now: _at(3));
      g.tick(_at(3.1));
      expect(g.hasHeading, isTrue);
      expect(g.heading, closeTo(90, 1.5));
    });

    test('a heading from the device wins over the movement', () {
      final g = LiveGlide();
      g.push(_a, heading: 200, now: _at(0));
      g.push(_east(_a, 0.0005), heading: 200, now: _at(3));
      g.tick(_at(3.1));
      expect(g.heading, closeTo(200, 1e-6));
    });

    test('my own marker (no bearing from movement) keeps its heading when the GPS gives none', () {
      final g = LiveGlide(bearingFromMovement: false);
      g.push(_a, now: _at(0));
      g.push(_east(_a, 0.0005), now: _at(3));
      expect(g.hasHeading, isFalse);
    });

    test('heading turns the short way round, never the long way', () {
      final g = LiveGlide();
      g.push(_a, heading: 350, now: _at(0));
      g.push(_north(_a, 0.0005), heading: 10, now: _at(3));
      g.tick(_at(3.05));
      // eased part of the way from 350 towards 10, through north: stays near 350..360, never ~180
      final h = g.heading;
      expect(h > 340 || h < 20, isTrue);
    });

    test('speed from the gap between fixes, and zero once fixes stop', () {
      final g = LiveGlide();
      g.push(_a, now: _at(0));
      g.push(_north(_a, 0.0005), now: _at(4)); // ~55.6 m in 4 s
      expect(g.speed(_at(5)), closeTo(13.9, 0.4));
      expect(g.moving(_at(5)), isTrue);
      expect(g.speed(_at(20)), 0);
      expect(g.moving(_at(20)), isFalse);
    });
  });

  group('LiveEta', () {
    test('blends the route speed with the real speed', () {
      expect(LiveEta.secondsFor(1000, routeSpeedMps: 10), closeTo(100, 1e-9));
      expect(LiveEta.secondsFor(1000, routeSpeedMps: 10, observedMps: 2), closeTo(1000 / 6, 1e-9));
    });

    test('standing still does not blow the ETA up', () {
      expect(LiveEta.secondsFor(1000, routeSpeedMps: 10, observedMps: 0.2), closeTo(100, 1e-9));
    });

    test('bad route speed falls back, zero distance is zero seconds', () {
      expect(LiveEta.secondsFor(830, routeSpeedMps: 0), closeTo(100, 1e-9));
      expect(LiveEta.secondsFor(0, routeSpeedMps: 10), 0);
    });

    test('uses the average speed of the real route', () {
      const b = LatLng(-6.8000, 39.2090);
      final r = NavRoute.straight(_a, b); // 8.3 m/s by construction
      final e = LiveEta.fromRoute(r, remainingM: 830);
      expect(e.seconds, closeTo(100, 0.01));
      expect(e.approximate, isFalse);
    });

    test('straight-line guess is marked approximate', () {
      expect(LiveEta.straight(830).approximate, isTrue);
    });
  });

  group('LiveText', () {
    test('"8 min away · 2.4 km"', () {
      const e = LiveEta(2400, 480);
      expect(LiveText.away(e, true), '8 min away · 2.4 km');
      expect(LiveText.away(e, false), 'Yuko 8 dak mbali · 2.4 km');
      expect(LiveText.chip(e, true), '8 min');
    });

    test('approximate estimates carry a ~', () {
      const e = LiveEta(2400, 480, approximate: true);
      expect(LiveText.away(e, true), '~8 min away · 2.4 km');
      expect(LiveText.chip(e, true), '~8 min');
    });

    test('very close means "right here"', () {
      const e = LiveEta(20, 5);
      expect(LiveText.away(e, true), 'Right here');
      expect(LiveText.chip(e, true), 'Here');
      expect(LiveText.away(e, false), 'Yuko hapa');
    });

    test('under a minute reads naturally in both languages', () {
      const e = LiveEta(300, 40);
      expect(LiveText.away(e, true), '< 1 min away · 300 m');
      expect(LiveText.away(e, false), 'Yuko chini ya dak 1 · 300 m');
      expect(LiveText.chip(e, true), '< 1 min');
      expect(LiveText.chip(e, false), '< dak 1');
    });

    test('last seen', () {
      expect(LiveText.lastSeen(40, true), 'Last seen 40s ago');
      expect(LiveText.lastSeen(130, true), 'Last seen 2 min ago');
    });
  });
}
