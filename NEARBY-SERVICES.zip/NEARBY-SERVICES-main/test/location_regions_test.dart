import 'package:flutter_test/flutter_test.dart';
import 'package:ungana/services/location_service.dart';

void main() {
  group('regions follow the detected country', () {
    test('each supported country has its own list, capital first', () {
      expect(LocationService.regionsFor('TZ').first, 'Dar es Salaam');
      expect(LocationService.regionsFor('KE').first, 'Nairobi');
      expect(LocationService.regionsFor('UG').first, 'Kampala');
      expect(LocationService.regionsFor('RW').first, 'Kigali');
      expect(LocationService.regionsFor('BI').first, 'Bujumbura');
      expect(LocationService.regionsFor('CD').first, 'Kinshasa');
    });

    test('lists are not mixed between countries', () {
      expect(LocationService.regionsFor('KE'), isNot(contains('Arusha')));
      expect(LocationService.regionsFor('TZ'), isNot(contains('Nairobi')));
    });

    test('unknown or empty country falls back to Tanzania', () {
      expect(LocationService.regionsFor(''), LocationService.regionsFor('TZ'));
      expect(LocationService.regionsFor('US'), LocationService.regionsFor('TZ'));
      expect(LocationService.regionsFor(null), LocationService.regionsFor('TZ'));
    });

    test('every list is non-empty with no duplicates', () {
      LocationService.regionsByCountry.forEach((iso, list) {
        expect(list, isNotEmpty, reason: iso);
        expect(list.toSet().length, list.length, reason: '$iso has duplicates');
      });
    });
  });

  group('resolveDetectedLocation', () {
    test('Tanzania city and region names match the list', () {
      expect(LocationService.resolveDetectedLocation(iso: 'TZ', city: 'Dar es Salaam'), 'Dar es Salaam');
      expect(LocationService.resolveDetectedLocation(iso: 'TZ', region: 'Arusha Region'), 'Arusha');
      expect(LocationService.resolveDetectedLocation(iso: 'TZ', city: 'Moshi'), 'Kilimanjaro (Moshi)');
    });

    test('Kenya counties and towns match', () {
      expect(LocationService.resolveDetectedLocation(iso: 'KE', city: 'Nairobi', region: 'Nairobi County'), 'Nairobi');
      expect(LocationService.resolveDetectedLocation(iso: 'KE', city: 'Eldoret'), 'Uasin Gishu (Eldoret)');
      expect(LocationService.resolveDetectedLocation(iso: 'KE', city: 'Unknown', region: 'Kisumu County'), 'Kisumu');
    });

    test('Uganda, Rwanda and DRC match (incl. accents and provinces)', () {
      expect(LocationService.resolveDetectedLocation(iso: 'UG', city: 'Entebbe'), 'Wakiso (Entebbe)');
      expect(LocationService.resolveDetectedLocation(iso: 'RW', region: 'Southern Province'), 'Huye (Butare)');
      expect(LocationService.resolveDetectedLocation(iso: 'CD', city: 'Goma'), 'Nord-Kivu (Goma)');
      expect(LocationService.resolveDetectedLocation(iso: 'CD', region: 'Kasai-Oriental'), 'Kasaï-Oriental (Mbuji-Mayi)');
    });

    test('unmatched place in a supported country keeps the raw name', () {
      expect(LocationService.resolveDetectedLocation(iso: 'KE', city: 'Zzyzx'), 'Zzyzx');
    });

    test('no place data gives the country capital', () {
      expect(LocationService.resolveDetectedLocation(iso: 'KE'), 'Nairobi');
      expect(LocationService.resolveDetectedLocation(iso: 'UG'), 'Kampala');
    });

    test('unsupported country becomes "City, Country"', () {
      expect(
        LocationService.resolveDetectedLocation(iso: 'US', city: 'Austin', countryName: 'United States'),
        'Austin, United States',
      );
    });
  });

  group('regionFromCoordinates (GPS)', () {
    test('Dar es Salaam is not mistaken for Zanzibar', () {
      expect(LocationService.regionFromCoordinates('TZ', -6.80, 39.25), 'Dar es Salaam'); // city
      expect(LocationService.regionFromCoordinates('TZ', -6.78, 39.15), 'Dar es Salaam'); // Kimara
      expect(LocationService.regionFromCoordinates('TZ', -6.9, 39.28), 'Dar es Salaam'); // Kigamboni
    });

    test('Zanzibar islands and nearby regions', () {
      expect(LocationService.regionFromCoordinates('TZ', -6.1659, 39.2026), 'Zanzibar'); // Stone Town
      expect(LocationService.regionFromCoordinates('TZ', -5.2455, 39.7686), 'Zanzibar'); // Pemba
      expect(LocationService.regionFromCoordinates('TZ', -6.77, 38.92), 'Pwani (Kibaha)');
      expect(LocationService.regionFromCoordinates('TZ', -5.07, 39.10), 'Tanga');
    });

    test('only Tanzania, and only real coordinates inside it', () {
      expect(LocationService.regionFromCoordinates('KE', -1.29, 36.82), isNull);
      expect(LocationService.regionFromCoordinates(null, -6.8, 39.25), isNull);
      expect(LocationService.regionFromCoordinates('TZ', 51.5, -0.12), isNull);
      expect(LocationService.regionFromCoordinates('TZ', double.nan, 39.25), isNull);
    });
  });
}
