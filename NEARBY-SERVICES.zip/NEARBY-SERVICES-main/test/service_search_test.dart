import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart';
import 'package:ungana/models/models.dart';
import 'package:ungana/models/service_filters.dart';
import 'package:ungana/models/service_search.dart';

ServiceItem _s(String id, {double? km, String? city, String? title, bool is18 = false, String other = ''}) => ServiceItem(
      id: id,
      title: title ?? id,
      subtitle: '',
      distance: city ?? '',
      rating: 4,
      reviewsCount: 1,
      priceText: 'TSh 1',
      isSponsored: false,
      themeColor: Colors.blue,
      icon: Icons.home,
      distanceKm: km,
      city: city,
      is18Plus: is18,
      otherLanguage: other,
    );

void main() {
  group('other language (search only)', () {
    final barber = _s('b', title: 'Barber shop', other: 'kinyozi, kunyoa, kusafisha nywele');

    test('finds a service by words typed in another language', () {
      expect(ServiceText.matches(barber, 'kinyozi'), isTrue);
      expect(ServiceText.matches(barber, 'kunyoa'), isTrue);
      expect(ServiceText.matches(barber, 'kusafisha nywele'), isTrue);
      expect(ServiceText.matches(barber, 'nywel'), isTrue);
      expect(ServiceText.matches(barber, 'plumber'), isFalse);
    });

    test('localMatches returns it', () {
      expect(ServiceText.localMatches([barber], 'kunyoa').map((e) => e.id), ['b']);
    });

    test('sensitive services still need a whole word', () {
      final s = _s('x', title: 'Hidden', is18: true, other: 'kinyozi');
      expect(StrictMatch.allows(s, 'kinyozi'), isTrue);
      expect(StrictMatch.allows(s, 'kinyo'), isFalse);
    });
  });

  test('category word becomes a category search', () {
    expect(ServiceCategories.resolve('Plumber', null).category, 'Plumbing');
    expect(ServiceCategories.resolve('Plumber', null).query, isNull);
    expect(ServiceCategories.resolve('kinyozi', null).category, 'Barber');
    final r = ServiceCategories.resolve('bridal makeup', null);
    expect(r.category, isNull);
    expect(r.query, 'bridal makeup');
    expect(ServiceCategories.resolve('hair', 'Barber').category, 'Barber');
  });

  test('split by radius, falling back to city when distance unknown', () {
    final r = ServiceSearch.split(
      [_s('a', km: 3), _s('b', km: 80), _s('c', city: 'Arusha'), _s('d', city: 'Dar es Salaam')],
      radiusKm: 10,
      userCity: 'Dar es Salaam',
    );
    expect(r.nearby.map((e) => e.id), ['a', 'd']);
    expect(r.elsewhere.map((e) => e.id), ['b', 'c']);
  });

  test('distance filter is dropped so far results stay as "elsewhere"', () {
    const f = ServiceFilters(maxDistanceKm: 5, minRating: 3);
    final out = f.withoutDistance().apply([_s('a', km: 2), _s('b', km: 500)]);
    expect(out.length, 2);
  });

  group('strict matching for sensitive services', () {
    final sensitive = _s('x', title: 'Utumbo umetoka', is18: true);

    test('a fragment of a word does not find it', () {
      expect(StrictMatch.allows(sensitive, 'Utu'), isFalse);
      expect(StrictMatch.allows(sensitive, 'utumb'), isFalse);
      expect(StrictMatch.allows(sensitive, 'meto'), isFalse);
    });

    test('a whole word, the phrase, extra or reordered words find it', () {
      expect(StrictMatch.allows(sensitive, 'Utumbo'), isTrue);
      expect(StrictMatch.allows(sensitive, 'UTUMBO'), isTrue);
      expect(StrictMatch.allows(sensitive, 'umetoka'), isTrue);
      expect(StrictMatch.allows(sensitive, 'Utumbo umetoka'), isTrue);
      expect(StrictMatch.allows(sensitive, '  utumbo   umetoka! '), isTrue);
      expect(StrictMatch.allows(sensitive, 'Utumbo umetoka sana'), isTrue);
      expect(StrictMatch.allows(sensitive, 'umetoka Utumbo'), isTrue);
    });

    test('only fragments or unrelated words do not find it', () {
      expect(StrictMatch.allows(sensitive, 'Utu sana'), isFalse);
      expect(StrictMatch.allows(sensitive, 'sana'), isFalse);
    });

    test('normal services keep the forgiving search; empty query passes', () {
      final normal = _s('n', title: 'Utumbo umetoka');
      expect(StrictMatch.allows(normal, 'Utu'), isTrue);
      expect(StrictMatch.allows(sensitive, null), isTrue);
      expect(StrictMatch.allows(sensitive, '  '), isTrue);
    });
  });

  group('ServiceText: search in description, features, category, city', () {
    ServiceItem svc(String id, {String title = 'Mama Lishe', String description = '', String short = '', List<String> features = const [], String category = 'Food', String? city, bool is18 = false}) =>
        ServiceItem(
          id: id,
          title: title,
          subtitle: description,
          shortDescription: short,
          category: category,
          distance: city ?? '',
          rating: 4,
          reviewsCount: 1,
          priceText: 'TSh 1',
          isSponsored: false,
          themeColor: Colors.blue,
          icon: Icons.home,
          city: city,
          features: features,
          is18Plus: is18,
        );

    test('finds a service by a feature, even when the title has nothing to do with it', () {
      final a = svc('a', features: ['Soup', 'Pizza', 'Eggs']);
      expect(ServiceText.matches(a, 'pizza'), isTrue);
      expect(ServiceText.matches(a, 'PIZZ'), isTrue); // partial word, any case
      expect(ServiceText.matches(a, 'sandwich'), isFalse);
    });

    test('finds a service by its full or short description, in any word order', () {
      final a = svc('a', description: 'Fresh chapati and maharage delivered fast', short: 'Home cooked');
      expect(ServiceText.matches(a, 'chapati'), isTrue);
      expect(ServiceText.matches(a, 'delivered chapati'), isTrue);
      expect(ServiceText.matches(a, 'home cooked'), isTrue);
      expect(ServiceText.matches(a, 'chapati pizza'), isFalse); // every word must be found
    });

    test('accents, punctuation and category / city count', () {
      final a = svc('a', title: 'Café Zuri', category: 'Food', city: 'Arusha');
      expect(ServiceText.matches(a, 'cafe'), isTrue);
      expect(ServiceText.matches(a, 'food arusha'), isTrue);
      expect(ServiceText.matches(a, ''), isFalse);
      expect(ServiceText.matches(a, null), isFalse);
    });

    test('localMatches adds known services by features / description and skips the rest', () {
      final known = [
        svc('pizza', features: ['Pizza']),
        svc('desc', description: 'We sell pizza slices'),
        svc('none', features: ['Soup']),
        svc('blocked', features: ['Pizza']),
        svc('barber', category: 'Barber', features: ['Pizza']),
      ];
      final r = ServiceText.localMatches(known, 'pizza', category: 'Food', exclude: (s) => s.id == 'blocked');
      expect(r.map((e) => e.id), ['pizza', 'desc']);
      expect(ServiceText.localMatches(known, '  '), isEmpty);
      expect(ServiceText.localMatches(known, 'pizza', max: 1).length, 1);
    });

    test('localMatches respects the city', () {
      final known = [svc('a', features: ['Pizza'], city: 'Arusha'), svc('b', features: ['Pizza'], city: 'Mwanza')];
      expect(ServiceText.localMatches(known, 'pizza', city: 'arusha').map((e) => e.id), ['a']);
      expect(ServiceText.localMatches(known, 'pizza').length, 2);
    });

    test('18+ services stay strict: a fragment of a word does not find them', () {
      final s = svc('x', features: ['Utumbo umetoka'], is18: true);
      expect(ServiceText.localMatches([s], 'Utu'), isEmpty);
      expect(ServiceText.localMatches([s], 'Utumbo').map((e) => e.id), ['x']);
    });
  });
}
