import 'package:flutter_test/flutter_test.dart';
import 'package:ungana/models/ads_config.dart';

const _admobBanner = 'ca-app-pub-1234567890123456/1234567890';
const _fbPlacement = '1234567890123456_6543210987654321';

AdsConfig _cfg({
  bool enabled = true,
  bool testMode = false,
  AdProvider def = AdProvider.admob,
  bool fallback = true,
  Map<AdPage, AdPageSetting> pages = const {},
}) {
  return AdsConfig(
    enabled: enabled,
    testMode: testMode,
    defaultProvider: def,
    autoFallback: fallback,
    pages: pages,
    units: {
      AdProvider.admob: {AdPlatform.android: const AdUnitIds(banner: _admobBanner)},
      AdProvider.facebook: {AdPlatform.android: const AdUnitIds(banner: _fbPlacement, rewarded: _fbPlacement)},
      AdProvider.ironsource: {AdPlatform.android: const AdUnitIds(appKey: 'abc12345', banner: 'unit12345')},
    },
  );
}

void main() {
  group('AdProvider', () {
    test('parses the ways the server may write it', () {
      expect(AdProvider.tryParse('ADMOB'), AdProvider.admob);
      expect(AdProvider.tryParse('Facebook'), AdProvider.facebook);
      expect(AdProvider.tryParse('fan'), AdProvider.facebook);
      expect(AdProvider.tryParse('iron_source'), AdProvider.ironsource);
      expect(AdProvider.tryParse('LevelPlay'), AdProvider.ironsource);
      expect(AdProvider.tryParse('applovin'), isNull);
      expect(AdProvider.tryParse(null), isNull);
    });
  });

  group('AdIdRules', () {
    test('blank is fine, wrong shapes are not', () {
      expect(AdIdRules.valid(AdProvider.admob, AdFormat.banner, ''), isTrue);
      expect(AdIdRules.valid(AdProvider.admob, AdFormat.banner, _admobBanner), isTrue);
      // an AdMob APP id (with ~) pasted where a unit id goes
      expect(AdIdRules.valid(AdProvider.admob, AdFormat.banner, 'ca-app-pub-1234567890123456~1234567890'), isFalse);
      expect(AdIdRules.valid(AdProvider.facebook, AdFormat.banner, _fbPlacement), isTrue);
      expect(AdIdRules.valid(AdProvider.facebook, AdFormat.banner, 'IMG_16_9_APP_INSTALL#$_fbPlacement'), isTrue);
      expect(AdIdRules.valid(AdProvider.facebook, AdFormat.banner, 'nope'), isFalse);
      expect(AdIdRules.valid(AdProvider.ironsource, AdFormat.banner, 'unit12345'), isTrue);
      expect(AdIdRules.valid(AdProvider.ironsource, AdFormat.banner, 'bad id!'), isFalse);
      expect(AdIdRules.valid(AdProvider.ironsource, AdFormat.native, 'Home Feed'), isTrue);
      expect(AdIdRules.validAppKey('abc12345'), isTrue);
      expect(AdIdRules.validAppKey('ab'), isFalse);
    });
  });

  group('AdsConfig parsing', () {
    test('missing or empty answer gives safe defaults', () {
      final c = AdsConfig.tryParse({})!;
      expect(c.enabled, isTrue);
      expect(c.testMode, isTrue);
      expect(c.defaultProvider, AdProvider.admob);
      expect(c.autoFallback, isTrue);
      expect(c.page(AdPage.home).enabled, isTrue);
      expect(c.providerFor(AdPage.home), AdProvider.admob);
    });

    test('reads the server shape, accepts a data wrapper and drops bad IDs', () {
      final c = AdsConfig.tryParse({
        'data': {
          'testMode': false,
          'defaultProvider': 'IRONSOURCE',
          'pages': {
            'home': {'enabled': true, 'provider': 'FACEBOOK'},
            'chats': {'enabled': false, 'provider': 'DEFAULT'},
            'unknownPage': {'enabled': false},
          },
          'units': {
            'admob': {
              'android': {'banner': _admobBanner, 'native': 'garbage'},
            },
            'ironsource': {
              'ios': {'appKey': 'key12345', 'rewarded': 'rew12345'},
            },
          },
        },
      })!;
      expect(c.testMode, isFalse);
      expect(c.defaultProvider, AdProvider.ironsource);
      expect(c.providerFor(AdPage.home), AdProvider.facebook);
      expect(c.providerFor(AdPage.search), AdProvider.ironsource);
      expect(c.page(AdPage.chats).enabled, isFalse);
      expect(c.idsOf(AdProvider.admob, AdPlatform.android).banner, _admobBanner);
      expect(c.idsOf(AdProvider.admob, AdPlatform.android).native, '');
      expect(c.idsOf(AdProvider.ironsource, AdPlatform.ios).appKey, 'key12345');
    });

    test('not an object is null', () {
      expect(AdsConfig.tryParse('x'), isNull);
      expect(AdsConfig.tryParse(null), isNull);
    });

    test('toJson then tryParse gives the same settings', () {
      final c = _cfg(def: AdProvider.facebook, pages: {AdPage.chats: const AdPageSetting(enabled: false)});
      final back = AdsConfig.tryParse(c.toJson())!;
      expect(back.sameAs(c), isTrue);
      expect(_cfg().sameAs(c), isFalse);
    });
  });

  group('unit ids', () {
    test('AdMob test mode uses Google test units whatever the admin typed', () {
      final c = _cfg(testMode: true);
      expect(c.unitId(AdProvider.admob, AdPlatform.android, AdFormat.banner), AdmobTestIds.of(AdPlatform.android, AdFormat.banner));
      expect(c.hasUnit(AdProvider.admob, AdPlatform.ios, AdFormat.rewarded), isTrue);
    });

    test('real mode needs the admin IDs; ironSource needs an app key', () {
      final c = _cfg();
      expect(c.hasUnit(AdProvider.admob, AdPlatform.android, AdFormat.banner), isTrue);
      expect(c.hasUnit(AdProvider.admob, AdPlatform.android, AdFormat.rewarded), isFalse);
      expect(c.hasUnit(AdProvider.admob, AdPlatform.ios, AdFormat.banner), isFalse);
      expect(c.hasUnit(AdProvider.ironsource, AdPlatform.android, AdFormat.banner), isTrue);
      expect(c.hasUnit(AdProvider.ironsource, AdPlatform.android, AdFormat.rewarded), isFalse);
      // native uses an optional placement name, so the app key alone is enough
      expect(c.hasUnit(AdProvider.ironsource, AdPlatform.android, AdFormat.native), isTrue);
      expect(c.hasUnit(AdProvider.ironsource, AdPlatform.ios, AdFormat.native), isFalse);
    });
  });

  group('chain', () {
    test('page choice first, then default, then the rest, only networks with IDs', () {
      final c = _cfg(pages: {AdPage.home: const AdPageSetting(provider: AdProvider.facebook)});
      expect(c.chain(AdPage.home, AdFormat.banner, AdPlatform.android),
          [AdProvider.facebook, AdProvider.admob, AdProvider.ironsource]);
      // rewarded: AdMob has no rewarded ID, ironSource neither
      expect(c.chain(AdPage.videoReward, AdFormat.rewarded, AdPlatform.android), [AdProvider.facebook]);
    });

    test('without fallback only the page choice is used', () {
      final c = _cfg(fallback: false, pages: {AdPage.home: const AdPageSetting(provider: AdProvider.facebook)});
      expect(c.chain(AdPage.home, AdFormat.banner, AdPlatform.android), [AdProvider.facebook]);
      expect(c.chain(AdPage.search, AdFormat.banner, AdPlatform.android), [AdProvider.admob]);
    });

    test('a page without an ID on its network shows nothing when fallback is off', () {
      final c = _cfg(fallback: false, def: AdProvider.admob);
      expect(c.chain(AdPage.videoReward, AdFormat.rewarded, AdPlatform.android), isEmpty);
    });

    test('ads off, or the page off, gives nothing', () {
      expect(_cfg(enabled: false).chain(AdPage.home, AdFormat.banner, AdPlatform.android), isEmpty);
      final off = _cfg(pages: {AdPage.home: const AdPageSetting(enabled: false)});
      expect(off.chain(AdPage.home, AdFormat.banner, AdPlatform.android), isEmpty);
      expect(off.chain(AdPage.search, AdFormat.banner, AdPlatform.android), isNotEmpty);
    });

    test('unavailable networks are skipped', () {
      final c = _cfg();
      expect(c.chain(AdPage.home, AdFormat.banner, AdPlatform.android, available: (p) => p != AdProvider.admob),
          [AdProvider.facebook, AdProvider.ironsource]);
    });
  });
}
