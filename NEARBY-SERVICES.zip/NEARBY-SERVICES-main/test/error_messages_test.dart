import 'package:flutter_test/flutter_test.dart';
import 'package:ungana/constants/app_strings.dart';
import 'package:ungana/services/error_messages.dart';

void main() {
  test('payment and category codes the server sends have their own text', () {
    for (final code in const [
      'TOPUP_BELOW_MIN',
      'TOPUP_ABOVE_MAX',
      'INVALID_PHONE',
      'INVALID_CATEGORY',
      'INVALID_CATEGORY_ID',
      'INVALID_CATEGORY_NAME',
      'INVALID_SORT_ORDER',
      'CATEGORY_ID_IN_USE',
      'CATEGORY_IN_USE',
      'CATEGORY_NOT_FOUND',
      'CARD_PAYMENTS_DISABLED',
    ]) {
      expect(ErrorMessages.lookup(code), isNotNull, reason: code);
    }
  });

  test('the account-deletion codes the server sends have their own text, in both languages', () {
    for (final code in const ['WRONG_PASSWORD', 'WALLET_NOT_EMPTY', 'OPEN_BOOKINGS', 'PAYMENT_PENDING', 'ADMIN_ACCOUNT']) {
      expect(ErrorMessages.lookup(code), isNotNull, reason: code);
    }
    // Same code, other language: a different sentence, never the raw code.
    final before = AppStrings.currentLanguage.value;
    try {
      AppStrings.currentLanguage.value = AppLanguage.english;
      final en = ErrorMessages.lookup('WRONG_PASSWORD');
      AppStrings.currentLanguage.value = AppLanguage.swahili;
      final sw = ErrorMessages.lookup('WRONG_PASSWORD');
      expect(en, isNot(sw));
      expect(sw!.contains('WRONG_PASSWORD'), false);
    } finally {
      AppStrings.currentLanguage.value = before;
    }
  });

  test('INVALID_STATUS with a status after the colon still finds its text', () {
    final plain = ErrorMessages.lookup('INVALID_STATUS');
    expect(plain, isNotNull);
    expect(ErrorMessages.lookup('INVALID_STATUS:REFUNDED'), plain);
    expect(plain!.toLowerCase().contains('not allowed'), false);
  });

  test('the admin user-management codes have their own text', () {
    for (final code in const ['ACCOUNT_SUSPENDED', 'ACCOUNT_DELETED', 'REASON_REQUIRED', 'REASON_TOO_LONG']) {
      expect(ErrorMessages.lookup(code), isNotNull, reason: code);
    }
  });
}
