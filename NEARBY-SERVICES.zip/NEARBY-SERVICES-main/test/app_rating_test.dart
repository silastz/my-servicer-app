import 'package:flutter_test/flutter_test.dart';
import 'package:ungana/services/app_rating_service.dart';

void main() {
  final now = DateTime(2026, 10, 23);

  bool ask(int stars, {int count = 0, DateTime? last}) =>
      AppRatingService.shouldAsk(stars: stars, askCount: count, lastAsk: last, now: now);

  test('only good reviews trigger the store card', () {
    expect(ask(5), isTrue);
    expect(ask(4), isTrue);
    expect(ask(3), isFalse);
    expect(ask(1), isFalse);
  });

  test('not again within 90 days', () {
    expect(ask(5, last: now.subtract(const Duration(days: 30))), isFalse);
    expect(ask(5, last: now.subtract(const Duration(days: 91))), isTrue);
  });

  test('stops after 3 asks', () {
    expect(ask(5, count: 2, last: now.subtract(const Duration(days: 200))), isTrue);
    expect(ask(5, count: 3, last: now.subtract(const Duration(days: 200))), isFalse);
  });
}
