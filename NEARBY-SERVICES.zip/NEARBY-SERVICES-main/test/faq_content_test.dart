import 'package:flutter_test/flutter_test.dart';
import 'package:ungana/models/faq_content.dart';

void main() {
  final all = [for (final c in FaqContent.categories) ...c.items];

  test('every category and question has English and Swahili text', () {
    expect(FaqContent.categories.length, greaterThanOrEqualTo(8));
    final ids = FaqContent.categories.map((c) => c.id).toList();
    expect(ids.toSet().length, ids.length);
    for (final c in FaqContent.categories) {
      expect(c.titleEn.trim(), isNotEmpty);
      expect(c.titleSw.trim(), isNotEmpty);
      expect(c.items, isNotEmpty);
    }
    for (final i in all) {
      expect(i.qEn.trim(), isNotEmpty);
      expect(i.qSw.trim(), isNotEmpty);
      expect(i.aEn.trim().length, greaterThan(20), reason: i.qEn);
      expect(i.aSw.trim().length, greaterThan(20), reason: i.qSw);
    }
  });

  test('no duplicate questions', () {
    final q = all.map((i) => i.qEn.toLowerCase()).toList();
    expect(q.toSet().length, q.length);
  });

  test('only known tokens are used', () {
    final re = RegExp(r'\{([a-zA-Z]+)\}');
    for (final i in all) {
      for (final t in [i.aEn, i.aSw]) {
        for (final m in re.allMatches(t)) {
          expect(FaqContent.tokens.contains(m.group(1)), true, reason: '${m.group(0)} in ${i.qEn}');
        }
      }
    }
  });

  test('render fills known values and drops empty brackets', () {
    expect(FaqContent.render('fee ({regFee}) ok', {'regFee': 'TSh 10,000'}), 'fee (TSh 10,000) ok');
    expect(FaqContent.render('fee ({regFee}) ok', {}), 'fee ok');
    expect(FaqContent.render('a {collection} b', {'collection': '3%'}), 'a 3% b');
  });

  test('search finds answers in both languages', () {
    expect(FaqContent.search('escrow', true, {}), isNotEmpty);
    expect(FaqContent.search('nenosiri', false, {}), isNotEmpty);
    expect(FaqContent.search('', true, {}), isEmpty);
    expect(FaqContent.search('zzzzqq', true, {}), isEmpty);
  });
}
