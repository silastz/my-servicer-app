# Security & login update - summary

## Setup (do once)
1. `flutter pub get`, then `flutter analyze`.
2. Put your server's CA certificate in `assets/certs/pinned_ca.pem` (see `assets/certs/README.txt`).
3. Release build: `API_ORIGIN=https://your.server EXPECTED_SIGNER_SHA256=<hex> ./tool/build_release.sh appbundle`
4. Play Console: link a Cloud project and enable the Play Integrity API; verify tokens on the backend (`docs/play_integrity_backend.md`).
5. Server hardening: `docs/SECURITY_HARDENING.md`.

## New / changed
- Network: certificate pinning, no system proxy, no cleartext, user-CA not trusted (`lib/security/secure_http.dart`, `network_security_config.xml`, iOS ATS)
- URL hiding: obfuscated address, `--dart-define=API_ORIGIN`, Dart obfuscation (`client_security_config.dart`, `tool/`)
- Device: root / Frida / Xposed / debugger detection, re-scan on resume, signature (tamper) check, FLAG_SECURE (`MainActivity.kt`, `device_integrity.dart`, `integrity_guard.dart`)
- Play Integrity token on sensitive calls (`attestation.dart`)
- Login / forgot password: no account enumeration, strong password policy with common-password detection, persistent lock-outs, network errors no longer count as wrong attempts, safe JSON/status handling, mounted checks, resend countdown (30/60/120s)
- UI: auto spinners on action buttons (`AppButton`, `LoadingTextButton`, offers, orders, payments, top-up)

## Registration hardening (all sign-up flows)
- New `lib/security/input_validation.dart`: one set of rules (name, business name, phone, e-mail,
  password shape, OTP, NIN, invitation code) used by sign-up, provider registration and invitation screens.
- Sign-up (`login_modal.dart`): name/phone/e-mail/password validated before any request; passwords are no
  longer silently trimmed; length caps and character filters on every field; device-level brake after repeated
  rejected sign-ups (not triggered by network errors); server error text is filtered before display.
- Provider registration (`register_provider_screen.dart`): double-tap guard (no duplicate accounts/payments);
  strict phone check (+255 needs 9 digits; fixes "+255255..." numbers); password checked against the user's own phone;
  e-mail, business name and description validated; OTP digits only with SMS autofill; resend respects the cool-down and
  shows the real reason (offline / busy) instead of a generic error; fee taken from one source and confirmed with
  the server before the account is marked paid.
- Fee screen (`registration_fee_screen.dart`): one payment at a time; result confirmed with the server; absurd amounts
  from the server ignored; payment reference no longer just a timestamp.
- Invitation (`accept_invitation_screen.dart`): code/NIN format filters, clipboard text sanitised, persistent lock-out
  after repeated wrong attempts.
- API (`api_service.dart`): `register()` refuses impossible input and any role other than buyer/seller;
  verification/avatar uploads check type (photos only) and size (10 MB) before sending.
- Server must still enforce everything above (rate limits, role assignment, amounts, payment status).

## Provider registration: country code selector
- New `lib/widgets/country_code_picker.dart` (flag + code chip, list of Tanzania, Kenya, Uganda, Rwanda, Burundi, DRC).
- The phone field in `register_provider_screen.dart` now lets the user choose the country code (it starts with the detected
  country). The number is built from the chosen code; typing a full +code number or 0-prefixed number still works.
- Saved numbers of existing users are split into code + local part. The field is locked after verification.
- Validator: Uganda and Rwanda numbers are checked for 9 digits after the code (like Tanzania and Kenya).
- Mobile-money payment number stays Tanzanian (+255) because the payment providers are Tanzanian.
