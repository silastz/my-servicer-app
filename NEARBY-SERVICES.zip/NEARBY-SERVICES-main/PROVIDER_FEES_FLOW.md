# Provider fees: two charges at withdrawal, nothing taken when the buyer pays

The admin sets three numbers: **collection %** and **VAT %** (both of the withdrawn amount) and a flat **payout fee**
(TSh). The collection fee is charged **on its own**. The payout fee is **inside** the VAT charge, not added on top.

| Moment | What happens | Example |
| --- | --- | --- |
| **Buyer pays the provider** | the provider's wallet is credited the **full** amount | buyer pays 20,000 -> wallet shows **20,000** |
| **Provider withdraws** | collection fee + VAT charge are taken | withdraw 20,000 -> 600 + 3,600 -> receives **15,800** |
| **Booking is refunded to the buyer** | only the VAT charge is taken from the refund (no collection fee) | refund 10,000 -> 1,800 -> buyer gets back **8,200** |

## Full calculation (3% collection, 18% VAT, payout fee 1,500)

| Withdraw | Collection fee (3%) | VAT charge (18%) | of which payout fee | of which VAT | Provider receives |
| --- | --- | --- | --- | --- | --- |
| 5,000 | 150 | 1,500 (18% = 900, below payout fee) | 1,500 | 0 | **3,350** |
| 10,000 | 300 | 1,800 | 1,500 | 300 | **7,900** |
| 20,000 | 600 | 3,600 | 1,500 | 2,100 | **15,800** |

Check on 20,000: `20,000 - 600 - 1,500 - 2,100 = 15,800`.

Admin wallet on a 20,000 withdrawal: **+600** collection fee income, **+1,500** payout fee income, **+2,100** VAT
(held to remit, not income).

Formula (same on app and server, whole TSh, percent rounded half up):

```
collection = round_half_up(amount * collectionPercent / 100)
pct        = round_half_up(amount * vatPercent / 100)
charge     = max(pct, payoutFee)          # the payout cost is always covered
payoutPart = payoutFee
vatPart    = charge - payoutFee           # 0 when the amount is small
net        = amount - collection - charge # reject with 400 if net <= 0
refund     = paid - charge                # no collection fee on refunds
```

- **Small amounts:** my rule, so the payout cost is never lost. Tell me if you prefer charging only the 18% there.
- If only some of the three are set, the others count as 0.
- Providers see **two** amounts: "Collection fee" and "Fee". They never see the payout / VAT split. Buyers see
  "minus the fee" on refunds only. The admin wallet shows collection fees, payout fee income and VAT separately.

*Whether the 18% part is correctly "VAT" (a tax with tax invoices / fiscal receipts) is a question for your
accountant or the tax authority. This only implements the numbers as described; it is not tax advice. If the gateway
charges you its own payout cost, that is not subtracted anywhere in the app.*

## What the backend must change (the app cannot do this part)

1. **Crediting a buyer's payment:** credit the provider the **full** amount. Remove any collection-fee deduction here;
   it is now taken at withdrawal.
2. **`POST /wallet/withdraw {amount, phone}`:** `amount` is what leaves the provider's wallet. The server then:
   - applies the formula above with the admin's **current** values (never taken from the request)
   - debits the wallet by `amount`, sends `net` to the phone, credits `collection` to the platform wallet as
     `income.collectionFees`, `payoutPart` as `income.withdrawalFees` and `vatPart` as `income.vat` (separate, owed to
     the tax authority)
   - answers `{ ..., "fee": 4200, "netAmount": 15800 }`; `fee` is collection + charge (the app shows it as one
     amount on the "sent" message). Do not send the payout / VAT split to providers or buyers
   - stores `collection`, `charge`, `payoutPart`, `vatPart` on the withdrawal row so later changes do not rewrite history
3. **Refunds** credit the buyer's Pocket Fund `paid - charge` (10,000 -> **8,200**) and credit the charge to the platform
   wallet with the same split. Decide the rule for tiny bookings (`net <= 0` -> buyer gets 0). The terms must be shown to
   buyers before they pay.
4. **Accounting:** report platform income when the fees are taken (at withdrawal).
5. **Existing balances:** providers already credited net of the old 3% were deducted earlier; decide whether to top them
   up once or leave history as it is.
6. **Withdrawal list / receipts:** show gross, collection fee, fee and net to providers.

## Withdrawal limits (from / to)

The admin also sets the **lowest** (`withdrawMin`) and **highest** (`withdrawMax`) amount a provider can withdraw at once,
on the same Provider Fees screen ("From" / "To"). `0` in From = app default (the old `fees.withdrawMin`, else 1,000);
`0` in To = no maximum. `withdrawMax` must not be below `withdrawMin`. The withdraw screen shows "From 2,000 to 500,000
per withdrawal", rejects amounts outside it, and "Withdraw all" fills at most the maximum. **The server must enforce the
same range** on `POST /wallet/withdraw` (400 if outside) using the admin's current values.

## Admin sets the fees

| Call | Who | Body / answer |
| --- | --- | --- |
| `GET /admin/payments/provider-fees` | `ROLE_ADMIN` only | `{ "collectionPercent": 3, "vatPercent": 18, "payoutFee": 1500, "withdrawMin": 1000, "withdrawMax": 5000000 }` |
| `PUT /admin/payments/provider-fees` | `ROLE_ADMIN` only | same body, same answer |

Rules: 403 to non-admins; `collectionPercent` 0-20, `vatPercent` 0-50 (decimals allowed), `payoutFee` whole TSh
0-1,000,000; `withdrawMin` / `withdrawMax` 0 or 100-100,000,000; audit-log every change (who, old, new, time). The same values go in `GET /app/policy` as
`fees.provider = { collectionPercent, vatPercent, payoutFee, withdrawMin, withdrawMax }`. A change applies to withdrawals and refunds made after it.

## In the app

- **Withdraw screen:** "You withdraw 20,000 / Collection fee -600 / Fee -3,600 / You receive 15,800", plus a warning when
  an amount is too small to cover the fees.
- **Admin -> Provider Fees:** three fields (collection %, VAT %, payout fee) and an example on 20,000 showing the
  provider's side and the admin wallet's split (+600, +1,500, +2,100 VAT).
- **Admin Wallet:** income rows include withdrawal (payout) fees and collection fees, plus a separate "VAT collected
  (to remit)" line.
- The app's numbers are an estimate for display. The server charges, and its answer wins.
