import Flutter
import UIKit
import AVFoundation

@main
@objc class AppDelegate: FlutterAppDelegate, FlutterImplicitEngineDelegate {
  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }

  func didInitializeImplicitFlutterEngine(_ engineBridge: FlutterImplicitEngineBridge) {
    GeneratedPluginRegistrant.register(with: engineBridge.pluginRegistry)

    // Cuts a long video to its first maxMs (no re-encoding). See VideoTrim in lib/services/video_trim.dart.
    let channel = FlutterMethodChannel(name: "ungana/video", binaryMessenger: engineBridge.applicationRegistrar.messenger())
    channel.setMethodCallHandler { call, result in
      guard call.method == "trim",
            let args = call.arguments as? [String: Any],
            let path = args["path"] as? String,
            let maxMs = args["maxMs"] as? Int else { result(nil); return }
      let asset = AVURLAsset(url: URL(fileURLWithPath: path))
      let out = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("trim_\(Int(Date().timeIntervalSince1970)).mp4")
      guard let export = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetPassthrough) else { result(nil); return }
      export.outputURL = out
      export.outputFileType = .mp4
      export.timeRange = CMTimeRange(start: .zero, duration: CMTime(value: CMTimeValue(maxMs), timescale: 1000))
      export.exportAsynchronously {
        DispatchQueue.main.async { result(export.status == .completed ? out.path : nil) }
      }
    }
  }
}
