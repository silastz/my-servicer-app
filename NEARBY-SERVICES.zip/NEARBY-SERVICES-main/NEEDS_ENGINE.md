# Customer need identification ("what is the customer thinking?")

Guesses which service a customer probably needs, from what they do in the app.
Runs fully on the phone; nothing is sent to the server.

Files
- `lib/models/customer_needs.dart` – the algorithm (pure Dart, unit-tested)
- `lib/services/need_signals.dart` – remembers signals per account (SharedPreferences, 120 days / 300 events)
- `lib/widgets/likely_needs_card.dart` – Home section "You may need" (hidden until confident)
- `test/customer_needs_test.dart`

Signals and weights: search 3, favorite 4, category open 2, service view 1.5, booking (see below).

How a guess is made
1. Every signal fades with a 14-day half-life, so recent thinking wins.
2. Urgent words ("emergency", "haraka", "dharura"...) boost a signal x1.5 for 3 days and flag it.
3. A booking means the need was met: earlier signals in that category count x0.2.
4. Repeat services (Barber 14d, Cleaning 10d, Beauty 21d, Massage 30d, General 45d) come back as
   "due again" once ~80% of the usual gap has passed.
5. Bookings/favorites nudge related services (Photography -> Beauty/Barber, Plumbing -> Cleaning/Repair...).
6. Weekend / evening gives a small tie-break only.
7. confidence = score / (score + 3); shown only when >= 0.3. One casual view is never enough.

Free text is read in English and Swahili ("bomba linavuja" -> Plumbing). The Search screen shows a
"Looks like you need ..." chip, and searches record the need.

Hooks: Home category tap, Search submit, service page open, favorite on, booking sent.
`NeedSignals.clear()` wipes everything (wire it to a privacy setting if wanted).
Tuning: weights, half-life, cadence and phrase lists are constants at the top of `NeedEngine`.
