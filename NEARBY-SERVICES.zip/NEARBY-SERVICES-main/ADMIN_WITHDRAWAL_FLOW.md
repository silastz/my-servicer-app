# Admin withdrawal: only the payout fee

The admin can withdraw from the **Admin Wallet** (button on `lib/screens/admin_wallet_screen.dart`,
screen `lib/screens/admin_withdraw_screen.dart`) to a mobile-money number.

**The only fee is the flat payout fee** (`payoutFee`, the same value the admin sets on Provider Fees).
No collection fee. No VAT charge. A provider withdrawal is different (see `PROVIDER_FEES_FLOW.md`).

| Admin withdraws | Payout fee | Admin receives |
| --- | --- | --- |
| 5,000 | 1,500 | **3,500** |
| 20,000 | 1,500 | **18,500** |
| 100,000 | 1,500 | **98,500** |

Formula: `net = amount - payoutFee` (reject with 400 if `net <= 0`). With no payout fee set, the fee is 0.

## Backend needs
| Call | Who | Body / answer |
|---|---|---|
| `POST /admin/wallet/withdraw` | `ROLE_ADMIN` only (403 otherwise) | body `{amount, phone}` -> `{fee, netAmount, reference, balance}` |

The server must:
- read the payout fee from the admin's **current** setting (never from the request) and apply nothing else;
- check `amount <= withdrawable balance`. **Do not let the admin withdraw money held in escrow, or the
  VAT collected that is still owed to the tax authority**; decide what "withdrawable" means and enforce it;
- debit `amount` from the platform wallet, send `amount - fee` to the phone, and record one `OUT` row in
  `GET /admin/wallet/transactions` (type `WITHDRAWAL`) with `amount`, `fee`, `net`, the phone (masked) and who did it;
- **not** count the payout fee as platform income (the admin is paying the gateway, not earning). Book it as
  a payout cost. `income.withdrawalFees` / `income.collectionFees` / `income.vat` stay unchanged;
- make it idempotent (reject a double tap / retry with the same reference) and audit-log every admin withdrawal.

## In the app
- Admin Wallet -> **Withdraw** -> amount + phone, with a breakdown: "You withdraw / Payout fee / You receive".
  No collection fee or VAT line is ever shown.
- The numbers shown are an estimate; the server's `fee` and `netAmount` win on the success message.
- Minimum 1,000 TSh and the platform balance are checked in the app for convenience only; the server enforces everything.
