# Ads in NEARBY SERVICES (AdMob, Facebook, ironSource + in-house)

Three ad networks plus the admin's own **in-house ads**, switched by the admin from the app: **Profile > Admin > Ads**.

- **Google AdMob** - `google_mobile_ads`
- **Facebook Audience Network (FAN)** - called directly, via `packages/easy_audience_network` (a vendored, modernised copy of the `easy_audience_network` plugin, see its `README_VENDORED.md`)
- **ironSource / Unity LevelPlay** - mediation, `unity_levelplay_mediation`, with the **Meta** and **AdMob** adapters in the build. Which networks LevelPlay mixes is set in the LevelPlay dashboard.

- **In-house ads** - the admin pastes JSON (image, title, text, button, link; optional pages, dates, weight,
  countries, text per country) in Admin > Ads. No network, no IDs. Details and field rules:
  `docs/ads_config_api_contract.md`. They can be the default, the choice of one page, or (with fallback on)
  the last network tried when the others have no ad. **All formats**: banner, native, and rewarded (a
  full-screen ad with a countdown before a provider video). Every one shows an "Ad" label; a tap opens its
  https link.
  - **Country**: `"countries": ["TZ","KE"]` = only people in those countries see the ad (none = everyone).
  - **Text per country**: `title_TZ`, `body_KE`, `cta_TZ`, `imageUrl_KE`, `url_TZ` replace the plain field for
    that country; everyone else reads the plain field.
  - The country is the one the app detected (network location) or the person chose in Settings.

Until the backend answers, the app behaves as before: AdMob **test ads**.

## What the admin controls (no app update)
- **Show ads from** (top of Admin > Ads, one tap): **All** (mixed), **AdMob**, **Facebook**, **ironSource**,
  **In-house**, or **Off**. A network choice also puts every page back on "Default", so the whole app follows
  it; **Off** turns ads off everywhere. "All" starts each ad spot with a random network that is set up and falls
  back to the others. Per page you can still pick any network, "All", or switch the page off.
- Ads on/off, **test mode** (Google sample ads / Facebook test requests), **automatic fallback**.
- The **default network**, and a **network per page** (or "Default"), or no ads on a page.
- The **ad IDs** of every network, per platform (Android / iOS). Blank = not available on that network.
- Not changeable remotely: the AdMob **app ID** (manifest / plist), a new ironSource app key needs an app restart.

Fallback order for a page: its own network, then the default, then the others - only networks that
have an ID and started. If a network has no ad to show, the widget moves on to the next one.

## Where ads show
| Page (admin name) | Ad |
|---|---|
| Home | Banner under the hero banner; native ad after every 8 cards (Android: one card-sized cell, iOS: full-width row) |
| Service details | Two banners |
| Search results | Native ad after the 3rd result, then after every 8 more |
| Provider profile | Banner above the tabs; native ad after the 2nd service (3+ services) |
| Chats | One native ad row after the 3rd chat |
| Video play | **Rewarded ad** before a provider video: a network's rewarded video, or an in-house full-screen ad (user is asked first; watched = video plays, closed early = no video, no ad available = video plays anyway) |

An ad takes no space until it has loaded.

## Files
- `lib/models/ads_config.dart` - the settings, ID checks, fallback list (tested in `test/ads_config_test.dart`)
- `lib/models/house_ads.dart` - in-house ad JSON: validation, dates, weights, countries, text per country (tested in `test/house_ads_test.dart`)
- `lib/services/ads/house_rewarded.dart`, `lib/widgets/house_rewarded_screen.dart` - the in-house rewarded (full-screen) ad
- `lib/services/ads_config_service.dart` - download + keep the settings (`GET /app/ads`)
- `lib/services/ad_service.dart` - starts the networks, rewarded video, "which networks for this page"
- `lib/services/ads/` - per-network start-up and rewarded video
- `lib/widgets/ad_widgets.dart` - banner / native widgets for the three networks
- `lib/screens/admin_ads_screen.dart` - admin screen
- `docs/ads_config_api_contract.md` - **backend to build** (`GET /app/ads`, `GET/PUT /admin/ads/config`)
- `android/app/build.gradle.kts`, `android/app/proguard-rules.pro`, `ios/Runner/Info.plist`

## Before you publish
1. Build the backend endpoints in `docs/ads_config_api_contract.md`.
2. Create the apps/ad units: AdMob (banner, native advanced, rewarded), Meta Monetization Manager
   (placements; the app must be approved there), LevelPlay (app key, banner + rewarded ad units, a native placement).
3. Replace the AdMob **app ID** in `AndroidManifest.xml` and `Info.plist` (still Google's test ID).
4. `flutter pub get`, then check the two LevelPlay adapter lines in `android/app/build.gradle.kts`
   (see below), and on iOS add the pods (below).
5. Admin > Ads: fill the IDs, then turn **Test mode** off ("go live"). Never tap your own real ads.
6. Privacy policy (advertising ID), Google Play "Data safety" + Ads declaration. Ads are limited to
   `MaxAdContentRating.pg` for AdMob (`lib/services/ads/admob_ads.dart`); Meta and LevelPlay have
   their own content/blocking controls in their dashboards (the app has some 18+ listings).

## LevelPlay adapters
**Android** (`android/app/build.gradle.kts`): the Meta and AdMob adapter lines use the
`com.unity3d.ads-mediation:<network>-adapter:5.+` pattern from the plugin's own example. The adapter
versions must match LevelPlay SDK 9.6.1: if Gradle cannot resolve them, copy the exact lines from the
LevelPlay "Meta Audience Network" and "AdMob" Android guides. The Meta SDK version comes from
`packages/easy_audience_network/android/build.gradle` (6.21.0); keep it compatible with the Meta adapter.

**iOS**: no `Podfile` is committed (Flutter generates it). After `flutter create .` / first build, add inside
`target 'Runner'` in `ios/Podfile`, below `flutter_install_all_ios_pods`:
```ruby
pod 'IronSourceFacebookAdapter'
pod 'IronSourceAdMobAdapter'
```
and set `platform :ios, '15.0'` (LevelPlay 9.6 needs Xcode 26 / iOS 15+). If CocoaPods complains about
`use_frameworks!`, use `use_frameworks! :linkage => :static`. `Info.plist` now has `NSAllowsArbitraryLoads = true`
because LevelPlay requires it (some mediated networks use http): this relaxes iOS App Transport Security app-wide.

Debug builds with test mode on call `LevelPlay.validateIntegration()`: read the adapter checklist in logcat / Xcode.

## Notes
- AGP 9 / Kotlin: LevelPlay 9.6 needs Kotlin 2.0+ (the project uses 2.3).
- `pubspec.lock` is stale until you run `flutter pub get`.
- The Facebook plugin's native ad uses the plugin's own layouts (not the AdMob card factory).
