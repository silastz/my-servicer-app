# Ungana (Mobile Client) 📱

Programu ya simu ya mkononi (Flutter) inayowaunganisha watoa huduma wa karibu na wateja kwa usalama wa hali ya juu nchini Tanzania na Afrika Mashariki.

---

## 🌟 Sifa Kuu za Mfumo (Key Features)

### 1. 🛡️ Usiri Kamili wa NIDA & Majina (Privacy 100%)
- **Stage Names Tu**: Majina halisi ya cheti cha NIDA na namba za NIDA ni siri ya ndani ya mfumo tu (Admin pekee). Wanunuzi na umma wanaona majina ya kikazi pekee (Stage Name, mfano: *"Zeen Spa"*, *"Musa Quick Plumbing"*).
- **Beji za Uhakiki (Verification Badges)**:
  - 🟢 **Green Badge**: Utambulisho umethibitishwa kikamilifu (Kitambulisho + Selfie) AU kupitia **Mwaliko** kutoka kwa mtoa huduma aliyethibitishwa (Green au Blue). Mwenye Green anaweza kualika wengine.
  - 🔵 **Blue Badge**: **Biashara Iliyothibitishwa** (nyaraka za biashara). Inahitaji Green kwanza. Mwaliko unatoa Green tu, haiwezi kutoa Blue.

### 2. 🔒 Ulinzi wa Mawasiliano (Locked vs Unlocked Contacts)
- Muuzaji anauwezo wa kuweka huduma yake kama **Info Locked**:
  - **Locked**: Namba za simu, WhatsApp, Instagram na eneo kamili (GPS) zimefichwa kwa umma. Vinafunguka kwa mteja **baada ya muuzaji kukubali ombi (Service Request)**.
  - **Unlocked**: Mawasiliano yanaonekana wazi moja kwa moja kwa mtu yeyote.

### 3. 💰 Mfumo wa Malipo Salama (Escrow & Pocket Fund)
- Mteja anaweza kulipa kupitia **Pocket Fund (Wallet)** au **Direct Online**.
- Pesa hazitoki kwa muuzaji moja kwa moja; zinalindwa kwenye **Escrow**.
- Muuzaji analipwa **baada tu ya mnunuzi kuthibitisha kuridhika (Satisfied / Mark Completed)**.

---

## 📡 Viunganishi vya Backend & API (Live Production)

- **Domain ya API**: (imeondolewa - ona docs/SECURITY_HARDENING.md)
- **Swagger Documentation**: (imeondolewa - ona docs/SECURITY_HARDENING.md)
- **Health Check**: (imeondolewa - ona docs/SECURITY_HARDENING.md)
- **Huduma za Mwanzo (Marketplace Feed)**: (imeondolewa - ona docs/SECURITY_HARDENING.md)

---

## 🚀 Kuanza Kazi (Development & Build)

### 1. Mahitaji ya Awali
- Flutter SDK (3.x au zaidi)
- Android SDK / Xcode kwa iOS

### 2. Kusanikisha Package (Install Dependencies)
```bash
flutter pub get
```

### 3. Kuendesha App Kwenye Emulator au Simu (Debug Mode)
```bash
flutter run
```

### 4. Kujenga APK ya Release (Production Build)
```bash
flutter build apk --release
```
*Faili la APK litapatikana kwenye: `build/app/outputs/flutter-apk/app-release.apk`*

---

## 📁 Muundo wa Folda za Mradi (Project Structure)

```text
lib/
├── main.dart                   # Entry point, theme, navigation & dynamic home feed
├── models/
│   └── service_model.dart      # Data models kwa huduma, stage names, na badges
├── services/
│   └── api_service.dart        # HTTP client kwa ajili ya kuungana na REST API
└── screens/
    ├── home_screen.dart        # Screen ya kwanza ya kugundua huduma za karibu
    ├── category_detail_screen.dart # Huduma zilizochujwa kwa makundi
    ├── search_filter_screen.dart   # Utafutaji wa huduma kwa eneo na bei
    ├── seller_profile_screen.dart  # Wasifu wa muuzaji (Locked/Unlocked contacts)
    ├── booking_escrow_screen.dart  # Mtiririko wa kuweka fedha kwenye Escrow
    └── nida_verification_screen.dart # Kupakia NIDA & Mwaliko wa mdhamini
```

---

## 📝 Ramani ya Maendeleo (Roadmap)

- [x] Muunganisho wa REST API ya Backend (Spring Boot 4 / Java 21)
- [x] Usawazishaji wa Home Feed (Massage, Cleaning, Plumbing, Beauty, Electrical)
- [x] Uonyeshaji wa beji za uhakiki (Green = utambulisho, Blue = biashara)
- [ ] Screen ya Seller Profile inayoonesha Mawasiliano Yaliyofungwa / Yaliyofunguliwa
- [ ] Mtiririko wa Ombi la Huduma (Request) na Malipo ya Escrow
- [ ] Dashibodi ya Pocket Fund & Wallet Top-up
- [ ] Upakiaji wa taarifa za NIDA na mfumo wa udhamini/mwaliko

## In-app navigation
"Navigate" (service details, Call/Contact sheet) and "Track on Map" (booking details) now open the
in-app navigation screen (`lib/screens/map_tracking_screen.dart`) instead of Google Maps:
route preview, an optional "Use Google Maps" button, turn-by-turn banner, heading-following camera, ETA, automatic re-routing and arrival
detection. Routing: public OSRM; address lookup fallback: Nominatim. Engine: `lib/services/navigation_engine.dart`.

### Message the provider from navigation
`lib/widgets/message_provider_sheet.dart`: buyers can message the provider (quick replies such as
"I'm on my way. ETA 12 min", or free text) from the route preview, during navigation and on arrival.
Messages use the normal chat API, so they also show in the Chats tab.

Service page: seller card no longer shows review count / jobs done, and the verification chip (Blue Tick / NIDA) was removed from the badge row.
Service page: removed the verification tick on the seller avatar.

### Provider's view of the buyer
- New `lib/screens/buyer_profile_screen.dart`: tapping the customer's photo or name on a request card opens a
  Customer page (real photo or initial, name, member-since if the API sends it, this booking, Message,
  Report / Block). Phone number and exact address are never shown there.
- Request cards (incoming and outgoing) now show the buyer's real avatar instead of placeholder images.
- Booking details: the row reads "Customer" (not "Provider") when a provider opens it, and "Track on Map" is hidden
  until the booking is no longer pending.

### Admin: SMS provider (Meseji / Beem Africa)
Profile > Admin > "SMS Provider" (`lib/screens/admin_sms_gateway_screen.dart`). The admin picks the default
provider (Meseji unless changed) and enters its credentials. Secrets are write-only: the server never returns
them, a blank field keeps the saved value. Test connection / Send test SMS use the saved settings.
Server contract: `docs/sms_gateway_api_contract.md`. Customer need engine: `NEEDS_ENGINE.md`.
