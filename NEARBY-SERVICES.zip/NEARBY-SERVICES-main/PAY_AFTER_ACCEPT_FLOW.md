# Pay after accept

New flow: **request, provider accepts, buyer pays, job completed.** Nothing is charged when the request is sent.

## App (done in this version)
- `booking_request_screen.dart`: no payment choice. It calls `POST /escrow/create` with `paymentMethod: "PAY_AFTER_ACCEPT"`.
- `requests_screen.dart`, `booking_details_screen.dart`: a progress bar (Request sent > Accepted > Paid > Completed) on the buyer card, provider card and booking details. A declined or cancelled request shows a red banner instead.
- Provider can **Accept** straight away (it used to be blocked until the buyer paid).
- After acceptance the buyer sees **Pay now** (Pocket Fund, mobile money or card, same `PayNowSheet` as before).
- `payment_flow.dart`: `awaitingPayAfterAccept(tx)` and `progress(tx)` drive the UI.

## Backend must support (the app cannot do this alone)
1. `POST /escrow/create` accepts `paymentMethod = PAY_AFTER_ACCEPT`: create the booking as `PENDING_ACCEPTANCE`, `paymentStatus = UNPAID`, charge nothing, hold no funds.
2. `POST /escrow/accept/{ref}` works while `paymentStatus = UNPAID`: status becomes `ACCEPTED`, `paymentStatus` stays `UNPAID`. Notify the buyer.
3. Booking JSON must always send `paymentStatus` (`UNPAID` until paid, then `PAID`). The app shows "Pay now" only when it sees `ACCEPTED` + `UNPAID`.
4. `POST /escrow/pay/{ref}` and the mobile-money / card payments for `purpose: BOOKING` work on an `ACCEPTED` booking and set `paymentStatus = PAID`; funds are held until `POST /escrow/release/{ref}`.
5. Unlock phone and exact location only when `paymentStatus = PAID` (decide this rule on the server).
6. Reject / cancel while `UNPAID` must not try to refund anything.

Unchanged: the provider can still use "Ask buyer to pay first" (AWAITING_PAYMENT / PAYMENT_SENT) for offline payments.
