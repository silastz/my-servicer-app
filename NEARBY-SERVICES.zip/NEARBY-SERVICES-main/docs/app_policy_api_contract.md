# App policy API (admin switches: fees, wallet limits, security)

The admin panel controls these values from the backend. Users have no setting for any of them.
The app reads the policy at start-up and whenever it returns to the foreground (at most once every
10 minutes) and keeps the last answer on the phone, so it also applies offline and at the next launch.

## Request

`GET {API_BASE}/app/policy?platform=android|ios|web`  (public, no login needed)

## Response `200`

```json
{
  "data": {
    "fees": {
      "registrationFee": 10000,
      "serviceFee": 5000,
      "freeServiceLimit": 2,
      "boostPlans": [
        { "id": "boost_1d", "days": 1, "price": 2000 },
        { "id": "boost_3d", "days": 3, "price": 5000 },
        { "id": "boost_7d", "days": 7, "price": 10000 }
      ],
      "topUpMin": 1000,
      "topUpMax": 5000000,
      "withdrawMin": 1000,
      "provider": { "collectionPercent": 3, "vatPercent": 18, "payoutFee": 1500, "withdrawMin": 1000, "withdrawMax": 5000000 }
    },
    "payments": {
      "gateway": "SNIPPE"
    },
    "security": {
      "screenCaptureAllowed": false,
      "blockCompromisedDevice": true,
      "playIntegrity": true,
      "blockVpn": false
    }
  }
}
```

(a flat object without `data` is accepted too). **Every field is optional**: a field the admin leaves
out goes back to the app's built-in default.

### fees (TSh)

| Field | Valid range | Used for |
| --- | --- | --- |
| `registrationFee` | 1 - 1,000,000 | Provider registration fee shown before the server answers |
| `serviceFee` | 1 - 1,000,000 | Fee for each extra service, shown before the server answers |
| `freeServiceLimit` | 0 - 100 (whole number) | How many services the one-time registration fee covers. The admin can raise or lower it. **Not sent = 2 (the default).** |
| `boostPlans` | at least one valid plan (`days` > 0, `price` > 0) | Boost packages shown before `GET /boosts/plans` answers |
| `provider.withdrawMin` / `provider.withdrawMax` | 0 or 100 - 100,000,000 (`withdrawMax` >= `withdrawMin` when both are set) | Admin's "from / to" for one withdrawal. 0 = not set: no admin minimum (old `withdrawMin` key, else 1,000) / no maximum. The server must enforce both (400 outside the range). If max < min both are ignored by the app |
| `topUpMin` / `topUpMax` | 100 - 100,000,000 (`topUpMax` >= `topUpMin`) | Wallet top-up amount limits |
| `withdrawMin` | 100 - 100,000,000 | Smallest withdrawal |
| `provider.collectionPercent` / `provider.vatPercent` / `provider.payoutFee` | 0 - 20 / 0 - 50 (both % of the withdrawn amount) / 0 - 1,000,000 (whole TSh, inside the VAT charge) | Two charges taken from the provider **only when they withdraw** (the wallet shows the full amount a buyer paid): the collection fee on its own, plus the VAT charge with the payout fee inside it. 20,000 = 600 collection + 3,600 (1,500 payout + 2,100 VAT), so 15,800 is paid out; if 18% is below the payout fee the charge is the payout fee. Refunds carry the VAT charge only. Shown as two amounts (collection fee, fee), an estimate; the server charges the real ones. See `PROVIDER_FEES_FLOW.md`. Not sent = no fee shown |

Invalid values are ignored (the default is used).

**Free services (`freeServiceLimit`)**: the registration fee pays for this many services; every service after
that needs its own `serviceFee`. Default is **2**. The real check is on the server
(`GET /payments/service-fee` returns `freeLimit` and `needsPayment`, `POST /services` answers 402): when the
admin changes the number, the server must use the same number, and decide what happens to providers who
already posted more services than the new, lower limit (suggested: they keep what they have, and only
new services need a fee). The app shows the number the server sends and uses the policy value only until the server answers.

**The app only displays these numbers and checks the amount a user types. The server MUST still set the
real price and enforce every limit itself** (see `SERVICE_FEE_FLOW.md`): the existing calls
`GET /payments/registration-fee`, `GET /payments/service-fee`, `GET /boosts/plans` stay the real source
for what a user is charged. Keep the policy and those answers in sync (one admin setting should feed both).

### payments

| Field | Valid values | Meaning | If missing / invalid |
| --- | --- | --- | --- |
| `gateway` | `DPO`, `SNIPPE`, `CLICKPESA`, `SELCOM`, `PESAPAL` (case-insensitive; spaces, `_` and `-` ignored, so `Click Pesa` and `pesa_pal` work) | The gateway the admin has switched on for card and mobile-money payments | **`SNIPPE`** (the default) |

The app sends the active gateway as `gateway` in `POST /payments/card/checkout` and `POST /payments/mobile/request`.
The backend must create the checkout / prompt with that gateway, and must **not** trust the app's value alone:
use the admin's current setting, so an old app or a tampered request cannot pick a different gateway.
Payment status (`/payments/status/{ref}`, `/payments/card/status/{ref}`) must be answered by whichever gateway created that payment.

### Admin screen (in the app)

An account whose login answer has `role: "ROLE_ADMIN"` sees **Profile -> Payment Gateway (Admin)**. It shows the five
gateways with the active one marked and Snippe marked as the default, and saves with a confirmation.

| Call | Who | Answer |
| --- | --- | --- |
| `GET /admin/payments/gateway` | `ROLE_ADMIN` only | `{ "gateway": "SNIPPE" }` (`{data:{...}}` also accepted) |
| `PUT /admin/payments/gateway` `{ "gateway": "SELCOM" }` | `ROLE_ADMIN` only | `{ "gateway": "SELCOM" }` |

Rules the server must enforce (the app cannot):
- Answer **403** to anyone who is not an admin. The role is also stored on the phone, so the app only uses it to
  decide whether to *show* the entry; a tampered phone must get nothing from these two calls.
- Accept only `DPO`, `SNIPPE`, `CLICKPESA`, `SELCOM`, `PESAPAL`; reject anything else with 400.
- The saved value is the one `GET /app/policy` returns as `payments.gateway` (one setting feeds both).
- Write an audit log row (who, old value, new value, time). Use the admin's 2FA / re-login if you have it:
  this switch decides where every customer's money goes.
- Payments already created keep their own gateway; only new payments use the new one.

### Admin wallet (in the app, read only)

**Profile -> Admin Wallet** shows the platform's own wallet. It only displays what the server reports; nothing in the
app moves money (no withdraw, no transfer).

| Call | Who | Answer |
| --- | --- | --- |
| `GET /admin/wallet` | `ROLE_ADMIN` only | `{ "balance": 1250000, "held": 300000, "totalIn": 2400000, "totalOut": 1150000, "income": { "registrationFees": 800000, "serviceFees": 450000, "boosts": 300000, "commissions": 850000, "withdrawalFees": 120000, "vat": 21600 } }` (`{data:{...}}` also accepted) |
| `GET /admin/wallet/transactions?limit=50` | `ROLE_ADMIN` only | `[ { "id", "type", "amount", "direction": "IN" or "OUT", "title", "status", "reference", "createdAt" } ]`, newest first |

All amounts are TSh. Same rules as the gateway calls: answer **403** to non-admins, never trust the role stored on the
phone, and audit-log reads if you can. `held` is money in escrow that is not yet the platform's to spend. `income.vat` is VAT collected and owed to the tax authority: shown separately, not income.

### security

| Field | Meaning | If missing |
| --- | --- | --- |
| `screenCaptureAllowed` | `true` = screenshots and screen recording allowed for everyone; `false` = blocked | blocked |
| `blockCompromisedDevice` | `true` = the app refuses to run on rooted / hooked / debugged / repackaged devices | build default (**off** since this version; set `BLOCK_COMPROMISED=true` at build time to default it on) |
| `playIntegrity` | `true` = send a Google Play Integrity token with login, wallet, escrow and payment requests | build default (on) |
| `blockVpn` | `true` = while a VPN is on, the app shows "turn off your VPN" (with a Try again button) instead of working | **off** (VPN allowed) |

Not controllable from here, on purpose (build-time only): `REQUIRE_PINNING` (certificate pinning) and
`EXPECTED_SIGNER_SHA256` (app signing check). Pinning protects the very connection this policy is
downloaded over, and both would let a hijacked admin account weaken every user's protection.

## Notes
- Android: one switch covers both screenshots and screen recording (FLAG_SECURE); it also hides the app in the recent-apps preview.
- `blockCompromisedDevice` and `playIntegrity` take effect from the next launch (the device scan runs at start-up).
- `blockVpn` also works while the app is open: it is re-checked when the policy changes and whenever the app returns to the foreground.
- VPN detection is Android only (iOS has no native scanner, so `blockVpn` has no effect there). Many honest users use a VPN (privacy, travel, public Wi-Fi): switch it on only if you really need it. Not applied to debug builds.
- Not 200 / not JSON / no network: the app keeps the last saved policy (defaults if there is none).
- iOS has no native screenshot handler yet, so `screenCaptureAllowed` has no effect there.
- Protect the admin panel strongly (2FA, audit log): these switches can lower security for all users.

## Support contacts (Help screen)
`GET /api/app/policy` -> `data.support = { phone?, whatsapp?, email? }`. What the admin saved wins; the server env vars `SUPPORT_PHONE`, `SUPPORT_WHATSAPP`, `SUPPORT_EMAIL` are the default. Admin: `GET/PUT /api/admin/support` `{phone, whatsapp, email}` (GET also returns `source` per contact: admin|env|none). Only the contacts that are set are sent; the app hides the rest
(no built-in number or address). Numbers: 9-15 digits, optional leading `+`. The admin sets them in Registration & listing fees
(`PUT /api/admin/settings {supportPhone, supportWhatsapp, supportEmail}`; not sent = unchanged, empty text = cleared;
errors `INVALID_SUPPORT_PHONE`, `INVALID_SUPPORT_WHATSAPP`, `INVALID_SUPPORT_EMAIL`).

## Service categories (admin managed)
`GET /api/app/policy` -> `data.categories = [{id, nameEn, nameSw}]` (active only, in display order; absent = keep the built-in list).
`id` is what the app sends as `?category=` and in `POST/PUT /api/services` (`category`); a new service with an unknown or switched-off
category gets 400 `INVALID_CATEGORY`. Admin: `GET/POST /api/admin/categories`, `PUT/DELETE /api/admin/categories/{id}`
(see the backend docs/APP_STARTUP_CONFIG.md). Errors: `INVALID_CATEGORY_ID`, `CATEGORY_ID_IN_USE`, `INVALID_CATEGORY_NAME`, `CATEGORY_NOT_FOUND`, `CATEGORY_IN_USE`.
