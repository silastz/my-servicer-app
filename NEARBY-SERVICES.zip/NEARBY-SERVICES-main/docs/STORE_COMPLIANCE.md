# Store compliance checklist (Google Play + App Store)

## Done in the code
| Requirement | Where |
| --- | --- |
| In-app account deletion | Profile menu (three dots) -> **Delete account** (`lib/screens/delete_account_screen.dart`). Backend: `GET /api/users/me/delete-check`, `DELETE /api/users/me` (see the backend `docs/APP_STARTUP_CONFIG.md`) |
| Hosted Privacy Policy, Terms, deletion page | Served by the backend: `/legal/privacy`, `/legal/terms`, `/legal/delete-account`. The Help screen opens them (the admin's own links from `/api/app/policy` win; the short in-app text is only an offline fallback) |
| No silent errors | Every handled error goes through `AppLog.e` (`lib/services/app_log.dart`); release builds print nothing and keep only `where: ErrorType` in memory. Plug a crash reporter into `AppLog.onError` |
| No `print` / `debugPrint` in release | All logging goes through `AppLog.d` (debug builds only) |
| Naming | Dart package is now `ungana` (was `jamiiapp`); Flutter `SecurityConfig` is now `ClientSecurityConfig` so it no longer clashes with the backend's `SecurityConfig` |
| Rooted-phone lock-out | `BLOCK_COMPROMISED` now defaults to **off**; the admin can switch it on remotely, or build with `BLOCK_COMPROMISED=true ./tool/build_release.sh` |

## Before you submit
1. Backend `.env`: set `APP_PUBLIC_BASE_URL=https://your.server`, `APP_OPERATOR_NAME=<registered company>`, and the `SUPPORT_*` contacts. Open `/legal/privacy` in a browser and read it.
2. **Have a lawyer review the three pages** (`src/main/resources/legal/*.html`). They describe what the app does today, but they are a draft, not legal advice.
3. Play Console -> App content: Privacy policy URL = `https://your.server/legal/privacy`; Data deletion URL = `https://your.server/legal/delete-account`. Fill the Data safety form to match the privacy page (location, phone, email, photos, ID documents, payments, advertising ID).
4. App Store Connect: Privacy Policy URL = same; the App Privacy "nutrition labels" must match too. Apple also wants the in-app deletion to be easy to find: it is in the profile menu.
5. Ads: AdMob, LevelPlay and Meta Audience Network collect the advertising ID. Declare it in both stores and consider a consent prompt for EEA/UK users.

## Known and deliberately left alone
* The Android application ID is still `com.unganalink.app`. Changing it makes a new app in Play and breaks Firebase / App Links; only change it before the first release.
* Desktop folders (linux/windows/macos) still carry the old `jamiiapp` binary name; they are not shipped.
