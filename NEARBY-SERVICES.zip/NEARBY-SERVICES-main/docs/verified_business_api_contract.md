# Verified Business (backend contract)

Providers only. Separate from the green/blue identity badges: a gold **Verified Business** chip
and the business name appear on the provider's service page and profile. Server enforces; the app displays.
Auth: Bearer token. Base: `/api`.

## Rules
- Caller must have `BLUE_TICK`, else 403 `BLUE_TICK_REQUIRED` (on both calls below and on document types listed here).
- The owner name on the documents must match the name read from the verified ID. Mismatch -> `REJECTED` with a `reason`.
- Admin reviews manually. Store the expiry of the business licence; when it lapses set status `EXPIRED` and stop sending `businessVerified: true`.
- Never expose document numbers to customers.
- If the Blue Tick is lost, drop Verified Business too.

## POST /verification/business
`{ "businessName": "Zeen Spa Ltd" }` -> 2xx. Creates or updates the application. The app calls it before each document upload.

## Documents
Uploaded with the existing `POST /verification/documents` (field `file`, field `type`):
`business_registration` (BRELA), `tin_certificate`, `business_license` (all required), `location_permit` (optional).
`GET /verification/documents` already reports each one's status.

## GET /verification/business
`{ "status": "NONE"|"PENDING"|"VERIFIED"|"REJECTED"|"EXPIRED", "businessName": "...", "reason": "...", "expiresAt": "2027-01-31" }`
Move to `PENDING` once all required documents are in; `VERIFIED` after review.

## Customer-facing
In the seller object of services (`seller`): `businessVerified: true|false` and `businessName` (only when verified).

## Optional perks (not built into the app)
Higher payout limits or better ranking for Verified Business providers.
