# Verified photo (backend contract)

The server must enforce every rule; the app only displays results. Auth: `Authorization: Bearer <token>`. Base: `/api`.

## What the user gets
Profile → **Verify photo** (any signed-in user). The user takes a live camera photo (no gallery).
Once the server marks it VERIFIED, providers see it (with a small blue check) on that user's
requests, **only while Hide My ID is OFF**. With Hide My ID ON, providers see the normal profile image and
the stage name with the Safe badge instead (not this photo). See verified_name_api_contract.md.

## POST /users/me/verified-photo
Multipart, field `file` (jpg/png/webp, max 10 MB). 200/201: `{ "status": "PENDING", "url": "https://..." }`.
A new upload replaces the old one and resets the status to `PENDING` (or `VERIFIED` if you verify automatically).

## GET /users/me/verified-photo
`{ "status": "NONE" | "PENDING" | "VERIFIED" | "REJECTED", "url": "...", "reason": "..." }`
`reason` is shown to the user when `REJECTED`.

## Provider-facing buyer object (`tx.buyer`)
- `verifiedPhotoUrl`: send **only** when status is `VERIFIED` **and** the buyer's `hideMyId` is false. Never send it otherwise.
- When `hideMyId` is true, send the normal `avatarUrl` and `stageName`, but no real name (see verified_name_api_contract.md).

Suggested checks: face detected, one person, not a photo of a screen; optionally match against the NIDA selfie. Keep rejected photos for audit.
