# Ads settings (AdMob / Facebook / ironSource) - API contract

The app shows ads from three networks. The admin chooses, from the app (Profile > Admin > Ads),
which network each page uses and which ad IDs to request. The server only stores one JSON
document and hands it out. Nothing in it is secret (ad unit IDs are inside every app), so users
can read it.

## Endpoints

| Call | Who | Response |
|---|---|---|
| `GET /app/ads?platform=android\|ios\|web` | anyone, no login (like `/app/policy`) | config (below) |
| `GET /admin/ads/config` | `ROLE_ADMIN` only, **403** for anyone else | config |
| `PUT /admin/ads/config` (body = config) | `ROLE_ADMIN` only, **403** for anyone else | config as saved |

`{ "data": { ... } }` wrappers are also accepted. The app asks `/app/ads` on start and whenever it
returns to the front (at most every 10 minutes), keeps the last answer on the phone and uses
built-in defaults (AdMob test ads) until it has had one. If nothing was ever saved, return `{}`.

## config

```json
{
  "enabled": true,
  "testMode": false,
  "defaultProvider": "ADMOB",
  "autoFallback": true,
  "pages": {
    "home":            { "enabled": true,  "provider": "DEFAULT" },
    "serviceDetails":  { "enabled": true,  "provider": "FACEBOOK" },
    "search":          { "enabled": true,  "provider": "IRONSOURCE" },
    "providerProfile": { "enabled": true,  "provider": "DEFAULT" },
    "chats":           { "enabled": false, "provider": "DEFAULT" },
    "videoReward":     { "enabled": true,  "provider": "ADMOB" }
  },
  "units": {
    "admob": {
      "android": { "banner": "ca-app-pub-1234567890123456/1234567890", "native": "", "rewarded": "" },
      "ios":     { "banner": "", "native": "", "rewarded": "" }
    },
    "facebook": {
      "android": { "banner": "1234567890123456_1234567890123456", "native": "", "rewarded": "" },
      "ios":     { "banner": "", "native": "", "rewarded": "" }
    },
    "ironsource": {
      "android": { "appKey": "abc12345", "banner": "unit12345", "native": "Home Feed", "rewarded": "unit67890" },
      "ios":     { "appKey": "", "banner": "", "native": "", "rewarded": "" }
    }
  }
}
```

| Field | Meaning | If missing / invalid |
|---|---|---|
| `enabled` | master switch, false = no ads anywhere | on |
| `testMode` | true = Google sample ads (AdMob), test requests (Facebook). Facebook and ironSource still need real IDs | **true** (safe) |
| `defaultProvider` | `ADMOB`, `FACEBOOK`, `IRONSOURCE`, `INHOUSE` or `ALL` (case-insensitive). `ALL` = mixed: every ad spot starts with a random one of the networks that are set up and falls back to the others | `ADMOB` |
| `autoFallback` | when a network has no ID or no ad, try the default, then the others | on |
| `pages.<page>.enabled` | false = no ads on that page (for `videoReward`: the video plays without an ad) | on |
| `pages.<page>.provider` | a network, `INHOUSE`, `ALL`, or `DEFAULT` = follow `defaultProvider` | `DEFAULT` |
| `house` | list of the admin's own ads, see "In-house ads" below | none |
| `units.<network>.<platform>` | IDs per network and platform (`android`, `ios`) | blank = not available on that network |

Pages: `home`, `serviceDetails`, `search`, `providerProfile`, `chats`, `videoReward`.
Formats per page are fixed by the app (see ADS.md).

ironSource specifics: `appKey` is the LevelPlay app key; `banner` and `rewarded` are LevelPlay ad
unit IDs; `native` is an **optional placement name** (the native ad is requested by placement).
A new `appKey` only takes effect after the app restarts. The AdMob **app ID** is not part of this
document: it lives in `AndroidManifest.xml` / `Info.plist` and needs an app update to change.

## Server rules
- `PUT` replaces the whole document. Validate, then store it as one JSON value (one row).
- Reject with 400 an unknown `defaultProvider` / `pages.*.provider`, and IDs that are not shaped like the network's:
  - AdMob unit: `^ca-app-pub-\d{16}/\d{10}$` (an app ID contains `~`, refuse it)
  - Facebook placement: `^(?:[A-Za-z0-9_]{3,40}#)?\d{8,20}_\d{8,20}$`
  - ironSource `appKey` / banner / rewarded: `^[A-Za-z0-9]{5,40}$`; native placement: `^[A-Za-z0-9 _\-]{1,40}$`
  - blank is always allowed; max 64 characters
- Write an audit entry (who, when, which fields changed). Changing `testMode` to false is the "go live" switch.
- `GET /app/ads` may be cached for a minute or two; it must never include anything else from the admin store.


## In-house ads (`house`)

The admin can paste their own ads as JSON (Admin > Ads > "In-house ads"). The app checks the JSON
before saving; the server just stores `house` with the rest of the config and returns it unchanged
in `/app/ads` (it may validate the same rules, but must not rewrite it).

```json
"house": [
  {
    "id": "plumbers-promo",
    "title": "Plumbers near you",
    "body": "Book a verified plumber today.",
    "cta": "Book now",
    "imageUrl": "https://example.com/promo.jpg",
    "url": "https://example.com/plumbers",
    "formats": ["banner", "native"],
    "pages": ["home", "search"],
    "platforms": ["android", "ios"],
    "countries": ["TZ", "KE"],
    "title_TZ": "Mafundi bomba karibu nawe",
    "body_TZ": "Weka oda ya fundi aliyethibitishwa leo.",
    "cta_TZ": "Weka oda",
    "title_KE": "Plumbers in Nairobi",
    "cta_KE": "Book in Nairobi",
    "weight": 3,
    "start": "2026-11-01T00:00:00Z",
    "end": "2026-11-30T23:59:59Z",
    "enabled": true
  },
  {
    "id": "video-promo",
    "title": "Grow your business",
    "imageUrl": "https://example.com/video-promo.jpg",
    "url": "https://example.com/join",
    "formats": ["rewarded"],
    "rewardSeconds": 5
  }
]
```

| Field | Rule | If missing |
|---|---|---|
| `id` | required, unique, letters / numbers / `-` / `_`, max 40 | ad rejected |
| `title` | required, max 60 characters | ad rejected |
| `body` | max 140 characters | none |
| `cta` | button text, max 24 characters | `Open` |
| `imageUrl`, `url` | required, full `https://` link, max 500, no `user:pass@` | ad rejected |
| `formats` | `banner`, `native`, `rewarded` (the full-screen ad before a provider video) | `banner` + `native` |
| `pages` | `home`, `serviceDetails`, `search`, `providerProfile`, `chats`, `videoReward` | every page that shows one of the ad's `formats` (banner / native: the first five; rewarded: `videoReward`) |
| `platforms` | `android`, `ios` | both |
| `countries` | list of 2-letter ISO codes (`TZ`, `KE`, ...). Only people in those countries see the ad. An ad with a list is not shown while the person's country is unknown | every country |
| `title_XX`, `body_XX`, `cta_XX`, `imageUrl_XX`, `url_XX` | the same field for country `XX` (e.g. `title_TZ`, `cta_KE`; `TZtitle` / `TZ_cta` also read). Same rules as the plain field (max length, `https`). Blank = use the plain field | plain field everywhere |
| `rewardSeconds` | rewarded only: whole number 3 to 30, seconds before the reward is earned | 5 |
| `weight` | whole number 1 to 100: an ad with weight 3 shows three times as often as weight 1 | 1 |
| `start`, `end` | ISO date-time; the ad shows only between them (`end` after `start`) | no limit |
| `enabled` | false = paused | true |

**Country.** The phone uses the country the app detected (network location) or the person chose in
Settings. `countries` decides who sees an ad; `title_XX` etc. decide what that country reads. They are
independent: an ad with `title_KE` and no `countries` shows to everyone, Kenya sees the Kenyan title.
The server must keep the `title_XX` style keys exactly as sent (it must not drop unknown keys).

At most 20 ads. A phone drops an invalid ad and keeps the valid ones. In-house ads are used where
the admin picks `INHOUSE` (default network or one page) and, with `autoFallback` on, as the last
network tried when the others have no ID or no ad. They handle every format: banner and native
inside the page, and `rewarded` as a full-screen page (picture, title, text, button, countdown)
before a provider video; closing it before `rewardSeconds` means the video does not play.
Every in-house ad carries an "Ad" label, and a tap opens `url` in the phone's browser.
