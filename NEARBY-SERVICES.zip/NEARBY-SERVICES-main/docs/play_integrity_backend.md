# Play Integrity: backend verification

The app (Android, release) sends two headers on login, register, OTP, password reset, wallet, escrow, payments and boost calls:

* `X-Integrity-Token`: token from Google Play Integrity
* `X-Integrity-Nonce`: random value the app bound to the token

If a phone has no Google Play Services the headers are simply absent. The app never blocks the user for this;
**your server decides**. Recommended rollout: (1) log only, (2) enforce on withdraw / escrow release / payments,
(3) require for login when you are confident. Absent token => allow low-risk calls, require extra proof (OTP) for money calls.

## Setup (once)
1. Play Console > your app > Release > App integrity > link a Google Cloud project, enable the *Play Integrity API*.
2. Create a service account with access, download the JSON key (keep it on the server only).
3. Note the **App signing key certificate SHA-256** (also used as `EXPECTED_SIGNER_SHA256` for the in-app tamper check;
   write it as lowercase hex without colons).

## Verify on the server (Spring Boot / Java sketch)
```java
// build.gradle: com.google.apis:google-api-services-playintegrity + google-auth-library-oauth2-http
PlayIntegrity pi = new PlayIntegrity.Builder(transport, json, new HttpCredentialsAdapter(creds))
    .setApplicationName("ungana").build();
DecodeIntegrityTokenResponse r = pi.v1()
    .decodeIntegrityToken("com.unganalink.app", new DecodeIntegrityTokenRequest().setIntegrityToken(token))
    .execute();
TokenPayloadExternal p = r.getTokenPayloadExternal();

boolean ok =
    p.getRequestDetails().getRequestPackageName().equals("com.unganalink.app")
 && p.getRequestDetails().getNonce().equals(nonceHeader)                       // also: single-use, <= 2 min old
 && System.currentTimeMillis() - p.getRequestDetails().getTimestampMillis() < 120_000
 && "PLAY_RECOGNIZED".equals(p.getAppIntegrity().getAppRecognitionVerdict())    // genuine, Play-installed build
 && p.getDeviceIntegrity().getDeviceRecognitionVerdict().contains("MEETS_DEVICE_INTEGRITY");
```
Rules: store used nonces for a few minutes and reject repeats (replay protection); never trust a verdict the app computes itself;
treat `UNRECOGNIZED_VERSION` as suspicious but allow side-loaded testers while you roll out.

## Stronger version (optional)
Have the server issue the nonce (`GET /auth/nonce`, one-time, ~2 min) and make the app use it.

## iOS
Apple's equivalent is App Attest (DeviceCheck). Not included in this build.
