# Multi-currency: what the backend must do

The app now detects the user's country (already done by `LocationService.refreshCountry`)
and shows every price, fee, wallet amount and mobile-money number in that country's money.
**The app never converts amounts.** Amounts are always in the account's own currency, and
the server is the only source of truth for what is charged.

| Country | Currency | Symbol | Dial |
|---|---|---|---|
| Tanzania (home market, default) | TZS | TSh | +255 |
| Kenya | KES | KSh | +254 |
| Uganda | UGX | USh | +256 |
| Rwanda | RWF | FRw | +250 |
| Burundi | BIF | FBu | +257 |
| DR Congo | CDF | FC | +243 |

## Every request
The app sends `X-Country` (e.g. `KE`) and `X-Currency` (e.g. `KES`).

## Sign-in / sign-up response
Return the wallet currency so a user who signs in on a phone in another country keeps
their own money: `"currency": "TZS"` (or `"country": "TZ"`). The app saves it and stops
following the detected country. If the response has none, the app keeps the currency it
had detected at that moment, which is wrong for someone signing in abroad, so please send it.

## Amounts
Everything the app displays or sends is a whole number in the account currency:
service prices, `salePrice`, boost plans, registration / service fees, top-up and
withdrawal limits (`/app-policy`), provider fees, earnings, wallet balance, offers.
Per-country values must come from the server (a KES user must get KES fees, not TZS ones).

## Payments / mobile money
The app now accepts a valid mobile number of any supported country and sends it as digits
with the country code (`254712345678`). Choosing and routing the gateway per country
(M-Pesa KE, MTN/Airtel UG, MTN/Airtel RW, ...) is a backend job: today's methods in the app are the
Tanzanian wallets.

## Changing country / currency in Settings
`PUT /users/me/currency` with `{"country": "KE", "currency": "KES"}`, answer 2xx to accept.
The app switches its display only after a 2xx. Refuse with a clear message when the change is not
allowed (for example while the wallet still holds a balance or a withdrawal is pending); the app shows
that message. The app never converts a balance, so the server decides what happens to existing money.
Signed-out users can pick a country in Settings too; that is saved on the phone only.
