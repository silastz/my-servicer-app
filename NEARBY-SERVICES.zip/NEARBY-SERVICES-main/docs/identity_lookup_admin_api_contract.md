# ID name check login (BRELA) - admin API contract

The mobile app is only a remote control (`lib/screens/admin_identity_lookup_screen.dart`, Profile > Admin >
"ID Name Check Login"). The server stores the login the lookup service needs (to find the name registered for a
NIN, see verified_name_api_contract.md), uses it for every lookup, and decides what is allowed. Every call is
`ROLE_ADMIN` only; answer **403** to anyone else.

## The password is write-only
- The server **never returns** the password. It returns `passwordSet` so the app can show "Saved".
- On `PUT`, a field that is **missing** (the app leaves blank ones out) means "keep the saved value".
- Store the password **encrypted at rest** (AES-256-GCM, key in an environment variable / secret store, not in the
  database). Never log request bodies on these endpoints. Never put the login in `/app/policy` or any endpoint a
  normal user can read.
- Audit each change and each test (who, when, which fields changed). Never write the values.

## Endpoints

| Call | Body | Response |
|---|---|---|
| `GET /admin/identity-lookup` | - | config |
| `PUT /admin/identity-lookup` | `{ "username": "bob", "password": "..." }` (either may be missing) | config, as now saved |
| `POST /admin/identity-lookup/test` | `{}` | `{ "success": true, "message": "Login works." }` |

`{ "data": { ... } }` wrappers are also accepted.

### config
```json
{ "username": "bob", "passwordSet": true, "source": "ADMIN", "updatedAt": "2026-10-24T08:30:00Z" }
```
`source`: `ADMIN` (saved in the app), `CONFIG` (the server's own first-install login, used only until an admin saves
one), `NONE` (nothing yet; new name checks stay PENDING).

### Errors `{ "message": "<CODE>" }`
`USERNAME_INVALID` (letters, numbers and . _ @ + - only, 1-100), `PASSWORD_INVALID` (max 200, no control
characters), `CREDENTIALS_INCOMPLETE` (a login needs both; the first save must send both unless the server already has
a fallback login), `NO_CHANGES` (nothing sent).

### Test
Signs in to the lookup service with the saved login and reports the result. It looks up **no** NIN. Messages never
contain the username or password.

## Effect of a change
It applies on the **next lookup, no restart**: the server ends its current session and signs in again with the new
login. If the login is wrong or missing, name checks do not fail: the name is saved as `PENDING` (see
verified_name_api_contract.md) until the admin fixes it.

Reference implementation (Java / Spring): `IdentityLookupAdminService`, `LookupCredentialProvider`, `SecretBox`,
`BrelaNinRegistry` in the backend package `com.unganalink.verification`.
