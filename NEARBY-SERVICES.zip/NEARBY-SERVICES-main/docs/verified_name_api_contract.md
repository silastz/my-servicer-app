# Verify My Legal Name + display rules (backend contract)

Server enforces; the app only displays. Auth: Bearer token. Base: `/api`.

## Verify My Legal Name
The user types their **legal name exactly as on their ID** in Profile -> **Verify your identity** (Identity Verification screen).
The typed name is only a claim. The server compares it with the approved ID documents (and, for an invitation, with the
official identity source for the NIN) and sets the status. The app shows a name as "verified" only when status is VERIFIED.
Profile -> **Verify My Legal Name** just shows the status and opens Identity Verification.

### Auto-verify when the ID front and back are approved
As soon as the ID photos (front, and back when the ID has one) are approved, the **server sets the legal name to VERIFIED by itself**, using the name read from the approved ID. The selfie is not needed for this, and it does not wait for the Green badge. The same applies when a trusted invitation is accepted (name from the official identity source for the NIN). The user types nothing.
- Do it in the same step that approves the ID documents, or within seconds. The app re-checks `GET /users/me/verified-name` every 5 s for about a minute on the Identity Verification screen, and on every refresh.
- A name typed earlier is replaced by the server's own spelling from the ID. If it differed, the ID wins (no REJECTED state for a verified identity).
- `POST /users/me/verified-name` once the status is VERIFIED returns `ALREADY_VERIFIED`.
- Fallback: if the server cannot read the name from the ID, it leaves the status NONE/PENDING and keeps accepting `POST /users/me/verified-name`. After about a minute of waiting the app shows a "Fill in your legal name" field; the typed name is only a claim and is checked as before.
- Until the status flips, the app shows "Confirming with your ID" and hides the name form.

### Order in the app
1. **Step 1:** the user saves the legal name and the 20-digit NIN (`POST /users/me/verified-name`).
2. **Step 2:** only then the ID front and back are uploaded (the app asks to save step 1 first; the server should also refuse ID photos before a name and NIN exist).
When the ID photos are approved, the server checks the name and NIN against the ID and sets the name to VERIFIED.

### Verify at once when the name matches the NIN
When `POST /users/me/verified-name` arrives with a NIN, the server looks up the name registered for it (official identity source, same `lookup(nin)` interface and matching rules as in invitation_api_contract.md) **before** answering:
- Match -> save the name using the registered spelling, status **VERIFIED**, answer 2xx. The app re-reads `GET /users/me/verified-name` straight after and shows "verified". No ID photo is needed for the legal name (Green still needs the ID or an invitation).
- No match -> `NAME_MISMATCH` (4xx); nothing is saved. Never say which part failed or return the registered name.
- NIN not in the source -> `NIN_NOT_FOUND`; nothing is saved.
- Source down or timing out -> save as PENDING (do not fail); the name is then verified by the ID-photo path above, or by retrying the lookup later.
- Rate-limit per account and per NIN (each attempt reveals a match yes/no). Store only: NIN, result, time, source reference id.

### POST /users/me/verified-name
Body: `{ "fullName": "Amina Juma Mwanga", "nidaNumber": "<20 digits>" }`. Extra errors: `INVALID_NIN` (not exactly 20 digits), `NIN_ALREADY_USED`. The NIN is never returned to the app; the app keeps only a flag that it was saved. 2xx on save (status becomes PENDING, or VERIFIED/REJECTED if you check at once).
Errors `{ "message": "<CODE>" }`: `NAME_INVALID` (letters, spaces, . ' - only, 2-60 chars), `NAME_LOCKED` / `ALREADY_VERIFIED` (a legal name cannot be changed from the app).
A new submission while PENDING or REJECTED replaces the old one. Compare names with the matching rules in invitation_api_contract.md.
Rate-limit submissions per account so the endpoint cannot be used to guess other people's names.

### GET /users/me/verified-name
`{ "status": "NONE"|"PENDING"|"VERIFIED"|"REJECTED", "name": "...", "reason": "..." }`
`name` only when VERIFIED (the server's own spelling, which is what providers see). `reason` shown on REJECTED. Never return the ID number.

## What a provider sees for a buyer (`tx.buyer`)
| Buyer's Hide My ID | Name | Photo | Badge |
|---|---|---|---|
| ON  | `stageName` | normal profile image (`avatarUrl`) | Safe (`safeBadge: true`) |
| OFF | `verifiedName` (if VERIFIED), else `stageName` | `verifiedPhotoUrl` (if VERIFIED), else `avatarUrl` | blue check on legal name / photo |

Server rules:
- Hide My ID ON: do **not** send `verifiedName`, `verifiedPhotoUrl`, `name`, `fullName`. Send `stageName`, `avatarUrl`, `safeBadge`.
- Hide My ID OFF: send `verifiedName` / `verifiedPhotoUrl` only when their status is VERIFIED.
- The app also ignores the legal name/photo when `hideMyId` is true, but the server is the real protection.
- This applies to buyers as seen by providers. Providers' own NIDA names stay private from buyers (README privacy rule).
