# Security hardening: anti-sniffing and hiding the server address

## The honest limit
A server address **cannot be fully hidden** from someone who watches the network of a device they control:
DNS lookups and the TLS SNI field reveal the host name, and the IP is visible to anyone on the path.
So the goal is layers: (1) make the address hard to *find* statically, (2) make traffic useless to *read or replay*,
(3) make the server *safe even if the address is known*. Layer 3 is what actually protects you.

## What is built into the app (this repo)
| Threat | Defence | Where |
|---|---|---|
| Proxy sniffers (Burp, Charles, mitmproxy, Fiddler) | Client ignores system/Wi-Fi proxy (`findProxy = DIRECT`) | `lib/security/secure_http.dart` |
| MITM with fake/user-installed certificate (HttpCanary, Packet Capture…) | Certificate pinning (Dart context trusts only `assets/certs/pinned_ca.pem`); Android trusts system CAs only, optional SPKI pin-set | `secure_http.dart`, `res/xml/network_security_config.xml` |
| Plain-text (http) sniffing | Cleartext refused in Dart, Android (`cleartextTrafficPermitted=false`), iOS (ATS) | same + `Info.plist` |
| Reading URL from the APK/IPA (`strings`, grep, jadx) | URL not in code as text (XOR-encoded), can be injected at build time with `--dart-define=API_ORIGIN`, Dart `--obfuscate`, R8 minify | `client_security_config.dart`, `tool/build_release.sh` |
| Frida/Xposed hooking, debugger, root | Native scan; app refuses to run (release only) | `MainActivity.kt`, `device_integrity.dart` |
| Screen recording / screenshots / recents preview | `FLAG_SECURE` (release only) | `MainActivity.kt` |
| Proxy / VPN / user-CA present | Detected (reported in `DeviceIntegrity.last`); traffic already protected | `device_integrity.dart` |
| Search-engine / referrer leaks (web build) | `noindex` + `no-referrer` meta | `web/index.html` |
| Repackaged / modified APK | Startup check that the signing certificate matches `EXPECTED_SIGNER_SHA256` (off until you set it) | `device_integrity.dart` |
| Frida attached after launch | Re-scan every time the app returns to the foreground | `integrity_guard.dart` |
| Fake clients / bots calling your API | Play Integrity token on sensitive calls, verified by the backend (`docs/play_integrity_backend.md`) | `attestation.dart` |
| Backup extraction | `allowBackup=false` (already) | manifest |

### Setup you must do once
1. Put your CA PEM into `assets/certs/pinned_ca.pem` (see `assets/certs/README.txt`), then build with `REQUIRE_PINNING=true`.
   Pin the intermediate/root CA, not the leaf, and keep a backup pin, otherwise certificate renewal can lock every user out.
2. (Optional) enable the `<pin-set>` in `network_security_config.xml`.
3. Build with `API_ORIGIN=https://your.server ./tool/build_release.sh appbundle`.
4. To change the built-in fallback URL: `dart run tool/obfuscate_url.dart https://your.server`.
5. Never commit `key.properties`, `build/symbols`, or a PEM private key.

### Not covered (needs native work / a paid SDK)
* iOS jailbreak/hook detection (pinning, no-proxy and ATS already work on iOS). Consider freeRASP or similar.
* Remote attestation (Google Play Integrity / Apple App Attest): the strongest way to make the server accept only your genuine app. Verify the token on the backend.
* Images/video use the platform network stack, so they are covered by the Android network security config, not by the Dart pinned client.
* Anyone who runs the app on their own device can still see what it connects to. Treat the address as public knowledge and secure the server.

## Server side (where it matters most)
### 1. Hide the real origin IP
* Put the domain behind **Cloudflare** (or another reverse proxy/CDN), proxied (orange cloud). The public IP becomes the CDN's.
* On the origin firewall allow ports 80/443 **only from the CDN IP ranges**; block everything else. Use *Authenticated Origin Pulls* (mTLS) so only the CDN can talk to the origin.
* Remove old DNS records / certificates that reveal the origin IP (check crt.sh, SecurityTrails history, `mail.` / `ftp.` / `dev.` subdomains). Send mail from a different IP.
* Use a wildcard certificate so internal subdomains don't appear in public Certificate Transparency logs.
* Keep SSH off the public internet (VPN / allowlist / key-only).

### 2. Don't advertise the API
* Disable Swagger/OpenAPI and actuator in production. Spring Boot:
  ```properties
  springdoc.api-docs.enabled=false
  springdoc.swagger-ui.enabled=false
  management.endpoints.web.exposure.include=health
  management.endpoint.health.show-details=never
  server.error.include-stacktrace=never
  server.error.include-message=never
  server.server-header=
  ```
* Return generic errors; no stack traces, framework names or versions.
* Serve `robots.txt` with `Disallow: /` and send `X-Robots-Tag: noindex, nofollow` on API responses.
* Use unguessable ids (UUIDs) and uniform 401/404 responses so endpoints cannot be enumerated.
* Don't put the host name in public docs/README (done in README of this repo; also review `docs/*.pdf`).

### 3. Nginx example
```nginx
server_tokens off;                       # hide nginx version
more_clear_headers Server X-Powered-By;  # (headers-more module)

# Reject requests that don't use your host name (scanners hitting the bare IP)
server { listen 443 ssl default_server; ssl_reject_handshake on; }

server {
  listen 443 ssl http2;
  server_name api.example.com;
  ssl_protocols TLSv1.2 TLSv1.3;
  add_header Strict-Transport-Security "max-age=63072000; includeSubDomains; preload" always;
  add_header X-Content-Type-Options nosniff always;
  add_header X-Frame-Options DENY always;
  add_header Referrer-Policy no-referrer always;
  add_header X-Robots-Tag "noindex, nofollow" always;
  add_header Content-Security-Policy "default-src 'none'; frame-ancestors 'none'" always; # API responses only

  autoindex off;
  location ~ /\.(?!well-known) { deny all; }                       # .git, .env ...
  location ~* \.(env|bak|sql|old|swp|zip|tar|gz|log)$ { deny all; }

  limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;       # put at http{} level
  location /api/ { limit_req zone=api burst=20 nodelay; proxy_pass http://127.0.0.1:8080; }
  location /api/auth/ { limit_req zone=api burst=5 nodelay; proxy_pass http://127.0.0.1:8080; }
}
```
Add **fail2ban** for repeated 401/404 bursts and enable the Cloudflare WAF + bot-fight mode.

### 4. Make a known address useless
* Short-lived JWT + refresh token; rotate on use; revoke on logout/password change (the app already clears the session on 401).
* Rate-limit and lock out OTP/login per phone, per IP and per device.
* Verify a Play Integrity / App Attest token on sensitive endpoints (login, payments, escrow, withdrawals).
* Never trust the client: authorise every object access on the server (IDOR checks), validate all input, log and alert on anomalies.
* Encrypt secrets (DB, OneSignal REST key, payment keys) on the server only. **Nothing secret may live in the app**; anything in the app is extractable.

### 5. DNS / TLS privacy (optional extras)
* Enable **Encrypted Client Hello (ECH)** (Cloudflare supports it) so SNI isn't visible in TLS handshakes.
* Use DNSSEC and CAA records. Users on Private DNS (DoH/DoT) hide lookups from the local network, but not from their own device.
* Consider rotating to a fresh domain/subdomain if it leaks; because the app reads it from `API_ORIGIN`, a rebuild is enough.

## Verify
* Point Burp/mitmproxy at a test phone: the app should fail to connect (pinning) rather than show traffic.
* `strings app-release.apk lib/arm64-v8a/libapp.so | grep -i yourdomain` should find nothing but the manifest deep-link host (required by Android App Links).
* Scan your own server: `nmap`, `curl -I`, securityheaders.com, SSL Labs.
