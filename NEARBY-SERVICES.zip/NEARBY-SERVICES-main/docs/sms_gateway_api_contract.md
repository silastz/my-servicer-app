# SMS gateway (Meseji / Beem Africa) - admin API contract

The mobile app is only a remote control (`lib/screens/admin_sms_gateway_screen.dart`). The
server stores the credentials, sends the SMS (login OTP, alerts) and decides which provider
to use. Every call is `ROLE_ADMIN` only; answer **403** to anyone else.

Default provider: `MESEJI` (when nothing is saved or the value is unknown).

## Secrets are write-only
- The server **never returns** an API key, secret key or password. It returns booleans
  (`apiKeySet`, `secretSet`, `passwordSet`) so the app can show "Saved".
- On `PUT`, a secret field that is **missing** (the app leaves blank ones out) means "keep the
  saved value". Store secrets encrypted at rest; never log request bodies.
- Do not put these values in `/app/policy` or any endpoint a normal user can read.

## Endpoints

| Call | Body | Response |
|---|---|---|
| `GET /admin/sms/config` | - | config (below) |
| `PUT /admin/sms/config` | update (below) | config (below), the values now saved |
| `POST /admin/sms/test-connection` | `{ "provider": "BEEM" }` | `{ "success": true, "message": "Beem connected. Balance: 120 credits." }` |
| `POST /admin/sms/test-send` | `{ "provider": "MESEJI", "phone": "+255712345678" }` | `{ "success": true, "message": "Test SMS sent." }` |

`{ "data": { ... } }` wrappers are also accepted.

### config
```json
{
  "defaultProvider": "MESEJI",
  "autoFailover": true,
  "meseji": { "apiKeySet": true, "passwordSet": true, "senderId": "UNGANA", "email": "me@x.com", "costPerSms": 15 },
  "beem":   { "apiKeySet": false, "secretSet": false, "senderId": "INFO", "costPerSms": 15 }
}
```

### update
```json
{
  "defaultProvider": "BEEM",
  "autoFailover": true,
  "meseji": { "apiKey": "optional", "senderId": "UNGANA", "email": "me@x.com", "password": "optional", "costPerSms": 15 },
  "beem":   { "apiKey": "optional", "secretKey": "optional", "senderId": "INFO", "costPerSms": 15 }
}
```

## Automatic failover (`autoFailover`, default true)
When sending with the chosen provider fails, send the SAME message once with the other
provider, using the OTHER provider's own sender ID, if its credentials are saved.
- Do not retry a bad phone number or an over-long message (the other provider rejects it too).
- Record the provider that really sent it (delivery checks must ask that one) and log the switch.
- `test-send` must NOT fail over, so the admin sees the tested provider's real result.
- Both fail -> report failure with both reasons.

## Server rules
- `defaultProvider` must be `MESEJI` or `BEEM`; reject anything else (400).
- Refuse to make a provider the default while its credentials are incomplete
  (Meseji: api key + sender; Beem: api key + secret + sender).
- Beem `senderId`: max 11 chars, letters/numbers/spaces, and it must be approved in the Beem
  dashboard. `costPerSms`: 0 - 100000.
- `test-connection` logs in / reads the balance with the saved credentials and sends no SMS.
  `test-send` sends one real SMS: rate-limit (e.g. 5/hour per admin), write an audit entry with
  the phone number partly hidden.
- Provider calls: Beem `POST https://apisms.beem.africa/v1/send` (Basic auth `apiKey:secret`),
  balance `GET https://apisms.beem.africa/public/v1/vendors/balance`; Meseji
  `POST {api_url}/sms/send` with `x-api-key`.
- Send every SMS with the chosen default provider and ITS OWN sender ID (the two are not
  interchangeable).
