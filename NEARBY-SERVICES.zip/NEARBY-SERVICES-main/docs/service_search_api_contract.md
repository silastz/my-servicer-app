# Service search (`GET /services?query=...`)

The app sends what the person typed as `query`. For the best results the **server** should match it
against all of these, not only the title:

| Searched | Notes |
|---|---|
| `title` | |
| `description` (full text) | |
| `shortDescription` | |
| `features` (each item: Soup, Pizza, Eggs ...) | the seller's own list |
| `otherLanguage` | free text from the publish/edit form, e.g. `kinyozi, kunyoa, kusafisha nywele`. **Search only** - never return it to buyers' screens, never show it in the UI |
| seller `stageName` and `businessName` | |
| `category` (English and Swahili words) | |
| `city` / region | |

Rules:
- **Partial words** match ("plum" finds "Plumbing", "pizz" finds the feature "Pizza").
- Several words: **every** word must be found somewhere in the text above, in any order.
- Case, accents and punctuation are ignored.
- **Sensitive (18+) services** must NOT match on a part of a word: only a whole word (the app enforces this
  again on the phone, see `StrictMatch`).

## What the app does on top
On the first page of a text search the app also adds services it already has (from Home, categories,
earlier searches) whose description, features, provider name, category or city match the words typed
(`ServiceText.localMatches`, `lib/models/service_search.dart`). They respect the chosen category and city,
blocked sellers and the 18+ setting. This only helps for services the app has already loaded: it cannot
find a service the server never sent, so the server rules above are the real fix.

## `otherLanguage` field
`POST /services` and `PUT /services/{id}` now accept `otherLanguage` (string, max 200 chars, optional, empty string clears it).
Store it on the service, index it with the other searched fields, and return it on the seller's own service JSON so the edit
form can load it back. The app also searches it locally (`ServiceText.haystack`).
