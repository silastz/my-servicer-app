# Trusted invitation API (backend contract)

The app is wired to these endpoints. The server must enforce every rule; the app only displays results.
All calls use `Authorization: Bearer <token>`. Base: `/api`.

## POST /verification/invitations
Body: `{ "inviteePhone": "+255712345678" }`
Success 200: `{ "code": "AB12CD", ... }` (the app shows `<inviterUserId>-<code>` to the inviter).

Server rules:
- Caller must currently have `GREEN_BADGE` or `BLUE_TICK` (verified identity), else 403 `INVITER_NOT_VERIFIED`.
- Reject self-invite (`SELF_INVITE`), invitee already verified (`ALREADY_VERIFIED`), same phone already invited (`ALREADY_INVITED`).
- Rate-limit per inviter (`INVITE_LIMIT_REACHED`, suggested 5 open invitations).
- Code: random, single use, expires (suggested 14 days), stored with inviter id and invitee phone.

## GET /verification/invitations
Returns a list (or `{ "invitations": [...] }`) of `{ code, status: PENDING|ACCEPTED|EXPIRED|CANCELLED, direction: SENT|RECEIVED, name?, phone?, inviterName? }`.

In-app invitations: rows with `direction: RECEIVED` and `status: PENDING` are those whose invited phone matches the caller's verified phone. They must include the full `code` (with inviter id prefix) and `inviterName` (stage name). The app lists them on the accept screen ("Use code") and shows a count on the Profile entry. Optionally also send a push notification when an invitation is created for a registered phone.

## POST /verification/invitations/accept
Body: `{ "code": "123-AB12CD" }` (the code includes the inviter id prefix). No NIN and no name are sent here: the server uses the legal name and NIN the invitee saved in Identity Verification Step 1 (`POST /users/me/verified-name`, see verified_name_api_contract.md).

Server rules, in one transaction:
- Code exists, unused, not expired, and the inviter still has `GREEN_BADGE` or `BLUE_TICK` (`INVITE_INVALID`).
- The accepting account's phone matches the invited phone (`INVITE_PHONE_MISMATCH`).
- The account has a saved legal name and NIN (`NAME_REQUIRED`: the app tells the user to save them in Identity Verification). The 20-digit and not-used-elsewhere checks (`INVALID_NIN`, `NIN_ALREADY_USED`) happen when they are saved.
- Identity check (see below) passes. Otherwise nothing is saved and the invitation stays `PENDING`.
- Then: set the accepter's badge to `GREEN_BADGE` (identity only; an invitation never gives `BLUE_TICK`, which is Verified Business), mark the invitation `ACCEPTED`, and write a record linking inviter and invitee ("vouched for") for audit. Keep a Blue badge if the accepter already has it.

## Identity check: does the NIN belong to this name?
The server asks an **official identity source** for the name registered to the NIN and compares it with the saved legal name.
Use NIDA's approved verification service or a licensed identity provider. Do not scrape another portal, and keep TLS verification on.
Put the source behind one interface so it can be swapped: `lookup(nin) -> { found, firstName, middleName, lastName }`.

Matching rules (server side):
1. Normalize both sides: Unicode NFKD, strip accents, lowercase, remove everything except letters and spaces, collapse spaces.
2. Split the saved legal name into tokens. First and last token must each match the registered value exactly after normalization (allow a small typo tolerance, e.g. edit distance 1 for names of 6+ letters, only if you accept that risk).
3. Order does not matter across the whole name (some IDs list the surname first): compare the sets of name tokens.
4. Any middle names in the saved name must match registered middle tokens. If none were typed, ignore the registered middle names.
5. Any failure returns `NAME_MISMATCH`. Never return the registered name or say which part failed.

Other results: NIN not in the source -> `NIN_NOT_FOUND`; source down or timing out -> 503 `IDENTITY_SERVICE_UNAVAILABLE` (nothing saved, the user can retry).

Privacy and safety:
- The registered name, date of birth and other biodata are never sent to the app, never shown to the inviter, and never stored. Store only: NIN (as now), check result, time, and the source's reference id.
- Audit log: who, invitation id, pass/fail, which field failed, and the NIN masked to its last 4 digits.
- Rate-limit attempts per account and per NIN (the app also slows repeated failures) so the endpoint cannot be used to look up other people's names by guessing.

Error body: `{ "message": "<CODE>" }`. The app maps these codes to English/Swahili text.

## Notes
- `POST /verification/blue-tick` with `inviterUserId` (existing `ApiService.applyBlueTick`) trusts a client-supplied inviter id. The new screens do not use it; the server should not grant a badge from that path.
- Anyone with Green (by invitation or by ID upload) may invite others. This creates chains of trust, so consider a depth limit or a minimum account age.
- If an invitee later turns out to be fraudulent, the stored link lets you review the inviter too.

## Vouch requests: an unverified person asks a verified provider
Not only verified providers start an invitation: someone without a badge can ask a verified provider who knows them to vouch for them. The provider decides; nothing is granted by the request itself.

- `POST /verification/invitation-requests` body `{ "providerPhone": "+255..." }`. The phone must belong to a registered account with `GREEN_BADGE` or `BLUE_TICK` (`PROVIDER_NOT_VERIFIED`); one open request per pair (`REQUEST_ALREADY_SENT`); not your own number (`SELF_INVITE`). Do not reveal whether a number is registered beyond these errors; rate-limit per account.
- `GET /verification/invitation-requests` -> list or `{ "requests": [...] }` of `{ id, status: PENDING|APPROVED|DECLINED|EXPIRED, direction: SENT|RECEIVED, name?, phone? }`. `name` is the stage name; never the legal name, NIN or ID photos.
- `POST /verification/invitation-requests/{id}/approve` (provider only). The server creates a normal invitation for the requester's phone exactly as `POST /verification/invitations` does (same expiry, same audit "vouched for" record) and it appears in the requester's received invitations, so they accept with one tap. `POST .../{id}/decline` closes it.
- Requests expire (suggest 14 days). Only the provider named in the request can answer it.
- The app shows "Ask a verified provider to vouch for me" on Identity Verification for unverified users, and a "Asking you to vouch for them" card with Approve/Decline on "Invite someone you trust" for verified providers. Approve asks the provider to confirm they know and trust the person.
