# Hide My ID (backend contract)

The app is wired to this. The server must enforce it; the app only displays results.
All calls use `Authorization: Bearer <token>`. Base: `/api`.

## What the user gets
Settings → Privacy & Security → **Hide My ID** (any signed-in user, default OFF).
When ON, a provider who receives this user's booking request sees:
- the user's **stage name only** (never real/NIDA name),
- their normal profile image (not the verified photo),
- a green **Safe** badge on the request cards, the customer page and booking details.

Phone number and exact address stay private until the booking is confirmed (unchanged).

## PUT /users/me/privacy
Body: `{ "hideMyId": true | false }`
Success: any 2xx. The app only switches the toggle after a 2xx, so a failure never shows "On" while the server still shares the identity.

## Login response
Include `"hideMyId": true|false` in `/auth/login` so the choice is restored on a new phone.

## Buyer object inside provider-facing transactions (`tx.buyer`)
| Field | Meaning |
|---|---|
| `hideMyId` | `true` when the buyer turned it on |
| `stageName` | always sent |
| `safeBadge` | `true` when the server grants the Safe badge (see below) |

Server rules:
- When `hideMyId` is true, **do not send** `name`, `fullName`, `buyerName`, `verifiedName` or `verifiedPhotoUrl` to providers. Send `stageName` and the normal `avatarUrl`. The app ignores the name fields in this case, but the server is the real protection. See verified_name_api_contract.md.
- `safeBadge` must be decided by the server, never by the client. Suggested rule: `hideMyId` is on AND the account has a verified NIDA (green or blue). The app shows the badge only if `hideMyId` and `safeBadge` are both `true`; it never invents one.
- Keep the real identity available to admin and dispute handling.

## Locked profile + Hide My ID ON (provider view)
Provider sees: stage name + profile photo + Safe badge. No phone, no socials, no exact location.
The request card and the customer page say "Contacts and ID hidden. Accept to see contact and location."
- Send `profileLocked` (bool) on `tx.buyer`; the app treats a missing value as Locked.
- Social links are never shown on request screens, in any combination. Do not send them in `tx.buyer`.
- Phone and exact location are released by the server only after the provider accepts.
