# Verification tiers (green / blue) and the Safe badge

Applies to **every** user, buyer or provider. The **server** computes the tier from approved checks; the app only shows it.

| Tier | Needs ALL of these approved | Badge |
|---|---|---|
| Green | NIN, name (read from ID), photo (verified face photo) | green |
| Blue | NIN, NIDA card, name, photo, photo holding the NIDA card | blue |

Blue includes everything in green. If any check is later rejected/expired, the tier drops.

## Safe badge
Shown to providers on a buyer's requests while the buyer has **Hide My ID ON** and holds green or blue.
It uses the tier's color: green tier = green Safe, blue tier = blue Safe.
The server sends `safeBadge: true` plus `verificationBadge: "GREEN_BADGE" | "BLUE_TICK"` on `tx.buyer`.
(The app falls back to green if it gets `safeBadge` without a tier, and shows nothing without `safeBadge`.)

## Hide My ID OFF
When the ID front and back are approved, the server automatically makes the legal name VERIFIED (selfie not needed); the user does not type it.
The provider sees the green/blue verification badge next to the buyer's verified name (send `verificationBadge`).
Hide My ID ON: send `safeBadge` and `verificationBadge`, but never `verifiedName` / `verifiedPhotoUrl`.
