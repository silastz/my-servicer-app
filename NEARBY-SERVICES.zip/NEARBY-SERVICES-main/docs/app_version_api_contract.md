# App version API (update dialog)

The app asks the backend which version is current and shows an "Update available" dialog when the
backend's version is newer than the installed one. It checks 2 seconds after launch and each time the
app returns to the foreground (at most every 30 minutes). If the call fails, nothing is shown.

## GET /api/app/version?platform=android|ios
No auth. Success 200:

```json
{
  "latestVersion": "1.2.0",
  "minVersion": "1.0.5",
  "forceUpdate": false,
  "storeUrl": "https://play.google.com/store/apps/details?id=com.unganalink.app",
  "messageEn": "Faster chat and bug fixes.",
  "messageSw": "Mazungumzo ya haraka na marekebisho."
}
```

- `latestVersion` (required): newest released version, compared with the app's `version` in pubspec (the part before `+`).
- `minVersion` (optional): installed versions below this get a **required** update dialog (cannot be closed).
- `forceUpdate` (optional): `true` makes the update required for everyone older than `latestVersion`.
- `storeUrl` (optional, https only): falls back to the Play Store link for `com.unganalink.app`. Set the App Store link for `ios`.
- `messageEn` / `messageSw` (optional): custom text; defaults are built in.

Optional update: the user can tap **Later**; the app then stays quiet until `latestVersion` changes again.

Release steps: publish the build to the store first, then raise `latestVersion` here.
