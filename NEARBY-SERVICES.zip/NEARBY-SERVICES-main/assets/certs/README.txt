Put the PEM of the CA that signs your server certificate in this folder as:

    pinned_ca.pem

Use the ROOT or INTERMEDIATE CA (they last years), not the leaf certificate (renews every ~90 days).
You can concatenate several PEM blocks (e.g. current + backup CA).

Get the chain:
    openssl s_client -showcerts -connect YOUR_HOST:443 </dev/null
Copy the intermediate/root "-----BEGIN CERTIFICATE-----" block(s) into pinned_ca.pem.
(Let's Encrypt: ISRG Root X1 is at https://letsencrypt.org/certs/isrgrootx1.pem)

Then build with:  --dart-define=REQUIRE_PINNING=true
Also add the same CA hash to android/app/src/main/res/xml/network_security_config.xml (see comments there).
