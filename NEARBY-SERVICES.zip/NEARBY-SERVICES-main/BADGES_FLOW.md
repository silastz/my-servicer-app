# Service badges (earned from reviews)

The badge row on the service page shows only what the server awarded. The app never invents a badge.

## What the app expects
Each service/seller JSON may carry the provider's earned badges:

    "badges": ["TOP_RATED", "PROFESSIONAL"]          // seller.badges, sellerBadges or badges
    "badges": [{"key": "CLEAN_SAFE"}]                 // objects with key / code / name / label also work

Known keys (own icon and colour): TOP_RATED, PROFESSIONAL, CLEAN_SAFE, LOVED_BY_CUSTOMERS (CUSTOMER_FAVORITE), RELIABLE (ON_TIME).
Any other key the admin adds is shown with its name in Title Case and a default icon.

## Automatic in the app
The app also works the badges out by itself from the service's real rating and review count
(`ServiceBadgeRules` in `lib/widgets/service_badges.dart`), then merges them with any the server sent:
- TOP_RATED: rating >= 4.8 with 10+ reviews
- PROFESSIONAL: rating >= 4.5 with 5+ reviews
- CUSTOMER_FAVORITE: rating >= 4.6 with 25+ reviews
They appear and disappear on their own as reviews change. Change the numbers at the top of that class.

## Admin side (server, optional)
Badges are awarded and removed automatically from review data, for example:
- TOP_RATED: average rating >= 4.8 with at least 10 reviews
- PROFESSIONAL: average rating >= 4.5 with at least 5 reviews
- CLEAN_SAFE: reviews rated 5 stars for cleanliness/safety >= 80% (needs 5+ reviews)

Thresholds are the admin's choice. The server re-checks after every new review and drops a badge when the provider no longer qualifies.

## Available Now
Not a review badge. A green online pill, drawn live only while the provider is online.

## Verification marks (Green / Blue)
- GREEN = identity fully verified. Earned by uploading ID + selfie holding the ID (server reviews), or by accepting an invitation (a verified provider can invite you, or you can ask a verified provider to vouch for you and they approve; code only; the legal name and NIN were saved in Identity Verification Step 1). A Green provider can invite others.
- BLUE = Verified Business (business documents approved by the server). Needs Green first. A Blue provider can invite too.
- An invitation covers identity only: the invitee gets Green, never Blue.
- Wire values are unchanged: `verificationBadge` = `GREEN_BADGE` | `BLUE_TICK` | `NONE`. Their meaning changed (BLUE_TICK now means Verified Business), so the server must award them that way.
- Server contract changes: invitation create/accept allowed for GREEN_BADGE and BLUE_TICK inviters (error `INVITER_NOT_VERIFIED`); accept grants GREEN_BADGE; `/verification/business` requires GREEN_BADGE or BLUE_TICK (error `GREEN_BADGE_REQUIRED`); GREEN_BADGE is granted only when BOTH the ID (front and back, or passport photo page) AND the selfie holding the ID are approved (the face photo stays optional); one approved document alone grants nothing; business approval grants BLUE_TICK; business expiry drops BLUE_TICK back to GREEN_BADGE.
- The gold "Verified Business" chip stays next to the Blue mark.
- Legal name: once the ID front and back are approved, the server confirms the legal name with the ID automatically (no typing; the selfie is not needed). Before that, in Identity Verification Step 1 the user saves the legal name and the 20-digit NIN (`POST /users/me/verified-name`), then uploads the ID front and back; the server verifies them against the ID. Once VERIFIED it is the legal name providers see on bookings (only while Hide My ID is off). Invitation accept has no name or NIN fields: the server checks the saved legal name against the name registered for the saved NIN via an official identity source before granting Green (see docs/invitation_api_contract.md).
