# easy_audience_network (vendored)

Copy of [easy_audience_network 0.0.7](https://github.com/nooralibutt/audience_network_flutter)
(MIT, Dreamsoft Innovations). The pub.dev release was last updated in 2024 and its Android build
files no longer work with current Gradle, so it lives here and is used through a `path:` dependency.

Changes from upstream (nothing in the Dart or Java/Swift code was touched):
- `android/build.gradle`: removed the private `buildscript` (old Android Gradle Plugin) and the
  bundled `flutter.jar`; compile SDK 35, Java 17; Meta Audience Network SDK 6.17.0 -> 6.21.0.
- `android/src/main/AndroidManifest.xml`: removed the `package` attribute (the namespace is in Gradle).
- Removed the Gradle wrapper, `tempLibs`, IDE files, example and tests.

If you prefer the upstream package, replace the `path:` dependency in `pubspec.yaml` with
`easy_audience_network: ^0.0.7` and delete this folder. Its API is identical.
