// Usage: dart run tool/obfuscate_url.dart https://your.server
// Prints the two lists to paste into lib/security/client_security_config.dart.
import 'dart:convert';
import 'dart:math';

void main(List<String> args) {
  if (args.isEmpty) {
    print('Usage: dart run tool/obfuscate_url.dart https://your.server');
    return;
  }
  final rnd = Random.secure();
  final key = List<int>.generate(16, (_) => rnd.nextInt(256));
  final data = utf8.encode(args.first);
  final blob = [for (var i = 0; i < data.length; i++) data[i] ^ key[i % key.length]];
  print('static const List<int> _blob = $blob;');
  print('static const List<int> _key = $key;');
}
