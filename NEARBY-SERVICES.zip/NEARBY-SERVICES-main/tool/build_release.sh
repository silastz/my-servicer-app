#!/usr/bin/env bash
# Hardened release build: obfuscated Dart code, stripped symbols, server URL kept out of the repo.
# Usage: API_ORIGIN=https://your.server ADMOB_APP_ID=ca-app-pub-XXXX~YYYY [BLOCK_COMPROMISED=true] \
#        ./tool/build_release.sh [apk|appbundle|ios]
set -euo pipefail
TARGET="${1:-appbundle}"
: "${API_ORIGIN:?Set API_ORIGIN=https://your.server}"
: "${ONESIGNAL_APP_ID:=d735e239-78de-40bb-8eae-90ae6b64c534}"   # public App ID; override with the env var if needed
: "${ADMOB_APP_ID:?Set ADMOB_APP_ID to your real AdMob app id, the Google test id must not ship}"
case "$ADMOB_APP_ID" in ca-app-pub-3940256099942544*) echo "ADMOB_APP_ID is the Google demo id" >&2; exit 1;; esac
export ADMOB_APP_ID   # read by android/app/build.gradle.kts and ios/Flutter/Release.xcconfig
if [ "$TARGET" = "ios" ]; then   # iOS reads the AdMob ID from this generated xcconfig
  echo "ADMOB_APP_ID = $ADMOB_APP_ID" > ios/Flutter/Admob.xcconfig
fi
# Certificate pinning is enforced only when assets/certs/pinned_ca.pem is bundled. Forcing it without the file
# makes every request to the server fail ("pinned certificate missing"), so the app could not start.
if [ -z "${REQUIRE_PINNING:-}" ]; then
  if [ -s assets/certs/pinned_ca.pem ]; then REQUIRE_PINNING=true; else
    REQUIRE_PINNING=false
    echo "WARNING: assets/certs/pinned_ca.pem not found - building WITHOUT certificate pinning (see assets/certs/README.txt)." >&2
  fi
elif [ "$REQUIRE_PINNING" = "true" ] && [ ! -s assets/certs/pinned_ca.pem ]; then
  echo "REQUIRE_PINNING=true but assets/certs/pinned_ca.pem is missing: the app would block every request." >&2; exit 1
fi
mkdir -p build/symbols   # keep these PRIVATE (needed to de-obfuscate crash traces)
flutter build "$TARGET" --release \
  --obfuscate --split-debug-info=build/symbols \
  --dart-define=API_ORIGIN="$API_ORIGIN" \
  --dart-define=ONESIGNAL_APP_ID="$ONESIGNAL_APP_ID" \
  --dart-define=REQUIRE_PINNING="$REQUIRE_PINNING" \
  --dart-define=BLOCK_COMPROMISED="${BLOCK_COMPROMISED:-false}" \
  --dart-define=EXPECTED_SIGNER_SHA256="${EXPECTED_SIGNER_SHA256:-}"
