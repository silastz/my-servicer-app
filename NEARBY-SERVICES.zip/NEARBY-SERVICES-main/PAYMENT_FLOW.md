# Pay-first / offline payment flow

The app side is done; the backend needs the endpoints and statuses below.

## Buyer chooses how to pay (booking request screen)
`POST /escrow/create` now also accepts `paymentMethod: "OFFLINE"` with `offlineChannel: "cash" | "transfer"`.
Nothing is charged in the app for OFFLINE bookings.

## Statuses
| Status | Meaning |
|---|---|
| `PENDING_ACCEPTANCE` | Provider is reviewing the request |
| `AWAITING_PAYMENT` | Provider asked the buyer to pay first |
| `PAYMENT_SENT` | Buyer tapped "I have paid" (offline) |
| `PAYMENT_DISPUTED` | Provider says the money did not arrive |
| `ACCEPTED` | Accepted (after payment is confirmed when pay-first was requested) |

## Endpoints
| Who | Call | Effect |
|---|---|---|
| Provider | `POST /escrow/request-payment/{ref}` `{mode: ONLINE\|OFFLINE, instructions, deadlineMinutes}` | `PENDING_ACCEPTANCE` -> `AWAITING_PAYMENT`, alert buyer |
| Buyer | `POST /escrow/mark-paid/{ref}` `{reference, note, proofUrl?}` | `AWAITING_PAYMENT` -> `PAYMENT_SENT`, alert provider |
| Provider | `POST /escrow/confirm-payment/{ref}` | `PAYMENT_SENT` / `PAYMENT_DISPUTED` -> `ACCEPTED`, unlock contacts |
| Provider | `POST /escrow/payment-not-received/{ref}` `{reason}` | `PAYMENT_SENT` -> `PAYMENT_DISPUTED`, alert buyer |
| Buyer | `POST /escrow/pay/{ref}` `{paymentMethod: POCKET_FUND}` | online pay of an existing booking; mobile money / card use `/payments/mobile/request` and `/payments/card/checkout` with `purpose: BOOKING` and the booking ref |

## Buyer's payment choice (held or direct)
On the request form the buyer chooses how the online payment is treated:
`paymentPreference: "HELD"` (default; kept in escrow until the buyer confirms the job is done) or
`"DIRECT"` (released to the provider as soon as it is paid, nothing held). `POST /escrow/create` accepts it
alongside `paymentMethod: PAY_AFTER_ACCEPT`, and the booking JSON must return it as `paymentPreference`
so the provider's request card can show it. The app also writes a "Payment: ..." line into the booking notes.
Server rules: store the choice, never let the buyer change it after creating the booking, hold the money only
for `HELD`, and release `DIRECT` payments to the provider's wallet when the payment is confirmed (the
buyer then has no "Confirm completed / release" step).

## Optional payment proof (screenshot / receipt)
In the "I have paid" sheet the buyer can attach a photo. The app first uploads it with
`POST /escrow/payment-proof` (multipart field `file`, images only, max 10 MB) -> `{"url": "https://..."}`,
then sends that link as `proofUrl` in `mark-paid`. The booking JSON carries it back as `paymentProofUrl`.
Server rules: only the buyer of that booking may upload; only that buyer and the booking's provider may
view the file; validate type and size on the server.

## Rules the server must enforce (the app cannot)
- Only the provider can call `confirm-payment` and `payment-not-received`; never the buyer.
- `mark-paid` only by the buyer of that booking, only from `AWAITING_PAYMENT`.
- A booking with `paymentMethod` POCKET_FUND / DIRECT must not be accepted until `paymentStatus` is paid.
- Expire `AWAITING_PAYMENT` after `paymentDeadline` (cancel the booking).

## Fields the booking JSON should carry
`paymentMethod`, `paymentMode` (ONLINE|OFFLINE), `paymentStatus` (UNPAID|PAID|FAILED|PENDING_PAYMENT),
`paymentInstructions`, `paymentDeadline` (ISO-8601), `paymentReference`, `paymentNote`, `paymentProofUrl`.
