#!/usr/bin/env bash
# ==============================================================================
# deploy.sh — Automation Helper for NearByServices (Master VPS: 95.111.251.192)
# Developer: lwenaadam | Port: 3010 | Shared Memory Budget: 8GB RAM
# ==============================================================================
set -e

VPS_HOST="95.111.251.192"
VPS_USER="lwenaadam"
REMOTE_DIR="/home/lwenaadam/nearbyservices"
LOCAL_DIR="/home/lwena/projects/AdamDev/frontends/backends/NearByServices"

echo "🚀 [1/4] Preparing deployment for NearByServices to ${VPS_HOST}..."

# 1. Sync backend files (excluding build artifacts and git history)
echo "📦 [2/4] Syncing project files via rsync..."
ssh -o StrictHostKeyChecking=no "${VPS_USER}@${VPS_HOST}" "mkdir -p ${REMOTE_DIR}"
rsync -avz --delete \
  --exclude='.git' \
  --exclude='target' \
  --exclude='.idea' \
  --exclude='.vscode' \
  --exclude='backups' \
  --exclude='.env' \
  "${LOCAL_DIR}/" "${VPS_USER}@${VPS_HOST}:${REMOTE_DIR}/"

# 2. Remote Build & Deploy
echo "🐳 [3/4] Building and launching containers on VPS..."
ssh -o StrictHostKeyChecking=no "${VPS_USER}@${VPS_HOST}" << 'EOF'
  cd /home/lwenaadam/nearbyservices

  # Check or initialize .env if not present (random secrets; API keys left blank for you to fill in)
  if [ ! -f .env ]; then
    echo "Creating initial .env with generated secrets..."
    umask 177
    cat << ENVFILE > .env
PORT=3010
POSTGRES_DB=nearbyservices
POSTGRES_USER=postgres
POSTGRES_PASSWORD=$(openssl rand -hex 24)
JWT_SECRET=$(openssl rand -hex 32)
UNGANA_SECRETS_KEY=$(openssl rand -base64 32)
ACTIVE_SMS_PROVIDER=SMS_GATEWAY_PRO
SMS_SENDER_ID=NEARBY
SMS_GATEWAY_PRO_URL=https://kzjgdeqfmxkmpmadtbpb.supabase.co/functions/v1/sms-api/send
SMS_GATEWAY_PRO_API_KEY=
SELANIM_SMS_URL=https://bulksms.selanim.com/api/v1/sms/send
SELANIM_API_KEY=
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=karibuhuduma@gmail.com
SMTP_PASSWORD=
ADMIN_PHONE=
ADMIN_PASSWORD=$(openssl rand -base64 18 | tr -d '/+=' | cut -c1-16)
ADMIN_EMAIL=
SUPPORT_PHONE=
SUPPORT_WHATSAPP=
SUPPORT_EMAIL=
ENVFILE
    chmod 600 .env
    echo "!! Set ADMIN_PHONE (the admin signs in with it; ADMIN_PASSWORD was generated in .env) and fill in SMS_GATEWAY_PRO_API_KEY, SMTP_PASSWORD, SUPPORT_PHONE and SUPPORT_WHATSAPP in $(pwd)/.env, then re-run deploy."
    echo "   (Until SUPPORT_PHONE / SUPPORT_WHATSAPP are set, the app hides those two contacts.)"
  fi

  # Deploy stack with memory limits
  docker compose down --remove-orphans || true
  docker compose up -d --build

  # Clean up dangling layers to preserve 8GB RAM and NVMe space
  docker image prune -f
EOF

# 3. Health check validation
echo "🩺 [4/4] Verifying health check on port 3010..."
sleep 10
if curl -sf "http://${VPS_HOST}:3010/api/health" > /dev/null; then
  echo "✅ Deployment successful! Service is UP and running at http://${VPS_HOST}:3010"
else
  echo "⚠️ Health check pending or starting up. Check remote logs with:"
  echo "   ssh ${VPS_USER}@${VPS_HOST} 'docker logs nearbyservices-api --tail 50 -f'"
fi
