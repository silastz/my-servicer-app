package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.Role;
import com.nearbyservices.model.User;
import com.nearbyservices.repository.ServicePostRepository;
import com.nearbyservices.repository.UserRepository;
import com.nearbyservices.repository.WalletRepository;
import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.security.JwtService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/** Admin account management: suspend, reactivate, delete, and who is protected from it. */
class UserAdminServiceTest {

    private static final long ADMIN_ID = 1L;

    private UserRepository users;
    private AccountDeletionService deletion;
    private UserAdminService service;
    private User seller;
    private User otherAdmin;

    @BeforeEach
    void setUp() {
        users = mock(UserRepository.class);
        deletion = mock(AccountDeletionService.class);
        service = new UserAdminService(users, mock(WalletRepository.class), mock(ServicePostRepository.class), deletion);

        seller = User.builder().id(7L).username("zeen").phone("+255712345678").password("hash")
                .stageName("Zeen Spa").role(Role.ROLE_SELLER).phoneVerified(true).build();
        otherAdmin = User.builder().id(2L).username("boss").phone("+255700000000").password("hash")
                .stageName("Boss").role(Role.ROLE_ADMIN).phoneVerified(true).build();
        when(users.findByIdForUpdate(7L)).thenReturn(Optional.of(seller));
        when(users.findByIdForUpdate(2L)).thenReturn(Optional.of(otherAdmin));
        when(users.findById(7L)).thenReturn(Optional.of(seller));
        when(users.findById(2L)).thenReturn(Optional.of(otherAdmin));
    }

    @Test
    void suspendBlocksTheAccountAndKillsOldLogins() {
        Map<String, Object> out = service.suspend(ADMIN_ID, 7L, "  Scam reports  ");
        assertEquals("SUSPENDED", out.get("status"));
        assertTrue(seller.isSuspended());
        assertEquals("Scam reports", seller.getSuspendReason());
        assertNotNull(seller.getTokensValidFrom());
        verify(users).save(seller);
    }

    @Test
    void suspendNeedsAReason() {
        ApiException e = assertThrows(ApiException.class, () -> service.suspend(ADMIN_ID, 7L, "   "));
        assertEquals("REASON_REQUIRED", e.getMessage());
        assertFalse(seller.isSuspended());
        verify(users, never()).save(any());
    }

    @Test
    void reasonCannotBeHuge() {
        ApiException e = assertThrows(ApiException.class, () -> service.suspend(ADMIN_ID, 7L, "x".repeat(501)));
        assertEquals("REASON_TOO_LONG", e.getMessage());
    }

    @Test
    void adminAccountsCannotBeSuspendedOrDeleted() {
        assertEquals("ADMIN_ACCOUNT", assertThrows(ApiException.class, () -> service.suspend(ADMIN_ID, 2L, "why")).getMessage());
        assertEquals("ADMIN_ACCOUNT", assertThrows(ApiException.class, () -> service.reactivate(ADMIN_ID, 2L)).getMessage());
        assertEquals("ADMIN_ACCOUNT", assertThrows(ApiException.class, () -> service.delete(ADMIN_ID, 2L)).getMessage());
        verify(deletion, never()).deleteByAdmin(org.mockito.ArgumentMatchers.anyLong(), org.mockito.ArgumentMatchers.anyLong());
    }

    @Test
    void adminCannotActOnThemselves() {
        assertEquals("ADMIN_ACCOUNT", assertThrows(ApiException.class, () -> service.suspend(7L, 7L, "why")).getMessage());
        assertEquals("ADMIN_ACCOUNT", assertThrows(ApiException.class, () -> service.delete(7L, 7L)).getMessage());
    }

    @Test
    void unknownUserIs404() {
        ApiException e = assertThrows(ApiException.class, () -> service.suspend(ADMIN_ID, 99L, "why"));
        assertEquals("USER_NOT_FOUND", e.getMessage());
    }

    @Test
    void deletedAccountCannotBeSuspended() {
        seller.setDeletedAt(Instant.now());
        ApiException e = assertThrows(ApiException.class, () -> service.suspend(ADMIN_ID, 7L, "why"));
        assertEquals("ACCOUNT_DELETED", e.getMessage());
    }

    @Test
    void reactivateClearsTheSuspension() {
        service.suspend(ADMIN_ID, 7L, "why");
        Map<String, Object> out = service.reactivate(ADMIN_ID, 7L);
        assertEquals("ACTIVE", out.get("status"));
        assertFalse(seller.isSuspended());
        assertNull(seller.getSuspendReason());
    }

    @Test
    void deleteGoesThroughTheSharedDeletionRules() {
        service.delete(ADMIN_ID, 7L);
        verify(deletion).deleteByAdmin(ADMIN_ID, 7L);
    }

    @Test
    void badFilterValuesAreRejected() {
        assertEquals("INVALID_STATUS", assertThrows(ApiException.class, () -> service.list(null, "NOPE", null, 0, 10)).getMessage());
        assertEquals("INVALID_ROLE", assertThrows(ApiException.class, () -> service.list(null, null, "KING", 0, 10)).getMessage());
    }

    @Test
    void suspendedTokensAreRefused() {
        JwtService jwt = new JwtService();
        ReflectionTestUtils.setField(jwt, "secretKey", "404E635266556A586E3272357538782F413F4428472B4B6250645367566B5970");
        ReflectionTestUtils.setField(jwt, "jwtExpiration", 60_000L);
        String token = jwt.generateToken(new CustomUserDetails(seller));
        assertTrue(jwt.isTokenValid(token, new CustomUserDetails(seller)));
        seller.setSuspendedAt(Instant.now());
        assertFalse(jwt.isTokenValid(token, new CustomUserDetails(seller)));
    }
}
