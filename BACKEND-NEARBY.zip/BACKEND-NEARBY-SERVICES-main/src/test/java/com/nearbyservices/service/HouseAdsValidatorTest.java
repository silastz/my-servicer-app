package com.nearbyservices.service;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class HouseAdsValidatorTest {

    private static final Set<String> PAGES = Set.of("home", "serviceDetails", "search", "providerProfile", "chats", "videoReward");

    private static Map<String, Object> ad() {
        Map<String, Object> a = new LinkedHashMap<>();
        a.put("id", "plumbers-promo");
        a.put("title", "Plumbers near you");
        a.put("body", "Book a verified plumber today.");
        a.put("cta", "Book now");
        a.put("imageUrl", "https://example.com/promo.jpg");
        a.put("url", "https://example.com/plumbers");
        a.put("formats", List.of("banner", "native"));
        a.put("pages", List.of("home", "search"));
        a.put("platforms", List.of("android", "ios"));
        a.put("countries", List.of("TZ", "KE"));
        a.put("title_TZ", "Mafundi bomba karibu nawe");
        a.put("weight", 3.0);
        a.put("start", "2026-11-01T00:00:00Z");
        a.put("end", "2026-11-30T23:59:59Z");
        a.put("enabled", true);
        return a;
    }

    private static String check(Map<String, Object> a) {
        return HouseAdsValidator.validate(List.of(a), PAGES);
    }

    @Test
    void validAdPassesAndNoHouseIsFine() {
        assertNull(check(ad()));
        assertNull(HouseAdsValidator.validate(null, PAGES));
        assertNull(HouseAdsValidator.validate(List.of(), PAGES));
    }

    @Test
    void rejectsBadFields() {
        Map<String, Object> a = ad(); a.put("url", "http://example.com"); // not https
        assertEquals("INVALID_HOUSE_AD:plumbers-promo:url", check(a));
        a = ad(); a.put("imageUrl", "https://user:pw@example.com/x.jpg");
        assertEquals("INVALID_HOUSE_AD:plumbers-promo:imageUrl", check(a));
        a = ad(); a.put("title", "x".repeat(61));
        assertEquals("INVALID_HOUSE_AD:plumbers-promo:title", check(a));
        a = ad(); a.put("formats", List.of("popup"));
        assertEquals("INVALID_HOUSE_AD:plumbers-promo:formats", check(a));
        a = ad(); a.put("pages", List.of("checkout"));
        assertEquals("INVALID_HOUSE_AD:plumbers-promo:pages", check(a));
        a = ad(); a.put("countries", List.of("TZA"));
        assertEquals("INVALID_HOUSE_AD:plumbers-promo:countries", check(a));
        a = ad(); a.put("weight", 101.0);
        assertEquals("INVALID_HOUSE_AD:plumbers-promo:weight", check(a));
        a = ad(); a.put("rewardSeconds", 2.0);
        assertEquals("INVALID_HOUSE_AD:plumbers-promo:rewardSeconds", check(a));
        a = ad(); a.put("end", "2026-10-01T00:00:00Z"); // before start
        assertEquals("INVALID_HOUSE_AD:plumbers-promo:end", check(a));
        a = ad(); a.put("start", "tomorrow");
        assertEquals("INVALID_HOUSE_AD:plumbers-promo:start", check(a));
    }

    @Test
    void checksTextPerCountryAndKeepsUnknownKeys() {
        Map<String, Object> a = ad(); a.put("url_KE", "http://bad.example");
        assertEquals("INVALID_HOUSE_AD:plumbers-promo:url_KE", check(a));
        a = ad(); a.put("cta_TZ", "y".repeat(25));
        assertEquals("INVALID_HOUSE_AD:plumbers-promo:cta_TZ", check(a));
        a = ad(); a.put("cta_TZ", ""); // blank = use the plain field
        assertNull(check(a));
    }

    @Test
    void idsMustBeUniqueAndAtMostTwentyAds() {
        List<Object> two = new ArrayList<>(List.of(ad(), ad()));
        assertEquals("INVALID_HOUSE_AD:plumbers-promo:id_duplicate", HouseAdsValidator.validate(two, PAGES));
        List<Object> many = new ArrayList<>();
        for (int i = 0; i < 21; i++) { Map<String, Object> a = ad(); a.put("id", "ad" + i); many.add(a); }
        assertEquals("TOO_MANY_HOUSE_ADS", HouseAdsValidator.validate(many, PAGES));
    }

    @Test
    void configDiffListsFieldNamesOnly() {
        Map<String, Object> before = new LinkedHashMap<>(Map.of("testMode", true, "pages", Map.of("home", Map.of("enabled", true))));
        Map<String, Object> after = new LinkedHashMap<>(Map.of("testMode", false, "pages", Map.of("home", Map.of("enabled", false)), "enabled", true));
        List<String> changed = ConfigDiff.changedPaths(before, after);
        assertEquals(Set.of("testMode", "pages.home.enabled", "enabled"), Set.copyOf(changed));
        assertEquals("no field changed", ConfigDiff.detail(List.of()));
    }
}
