package com.nearbyservices.service;

import com.nearbyservices.model.LiveLocation;
import com.nearbyservices.repository.LiveLocationRepository;
import org.junit.jupiter.api.Test;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class LiveLocationServiceTest {

    private final LiveLocationRepository repo = mock(LiveLocationRepository.class);
    private final LiveLocationService service = new LiveLocationService(repo);

    private LiveLocation row(long ageMillis) {
        return LiveLocation.builder().posKey("TX1:7").bookingRef("TX1").userId(7L)
                .latitude(-6.79).longitude(39.2).heading(90.0)
                .atMillis(System.currentTimeMillis() - ageMillis).build();
    }

    @Test
    void freshPositionIsReturned() {
        when(repo.findById("TX1:7")).thenReturn(Optional.of(row(5_000)));
        var p = service.fresh("TX1", 7);
        assertTrue(p.isPresent());
        assertEquals(-6.79, p.get().latitude());
        assertEquals(90.0, p.get().heading());
    }

    @Test
    void stalePositionIsIgnored() {
        when(repo.findById("TX1:7")).thenReturn(Optional.of(row(LiveLocationService.TTL_MILLIS + 5_000)));
        assertTrue(service.fresh("TX1", 7).isEmpty());
    }

    @Test
    void missingPositionIsEmpty() {
        when(repo.findById("TX1:9")).thenReturn(Optional.empty());
        assertTrue(service.fresh("TX1", 9).isEmpty());
    }

    @Test
    void putUpsertsUnderBookingAndUserKey() {
        service.put("TX1", 7, -6.79, 39.2, null);
        verify(repo).upsert(org.mockito.ArgumentMatchers.eq("TX1:7"), org.mockito.ArgumentMatchers.eq("TX1"), org.mockito.ArgumentMatchers.eq(7L),
                org.mockito.ArgumentMatchers.eq(-6.79), org.mockito.ArgumentMatchers.eq(39.2), org.mockito.ArgumentMatchers.isNull(), anyLong());
    }

    @Test
    void removeDeletesTheKey() {
        service.remove("TX1", 7);
        verify(repo).deleteByKey("TX1:7");
    }
}
