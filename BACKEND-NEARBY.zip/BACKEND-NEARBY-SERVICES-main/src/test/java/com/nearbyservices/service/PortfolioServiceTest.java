package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.PortfolioItem;
import com.nearbyservices.model.Role;
import com.nearbyservices.model.User;
import com.nearbyservices.repository.PortfolioItemRepository;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockMultipartFile;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class PortfolioServiceTest {

    private final PortfolioItemRepository items = mock(PortfolioItemRepository.class);
    private final FileStorageService files = mock(FileStorageService.class);
    private final PortfolioService service = new PortfolioService(items, files);
    private final MockMultipartFile file = new MockMultipartFile("file", "a.jpg", "image/jpeg", new byte[]{1});

    private static User user(Role role) {
        User u = new User();
        u.setId(7L);
        u.setRole(role);
        return u;
    }

    @Test
    void buyersCannotAddToAPortfolio() {
        assertThrows(ApiException.class, () -> service.add(user(Role.ROLE_BUYER), file, null, PortfolioItem.Type.IMAGE));
        verifyNoInteractions(files);
    }

    @Test
    void photoLimitStopsTheUploadBeforeAnyFileIsSaved() {
        when(items.countByOwnerIdAndType(7L, PortfolioItem.Type.IMAGE)).thenReturn((long) PortfolioService.MAX_IMAGES);
        assertThrows(ApiException.class, () -> service.add(user(Role.ROLE_SELLER), file, null, PortfolioItem.Type.IMAGE));
        verify(files, never()).storePortfolio(any(), any());
    }

    @Test
    void ownerCanRemoveAnItemAndItsFile() {
        PortfolioItem it = PortfolioItem.builder().id(3L).ownerId(7L).type(PortfolioItem.Type.IMAGE)
                .url("/uploads/portfolio/images/x.jpg").build();
        when(items.findByIdAndOwnerId(3L, 7L)).thenReturn(java.util.Optional.of(it));
        service.delete(user(Role.ROLE_SELLER), 3L);
        verify(items).delete(it);
        verify(files).deletePortfolioFile("/uploads/portfolio/images/x.jpg");
    }

    @Test
    void someoneElsesItemIsNotFound() {
        when(items.findByIdAndOwnerId(3L, 7L)).thenReturn(java.util.Optional.empty());
        assertThrows(ApiException.class, () -> service.delete(user(Role.ROLE_SELLER), 3L));
    }
}
