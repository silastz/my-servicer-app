package com.nearbyservices.service;

import com.nearbyservices.model.Report;
import com.nearbyservices.model.Role;
import com.nearbyservices.model.User;
import com.nearbyservices.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.time.Instant;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/** Admins hear about new reports; deleted or suspended admins and a switched-off push do not. */
class AdminAlertsTest {

    private PushService push;
    private UserRepository users;
    private AdminAlerts alerts;
    private Report report;

    private static User admin(long id) {
        return User.builder().id(id).username("a" + id).phone("p" + id).password("x").stageName("A").role(Role.ROLE_ADMIN).build();
    }

    @BeforeEach
    void setUp() {
        push = mock(PushService.class);
        users = mock(UserRepository.class);
        alerts = new AdminAlerts(push, users);
        when(push.enabled()).thenReturn(true);
        report = Report.builder().id(5L).type("USER").reason("Scam").build();
    }

    @Test
    void everyActiveAdminGetsTheReportAlert() {
        User gone = admin(2);
        gone.setDeletedAt(Instant.now());
        User held = admin(3);
        held.setSuspendedAt(Instant.now());
        when(users.findByRole(Role.ROLE_ADMIN)).thenReturn(List.of(admin(1), gone, held));

        alerts.newReport(report);

        ArgumentCaptor<Map<String, Object>> data = ArgumentCaptor.forClass(Map.class);
        verify(push).toUser(org.mockito.ArgumentMatchers.eq(1L), any(), any(), data.capture());
        verify(push, never()).toUser(org.mockito.ArgumentMatchers.eq(2L), any(), any(), any());
        verify(push, never()).toUser(org.mockito.ArgumentMatchers.eq(3L), any(), any(), any());
        assertEquals("admin_report", data.getValue().get("type"));
        assertEquals("5", data.getValue().get("id"));
    }

    @Test
    void nothingIsSentWhenPushIsNotConfigured() {
        when(push.enabled()).thenReturn(false);
        alerts.newReport(report);
        verify(push, never()).toUser(anyLong(), any(), any(), any());
    }

    @Test
    void aFailureNeverReachesTheCaller() {
        when(users.findByRole(Role.ROLE_ADMIN)).thenThrow(new RuntimeException("db down"));
        alerts.newReport(report); // must not throw
    }

    @Test
    void adminAlertTypesAreNeverMutedByUserSwitches() {
        for (String type : List.of("admin_report", "admin_dispute", "admin_withdrawal")) {
            assertEquals(null, PushService.categoryOf(Map.of("type", type)), type);
        }
    }

    @Test
    void aFailedPaymentAlertsOncePerPayment() {
        when(users.findByRole(Role.ROLE_ADMIN)).thenReturn(List.of(admin(1)));
        com.nearbyservices.model.Payment p = com.nearbyservices.model.Payment.builder()
                .reference("PAY-123456").purpose(com.nearbyservices.model.PaymentPurpose.WALLET_TOPUP)
                .amount(new java.math.BigDecimal("5000")).gateway("SNIPPE").build();
        alerts.paymentFailed(p);
        alerts.paymentFailed(p); // the gateway repeats its webhook
        verify(push, org.mockito.Mockito.times(1)).toUser(org.mockito.ArgumentMatchers.eq(1L), any(), any(), any());
    }

    @Test
    void gatewayErrorsAreSentNowAndThrottledPerGateway() {
        when(users.findByRole(Role.ROLE_ADMIN)).thenReturn(List.of(admin(1)));
        alerts.paymentGatewayError("SNIPPE", "WALLET_TOPUP", "PAY-1", "HttpTimeoutException");
        alerts.paymentGatewayError("SNIPPE", "WALLET_TOPUP", "PAY-2", "HttpTimeoutException");
        verify(push, org.mockito.Mockito.times(1)).toUserNow(org.mockito.ArgumentMatchers.eq(1L), any(), any(), any());
        alerts.paymentGatewayError("DPO", "WALLET_TOPUP", "PAY-3", "X"); // another gateway is its own problem
        verify(push, org.mockito.Mockito.times(2)).toUserNow(org.mockito.ArgumentMatchers.eq(1L), any(), any(), any());
    }

    @Test
    void paymentAlertTypeIsNotMutedByTheBookingsSwitch() {
        assertEquals(null, PushService.categoryOf(Map.of("type", "admin_pay_error")));
    }

    @Test
    void anAdminWhoSwitchedACategoryOffGetsNoneOfIt() {
        User quiet = admin(1);
        quiet.setNotifAdminReports(false);
        User normal = admin(2);
        when(users.findByRole(Role.ROLE_ADMIN)).thenReturn(List.of(quiet, normal));

        alerts.newReport(report);

        verify(push, never()).toUser(org.mockito.ArgumentMatchers.eq(1L), any(), any(), any());
        verify(push).toUser(org.mockito.ArgumentMatchers.eq(2L), any(), any(), any());
    }

    @Test
    void switchesAreIndependentPerCategory() {
        User a = admin(1);
        a.setNotifAdminReports(false);
        when(users.findByRole(Role.ROLE_ADMIN)).thenReturn(List.of(a));

        alerts.withdrawalRequested("WD-1");
        alerts.paymentGatewayError("SNIPPE", "WALLET_TOPUP", "PAY-9", "X");

        verify(push).toUser(org.mockito.ArgumentMatchers.eq(1L), any(), any(), any());
        verify(push).toUserNow(org.mockito.ArgumentMatchers.eq(1L), any(), any(), any());
    }
}
