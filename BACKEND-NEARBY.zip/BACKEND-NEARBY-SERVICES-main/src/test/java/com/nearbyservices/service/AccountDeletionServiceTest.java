package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.Role;
import com.nearbyservices.model.User;
import com.nearbyservices.model.Wallet;
import com.nearbyservices.repository.EscrowTransactionRepository;
import com.nearbyservices.repository.LiveLocationRepository;
import com.nearbyservices.repository.PaymentRepository;
import com.nearbyservices.repository.ServicePostRepository;
import com.nearbyservices.repository.UserRepository;
import com.nearbyservices.repository.UserSearchTermRepository;
import com.nearbyservices.repository.UserVerificationProfileRepository;
import com.nearbyservices.repository.VerificationDocumentRepository;
import com.nearbyservices.repository.WalletRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyCollection;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/** Deleting an account: right password, nothing still open, then every personal field is erased. */
class AccountDeletionServiceTest {

    private UserRepository users;
    private WalletRepository wallets;
    private EscrowTransactionRepository escrows;
    private PaymentRepository payments;
    private ServicePostRepository services;
    private VerificationDocumentRepository docs;
    private UserVerificationProfileRepository profiles;
    private UserSearchTermRepository terms;
    private LiveLocationRepository live;
    private PasswordEncoder encoder;
    private AccountDeletionService service;
    private User user;

    @BeforeEach
    void setUp() {
        users = mock(UserRepository.class);
        wallets = mock(WalletRepository.class);
        escrows = mock(EscrowTransactionRepository.class);
        payments = mock(PaymentRepository.class);
        services = mock(ServicePostRepository.class);
        docs = mock(VerificationDocumentRepository.class);
        profiles = mock(UserVerificationProfileRepository.class);
        terms = mock(UserSearchTermRepository.class);
        live = mock(LiveLocationRepository.class);
        encoder = mock(PasswordEncoder.class);
        service = new AccountDeletionService(users, wallets, escrows, payments, services, docs, profiles, terms, live,
                mock(FileStorageService.class), encoder, new AttemptLimiter());

        user = User.builder().id(7L).username("zeen").phone("+255712345678").email("z@example.com")
                .password("hash").stageName("Zeen Spa").role(Role.ROLE_SELLER).bio("hello")
                .avatarUrl("/uploads/profile/avatars/a.jpg").nidaNumber("1990").build();
        when(users.findByIdForUpdate(7L)).thenReturn(Optional.of(user));
        when(users.findById(7L)).thenReturn(Optional.of(user));
        when(encoder.matches("right", "hash")).thenReturn(true);
        when(encoder.encode(anyString())).thenReturn("random-hash");
        when(wallets.findByUserId(7L)).thenReturn(Optional.empty());
        when(services.findBySellerId(7L)).thenReturn(List.of());
        when(docs.findByUserId(7L)).thenReturn(List.of());
        when(profiles.findById(7L)).thenReturn(Optional.empty());
    }

    @Test
    void wrongPasswordChangesNothing() {
        ApiException e = assertThrows(ApiException.class, () -> service.delete(user, "wrong"));
        assertEquals("WRONG_PASSWORD", e.getMessage());
        verify(users, never()).save(any());
        assertNull(user.getDeletedAt());
    }

    @Test
    void moneyInTheWalletBlocksDeletion() {
        Wallet w = new Wallet();
        w.setBalance(new BigDecimal("500"));
        w.setLockedEscrowBalance(BigDecimal.ZERO);
        when(wallets.findByUserId(7L)).thenReturn(Optional.of(w));
        ApiException e = assertThrows(ApiException.class, () -> service.delete(user, "right"));
        assertEquals("WALLET_NOT_EMPTY", e.getMessage());
        verify(users, never()).save(any());
    }

    @Test
    void openBookingBlocksDeletion() {
        when(escrows.existsByBuyerIdAndStatusIn(anyLong(), anyCollection())).thenReturn(true);
        ApiException e = assertThrows(ApiException.class, () -> service.delete(user, "right"));
        assertEquals("OPEN_BOOKINGS", e.getMessage());
    }

    @Test
    void adminAccountCannotBeDeleted() {
        user.setRole(Role.ROLE_ADMIN);
        ApiException e = assertThrows(ApiException.class, () -> service.delete(user, "right"));
        assertEquals("ADMIN_ACCOUNT", e.getMessage());
    }

    @Test
    void successErasesPersonalDataAndKeepsTheRow() {
        service.delete(user, "right");
        verify(users).save(user);
        assertNotNull(user.getDeletedAt());
        assertEquals("deleted-7", user.getPhone());
        assertEquals("deleted-7", user.getUsername());
        assertNull(user.getEmail());
        assertNull(user.getBio());
        assertNull(user.getAvatarUrl());
        assertNull(user.getNidaNumber());
        assertEquals("Deleted user", user.getStageName());
        assertEquals("random-hash", user.getPassword());
        assertNotNull(user.getTokensValidFrom());
        verify(terms).deleteByUserId(7L);
        verify(live).deleteByUserId(7L);
    }

    @Test
    void deletingTwiceIsHarmless() {
        service.delete(user, "right");
        service.delete(user, "anything"); // already deleted: returns quietly
        assertTrue(user.getDeletedAt() != null);
    }

    @Test
    void adminDeletionErasesWithoutPasswordButKeepsTheSameRules() {
        service.deleteByAdmin(1L, 7L);
        assertNotNull(user.getDeletedAt());
        assertEquals("deleted-7", user.getPhone());
        verify(users).save(user);
    }

    @Test
    void adminDeletionIsBlockedByMoneyInTheWallet() {
        Wallet w = new Wallet();
        w.setBalance(new BigDecimal("500"));
        w.setLockedEscrowBalance(BigDecimal.ZERO);
        when(wallets.findByUserId(7L)).thenReturn(Optional.of(w));
        ApiException e = assertThrows(ApiException.class, () -> service.deleteByAdmin(1L, 7L));
        assertEquals("WALLET_NOT_EMPTY", e.getMessage());
        verify(users, never()).save(any());
    }
}
