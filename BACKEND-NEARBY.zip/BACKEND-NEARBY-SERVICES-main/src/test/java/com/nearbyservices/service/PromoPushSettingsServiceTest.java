package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.AdminSettings;
import com.nearbyservices.repository.AdminSettingsRepository;
import com.nearbyservices.verification.AuditLog;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/** Promo push controls: on, every 6 hours by default; only 1-72 hours accepted; every change audited. */
class PromoPushSettingsServiceTest {

    private AdminSettings row;
    private AdminSettingsRepository repo;
    private AuditLog audit;
    private PromoPushSettingsService service;

    @BeforeEach
    void setUp() {
        row = AdminSettings.builder().build();
        repo = mock(AdminSettingsRepository.class);
        audit = mock(AuditLog.class);
        AdminSettingsService settings = mock(AdminSettingsService.class);
        when(settings.getSettings()).thenReturn(row);
        service = new PromoPushSettingsService(settings, repo, audit);
    }

    @Test
    void defaultsAreOnAndSixHours() {
        assertTrue(service.enabled());
        assertEquals(6, service.intervalHours());
    }

    @Test
    void adminCanChangeBoth_andItIsAudited() {
        service.update(9L, false, 12);
        assertFalse(service.enabled());
        assertEquals(12, service.intervalHours());
        verify(repo).save(row);
        verify(audit).record(9L, "PROMO_PUSH_SETTINGS_CHANGED", "enabled true -> false, hours 6 -> 12");
    }

    @Test
    void aMissingValueLeavesThatControlAsItIs() {
        service.update(9L, null, 3);
        assertTrue(service.enabled());
        assertEquals(3, service.intervalHours());
    }

    @Test
    void outOfRangeIsRefused_andNothingChanges() {
        for (int bad : new int[]{0, -1, 73, 500}) {
            assertThrows(ApiException.class, () -> service.update(1L, false, bad));
        }
        assertTrue(service.enabled());
        assertEquals(6, service.intervalHours());
        verify(repo, never()).save(any());
        verify(audit, never()).record(anyLong(), anyString(), anyString());
    }
}
