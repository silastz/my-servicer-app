package com.nearbyservices.service;

import com.nearbyservices.dto.AuthResponse;
import com.nearbyservices.dto.CompleteSignupRequest;
import com.nearbyservices.dto.LoginRequest;
import com.nearbyservices.dto.RegisterRequest;
import com.nearbyservices.model.Role;
import com.nearbyservices.model.User;
import com.nearbyservices.model.Wallet;
import com.nearbyservices.repository.UserRepository;
import com.nearbyservices.repository.WalletRepository;
import com.nearbyservices.security.JwtService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.Instant;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Rules:
 *  1. Sign-up step 1 saves NOTHING on the server (no account, no pending record). It texts a code and returns
 *     a signed challenge.
 *  2. The account (User + Wallet) is created only when the code comes back right (step 2), with the form.
 *  3. An account opens (login / token) only after its PHONE code was confirmed; a verified email is not enough.
 */
class AuthServiceOtpGateTest {

    private static final String PHONE = "+255712345678";

    private UserRepository userRepository;
    private WalletRepository walletRepository;
    private PasswordEncoder passwordEncoder;
    private JwtService jwtService;
    private SmsService smsService;
    private EmailService emailService;
    private SignupOtpChallenge challenges;
    private AuthService service;

    @BeforeEach
    void setUp() {
        userRepository = mock(UserRepository.class);
        walletRepository = mock(WalletRepository.class);
        passwordEncoder = mock(PasswordEncoder.class);
        jwtService = mock(JwtService.class);
        smsService = mock(SmsService.class);
        emailService = mock(EmailService.class);
        challenges = new SignupOtpChallenge("test-secret");
        when(passwordEncoder.encode(anyString())).thenReturn("new-hash");
        when(userRepository.save(any(User.class))).thenAnswer(inv -> inv.getArgument(0));
        service = new AuthService(
                userRepository,
                walletRepository,
                passwordEncoder,
                jwtService,
                mock(AuthenticationManager.class),
                emailService,
                smsService,
                new AttemptLimiter(),
                challenges);
    }

    private static RegisterRequest form() {
        RegisterRequest r = new RegisterRequest();
        r.setPhone(PHONE);
        r.setPassword("some-pass");
        r.setStageName("Someone");
        r.setRole(Role.ROLE_BUYER);
        r.setEmail("someone@example.com");
        return r;
    }

    private static CompleteSignupRequest step2(String otp, String challenge) {
        CompleteSignupRequest r = new CompleteSignupRequest();
        r.setPhone(PHONE);
        r.setOtp(otp);
        r.setChallenge(challenge);
        r.setPassword("some-pass");
        r.setStageName("Someone");
        r.setRole(Role.ROLE_BUYER);
        r.setEmail("someone@example.com");
        return r;
    }

    private static User account(boolean phoneVerified, boolean emailVerified) {
        User u = new User();
        u.setId(7L);
        u.setUsername("u_abc");
        u.setPhone(PHONE);
        u.setPassword("old-hash");
        u.setStageName("Original Name");
        u.setRole(Role.ROLE_BUYER);
        u.setEmail("owner@example.com");
        u.setPhoneVerified(phoneVerified);
        u.setEmailVerified(emailVerified);
        return u;
    }

    private String freshChallenge(String otp) {
        return challenges.issue(PHONE, otp, Instant.now().plusSeconds(300));
    }

    // ---- 1. step 1 saves nothing -------------------------------------------------------------------------------

    @Test
    void register_savesNothing_textsTheCode_andReturnsAChallengeForThatCode() {
        AuthResponse out = service.register(form());

        verify(userRepository, never()).save(any(User.class));
        verify(walletRepository, never()).save(any(Wallet.class));
        ArgumentCaptor<String> code = ArgumentCaptor.forClass(String.class);
        verify(smsService).sendOtpSms(anyString(), anyString(), code.capture());
        assertNull(out.getToken());
        assertNull(out.getId());
        assertFalse(out.isPhoneVerified());
        assertNotNull(out.getSignupChallenge());
        assertTrue(challenges.matches(PHONE, code.getValue(), out.getSignupChallenge()));
        assertFalse(out.getSignupChallenge().contains(code.getValue())); // the challenge does not reveal the code
    }

    @Test
    void register_overAVerifiedAccount_isRefusedAndTextsNothing() {
        User existing = account(true, false);
        when(userRepository.findByPhone(PHONE)).thenReturn(Optional.of(existing));

        IllegalArgumentException e = assertThrows(IllegalArgumentException.class, () -> service.register(form()));

        assertEquals("PHONE_ALREADY_REGISTERED", e.getMessage());
        assertEquals("old-hash", existing.getPassword());
        verify(smsService, never()).sendOtpSms(anyString(), anyString(), anyString());
    }

    @Test
    void register_overAnOlderUnconfirmedAccountRow_neverOverwritesIt() {
        User existing = account(false, false);
        when(userRepository.findByPhone(PHONE)).thenReturn(Optional.of(existing));

        IllegalArgumentException e = assertThrows(IllegalArgumentException.class, () -> service.register(form()));

        assertEquals("PHONE_VERIFICATION_PENDING", e.getMessage());
        assertEquals("old-hash", existing.getPassword());
        assertEquals("Original Name", existing.getStageName());
        verify(userRepository, never()).save(any(User.class));
        verify(smsService, never()).sendOtpSms(anyString(), anyString(), anyString());
    }

    // ---- 2. account created only on the right code ------------------------------------------------------------

    @Test
    void completeSignup_rightCode_createsTheAccountAndWallet_phoneVerified_andIssuesToken() {
        when(jwtService.generateToken(any(UserDetails.class), anyMap())).thenReturn("tok");

        AuthResponse out = service.completeSignup(step2("123456", freshChallenge("123456")));

        assertEquals("tok", out.getToken());
        assertTrue(out.isPhoneVerified());
        ArgumentCaptor<User> saved = ArgumentCaptor.forClass(User.class);
        verify(userRepository).save(saved.capture());
        assertTrue(saved.getValue().isPhoneVerified());
        assertEquals(PHONE, saved.getValue().getPhone());
        assertEquals("new-hash", saved.getValue().getPassword());
        verify(walletRepository).save(any(Wallet.class));
    }

    @Test
    void completeSignup_wrongCode_createsNothing() {
        IllegalArgumentException e = assertThrows(IllegalArgumentException.class,
                () -> service.completeSignup(step2("000000", freshChallenge("123456"))));

        assertEquals("INVALID_OR_EXPIRED_OTP", e.getMessage());
        verify(userRepository, never()).save(any(User.class));
        verify(walletRepository, never()).save(any(Wallet.class));
        verify(jwtService, never()).generateToken(any(UserDetails.class), anyMap());
    }

    @Test
    void completeSignup_expiredChallenge_createsNothing() {
        String expired = challenges.issue(PHONE, "123456", Instant.now().minusSeconds(5));

        assertThrows(IllegalArgumentException.class, () -> service.completeSignup(step2("123456", expired)));

        verify(userRepository, never()).save(any(User.class));
    }

    @Test
    void completeSignup_challengeMadeForAnotherPhone_createsNothing() {
        String other = challenges.issue("+255700000000", "123456", Instant.now().plusSeconds(300));

        assertThrows(IllegalArgumentException.class, () -> service.completeSignup(step2("123456", other)));

        verify(userRepository, never()).save(any(User.class));
    }

    @Test
    void completeSignup_withATamperedExpiry_createsNothing() {
        String real = freshChallenge("123456");
        String tampered = (Instant.now().getEpochSecond() + 999_999) + real.substring(real.indexOf('.'));

        assertThrows(IllegalArgumentException.class, () -> service.completeSignup(step2("123456", tampered)));

        verify(userRepository, never()).save(any(User.class));
    }

    @Test
    void completeSignup_whenThePhoneBecameAnAccountMeanwhile_isRefused() {
        when(userRepository.findByPhone(PHONE)).thenReturn(Optional.of(account(true, false)));

        IllegalArgumentException e = assertThrows(IllegalArgumentException.class,
                () -> service.completeSignup(step2("123456", freshChallenge("123456"))));

        assertEquals("PHONE_ALREADY_REGISTERED", e.getMessage());
        verify(userRepository, never()).save(any(User.class));
    }

    // ---- 3. only the phone code opens an account --------------------------------------------------------------

    @Test
    void login_isRefusedWhenOnlyTheEmailIsVerified() {
        User user = account(false, true);
        when(userRepository.findByEmail("owner@example.com")).thenReturn(Optional.of(user));

        LoginRequest req = new LoginRequest();
        req.setLogin("owner@example.com");
        req.setPassword("whatever");

        IllegalArgumentException e = assertThrows(IllegalArgumentException.class, () -> service.login(req));

        assertEquals("ACCOUNT_NOT_VERIFIED", e.getMessage());
        verify(jwtService, never()).generateToken(any(UserDetails.class), anyMap());
    }

    @Test
    void login_worksOnceThePhoneIsVerified() {
        User user = account(true, false);
        when(userRepository.findByPhone(PHONE)).thenReturn(Optional.of(user));
        when(jwtService.generateToken(any(UserDetails.class), anyMap())).thenReturn("tok");

        LoginRequest req = new LoginRequest();
        req.setLogin(PHONE);
        req.setPassword("whatever");

        assertEquals("tok", service.login(req).getToken());
    }
}
