package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.AdminSettings;
import com.nearbyservices.repository.AdminSettingsRepository;
import com.nearbyservices.verification.AuditLog;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/** The admin's "pending minutes" of a sent code: default 4, only 1-10 accepted, every change audited. */
class OtpSettingsServiceTest {

    private AdminSettings row;
    private AdminSettingsRepository repo;
    private AuditLog audit;
    private OtpSettingsService service;

    @BeforeEach
    void setUp() {
        row = AdminSettings.builder().build();
        repo = mock(AdminSettingsRepository.class);
        audit = mock(AuditLog.class);
        AdminSettingsService settings = mock(AdminSettingsService.class);
        when(settings.getSettings()).thenReturn(row);
        service = new OtpSettingsService(settings, repo, audit);
    }

    @Test
    void defaultIsFourMinutes() {
        assertEquals(4, service.pendingMinutes());
    }

    @Test
    void adminCanChangeIt_andItIsAudited() {
        assertEquals(7, service.setPendingMinutes(9L, 7));
        assertEquals(7, service.pendingMinutes());
        verify(repo).save(row);
        verify(audit).record(9L, "OTP_PENDING_MINUTES_CHANGED", "4 -> 7");
    }

    @Test
    void outOfRangeOrMissingIsRefused_andNothingChanges() {
        for (Integer bad : new Integer[]{null, 0, -3, 11, 500}) {
            assertThrows(ApiException.class, () -> service.setPendingMinutes(1L, bad));
        }
        assertEquals(4, service.pendingMinutes());
        verify(repo, never()).save(any());
        verify(audit, never()).record(anyLong(), anyString(), anyString());
    }

    @Test
    void edgesOneAndTenAreAllowed() {
        service.setPendingMinutes(1L, 1);
        assertEquals(1, service.pendingMinutes());
        service.setPendingMinutes(1L, 10);
        assertEquals(10, service.pendingMinutes());
    }

    @Test
    void aBrokenStoredValueFallsBackToTheDefault() {
        row.setOtpPendingMinutes(0); // e.g. an old row
        assertEquals(4, service.pendingMinutes());
    }
}
