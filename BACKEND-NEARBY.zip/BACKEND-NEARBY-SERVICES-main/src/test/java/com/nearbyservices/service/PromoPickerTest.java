package com.nearbyservices.service;

import com.nearbyservices.service.PromoPicker.Candidate;
import com.nearbyservices.service.PromoPicker.History;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** One boosted service per user: never their own or a blocked one, never-seen first, spread across users. */
class PromoPickerTest {

    private static final List<Candidate> THREE = List.of(new Candidate(1, 101), new Candidate(2, 102), new Candidate(3, 103));

    @Test
    void neverTheUsersOwnService_orABlockedSellers() {
        Long own = PromoPicker.pick(List.of(new Candidate(1, 7)), 7, Set.of(), Set.of(), Map.of(), Map.of(), new Random(1));
        assertNull(own);
        Long blocked = PromoPicker.pick(THREE, 5, Set.of(101L, 102L), Set.of(), Map.of(), Map.of(), new Random(1));
        assertEquals(3L, blocked);
    }

    @Test
    void nothingToPickWhenThereAreNoCandidates() {
        assertNull(PromoPicker.pick(List.of(), 5, Set.of(), Set.of(), Map.of(), Map.of(), new Random(1)));
    }

    @Test
    void aServiceTheUserHasNotSeenComesBeforeOneTheyHave() {
        Map<Long, History> seen = Map.of(1L, new History(2, Instant.parse("2026-10-24T10:00:00Z")),
                2L, new History(1, Instant.parse("2026-10-23T10:00:00Z")));
        for (long seed = 0; seed < 20; seed++) {
            assertEquals(3L, PromoPicker.pick(THREE, 5, Set.of(), Set.of(), seen, Map.of(), new Random(seed)));
        }
    }

    @Test
    void whenAllWereSeenEqually_theOneSentLongestAgoComesFirst() {
        Map<Long, History> seen = Map.of(
                1L, new History(1, Instant.parse("2026-10-24T10:00:00Z")),
                2L, new History(1, Instant.parse("2026-10-22T10:00:00Z")),
                3L, new History(1, Instant.parse("2026-10-23T10:00:00Z")));
        assertEquals(2L, PromoPicker.pick(THREE, 5, Set.of(), Set.of(), seen, Map.of(), new Random(1)));
    }

    @Test
    void newUsersAreSpreadAcrossServices_bytheRecentTotals() {
        Map<Long, Integer> recent = new HashMap<>();
        Set<Long> got = new HashSet<>();
        for (long user = 1; user <= 3; user++) {
            Long id = PromoPicker.pick(THREE, user, Set.of(), Set.of(), Map.of(), recent, new Random(user));
            got.add(id);
            recent.merge(id, 1, Integer::sum); // what the job does after each push
        }
        assertEquals(Set.of(1L, 2L, 3L), got); // three new users, three different services
    }

    @Test
    void aServiceTheUserSearchedForComesFirst_evenIfSeenBefore() {
        Map<Long, History> seen = Map.of(2L, new History(5, Instant.parse("2026-10-24T10:00:00Z")));
        for (long seed = 0; seed < 20; seed++) {
            assertEquals(2L, PromoPicker.pick(THREE, 5, Set.of(), Set.of(2L), seen, Map.of(), new Random(seed)));
        }
    }

    @Test
    void windowIsByTheUsersOwnClock() {
        ZoneId eat = ZoneId.of("Africa/Nairobi");
        assertFalse(PromoPicker.inWindow(ZonedDateTime.of(2026, 10, 25, 7, 59, 0, 0, eat), 8, 20));
        assertTrue(PromoPicker.inWindow(ZonedDateTime.of(2026, 10, 25, 8, 0, 0, 0, eat), 8, 20));
        assertTrue(PromoPicker.inWindow(ZonedDateTime.of(2026, 10, 25, 19, 59, 0, 0, eat), 8, 20));
        assertFalse(PromoPicker.inWindow(ZonedDateTime.of(2026, 10, 25, 20, 0, 0, 0, eat), 8, 20));
        // a window that crosses midnight
        assertTrue(PromoPicker.inWindow(ZonedDateTime.of(2026, 10, 25, 23, 0, 0, 0, eat), 22, 6));
        assertFalse(PromoPicker.inWindow(ZonedDateTime.of(2026, 10, 25, 12, 0, 0, 0, eat), 22, 6));
    }
}
