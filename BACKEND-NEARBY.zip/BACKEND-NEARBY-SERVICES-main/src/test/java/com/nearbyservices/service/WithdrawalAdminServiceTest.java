package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.PlatformEntry;
import com.nearbyservices.model.User;
import com.nearbyservices.model.Wallet;
import com.nearbyservices.model.WalletTransaction;
import com.nearbyservices.repository.PlatformEntryRepository;
import com.nearbyservices.repository.WalletRepository;
import com.nearbyservices.repository.WalletTransactionRepository;
import com.nearbyservices.verification.AuditLog;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/** Completing or failing a payout: once only; a failure gives the money back and reverses the fees. */
class WithdrawalAdminServiceTest {

    private final WalletTransactionRepository walletTransactions = mock(WalletTransactionRepository.class);
    private final WalletRepository walletRepository = mock(WalletRepository.class);
    private final PlatformEntryRepository entries = mock(PlatformEntryRepository.class);
    private final AuditLog auditLog = mock(AuditLog.class);
    private final WithdrawalAdminService service =
            new WithdrawalAdminService(walletTransactions, walletRepository, entries, auditLog);

    private WalletTransaction withdrawal;
    private Wallet wallet;

    @BeforeEach
    void setUp() {
        withdrawal = WalletTransaction.builder().id(1L).userId(7L).type("WITHDRAWAL").direction("OUT")
                .amount(new BigDecimal("10000")).status("PENDING").reference("WD-AAAA1111")
                .collectionFee(100L).chargeFee(900L).payoutPart(500L).vatPart(400L).netAmount(9000L)
                .payoutPhone("255712345678").build();
        wallet = new Wallet();
        wallet.setUser(User.builder().id(7L).build());
        wallet.setBalance(new BigDecimal("2000"));
        wallet.setLockedEscrowBalance(BigDecimal.ZERO);
        when(walletTransactions.findWithdrawalForUpdate("WD-AAAA1111")).thenReturn(Optional.of(withdrawal));
        when(walletTransactions.save(any(WalletTransaction.class))).thenAnswer(i -> i.getArgument(0));
        when(walletRepository.findByUserIdForUpdate(7L)).thenReturn(Optional.of(wallet));
    }

    @Test
    void complete_marksPendingAsCompleted_andMovesNoMoney() {
        Map<String, Object> out = service.complete(5L, "WD-AAAA1111");

        assertEquals("COMPLETED", withdrawal.getStatus());
        assertEquals("COMPLETED", out.get("status"));
        assertEquals("255712345678", out.get("phone"));
        assertEquals(0, new BigDecimal("2000").compareTo(wallet.getBalance()));
        verify(walletRepository, never()).save(any());
    }

    @Test
    void fail_refundsTheWholeAmount_andReversesTheFeeLines() {
        PlatformEntry collection = PlatformEntry.builder().type("COLLECTION_FEE").direction("IN").status("COMPLETED").reference("WD-AAAA1111").build();
        PlatformEntry payout = PlatformEntry.builder().type("PAYOUT_FEE").direction("IN").status("COMPLETED").reference("WD-AAAA1111").build();
        PlatformEntry vat = PlatformEntry.builder().type("VAT").direction("IN").status("COMPLETED").reference("WD-AAAA1111").build();
        when(entries.findByReferenceAndTypeIn(any(), any())).thenReturn(List.of(collection, payout, vat));

        service.fail(5L, "WD-AAAA1111", "  number not registered ");

        assertEquals("FAILED", withdrawal.getStatus());
        assertEquals("number not registered", withdrawal.getFailReason());
        assertEquals(0, new BigDecimal("12000").compareTo(wallet.getBalance())); // 2,000 + the full 10,000
        verify(walletRepository).save(wallet);
        for (PlatformEntry e : List.of(collection, payout, vat)) assertEquals("REVERSED", e.getStatus());
    }

    @Test
    void secondComplete_orFailAfterCompleteOrFail_isInvalidStatus_andRefundsNothing() {
        withdrawal.setStatus("FAILED");

        assertEquals("INVALID_STATUS:FAILED", assertThrows(ApiException.class, () -> service.fail(5L, "WD-AAAA1111", null)).getMessage());
        assertEquals("INVALID_STATUS:FAILED", assertThrows(ApiException.class, () -> service.complete(5L, "WD-AAAA1111")).getMessage());
        withdrawal.setStatus("COMPLETED");
        assertEquals("INVALID_STATUS:COMPLETED", assertThrows(ApiException.class, () -> service.fail(5L, "WD-AAAA1111", null)).getMessage());
        verify(walletRepository, never()).save(any());
    }

    @Test
    void platformWithdrawal_failStopsCounting_completeKeepsIt() {
        PlatformEntry own = PlatformEntry.builder().type("WITHDRAWAL").direction("OUT").amount(new BigDecimal("5000"))
                .status("PENDING").reference("AWD-BBBB2222").adminId(5L).payoutPhone("255700000000").build();
        when(walletTransactions.findWithdrawalForUpdate("AWD-BBBB2222")).thenReturn(Optional.empty());
        when(entries.findByTypeAndReferenceForUpdate("WITHDRAWAL", "AWD-BBBB2222")).thenReturn(Optional.of(own));
        when(entries.save(any(PlatformEntry.class))).thenAnswer(i -> i.getArgument(0));

        service.fail(5L, "AWD-BBBB2222", null);
        assertEquals("FAILED", own.getStatus());

        own.setStatus("PENDING");
        service.complete(5L, "AWD-BBBB2222");
        assertEquals("COMPLETED", own.getStatus());
        verify(walletRepository, never()).save(any());
    }

    @Test
    void unknownReference_isNotFound() {
        when(walletTransactions.findWithdrawalForUpdate("WD-NOPE0000")).thenReturn(Optional.empty());
        when(entries.findByTypeAndReferenceForUpdate("WITHDRAWAL", "WD-NOPE0000")).thenReturn(Optional.empty());
        assertEquals("WITHDRAWAL_NOT_FOUND", assertThrows(ApiException.class, () -> service.complete(5L, "WD-NOPE0000")).getMessage());
    }

    @Test
    void list_refusesAnUnknownStatus() {
        assertEquals("INVALID_STATUS", assertThrows(ApiException.class, () -> service.list("DONE", 10)).getMessage());
    }
}
