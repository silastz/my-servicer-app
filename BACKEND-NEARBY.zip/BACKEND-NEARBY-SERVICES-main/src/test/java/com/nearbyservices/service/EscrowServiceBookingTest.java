package com.nearbyservices.service;

import com.nearbyservices.dto.CreateEscrowRequest;
import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.EscrowStatus;
import com.nearbyservices.model.EscrowTransaction;
import com.nearbyservices.model.PaymentMethod;
import com.nearbyservices.model.ServicePost;
import com.nearbyservices.model.User;
import com.nearbyservices.repository.EscrowTransactionRepository;
import com.nearbyservices.repository.ServicePostRepository;
import com.nearbyservices.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/** Booking money rules: the server sets the price, the service must be the seller's and active, one refund per booking. */
class EscrowServiceBookingTest {

    private final EscrowTransactionRepository escrowRepository = mock(EscrowTransactionRepository.class);
    private final UserBlockService userBlockService = mock(UserBlockService.class);
    private final UserRepository userRepository = mock(UserRepository.class);
    private final ServicePostRepository servicePostRepository = mock(ServicePostRepository.class);
    private final OfferService offerService = mock(OfferService.class);
    private final PushService pushService = mock(PushService.class);

    private EscrowService service;
    private User buyer;
    private User seller;

    @BeforeEach
    void setUp() {
        EscrowService real = new EscrowService(escrowRepository, userBlockService, userRepository,
                mock(com.nearbyservices.repository.WalletRepository.class), servicePostRepository,
                mock(WalletService.class), mock(VerificationService.class), offerService,
                mock(PaymentSettingsService.class), mock(PlatformWalletService.class),
                mock(com.nearbyservices.repository.UserVerificationProfileRepository.class),
                mock(PaymentService.class), pushService, mock(FileStorageService.class), mock(AttemptLimiter.class),
                mock(com.nearbyservices.repository.ReviewRepository.class), mock(LiveLocationService.class));
        service = spy(real);
        doReturn(null).when(service).mapToResponse(any()); // the response mapping is not what is tested here

        buyer = User.builder().id(1L).build();
        seller = User.builder().id(2L).build();
        when(userRepository.findById(2L)).thenReturn(Optional.of(seller));
        when(escrowRepository.save(any(EscrowTransaction.class))).thenAnswer(i -> i.getArgument(0));
    }

    private ServicePost post(long id, User owner, boolean active) {
        ServicePost p = new ServicePost();
        p.setId(id);
        p.setSeller(owner);
        p.setActive(active);
        p.setPrice(new BigDecimal("50000"));
        return p;
    }

    private CreateEscrowRequest request(Long serviceId, String amount) {
        CreateEscrowRequest r = new CreateEscrowRequest();
        r.setSellerId(2L);
        r.setServiceId(serviceId);
        r.setAmount(new BigDecimal(amount));
        r.setPaymentMethod(PaymentMethod.PAY_AFTER_ACCEPT);
        return r;
    }

    private static String code(Runnable call) {
        return assertThrows(ApiException.class, call::run).getMessage();
    }

    @Test
    void priceComesFromTheService_notFromTheApp() {
        ServicePost p = post(10, seller, true);
        when(servicePostRepository.findById(10L)).thenReturn(Optional.of(p));
        when(offerService.currentPrice(p)).thenReturn(new BigDecimal("45000"));

        service.initiateEscrow(buyer, request(10L, "1"));

        ArgumentCaptor<EscrowTransaction> saved = ArgumentCaptor.forClass(EscrowTransaction.class);
        verify(escrowRepository).save(saved.capture());
        assertEquals(0, new BigDecimal("45000").compareTo(saved.getValue().getAmount()));
    }

    @Test
    void missingServiceId_isRefused() {
        assertEquals("SERVICE_REQUIRED", code(() -> service.initiateEscrow(buyer, request(null, "50000"))));
        verify(escrowRepository, never()).save(any());
    }

    @Test
    void unknownService_isRefused() {
        when(servicePostRepository.findById(99L)).thenReturn(Optional.empty());
        assertEquals("SERVICE_NOT_FOUND", code(() -> service.initiateEscrow(buyer, request(99L, "50000"))));
        verify(escrowRepository, never()).save(any());
    }

    @Test
    void serviceOfAnotherSeller_isRefusedAsNotFound() {
        User other = User.builder().id(3L).build();
        when(servicePostRepository.findById(10L)).thenReturn(Optional.of(post(10, other, true)));
        assertEquals("SERVICE_NOT_FOUND", code(() -> service.initiateEscrow(buyer, request(10L, "50000"))));
        verify(escrowRepository, never()).save(any());
    }

    @Test
    void inactiveService_isRefused() {
        when(servicePostRepository.findById(10L)).thenReturn(Optional.of(post(10, seller, false)));
        assertEquals("SERVICE_NOT_ACTIVE", code(() -> service.initiateEscrow(buyer, request(10L, "50000"))));
        verify(escrowRepository, never()).save(any());
    }

    @Test
    void cancelAndRejectAndReleaseReadTheBookingWithARowLock() {
        when(escrowRepository.findByTransactionRefForUpdate("ESC-1")).thenReturn(Optional.empty());

        assertEquals("BOOKING_NOT_FOUND", code(() -> service.cancelRequest(buyer, "ESC-1")));
        assertEquals("BOOKING_NOT_FOUND", code(() -> service.rejectRequest(seller, "ESC-1")));
        assertEquals("BOOKING_NOT_FOUND", code(() -> service.releaseFundsOnBuyerSatisfied(buyer, "ESC-1")));
        assertEquals("BOOKING_NOT_FOUND", code(() -> service.adminReleaseFunds("ESC-1")));
        verify(escrowRepository, never()).findByTransactionRef(anyString());
    }

    @Test
    void secondCancelOfARefundedBooking_isInvalidStatus_andMovesNoMoney() {
        EscrowTransaction tx = EscrowTransaction.builder().transactionRef("ESC-2").buyer(buyer).seller(seller)
                .amount(new BigDecimal("1000")).paymentMethod(PaymentMethod.POCKET_FUND)
                .status(EscrowStatus.CANCELLED).build();
        when(escrowRepository.findByTransactionRefForUpdate("ESC-2")).thenReturn(Optional.of(tx));

        assertEquals("INVALID_STATUS:CANCELLED", code(() -> service.cancelRequest(buyer, "ESC-2")));
        verify(escrowRepository, never()).save(any());
    }

    @Test
    void someoneElsesBooking_isNotYourBooking() {
        EscrowTransaction tx = EscrowTransaction.builder().transactionRef("ESC-3").buyer(buyer).seller(seller)
                .amount(new BigDecimal("1000")).status(EscrowStatus.PENDING_ACCEPTANCE).build();
        when(escrowRepository.findByTransactionRefForUpdate("ESC-3")).thenReturn(Optional.of(tx));

        User stranger = User.builder().id(9L).build();
        assertEquals("NOT_YOUR_BOOKING", code(() -> service.cancelRequest(stranger, "ESC-3")));
        assertEquals("NOT_YOUR_BOOKING", code(() -> service.rejectRequest(stranger, "ESC-3")));
    }
}
