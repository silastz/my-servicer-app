package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.Role;
import com.nearbyservices.model.User;
import com.nearbyservices.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/** An admin's alert switches: all on by default, partial updates, bad values refused. */
class AdminNotificationPrefsServiceTest {

    private AdminNotificationPrefsService service;
    private User admin;

    @BeforeEach
    void setUp() {
        UserRepository users = mock(UserRepository.class);
        admin = User.builder().id(1L).username("a").phone("p").password("x").stageName("A").role(Role.ROLE_ADMIN).build();
        when(users.findById(1L)).thenReturn(Optional.of(admin));
        when(users.save(any(User.class))).thenAnswer(i -> i.getArgument(0));
        service = new AdminNotificationPrefsService(users);
    }

    @Test
    void everythingIsOnByDefault() {
        Map<String, Object> m = service.get(1L);
        assertEquals(Map.of("reports", true, "disputes", true, "withdrawals", true, "payments", true), m);
    }

    @Test
    void onlyTheSentSwitchesChange() {
        Map<String, Object> body = new HashMap<>();
        body.put("reports", false);
        Map<String, Object> m = service.update(1L, body);
        assertFalse(admin.isNotifAdminReports());
        assertTrue(admin.isNotifAdminDisputes());
        assertEquals(false, m.get("reports"));
        assertEquals(true, m.get("payments"));
    }

    @Test
    void aNonBooleanValueChangesNothing() {
        Map<String, Object> body = new HashMap<>();
        body.put("payments", false);
        body.put("reports", "no");
        ApiException e = assertThrows(ApiException.class, () -> service.update(1L, body));
        assertEquals("INVALID_PREFERENCE", e.getMessage());
        assertTrue(admin.isNotifAdminPayments());
    }
}
