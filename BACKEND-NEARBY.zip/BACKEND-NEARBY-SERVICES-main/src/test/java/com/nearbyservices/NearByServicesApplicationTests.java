package com.nearbyservices;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertTrue;

class NearByServicesApplicationTests {

    @Test
    void unitTestCheck() {
        assertTrue(true);
    }
}
