package com.nearbyservices.security;

import org.junit.jupiter.api.Test;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/** The login is a sliding one: a young token is kept, an older one is swapped for a fresh token with the same claims. */
class JwtServiceTest {

    // 32 bytes, base64: valid HS256 key for the test only
    private static final String KEY = "dGVzdC1rZXktZm9yLWp3dC1zZXJ2aWNlLXRlc3QtMDEyMzQ1Njc=";

    private JwtService service(long renewAfterMs) {
        JwtService s = new JwtService();
        ReflectionTestUtils.setField(s, "secretKey", KEY);
        ReflectionTestUtils.setField(s, "jwtExpiration", 31_536_000_000L);
        ReflectionTestUtils.setField(s, "renewAfter", renewAfterMs);
        return s;
    }

    private UserDetails user() {
        return User.withUsername("42").password("x").authorities("ROLE_USER").build();
    }

    @Test
    void youngTokenIsNotRenewed() {
        JwtService s = service(7L * 24 * 3600 * 1000);
        String token = s.generateToken(user(), Map.of("role", "ROLE_USER"));
        assertNull(s.renewedIfDue(token, user()));
    }

    @Test
    void oldTokenIsRenewedWithSameClaims() {
        JwtService s = service(0); // everything counts as old
        String token = s.generateToken(user(), Map.of("role", "ROLE_USER"));
        String fresh = s.renewedIfDue(token, user());
        assertNotNull(fresh);
        assertEquals("42", s.extractUsername(fresh));
        assertEquals("ROLE_USER", s.extractClaim(fresh, c -> c.get("role", String.class)));
        assertTrue(s.isTokenValid(fresh, user()));
    }

    @Test
    void loginLastsAboutAYear() {
        JwtService s = service(7L * 24 * 3600 * 1000);
        String token = s.generateToken(user());
        long left = s.extractClaim(token, c -> c.getExpiration().getTime()) - System.currentTimeMillis();
        assertTrue(left > 360L * 24 * 3600 * 1000);
    }
}
