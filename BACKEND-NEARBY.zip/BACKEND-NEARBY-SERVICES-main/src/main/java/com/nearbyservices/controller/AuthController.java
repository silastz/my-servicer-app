package com.nearbyservices.controller;

import com.nearbyservices.dto.AuthResponse;
import com.nearbyservices.dto.LoginRequest;
import com.nearbyservices.dto.RegisterRequest;
import com.nearbyservices.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@Valid @RequestBody RegisterRequest request) {
        return ResponseEntity.ok(authService.register(request));
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody LoginRequest request) {
        return ResponseEntity.ok(authService.login(request));
    }

    @PostMapping("/verify-otp")
    public ResponseEntity<Map<String, Object>> verifyOtp(@RequestBody Map<String, String> payload) {
        String email = payload.get("email");
        String otp = payload.get("otp");
        boolean success = authService.verifyEmailOtp(email, otp);
        if (success) {
            return ResponseEntity.ok(Map.of("success", true, "message", "Email verified successfully"));
        } else {
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", "Invalid or expired OTP"));
        }
    }

    @PostMapping("/resend-otp")
    public ResponseEntity<Map<String, Object>> resendOtp(@RequestBody Map<String, String> payload) {
        String email = payload.get("email");
        authService.resendEmailOtp(email);
        // Same reply whether or not the account exists (no account enumeration).
        return ResponseEntity.ok(Map.of("success", true, "message", "If the account exists, a new code was sent"));
    }

    @PostMapping("/phone/verify-otp")
    public ResponseEntity<Map<String, Object>> verifyPhoneOtp(@RequestBody Map<String, String> payload) {
        String phone = payload.get("phone");
        String otp = payload.get("otp");
        return authService.verifyPhoneOtp(phone, otp)
                .map(authResponse -> ResponseEntity.ok(Map.<String, Object>of(
                        "success", true,
                        "message", "Phone verified successfully",
                        "data", authResponse
                )))
                .orElseGet(() -> ResponseEntity.badRequest().body(Map.<String, Object>of(
                        "success", false,
                        "message", "Invalid or expired OTP code"
                )));
    }

    /** Sign-up step 2: the SMS code and the sign-up form together. The account is created only here, on a right code. */
    @PostMapping("/phone/complete-signup")
    public ResponseEntity<Map<String, Object>> completeSignup(@Valid @RequestBody com.nearbyservices.dto.CompleteSignupRequest request) {
        AuthResponse account = authService.completeSignup(request);
        return ResponseEntity.ok(Map.<String, Object>of(
                "success", true,
                "message", "Phone verified successfully",
                "data", account
        ));
    }

    @PostMapping("/phone/resend-otp")
    public ResponseEntity<Map<String, Object>> resendPhoneOtp(@RequestBody Map<String, String> payload) {
        String phone = payload.get("phone");
        authService.resendPhoneOtp(phone);
        // Same reply whether or not the account exists (no account enumeration).
        return ResponseEntity.ok(Map.of("success", true, "message", "If the account exists, a new code was sent"));
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<Map<String, Object>> forgotPassword(@Valid @RequestBody com.nearbyservices.dto.ForgotPasswordRequest request) {
        try {
            return ResponseEntity.ok(authService.forgotPassword(request));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", e.getMessage()));
        }
    }

    @PostMapping("/reset-password")
    public ResponseEntity<Map<String, Object>> resetPassword(@Valid @RequestBody com.nearbyservices.dto.ResetPasswordRequest request) {
        try {
            return ResponseEntity.ok(authService.resetPassword(request));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", e.getMessage()));
        }
    }
}
