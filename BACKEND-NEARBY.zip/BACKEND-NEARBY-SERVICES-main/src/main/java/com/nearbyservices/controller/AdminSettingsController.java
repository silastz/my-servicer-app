package com.nearbyservices.controller;

import com.nearbyservices.model.AdminSettings;
import com.nearbyservices.service.AdminSettingsService;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@RestController
@RequestMapping("/api/admin/settings")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
public class AdminSettingsController {

    private final AdminSettingsService adminSettingsService;

    @GetMapping
    public ResponseEntity<AdminSettings> getSettings() {
        return ResponseEntity.ok(adminSettingsService.getSettings());
    }

    @PutMapping
    public ResponseEntity<AdminSettings> updateSettings(@RequestBody UpdateSettingsRequest req) {
        AdminSettings updated = adminSettingsService.updateSettings(
                req.getSellerRegistrationFee(),
                req.getFreeServicesQuota(),
                req.getCombinedPackageCount(),
                req.getPackagePrice(),
                req.getServiceFee()
        );
        if (req.getSupportPhone() != null || req.getSupportWhatsapp() != null || req.getSupportEmail() != null) {
            updated = adminSettingsService.updateSupport(req.getSupportPhone(), req.getSupportWhatsapp(), req.getSupportEmail());
        }
        return ResponseEntity.ok(updated);
    }

    @Data
    public static class UpdateSettingsRequest {
        private BigDecimal sellerRegistrationFee;
        private Integer freeServicesQuota;
        private Integer combinedPackageCount;
        private BigDecimal packagePrice;
        private BigDecimal serviceFee;
        // Support contacts for the Help screen. Not sent = unchanged, empty text = cleared.
        private String supportPhone;
        private String supportWhatsapp;
        private String supportEmail;
    }
}
