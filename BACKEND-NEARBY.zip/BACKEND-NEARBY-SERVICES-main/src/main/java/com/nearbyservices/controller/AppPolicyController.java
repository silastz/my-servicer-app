package com.nearbyservices.controller;

import com.nearbyservices.dto.ProviderFeesDto;
import com.nearbyservices.model.AdminSettings;
import com.nearbyservices.repository.BoostPlanRepository;
import com.nearbyservices.service.AdminSettingsService;
import com.nearbyservices.service.OtpSettingsService;
import com.nearbyservices.service.ServiceCategoryAdminService;
import com.nearbyservices.service.SupportContactService;
import com.nearbyservices.service.PaymentSettingsService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * GET /api/app/policy (public): the numbers the admin controls, so the app can show them before the server
 * answers its own calls. The app only DISPLAYS these; the server still sets every real price and limit.
 * Fields the server has no setting for (topUpMin / topUpMax, security) are left out: the app uses its defaults.
 */
@RestController
@RequestMapping("/api/app")
@RequiredArgsConstructor
public class AppPolicyController {

    /** The gateways the app knows by name. Anything else (SANDBOX) is left out and the app uses its default. */
    private static final Set<String> APP_GATEWAYS = Set.of("DPO", "SNIPPE", "CLICKPESA", "SELCOM", "PESAPAL");

    private final AdminSettingsService adminSettingsService;
    private final PaymentSettingsService paymentSettings;
    private final BoostPlanRepository boostPlanRepository;
    private final OtpSettingsService otpSettings;
    private final ServiceCategoryAdminService categoryService;
    private final SupportContactService supportContacts;

    /** Full Terms / Privacy pages (https). Empty = not sent, and the app shows its short in-app text. */
    @Value("${app.legal.terms-url:}")
    private String termsUrl;
    @Value("${app.legal.privacy-url:}")
    private String privacyUrl;

    /** Public https address of this server. Used to build the default Terms / Privacy links (see LegalController). */
    @Value("${app.public-base-url:}")
    private String publicBaseUrl;

    private String legalUrl(String configured, String path) {
        if (httpsUrl(configured)) return configured.trim();
        if (!httpsUrl(publicBaseUrl)) return null;
        String base = publicBaseUrl.trim();
        while (base.endsWith("/")) base = base.substring(0, base.length() - 1);
        return base + path;
    }

    private static boolean httpsUrl(String v) {
        return v != null && v.trim().regionMatches(true, 0, "https://", 0, 8) && v.trim().length() > 8;
    }

    private static boolean notBlank(String v) {
        return v != null && !v.isBlank();
    }

    @GetMapping("/policy")
    public Map<String, Object> policy() {
        AdminSettings s = adminSettingsService.getSettings();
        ProviderFeesDto f = paymentSettings.fees();

        Map<String, Object> provider = new LinkedHashMap<>();
        provider.put("collectionPercent", f.getCollectionPercent());
        provider.put("vatPercent", f.getVatPercent());
        provider.put("payoutFee", f.getPayoutFee());
        provider.put("withdrawMin", f.getWithdrawMin());
        provider.put("withdrawMax", f.getWithdrawMax());

        List<Map<String, Object>> plans = boostPlanRepository.findByActiveTrueOrderByDaysAsc().stream().map(p -> {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", p.getId());
            m.put("days", p.getDays());
            m.put("price", p.getPrice());
            return m;
        }).toList();

        Map<String, Object> fees = new LinkedHashMap<>();
        fees.put("registrationFee", s.getSellerRegistrationFee());
        fees.put("serviceFee", s.getServiceFee());
        fees.put("freeServiceLimit", s.getFreeServicesQuota());
        if (s.getTopUpMin() != null && s.getTopUpMin() > 0) fees.put("topUpMin", s.getTopUpMin());
        if (s.getTopUpMax() != null && s.getTopUpMax() > 0) fees.put("topUpMax", s.getTopUpMax());
        if (!plans.isEmpty()) fees.put("boostPlans", plans);
        fees.put("provider", provider);

        Map<String, Object> data = new LinkedHashMap<>();
        data.put("fees", fees);
        String gateway = paymentSettings.activeGatewayId().toUpperCase(Locale.ROOT);
        Map<String, Object> payments = new LinkedHashMap<>();
        if (APP_GATEWAYS.contains(gateway)) payments.put("gateway", gateway);
        payments.put("cardEnabled", paymentSettings.cardEnabled());
        data.put("payments", payments);
        // Support contacts for the Help screen: what the admin saved, else the SUPPORT_* env vars. Unset ones are left out (the app hides them).
        Map<String, Object> support = supportContacts.effective();
        data.put("support", support);
        // Links to the full Terms and Privacy Policy pages (APP_TERMS_URL / APP_PRIVACY_URL). Unset ones are left out.
        Map<String, Object> legal = new LinkedHashMap<>();
        String terms = legalUrl(termsUrl, "/legal/terms");
        String privacy = legalUrl(privacyUrl, "/legal/privacy");
        if (terms != null) legal.put("termsUrl", terms);
        if (privacy != null) legal.put("privacyUrl", privacy);
        if (!legal.isEmpty()) data.put("legal", legal);
        // Security switches the admin set; the ones never set are left out (the app uses its build default).
        Map<String, Object> security = new LinkedHashMap<>();
        if (s.getScreenCaptureAllowed() != null) security.put("screenCaptureAllowed", s.getScreenCaptureAllowed());
        if (s.getBlockCompromisedDevice() != null) security.put("blockCompromisedDevice", s.getBlockCompromisedDevice());
        if (s.getPlayIntegrity() != null) security.put("playIntegrity", s.getPlayIntegrity());
        if (s.getBlockVpn() != null) security.put("blockVpn", s.getBlockVpn());
        if (!security.isEmpty()) data.put("security", security);
        // Service categories the admin keeps switched on, in order: [{id, nameEn, nameSw}]. Empty = app uses its built-in list.
        List<Map<String, Object>> categories = categoryService.publicList();
        if (!categories.isEmpty()) data.put("categories", categories);
        // Minutes a sent sign-up / reset code stays "pending" in the app (reopen + same phone/email = code screen).
        data.put("auth", Map.of("otpPendingMinutes", otpSettings.pendingMinutes()));
        return Map.of("data", data);
    }
}
