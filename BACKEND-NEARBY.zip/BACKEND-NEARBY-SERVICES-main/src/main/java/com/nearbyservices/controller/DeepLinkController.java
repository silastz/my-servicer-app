package com.nearbyservices.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.CacheControl;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.time.Duration;
import java.util.Arrays;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * What the app's Android App Links need from this host (the manifest has android:autoVerify="true"):
 *   GET /.well-known/assetlinks.json   proves the app owns https://host/i/* and /s/* (set ANDROID_SHA256_FINGERPRINTS)
 *   GET /i/{code}  invitation link     GET /s/{id}  shared service link
 * With the app installed Android opens the app directly. Without it (or on a phone that does not verify) the
 * visitor sees a small page that tries the nearbyservices:// link and offers the Play Store.
 * All three are public (SecurityConfig).
 */
@RestController
public class DeepLinkController {

    private static final Pattern CODE = Pattern.compile("[A-Za-z0-9_-]{1,64}");
    private static final Pattern SHA256 = Pattern.compile("([0-9A-Fa-f]{2}:){31}[0-9A-Fa-f]{2}");
    private static final String PACKAGE = "com.unganalink.app";
    private static final String STORE = "https://play.google.com/store/apps/details?id=" + PACKAGE;

    /** Signing certificate SHA-256 fingerprint(s), colon format, comma separated (Play Console > App integrity). */
    private final String fingerprints;

    public DeepLinkController(@Value("${app.android-sha256:}") String fingerprints) {
        this.fingerprints = fingerprints;
    }

    @GetMapping(value = "/.well-known/assetlinks.json", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> assetLinks() {
        String list = Arrays.stream(fingerprints.split(","))
                .map(String::trim)
                .filter(f -> SHA256.matcher(f).matches())
                .map(f -> "\"" + f.toUpperCase() + "\"")
                .collect(Collectors.joining(","));
        String body = list.isEmpty()
                ? "[]"
                : "[{\"relation\":[\"delegate_permission/common.handle_all_urls\"],\"target\":{\"namespace\":\"android_app\","
                  + "\"package_name\":\"" + PACKAGE + "\",\"sha256_cert_fingerprints\":[" + list + "]}}]";
        return ResponseEntity.ok().cacheControl(CacheControl.maxAge(Duration.ofHours(1)).cachePublic()).body(body);
    }

    @GetMapping(value = "/i/{code}", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<String> invite(@PathVariable String code) {
        return landing(CODE.matcher(code).matches() ? "nearbyservices://invite/" + code : null,
                "You have been invited to Ungana");
    }

    @GetMapping(value = "/s/{id}", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<String> service(@PathVariable String id) {
        return landing(CODE.matcher(id).matches() ? "nearbyservices://service/" + id : null,
                "Open this service in Ungana");
    }

    private static ResponseEntity<String> landing(String appLink, String title) {
        String open = appLink == null ? "" : "<p><a class=\"b\" href=\"" + appLink + "\">Open in the app</a></p>";
        String html = "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\">"
                + "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Ungana</title>"
                + "<style>body{font-family:system-ui,sans-serif;text-align:center;padding:48px 20px;color:#1b1b1b}"
                + ".b{display:inline-block;padding:12px 22px;border-radius:10px;background:#0a7d4f;color:#fff;text-decoration:none}"
                + "</style></head><body><h2>" + title + "</h2>" + open
                + "<p><a class=\"b\" href=\"" + STORE + "\">Get the app on Google Play</a></p></body></html>";
        return ResponseEntity.ok().header("X-Robots-Tag", "noindex").body(html);
    }
}
