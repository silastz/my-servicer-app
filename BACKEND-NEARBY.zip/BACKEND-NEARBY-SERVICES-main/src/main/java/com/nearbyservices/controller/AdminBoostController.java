package com.nearbyservices.controller;

import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.BoostPlanAdminService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/** Admin only (also enforced for /api/admin/** in SecurityConfig). The boost price list. */
@RestController
@RequestMapping("/api/admin/boosts/plans")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
public class AdminBoostController {

    private final BoostPlanAdminService plans;

    /** Every plan, including switched-off ones: [{id, days, price, active}]. */
    @GetMapping
    public List<Map<String, Object>> list() {
        return plans.all();
    }

    /** Body: {id, days, price, active?}. */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Map<String, Object> create(@AuthenticationPrincipal CustomUserDetails admin, @RequestBody Map<String, Object> body) {
        return plans.create(admin.getUser().getId(), body);
    }

    /** Body: any of {days, price, active}. Applies to future purchases only. */
    @PutMapping("/{id}")
    public Map<String, Object> update(@AuthenticationPrincipal CustomUserDetails admin, @PathVariable String id,
                                      @RequestBody Map<String, Object> body) {
        return plans.update(admin.getUser().getId(), id, body);
    }
}
