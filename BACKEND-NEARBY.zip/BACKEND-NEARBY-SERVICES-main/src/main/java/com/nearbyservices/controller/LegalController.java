package com.nearbyservices.controller;

import com.nearbyservices.service.SupportContactService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.CacheControl;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.HtmlUtils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Public Privacy Policy, Terms of Use and "Delete your account" pages (GET /legal/privacy, /legal/terms,
 * /legal/delete-account). Google Play and the App Store need these as hosted https links; GET /api/app/policy
 * hands the first two to the app, and the third is the "account deletion URL" for the Play Console.
 * The wording lives in src/main/resources/legal/*.html; the support contacts are filled in from the admin settings.
 */
@RestController
@RequiredArgsConstructor
public class LegalController {

    private static final List<String> PAGES = List.of("privacy", "terms", "delete-account");

    private final SupportContactService supportContacts;
    private final Map<String, String> templates = new ConcurrentHashMap<>();

    @Value("${app.legal.app-name:Ungana}")
    private String appName;
    /** Who runs the app, shown in the pages. Set APP_OPERATOR_NAME to the registered company name. */
    @Value("${app.legal.operator-name:the Ungana team}")
    private String operatorName;
    /** Date shown at the top of the pages. Change it (APP_LEGAL_UPDATED) whenever the wording changes. */
    @Value("${app.legal.updated:25 October 2026}")
    private String updated;

    @GetMapping(value = "/legal/privacy", produces = MediaType.TEXT_HTML_VALUE + ";charset=UTF-8")
    public ResponseEntity<String> privacy() throws IOException { return page("privacy"); }

    @GetMapping(value = "/legal/terms", produces = MediaType.TEXT_HTML_VALUE + ";charset=UTF-8")
    public ResponseEntity<String> terms() throws IOException { return page("terms"); }

    @GetMapping(value = "/legal/delete-account", produces = MediaType.TEXT_HTML_VALUE + ";charset=UTF-8")
    public ResponseEntity<String> deleteAccount() throws IOException { return page("delete-account"); }

    private ResponseEntity<String> page(String name) throws IOException {
        if (!PAGES.contains(name)) return ResponseEntity.notFound().build();
        String raw = templates.get(name);
        if (raw == null) {
            raw = new String(new ClassPathResource("legal/" + name + ".html").getInputStream().readAllBytes(), StandardCharsets.UTF_8);
            templates.put(name, raw);
        }
        Map<String, Object> c = supportContacts.effective();
        String html = raw
                .replace("{{APP_NAME}}", HtmlUtils.htmlEscape(appName))
                .replace("{{OPERATOR}}", HtmlUtils.htmlEscape(operatorName))
                .replace("{{UPDATED}}", HtmlUtils.htmlEscape(updated))
                .replace("{{CONTACT}}", contactHtml(c, false))
                .replace("{{CONTACT_DELETE}}", contactHtml(c, true));
        return ResponseEntity.ok().cacheControl(CacheControl.maxAge(Duration.ofMinutes(10)).cachePublic()).body(html);
    }

    private static String contactHtml(Map<String, Object> c, boolean forDeletion) {
        StringBuilder b = new StringBuilder();
        Object email = c.get("email"), phone = c.get("phone"), wa = c.get("whatsapp");
        if (email == null && phone == null && wa == null) {
            return "<p>Use <strong>Help &amp; Support</strong> inside the app to reach us.</p>";
        }
        b.append(forDeletion
                ? "<p>Contact support from the phone number or email registered on the account and ask for the account to be deleted:</p>"
                : "<p>Questions about this page or your data? Reach us:</p>");
        b.append("<ul>");
        if (email != null) {
            String e = HtmlUtils.htmlEscape(email.toString());
            b.append("<li>Email: <a href=\"mailto:").append(e).append("\">").append(e).append("</a></li>");
        }
        if (phone != null) b.append("<li>Phone: ").append(HtmlUtils.htmlEscape(phone.toString())).append("</li>");
        if (wa != null) b.append("<li>WhatsApp: ").append(HtmlUtils.htmlEscape(wa.toString())).append("</li>");
        return b.append("</ul>").toString();
    }
}
