package com.nearbyservices.controller;

import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.ServiceCategoryAdminService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/** Admin only (also enforced for /api/admin/** in SecurityConfig). Manage the service categories. */
@RestController
@RequestMapping("/api/admin/categories")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
public class AdminCategoryController {

    private final ServiceCategoryAdminService categories;

    /** Every category, including switched-off ones: [{id, nameEn, nameSw, sortOrder, active, services}]. */
    @GetMapping
    public List<Map<String, Object>> list() {
        return categories.all();
    }

    /** Body: {id, nameEn?, nameSw?, sortOrder?, active?}. */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Map<String, Object> create(@AuthenticationPrincipal CustomUserDetails admin, @RequestBody Map<String, Object> body) {
        return categories.create(admin.getUser().getId(), body);
    }

    /** Body: any of {nameEn, nameSw, sortOrder, active}. The id never changes. */
    @PutMapping("/{id}")
    public Map<String, Object> update(@AuthenticationPrincipal CustomUserDetails admin, @PathVariable String id,
                                      @RequestBody Map<String, Object> body) {
        return categories.update(admin.getUser().getId(), id, body);
    }

    /** Only when no service uses it (409 CATEGORY_IN_USE otherwise: switch it off instead). */
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@AuthenticationPrincipal CustomUserDetails admin, @PathVariable String id) {
        categories.delete(admin.getUser().getId(), id);
    }
}
