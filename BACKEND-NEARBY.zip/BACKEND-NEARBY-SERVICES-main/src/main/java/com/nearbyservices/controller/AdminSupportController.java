package com.nearbyservices.controller;

import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.AdminSettingsService;
import com.nearbyservices.service.SupportContactService;
import com.nearbyservices.verification.AuditLog;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/** Admin only (also enforced for /api/admin/** in SecurityConfig). The support contacts on the app's Help screen. */
@RestController
@RequestMapping("/api/admin/support")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
public class AdminSupportController {

    private final SupportContactService support;
    private final AdminSettingsService settings;
    private final AuditLog auditLog;

    /** {phone, whatsapp, email, source:{phone, whatsapp, email}}; source is "admin", "env" (SUPPORT_* default) or "none". */
    @GetMapping
    public Map<String, Object> get() {
        return support.forAdmin();
    }

    /**
     * Body: any of {phone, whatsapp, email}. Not sent = unchanged; empty text = cleared (falls back to the env default).
     * Errors: 400 INVALID_SUPPORT_PHONE / INVALID_SUPPORT_WHATSAPP / INVALID_SUPPORT_EMAIL.
     */
    @PutMapping
    public Map<String, Object> update(@AuthenticationPrincipal CustomUserDetails admin, @RequestBody Map<String, Object> body) {
        settings.updateSupport(str(body.get("phone")), str(body.get("whatsapp")), str(body.get("email")));
        auditLog.record(admin.getUser().getId(), "SUPPORT_CONTACTS_CHANGED", "fields: " + body.keySet());
        return support.forAdmin();
    }

    private static String str(Object o) {
        return o == null ? null : o.toString();
    }
}
