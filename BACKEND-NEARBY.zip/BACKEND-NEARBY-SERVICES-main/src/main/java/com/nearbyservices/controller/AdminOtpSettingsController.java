package com.nearbyservices.controller;

import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.OtpSettingsService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/** Admin only (also enforced for /api/admin/** in SecurityConfig). */
@RestController
@RequestMapping("/api/admin/otp-settings")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
public class AdminOtpSettingsController {

    private final OtpSettingsService settings;

    /** {"pendingMinutes": 4, "min": 1, "max": 10}. */
    @GetMapping
    public Map<String, Object> get() {
        return view(settings.pendingMinutes());
    }

    /** Body: {"pendingMinutes": 6}. 400 INVALID_OTP_PENDING_MINUTES outside 1-10. */
    @PutMapping
    public Map<String, Object> set(@AuthenticationPrincipal CustomUserDetails admin,
                                   @RequestBody Map<String, Object> body) {
        Integer minutes = body.get("pendingMinutes") instanceof Number n && n.doubleValue() == n.intValue()
                ? n.intValue() : null;
        return view(settings.setPendingMinutes(admin.getUser().getId(), minutes));
    }

    private static Map<String, Object> view(int minutes) {
        return Map.of("pendingMinutes", minutes,
                "min", OtpSettingsService.MIN_PENDING_MINUTES,
                "max", OtpSettingsService.MAX_PENDING_MINUTES);
    }
}
