package com.nearbyservices.controller;

import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.ReportService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
public class ReportController {

    private final ReportService reportService;

    /** Body: {type: SERVICE|USER|GENERAL, reason, details?, serviceId?, reportedUserId?} */
    @PostMapping("/api/reports")
    public ResponseEntity<Map<String, Object>> submit(@AuthenticationPrincipal CustomUserDetails u,
                                                      @RequestBody Map<String, Object> body) {
        return ResponseEntity.ok(reportService.submit(u.getUser(),
                text(body.get("type")), text(body.get("reason")), text(body.get("details")),
                number(body.get("serviceId")), number(body.get("reportedUserId"))));
    }

    /** Admin only. ?status=OPEN|REVIEWING|RESOLVED|DISMISSED (optional), ?limit= (default 50) */
    @GetMapping("/api/admin/reports")
    @PreAuthorize("hasRole('ADMIN')")
    public List<Map<String, Object>> list(@RequestParam(required = false) String status,
                                          @RequestParam(defaultValue = "50") int limit) {
        return reportService.list(status, limit);
    }

    /** Admin only. Body: {status, note?} */
    @PostMapping("/api/admin/reports/{id}/status")
    @PreAuthorize("hasRole('ADMIN')")
    public Map<String, Object> setStatus(@PathVariable Long id, @RequestBody Map<String, String> body) {
        return reportService.setStatus(id, body.get("status"), body.get("note"));
    }

    private static String text(Object o) {
        return o == null ? null : o.toString();
    }

    private static Long number(Object o) {
        if (o == null) return null;
        try {
            return o instanceof Number n ? n.longValue() : Long.parseLong(o.toString().trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
