package com.nearbyservices.controller;

import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.PromoPushSettingsService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.Map;

/** Admin only (also enforced for /api/admin/** in SecurityConfig). */
@RestController
@RequestMapping("/api/admin/promo-push")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
public class AdminPromoPushController {

    private final PromoPushSettingsService settings;

    /** {"enabled": true, "intervalHours": 6, "min": 1, "max": 72}. */
    @GetMapping
    public Map<String, Object> get() {
        return view();
    }

    /** Body: any of {"enabled": bool, "intervalHours": 1-72}. 400 INVALID_PROMO_PUSH_INTERVAL outside 1-72. */
    @PutMapping
    public Map<String, Object> set(@AuthenticationPrincipal CustomUserDetails admin,
                                   @RequestBody Map<String, Object> body) {
        Boolean enabled = body.get("enabled") instanceof Boolean b ? b : null;
        Object raw = body.get("intervalHours");
        Integer hours = null;
        if (raw != null) {
            if (!(raw instanceof Number n) || n.doubleValue() != n.intValue()) {
                throw com.nearbyservices.exception.ApiException.badRequest("INVALID_PROMO_PUSH_INTERVAL");
            }
            hours = n.intValue();
        }
        settings.update(admin.getUser().getId(), enabled, hours);
        return view();
    }

    private Map<String, Object> view() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("enabled", settings.enabled());
        m.put("intervalHours", settings.intervalHours());
        m.put("min", PromoPushSettingsService.MIN_INTERVAL_HOURS);
        m.put("max", PromoPushSettingsService.MAX_INTERVAL_HOURS);
        return m;
    }
}
