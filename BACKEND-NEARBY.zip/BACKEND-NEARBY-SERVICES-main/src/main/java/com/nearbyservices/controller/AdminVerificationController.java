package com.nearbyservices.controller;

import com.nearbyservices.service.IdentityVerificationService;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.CacheControl;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Admin review queue for identity papers, verified photos and Verified Business (ROLE_ADMIN, see SecurityConfig).
 * docs/ADMIN_VERIFICATION_REVIEW.md has the calls and the order to use them.
 */
@RestController
@RequestMapping("/api/admin/verification")
@PreAuthorize("hasRole('ADMIN')")
public class AdminVerificationController {

    private final IdentityVerificationService service;

    public AdminVerificationController(IdentityVerificationService service) {
        this.service = service;
    }

    @GetMapping("/documents")
    public List<Map<String, Object>> documents(@RequestParam(defaultValue = "PENDING") String status) {
        return service.adminDocuments(status);
    }

    /** The picture itself (private storage; only an admin can open it). */
    @GetMapping("/documents/{id}/file")
    public ResponseEntity<Resource> file(@PathVariable long id) {
        Path p = service.adminDocumentFile(id);
        String name = p.getFileName().toString().toLowerCase(Locale.ROOT);
        MediaType type = name.endsWith(".png") ? MediaType.IMAGE_PNG
                : name.endsWith(".webp") ? MediaType.parseMediaType("image/webp")
                : (name.endsWith(".heic") || name.endsWith(".heif")) ? MediaType.parseMediaType("image/heic")
                : MediaType.IMAGE_JPEG;
        return ResponseEntity.ok().contentType(type).cacheControl(CacheControl.noStore()).body(new FileSystemResource(p));
    }

    /** Body (optional): {"legalName": "name as read from the ID"} on id_front / id_back. */
    @PostMapping("/documents/{id}/approve")
    public Map<String, Object> approveDocument(@PathVariable long id, @RequestBody(required = false) Map<String, Object> body) {
        return service.reviewDocument(id, true, null, IdentityVerificationController.str(body, "legalName"));
    }

    @PostMapping("/documents/{id}/reject")
    public Map<String, Object> rejectDocument(@PathVariable long id, @RequestBody(required = false) Map<String, Object> body) {
        return service.reviewDocument(id, false, IdentityVerificationController.str(body, "reason"), null);
    }

    @GetMapping("/photos")
    public List<Map<String, Object>> photos(@RequestParam(defaultValue = "PENDING") String status) {
        return service.adminPhotos(status);
    }

    @PostMapping("/photos/{userId}/approve")
    public Map<String, Object> approvePhoto(@PathVariable long userId) {
        return service.reviewPhoto(userId, true, null);
    }

    @PostMapping("/photos/{userId}/reject")
    public Map<String, Object> rejectPhoto(@PathVariable long userId, @RequestBody(required = false) Map<String, Object> body) {
        return service.reviewPhoto(userId, false, IdentityVerificationController.str(body, "reason"));
    }

    @GetMapping("/business")
    public List<Map<String, Object>> businesses(@RequestParam(defaultValue = "PENDING") String status) {
        return service.adminBusinesses(status);
    }

    /** Body: {"expiresAt": "2027-01-31"} (the date the business licence runs out). */
    @PostMapping("/business/{userId}/approve")
    public Map<String, Object> approveBusiness(@PathVariable long userId, @RequestBody Map<String, Object> body) {
        return service.reviewBusiness(userId, true, null, IdentityVerificationController.str(body, "expiresAt"));
    }

    @PostMapping("/business/{userId}/reject")
    public Map<String, Object> rejectBusiness(@PathVariable long userId, @RequestBody(required = false) Map<String, Object> body) {
        return service.reviewBusiness(userId, false, IdentityVerificationController.str(body, "reason"), null);
    }
}
