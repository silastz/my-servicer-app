package com.nearbyservices.controller;

import com.nearbyservices.dto.DepositWalletRequest;
import com.nearbyservices.dto.WalletResponse;
import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.PaymentPurpose;
import com.nearbyservices.service.PaymentService;
import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.WalletService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/wallet")
@RequiredArgsConstructor
public class WalletController {

    private final WalletService walletService;
    private final PaymentService paymentService;

    @GetMapping
    public ResponseEntity<WalletResponse> getWallet(@AuthenticationPrincipal CustomUserDetails userDetails) {
        return ResponseEntity.ok(walletService.getWalletResponse(userDetails.getUser()));
    }

    /**
     * Confirms a top-up. This call NEVER adds money itself: the wallet is credited once, by the payment
     * system, when the WALLET_TOPUP payment turns PAID. Here we only check that the caller's own payment
     * with this reference is PAID and return the wallet (the amount in the body is ignored).
     * Before, anyone could POST any amount and get it for free.
     */
    @PostMapping("/deposit")
    public ResponseEntity<WalletResponse> deposit(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @Valid @RequestBody DepositWalletRequest request) {
        String reference = request.getReference() == null ? "" : request.getReference().trim();
        if (reference.isEmpty() || !paymentService.isPaid(userDetails.getUser().getId(), PaymentPurpose.WALLET_TOPUP, reference)) {
            throw ApiException.conflict("PAYMENT_NOT_CONFIRMED");
        }
        return ResponseEntity.ok(walletService.getWalletResponse(userDetails.getUser()));
    }

    /** The caller's own wallet history, newest first: top ups, withdrawals, bookings, refunds, boosts. */
    @GetMapping("/transactions")
    public ResponseEntity<java.util.List<com.nearbyservices.dto.WalletTransactionResponse>> transactions(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @RequestParam(defaultValue = "100") int limit) {
        return ResponseEntity.ok(walletService.history(userDetails.getUser(), limit));
    }

    @PostMapping("/withdraw")
    public ResponseEntity<WalletResponse> withdraw(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @Valid @RequestBody com.nearbyservices.dto.WithdrawWalletRequest request) {
        return ResponseEntity.ok(walletService.withdraw(userDetails.getUser(), request));
    }
}
