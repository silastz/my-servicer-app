package com.nearbyservices.controller;

import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.ChatService;
import com.nearbyservices.service.FileStorageService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/chats")
@RequiredArgsConstructor
public class ChatController {

    private final ChatService chatService;
    private final FileStorageService fileStorageService;

    @GetMapping("/conversations")
    public ResponseEntity<List<Map<String, Object>>> getConversations(
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        return ResponseEntity.ok(chatService.getUserConversations(userDetails.getUser()));
    }

    @GetMapping("/{otherUserId}/messages")
    public ResponseEntity<List<Map<String, Object>>> getMessages(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @PathVariable Long otherUserId) {
        return ResponseEntity.ok(chatService.getConversationMessages(userDetails.getUser(), otherUserId));
    }

    @PostMapping("/send")
    public ResponseEntity<Map<String, Object>> sendMessage(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @RequestBody Map<String, Object> body) {
        Object rawRecipient = body.get("recipientId");
        Long recipientId;
        if (rawRecipient instanceof Number) {
            recipientId = ((Number) rawRecipient).longValue();
        } else {
            recipientId = Long.parseLong(rawRecipient.toString());
        }
        String message = (String) body.get("message");
        Long replyToId = null;
        Object rawReply = body.get("replyToId");
        if (rawReply instanceof Number n) {
            replyToId = n.longValue();
        } else if (rawReply != null && !rawReply.toString().isBlank() && !"null".equals(rawReply.toString())) {
            replyToId = Long.parseLong(rawReply.toString());
        }
        Object rawClientId = body.get("clientId");
        String clientId = rawClientId == null ? null : rawClientId.toString();
        return ResponseEntity.ok(chatService.sendMessage(userDetails.getUser(), recipientId, message, replyToId, clientId));
    }

    /** Edit the text of one of your own messages. Body: {"message": "new text"}. */
    @PutMapping("/messages/{messageId}")
    public ResponseEntity<Map<String, Object>> editMessage(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @PathVariable Long messageId,
            @RequestBody Map<String, Object> body) {
        Object text = body.get("message");
        return ResponseEntity.ok(chatService.editMessage(userDetails.getUser(), messageId, text == null ? null : text.toString()));
    }

    /** Delete a message for me. When both people have deleted it, it is removed permanently. */
    @DeleteMapping("/messages/{messageId}")
    public ResponseEntity<Map<String, Object>> deleteMessage(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @PathVariable Long messageId) {
        boolean permanent = chatService.deleteMessage(userDetails.getUser(), messageId);
        return ResponseEntity.ok(Map.of("deleted", true, "permanent", permanent));
    }

    /** Chat picture upload. The app sends one multipart field "file" and reads {"url": "..."}. */
    @PostMapping(value = "/images", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Map<String, String>> uploadImage(@RequestParam("file") MultipartFile file) {
        return ResponseEntity.ok(Map.of("url", fileStorageService.storeChatImage(file)));
    }

    /** Chat voice note or document upload (pdf, docx, xlsx, m4a, ...). Same shape as the picture upload. */
    @PostMapping(value = "/files", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Map<String, String>> uploadFile(@RequestParam("file") MultipartFile file) {
        return ResponseEntity.ok(Map.of("url", fileStorageService.storeChatFile(file)));
    }

    /** Stop push notifications from this person (messages still arrive). */
    @PostMapping("/{userId}/mute")
    public ResponseEntity<Map<String, Object>> mute(
            @AuthenticationPrincipal CustomUserDetails userDetails, @PathVariable Long userId) {
        chatService.setMuted(userDetails.getUser(), userId, true);
        return ResponseEntity.ok(Map.of("muted", true));
    }

    /** Turn push notifications from this person back on. */
    @DeleteMapping("/{userId}/mute")
    public ResponseEntity<Map<String, Object>> unmute(
            @AuthenticationPrincipal CustomUserDetails userDetails, @PathVariable Long userId) {
        chatService.setMuted(userDetails.getUser(), userId, false);
        return ResponseEntity.ok(Map.of("muted", false));
    }
}
