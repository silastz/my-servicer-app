package com.nearbyservices.controller;

import com.nearbyservices.dto.PaymentRequest;
import com.nearbyservices.model.Payment;
import com.nearbyservices.model.PaymentStatus;
import com.nearbyservices.payment.SnippeGateway;
import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.PaymentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;
    private final SnippeGateway snippe;

    /** The admin's saved gateway choice (database), falling back to payments.gateway from the config. */
    private final com.nearbyservices.service.PaymentSettingsService paymentSettings;

    @Value("${payments.webhook-secret:}")
    private String webhookSecret;

    /** {paid, amount} for the signed-in provider. */
    @GetMapping("/registration-fee")
    public Map<String, Object> registrationFee(@AuthenticationPrincipal CustomUserDetails u) {
        return paymentService.registrationFee(u.getUser());
    }

    /** Sends the mobile-money prompt. Answer: {reference, status}. */
    @PostMapping("/mobile/request")
    public Map<String, Object> mobileRequest(@AuthenticationPrincipal CustomUserDetails u,
                                             @Valid @RequestBody PaymentRequest r) {
        Payment p = paymentService.startMobile(u.getUser(), r);
        return Map.of("reference", p.getReference(), "status", p.getStatus().name());
    }

    /** Hosted card checkout. Answer: {checkoutUrl, reference}. The app never sees card numbers. */
    @PostMapping("/card/checkout")
    public Map<String, Object> cardCheckout(@AuthenticationPrincipal CustomUserDetails u,
                                            @Valid @RequestBody PaymentRequest r) {
        Payment p = paymentService.startCard(u.getUser(), r);
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("checkoutUrl", p.getCheckoutUrl());
        out.put("reference", p.getReference());
        return out;
    }

    @GetMapping({"/status/{reference}", "/card/status/{reference}"})
    public Map<String, Object> status(@AuthenticationPrincipal CustomUserDetails u, @PathVariable String reference) {
        return Map.of("status", paymentService.statusFor(u.getUser(), reference).name());
    }

    /** The page the SANDBOX card checkout opens. No money is taken here. */
    @GetMapping(value = "/sandbox/checkout/{reference}", produces = "text/html;charset=UTF-8")
    public ResponseEntity<String> sandboxCheckout(@PathVariable String reference) {
        if (!"SANDBOX".equalsIgnoreCase(paymentSettings.activeGatewayId())) return ResponseEntity.notFound().build();
        String safe = reference.replaceAll("[^A-Za-z0-9_.:-]", "");
        return ResponseEntity.ok("<!doctype html><meta name=viewport content='width=device-width'><body style='font-family:sans-serif;padding:24px'>"
                + "<h3>Sandbox checkout</h3><p>No real payment is taken. Reference: " + safe
                + "</p><p>An admin can mark it paid with POST /api/admin/payments/" + safe + "/status.</p></body>");
    }

    /**
     * Snippe callback, no JWT. Trusted only when X-Webhook-Signature matches HMAC-SHA256(signing key,
     * "{X-Webhook-Timestamp}.{raw body}") and the timestamp is under 5 minutes old. Events that are not about
     * a payment (payouts) are acknowledged and ignored. A 2xx stops Snippe's retries; anything else makes it retry.
     */
    @PostMapping("/webhook/snippe")
    public ResponseEntity<Map<String, Object>> snippeWebhook(@RequestBody String raw,
                                                             @RequestHeader(value = "X-Webhook-Timestamp", required = false) String timestamp,
                                                             @RequestHeader(value = "X-Webhook-Signature", required = false) String signature) {
        java.util.Optional<SnippeGateway.Event> event;
        try {
            event = snippe.verifyWebhook(raw, timestamp, signature);
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(Map.of("message", "FORBIDDEN"));
        }
        event.ifPresent(e -> paymentService.applyGatewayEvent("SNIPPE", e.reference(), e.gatewayReference(), e.status(), e.amount()));
        return ResponseEntity.ok(Map.of("ok", true));
    }

    /**
     * Gateway callback, no JWT. Trusted only with the shared secret in X-Webhook-Secret; with no
     * secret configured it is switched off. Body: {reference, status, gatewayReference?}.
     */
    @PostMapping("/webhook/{gateway}")
    public ResponseEntity<Map<String, Object>> webhook(@PathVariable String gateway,
                                                       @RequestHeader(value = "X-Webhook-Secret", required = false) String secret,
                                                       @RequestBody Map<String, Object> body) {
        if (webhookSecret == null || webhookSecret.isBlank() || secret == null
                || !MessageDigest.isEqual(secret.getBytes(StandardCharsets.UTF_8), webhookSecret.getBytes(StandardCharsets.UTF_8))) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(Map.of("message", "FORBIDDEN"));
        }
        String reference = String.valueOf(body.getOrDefault("reference", ""));
        PaymentStatus status;
        try {
            status = PaymentStatus.valueOf(String.valueOf(body.getOrDefault("status", "")).trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("message", "INVALID_PAYMENT_STATUS"));
        }
        Object gref = body.get("gatewayReference");
        paymentService.applyStatus(reference, status, gref == null ? null : gref.toString());
        return ResponseEntity.ok(Map.of("ok", true));
    }
}
