package com.nearbyservices.controller;

import com.nearbyservices.dto.ServiceFeeStatusResponse;
import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.ServiceFeeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
public class ServiceFeeController {

    private final ServiceFeeService serviceFeeService;

    /** {freeLimit, used, credits, amount, needsPayment} for the signed-in provider. */
    @GetMapping("/service-fee")
    public ResponseEntity<ServiceFeeStatusResponse> serviceFee(@AuthenticationPrincipal CustomUserDetails userDetails) {
        return ResponseEntity.ok(serviceFeeService.status(userDetails.getUser()));
    }
}
