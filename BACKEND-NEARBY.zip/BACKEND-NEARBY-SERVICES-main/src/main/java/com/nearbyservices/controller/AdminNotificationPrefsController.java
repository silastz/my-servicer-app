package com.nearbyservices.controller;

import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.AdminNotificationPrefsService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/** Admin only (also enforced for /api/admin/** in SecurityConfig). The signed-in admin's own alert switches. */
@RestController
@RequestMapping("/api/admin/notification-prefs")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
public class AdminNotificationPrefsController {

    private final AdminNotificationPrefsService prefs;

    /** {reports, disputes, withdrawals, payments}: true = alerts of that kind are sent to this admin (all true by default). */
    @GetMapping
    public Map<String, Object> get(@AuthenticationPrincipal CustomUserDetails admin) {
        return prefs.get(admin.getUser().getId());
    }

    /** Body: any of {reports, disputes, withdrawals, payments} as true/false. Answers the full set. 400 INVALID_PREFERENCE. */
    @PutMapping
    public Map<String, Object> update(@AuthenticationPrincipal CustomUserDetails admin, @RequestBody Map<String, Object> body) {
        return prefs.update(admin.getUser().getId(), body);
    }
}
