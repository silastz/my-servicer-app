package com.nearbyservices.controller;

import com.nearbyservices.model.User;
import com.nearbyservices.repository.UserRepository;
import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.ContactChangeService;
import com.nearbyservices.service.ProfileService;
import com.nearbyservices.service.UserBlockService;
import com.nearbyservices.service.UserSettingsService;
import org.springframework.http.MediaType;
import org.springframework.web.multipart.MultipartFile;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserRepository userRepository;
    private final ProfileService profileService;
    private final ContactChangeService contactChangeService;
    private final UserBlockService userBlockService;
    private final UserSettingsService userSettingsService;
    private final com.nearbyservices.service.AccountDeletionService accountDeletionService;

    @GetMapping("/me")
    public ResponseEntity<Map<String, Object>> getProfile(@AuthenticationPrincipal CustomUserDetails userDetails) {
        User user = userDetails.getUser();
        Map<String, Object> me = new java.util.LinkedHashMap<>();
        me.put("id", user.getId());
        me.put("username", user.getUsername());
        me.put("phone", user.getPhone() != null ? user.getPhone() : "");
        me.put("email", user.getEmail() != null ? user.getEmail() : "");
        me.put("stageName", user.getStageName() != null ? user.getStageName() : "");
        me.put("role", user.getRole() != null ? user.getRole().name() : "ROLE_BUYER");
        me.put("phoneVerified", user.isPhoneVerified());
        me.put("emailVerified", user.isEmailVerified());
        me.put("verificationBadge", user.getVerificationBadge() != null ? user.getVerificationBadge().name() : "NONE");
        me.put("bio", user.getBio() != null ? user.getBio() : "");
        me.put("avatarUrl", user.getAvatarUrl() != null ? user.getAvatarUrl() : "");
        me.put("coverUrl", user.getCoverUrl() != null ? user.getCoverUrl() : "");
        me.put("hideMyId", user.isHideMyId());
        me.put("profileLocked", user.isProfileLocked());
        me.put("socials", UserSettingsService.socialsOf(user));
        me.put("notifBookings", user.isNotifBookings());
        me.put("notifMessages", user.isNotifMessages());
        me.put("notifPromos", user.isNotifPromos());
        me.put("country", UserSettingsService.countryOf(user));
        me.put("currency", UserSettingsService.currencyOf(user));
        return ResponseEntity.ok(me);
    }

    /**
     * @deprecated Older app builds only. The app now calls PUT /users/me/profile (same rules). Remove once no installed build uses it.
     */
    @Deprecated
    @PutMapping("/profile")
    public ResponseEntity<Map<String, Object>> updateProfile(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @RequestBody Map<String, String> body) {
        User user = userDetails.getUser();
        // Same rules as PUT /users/me/profile (2-40 characters), so this older call cannot save a name the newer one refuses.
        // A missing or blank name changes nothing.
        String newName = body.get("stageName");
        if (newName != null && !newName.isBlank()) {
            user = userRepository.findById(user.getId()).orElse(user);
            profileService.update(user, newName, null);
            user = userRepository.findById(user.getId()).orElse(user);
        }
        // Phone and email are NOT changed here any more: they are the account's identity and now need a code
        // sent to the new value (POST /users/me/phone|email/request-change, then confirm-change).

        return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Profile updated successfully",
                "stageName", user.getStageName() != null ? user.getStageName() : "",
                "email", user.getEmail() != null ? user.getEmail() : "",
                "phone", user.getPhone() != null ? user.getPhone() : ""
        ));
    }

    // ---- Public profile (what the service page shows about the seller) -------------------------

    /** Body: {stageName?, bio?}. Only what is sent changes; phone and email are NOT changed here (they need a code). */
    @PutMapping("/me/profile")
    public ResponseEntity<Map<String, Object>> updateMyProfile(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @RequestBody Map<String, String> body) {
        return ResponseEntity.ok(profileService.update(userDetails.getUser(), body.get("stageName"), body.get("bio")));
    }

    /** Multipart field "file". Answer: {"url": "...", "avatarUrl": "..."} */
    @PostMapping(value = "/me/avatar", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Map<String, String>> uploadAvatar(
            @AuthenticationPrincipal CustomUserDetails userDetails, @RequestParam("file") MultipartFile file) {
        String url = profileService.setAvatar(userDetails.getUser(), file);
        return ResponseEntity.ok(Map.of("url", url, "avatarUrl", url));
    }

    // ---- Delete my account (Google Play / App Store requirement) ---------------------------------

    /** Can the account be deleted now? Answer: {"canDelete": true} or {"canDelete": false, "reason": "WALLET_NOT_EMPTY|OPEN_BOOKINGS|PAYMENT_PENDING|ADMIN_ACCOUNT"}. */
    @GetMapping("/me/delete-check")
    public ResponseEntity<Map<String, Object>> deleteCheck(@AuthenticationPrincipal CustomUserDetails u) {
        String reason = accountDeletionService.blocker(u.getUser());
        Map<String, Object> m = new java.util.LinkedHashMap<>();
        m.put("canDelete", reason == null);
        if (reason != null) m.put("reason", reason);
        return ResponseEntity.ok(m);
    }

    /**
     * Body: {"password": "..."}. Deletes (anonymises) the signed-in account for good. 403 WRONG_PASSWORD,
     * 409 with a reason code (WALLET_NOT_EMPTY, OPEN_BOOKINGS, PAYMENT_PENDING, ADMIN_ACCOUNT) while something is still open.
     */
    @DeleteMapping("/me")
    public ResponseEntity<Map<String, Object>> deleteMyAccount(
            @AuthenticationPrincipal CustomUserDetails u, @RequestBody(required = false) Map<String, String> body) {
        accountDeletionService.delete(u.getUser(), body == null ? null : body.get("password"));
        return ResponseEntity.ok(Map.of("success", true));
    }

    @DeleteMapping("/me/avatar")
    public ResponseEntity<Void> deleteAvatar(@AuthenticationPrincipal CustomUserDetails userDetails) {
        profileService.removeAvatar(userDetails.getUser());
        return ResponseEntity.noContent().build();
    }

    /** Multipart field "file". Answer: {"url": "...", "coverUrl": "..."} */
    @PostMapping(value = "/me/cover", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Map<String, String>> uploadCover(
            @AuthenticationPrincipal CustomUserDetails userDetails, @RequestParam("file") MultipartFile file) {
        String url = profileService.setCover(userDetails.getUser(), file);
        return ResponseEntity.ok(Map.of("url", url, "coverUrl", url));
    }

    @DeleteMapping("/me/cover")
    public ResponseEntity<Void> deleteCover(@AuthenticationPrincipal CustomUserDetails userDetails) {
        profileService.removeCover(userDetails.getUser());
        return ResponseEntity.noContent().build();
    }

    // ---- Change the registered phone / email (code sent to the NEW value) ------------------------

    /** Body: {"phone": "+2557..."}. Sends a 6-digit code to that number. */
    @PostMapping("/me/phone/request-change")
    public ResponseEntity<Map<String, Object>> requestPhoneChange(
            @AuthenticationPrincipal CustomUserDetails u, @RequestBody Map<String, String> body) {
        contactChangeService.request(u.getUser(), ContactChangeService.Kind.PHONE, body.get("phone"));
        return ResponseEntity.ok(Map.of("success", true));
    }

    /** Body: {"phone": "+2557...", "otp": "123456"}. Switches the phone only if the code is right. */
    @PostMapping("/me/phone/confirm-change")
    public ResponseEntity<Map<String, Object>> confirmPhoneChange(
            @AuthenticationPrincipal CustomUserDetails u, @RequestBody Map<String, String> body) {
        String value = contactChangeService.confirm(u.getUser(), ContactChangeService.Kind.PHONE, body.get("phone"), body.get("otp"));
        return ResponseEntity.ok(Map.of("success", true, "phone", value));
    }

    @PostMapping("/me/email/request-change")
    public ResponseEntity<Map<String, Object>> requestEmailChange(
            @AuthenticationPrincipal CustomUserDetails u, @RequestBody Map<String, String> body) {
        contactChangeService.request(u.getUser(), ContactChangeService.Kind.EMAIL, body.get("email"));
        return ResponseEntity.ok(Map.of("success", true));
    }

    @PostMapping("/me/email/confirm-change")
    public ResponseEntity<Map<String, Object>> confirmEmailChange(
            @AuthenticationPrincipal CustomUserDetails u, @RequestBody Map<String, String> body) {
        String value = contactChangeService.confirm(u.getUser(), ContactChangeService.Kind.EMAIL, body.get("email"), body.get("otp"));
        return ResponseEntity.ok(Map.of("success", true, "email", value));
    }

    // ---- Account settings: Hide My ID, country / currency, last position -------------------------

    /** Body: {"hideMyId": true|false}. */
    @PutMapping("/me/privacy")
    public ResponseEntity<Map<String, Object>> updatePrivacy(
            @AuthenticationPrincipal CustomUserDetails u, @RequestBody Map<String, Object> body) {
        Boolean hide = asBool(body.get("hideMyId"));
        Boolean locked = asBool(body.get("profileLocked"));
        if (hide == null && locked == null) throw com.nearbyservices.exception.ApiException.badRequest("INVALID_REQUEST");
        if (hide != null) userSettingsService.setHideMyId(u.getUser(), hide);
        if (locked != null) userSettingsService.setProfileLocked(u.getUser(), locked);
        Map<String, Object> out = new java.util.LinkedHashMap<>();
        out.put("success", true);
        if (hide != null) out.put("hideMyId", hide);
        if (locked != null) out.put("profileLocked", locked);
        return ResponseEntity.ok(out);
    }

    /**
     * Body: any of {"whatsapp","instagram","facebook","x","tiktok","youtube"}: the profile social links.
     * Not sent = unchanged, empty text = cleared. Answer: {success, socials:{...}}. The public sees them (as the fallback for a
     * service with no contacts of its own) only while the profile is unlocked.
     */
    @PutMapping("/me/socials")
    public ResponseEntity<Map<String, Object>> updateSocials(
            @AuthenticationPrincipal CustomUserDetails u, @RequestBody Map<String, Object> body) {
        Map<String, String> saved = userSettingsService.setSocials(u.getUser(), body);
        return ResponseEntity.ok(Map.of("success", true, "socials", saved));
    }

    /** Body: any of {"bookings": bool, "messages": bool, "promos": bool}. Missing switches stay as they are. */
    @PutMapping("/me/notifications")
    public ResponseEntity<Map<String, Object>> updateNotifications(
            @AuthenticationPrincipal CustomUserDetails u, @RequestBody Map<String, Object> body) {
        Boolean b = asBool(body.get("bookings"));
        Boolean m = asBool(body.get("messages"));
        Boolean p = asBool(body.get("promos"));
        if (b == null && m == null && p == null) throw com.nearbyservices.exception.ApiException.badRequest("INVALID_REQUEST");
        User saved = userSettingsService.setNotificationPrefs(u.getUser(), b, m, p);
        return ResponseEntity.ok(Map.of("success", true,
                "bookings", saved.isNotifBookings(), "messages", saved.isNotifMessages(), "promos", saved.isNotifPromos()));
    }

    private static Boolean asBool(Object v) {
        if (v instanceof Boolean b) return b;
        if (v == null) return null;
        String s = v.toString();
        return "true".equalsIgnoreCase(s) ? Boolean.TRUE : "false".equalsIgnoreCase(s) ? Boolean.FALSE : null;
    }

    /** Body: {"country": "KE", "currency": "KES"}. Refused with a readable message while money is held. */
    @PutMapping("/me/currency")
    public ResponseEntity<Map<String, Object>> updateCurrency(
            @AuthenticationPrincipal CustomUserDetails u, @RequestBody Map<String, Object> body) {
        Object country = body.get("country");
        Object currency = body.get("currency");
        userSettingsService.setCurrency(u.getUser(), country == null ? null : country.toString(),
                currency == null ? null : currency.toString());
        return ResponseEntity.ok(Map.of("success", true,
                "country", country.toString().trim().toUpperCase(java.util.Locale.ROOT),
                "currency", currency.toString().trim().toUpperCase(java.util.Locale.ROOT)));
    }

    /** Body: {"latitude": -6.8, "longitude": 39.28}. Only the user's own position, never shown to anyone. */
    @PutMapping("/me/location")
    public ResponseEntity<Map<String, Object>> updateLocation(
            @AuthenticationPrincipal CustomUserDetails u, @RequestBody Map<String, Object> body) {
        userSettingsService.setLocation(u.getUser(), decimal(body.get("latitude")), decimal(body.get("longitude")));
        return ResponseEntity.ok(Map.of("success", true));
    }

    private static Double decimal(Object o) {
        if (o == null) return null;
        try {
            return o instanceof Number n ? n.doubleValue() : Double.parseDouble(o.toString().trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    // ---- Block list ---------------------------------------------------------------------------------

    /** Optional body: {reason, details}. Blocking twice is fine. */
    @PostMapping("/{id}/block")
    public ResponseEntity<Map<String, Object>> block(
            @AuthenticationPrincipal CustomUserDetails u, @PathVariable Long id,
            @RequestBody(required = false) Map<String, String> body) {
        userBlockService.block(u.getUser(), id,
                body == null ? null : body.get("reason"), body == null ? null : body.get("details"));
        return ResponseEntity.ok(Map.of("success", true));
    }

    @DeleteMapping("/{id}/block")
    public ResponseEntity<Void> unblock(@AuthenticationPrincipal CustomUserDetails u, @PathVariable Long id) {
        userBlockService.unblock(u.getUser(), id);
        return ResponseEntity.noContent().build();
    }

    /** [{id, stageName, blockedAt, reason, blockedUser:{id, stageName}}] */
    @GetMapping("/blocked")
    public ResponseEntity<java.util.List<Map<String, Object>>> blocked(@AuthenticationPrincipal CustomUserDetails u) {
        return ResponseEntity.ok(userBlockService.list(u.getUser()));
    }
}
