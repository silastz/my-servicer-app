package com.nearbyservices.controller;

import com.nearbyservices.dto.ProviderFeesDto;
import com.nearbyservices.model.PaymentStatus;
import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.PaymentSettingsService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import com.nearbyservices.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/** Admin only (also enforced for /api/admin/** in SecurityConfig). For the SANDBOX gateway and manual reconciliation. */
@RestController
@RequestMapping("/api/admin/payments")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
public class AdminPaymentController {

    private final PaymentService paymentService;
    private final PaymentSettingsService settings;

    /** {"gateway": "SANDBOX", "available": [...]}. Only gateways that have an implementation are listed. */
    @GetMapping("/gateway")
    public Map<String, Object> gateway() {
        return Map.of("gateway", settings.activeGatewayId().toUpperCase(), "available", settings.availableGateways());
    }

    /** Body: {"gateway": "SELCOM"}. 400 when that gateway has no implementation on this server. */
    @PutMapping("/gateway")
    public Map<String, Object> setGateway(@AuthenticationPrincipal CustomUserDetails admin,
                                          @RequestBody Map<String, String> body) {
        String saved = settings.setGateway(admin.getUser().getId(), body.get("gateway"));
        return Map.of("gateway", saved);
    }

    /** {"enabled": false}. Card payments are off until switched on here. */
    @GetMapping("/card")
    public Map<String, Object> card() {
        return Map.of("enabled", settings.cardEnabled());
    }

    /** Body: {"enabled": true}. */
    @PutMapping("/card")
    public Map<String, Object> setCard(@AuthenticationPrincipal CustomUserDetails admin,
                                       @RequestBody Map<String, Object> body) {
        return Map.of("enabled", settings.setCardEnabled(admin.getUser().getId(), Boolean.TRUE.equals(body.get("enabled"))));
    }

    /** {"email": "...", "source": "admin"|"env"}: the email sent to the gateway for a payer with no email on their account. */
    @GetMapping("/fallback-email")
    public Map<String, String> fallbackEmail() {
        return settings.fallbackEmail();
    }

    /** Body: {"email": "payments@yourdomain.com"}. Empty text = back to the env default. 400 INVALID_PAYMENT_EMAIL. */
    @PutMapping("/fallback-email")
    public Map<String, String> setFallbackEmail(@AuthenticationPrincipal CustomUserDetails admin,
                                                @RequestBody Map<String, String> body) {
        return settings.setFallbackEmail(admin.getUser().getId(), body.get("email"));
    }

    @GetMapping("/provider-fees")
    public ProviderFeesDto providerFees() {
        return settings.fees();
    }

    @PutMapping("/provider-fees")
    public ProviderFeesDto setProviderFees(@AuthenticationPrincipal CustomUserDetails admin,
                                           @RequestBody ProviderFeesDto body) {
        return settings.setFees(admin.getUser().getId(), body);
    }

    /** Body: {"status": "PAID" | "FAILED" | "CANCELLED"}. PAID applies the payment's effect once. */
    @PostMapping("/{reference}/status")
    public Map<String, Object> setStatus(@PathVariable String reference, @RequestBody Map<String, String> body) {
        PaymentStatus s = PaymentStatus.valueOf(String.valueOf(body.get("status")).toUpperCase());
        var p = paymentService.applyStatus(reference, s, null);
        return Map.of("reference", p.getReference(), "status", p.getStatus().name(), "settled", p.isSettled());
    }
}
