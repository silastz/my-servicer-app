package com.nearbyservices.controller;

import com.nearbyservices.dto.NidaBlueTickRequest;
import com.nearbyservices.dto.NidaGreenBadgeRequest;
import com.nearbyservices.dto.PublicUserDto;
import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.VerificationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/verification")
@RequiredArgsConstructor
public class VerificationController {

    private final VerificationService verificationService;

    /**
     * Green Badge: NIDA Number verification.
     */
    @PostMapping("/green-badge")
    public ResponseEntity<PublicUserDto> applyGreenBadge(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @Valid @RequestBody NidaGreenBadgeRequest request) {
        return ResponseEntity.ok(verificationService.applyGreenBadge(userDetails.getUser(), request));
    }

    /**
     * Blue Tick: NIDA ID + Photo holding ID OR invitation from another verified Blue Tick user.
     */
    @PostMapping("/blue-tick")
    public ResponseEntity<PublicUserDto> applyBlueTick(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @RequestBody NidaBlueTickRequest request) {
        return ResponseEntity.ok(verificationService.applyBlueTick(userDetails.getUser(), request));
    }

    /**
     * View any user's public profile (Stage name + Badge only, NEVER private NIDA data).
     */
    @GetMapping("/users/{userId}/public")
    public ResponseEntity<PublicUserDto> getPublicProfile(@PathVariable Long userId) {
        return ResponseEntity.ok(verificationService.getPublicProfile(userId));
    }
}
