package com.nearbyservices.controller;

import com.nearbyservices.model.PortfolioItem;
import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.PortfolioService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

/** A provider's own portfolio (photos and videos on their profile). See docs/PORTFOLIO.md. */
@RestController
@RequestMapping("/api/portfolio")
@RequiredArgsConstructor
public class PortfolioController {

    private final PortfolioService portfolio;

    /** Public: anyone can see a provider's portfolio. Newest first. */
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Map<String, Object>>> list(@PathVariable Long userId) {
        return ResponseEntity.ok(portfolio.list(userId));
    }

    @PostMapping(value = "/images", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Map<String, Object>> addImage(
            @AuthenticationPrincipal CustomUserDetails me,
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "caption", required = false) String caption) {
        return ResponseEntity.ok(portfolio.add(me.getUser(), file, caption, PortfolioItem.Type.IMAGE));
    }

    @PostMapping(value = "/videos", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Map<String, Object>> addVideo(
            @AuthenticationPrincipal CustomUserDetails me,
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "caption", required = false) String caption) {
        return ResponseEntity.ok(portfolio.add(me.getUser(), file, caption, PortfolioItem.Type.VIDEO));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Map<String, Object>> caption(
            @AuthenticationPrincipal CustomUserDetails me,
            @PathVariable Long id,
            @RequestBody Map<String, String> body) {
        return ResponseEntity.ok(portfolio.setCaption(me.getUser(), id, body.get("caption")));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Object>> delete(
            @AuthenticationPrincipal CustomUserDetails me,
            @PathVariable Long id) {
        portfolio.delete(me.getUser(), id);
        return ResponseEntity.ok(Map.of("deleted", true));
    }
}
