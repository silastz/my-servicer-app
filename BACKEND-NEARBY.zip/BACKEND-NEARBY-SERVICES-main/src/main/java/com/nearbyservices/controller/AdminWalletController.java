package com.nearbyservices.controller;

import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.PlatformWalletService;
import com.nearbyservices.service.WithdrawalAdminService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/** The platform's own wallet. Admin only (also enforced for /api/admin/** in SecurityConfig). */
@RestController
@RequestMapping("/api/admin/wallet")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
public class AdminWalletController {

    private final PlatformWalletService platformWallet;
    private final WithdrawalAdminService withdrawals;

    /** {balance, held, totalIn, totalOut, income: {...}} */
    @GetMapping
    public Map<String, Object> summary() {
        return platformWallet.summary();
    }

    /** Newest first: [{id, type, amount, direction, title, status, reference, createdAt}] */
    @GetMapping("/transactions")
    public List<Map<String, Object>> transactions(@RequestParam(defaultValue = "50") int limit) {
        return platformWallet.transactions(limit);
    }

    /** Body: {amount, phone, reference?}. Answer: {fee, netAmount, reference, balance}. */
    @PostMapping("/withdraw")
    public Map<String, Object> withdraw(@AuthenticationPrincipal CustomUserDetails admin, @RequestBody Map<String, Object> body) {
        BigDecimal amount = null;
        try {
            if (body.get("amount") != null) amount = new BigDecimal(body.get("amount").toString().trim());
        } catch (NumberFormatException ignored) {
            // stays null -> INVALID_AMOUNT
        }
        Object phone = body.get("phone");
        Object ref = body.get("reference");
        return platformWallet.adminWithdraw(admin.getUser().getId(), amount,
                phone == null ? null : phone.toString(), ref == null ? null : ref.toString());
    }

    /**
     * Withdrawals to pay out, newest first: users' and the admin's own. {@code status}: PENDING (default), COMPLETED,
     * FAILED or ALL. [{reference, kind: USER|PLATFORM, userId?, amount, fee, netAmount, phone, status, failReason?, createdAt}]
     */
    @GetMapping("/withdrawals")
    public List<Map<String, Object>> listWithdrawals(@RequestParam(required = false) String status,
                                                 @RequestParam(defaultValue = "50") int limit) {
        return withdrawals.list(status, limit);
    }

    /** The payout was sent: PENDING becomes COMPLETED. Anything but PENDING is 409 INVALID_STATUS:<status>. */
    @PostMapping("/withdrawals/{ref}/complete")
    public Map<String, Object> completeWithdrawal(@AuthenticationPrincipal CustomUserDetails admin, @PathVariable String ref) {
        return withdrawals.complete(admin.getUser().getId(), ref);
    }

    /**
     * The payout could not be sent. Body (optional): {reason}. A user's money goes back to their wallet and the fees booked
     * for it are reversed; the admin's own withdrawal stops counting.
     */
    @PostMapping("/withdrawals/{ref}/fail")
    public Map<String, Object> failWithdrawal(@AuthenticationPrincipal CustomUserDetails admin, @PathVariable String ref,
                                              @RequestBody(required = false) Map<String, Object> body) {
        Object reason = body == null ? null : body.get("reason");
        return withdrawals.fail(admin.getUser().getId(), ref, reason == null ? null : reason.toString());
    }
}
