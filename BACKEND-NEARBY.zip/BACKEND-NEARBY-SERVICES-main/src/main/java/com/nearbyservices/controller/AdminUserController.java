package com.nearbyservices.controller;

import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.UserAdminService;
import com.nearbyservices.verification.AuditLog;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/** Admin only (also enforced for /api/admin/** in SecurityConfig). Manage user accounts. */
@RestController
@RequestMapping("/api/admin/users")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
public class AdminUserController {

    private final UserAdminService users;
    private final AuditLog auditLog;

    /**
     * Newest first. {@code q}: name, username, phone, email or exact id. {@code status}: ACTIVE, SUSPENDED, DELETED or ALL.
     * {@code role}: BUYER, SELLER or ADMIN. Pages start at 0; {@code size} is at most 100.
     * [{id, stageName, username, phone, email, role, verificationBadge, phoneVerified, status, suspendReason, suspendedAt, createdAt}]
     */
    @GetMapping
    public List<Map<String, Object>> list(@RequestParam(required = false) String q,
                                          @RequestParam(required = false) String status,
                                          @RequestParam(required = false) String role,
                                          @RequestParam(defaultValue = "0") int page,
                                          @RequestParam(defaultValue = "30") int size) {
        return users.list(q, status, role, page, size);
    }

    /** The summary plus {emailVerified, country, currency, servicesPosted, activeServices, walletBalance, walletLocked, deletedAt}. 404 USER_NOT_FOUND. */
    @GetMapping("/{id}")
    public Map<String, Object> detail(@PathVariable long id) {
        return users.detail(id);
    }

    /**
     * Body: {reason}. The person is signed out everywhere and cannot sign in; their services leave the search.
     * Errors: 400 REASON_REQUIRED / REASON_TOO_LONG, 403 ADMIN_ACCOUNT, 404 USER_NOT_FOUND, 409 ACCOUNT_DELETED.
     */
    @PostMapping("/{id}/suspend")
    public Map<String, Object> suspend(@AuthenticationPrincipal CustomUserDetails admin, @PathVariable long id,
                                       @RequestBody(required = false) Map<String, Object> body) {
        Object reason = body == null ? null : body.get("reason");
        Map<String, Object> out = users.suspend(admin.getUser().getId(), id, reason == null ? null : reason.toString());
        auditLog.record(admin.getUser().getId(), "USER_SUSPENDED", "user " + id);
        return out;
    }

    /** The person can sign in again (with a new login). Same errors as suspend, without the reason ones. */
    @PostMapping("/{id}/reactivate")
    public Map<String, Object> reactivate(@AuthenticationPrincipal CustomUserDetails admin, @PathVariable long id) {
        Map<String, Object> out = users.reactivate(admin.getUser().getId(), id);
        auditLog.record(admin.getUser().getId(), "USER_REACTIVATED", "user " + id);
        return out;
    }

    /**
     * Deletes (anonymises) the account for good. Errors: 403 ADMIN_ACCOUNT, 404 USER_NOT_FOUND, and 409 WALLET_NOT_EMPTY /
     * OPEN_BOOKINGS / PAYMENT_PENDING while money or a booking is still open.
     */
    @PostMapping("/{id}/delete")
    public Map<String, Object> delete(@AuthenticationPrincipal CustomUserDetails admin, @PathVariable long id) {
        Map<String, Object> out = users.delete(admin.getUser().getId(), id);
        auditLog.record(admin.getUser().getId(), "USER_DELETED", "user " + id);
        return out;
    }
}
