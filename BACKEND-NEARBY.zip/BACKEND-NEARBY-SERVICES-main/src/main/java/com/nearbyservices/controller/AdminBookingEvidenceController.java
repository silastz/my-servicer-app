package com.nearbyservices.controller;

import com.nearbyservices.service.EscrowService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/** Booking record for disputes and scam reports, including where the customer was when they sent the request. Admin only. */
@RestController
@RequestMapping("/api/admin/escrow")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
public class AdminBookingEvidenceController {

    private final EscrowService escrowService;

    /** GET /api/admin/escrow/{transactionRef}/evidence */
    @GetMapping("/{transactionRef}/evidence")
    public Map<String, Object> evidence(@PathVariable String transactionRef) {
        return escrowService.evidence(transactionRef);
    }
}
