package com.nearbyservices.controller;

import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.BoostService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
public class BoostController {

    private final BoostService boostService;

    /** The server's own price list: [{id, days, price}]. */
    @GetMapping("/api/boosts/plans")
    public List<Map<String, Object>> plans() {
        return boostService.plans();
    }

    /** Body: {serviceId, planId, days?, paymentMethod: MOBILE_MONEY|CARD|POCKET_FUND, reference?} */
    @PostMapping("/api/boosts/activate")
    public ResponseEntity<Map<String, Object>> activate(@AuthenticationPrincipal CustomUserDetails u,
                                                        @RequestBody Map<String, Object> body) {
        Long days = number(body.get("days"));
        return ResponseEntity.ok(boostService.activate(u.getUser(),
                number(body.get("serviceId")), text(body.get("planId")),
                days == null ? null : Integer.valueOf(days.intValue()),
                text(body.get("paymentMethod")), text(body.get("reference"))));
    }

    private static String text(Object o) {
        return o == null ? null : o.toString();
    }

    private static Long number(Object o) {
        if (o == null) return null;
        try {
            return o instanceof Number n ? n.longValue() : Long.parseLong(o.toString().trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
