package com.nearbyservices.controller;

import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.AppConfigService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.CacheControl;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.Duration;

/**
 * What the app reads as Home opens, with no login:
 *   GET /api/app/ads?platform=      ad settings (docs/ads_config_api_contract.md)
 *   GET /api/app/version?platform=  update dialog info (docs/app_version_api_contract.md)
 * And what the admin writes (ROLE_ADMIN: /api/admin/** is closed to everyone else in SecurityConfig):
 *   GET|PUT /api/admin/ads/config
 *   GET|PUT /api/admin/app/version?platform=
 * The JSON is sent exactly as stored.
 */
@RestController
@RequiredArgsConstructor
public class AppConfigController {

    private final AppConfigService config;

    @GetMapping(value = "/api/app/ads", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> publicAds(@RequestParam(required = false) String platform) {
        return ResponseEntity.ok().cacheControl(CacheControl.maxAge(Duration.ofSeconds(60)).cachePublic())
                .contentType(MediaType.APPLICATION_JSON).body(config.adsJson());
    }

    @GetMapping(value = "/api/app/version", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> publicVersion(@RequestParam(required = false) String platform) {
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(config.versionJson(platform));
    }

    @GetMapping(value = "/api/admin/ads/config", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> adminAds() {
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(config.adsJson());
    }

    @PutMapping(value = "/api/admin/ads/config", consumes = MediaType.ALL_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> saveAds(@AuthenticationPrincipal CustomUserDetails admin, @RequestBody String body) {
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(config.saveAds(body, who(admin)));
    }

    @GetMapping(value = "/api/admin/app/version", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> adminVersion(@RequestParam(defaultValue = "android") String platform) {
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(config.versionJson(platform));
    }

    @PutMapping(value = "/api/admin/app/version", consumes = MediaType.ALL_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> saveVersion(@AuthenticationPrincipal CustomUserDetails admin,
                                              @RequestParam(defaultValue = "android") String platform,
                                              @RequestBody String body) {
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(config.saveVersion(platform, body, who(admin)));
    }

    private static long who(CustomUserDetails admin) {
        return admin == null || admin.getUser().getId() == null ? 0L : admin.getUser().getId();
    }
}
