package com.nearbyservices.controller;

import com.nearbyservices.dto.CreateEscrowRequest;
import com.nearbyservices.dto.EscrowTransactionResponse;
import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.EscrowService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/escrow")
@RequiredArgsConstructor
public class EscrowController {

    private final EscrowService escrowService;

    /**
     * Create an Escrow transaction and lock funds.
     */
    @PostMapping("/create")
    public ResponseEntity<EscrowTransactionResponse> createEscrow(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @Valid @RequestBody CreateEscrowRequest request) {
        return ResponseEntity.ok(escrowService.initiateEscrow(userDetails.getUser(), request));
    }

    /**
     * Seller accepts booking request: Contacts are unlocked for Buyer.
     */
    @PostMapping("/accept/{transactionRef}")
    public ResponseEntity<EscrowTransactionResponse> acceptRequest(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @PathVariable String transactionRef) {
        return ResponseEntity.ok(escrowService.acceptRequest(userDetails.getUser(), transactionRef));
    }

    /**
     * Seller rejects booking request: Funds automatically refunded to Buyer.
     */
    @PostMapping("/reject/{transactionRef}")
    public ResponseEntity<EscrowTransactionResponse> rejectRequest(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @PathVariable String transactionRef) {
        return ResponseEntity.ok(escrowService.rejectRequest(userDetails.getUser(), transactionRef));
    }

    /**
     * Buyer cancels booking request before acceptance: Funds instantly refunded to Buyer.
     */
    @PostMapping("/cancel/{transactionRef}")
    public ResponseEntity<EscrowTransactionResponse> cancelRequest(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @PathVariable String transactionRef) {
        return ResponseEntity.ok(escrowService.cancelRequest(userDetails.getUser(), transactionRef));
    }

    /**
     * Buyer confirms satisfaction and releases funds to Seller.
     */
    @PostMapping("/release/{transactionRef}")
    public ResponseEntity<EscrowTransactionResponse> releaseFunds(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @PathVariable String transactionRef) {
        return ResponseEntity.ok(escrowService.releaseFundsOnBuyerSatisfied(userDetails.getUser(), transactionRef));
    }

    // ---- Live location: follow each other on an active booking (memory only, expires after 90 s) ----

    /** Body: {latitude, longitude, heading?}. Only while the booking is accepted (and paid when payment is required). */
    @PostMapping("/{transactionRef}/live-location")
    public ResponseEntity<Map<String, Object>> shareLiveLocation(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @PathVariable String transactionRef,
            @RequestBody Map<String, Object> body) {
        return ResponseEntity.ok(escrowService.shareLiveLocation(userDetails.getUser(), transactionRef,
                num(body.get("latitude")), num(body.get("longitude")), num(body.get("heading"))));
    }

    /** The other person's last position: {active, latitude, longitude, heading?, ageSeconds}. */
    @GetMapping("/{transactionRef}/live-location")
    public ResponseEntity<Map<String, Object>> otherLiveLocation(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @PathVariable String transactionRef) {
        return ResponseEntity.ok(escrowService.otherLiveLocation(userDetails.getUser(), transactionRef));
    }

    /** Stop sharing my position. */
    @DeleteMapping("/{transactionRef}/live-location")
    public ResponseEntity<Map<String, Object>> stopLiveLocation(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @PathVariable String transactionRef) {
        return ResponseEntity.ok(escrowService.stopLiveLocation(userDetails.getUser(), transactionRef));
    }

    private static Double num(Object o) {
        if (o == null) return null;
        try {
            return o instanceof Number n ? n.doubleValue() : Double.parseDouble(o.toString().trim());
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    // ---- Payment flow (docs/ESCROW_PAYMENT_FLOW.md). Bodies are optional JSON objects. ----

    /** Provider asks the buyer to pay first: {mode: ONLINE|OFFLINE, instructions, deadlineMinutes}. */
    @PostMapping("/request-payment/{transactionRef}")
    public ResponseEntity<EscrowTransactionResponse> requestPayment(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @PathVariable String transactionRef,
            @RequestBody(required = false) Map<String, Object> body) {
        return ResponseEntity.ok(escrowService.requestPayment(userDetails.getUser(), transactionRef, body));
    }

    /** Buyer says they paid the provider directly: {reference?, note?, proofUrl?}. */
    @PostMapping("/mark-paid/{transactionRef}")
    public ResponseEntity<EscrowTransactionResponse> markPaid(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @PathVariable String transactionRef,
            @RequestBody(required = false) Map<String, Object> body) {
        return ResponseEntity.ok(escrowService.markPaid(userDetails.getUser(), transactionRef, body));
    }

    /** Provider confirms the money arrived (the buyer can never confirm). */
    @PostMapping("/confirm-payment/{transactionRef}")
    public ResponseEntity<EscrowTransactionResponse> confirmPayment(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @PathVariable String transactionRef) {
        return ResponseEntity.ok(escrowService.confirmPayment(userDetails.getUser(), transactionRef));
    }

    /** Provider says the money did not arrive: {reason?}. */
    @PostMapping("/payment-not-received/{transactionRef}")
    public ResponseEntity<EscrowTransactionResponse> paymentNotReceived(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @PathVariable String transactionRef,
            @RequestBody(required = false) Map<String, Object> body) {
        return ResponseEntity.ok(escrowService.paymentNotReceived(userDetails.getUser(), transactionRef, body));
    }

    /** Buyer pays in the app: {paymentMethod: POCKET_FUND | MOBILE_MONEY | CARD}. */
    @PostMapping("/pay/{transactionRef}")
    public ResponseEntity<EscrowTransactionResponse> pay(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @PathVariable String transactionRef,
            @RequestBody(required = false) Map<String, Object> body) {
        return ResponseEntity.ok(escrowService.pay(userDetails.getUser(), transactionRef, body));
    }

    /** Buyer uploads a payment screenshot (field "file"). Returns {"url": "..."} to send as proofUrl in mark-paid. */
    @PostMapping(value = "/payment-proof", consumes = org.springframework.http.MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Map<String, String>> uploadProof(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @RequestParam("file") org.springframework.web.multipart.MultipartFile file) {
        return ResponseEntity.ok(Map.of("url", escrowService.uploadPaymentProof(userDetails.getUser(), file)));
    }

    /** The proof picture: only that booking's buyer and provider (and admins). Never cached or sniffed. */
    @GetMapping("/payment-proof/{name}")
    public ResponseEntity<org.springframework.core.io.Resource> proof(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @PathVariable String name) {
        boolean admin = userDetails.getUser().getRole() == com.nearbyservices.model.Role.ROLE_ADMIN;
        java.nio.file.Path file = escrowService.paymentProofFile(userDetails.getUser(), name, admin);
        String lower = name.toLowerCase(java.util.Locale.ROOT);
        String type = lower.endsWith(".png") ? "image/png" : lower.endsWith(".webp") ? "image/webp" : "image/jpeg";
        return ResponseEntity.ok()
                .contentType(org.springframework.http.MediaType.parseMediaType(type))
                .header("Cache-Control", "private, no-store")
                .header("X-Content-Type-Options", "nosniff")
                .body(new org.springframework.core.io.FileSystemResource(file));
    }

    /**
     * Buyer views their escrow transactions.
     */
    @GetMapping("/buyer/my-transactions")
    public ResponseEntity<List<EscrowTransactionResponse>> getBuyerTransactions(
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        return ResponseEntity.ok(escrowService.getBuyerTransactions(userDetails.getUser()));
    }

    /**
     * Seller views orders/escrows created for them.
     */
    @GetMapping("/seller/my-orders")
    public ResponseEntity<List<EscrowTransactionResponse>> getSellerTransactions(
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        return ResponseEntity.ok(escrowService.getSellerTransactions(userDetails.getUser()));
    }

    /**
     * Admin view all platform escrow transactions
     */
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/admin/all")
    public ResponseEntity<List<EscrowTransactionResponse>> getAdminTransactions() {
        return ResponseEntity.ok(escrowService.getAllTransactionsForAdmin());
    }

    /**
     * Admin override release funds
     */
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/admin/release/{transactionRef}")
    public ResponseEntity<EscrowTransactionResponse> adminRelease(@PathVariable String transactionRef) {
        return ResponseEntity.ok(escrowService.adminReleaseFunds(transactionRef));
    }

    /**
     * Admin override refund buyer
     */
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/admin/refund/{transactionRef}")
    public ResponseEntity<EscrowTransactionResponse> adminRefund(@PathVariable String transactionRef) {
        return ResponseEntity.ok(escrowService.adminRefundBuyer(transactionRef));
    }
}
