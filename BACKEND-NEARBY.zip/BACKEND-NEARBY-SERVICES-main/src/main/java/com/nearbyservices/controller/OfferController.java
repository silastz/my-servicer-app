package com.nearbyservices.controller;

import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.OfferService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/offers")
@RequiredArgsConstructor
public class OfferController {

    private final OfferService offerService;

    /** Body: {serviceId, amount, message?}. sellerId and listedPrice may be sent but are ignored. */
    @PostMapping
    public ResponseEntity<Map<String, Object>> create(@AuthenticationPrincipal CustomUserDetails u,
                                                      @RequestBody Map<String, Object> body) {
        return ResponseEntity.ok(offerService.create(u.getUser(),
                number(body.get("serviceId")), decimal(body.get("amount")), text(body.get("message"))));
    }

    @PostMapping("/{id}/accept")
    public ResponseEntity<Map<String, Object>> accept(@AuthenticationPrincipal CustomUserDetails u, @PathVariable Long id) {
        return ResponseEntity.ok(offerService.accept(u.getUser(), id));
    }

    /** Body (optional): {reason?} */
    @PostMapping("/{id}/reject")
    public ResponseEntity<Map<String, Object>> reject(@AuthenticationPrincipal CustomUserDetails u, @PathVariable Long id,
                                                      @RequestBody(required = false) Map<String, Object> body) {
        return ResponseEntity.ok(offerService.reject(u.getUser(), id, body == null ? null : text(body.get("reason"))));
    }

    @PostMapping("/{id}/withdraw")
    public ResponseEntity<Map<String, Object>> withdraw(@AuthenticationPrincipal CustomUserDetails u, @PathVariable Long id) {
        return ResponseEntity.ok(offerService.withdraw(u.getUser(), id));
    }

    /** Offers I sent. */
    @GetMapping("/mine")
    public List<Map<String, Object>> mine(@AuthenticationPrincipal CustomUserDetails u) {
        return offerService.mine(u.getUser());
    }

    /** Offers on my services. */
    @GetMapping("/incoming")
    public List<Map<String, Object>> incoming(@AuthenticationPrincipal CustomUserDetails u) {
        return offerService.incoming(u.getUser());
    }

    private static String text(Object o) {
        return o == null ? null : o.toString();
    }

    private static Long number(Object o) {
        if (o == null) return null;
        try {
            return o instanceof Number n ? n.longValue() : Long.parseLong(o.toString().trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static BigDecimal decimal(Object o) {
        if (o == null) return null;
        try {
            return new BigDecimal(o.toString().trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
