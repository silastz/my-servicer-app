package com.nearbyservices.controller;

import com.nearbyservices.dto.ReviewRequest;
import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.ReviewService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
public class ReviewController {

    private final ReviewService reviewService;

    /** Rate the other side of a COMPLETED booking, once. Body: {transactionRef, rating 1-5, comment?}. */
    @PostMapping("/api/reviews")
    public Map<String, Object> submit(@AuthenticationPrincipal CustomUserDetails u, @Valid @RequestBody ReviewRequest r) {
        return reviewService.submit(u.getUser(), r);
    }

    @GetMapping("/api/reviews/received")
    public List<Map<String, Object>> received(@AuthenticationPrincipal CustomUserDetails u) {
        return reviewService.received(u.getUser());
    }

    @GetMapping("/api/reviews/written")
    public List<Map<String, Object>> written(@AuthenticationPrincipal CustomUserDetails u) {
        return reviewService.written(u.getUser());
    }

    /** Public (no sign-in): buyers' reviews of one provider. */
    @GetMapping("/api/users/{id}/reviews")
    public List<Map<String, Object>> providerReviews(@PathVariable Long id) {
        return reviewService.forProvider(id);
    }
}
