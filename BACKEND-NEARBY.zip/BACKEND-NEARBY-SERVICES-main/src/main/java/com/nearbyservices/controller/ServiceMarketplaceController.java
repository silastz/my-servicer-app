package com.nearbyservices.controller;

import com.nearbyservices.dto.ServicePostRequest;
import com.nearbyservices.dto.ServicePostResponse;
import com.nearbyservices.model.User;
import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.FileStorageService;
import com.nearbyservices.service.SearchHistoryService;
import com.nearbyservices.service.ServiceMarketplaceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

@RestController
@RequestMapping("/api/services")
@RequiredArgsConstructor
public class ServiceMarketplaceController {

    private final ServiceMarketplaceService serviceMarketplaceService;
    private final FileStorageService fileStorageService;
    private final SearchHistoryService searchHistory;

    @PostMapping
    public ResponseEntity<ServicePostResponse> createService(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @Valid @RequestBody ServicePostRequest request) {
        return ResponseEntity.ok(serviceMarketplaceService.createService(userDetails.getUser(), request));
    }

    /**
     * Public list (the viewer is optional: a signed-in owner sees their own contacts).
     * lat / lng / radiusKm / includeSensitive are sent by the app on every call.
     */
    @GetMapping
    public ResponseEntity<Page<ServicePostResponse>> getAllServices(
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @RequestParam(required = false) String query,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String city,
            @RequestParam(required = false) Double lat,
            @RequestParam(required = false) Double lng,
            @RequestParam(required = false) Integer radiusKm,
            @RequestParam(defaultValue = "false") boolean includeSensitive,
            @PageableDefault(size = 20) Pageable pageable) {
        User who = viewer(userDetails);
        // What a signed-in user types in search feeds their promo pushes (first page only, not every scroll).
        if (who != null && query != null && pageable.getPageNumber() == 0) searchHistory.record(who.getId(), query);
        return ResponseEntity.ok(serviceMarketplaceService.getAllActiveServices(
                query, category, city, lat, lng, radiusKm, includeSensitive, who, pageable));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ServicePostResponse> getServiceById(
            @PathVariable Long id,
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        return ResponseEntity.ok(serviceMarketplaceService.getServiceById(id, viewer(userDetails)));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ServicePostResponse> updateService(
            @PathVariable Long id,
            @AuthenticationPrincipal CustomUserDetails userDetails,
            @Valid @RequestBody ServicePostRequest request) {
        return ResponseEntity.ok(serviceMarketplaceService.updateService(id, userDetails.getUser(), request));
    }

    @GetMapping("/seller/my-services")
    public ResponseEntity<java.util.List<ServicePostResponse>> getMyServices(
            @AuthenticationPrincipal CustomUserDetails userDetails) {
        return ResponseEntity.ok(serviceMarketplaceService.getSellerServices(userDetails.getUser()));
    }

    /** Service photo upload. The app sends one multipart field "file" and reads {"url": "..."}. */
    @PostMapping(value = "/images", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Map<String, String>> uploadImage(@RequestParam("file") MultipartFile file) {
        String url = fileStorageService.store(file, FileStorageService.Kind.IMAGE);
        return ResponseEntity.ok(Map.of("url", url));
    }

    /** Service video upload. Same shape as the photo upload. */
    @PostMapping(value = "/videos", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Map<String, String>> uploadVideo(@RequestParam("file") MultipartFile file) {
        String url = fileStorageService.store(file, FileStorageService.Kind.VIDEO);
        return ResponseEntity.ok(Map.of("url", url));
    }

    private static User viewer(CustomUserDetails details) {
        return details == null ? null : details.getUser();
    }
}
