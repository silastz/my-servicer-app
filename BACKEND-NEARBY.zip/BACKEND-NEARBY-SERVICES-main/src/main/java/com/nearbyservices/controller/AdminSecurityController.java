package com.nearbyservices.controller;

import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.AppSecurityService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/** Admin only (also enforced for /api/admin/** in SecurityConfig). The app security switches and wallet top-up limits sent in /api/app/policy. */
@RestController
@RequestMapping("/api/admin/security")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
public class AdminSecurityController {

    private final AppSecurityService security;

    /** {screenCaptureAllowed, blockCompromisedDevice, playIntegrity, blockVpn, topUpMin, topUpMax}; null = not set (app default). */
    @GetMapping
    public Map<String, Object> get() {
        return security.get();
    }

    /**
     * Body: any of the same keys. Absent = unchanged, null = back to the app default (limits: 0 or null = no limit).
     * Limits are whole TSh 100 - 100,000,000; errors INVALID_TOPUP_MIN / INVALID_TOPUP_MAX / TOPUP_MAX_BELOW_MIN / INVALID_<SWITCH>.
     * The server enforces the top-up limits: 400 TOPUP_BELOW_MIN / TOPUP_ABOVE_MAX on a wallet top-up payment.
     */
    @PutMapping
    public Map<String, Object> update(@AuthenticationPrincipal CustomUserDetails admin, @RequestBody Map<String, Object> body) {
        return security.update(admin.getUser().getId(), body);
    }
}
