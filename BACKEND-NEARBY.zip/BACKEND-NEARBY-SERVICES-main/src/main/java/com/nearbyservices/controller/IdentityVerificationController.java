package com.nearbyservices.controller;

import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.service.IdentityVerificationService;
import org.springframework.http.MediaType;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Identity verification as the app calls it (docs/invitation_api_contract.md, verified_name_api_contract.md,
 * verified_photo_api_contract.md, verified_business_api_contract.md). All calls need a signed-in user;
 * errors come back as {"message": "<CODE>"} (see GlobalExceptionHandler).
 */
@RestController
public class IdentityVerificationController {

    private final IdentityVerificationService service;

    public IdentityVerificationController(IdentityVerificationService service) {
        this.service = service;
    }

    // ---- legal name
    @GetMapping("/api/users/me/verified-name")
    public Map<String, Object> getName(@AuthenticationPrincipal CustomUserDetails me) {
        return service.getName(me.getUser());
    }

    @PostMapping("/api/users/me/verified-name")
    public Map<String, Object> submitName(@AuthenticationPrincipal CustomUserDetails me, @RequestBody Map<String, Object> body) {
        return service.submitName(me.getUser(), str(body, "fullName"), str(body, "nidaNumber"));
    }

    // ---- verified photo
    @GetMapping("/api/users/me/verified-photo")
    public Map<String, Object> getPhoto(@AuthenticationPrincipal CustomUserDetails me) {
        return service.getPhoto(me.getUser());
    }

    @PostMapping(value = "/api/users/me/verified-photo", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String, Object> uploadPhoto(@AuthenticationPrincipal CustomUserDetails me, @RequestParam("file") MultipartFile file) {
        return service.uploadPhoto(me.getUser(), file);
    }

    // ---- ID and business papers
    @GetMapping("/api/verification/documents")
    public List<Map<String, Object>> documents(@AuthenticationPrincipal CustomUserDetails me) {
        return service.listDocuments(me.getUser());
    }

    @PostMapping(value = "/api/verification/documents", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String, Object> uploadDocument(@AuthenticationPrincipal CustomUserDetails me,
                                              @RequestParam("file") MultipartFile file,
                                              @RequestParam("type") String type,
                                              @RequestParam(value = "idKind", required = false) String idKind) {
        return service.uploadDocument(me.getUser(), file, type, idKind);
    }

    // ---- Verified Business
    @GetMapping("/api/verification/business")
    public Map<String, Object> business(@AuthenticationPrincipal CustomUserDetails me) {
        return service.getBusiness(me.getUser());
    }

    @PostMapping("/api/verification/business")
    public Map<String, Object> saveBusiness(@AuthenticationPrincipal CustomUserDetails me, @RequestBody Map<String, Object> body) {
        service.saveBusiness(me.getUser(), str(body, "businessName"));
        return Map.of("status", "SAVED");
    }

    // ---- trusted invitations
    @PostMapping("/api/verification/invitations")
    public Map<String, Object> createInvitation(@AuthenticationPrincipal CustomUserDetails me, @RequestBody Map<String, Object> body) {
        return service.createInvitation(me.getUser(), str(body, "inviteePhone"));
    }

    @GetMapping("/api/verification/invitations")
    public List<Map<String, Object>> invitations(@AuthenticationPrincipal CustomUserDetails me) {
        return service.listInvitations(me.getUser());
    }

    @PostMapping("/api/verification/invitations/accept")
    public Map<String, Object> accept(@AuthenticationPrincipal CustomUserDetails me, @RequestBody Map<String, Object> body) {
        return service.acceptInvitation(me.getUser(), str(body, "code"));
    }

    // ---- vouch requests
    @PostMapping("/api/verification/invitation-requests")
    public Map<String, Object> requestVouch(@AuthenticationPrincipal CustomUserDetails me, @RequestBody Map<String, Object> body) {
        return service.requestVouch(me.getUser(), str(body, "providerPhone"));
    }

    @GetMapping("/api/verification/invitation-requests")
    public List<Map<String, Object>> vouchRequests(@AuthenticationPrincipal CustomUserDetails me) {
        return service.listVouchRequests(me.getUser());
    }

    @PostMapping("/api/verification/invitation-requests/{id}/approve")
    public Map<String, Object> approve(@AuthenticationPrincipal CustomUserDetails me, @PathVariable String id) {
        return service.answerVouch(me.getUser(), id, true);
    }

    @PostMapping("/api/verification/invitation-requests/{id}/decline")
    public Map<String, Object> decline(@AuthenticationPrincipal CustomUserDetails me, @PathVariable String id) {
        return service.answerVouch(me.getUser(), id, false);
    }

    static String str(Map<String, Object> body, String key) {
        Object v = body == null ? null : body.get(key);
        return v == null ? null : String.valueOf(v);
    }
}
