package com.nearbyservices.config;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

/** Live chat: wss://host/ws/chat. Access is decided by the token the app sends as its first frame. */
@Configuration
@EnableWebSocket
@RequiredArgsConstructor
public class WebSocketConfig implements WebSocketConfigurer {

    private final ChatWebSocketHandler chatHandler;

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        // The phone app sends no browser Origin; the JWT in the first frame is the real protection.
        registry.addHandler(chatHandler, "/ws/chat").setAllowedOriginPatterns("*");
    }
}
