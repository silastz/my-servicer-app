package com.nearbyservices.config;

import com.nearbyservices.security.CustomUserDetailsService;
import com.nearbyservices.security.JwtAuthenticationEntryPoint;
import com.nearbyservices.security.JwtAuthenticationFilter;
import com.nearbyservices.security.SecurityHeadersFilter;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthFilter;
    private final SecurityHeadersFilter securityHeadersFilter;
    private final JwtAuthenticationEntryPoint jwtAuthEntryPoint;
    private final CustomUserDetailsService userDetailsService;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(AbstractHttpConfigurer::disable)
                .cors(cors -> cors.configurationSource(corsConfigurationSource()))
                .exceptionHandling(ex -> ex.authenticationEntryPoint(jwtAuthEntryPoint))
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .headers(headers -> headers
                        .frameOptions(HeadersConfigurer.FrameOptionsConfig::deny)
                        .xssProtection(HeadersConfigurer.XXssConfig::disable)
                        .contentSecurityPolicy(csp -> csp.policyDirectives("default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:;"))
                )
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/api/admin/**", "/api/escrow/admin/**").hasRole("ADMIN")
                        // Browsing services and viewing uploaded pictures is public, but ONLY by GET:
                        // POST/PUT on /api/services need a signed-in user (they used to be open and crashed).
                        .requestMatchers(HttpMethod.GET,
                                "/api/services",
                                "/api/services/*",
                                "/api/app/policy",
                                "/api/app/ads",
                                "/api/app/version",
                                "/api/users/*/reviews",
                                "/api/portfolio/user/*",
                                // App Links: ownership file + the pages behind shared invitation / service links.
                                "/.well-known/assetlinks.json",
                                // Hosted Privacy Policy, Terms and "delete your account" pages (store requirement).
                                "/legal/privacy",
                                "/legal/terms",
                                "/legal/delete-account",
                                "/i/*",
                                "/s/*",
                                "/uploads/**").permitAll()
                        .requestMatchers(
                                "/api/auth/**",
                                // Gateway callbacks carry no JWT; the controller checks a shared secret itself.
                                "/api/payments/webhook/**",
                                "/api/payments/sandbox/checkout/**",
                                "/api/verification/users/*/public",
                                "/api/health",
                                // WebSocket handshake carries no header; ChatWebSocketHandler checks the token itself.
                                "/ws/chat",
                                "/v3/api-docs/**",
                                "/swagger-ui/**",
                                "/swagger-ui.html",
                                "/error"
                        ).permitAll()
                        .anyRequest().authenticated()
                )
                .authenticationProvider(authenticationProvider())
                .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class)
                .addFilterAfter(securityHeadersFilter, JwtAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public AuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider(userDetailsService);
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        // High-security BCrypt hashing with salt factor 12
        return new BCryptPasswordEncoder(12);
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        // Allow mobile clients, web clients, and official frontends
        configuration.setAllowedOriginPatterns(List.of("*"));
        configuration.setAllowedMethods(List.of("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"));
        configuration.setAllowedHeaders(List.of(
                "Authorization",
                "Content-Type",
                "X-Requested-With",
                "Accept",
                "Origin",
                "Access-Control-Request-Method",
                "Access-Control-Request-Headers",
                // Sent by the app on every call (money of the user's country) and on sensitive calls.
                "X-Country",
                "X-Currency",
                "X-Integrity-Token",
                "X-Integrity-Nonce"
        ));
        configuration.setExposedHeaders(List.of("Authorization", "X-Refreshed-Token"));
        configuration.setAllowCredentials(true);
        configuration.setMaxAge(3600L);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
}
