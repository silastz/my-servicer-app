package com.nearbyservices.config;

import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.security.CustomUserDetailsService;
import com.nearbyservices.security.JwtService;
import com.nearbyservices.service.ChatDeliveryService;
import com.nearbyservices.service.ChatSocketRegistry;
import jakarta.annotation.PreDestroy;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.ConcurrentWebSocketSessionDecorator;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.io.IOException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Live chat socket at /ws/chat.
 *
 * The token is NOT put in the URL (URLs end up in server and proxy logs). The first frame the
 * app sends must be the text "auth <jwt>" within 10 seconds, otherwise the connection is closed.
 * After that the only frame the app sends is "ping" (answered with "pong") to keep the line open.
 */
@Component
@RequiredArgsConstructor
public class ChatWebSocketHandler extends TextWebSocketHandler {

    private static final String UID = "uid";
    private static final String DECORATED = "decorated";
    private static final int AUTH_TIMEOUT_SECONDS = 10;

    private final JwtService jwtService;
    private final CustomUserDetailsService userDetailsService;
    private final ChatSocketRegistry registry;
    private final ChatDeliveryService deliveryService;

    private final ScheduledExecutorService timer = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "chat-ws-auth-timeout");
        t.setDaemon(true);
        return t;
    });

    @PreDestroy
    void shutdown() {
        timer.shutdownNow();
    }

    @Override
    public void afterConnectionEstablished(WebSocketSession session) {
        timer.schedule(() -> {
            try {
                if (session.isOpen() && session.getAttributes().get(UID) == null) {
                    session.close(CloseStatus.POLICY_VIOLATION);
                }
            } catch (IOException ignored) {
            }
        }, AUTH_TIMEOUT_SECONDS, TimeUnit.SECONDS);
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws IOException {
        String text = message.getPayload();
        Object uid = session.getAttributes().get(UID);

        if (uid == null) {
            if (!text.startsWith("auth ") || text.length() > 4096) {
                session.close(CloseStatus.POLICY_VIOLATION);
                return;
            }
            Long userId = authenticate(text.substring(5).trim());
            if (userId == null) {
                session.close(CloseStatus.POLICY_VIOLATION);
                return;
            }
            // several threads may write to one socket (message sent + message read at once)
            WebSocketSession safe = new ConcurrentWebSocketSessionDecorator(session, 5000, 64 * 1024);
            session.getAttributes().put(UID, userId);
            session.getAttributes().put(DECORATED, safe);
            registry.add(userId, safe);
            safe.sendMessage(new TextMessage("{\"type\":\"ready\"}"));
            deliverWaitingMessages(userId);
            return;
        }

        if ("ping".equals(text)) {
            WebSocketSession safe = (WebSocketSession) session.getAttributes().get(DECORATED);
            if (safe != null) safe.sendMessage(new TextMessage("pong"));
        }
        // anything else is ignored: the app only ever listens
    }

    /** The user just came online: messages sent while they were away now count as delivered (two ticks). */
    private void deliverWaitingMessages(Long userId) {
        try {
            for (Long senderId : deliveryService.markAllDelivered(userId)) {
                registry.push(senderId, ChatSocketRegistry.chatEvent("delivered", userId, senderId));
            }
        } catch (RuntimeException ignored) {
            // ticks are cosmetic: the chat list load marks them delivered as well
        }
    }

    private Long authenticate(String jwt) {
        try {
            String username = jwtService.extractUsername(jwt);
            if (username == null) return null;
            UserDetails details = userDetailsService.loadUserById(username);
            if (!jwtService.isTokenValid(jwt, details) || !details.isEnabled()) return null;
            if (details instanceof CustomUserDetails cud) return cud.getUser().getId();
            return null;
        } catch (Exception e) {
            return null; // bad / expired token, unknown user
        }
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        Object uid = session.getAttributes().get(UID);
        if (uid instanceof Long id) registry.remove(id, session.getId());
    }

    @Override
    public void handleTransportError(WebSocketSession session, Throwable exception) throws IOException {
        if (session.isOpen()) session.close(CloseStatus.SERVER_ERROR);
    }
}
