package com.nearbyservices.config;

import com.nearbyservices.model.ServiceCategory;
import com.nearbyservices.repository.ServiceCategoryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

/** Puts the starting categories in an empty table. After that the table (not this class) is the category list. */
@Component
@RequiredArgsConstructor
@Slf4j
public class ServiceCategorySeeder implements CommandLineRunner {

    private final ServiceCategoryRepository repo;

    private static ServiceCategory c(String id, String sw, int order) {
        return ServiceCategory.builder().id(id).nameEn(id).nameSw(sw).sortOrder(order).build();
    }

    @Override
    public void run(String... args) {
        try {
            if (repo.count() > 0) return;
            repo.saveAll(List.of(
                    c("Massage", "Masaji", 1), c("Beauty", "Urembo", 2), c("Barber", "Kinyozi", 3),
                    c("Cleaning", "Usafi", 4), c("Plumbing", "Mabomba", 5), c("Electrical", "Umeme", 6),
                    c("Mechanic", "Fundi Magari", 7), c("Photography", "Picha", 8), c("Repair", "Ukarabati", 9),
                    c("Food", "Chakula", 10), c("General", "Nyingine", 11)));
            log.info("Seeded the default service categories.");
        } catch (Exception e) {
            log.warn("Could not seed service categories: {}", e.getMessage());
        }
    }
}
