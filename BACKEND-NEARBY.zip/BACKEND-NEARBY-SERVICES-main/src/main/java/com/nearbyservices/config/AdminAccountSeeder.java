package com.nearbyservices.config;

import com.nearbyservices.model.Role;
import com.nearbyservices.model.User;
import com.nearbyservices.model.Wallet;
import com.nearbyservices.repository.UserRepository;
import com.nearbyservices.repository.WalletRepository;
import com.nearbyservices.service.SmsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionTemplate;

import java.math.BigDecimal;
import java.util.Locale;

/**
 * Creates the first admin account from the environment, so a fresh server has someone who can sign in to the
 * admin screens. Admin accounts can never be created through sign-up.
 *
 * ADMIN_PHONE + ADMIN_PASSWORD (min 10 characters) [+ ADMIN_EMAIL, ADMIN_NAME]. There is NO built-in password.
 * - Account with that phone does not exist: it is created (phone already verified).
 * - It exists but is not an admin: it is promoted to admin (its password is left as it is).
 * - It is already an admin: nothing changes. A restart never resets a password the admin changed.
 * With no admin at all and nothing configured, a warning is logged at every start.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class AdminAccountSeeder {

    private static final int MIN_PASSWORD = 10;

    private final UserRepository userRepository;
    private final WalletRepository walletRepository;
    private final PasswordEncoder passwordEncoder;
    private final TransactionTemplate tx;

    @Value("${app.admin.phone:}")
    private String phoneRaw;
    @Value("${app.admin.password:}")
    private String password;
    @Value("${app.admin.email:}")
    private String emailRaw;
    @Value("${app.admin.name:Admin}")
    private String name;

    @EventListener(ApplicationReadyEvent.class)
    public void seed() {
        try {
            if (phoneRaw == null || phoneRaw.isBlank() || password == null || password.isBlank()) {
                boolean anyAdmin = userRepository.findAll().stream().anyMatch(u -> u.getRole() == Role.ROLE_ADMIN);
                if (!anyAdmin) log.warn("NO ADMIN ACCOUNT: set ADMIN_PHONE and ADMIN_PASSWORD (min {} characters) in .env and restart.", MIN_PASSWORD);
                return;
            }
            if (password.length() < MIN_PASSWORD) {
                log.error("ADMIN_PASSWORD is shorter than {} characters: admin account NOT created.", MIN_PASSWORD);
                return;
            }
            String phone = SmsService.normalizePhoneNumber(phoneRaw.trim());
            if (!phone.matches("^\\+[0-9]{9,15}$")) {
                log.error("ADMIN_PHONE is not a valid phone number: admin account NOT created.");
                return;
            }
            String email = emailRaw == null || emailRaw.isBlank() ? null : emailRaw.trim().toLowerCase(Locale.ROOT);
            tx.executeWithoutResult(s -> {
                User existing = userRepository.findByPhone(phone).orElse(null);
                if (existing != null) {
                    if (existing.getRole() == Role.ROLE_ADMIN) return;
                    existing.setRole(Role.ROLE_ADMIN);
                    existing.setPhoneVerified(true);
                    userRepository.save(existing);
                    log.warn("Existing account {} was promoted to ADMIN (ADMIN_PHONE).", phone);
                    return;
                }
                if (email != null && userRepository.existsByEmail(email)) {
                    log.error("ADMIN_EMAIL is already used by another account: admin account NOT created.");
                    return;
                }
                User saved = userRepository.save(User.builder()
                        .username("admin_" + Long.toString(System.nanoTime(), 36))
                        .phone(phone)
                        .phoneVerified(true)
                        .email(email)
                        .emailVerified(email != null)
                        .password(passwordEncoder.encode(password))
                        .stageName(name == null || name.isBlank() ? "Admin" : name.trim())
                        .role(Role.ROLE_ADMIN)
                        .build());
                walletRepository.save(Wallet.builder().user(saved).balance(BigDecimal.ZERO).lockedEscrowBalance(BigDecimal.ZERO).build());
                log.info("Admin account created for {}. Sign in with that phone and ADMIN_PASSWORD.", phone);
            });
        } catch (Exception e) {
            log.error("Could not seed the admin account: {}", e.getMessage());
        }
    }
}
