package com.nearbyservices.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

/**
 * The built-in JWT secret is public (it is in the source code): anyone could sign a login token for any user,
 * including an admin. Warns loudly at every start while it is in use; with REQUIRE_LIVE_PAYMENTS=true
 * (production) the server refuses to start.
 */
@Component
public class JwtSecretStartupCheck {

    private static final Logger log = LoggerFactory.getLogger(JwtSecretStartupCheck.class);
    static final String PUBLIC_DEFAULT = "404E635266556A586E3272357538782F413F4428472B4B6250645367566B5970";

    @Value("${security.jwt.secret:" + PUBLIC_DEFAULT + "}")
    private String secret;
    @Value("${payments.require-live:false}")
    private boolean requireLive;

    @EventListener(ApplicationReadyEvent.class)
    public void check() {
        if (secret == null || !PUBLIC_DEFAULT.equalsIgnoreCase(secret.trim())) return;
        String problem = "JWT_SECRET is the public default from the source code: anyone can forge a login token. Set JWT_SECRET (openssl rand -hex 32).";
        if (requireLive) throw new IllegalStateException("REQUIRE_LIVE_PAYMENTS is on. " + problem);
        log.warn("=================================================================");
        log.warn("INSECURE: {}", problem);
        log.warn("=================================================================");
    }
}
