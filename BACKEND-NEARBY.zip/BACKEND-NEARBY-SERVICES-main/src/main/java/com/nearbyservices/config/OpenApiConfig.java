package com.nearbyservices.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI nearbyServicesOpenAPI() {
        final String securitySchemeName = "bearerAuth";

        return new OpenAPI()
                .info(new Info()
                        .title("NEARBY SERVICES REST API")
                        .description("Enterprise REST API for Nearby Services Marketplace featuring NIDA Verification, In-App Escrow Wallet, and Service Listings.")
                        .version("v1.0.0")
                        .contact(new Contact()
                                .name("Adam Lwena Dev Team")
                                .email("dev@nearbyservices.co.tz"))
                        .license(new License()
                                .name("Proprietary")
                                .url("https://nearbyservices.co.tz")))
                .addSecurityItem(new SecurityRequirement().addList(securitySchemeName))
                .components(new Components()
                        .addSecuritySchemes(securitySchemeName,
                                new SecurityScheme()
                                        .name(securitySchemeName)
                                        .type(SecurityScheme.Type.HTTP)
                                        .scheme("bearer")
                                        .bearerFormat("JWT")
                                        .description("Weka token yako ya JWT: 'Bearer {token}'")));
    }
}
