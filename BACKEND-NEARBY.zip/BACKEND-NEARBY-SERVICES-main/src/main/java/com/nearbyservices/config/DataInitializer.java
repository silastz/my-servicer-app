package com.nearbyservices.config;

import com.nearbyservices.model.Role;
import com.nearbyservices.model.ServicePost;
import com.nearbyservices.model.User;
import com.nearbyservices.model.VerificationBadge;
import com.nearbyservices.model.Wallet;
import com.nearbyservices.repository.ServicePostRepository;
import com.nearbyservices.repository.UserRepository;
import com.nearbyservices.repository.WalletRepository;
import org.springframework.jdbc.core.JdbcTemplate;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.math.BigDecimal;
import java.util.List;

@Configuration
@RequiredArgsConstructor
@Slf4j
public class DataInitializer {

    private final UserRepository userRepository;
    private final WalletRepository walletRepository;
    private final ServicePostRepository servicePostRepository;
    private final PasswordEncoder passwordEncoder;
    private final JdbcTemplate jdbcTemplate;

    /** Demo sellers and stock-photo services. Off by default; set APP_SEED_DEMO_DATA=true only for local demos. */
    @org.springframework.beans.factory.annotation.Value("${app.seed-demo-data:false}")
    private boolean seedDemoData;

    @Bean
    public CommandLineRunner seedDatabase() {
        return args -> {
            try {
                log.info("Ensuring database schema columns are up to date...");
                jdbcTemplate.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS email VARCHAR(255);");
                jdbcTemplate.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verified BOOLEAN DEFAULT FALSE;");
                jdbcTemplate.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS email_otp VARCHAR(10);");
                jdbcTemplate.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS email_otp_expiry TIMESTAMP;");
                jdbcTemplate.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS invited_by_user_id BIGINT;");
                jdbcTemplate.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS nida_id_photo_url VARCHAR(255);");
                jdbcTemplate.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS nida_selfie_photo_url VARCHAR(255);");
                jdbcTemplate.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS nida_number VARCHAR(255);");
                jdbcTemplate.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS nida_official_first_name VARCHAR(255);");
                jdbcTemplate.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS nida_official_last_name VARCHAR(255);");
                jdbcTemplate.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS service_fee_credits INTEGER NOT NULL DEFAULT 0;");
                jdbcTemplate.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS services_posted INTEGER NOT NULL DEFAULT 0;");
                jdbcTemplate.execute("ALTER TABLE admin_settings ADD COLUMN IF NOT EXISTS service_fee NUMERIC(15,2) NOT NULL DEFAULT 5000;");
                jdbcTemplate.execute("ALTER TABLE admin_settings ADD COLUMN IF NOT EXISTS card_payments_enabled BOOLEAN NOT NULL DEFAULT FALSE;");
                jdbcTemplate.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS registration_fee_paid BOOLEAN NOT NULL DEFAULT FALSE;");
                jdbcTemplate.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS bio VARCHAR(500);");
                jdbcTemplate.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS avatar_url VARCHAR(500);");
                jdbcTemplate.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS cover_url VARCHAR(500);");
                jdbcTemplate.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS hide_my_id BOOLEAN NOT NULL DEFAULT FALSE;");
                jdbcTemplate.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS profile_locked BOOLEAN NOT NULL DEFAULT TRUE;");
                jdbcTemplate.execute("ALTER TABLE escrow_transactions DROP CONSTRAINT IF EXISTS escrow_transactions_status_check;");
                jdbcTemplate.execute("ALTER TABLE escrow_transactions ADD CONSTRAINT escrow_transactions_status_check CHECK (status::text = ANY (ARRAY['PENDING_ACCEPTANCE'::character varying, 'ACCEPTED'::character varying, 'FUNDED'::character varying, 'COMPLETED'::character varying, 'DISPUTED'::character varying, 'REFUNDED'::character varying, 'REJECTED'::character varying, 'AWAITING_PAYMENT'::character varying, 'PAYMENT_SENT'::character varying, 'PAYMENT_DISPUTED'::character varying, 'CANCELLED'::character varying]::text[]));");
                // Hibernate may have created a CHECK on payment_method with only the two old values; the new ones (OFFLINE, PAY_AFTER_ACCEPT) must be allowed.
                jdbcTemplate.execute("ALTER TABLE escrow_transactions DROP CONSTRAINT IF EXISTS escrow_transactions_payment_method_check;");
                jdbcTemplate.execute("ALTER TABLE escrow_transactions ADD CONSTRAINT escrow_transactions_payment_method_check CHECK (payment_method::text = ANY (ARRAY['DIRECT'::character varying, 'POCKET_FUND'::character varying, 'OFFLINE'::character varying, 'PAY_AFTER_ACCEPT'::character varying]::text[]));");
                log.info("Database schema check completed successfully.");
            } catch (Exception e) {
                log.warn("Schema migration notice: {}", e.getMessage());
            }

            if (!seedDemoData) {
                log.info("Demo seeding disabled (app.seed-demo-data=false).");
                return;
            }

            if (servicePostRepository.count() > 0) {
                log.info("Database already seeded. Skipping initial seeding.");
                return;
            }

            log.info("Starting database seeding for NearByServices marketplace...");

            // 1. Create Verified Sellers with Stage Names and Privacy Rules
            User seller1 = createOrGetUser("zeen_spa", "+255712345601", "Zeen Spa & Wellness",
                    Role.ROLE_SELLER, VerificationBadge.BLUE_TICK, "19940101-12345-00001-21");

            User seller2 = createOrGetUser("relax_touch", "+255712345602", "Relax Touch Massage",
                    Role.ROLE_SELLER, VerificationBadge.BLUE_TICK, "19920512-45210-00002-14");

            User seller3 = createOrGetUser("pro_cleaners", "+255712345603", "Kazi Bora Cleaning",
                    Role.ROLE_SELLER, VerificationBadge.GREEN_BADGE, "19950820-89123-00003-88");

            User seller4 = createOrGetUser("fundi_musa", "+255712345604", "Musa Quick Plumbing",
                    Role.ROLE_SELLER, VerificationBadge.BLUE_TICK, "19881104-77412-00004-95");

            User seller5 = createOrGetUser("dara_glam", "+255712345605", "Dara Glam Beauty & Hair",
                    Role.ROLE_SELLER, VerificationBadge.GREEN_BADGE, "19980315-66321-00005-32");

            User seller6 = createOrGetUser("voltage_pro", "+255712345606", "ElectroFix Solutions",
                    Role.ROLE_SELLER, VerificationBadge.BLUE_TICK, "19901225-33124-00006-71");

            User seller7 = createOrGetUser("king_barber", "+255712345607", "Fresh Cut Barber Shop",
                    Role.ROLE_SELLER, VerificationBadge.BLUE_TICK, "19960410-11223-00007-44");

            User seller8 = createOrGetUser("autocare_tz", "+255712345608", "AutoCare Garage & Mechanics",
                    Role.ROLE_SELLER, VerificationBadge.BLUE_TICK, "19850917-88990-00008-19");

            User seller9 = createOrGetUser("pixel_studio", "+255712345609", "Pro Photography & Studio",
                    Role.ROLE_SELLER, VerificationBadge.GREEN_BADGE, "19971201-44556-00009-66");

            User seller10 = createOrGetUser("james_tutor", "+255712345610", "Maths & Science Home Tutor",
                    Role.ROLE_SELLER, VerificationBadge.BLUE_TICK, "19930708-99887-00010-85");

            // 2. Create Realistic Service Posts with Real Images & Diverse Locations
            List<ServicePost> services = List.of(
                    // Massage Services
                    ServicePost.builder()
                            .title("Relax & Feel Better Massage Therapy")
                            .description("Huduma bora ya masaji ya kupumzisha mwili, kutoa uchovu na kuondoa maumivu ya misuli na viungo.")
                            .category("Massage")
                            .price(new BigDecimal("50000.00"))
                            .city("Dar es Salaam")
                            .region("Kinondoni")
                            .latitude(-6.7725)
                            .longitude(39.2412)
                            .phone("+255712345601")
                            .whatsappPhone("+255712345601")
                            .email("zeenspa@nearbyservices.tz")
                            .instagramUsername("zeen_wellness_tz")
                            .isInfoLocked(true) // LOCKED contacts
                            .imageUrls(List.of(
                                "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=800&auto=format&fit=crop&q=80",
                                "https://images.unsplash.com/photo-1600334129128-685c5582fd35?w=800&auto=format&fit=crop&q=80"
                            ))
                            .seller(seller1)
                            .active(true)
                            .build(),

                    ServicePost.builder()
                            .title("Hot Stone & Swedish Relaxation Therapy")
                            .description("Masaji ya kisasa ya mawe ya moto pamoja na mafuta asilia ya kutuliza msongo wa mawazo na mwili.")
                            .category("Massage")
                            .price(new BigDecimal("40000.00"))
                            .city("Dar es Salaam")
                            .region("Mikocheni")
                            .latitude(-6.7589)
                            .longitude(39.2520)
                            .phone("+255712345602")
                            .whatsappPhone("+255712345602")
                            .email("relaxtouch@nearbyservices.tz")
                            .instagramUsername("relax_touch_massage")
                            .isInfoLocked(false) // UNLOCKED contacts
                            .imageUrls(List.of(
                                "https://images.unsplash.com/photo-1519823551278-64ac92734fb1?w=800&auto=format&fit=crop&q=80",
                                "https://images.unsplash.com/photo-1540555700478-4be289fbecef?w=800&auto=format&fit=crop&q=80"
                            ))
                            .seller(seller2)
                            .active(true)
                            .build(),

                    ServicePost.builder()
                            .title("Best Care Therapeutic Deep Body Massage")
                            .description("Huduma ya masaji ya kitaalamu ya kina kwa ajili ya wanamichezo na wanaofanya kazi ngumu.")
                            .category("Massage")
                            .price(new BigDecimal("60000.00"))
                            .city("Dar es Salaam")
                            .region("Masaki")
                            .latitude(-6.7450)
                            .longitude(39.2780)
                            .phone("+255712345601")
                            .whatsappPhone("+255712345601")
                            .isInfoLocked(true)
                            .imageUrls(List.of(
                                "https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=800&auto=format&fit=crop&q=80"
                            ))
                            .seller(seller1)
                            .active(true)
                            .build(),

                    // Barber
                    ServicePost.builder()
                            .title("Fresh Cut Executive Haircut & Beard Grooming")
                            .description("Kunyolewa kisasa, scrub ya uso, kupaka rangi ndevu na masaji ya kichwa saluni au nyumbani kwako.")
                            .category("Barber")
                            .price(new BigDecimal("30000.00"))
                            .city("Dar es Salaam")
                            .region("Sinza")
                            .latitude(-6.7845)
                            .longitude(39.2230)
                            .phone("+255712345607")
                            .whatsappPhone("+255712345607")
                            .instagramUsername("freshcut_barber_tz")
                            .isInfoLocked(false)
                            .imageUrls(List.of(
                                "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=800&auto=format&fit=crop&q=80",
                                "https://images.unsplash.com/photo-1622286342621-4bd786c2447c?w=800&auto=format&fit=crop&q=80"
                            ))
                            .seller(seller7)
                            .active(true)
                            .build(),

                    // Cleaning
                    ServicePost.builder()
                            .title("Sparkle Cleaning Services & Deep Sofa Washing")
                            .description("Usafi wa kina wa nyumba, masofa, mazulia, magodoro na ofisi kwa kutumia mashine za kisasa za mvuke.")
                            .category("Cleaning")
                            .price(new BigDecimal("40000.00"))
                            .city("Dar es Salaam")
                            .region("Oysterbay")
                            .latitude(-6.7801)
                            .longitude(39.2734)
                            .phone("+255712345603")
                            .whatsappPhone("+255712345603")
                            .email("kazibora@nearbyservices.tz")
                            .instagramUsername("kaziboracleaning")
                            .isInfoLocked(true)
                            .imageUrls(List.of(
                                "https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=800&auto=format&fit=crop&q=80",
                                "https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?w=800&auto=format&fit=crop&q=80"
                            ))
                            .seller(seller3)
                            .active(true)
                            .build(),

                    // Mechanic
                    ServicePost.builder()
                            .title("AutoCare Mobile Garage & Computer Diagnostics")
                            .description("Ukaguzi na matengenezo ya gari popote ulipo (engine, suspension, wiring, na kupima gari na computer).")
                            .category("Mechanic")
                            .price(new BigDecimal("60000.00"))
                            .city("Dar es Salaam")
                            .region("Kijitonyama")
                            .latitude(-6.7780)
                            .longitude(39.2450)
                            .phone("+255712345608")
                            .whatsappPhone("+255712345608")
                            .isInfoLocked(false)
                            .imageUrls(List.of(
                                "https://images.unsplash.com/photo-1486006920555-c77dce18193b?w=800&auto=format&fit=crop&q=80",
                                "https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?w=800&auto=format&fit=crop&q=80"
                            ))
                            .seller(seller8)
                            .active(true)
                            .build(),

                    // Beauty & Makeup
                    ServicePost.builder()
                            .title("Glow Beauty Salon, Facial & Skin Care")
                            .description("Huduma ya urembo wa bibi harusi, makeup ya matukio, kusuka na kutengeneza nywele nyumbani kwako.")
                            .category("Beauty")
                            .price(new BigDecimal("35000.00"))
                            .city("Dar es Salaam")
                            .region("Sinza")
                            .latitude(-6.7865)
                            .longitude(39.2241)
                            .phone("+255712345605")
                            .whatsappPhone("+255712345605")
                            .isInfoLocked(false)
                            .imageUrls(List.of(
                                "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=800&auto=format&fit=crop&q=80",
                                "https://images.unsplash.com/photo-1560066984-138dadb4c035?w=800&auto=format&fit=crop&q=80"
                            ))
                            .seller(seller5)
                            .active(true)
                            .build(),

                    // Plumbing
                    ServicePost.builder()
                            .title("Reliable Plumber & Drainage Emergency Repair")
                            .description("Urekebishaji wa dharura wa mabomba ya maji, mifereji iliyoziba, na ufungaji wa heater na sinki.")
                            .category("Plumbing")
                            .price(new BigDecimal("45000.00"))
                            .city("Dar es Salaam")
                            .region("Ilala")
                            .latitude(-6.8234)
                            .longitude(39.2695)
                            .phone("+255712345604")
                            .whatsappPhone("+255712345604")
                            .email("fundimusa@nearbyservices.tz")
                            .instagramUsername("musa_plumbing_tz")
                            .isInfoLocked(false)
                            .imageUrls(List.of(
                                "https://images.unsplash.com/photo-1585704032915-c3400ca199e7?w=800&auto=format&fit=crop&q=80"
                            ))
                            .seller(seller4)
                            .active(true)
                            .build(),

                    // Electrical
                    ServicePost.builder()
                            .title("Bright Electric - Solar & Home Wiring")
                            .description("Ufungaji wa mifumo ya umeme, solar, generator, ukarabati wa hitilafu na ukaguzi wa usalama wa moto.")
                            .category("Electrical")
                            .price(new BigDecimal("55000.00"))
                            .city("Dar es Salaam")
                            .region("Mbezi Beach")
                            .latitude(-6.7112)
                            .longitude(39.2134)
                            .phone("+255712345606")
                            .whatsappPhone("+255712345606")
                            .isInfoLocked(true)
                            .imageUrls(List.of(
                                "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=800&auto=format&fit=crop&q=80"
                            ))
                            .seller(seller6)
                            .active(true)
                            .build(),

                    // Photography
                    ServicePost.builder()
                            .title("Pro Photography, Video & Event Coverage")
                            .description("Upigaji picha wa studio, harusi, birthday, picha za kibiashara na video za 4K.")
                            .category("Photography")
                            .price(new BigDecimal("70000.00"))
                            .city("Dar es Salaam")
                            .region("Mikocheni")
                            .latitude(-6.7550)
                            .longitude(39.2510)
                            .phone("+255712345609")
                            .whatsappPhone("+255712345609")
                            .isInfoLocked(false)
                            .imageUrls(List.of(
                                "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=800&auto=format&fit=crop&q=80",
                                "https://images.unsplash.com/photo-1537633552985-df8429e8048b?w=800&auto=format&fit=crop&q=80"
                            ))
                            .seller(seller9)
                            .active(true)
                            .build(),

                    // Tutoring
                    ServicePost.builder()
                            .title("Maths & Science Home Tuition (Primary & Secondary)")
                            .description("Mwalimu wa nyumbani wa hesabu, fizikia na kemia kuanzia shule ya msingi hadi kidato cha sita.")
                            .category("Tutoring")
                            .price(new BigDecimal("25000.00"))
                            .city("Dar es Salaam")
                            .region("Ubungo")
                            .latitude(-6.7820)
                            .longitude(39.2080)
                            .phone("+255712345610")
                            .whatsappPhone("+255712345610")
                            .isInfoLocked(true)
                            .imageUrls(List.of(
                                "https://images.unsplash.com/photo-1577896851231-70ef18881754?w=800&auto=format&fit=crop&q=80"
                            ))
                            .seller(seller10)
                            .active(true)
                            .build()
            );

            servicePostRepository.saveAll(services);
            log.info("Database seeding completed successfully with {} sample services!", services.size());
        };
    }

    private User createOrGetUser(String username, String phone, String stageName, Role role,
                                 VerificationBadge badge, String nida) {
        return userRepository.findByUsername(username).orElseGet(() -> {
            User user = User.builder()
                    .username(username)
                    .phone(phone)
                    .password(passwordEncoder.encode("SecretPass123!"))
                    .stageName(stageName)
                    .role(role)
                    .verificationBadge(badge)
                    .nidaNumber(nida)
                    .build();
            User saved = userRepository.save(user);

            // Give seller initial pocket fund balance
            walletRepository.save(Wallet.builder()
                    .user(saved)
                    .balance(new BigDecimal("150000.00"))
                    .lockedEscrowBalance(BigDecimal.ZERO)
                    .build());

            return saved;
        });
    }
}
