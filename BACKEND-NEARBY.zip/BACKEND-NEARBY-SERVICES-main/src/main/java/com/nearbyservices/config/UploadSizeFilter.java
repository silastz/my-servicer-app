package com.nearbyservices.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * The server-wide multipart limit has to fit the biggest upload (a 100 MB video), which would
 * let every other endpoint accept 100 MB too. This filter turns away oversized multipart
 * requests by their Content-Length, before the body is read, with a limit that fits the endpoint.
 * The exact per-file checks stay in FileStorageService.
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE + 10)
public class UploadSizeFilter extends OncePerRequestFilter {

    private static final long MB = 1024L * 1024L;
    /** Photos (10 MB), ID papers, payment proofs, profile pictures: one file plus form overhead. */
    private static final long DEFAULT_LIMIT = 12 * MB;
    /** Chat voice notes and documents (25 MB file). */
    private static final long CHAT_FILE_LIMIT = 27 * MB;
    /** Service videos (100 MB file). */
    private static final long VIDEO_LIMIT = 105 * MB;

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String type = request.getContentType();
        return !"POST".equalsIgnoreCase(request.getMethod()) && !"PUT".equalsIgnoreCase(request.getMethod())
                || type == null || !type.toLowerCase().startsWith("multipart/");
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        long length = request.getContentLengthLong();
        if (length > limitFor(request.getRequestURI())) {
            response.setStatus(413);
            response.setContentType("application/json");
            response.setCharacterEncoding(StandardCharsets.UTF_8.name());
            response.getWriter().write("{\"status\":413,\"message\":\"FILE_TOO_LARGE\"}");
            return;
        }
        chain.doFilter(request, response);
    }

    static long limitFor(String path) {
        if (path == null) return DEFAULT_LIMIT;
        if (path.endsWith("/services/videos") || path.endsWith("/portfolio/videos")) return VIDEO_LIMIT;
        if (path.endsWith("/chats/files")) return CHAT_FILE_LIMIT;
        return DEFAULT_LIMIT;
    }
}
