package com.nearbyservices.config;

import com.nearbyservices.service.PaymentSettingsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.util.Locale;

/**
 * Makes sure nobody runs production on the fake payment gateway by accident.
 *
 * - SANDBOX active: a loud warning at every start (no real money moves).
 * - SNIPPE active but its API key / webhook secret missing: a loud warning (every payment would fail).
 * - REQUIRE_LIVE_PAYMENTS=true (set this in production): the server refuses to start in either case.
 */
@Component
public class PaymentStartupCheck {

    private static final Logger log = LoggerFactory.getLogger(PaymentStartupCheck.class);

    private final PaymentSettingsService settings;

    @Value("${payments.require-live:false}")
    private boolean requireLive;
    @Value("${payments.snippe.api-key:}")
    private String snippeKey;
    @Value("${payments.snippe.webhook-secret:}")
    private String snippeWebhookSecret;

    public PaymentStartupCheck(PaymentSettingsService settings) {
        this.settings = settings;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void check() {
        String gateway = settings.activeGatewayId().toUpperCase(Locale.ROOT);
        String problem = null;
        if ("SANDBOX".equals(gateway)) {
            problem = "Payment gateway is SANDBOX: no real money moves and payments stay PENDING until an admin marks them. "
                    + "Set PAYMENTS_GATEWAY=SNIPPE (plus SNIPPE_API_KEY and SNIPPE_WEBHOOK_SECRET) for real payments.";
        } else if ("SNIPPE".equals(gateway) && (blank(snippeKey) || blank(snippeWebhookSecret))) {
            problem = "Payment gateway is SNIPPE but SNIPPE_API_KEY and/or SNIPPE_WEBHOOK_SECRET is empty: every payment would fail "
                    + "and confirmations from Snippe would be rejected.";
        }
        if (problem == null) {
            log.info("Payments: live gateway {} configured.", gateway);
            return;
        }
        if (requireLive) {
            throw new IllegalStateException("REQUIRE_LIVE_PAYMENTS is on. " + problem);
        }
        log.warn("=================================================================");
        log.warn("PAYMENTS NOT LIVE: {}", problem);
        log.warn("=================================================================");
    }

    private static boolean blank(String s) {
        return s == null || s.isBlank();
    }
}
