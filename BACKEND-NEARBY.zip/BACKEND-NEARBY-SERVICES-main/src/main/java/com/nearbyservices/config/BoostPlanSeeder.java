package com.nearbyservices.config;

import com.nearbyservices.model.BoostPlan;
import com.nearbyservices.repository.BoostPlanRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

/** Puts the starting boost packages in an empty table. After that the table (not this class) is the price list. */
@Component
@RequiredArgsConstructor
@Slf4j
public class BoostPlanSeeder implements CommandLineRunner {

    private final BoostPlanRepository boostPlanRepository;

    @Override
    public void run(String... args) {
        try {
            if (boostPlanRepository.count() > 0) return;
            boostPlanRepository.saveAll(List.of(
                    BoostPlan.builder().id("boost_1d").days(1).price(2000).build(),
                    BoostPlan.builder().id("boost_3d").days(3).price(5000).build(),
                    BoostPlan.builder().id("boost_7d").days(7).price(10000).build()));
            log.info("Seeded the default boost plans.");
        } catch (Exception e) {
            log.warn("Could not seed boost plans: {}", e.getMessage());
        }
    }
}
