package com.nearbyservices.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

/** Turns on @Scheduled jobs (the offer expiry reminder, promo pushes). */
@Configuration
@EnableScheduling
public class SchedulingConfig {
}
