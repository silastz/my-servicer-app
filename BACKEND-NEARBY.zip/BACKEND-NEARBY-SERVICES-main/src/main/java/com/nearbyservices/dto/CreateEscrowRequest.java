package com.nearbyservices.dto;

import com.nearbyservices.model.PaymentMethod;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class CreateEscrowRequest {

    @NotNull(message = "Seller ID is required")
    private Long sellerId;

    private Long serviceId;

    @NotNull(message = "Amount is required")
    @DecimalMin(value = "0.01", message = "Amount must be at least 0.01")
    private BigDecimal amount;

    @NotNull(message = "Payment method is required")
    private PaymentMethod paymentMethod;

    private String notes;

    /** The date and time the customer picked (ISO local, e.g. 2026-10-25T10:00:00). Optional. */
    private java.time.LocalDateTime scheduledAt;

    /** Where the provider should come, when the provider travels. Optional, up to 255 characters. */
    @jakarta.validation.constraints.Size(max = 255, message = "Address is too long")
    private String customerAddress;

    /** The customer's GPS position when sending (optional; both or neither). Accuracy in metres. */
    private Double buyerLatitude;
    private Double buyerLongitude;
    private Double buyerAccuracyMeters;

    /** An AGREED price offer to book with. The server then charges the offer's agreedAmount and ignores "amount". */
    private Long offerId;

    /** HELD or DIRECT (what the buyer chose on the request form). Stored; see docs/ESCROW_PAYMENT_FLOW.md. */
    private String paymentPreference;

    /** Positions (0, 1, 2) of the service's tasks the customer picked. The server works out the price from them. */
    private java.util.List<Integer> taskIndexes;

    /** Photos the customer attached (our own /uploads/ paths or https links), at most 5. */
    private java.util.List<String> photoUrls;

    /** True = "as soon as possible"; scheduledAt is then ignored. */
    private Boolean asap;
    /** Channel hints the app sends; the server does not rely on them. */
    private String directChannel;
    private String offlineChannel;
}
