package com.nearbyservices.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.math.BigDecimal;

/** Body of POST /payments/mobile/request and /payments/card/checkout. "gateway" is ignored: the server decides. */
@Data
public class PaymentRequest {
    @NotNull(message = "amount is required")
    private BigDecimal amount;
    @NotBlank(message = "purpose is required")
    private String purpose;
    @NotBlank(message = "reference is required")
    @Size(max = 100, message = "reference is too long")
    private String reference;
    private String phone;
    private String description;
    private String gateway;
}
