package com.nearbyservices.dto;

import com.nearbyservices.model.EscrowStatus;
import com.nearbyservices.model.PaymentMethod;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EscrowTransactionResponse {
    private Long id;
    private String transactionRef;
    private PublicUserDto buyer;
    private PublicUserDto seller;
    private Long serviceId;
    private String serviceTitle;
    /** {id, title}: the My Reviews screen reads service.title. */
    private java.util.Map<String, Object> service;
    private BigDecimal amount;
    private PaymentMethod paymentMethod;
    private EscrowStatus status;
    private String notes;
    /** Same text as notes: the app's request cards read the customer's note as customerNote. */
    private String customerNote;
    /** First uploaded photo of the booked service (null when the service has none). */
    @com.fasterxml.jackson.annotation.JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
    private String serviceImage;
    /** Service duration in minutes (null = price only). */
    @com.fasterxml.jackson.annotation.JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
    private Integer durationMinutes;
    /** When the customer wants the service (local date and time). */
    @com.fasterxml.jackson.annotation.JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
    private LocalDateTime scheduledAt;
    /** customer_comes | provider_travels | both, as set on the service. */
    @com.fasterxml.jackson.annotation.JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
    private String serviceMode;
    /** The provider's public area and city; address carries the same text for older app versions. */
    @com.fasterxml.jackson.annotation.JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
    private String place;
    @com.fasterxml.jackson.annotation.JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
    private String address;
    /** The customer's own address for a provider-travels booking; only sent once the provider accepted. */
    @com.fasterxml.jackson.annotation.JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
    private String customerAddress;

    // Only present for a booking made with an agreed offer; earnings and disputes show the real numbers.
    @com.fasterxml.jackson.annotation.JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
    private Long offerId;
    @com.fasterxml.jackson.annotation.JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
    private BigDecimal listedPrice;
    @com.fasterxml.jackson.annotation.JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
    private BigDecimal agreedAmount;
    @com.fasterxml.jackson.annotation.JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
    private BigDecimal discountAmount;

    private String paymentStatus;
    private String paymentMode;
    private String paymentInstructions;
    private LocalDateTime paymentDeadline;
    private String paymentReference;
    private String paymentNote;
    private String paymentProofUrl;
    private String paymentPreference;
    private java.util.List<TaskView> tasks;
    private java.util.List<String> photoUrls;
    private Boolean asap;

    @lombok.Data
    @lombok.NoArgsConstructor
    @lombok.AllArgsConstructor
    public static class TaskView {
        private String name;
        private java.math.BigDecimal price;
    }
    private String paymentDisputeReason;

    private LocalDateTime completedAt;
    private LocalDateTime createdAt;

    // Contact details unlocked when Seller accepts the request
    private boolean contactsUnlocked;
    // The customer's number: only once the provider accepted (and the booking is paid when payment is required).
    private String buyerPhone;
    private String sellerPhone;
    private String sellerWhatsappPhone;
    private String sellerEmail;
    // Only once contacts are unlocked: whatsapp, instagram, facebook, x, tiktok, youtube (service's own, else the profile's).
    private java.util.Map<String, String> sellerSocials;
    private Double sellerLatitude;
    private Double sellerLongitude;
}
