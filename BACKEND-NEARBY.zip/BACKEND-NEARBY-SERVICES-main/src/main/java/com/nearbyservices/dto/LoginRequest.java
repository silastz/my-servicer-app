package com.nearbyservices.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class LoginRequest {

    @NotBlank(message = "Phone or email is required")
    private String login; // phone number or email

    @NotBlank(message = "Password is required")
    private String password;
}
