package com.nearbyservices.dto;

import com.nearbyservices.model.Role;
import com.nearbyservices.model.VerificationBadge;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuthResponse {
    private String token;
    private Long id;
    private String username;
    private String stageName;
    private Role role;
    private VerificationBadge verificationBadge;
    private String email;
    private boolean emailVerified;
    private String phone;
    private boolean phoneVerified;
    // Restores the profile photo on a new phone
    private String avatarUrl;
    // Restores the Hide My ID choice and the wallet currency on a new phone
    private boolean hideMyId;
    private boolean profileLocked;
    private String country;
    private String currency;
    // Sign-up step 1 only: proves the SMS code later. The server keeps nothing about the sign-up.
    private String signupChallenge;
}
