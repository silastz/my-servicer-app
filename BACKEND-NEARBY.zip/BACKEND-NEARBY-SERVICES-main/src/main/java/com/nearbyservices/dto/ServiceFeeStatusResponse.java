package com.nearbyservices.dto;

import java.math.BigDecimal;

/** Answer of GET /payments/service-fee (see SERVICE_FEE_FLOW.md in the app). */
public record ServiceFeeStatusResponse(int freeLimit, int used, int credits, BigDecimal amount, boolean needsPayment) {
}
