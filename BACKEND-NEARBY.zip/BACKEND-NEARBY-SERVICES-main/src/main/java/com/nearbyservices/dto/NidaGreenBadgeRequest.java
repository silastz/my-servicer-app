package com.nearbyservices.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class NidaGreenBadgeRequest {

    // NIDA Number: exactly 20 digits in Tanzania
    @NotBlank(message = "NIDA number is required")
    @Size(min = 20, max = 20, message = "NIDA number must be 20 digits")
    private String nidaNumber;

    // First and last name entered for private verification matching
    private String officialFirstName;
    private String officialLastName;
}
