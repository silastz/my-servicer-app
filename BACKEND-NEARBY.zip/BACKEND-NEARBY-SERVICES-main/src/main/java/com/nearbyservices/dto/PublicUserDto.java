package com.nearbyservices.dto;

import com.nearbyservices.model.VerificationBadge;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@com.fasterxml.jackson.annotation.JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
public class PublicUserDto {
    private Long id;
    // Strictly Stage Name is displayed to the public
    private String stageName;
    private VerificationBadge verificationBadge;
    @com.fasterxml.jackson.annotation.JsonProperty("is18Plus")
    private boolean adultOnly;
    // Buyers' average rating of this provider and how many reviews it comes from.
    // Only filled where it is cheap (the service page), otherwise left out of the JSON.
    @com.fasterxml.jackson.annotation.JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
    private Double rating;
    @com.fasterxml.jackson.annotation.JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
    private Integer reviewsCount;
    // Public profile; the app reads avatarUrl / coverUrl / bio from the seller JSON.
    private String avatarUrl;
    private String coverUrl;
    private String bio;
    // Only filled on the buyer of a booking (see EscrowService): Hide My ID, the server's Safe badge decision,
    // and whether the profile is still locked for the provider (until the provider accepts).
    private Boolean hideMyId;
    private Boolean safeBadge;
    private Boolean profileLocked;
    // Verified Business (gold chip + business name on the provider's page). Only true while it is VERIFIED and not lapsed.
    private Boolean businessVerified;
    private String businessName;
    // Buyer as seen by a provider, ONLY when the buyer's Hide My ID is off and the check is VERIFIED.
    private String verifiedName;
    private String verifiedPhotoUrl;
    // Provider page facts (filled by VerificationService.mapToSellerDto; the app reads them from the seller JSON).
    // "createdAt" = member since; "isOnline" = connected to the live chat socket right now.
    private java.time.LocalDateTime createdAt;
    private Integer completedJobs;
    private Integer totalBookings;
    // The buyer of a booking, as the provider's customer page shows them (EscrowService).
    private Integer completedBookings;
    private Integer reviewsGiven;
    // Earned badge keys (TOP_RATED, PROFESSIONAL, CUSTOMER_FAVORITE) from the provider's reviews.
    private java.util.List<String> badges;
    @com.fasterxml.jackson.annotation.JsonProperty("isOnline")
    private Boolean online;
    // Real NIDA name and NIDA number are NEVER exposed here!
}
