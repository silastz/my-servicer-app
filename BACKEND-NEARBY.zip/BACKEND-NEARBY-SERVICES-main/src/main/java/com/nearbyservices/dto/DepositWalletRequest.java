package com.nearbyservices.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class DepositWalletRequest {

    @NotNull(message = "Deposit amount is required")
    // The amount is informational (the PAID payment decides what is credited); the app enforces the admin top-up minimum.
    @DecimalMin(value = "0.01", message = "INVALID_AMOUNT")
    private BigDecimal amount;

    /** Reference of the PAID WALLET_TOPUP payment this call confirms. Required: money is never added without it. */
    @jakarta.validation.constraints.NotBlank(message = "Payment reference is required")
    private String reference;

    /** MOBILE_MONEY or CARD. Informational only. */
    private String method;
}
