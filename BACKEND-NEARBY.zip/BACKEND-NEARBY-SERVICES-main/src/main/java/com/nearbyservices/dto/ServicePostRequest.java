package com.nearbyservices.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

/**
 * Everything the app's publish / edit form sends to POST /services and PUT /services/{id}.
 * Unknown fields are ignored so a newer app never gets a 400 from an older server.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ServicePostRequest {

    @NotBlank(message = "Title is required")
    @Size(max = 255, message = "Title is too long")
    private String title;

    @NotBlank(message = "Description is required")
    @Size(max = 2000, message = "Description is too long (max 2000 characters)")
    private String description;

    @NotBlank(message = "Category is required")
    @Size(max = 100, message = "Category is too long")
    private String category;

    @NotNull(message = "Price is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "Price must be greater than zero")
    private BigDecimal price;

    @Size(max = 200, message = "City is too long")
    private String city;
    @Size(max = 200, message = "Region is too long")
    private String region;
    private Double latitude;
    private Double longitude;

    @Size(max = 40, message = "Phone is too long")
    private String phone;
    @Size(max = 40, message = "WhatsApp number is too long")
    private String whatsappPhone;
    @Size(max = 255, message = "Email is too long")
    private String email;

    // Social usernames (the app strips a leading @)
    @Size(max = 255) private String instagramUsername;
    @Size(max = 255) private String facebookUsername;
    @Size(max = 255) private String tiktokUsername;
    // The JSON key is "xUsername". A Java field starting with a single lowercase letter followed by a capital
    // would be mapped to the wrong key ("xusername"), so the field has a longer name and the key is forced.
    @com.fasterxml.jackson.annotation.JsonProperty("xUsername")
    @Size(max = 255) private String twitterUsername;
    @Size(max = 255) private String youtubeUsername;

    @com.fasterxml.jackson.annotation.JsonProperty("isInfoLocked")
    private Boolean isInfoLocked = false;

    @com.fasterxml.jackson.annotation.JsonProperty("is18Plus")
    private Boolean is18Plus = false;

    @Size(max = 8, message = "At most 8 photos")
    private List<String> imageUrls;
    @Size(max = 6, message = "At most 6 videos")
    private List<String> videoUrls;
    @Size(max = 1000) private String featuredImageUrl;

    // ---- Details ----
    @Size(max = 200, message = "Short description is too long (max 200 characters)")
    private String shortDescription;
    @Size(max = 500, message = "Search words are too long (max 500 characters)")
    private String otherLanguage;
    @Size(max = 200, message = "Area is too long") private String area;
    @Min(value = 0, message = "Service radius cannot be negative")
    @Max(value = 500, message = "Service radius is too large")
    private Integer serviceRadiusKm;
    private String priceType;   // FIXED | STARTING_FROM | PER_HOUR
    private String serviceMode; // customer_comes | provider_travels | both
    @Min(value = 1, message = "Duration must be at least 1 minute")
    @Max(value = 1440, message = "Duration is too long")
    private Integer durationMinutes;
    @Size(max = 7, message = "At most 7 days")
    private List<String> availableDays;
    private String availableFrom; // "HH:mm"
    private String availableTo;   // "HH:mm"
    @Size(max = 30, message = "At most 30 features")
    private List<String> features;

    // ---- Tasks (each with its own price) ----
    @Size(max = 3, message = "At most 3 tasks")
    private List<TaskInput> tasks;

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class TaskInput {
        private String name;
        private BigDecimal price;
    }

    // ---- Discount and price offers ----
    @Min(value = 1, message = "Discount must be between 1% and 90%")
    @Max(value = 90, message = "Discount must be between 1% and 90%")
    private Integer discountPercent;
    private Instant discountValidUntil; // the app sends ISO-8601 UTC, e.g. 2026-11-30T20:59:59.000Z
    private Boolean allowOffers;
    @DecimalMin(value = "0.0", message = "Minimum offer cannot be negative")
    private BigDecimal minOfferPrice;
    @DecimalMin(value = "0.0", message = "Auto-accept price cannot be negative")
    private BigDecimal autoAcceptPrice;
}
