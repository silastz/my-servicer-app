package com.nearbyservices.dto;

import com.nearbyservices.model.Role;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * Second step of sign-up: the phone code AND the sign-up form arrive together. Nothing was saved on the
 * server before this call; the account is created only if the code (checked against the challenge) is right.
 */
@Data
public class CompleteSignupRequest {

    @NotBlank
    private String phone;

    @NotBlank
    private String otp;

    /** Returned by /auth/register together with the SMS. */
    @NotBlank
    private String challenge;

    @NotBlank
    @Size(min = 4, max = 72)
    private String password;

    @NotBlank
    @Size(max = 120)
    private String stageName;

    @NotNull
    private Role role;

    @Email
    private String email;
}
