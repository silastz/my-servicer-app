package com.nearbyservices.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class WithdrawWalletRequest {

    @NotNull(message = "Withdrawal amount is required")
    // The real minimum/maximum are the admin's limits, checked in WalletService.withdraw (WITHDRAW_BELOW_MIN).
    @DecimalMin(value = "0.01", message = "INVALID_AMOUNT")
    private BigDecimal amount;

    @NotBlank(message = "Phone number for payout is required")
    private String phone;
}
