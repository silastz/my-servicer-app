package com.nearbyservices.dto;

import com.nearbyservices.model.Role;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class RegisterRequest {

    // Ignored by the server (kept so older app versions that still send it keep working).
    @Size(max = 60)
    private String username;

    @NotBlank(message = "Phone number is required")
    private String phone;

    @jakarta.validation.constraints.Email(message = "Invalid email format")
    private String email;

    @NotBlank(message = "Password is required")
    @Size(min = 4, max = 72, message = "Password must be 4 to 72 characters")
    private String password;

    // Public display name for the user / seller
    @NotBlank(message = "Stage name is required")
    private String stageName;

    @NotNull(message = "Role is required")
    private Role role;
}
