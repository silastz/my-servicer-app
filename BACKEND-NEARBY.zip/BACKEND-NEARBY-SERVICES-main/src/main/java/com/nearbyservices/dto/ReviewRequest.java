package com.nearbyservices.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class ReviewRequest {
    @NotBlank(message = "transactionRef is required")
    private String transactionRef;

    @NotNull(message = "rating is required")
    @Min(value = 1, message = "Rating must be 1 to 5")
    @Max(value = 5, message = "Rating must be 1 to 5")
    private Integer rating;

    @Size(max = 1000, message = "Comment is too long (max 1000)")
    private String comment;
}
