package com.nearbyservices.dto;

import lombok.Data;

import java.math.BigDecimal;

/** Body of PUT /api/admin/payments/provider-fees and the answer of GET and PUT. */
@Data
public class ProviderFeesDto {
    private BigDecimal collectionPercent;
    private BigDecimal vatPercent;
    private Long payoutFee;
    private Long withdrawMin;
    private Long withdrawMax;
}
