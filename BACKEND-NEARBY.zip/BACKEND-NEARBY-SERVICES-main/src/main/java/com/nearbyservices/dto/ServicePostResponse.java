package com.nearbyservices.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.List;

/**
 * What the service page, the lists and the seller's "my services" screen read.
 * Field names match what the app reads (see ApiService._mapJsonToServiceItem).
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ServicePostResponse {
    private Long id;
    private String title;
    private String description;
    private String shortDescription;
    private String otherLanguage;
    private String category;

    // "price" is always the normal price. While a discount runs the app works out the sale price
    // from discountPercent (rounded to the country's money step), so no salePrice is sent.
    private BigDecimal price;
    private Integer discountPercent;
    private Instant discountValidUntil;
    private boolean allowOffers;
    // PRIVATE: only filled when the viewer is the owner
    private BigDecimal minOfferPrice;
    private BigDecimal autoAcceptPrice;

    private String city;
    private String region;
    private String area;
    private Integer serviceRadiusKm;
    private Double latitude;
    private Double longitude;
    private Double distanceKm; // only when the caller sent lat/lng

    private String priceType;
    private String serviceMode;
    private Integer durationMinutes;
    private List<String> availableDays;
    private String availableFrom;
    private String availableTo;
    private List<String> features;

    // Up to 3 tasks, each with its own price (always sent, empty list = none)
    private List<TaskView> tasks;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class TaskView {
        private String name;
        private BigDecimal price;
    }

    // From buyers' reviews of this service (0 / 0 until the first review)
    private Double rating;
    private Integer reviewsCount;

    private PublicUserDto seller;
    private boolean active;

    // Only sent while the boost is running (ISO-8601); the app shows "Boosted" while it is in the future.
    private Instant boostedUntil;

    // Contact locking: when locked, the public sees none of these until a request is accepted.
    // (The app reads the JSON key "isInfoLocked"; a Lombok boolean field called isInfoLocked would
    //  have been written as "infoLocked", so the field is renamed and the key is forced.)
    @JsonProperty("isInfoLocked")
    private boolean infoLocked;
    private boolean contactsVisible;
    private String phone;
    private String whatsappPhone;
    private String email;
    private String instagramUsername;
    private String facebookUsername;
    private String tiktokUsername;
    @JsonProperty("xUsername")
    private String twitterUsername;
    private String youtubeUsername;

    // Same reason: the app reads "is18Plus".
    @JsonProperty("is18Plus")
    private boolean adultOnly;
    private List<String> imageUrls;
    private List<String> videoUrls;
    private String featuredImageUrl;

    private LocalDateTime createdAt;
}
