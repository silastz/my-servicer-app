package com.nearbyservices.dto;

import lombok.Data;

@Data
public class NidaBlueTickRequest {

    // Option A: Provide ID Card Document URL and Selfie with ID
    private String nidaNumber;
    private String idPhotoUrl;
    private String selfieWithIdUrl;

    // Option B: Invited by an existing Blue Tick verified member
    private Long inviterUserId;
}
