package com.nearbyservices.dto;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/** Matches what the app reads: {id, type, amount, status, title, reference, createdAt, direction}. */
@Data
@Builder
public class WalletTransactionResponse {
    private Long id;
    private String type;
    private BigDecimal amount;
    private String status;
    private String title;
    private String reference;
    private LocalDateTime createdAt;
    private String direction;
    /** Withdrawals: collection fee + fee in one amount, and what reached the provider. The payout / VAT split is never sent. */
    @com.fasterxml.jackson.annotation.JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
    private Long fee;
    @com.fasterxml.jackson.annotation.JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
    private Long netAmount;
}
