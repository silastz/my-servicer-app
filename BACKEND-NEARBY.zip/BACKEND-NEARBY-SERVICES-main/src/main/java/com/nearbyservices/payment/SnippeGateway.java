package com.nearbyservices.payment;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.Payment;
import com.nearbyservices.model.PaymentStatus;
import com.nearbyservices.model.User;
import com.nearbyservices.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.Locale;
import java.util.Optional;

/**
 * Snippe (https://docs.snippe.sh, API version 2026-01-25): mobile-money collection with a USSD push.
 * Needs SNIPPE_API_KEY (Bearer key, scope collection:create + collection:read) and SNIPPE_WEBHOOK_SECRET
 * (the account's signing key, "whsec_..."). Without the API key every call answers 503 PAYMENT_GATEWAY_NOT_CONFIGURED.
 *
 * Card checkout is not offered: Snippe's documented API only creates "mobile" payments with an API key
 * (hosted sessions need a merchant login token), so {@link #createCheckout} answers 503 CARD_NOT_SUPPORTED.
 */
@Component
public class SnippeGateway implements PaymentGateway {

    private static final Logger log = LoggerFactory.getLogger(SnippeGateway.class);

    static final String ID = "SNIPPE";
    static final long MIN_AMOUNT = 500;
    static final long MAX_WEBHOOK_AGE_SECONDS = 300;

    private final String apiKey;
    private final String webhookSecret;
    private final String baseUrl;
    private final String webhookUrl;
    private final String fallbackEmail;
    private final com.nearbyservices.service.AdminSettingsService adminSettings;
    private final UserRepository userRepository;
    private final HttpClient http;

    public SnippeGateway(@Value("${payments.snippe.api-key:}") String apiKey,
                         @Value("${payments.snippe.webhook-secret:}") String webhookSecret,
                         @Value("${payments.snippe.base-url:https://api.snippe.sh}") String baseUrl,
                         @Value("${payments.snippe.fallback-email:no-reply@example.com}") String fallbackEmail,
                         @Value("${payments.public-base-url:http://localhost:3010}") String publicBaseUrl,
                         UserRepository userRepository,
                         com.nearbyservices.service.AdminSettingsService adminSettings) {
        this.apiKey = apiKey == null ? "" : apiKey.trim();
        this.webhookSecret = webhookSecret == null ? "" : webhookSecret.trim();
        this.baseUrl = baseUrl.replaceAll("/+$", "");
        this.webhookUrl = publicBaseUrl.replaceAll("/+$", "") + "/api/payments/webhook/snippe";
        this.fallbackEmail = fallbackEmail;
        this.adminSettings = adminSettings;
        this.userRepository = userRepository;
        this.http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5))
                .followRedirects(HttpClient.Redirect.NEVER).build();
    }

    /** For a payer with no email: what the admin set, else PAYMENTS_FALLBACK_EMAIL / SNIPPE_FALLBACK_EMAIL. */
    private String fallbackEmail() {
        String admin = adminSettings.getSettings().getPaymentFallbackEmail();
        return notBlank(admin) ? admin.trim() : fallbackEmail;
    }

    @Override
    public String id() {
        return ID;
    }

    // ---------------------------------------------------------------- money in

    @Override
    public String requestMobile(Payment payment) {
        requireKey();
        long amount = wholeTzs(payment.getAmount());
        if (amount < MIN_AMOUNT) throw ApiException.badRequest("AMOUNT_BELOW_GATEWAY_MIN");
        String phone = normalisePhone(payment.getPhone());
        if (phone == null) throw ApiException.badRequest("INVALID_PHONE");

        User u = userRepository.findById(payment.getUserId()).orElse(null);
        String[] name = splitName(u == null ? null : (notBlank(u.getStageName()) ? u.getStageName() : u.getUsername()));
        String email = u != null && notBlank(u.getEmail()) ? u.getEmail().trim() : fallbackEmail();

        String body = "{\"payment_type\":\"mobile\""
                + ",\"details\":{\"amount\":" + amount + ",\"currency\":\"TZS\"}"
                + ",\"phone_number\":" + MiniJson.quote(phone)
                + ",\"customer\":{\"firstname\":" + MiniJson.quote(name[0])
                + ",\"lastname\":" + MiniJson.quote(name[1])
                + ",\"email\":" + MiniJson.quote(email) + "}"
                + ",\"webhook_url\":" + MiniJson.quote(webhookUrl)
                + ",\"metadata\":{\"reference\":" + MiniJson.quote(payment.getReference())
                + ",\"purpose\":" + MiniJson.quote(payment.getPurpose().name()) + "}}";

        Object res = call(HttpRequest.newBuilder(URI.create(baseUrl + "/v1/payments"))
                .header("Idempotency-Key", idempotencyKey(payment.getReference()))
                .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8)), "create");
        String ref = MiniJson.str(res, "data", "reference");
        if (ref == null || ref.isBlank()) {
            log.error("Snippe create payment answered without a reference for {}", payment.getReference());
            throw ApiException.unavailable("PAYMENT_GATEWAY_ERROR");
        }
        return ref;
    }

    @Override
    public Checkout createCheckout(Payment payment, String description) {
        throw ApiException.unavailable("CARD_NOT_SUPPORTED");
    }

    @Override
    public Optional<PaymentStatus> queryStatus(Payment payment) {
        if (apiKey.isEmpty() || payment.getGatewayReference() == null || payment.getGatewayReference().isBlank()) {
            return Optional.empty();
        }
        String ref = payment.getGatewayReference().replaceAll("[^A-Za-z0-9_.:-]", "");
        Object res = call(HttpRequest.newBuilder(URI.create(baseUrl + "/v1/payments/" + ref)).GET(), "status");
        return Optional.ofNullable(mapStatus(MiniJson.str(res, "data", "status")));
    }

    // ---------------------------------------------------------------- webhook

    /** What a verified payment webhook says. {@code reference} is ours (from metadata), {@code gatewayReference} is Snippe's. */
    public record Event(String type, String reference, String gatewayReference, PaymentStatus status, BigDecimal amount) {}

    /**
     * Checks the signature and age, then reads the event. Returns empty for events that are not about a
     * payment we track (payouts, unknown types). Throws SecurityException when the request is not from Snippe.
     */
    public Optional<Event> verifyWebhook(String rawBody, String timestamp, String signature) {
        if (webhookSecret.isEmpty()) throw new SecurityException("webhook secret not set");
        if (!signatureValid(rawBody, timestamp, signature, webhookSecret, System.currentTimeMillis() / 1000)) {
            throw new SecurityException("bad signature");
        }
        Object root;
        try {
            root = MiniJson.parse(rawBody);
        } catch (IllegalArgumentException e) {
            throw new SecurityException("unreadable body");
        }
        String type = MiniJson.str(root, "type");
        if (type == null || !type.startsWith("payment.")) return Optional.empty();
        PaymentStatus status = mapStatus(MiniJson.str(root, "data", "status"));
        String ourRef = MiniJson.str(root, "data", "metadata", "reference");
        if (status == null || ourRef == null) return Optional.empty();
        Long value = MiniJson.whole(root, "data", "amount", "value");
        return Optional.of(new Event(type, ourRef, MiniJson.str(root, "data", "reference"), status,
                value == null ? null : BigDecimal.valueOf(value)));
    }

    /** hex(HMAC-SHA256(key, "{timestamp}.{rawBody}")), compared in constant time, and not older than 5 minutes. */
    static boolean signatureValid(String rawBody, String timestamp, String signature, String key, long nowSeconds) {
        if (rawBody == null || timestamp == null || signature == null) return false;
        long ts;
        try {
            ts = Long.parseLong(timestamp.trim());
        } catch (NumberFormatException e) {
            return false;
        }
        if (Math.abs(nowSeconds - ts) > MAX_WEBHOOK_AGE_SECONDS) return false;
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            byte[] sum = mac.doFinal((timestamp.trim() + "." + rawBody).getBytes(StandardCharsets.UTF_8));
            String expected = hex(sum);
            return MessageDigest.isEqual(expected.getBytes(StandardCharsets.UTF_8),
                    signature.trim().toLowerCase(Locale.ROOT).getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            return false;
        }
    }

    // ---------------------------------------------------------------- helpers

    /** completed -> PAID, failed -> FAILED, voided / expired -> CANCELLED, pending -> PENDING, anything else unknown. */
    static PaymentStatus mapStatus(String s) {
        if (s == null) return null;
        return switch (s.trim().toLowerCase(Locale.ROOT)) {
            case "completed" -> PaymentStatus.PAID;
            case "failed" -> PaymentStatus.FAILED;
            case "voided", "expired" -> PaymentStatus.CANCELLED;
            case "pending" -> PaymentStatus.PENDING;
            default -> null;
        };
    }

    /** 0712345678, +255712345678 and 255712345678 all become 255712345678; anything else is null. */
    static String normalisePhone(String raw) {
        if (raw == null) return null;
        String p = raw.replaceAll("[\\s-]", "");
        if (p.startsWith("+")) p = p.substring(1);
        if (p.startsWith("0")) p = "255" + p.substring(1);
        return p.matches("255[0-9]{9}") ? p : null;
    }

    /** Snippe rejects keys over 30 characters, so the payment reference (up to 100) is hashed: same payment, same key. */
    static String idempotencyKey(String reference) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(reference.getBytes(StandardCharsets.UTF_8));
            return "np-" + hex(d).substring(0, 26);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    static String[] splitName(String full) {
        String n = full == null ? "" : full.trim().replaceAll("\\s+", " ");
        if (n.isEmpty()) return new String[]{"Customer", "Ungana"};
        int sp = n.indexOf(' ');
        if (sp < 0) return new String[]{n, "-"};
        return new String[]{n.substring(0, sp), n.substring(sp + 1)};
    }

    private static long wholeTzs(BigDecimal a) {
        return a.setScale(0, RoundingMode.HALF_UP).longValueExact();
    }

    private static boolean notBlank(String s) {
        return s != null && !s.isBlank();
    }

    private static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    private void requireKey() {
        if (apiKey.isEmpty()) throw ApiException.unavailable("PAYMENT_GATEWAY_NOT_CONFIGURED");
    }

    /** Sends the call and returns the parsed body; maps Snippe's failures to our own error codes. */
    private Object call(HttpRequest.Builder b, String what) {
        requireKey();
        HttpResponse<String> r;
        try {
            r = http.send(b.timeout(Duration.ofSeconds(20))
                    .header("Authorization", "Bearer " + apiKey)
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .header("Snippe-Version", "2026-01-25").build(), HttpResponse.BodyHandlers.ofString());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw ApiException.unavailable("PAYMENT_GATEWAY_ERROR");
        } catch (Exception e) {
            log.warn("Snippe {} call failed: {}", what, e.getMessage());
            throw ApiException.unavailable("PAYMENT_GATEWAY_ERROR");
        }
        int code = r.statusCode();
        if (code >= 200 && code < 300) {
            try {
                return MiniJson.parse(r.body());
            } catch (IllegalArgumentException e) {
                log.error("Snippe {} answered {} with an unreadable body", what, code);
                throw ApiException.unavailable("PAYMENT_GATEWAY_ERROR");
            }
        }
        String msg = "";
        try {
            msg = String.valueOf(MiniJson.str(MiniJson.parse(r.body()), "message"));
        } catch (RuntimeException ignored) {
            // body was not JSON; the status code is enough
        }
        log.warn("Snippe {} answered {}: {}", what, code, msg);
        if (code == 401 || code == 403) throw ApiException.unavailable("PAYMENT_GATEWAY_NOT_CONFIGURED");
        if (code == 429) throw ApiException.tooManyRequests("PAYMENT_GATEWAY_BUSY");
        if (code == 400 || code == 422) throw ApiException.badRequest("PAYMENT_REJECTED");
        throw ApiException.unavailable("PAYMENT_GATEWAY_ERROR");
    }
}
