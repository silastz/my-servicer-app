package com.nearbyservices.payment;

import com.nearbyservices.model.Payment;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Test gateway: sends nothing and charges nothing. Payments stay PENDING until an admin marks them
 * (POST /api/admin/payments/{reference}/status) or the webhook reports them. NOT for production money.
 */
@Component
public class SandboxPaymentGateway implements PaymentGateway {

    private final String publicBaseUrl;

    public SandboxPaymentGateway(@Value("${payments.public-base-url:http://localhost:3010}") String publicBaseUrl) {
        this.publicBaseUrl = publicBaseUrl.replaceAll("/+$", "");
    }

    @Override
    public String id() {
        return "SANDBOX";
    }

    @Override
    public String requestMobile(Payment payment) {
        return "SBX-" + payment.getReference();
    }

    @Override
    public Checkout createCheckout(Payment payment, String description) {
        return new Checkout("SBX-" + payment.getReference(),
                publicBaseUrl + "/api/payments/sandbox/checkout/" + payment.getReference());
    }
}
