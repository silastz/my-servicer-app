package com.nearbyservices.payment;

import com.nearbyservices.model.Payment;
import com.nearbyservices.model.PaymentStatus;

import java.util.Optional;

/**
 * A payment provider (Snippe, DPO, Selcom, ClickPesa, Pesapal...). One implementation per provider;
 * the active one is chosen with payments.gateway. Add a provider by implementing this interface.
 */
public interface PaymentGateway {

    /** Matches payments.gateway, upper case (e.g. "SANDBOX", "SNIPPE"). */
    String id();

    /** Sends the mobile-money prompt to payment.getPhone(). Returns the gateway's own reference. */
    String requestMobile(Payment payment);

    /** Creates a hosted card checkout page. */
    Checkout createCheckout(Payment payment, String description);

    /** Asks the gateway for the current status, when it can be asked. Empty = unknown, wait for the webhook. */
    default Optional<PaymentStatus> queryStatus(Payment payment) {
        return Optional.empty();
    }

    record Checkout(String gatewayReference, String checkoutUrl) {}
}
