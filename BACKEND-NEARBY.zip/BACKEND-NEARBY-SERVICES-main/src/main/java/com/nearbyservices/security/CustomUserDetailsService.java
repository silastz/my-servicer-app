package com.nearbyservices.security;

import com.nearbyservices.model.User;
import com.nearbyservices.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CustomUserDetailsService implements UserDetailsService {

    private final UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String identifier) throws UsernameNotFoundException {
        // Login only: the identifier is an email or a phone number (the username is never used to sign in).
        if (identifier == null || identifier.isBlank()) {
            throw new UsernameNotFoundException("Empty identifier provided");
        }
        String trimmed = identifier.trim();
        String normalizedPhone = com.nearbyservices.service.SmsService.normalizePhoneNumber(trimmed);

        User user = userRepository.findByEmail(trimmed.toLowerCase())
                .or(() -> userRepository.findByPhone(trimmed))
                .or(() -> userRepository.findByPhone(normalizedPhone))
                .orElseThrow(() -> new UsernameNotFoundException("User not found with identifier: " + identifier));

        return new CustomUserDetails(user);
    }

    /** Used for tokens: the token subject is the numeric user id. Anything else is rejected. */
    public UserDetails loadUserById(String subject) throws UsernameNotFoundException {
        long id;
        try {
            id = Long.parseLong(subject == null ? "" : subject.trim());
        } catch (NumberFormatException e) {
            throw new UsernameNotFoundException("Invalid token subject");
        }
        User user = userRepository.findById(id)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
        return new CustomUserDetails(user);
    }
}
