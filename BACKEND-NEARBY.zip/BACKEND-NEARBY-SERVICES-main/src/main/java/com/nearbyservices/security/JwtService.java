package com.nearbyservices.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

@Component
public class JwtService {

    @Value("${security.jwt.secret:404E635266556A586E3272357538782F413F4428472B4B6250645367566B5970}")
    private String secretKey;

    // A login lasts a year and is renewed while the person uses the app, so nobody is signed out
    // just because time passed. Deleted, suspended and password-reset accounts are still refused at once.
    @Value("${security.jwt.expiration-ms:31536000000}")
    private long jwtExpiration;

    /** A token older than this is swapped for a fresh one on the next request (sliding login). */
    @Value("${security.jwt.renew-after-ms:604800000}")
    private long renewAfter;

    public String extractUsername(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    public String generateToken(UserDetails userDetails, Map<String, Object> extraClaims) {
        return buildToken(extraClaims, userDetails, jwtExpiration);
    }

    public String generateToken(UserDetails userDetails) {
        return generateToken(userDetails, new HashMap<>());
    }

    private String buildToken(Map<String, Object> extraClaims, UserDetails userDetails, long expiration) {
        return Jwts.builder()
                .claims(extraClaims)
                .subject(userDetails.getUsername())
                .issuedAt(new Date(System.currentTimeMillis()))
                .expiration(new Date(System.currentTimeMillis() + expiration))
                .signWith(getSignInKey())
                .compact();
    }

    /**
     * A fresh token with the same claims when [token] is older than the renew window, otherwise null.
     * Only call this for a token that already passed [isTokenValid]. The app keeps the new token, so an
     * active user never reaches the expiry date.
     */
    public String renewedIfDue(String token, UserDetails userDetails) {
        Claims claims = extractAllClaims(token);
        Date issuedAt = claims.getIssuedAt();
        if (issuedAt == null || System.currentTimeMillis() - issuedAt.getTime() < renewAfter) return null;
        Map<String, Object> extra = new HashMap<>(claims);
        for (String standard : new String[]{Claims.SUBJECT, Claims.ISSUED_AT, Claims.EXPIRATION, Claims.NOT_BEFORE,
                Claims.ID, Claims.ISSUER, Claims.AUDIENCE}) {
            extra.remove(standard);
        }
        return buildToken(extra, userDetails, jwtExpiration);
    }

    public boolean isTokenValid(String token, UserDetails userDetails) {
        final String username = extractUsername(token);
        if (!username.equals(userDetails.getUsername()) || isTokenExpired(token)) return false;
        // A deleted account can never sign in again, even with a token issued before the deletion.
        if (userDetails instanceof CustomUserDetails gone && gone.getUser().getDeletedAt() != null) return false;
        // A suspended account is locked out at once, even with a token issued before the suspension.
        if (userDetails instanceof CustomUserDetails held && held.getUser().isSuspended()) return false;
        // Phone code first: a login issued to an account whose phone was never confirmed is refused
        // (the HTTP filter and the chat WebSocket both check tokens here).
        if (userDetails instanceof CustomUserDetails unverified && !unverified.getUser().isPhoneVerified()) return false;
        // A password reset ends every login that was issued before it.
        if (userDetails instanceof CustomUserDetails cud && cud.getUser().getTokensValidFrom() != null) {
            Date issuedAt = extractClaim(token, Claims::getIssuedAt);
            long validFromSec = cud.getUser().getTokensValidFrom().getEpochSecond();
            if (issuedAt == null || issuedAt.getTime() / 1000 < validFromSec) return false;
        }
        return true;
    }

    private boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    private Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }

    private Claims extractAllClaims(String token) {
        return Jwts.parser()
                .verifyWith(getSignInKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    private SecretKey getSignInKey() {
        byte[] keyBytes = Decoders.BASE64.decode(secretKey);
        return Keys.hmacShaKeyFor(keyBytes);
    }
}
