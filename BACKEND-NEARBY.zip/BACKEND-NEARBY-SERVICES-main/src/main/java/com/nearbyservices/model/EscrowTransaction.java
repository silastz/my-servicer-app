package com.nearbyservices.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "escrow_transactions")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EscrowTransaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String transactionRef;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "buyer_id", nullable = false)
    private User buyer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "seller_id", nullable = false)
    private User seller;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "service_id")
    private ServicePost service;

    @Column(nullable = false, precision = 15, scale = 2)
    private BigDecimal amount;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private PaymentMethod paymentMethod;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private EscrowStatus status = EscrowStatus.FUNDED;

    private String notes;

    /** When the customer wants the service (local date and time, as picked on the request form). Null on older bookings. */
    private LocalDateTime scheduledAt;

    /** Where the customer wants the provider to come (typed by the customer). Shown to the provider only after acceptance. */
    @Column(length = 255)
    private String customerAddress;

    /**
     * The customer's phone position when the request was sent (a safety record for disputes and scam reports).
     * Stored with the time the server received it. It is never sent to the provider or the app; only admins can read it (AdminBookingEvidenceController).
     */
    private Double buyerLatitude;
    private Double buyerLongitude;
    private Double buyerLocationAccuracyM;
    private LocalDateTime buyerLocationCapturedAt;

    /** Copied from the service at booking time: customer_comes | provider_travels | both. Null when the provider didn't say. */
    @Column(length = 20)
    private String serviceMode;

    /** Where the service happens: the provider's own public area and city. Null when the provider gave none. */
    @Column(length = 255)
    private String place;

    // Set when the booking was made with an agreed price offer (see OfferService); null otherwise.
    private Long offerId;

    @Column(precision = 15, scale = 2)
    private BigDecimal listedPrice;

    @Column(precision = 15, scale = 2)
    private BigDecimal discountAmount;

    // Payment state (docs/ESCROW_PAYMENT_FLOW.md). paymentStatus: UNPAID or PAID; null on older bookings.
    @Column(length = 20)
    private String paymentStatus;
    @Column(length = 10)
    private String paymentMode;          // ONLINE (paid in the app) or OFFLINE (paid to the provider directly)
    @Column(length = 500)
    private String paymentInstructions;
    private LocalDateTime paymentDeadline;
    @Column(length = 100)
    private String paymentReference;
    @Column(length = 500)
    private String paymentNote;
    @Column(length = 300)
    private String paymentProofUrl;
    @Column(length = 10)
    private String paymentPreference;    // HELD or DIRECT, as the buyer chose on the request form
    @Column(length = 300)
    private String paymentDisputeReason;

    // Tasks the customer picked (copied from the service at request time) and the photos they attached.
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "escrow_tasks", joinColumns = @JoinColumn(name = "escrow_id"))
    @OrderColumn(name = "sort_order")
    @Builder.Default
    private java.util.List<ServiceTask> tasks = new java.util.ArrayList<>();

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "escrow_photos", joinColumns = @JoinColumn(name = "escrow_id"))
    @OrderColumn(name = "sort_order")
    @Column(name = "photo_url", length = 1000)
    @Builder.Default
    private java.util.List<String> photoUrls = new java.util.ArrayList<>();

    // "As soon as possible": the customer wants it now instead of a fixed date and time.
    private Boolean asap;
    private LocalDateTime paidAt;

    private LocalDateTime completedAt;

    // When the provider first accepted. Contacts stay unlocked from then on even if the booking later moves to
    // DISPUTED (the two people must still be able to reach each other). Null on bookings made before this field existed.
    private LocalDateTime acceptedAt;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
