package com.nearbyservices.model;

/** What a payment is for. The names are exactly what the app sends in "purpose". */
public enum PaymentPurpose {
    PROVIDER_REGISTRATION, SERVICE_FEE, WALLET_TOPUP, SERVICE_BOOST, BOOKING
}
