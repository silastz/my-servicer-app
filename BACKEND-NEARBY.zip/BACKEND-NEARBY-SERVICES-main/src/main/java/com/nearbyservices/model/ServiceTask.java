package com.nearbyservices.model;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * One task a provider offers inside a service, with its own price (up to 3 per service).
 * The same shape is copied onto a booking when the customer picks tasks, so the price the
 * customer agreed to never changes if the provider edits the service later.
 */
@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ServiceTask {
    @Column(name = "task_name", length = 100)
    private String name;

    @Column(name = "task_price", precision = 15, scale = 2)
    private BigDecimal price;
}
