package com.nearbyservices.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

/** One person's rating of the other side of one completed booking. At most one per (booking, reviewer). */
@Entity
@Table(name = "reviews", uniqueConstraints = @UniqueConstraint(columnNames = {"transaction_ref", "reviewer_id"}))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "transaction_ref", nullable = false)
    private String transactionRef;

    @Column(name = "reviewer_id", nullable = false)
    private Long reviewerId;

    @Column(name = "reviewee_id", nullable = false)
    private Long revieweeId;

    @Column(name = "service_id")
    private Long serviceId;

    /** True when the buyer rated the provider. Only these count toward service / provider ratings. */
    @Column(name = "from_buyer", nullable = false)
    private boolean fromBuyer;

    @Column(nullable = false)
    private int rating;

    @Column(length = 1000)
    private String comment;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;
}
