package com.nearbyservices.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

/** userId has muted mutedUserId: messages still arrive, but no push notification is sent. At most one row per pair. */
@Entity
@Table(name = "chat_mutes", uniqueConstraints = @UniqueConstraint(columnNames = {"user_id", "muted_user_id"}))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ChatMute {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "muted_user_id", nullable = false)
    private Long mutedUserId;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;
}
