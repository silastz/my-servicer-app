package com.nearbyservices.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

/**
 * One photo or video a provider put in their own portfolio. This is separate from the pictures
 * attached to a service: it belongs to the person and shows on their profile.
 */
@Entity
@Table(name = "portfolio_items", indexes = @Index(name = "idx_portfolio_owner", columnList = "owner_id, created_at"))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PortfolioItem {

    public enum Type { IMAGE, VIDEO }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "owner_id", nullable = false)
    private Long ownerId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Type type;

    /** Public path, e.g. /uploads/portfolio/images/<uuid>.jpg */
    @Column(nullable = false, length = 300)
    private String url;

    @Column(length = 140)
    private String caption;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @PrePersist
    void onCreate() {
        if (createdAt == null) createdAt = LocalDateTime.now();
    }
}
