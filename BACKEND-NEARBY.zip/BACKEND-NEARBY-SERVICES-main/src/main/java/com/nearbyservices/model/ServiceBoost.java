package com.nearbyservices.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.Instant;
import java.time.LocalDateTime;

/**
 * One purchased boost. The unique reference is the idempotency key: repeating the same activation
 * returns this row instead of adding days again. (Pocket-fund references are stored as
 * POCKET:{userId}:{reference} so nobody can use them to block another user's payment reference.)
 */
@Entity
@Table(name = "service_boosts")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ServiceBoost {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long serviceId;

    @Column(nullable = false)
    private Long userId;

    @Column(nullable = false, length = 50)
    private String planId;

    @Column(nullable = false)
    private int days;

    /** What was charged, in whole shillings (copied from the plan at purchase time). */
    @Column(nullable = false)
    private long price;

    /** MOBILE_MONEY, CARD or POCKET_FUND */
    @Column(nullable = false, length = 20)
    private String paymentMethod;

    @Column(nullable = false, unique = true, length = 160)
    private String reference;

    @Column(nullable = false)
    private Instant startsAt;

    @Column(nullable = false)
    private Instant endsAt;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;
}
