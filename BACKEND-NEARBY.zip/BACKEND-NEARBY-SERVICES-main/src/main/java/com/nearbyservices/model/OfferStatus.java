package com.nearbyservices.model;

/** OFFERED -> AGREED -> BOOKED is the happy path; the others end an offer early. */
public enum OfferStatus {
    OFFERED, AGREED, REJECTED, WITHDRAWN, EXPIRED, BOOKED
}
