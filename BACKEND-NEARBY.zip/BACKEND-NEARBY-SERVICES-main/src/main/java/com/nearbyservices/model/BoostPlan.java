package com.nearbyservices.model;

import jakarta.persistence.*;
import lombok.*;

/** One boost package a provider can buy (e.g. 3 days for TSh 5,000). The server's table is the only price list. */
@Entity
@Table(name = "boost_plans")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BoostPlan {

    /** The id the app sends back as "planId", e.g. boost_3d. */
    @Id
    @Column(length = 50)
    private String id;

    @Column(nullable = false)
    private int days;

    /** Whole Tanzanian shillings. */
    @Column(nullable = false)
    private long price;

    @Column(nullable = false)
    @Builder.Default
    private boolean active = true;
}
