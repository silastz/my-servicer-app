package com.nearbyservices.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "admin_settings")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AdminSettings {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // One-time seller registration / listing fee (e.g. 10000 TSh)
    @Column(nullable = false, precision = 15, scale = 2)
    @Builder.Default
    private BigDecimal sellerRegistrationFee = new BigDecimal("10000.00");

    // Quota of free services a seller can post initially
    @Column(nullable = false)
    @Builder.Default
    private int freeServicesQuota = 2;

    // Number of combined package services included
    @Column(nullable = false)
    @Builder.Default
    private int combinedPackageCount = 2;

    // Price for service package bundle
    @Column(nullable = false, precision = 15, scale = 2)
    @Builder.Default
    private BigDecimal packagePrice = new BigDecimal("15000.00");

    // Fee for each service posted after the free quota (one paid fee = one extra service)
    @Column(nullable = false, precision = 15, scale = 2, columnDefinition = "numeric(15,2) default 5000")
    @Builder.Default
    private BigDecimal serviceFee = new BigDecimal("5000.00");

    /** Gateway the admin switched on (SANDBOX, SNIPPE...). Null = use payments.gateway from application.yaml. */
    @Column(length = 30)
    private String paymentGateway;

    // ---- Provider fees (see PROVIDER_FEES_FLOW.md). All start at 0: nothing is charged until the admin sets them. columnDefinition defaults keep old rows valid under ddl-auto: update.
    /** Percent taken on its own when a provider withdraws (0-20). */
    @Column(nullable = false, precision = 5, scale = 2, columnDefinition = "numeric(5,2) default 0")
    @Builder.Default
    private BigDecimal providerCollectionPercent = BigDecimal.ZERO;

    /** VAT percent (0-50). */
    @Column(nullable = false, precision = 5, scale = 2, columnDefinition = "numeric(5,2) default 0")
    @Builder.Default
    private BigDecimal providerVatPercent = BigDecimal.ZERO;

    /** Flat payout fee in whole TSh (0-1,000,000). */
    @Column(nullable = false, columnDefinition = "bigint default 0")
    @Builder.Default
    private long providerPayoutFee = 0;

    /** Lowest amount per withdrawal. 0 = default 1,000. */
    @Column(nullable = false, columnDefinition = "bigint default 0")
    @Builder.Default
    private long withdrawMin = 0;

    /** Highest amount per withdrawal. 0 = no maximum. */
    @Column(nullable = false, columnDefinition = "bigint default 0")
    @Builder.Default
    private long withdrawMax = 0;

    /** Card payments are OFF until the admin switches them on. */
    @Column(nullable = false, columnDefinition = "boolean default false")
    @Builder.Default
    private boolean cardPaymentsEnabled = false;

    /**
     * How many minutes a sent sign-up / password-reset code stays "pending" in the app: if the user closes the
     * app and comes back within this time, typing the same phone/email goes straight to the code screen
     * instead of sending a new code. 1-10 (a code itself lives 10 minutes). Default 4.
     */
    @Column(nullable = false, columnDefinition = "integer default 4")
    @Builder.Default
    private int otpPendingMinutes = 4;

    /** Boosted services are pushed to users who switched promo notifications on (see PROMO_PUSH.md). */
    @Column(nullable = false, columnDefinition = "boolean default true")
    @Builder.Default
    private boolean promoPushEnabled = true;

    /** Least hours between two promo pushes to the same user. 1-72. Default 6. */
    @Column(nullable = false, columnDefinition = "integer default 6")
    @Builder.Default
    private int promoPushIntervalHours = 6;

    /** Support contacts the app's Help screen shows. Null / empty = not set, and the app hides that contact. */
    @Column(length = 40)
    private String supportPhone;
    @Column(length = 40)
    private String supportWhatsapp;
    @Column(length = 120)
    private String supportEmail;

    /** Email sent to the payment gateway for a payer who has none on their account. Null = use the PAYMENTS_FALLBACK_EMAIL default. */
    @Column(length = 120)
    private String paymentFallbackEmail;

    /** App security switches sent in /api/app/policy "security". Null = not set: the app uses its own default. */
    private Boolean screenCaptureAllowed;
    private Boolean blockCompromisedDevice;
    private Boolean playIntegrity;
    private Boolean blockVpn;

    /** Wallet top-up amount limits (TSh). Null / 0 = not set. */
    private Long topUpMin;
    private Long topUpMax;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
