package com.nearbyservices.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

/**
 * One named JSON document the admin controls and the app reads without logging in
 * (keys: "ads", "version.android", "version.ios"). Stored as the exact text that was validated.
 */
@Entity
@Table(name = "app_config")
public class AppConfigEntry {

    @Id
    @Column(name = "config_key", length = 60)
    private String key;

    @Column(name = "config_value", columnDefinition = "text", nullable = false)
    private String value;

    @Column(length = 100)
    private String updatedBy;

    @UpdateTimestamp
    private LocalDateTime updatedAt;

    public AppConfigEntry() {
    }

    public AppConfigEntry(String key, String value, String updatedBy) {
        this.key = key;
        this.value = value;
        this.updatedBy = updatedBy;
    }

    public String getKey() { return key; }
    public void setKey(String key) { this.key = key; }
    public String getValue() { return value; }
    public void setValue(String value) { this.value = value; }
    public String getUpdatedBy() { return updatedBy; }
    public void setUpdatedBy(String updatedBy) { this.updatedBy = updatedBy; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
}
