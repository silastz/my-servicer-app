package com.nearbyservices.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

/**
 * One promo push that was sent: this user was told about this boosted service at this moment.
 * It is the memory behind the "one service per user per interval" rule and behind the rotation
 * (a user is shown a service they have not seen yet before one they have).
 */
@Entity
@Table(name = "promo_push_log", indexes = {
        @Index(name = "idx_promo_push_user_sent", columnList = "user_id,sent_at"),
        @Index(name = "idx_promo_push_sent", columnList = "sent_at")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PromoPushLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "service_id", nullable = false)
    private Long serviceId;

    @Column(name = "sent_at", nullable = false)
    private Instant sentAt;
}
