package com.nearbyservices.model;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

/** An unverified person asks a verified provider to vouch for them. Nothing is granted by the request itself. */
@Entity
@Table(name = "vouch_requests", indexes = {
        @Index(name = "idx_vouch_requester", columnList = "requester_id"),
        @Index(name = "idx_vouch_provider", columnList = "provider_id")})
public class VouchRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long requesterId;

    @Column(nullable = false)
    private Long providerId;

    /** PENDING | APPROVED | DECLINED | EXPIRED */
    @Column(nullable = false, length = 12)
    private String status = "PENDING";

    @Column(nullable = false)
    private LocalDateTime expiresAt;

    @CreationTimestamp
    private LocalDateTime createdAt;

    public Long getId() { return id; }
    public Long getRequesterId() { return requesterId; }
    public void setRequesterId(Long v) { this.requesterId = v; }
    public Long getProviderId() { return providerId; }
    public void setProviderId(Long v) { this.providerId = v; }
    public String getStatus() { return status; }
    public void setStatus(String v) { this.status = v; }
    public LocalDateTime getExpiresAt() { return expiresAt; }
    public void setExpiresAt(LocalDateTime v) { this.expiresAt = v; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
