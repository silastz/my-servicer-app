package com.nearbyservices.model;

public enum EscrowStatus {
    PENDING_ACCEPTANCE, // Funds held, waiting for Seller acceptance
    ACCEPTED,           // Seller accepted the request, contacts unlocked for Buyer
    FUNDED,             // Legacy/funded state
    COMPLETED,          // Buyer satisfied, funds released to Seller
    DISPUTED,           // Conflict raised
    REFUNDED,           // Escrow refunded back to Buyer
    REJECTED,           // Seller declined request, funds automatically returned to Buyer
    CANCELLED,          // Buyer called the request off before it was accepted (money, if any, returned)
    AWAITING_PAYMENT,   // Seller asked the buyer to pay before accepting (docs/ESCROW_PAYMENT_FLOW.md)
    PAYMENT_SENT,       // Buyer says they paid directly (offline); the seller must confirm
    PAYMENT_DISPUTED    // Seller says the money did not arrive; the buyer can send it again or an admin decides
}
