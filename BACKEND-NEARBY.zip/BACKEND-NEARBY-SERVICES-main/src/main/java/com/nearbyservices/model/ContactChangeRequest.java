package com.nearbyservices.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

/** A pending change of the registered phone or email. One per (user, kind); a new request replaces the old one. */
@Entity
@Table(name = "contact_change_requests", uniqueConstraints = @UniqueConstraint(columnNames = {"user_id", "kind"}))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ContactChangeRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    /** PHONE or EMAIL */
    @Column(nullable = false, length = 10)
    private String kind;

    @Column(name = "new_value", nullable = false)
    private String newValue;

    /** BCrypt hash of the 6-digit code: the code itself is never stored. */
    @Column(name = "otp_hash", nullable = false)
    private String otpHash;

    @Column(nullable = false)
    private LocalDateTime expiresAt;

    @Column(nullable = false)
    private LocalDateTime createdAt;

    @Column(nullable = false)
    @Builder.Default
    private int attempts = 0;
}
