package com.nearbyservices.model;

import jakarta.persistence.*;
import lombok.*;

/**
 * The last position one person shared on one active booking. One row per (booking, person), overwritten on
 * every update, so there is no location history. Rows are deleted when sharing stops, when the booking stops
 * being active, and by a purge job once they are older than the position lifetime.
 */
@Entity
@Table(name = "live_locations", indexes = @Index(name = "idx_live_locations_at", columnList = "at_millis"))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LiveLocation {

    /** "{bookingRef}:{userId}" */
    @Id
    @Column(name = "pos_key", length = 120, nullable = false)
    private String posKey;

    @Column(name = "booking_ref", length = 100, nullable = false)
    private String bookingRef;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(nullable = false)
    private double latitude;

    @Column(nullable = false)
    private double longitude;

    private Double heading;

    /** When the fix arrived, epoch milliseconds. */
    @Column(name = "at_millis", nullable = false)
    private long atMillis;
}
