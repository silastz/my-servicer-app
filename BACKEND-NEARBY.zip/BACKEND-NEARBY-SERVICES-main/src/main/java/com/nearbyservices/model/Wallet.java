package com.nearbyservices.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "wallets")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Wallet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    private User user;

    // Available pocket funds ready for use or withdrawal
    @Column(nullable = false, precision = 15, scale = 2)
    @Builder.Default
    private BigDecimal balance = BigDecimal.ZERO;

    // Funds temporarily locked in escrow
    @Column(nullable = false, precision = 15, scale = 2)
    @Builder.Default
    private BigDecimal lockedEscrowBalance = BigDecimal.ZERO;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
