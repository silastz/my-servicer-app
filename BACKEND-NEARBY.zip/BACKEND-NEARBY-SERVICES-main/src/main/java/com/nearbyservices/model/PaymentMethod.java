package com.nearbyservices.model;

public enum PaymentMethod {
    DIRECT,
    POCKET_FUND,
    OFFLINE,          // buyer pays the provider directly (cash / transfer); the app holds nothing
    PAY_AFTER_ACCEPT  // nothing is charged at request time; the buyer pays after the provider accepts
}
