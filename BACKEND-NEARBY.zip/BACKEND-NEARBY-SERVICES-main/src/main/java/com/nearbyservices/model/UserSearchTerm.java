package com.nearbyservices.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

/** One thing a signed-in user searched for (lower case), kept so promo pushes can follow their interests. */
@Entity
@Table(name = "user_search_terms",
        uniqueConstraints = @UniqueConstraint(name = "uq_user_search_term", columnNames = {"user_id", "term"}),
        indexes = @Index(name = "idx_user_search_user_at", columnList = "user_id,searched_at"))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserSearchTerm {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(nullable = false, length = 100)
    private String term;

    @Column(name = "searched_at", nullable = false)
    private Instant searchedAt;
}
