package com.nearbyservices.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * One line of the platform's own wallet. Written in the same database transaction as the event that
 * earned or paid the money. Income types: REGISTRATION_FEE, SERVICE_FEE, BOOST, COLLECTION_FEE, PAYOUT_FEE (the
 * flat part of a withdrawal / refund charge), VAT (owed to the tax authority, not income). Money out: WITHDRAWAL.
 * (type, reference) is unique, so the same event can never be booked twice.
 * Status: COMPLETED, PENDING (withdrawal not paid out yet), FAILED (withdrawal payout failed) or REVERSED (a fee that was
 * booked for a withdrawal that then failed). FAILED and REVERSED lines are kept for the record but do not count in any total.
 */
@Entity
@Table(name = "platform_entries",
        uniqueConstraints = @UniqueConstraint(name = "uq_platform_entry_type_ref", columnNames = {"type", "reference"}),
        indexes = @Index(name = "idx_platform_entry_created", columnList = "createdAt"))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PlatformEntry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 30)
    private String type;

    /** IN or OUT. */
    @Column(nullable = false, length = 3)
    private String direction;

    @Column(nullable = false, precision = 15, scale = 2)
    private BigDecimal amount;

    @Column(nullable = false, length = 20)
    @Builder.Default
    private String status = "COMPLETED";

    @Column(length = 200)
    private String title;

    @Column(length = 100)
    private String reference;

    // Admin withdrawals only
    private Long fee;
    private Long netAmount;
    @Column(length = 30)
    private String phoneMasked;
    private Long adminId;
    /** Admin withdrawals only: the full payout number (the masked one above is what the transaction list shows). */
    @Column(length = 30)
    private String payoutPhone;
    /** Admin withdrawals only: why the payout was marked FAILED (optional). */
    @Column(length = 300)
    private String failReason;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;
}
