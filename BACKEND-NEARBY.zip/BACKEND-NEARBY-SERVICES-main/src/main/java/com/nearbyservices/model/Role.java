package com.nearbyservices.model;

public enum Role {
    ROLE_BUYER,
    ROLE_SELLER,
    ROLE_ADMIN
}
