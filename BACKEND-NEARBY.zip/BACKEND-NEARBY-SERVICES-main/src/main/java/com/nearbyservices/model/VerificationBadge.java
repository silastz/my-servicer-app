package com.nearbyservices.model;

public enum VerificationBadge {
    NONE,
    GREEN_BADGE, // NIDA Number verified
    BLUE_TICK     // NIDA ID + Photo selfie with ID (or invited by a verified Blue Tick member)
}
