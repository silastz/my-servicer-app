package com.nearbyservices.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "chat_messages")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ChatMessage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sender_id", nullable = false)
    private User sender;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "recipient_id", nullable = false)
    private User recipient;

    @Column(columnDefinition = "TEXT", nullable = false)
    private String message;

    @Builder.Default
    @Column(nullable = false)
    private boolean isRead = false;

    /** When the recipient's app first received the message (null = only stored on the server so far). */
    private LocalDateTime deliveredAt;

    /** When the recipient opened the conversation and saw it. */
    private LocalDateTime readAt;

    /**
     * Random id the app makes for each message it sends. If the network drops after the server saved
     * the message but before the app heard back, the app sends it again with the same id and the
     * server returns the saved copy instead of creating a second one.
     */
    @Column(name = "client_id", length = 64)
    private String clientId;

    /** The message this one answers (same conversation), or null. */
    @Column(name = "reply_to_id")
    private Long replyToId;

    /** Set when the sender changed the text after sending. */
    private LocalDateTime editedAt;

    /**
     * Delete is always "for me": the message is hidden from that person's view only. When both people
     * have deleted it, the row is removed from the database for good (see ChatService.deleteMessage).
     */
    @Builder.Default
    @Column(name = "hidden_for_sender", nullable = false, columnDefinition = "boolean default false")
    private boolean hiddenForSender = false;

    @Builder.Default
    @Column(name = "hidden_for_recipient", nullable = false, columnDefinition = "boolean default false")
    private boolean hiddenForRecipient = false;

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;
}
