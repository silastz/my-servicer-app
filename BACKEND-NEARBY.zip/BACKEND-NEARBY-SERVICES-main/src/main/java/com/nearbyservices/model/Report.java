package com.nearbyservices.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

/** A user's report of a service, another user, or a general problem. Reviewed by admins. */
@Entity
@Table(name = "reports")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Report {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "reporter_id", nullable = false)
    private Long reporterId;

    /** SERVICE, USER or GENERAL */
    @Column(nullable = false, length = 10)
    private String type;

    @Column(name = "service_id")
    private Long serviceId;

    /** The person reported (for a SERVICE report: its provider). */
    @Column(name = "reported_user_id")
    private Long reportedUserId;

    @Column(nullable = false, length = 100)
    private String reason;

    @Column(length = 2000)
    private String details;

    /** OPEN, REVIEWING, RESOLVED or DISMISSED */
    @Column(nullable = false, length = 12)
    @Builder.Default
    private String status = "OPEN";

    @Column(length = 1000)
    private String adminNote;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
