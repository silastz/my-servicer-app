package com.nearbyservices.model;

public enum PaymentStatus { PENDING, PAID, FAILED, CANCELLED }
