package com.nearbyservices.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * One line of a user's wallet history. Written in the same database transaction that changes the balance,
 * so the history can never disagree with the money. Rows are never edited, except that a withdrawal moves
 * from PENDING to COMPLETED / FAILED when the payout result is known.
 */
@Entity
@Table(name = "wallet_transactions", indexes = {
        @Index(name = "idx_wallet_tx_user_created", columnList = "userId, createdAt")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WalletTransaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long userId;

    /** DEPOSIT, WITHDRAWAL, BOOKING, REFUND or BOOST. */
    @Column(nullable = false, length = 20)
    private String type;

    /** IN or OUT, from the user's point of view. */
    @Column(nullable = false, length = 3)
    private String direction;

    /** Always positive; the direction says which way the money went. */
    @Column(nullable = false, precision = 15, scale = 2)
    private BigDecimal amount;

    /** COMPLETED, PENDING or FAILED. */
    @Column(nullable = false, length = 20)
    private String status;

    @Column(length = 200)
    private String title;

    @Column(length = 100)
    private String reference;

    // Withdrawals only: what was taken, stored so a later change of the fees never rewrites history.
    private Long collectionFee;
    private Long chargeFee;
    private Long payoutPart;
    private Long vatPart;
    private Long netAmount;

    /** Withdrawals only: where the payout goes (digits, optional leading +). Never sent back to the app. */
    @Column(length = 30)
    private String payoutPhone;

    /** Withdrawals only: why an admin marked the payout FAILED (optional). */
    @Column(length = 300)
    private String failReason;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;
}
