package com.nearbyservices.model;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

/** One uploaded paper (id_front, id_back, selfie_with_id, business_registration ...). One row per user and type; a new upload replaces it. */
@Entity
@Table(name = "verification_documents",
        uniqueConstraints = @UniqueConstraint(name = "uq_verification_doc_user_type", columnNames = {"user_id", "doc_type"}))
public class VerificationDocument {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "doc_type", nullable = false, length = 40)
    private String type;

    /** nida | voter | driving_licence | passport (id_front / id_back only) */
    @Column(length = 20)
    private String idKind;

    /** Key of the private file. Never sent to the app. */
    @Column(nullable = false, length = 200)
    private String fileKey;

    /** PENDING | APPROVED | REJECTED */
    @Column(nullable = false, length = 12)
    private String status = "PENDING";

    @Column(length = 200)
    private String reason;

    @CreationTimestamp
    private LocalDateTime createdAt;
    private LocalDateTime reviewedAt;

    public Long getId() { return id; }
    public Long getUserId() { return userId; }
    public void setUserId(Long v) { this.userId = v; }
    public String getType() { return type; }
    public void setType(String v) { this.type = v; }
    public String getIdKind() { return idKind; }
    public void setIdKind(String v) { this.idKind = v; }
    public String getFileKey() { return fileKey; }
    public void setFileKey(String v) { this.fileKey = v; }
    public String getStatus() { return status; }
    public void setStatus(String v) { this.status = v; }
    public String getReason() { return reason; }
    public void setReason(String v) { this.reason = v; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getReviewedAt() { return reviewedAt; }
    public void setReviewedAt(LocalDateTime v) { this.reviewedAt = v; }
}
