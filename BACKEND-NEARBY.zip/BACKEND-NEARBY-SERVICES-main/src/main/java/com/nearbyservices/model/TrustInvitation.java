package com.nearbyservices.model;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

/**
 * A verified provider vouches for someone they know. The row doubles as the audit link
 * "inviter vouched for invitee" (acceptedBy is filled when it is used).
 */
@Entity
@Table(name = "trust_invitations", indexes = {
        @Index(name = "idx_trust_inv_inviter", columnList = "inviter_id"),
        @Index(name = "idx_trust_inv_phone", columnList = "invitee_phone_key")})
public class TrustInvitation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long inviterId;

    /** Short single-use code; the app shows "<inviterId>-<code>". */
    @Column(nullable = false, length = 12)
    private String code;

    /** The phone as typed (digits with country code). */
    @Column(nullable = false, length = 20)
    private String inviteePhone;

    /** Last 9 digits, used to match the phone with an account whatever the prefix (0712.., 255712.., +255712..). */
    @Column(nullable = false, length = 9)
    private String inviteePhoneKey;

    /** PENDING | ACCEPTED | EXPIRED | CANCELLED */
    @Column(nullable = false, length = 12)
    private String status = "PENDING";

    @Column(nullable = false)
    private LocalDateTime expiresAt;

    private Long acceptedBy;
    private LocalDateTime acceptedAt;

    @CreationTimestamp
    private LocalDateTime createdAt;

    public Long getId() { return id; }
    public Long getInviterId() { return inviterId; }
    public void setInviterId(Long v) { this.inviterId = v; }
    public String getCode() { return code; }
    public void setCode(String v) { this.code = v; }
    public String getInviteePhone() { return inviteePhone; }
    public void setInviteePhone(String v) { this.inviteePhone = v; }
    public String getInviteePhoneKey() { return inviteePhoneKey; }
    public void setInviteePhoneKey(String v) { this.inviteePhoneKey = v; }
    public String getStatus() { return status; }
    public void setStatus(String v) { this.status = v; }
    public LocalDateTime getExpiresAt() { return expiresAt; }
    public void setExpiresAt(LocalDateTime v) { this.expiresAt = v; }
    public Long getAcceptedBy() { return acceptedBy; }
    public void setAcceptedBy(Long v) { this.acceptedBy = v; }
    public LocalDateTime getAcceptedAt() { return acceptedAt; }
    public void setAcceptedAt(LocalDateTime v) { this.acceptedAt = v; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
