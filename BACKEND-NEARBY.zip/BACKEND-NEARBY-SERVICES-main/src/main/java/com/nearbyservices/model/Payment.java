package com.nearbyservices.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/** One money-in attempt (mobile money prompt or card checkout). The reference is unique and is the idempotency key. */
@Entity
@Table(name = "payments")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 100)
    private String reference;

    @Column(nullable = false)
    private Long userId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private PaymentPurpose purpose;

    /** MOBILE or CARD */
    @Column(nullable = false, length = 10)
    private String channel;

    @Column(nullable = false, precision = 15, scale = 2)
    private BigDecimal amount;

    private String phone;

    @Column(nullable = false, length = 30)
    private String gateway;

    private String gatewayReference;

    @Column(length = 1000)
    private String checkoutUrl;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private PaymentStatus status = PaymentStatus.PENDING;

    /** True once the effect of a PAID payment (credit, wallet, ...) has been applied. Guards double settlement. */
    @Column(nullable = false)
    @Builder.Default
    private boolean settled = false;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
