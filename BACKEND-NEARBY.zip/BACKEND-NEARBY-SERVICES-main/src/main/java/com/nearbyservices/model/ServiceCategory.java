package com.nearbyservices.model;

import jakarta.persistence.*;
import lombok.*;

/**
 * One service category the admin manages. The id is the key services are saved under and the app sends as
 * ?category= (e.g. "Plumbing"); it never changes, only the display names do.
 */
@Entity
@Table(name = "service_categories")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ServiceCategory {

    @Id
    @Column(length = 60)
    private String id;

    @Column(name = "name_en", nullable = false, length = 80)
    private String nameEn;

    @Column(name = "name_sw", nullable = false, length = 80)
    private String nameSw;

    @Column(name = "sort_order", nullable = false)
    private int sortOrder;

    /** Off = hidden from the app and refused for new services; existing services keep it. */
    @Column(nullable = false)
    @Builder.Default
    private boolean active = true;
}
