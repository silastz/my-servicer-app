package com.nearbyservices.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "users")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {

    @JsonIgnore
    public boolean isSuspended() {
        return suspendedAt != null;
    }


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String username;

    @Column(nullable = false, unique = true)
    private String phone;

    @Column(unique = true)
    private String email;

    @Builder.Default
    @Column(nullable = false)
    private boolean emailVerified = false;

    @JsonIgnore
    @Column(name = "email_otp")
    private String emailOtp;

    @JsonIgnore
    @Column(name = "email_otp_expiry")
    private LocalDateTime emailOtpExpiry;

    @Builder.Default
    @Column(nullable = false)
    private boolean phoneVerified = false;

    @JsonIgnore
    @Column(name = "phone_otp")
    private String phoneOtp;

    @JsonIgnore
    @Column(name = "phone_otp_expiry")
    private LocalDateTime phoneOtpExpiry;

    @Column(nullable = false)
    @JsonIgnore
    private String password;

    /** Login tokens issued before this moment are refused (set when the password is reset). Null = no limit. */
    @JsonIgnore
    @Column(name = "tokens_valid_from")
    private java.time.Instant tokensValidFrom;

    // Public display name (Stage Name) for Sellers to maintain anonymity and privacy
    @Column(nullable = false)
    private String stageName;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Role role;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private VerificationBadge verificationBadge = VerificationBadge.NONE;

    @Builder.Default
    @Column(name = "is_18_plus", nullable = false)
    private boolean is18Plus = false;

    // STRICTLY PRIVATE / CONFIDENTIAL NIDA DATA
    // Kept secret & NEVER exposed in public DTOs
    @JsonIgnore
    @Column(name = "nida_number")
    private String nidaNumber;

    @JsonIgnore
    @Column(name = "nida_official_first_name")
    private String nidaOfficialFirstName;

    @JsonIgnore
    @Column(name = "nida_official_last_name")
    private String nidaOfficialLastName;

    @JsonIgnore
    @Column(name = "nida_id_photo_url")
    private String nidaIdPhotoUrl;

    @JsonIgnore
    @Column(name = "nida_selfie_photo_url")
    private String nidaSelfiePhotoUrl;

    @JsonIgnore
    @Column(name = "invited_by_user_id")
    private Long invitedByUserId;

    // Paid per-service fees not yet spent (one credit = one extra service). Server-side only.
    @JsonIgnore
    @Builder.Default
    @Column(name = "service_fee_credits", nullable = false, columnDefinition = "integer default 0")
    private int serviceFeeCredits = 0;

    // Services ever posted. Never goes down, so deleting a service does not give back a free slot.
    @JsonIgnore
    @Builder.Default
    @Column(name = "services_posted", nullable = false, columnDefinition = "integer default 0")
    private int servicesPosted = 0;

    // Set by a PAID PROVIDER_REGISTRATION payment (server side only).
    @JsonIgnore
    @Builder.Default
    @Column(name = "registration_fee_paid", nullable = false, columnDefinition = "boolean default false")
    private boolean registrationFeePaid = false;

    // Public profile (shown on the service page and the provider profile)
    @Column(name = "bio", length = 500)
    private String bio;

    @Column(name = "avatar_url", length = 500)
    private String avatarUrl;

    @Column(name = "cover_url", length = 500)
    private String coverUrl;

    // Not used any more: push goes through OneSignal by user id (PushService). The column stays so the schema does not change.
    @Column(name = "fcm_token")
    private String fcmToken;

    // Hide My ID: providers see this user's stage name and normal photo only. Default off.
    @Builder.Default
    @Column(name = "hide_my_id", nullable = false, columnDefinition = "boolean default false")
    private boolean hideMyId = false;

    // Profile Locked (default ON, same as the app): a locked provider's phone and social links stay hidden from the
    // public until a booking is accepted. The SERVER enforces it when it builds a service page.
    @Builder.Default
    @Column(name = "profile_locked", nullable = false, columnDefinition = "boolean default true")
    private boolean profileLocked = true;

    // The provider's profile social links / WhatsApp. They are the fallback for a service that has none of its own and
    // are shown only while the profile is unlocked (same rule as the service contacts). Handles without the leading @.
    @Column(name = "social_whatsapp", length = 100) private String socialWhatsapp;
    @Column(name = "social_instagram", length = 100) private String socialInstagram;
    @Column(name = "social_facebook", length = 100) private String socialFacebook;
    @Column(name = "social_x", length = 100) private String socialX;
    @Column(name = "social_tiktok", length = 100) private String socialTiktok;
    @Column(name = "social_youtube", length = 100) private String socialYoutube;

    // Notification switches (Settings > Notification Preferences). The SERVER enforces them, so a push for a
    // category the user turned off is never sent, even when the app is closed.
    @Builder.Default
    @Column(name = "notif_bookings", nullable = false, columnDefinition = "boolean default true")
    private boolean notifBookings = true;

    @Builder.Default
    @Column(name = "notif_messages", nullable = false, columnDefinition = "boolean default true")
    private boolean notifMessages = true;

    @Builder.Default
    @Column(name = "notif_promos", nullable = false, columnDefinition = "boolean default true")
    private boolean notifPromos = true;

    // Admin alert switches (Admin > Notification Preferences). Only read for admin accounts; the SERVER enforces them
    // (AdminAlerts), so an alert that is switched off is never sent, even when the app is closed.
    @Builder.Default
    @Column(name = "notif_admin_reports", nullable = false, columnDefinition = "boolean default true")
    private boolean notifAdminReports = true;

    @Builder.Default
    @Column(name = "notif_admin_disputes", nullable = false, columnDefinition = "boolean default true")
    private boolean notifAdminDisputes = true;

    @Builder.Default
    @Column(name = "notif_admin_withdrawals", nullable = false, columnDefinition = "boolean default true")
    private boolean notifAdminWithdrawals = true;

    @Builder.Default
    @Column(name = "notif_admin_payments", nullable = false, columnDefinition = "boolean default true")
    private boolean notifAdminPayments = true;

    // The account's country / wallet currency (ISO country, ISO currency). Null means Tanzania / TZS.
    @Column(name = "country", length = 2)
    private String country;

    @Column(name = "currency", length = 3)
    private String currency;

    // The user's own last GPS fix, used to rank nearby services. PRIVATE: never sent to anyone.
    @JsonIgnore
    @Column(name = "last_latitude")
    private Double lastLatitude;

    @JsonIgnore
    @Column(name = "last_longitude")
    private Double lastLongitude;

    @JsonIgnore
    @Column(name = "location_updated_at")
    private LocalDateTime locationUpdatedAt;

    /** Set when the user deletes their own account. The row stays (payment and booking history point at it) but holds no personal data. */
    @JsonIgnore
    @Column(name = "deleted_at")
    private java.time.Instant deletedAt;

    /** Set by an admin to block the account (null = not suspended). The row and all history stay; the person cannot sign in. */
    @JsonIgnore
    @Column(name = "suspended_at")
    private java.time.Instant suspendedAt;

    /** Why an admin suspended the account. Shown to the admin only. */
    @JsonIgnore
    @Column(name = "suspend_reason", length = 500)
    private String suspendReason;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
