package com.nearbyservices.model;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;

/**
 * A buyer's own price for a service. Negotiation happens before the booking: once AGREED, the buyer books
 * with offerId and the booking uses agreedAmount (never the amount the app sends).
 */
@Entity
@Table(name = "price_offers")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PriceOffer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long buyerId;

    /** Always the owner of the service, taken from the service and never from the app. */
    @Column(nullable = false)
    private Long sellerId;

    @Column(nullable = false)
    private Long serviceId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 12)
    @Builder.Default
    private OfferStatus status = OfferStatus.OFFERED;

    /** The service's price at offer time (the sale price while a sale runs). */
    @Column(nullable = false, precision = 15, scale = 2)
    private BigDecimal listedPrice;

    @Column(nullable = false, precision = 15, scale = 2)
    private BigDecimal amount;

    /** Set when the offer becomes AGREED; this is what the booking charges. */
    @Column(precision = 15, scale = 2)
    private BigDecimal agreedAmount;

    @Column(length = 500)
    private String message;

    @Column(length = 300)
    private String rejectReason;

    /** The escrow booking made with this offer (status BOOKED). */
    @Column(length = 50)
    private String bookingRef;

    /** Deadline of the current step: answer deadline while OFFERED, booking deadline while AGREED. */
    @Column(nullable = false)
    private Instant expiresAt;

    /** True once the "about to expire" reminder for the current step went out. Cleared when the offer moves on. */
    @Column(nullable = false, columnDefinition = "boolean default false")
    @Builder.Default
    private boolean reminderSent = false;

    @Column(nullable = false, updatable = false)
    private Instant createdAt;

    @Column(nullable = false)
    private Instant updatedAt;
}
