package com.nearbyservices.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "services")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ServicePost {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String title;

    @Column(nullable = false, length = 2000)
    private String description;

    @Column(nullable = false)
    private String category;

    @Column(nullable = false, precision = 15, scale = 2)
    private BigDecimal price;

    // Location details
    private String city;
    private String region;
    private Double latitude;
    private Double longitude;

    // Contact info (controlled by isInfoLocked)
    private String phone;
    private String whatsappPhone;
    private String email;
    private String instagramUsername;

    // Locked vs Unlocked contact rule:
    // If true (locked): contacts (phone, whatsapp, email, instagram, navigation coords) are hidden
    // until buyer's service request is accepted.
    @Builder.Default
    @Column(name = "is_info_locked", nullable = false)
    @com.fasterxml.jackson.annotation.JsonProperty("isInfoLocked")
    private Boolean isInfoLocked = false;

    // 18+ sensitive adult-oriented service flag
    @Builder.Default
    @Column(name = "is_18_plus", nullable = false)
    private boolean is18Plus = false;

    // Dynamic service images upload paths
    @ElementCollection
    @CollectionTable(name = "service_images", joinColumns = @JoinColumn(name = "service_id"))
    @Column(name = "image_url")
    @Builder.Default
    private java.util.List<String> imageUrls = new java.util.ArrayList<>();

    // Videos uploaded separately (up to 6 videos per service)
    @ElementCollection
    @CollectionTable(name = "service_videos", joinColumns = @JoinColumn(name = "service_id"))
    @Column(name = "video_url")
    @Builder.Default
    private java.util.List<String> videoUrls = new java.util.ArrayList<>();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "seller_id", nullable = false)
    private User seller;

    // ---- Extra details sent by the publish / edit form -------------------------------------
    // All new columns are nullable on purpose: existing rows stay valid when Hibernate adds them.

    @Column(name = "short_description", length = 200)
    private String shortDescription;

    // Search-only words in another language (not shown to buyers)
    @Column(name = "other_language", length = 500)
    private String otherLanguage;

    @Column(length = 200)
    private String area;

    @Column(name = "service_radius_km")
    private Integer serviceRadiusKm; // 0 = whole city

    @Column(name = "price_type", length = 20)
    private String priceType; // FIXED | STARTING_FROM | PER_HOUR

    @Column(name = "service_mode", length = 30)
    private String serviceMode; // customer_comes | provider_travels | both

    @Column(name = "duration_minutes")
    private Integer durationMinutes; // null = price only

    @ElementCollection
    @CollectionTable(name = "service_available_days", joinColumns = @JoinColumn(name = "service_id"))
    @Column(name = "day_key", length = 20)
    @Builder.Default
    private java.util.List<String> availableDays = new java.util.ArrayList<>();

    @Column(name = "available_from", length = 10)
    private String availableFrom; // "HH:mm"

    @Column(name = "available_to", length = 10)
    private String availableTo; // "HH:mm"

    private String facebookUsername;
    private String tiktokUsername;
    private String xUsername;
    private String youtubeUsername;

    // What is included / the menu. Order matters, so it keeps a position column.
    @ElementCollection
    @CollectionTable(name = "service_features", joinColumns = @JoinColumn(name = "service_id"))
    @OrderColumn(name = "sort_order")
    @Column(name = "feature", length = 100)
    @Builder.Default
    private java.util.List<String> features = new java.util.ArrayList<>();

    @Column(name = "featured_image_url", length = 1000)
    private String featuredImageUrl;

    // Up to 3 tasks, each with its own price. Empty = the service has one price only.
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "service_tasks", joinColumns = @JoinColumn(name = "service_id"))
    @OrderColumn(name = "sort_order")
    @Builder.Default
    private java.util.List<ServiceTask> tasks = new java.util.ArrayList<>();

    // ---- Discount and price offers (see NEGOTIATION_FLOW.md in the app) ----------------------
    @Column(name = "discount_percent")
    private Integer discountPercent; // 1-90, null = no discount

    @Column(name = "discount_valid_until")
    private java.time.Instant discountValidUntil; // null = until the seller removes it

    @Column(name = "allow_offers")
    private Boolean allowOffers; // null is treated as true

    // PRIVATE: only ever returned to the service owner
    @Column(name = "min_offer_price", precision = 15, scale = 2)
    private BigDecimal minOfferPrice;

    @Column(name = "auto_accept_price", precision = 15, scale = 2)
    private BigDecimal autoAcceptPrice;

    // Paid boost: ranked first and tagged "Boosted" while this is in the future. Null = never boosted.
    @Column(name = "boosted_until")
    private java.time.Instant boostedUntil;

    @Builder.Default
    private boolean active = true;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
