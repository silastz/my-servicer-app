package com.nearbyservices.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Everything about one user's identity checks except the NIN itself (that stays on User.nidaNumber):
 * legal name, verified photo, Verified Business. One row per user, keyed by the user id.
 * The typed legal name is only a claim; verifiedName is what the server confirmed. Never sent to the public
 * unless Hide My ID is off (see EscrowService).
 */
@Entity
@Table(name = "user_verification_profiles")
public class UserVerificationProfile {

    @Id
    @Column(name = "user_id")
    private Long userId;

    // ---- legal name: NONE | PENDING | VERIFIED | REJECTED
    @Column(length = 12, nullable = false)
    private String nameStatus = "NONE";
    @Column(length = 80)
    private String nameClaim;
    @Column(length = 80)
    private String verifiedName;
    @Column(length = 200)
    private String nameReason;

    // ---- live face photo: NONE | PENDING | VERIFIED | REJECTED
    @Column(length = 12, nullable = false)
    private String photoStatus = "NONE";
    @Column(length = 500)
    private String photoUrl;
    @Column(length = 200)
    private String photoReason;

    // ---- Verified Business: NONE | PENDING | VERIFIED | REJECTED | EXPIRED
    @Column(length = 12, nullable = false)
    private String businessStatus = "NONE";
    @Column(length = 120)
    private String businessName;
    @Column(length = 200)
    private String businessReason;
    private LocalDate businessExpiresAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;

    public UserVerificationProfile() {
    }

    public UserVerificationProfile(Long userId) {
        this.userId = userId;
    }

    public Long getUserId() { return userId; }
    public String getNameStatus() { return nameStatus; }
    public void setNameStatus(String v) { this.nameStatus = v; }
    public String getNameClaim() { return nameClaim; }
    public void setNameClaim(String v) { this.nameClaim = v; }
    public String getVerifiedName() { return verifiedName; }
    public void setVerifiedName(String v) { this.verifiedName = v; }
    public String getNameReason() { return nameReason; }
    public void setNameReason(String v) { this.nameReason = v; }
    public String getPhotoStatus() { return photoStatus; }
    public void setPhotoStatus(String v) { this.photoStatus = v; }
    public String getPhotoUrl() { return photoUrl; }
    public void setPhotoUrl(String v) { this.photoUrl = v; }
    public String getPhotoReason() { return photoReason; }
    public void setPhotoReason(String v) { this.photoReason = v; }
    public String getBusinessStatus() { return businessStatus; }
    public void setBusinessStatus(String v) { this.businessStatus = v; }
    public String getBusinessName() { return businessName; }
    public void setBusinessName(String v) { this.businessName = v; }
    public String getBusinessReason() { return businessReason; }
    public void setBusinessReason(String v) { this.businessReason = v; }
    public LocalDate getBusinessExpiresAt() { return businessExpiresAt; }
    public void setBusinessExpiresAt(LocalDate v) { this.businessExpiresAt = v; }
}
