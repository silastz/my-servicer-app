package com.nearbyservices.repository;

import com.nearbyservices.model.Report;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface ReportRepository extends JpaRepository<Report, Long> {
    long countByReporterIdAndCreatedAtAfter(Long reporterId, LocalDateTime since);

    /** The same person reporting the same thing again while the first is still open. */
    Optional<Report> findFirstByReporterIdAndTypeAndServiceIdAndReportedUserIdAndStatusIn(
            Long reporterId, String type, Long serviceId, Long reportedUserId, List<String> statuses);

    List<Report> findByStatusOrderByCreatedAtDesc(String status, Pageable pageable);

    List<Report> findAllByOrderByCreatedAtDesc(Pageable pageable);
}
