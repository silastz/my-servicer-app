package com.nearbyservices.repository;

import com.nearbyservices.model.PortfolioItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PortfolioItemRepository extends JpaRepository<PortfolioItem, Long> {

    List<PortfolioItem> findByOwnerIdOrderByCreatedAtDescIdDesc(Long ownerId);

    long countByOwnerIdAndType(Long ownerId, PortfolioItem.Type type);

    Optional<PortfolioItem> findByIdAndOwnerId(Long id, Long ownerId);

    List<PortfolioItem> findByOwnerId(Long ownerId);

    void deleteByOwnerId(Long ownerId);
}
