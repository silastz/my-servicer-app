package com.nearbyservices.repository;

import com.nearbyservices.model.VerificationDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface VerificationDocumentRepository extends JpaRepository<VerificationDocument, Long> {
    List<VerificationDocument> findByUserId(Long userId);
    Optional<VerificationDocument> findByUserIdAndType(Long userId, String type);
    List<VerificationDocument> findByStatusOrderByCreatedAtAsc(String status);
}
