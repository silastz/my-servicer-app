package com.nearbyservices.repository;

import com.nearbyservices.model.UserBlock;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserBlockRepository extends JpaRepository<UserBlock, Long> {
    boolean existsByBlockerIdAndBlockedId(Long blockerId, Long blockedId);

    List<UserBlock> findByBlockerIdOrderByCreatedAtDesc(Long blockerId);

    @Query("select b.blockedId from UserBlock b where b.blockerId = :id")
    List<Long> blockedIdsOf(@Param("id") Long blockerId);

    @Query("select b.blockerId from UserBlock b where b.blockedId = :id")
    List<Long> blockerIdsOf(@Param("id") Long blockedId);

    @Modifying
    @Query("delete from UserBlock b where b.blockerId = :blocker and b.blockedId = :blocked")
    void deletePair(@Param("blocker") Long blocker, @Param("blocked") Long blocked);
}
