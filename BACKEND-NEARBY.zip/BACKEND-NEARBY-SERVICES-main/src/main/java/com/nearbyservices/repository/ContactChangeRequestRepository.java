package com.nearbyservices.repository;

import com.nearbyservices.model.ContactChangeRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ContactChangeRequestRepository extends JpaRepository<ContactChangeRequest, Long> {
    Optional<ContactChangeRequest> findByUserIdAndKind(Long userId, String kind);
}
