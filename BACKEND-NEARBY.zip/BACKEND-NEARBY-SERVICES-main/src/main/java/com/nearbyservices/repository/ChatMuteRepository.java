package com.nearbyservices.repository;

import com.nearbyservices.model.ChatMute;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ChatMuteRepository extends JpaRepository<ChatMute, Long> {
    boolean existsByUserIdAndMutedUserId(Long userId, Long mutedUserId);

    @Modifying
    @Query("delete from ChatMute m where m.userId = :user and m.mutedUserId = :muted")
    void deletePair(@Param("user") Long userId, @Param("muted") Long mutedUserId);
}
