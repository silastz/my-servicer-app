package com.nearbyservices.repository;

import com.nearbyservices.model.LiveLocation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface LiveLocationRepository extends JpaRepository<LiveLocation, String> {

    /** Insert or overwrite in one statement (PostgreSQL), so two quick updates never collide. */
    @Modifying
    @Query(value = "INSERT INTO live_locations (pos_key, booking_ref, user_id, latitude, longitude, heading, at_millis) "
            + "VALUES (:key, :ref, :uid, :lat, :lng, CAST(:heading AS double precision), :at) "
            + "ON CONFLICT (pos_key) DO UPDATE SET latitude = EXCLUDED.latitude, longitude = EXCLUDED.longitude, "
            + "heading = EXCLUDED.heading, at_millis = EXCLUDED.at_millis", nativeQuery = true)
    void upsert(@Param("key") String key, @Param("ref") String ref, @Param("uid") long userId,
                @Param("lat") double lat, @Param("lng") double lng, @Param("heading") Double heading,
                @Param("at") long atMillis);

    @Modifying
    @Query("delete from LiveLocation l where l.posKey = :key")
    void deleteByKey(@Param("key") String key);

    @Modifying
    @Query("delete from LiveLocation l where l.userId = :uid")
    int deleteByUserId(@Param("uid") long userId);

    @Modifying
    @Query("delete from LiveLocation l where l.atMillis < :cutoff")
    int deleteOlderThan(@Param("cutoff") long cutoffMillis);
}
