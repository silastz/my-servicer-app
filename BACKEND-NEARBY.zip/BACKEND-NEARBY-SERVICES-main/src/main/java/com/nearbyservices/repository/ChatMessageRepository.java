package com.nearbyservices.repository;

import com.nearbyservices.model.ChatMessage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface ChatMessageRepository extends JpaRepository<ChatMessage, Long> {

    @Query("SELECT m FROM ChatMessage m WHERE " +
           "(m.sender.id = :u1 AND m.recipient.id = :u2) OR " +
           "(m.sender.id = :u2 AND m.recipient.id = :u1) " +
           "ORDER BY m.createdAt ASC")
    List<ChatMessage> findConversationBetween(@Param("u1") Long u1, @Param("u2") Long u2);

    @Query("SELECT m FROM ChatMessage m WHERE m.sender.id = :userId OR m.recipient.id = :userId ORDER BY m.createdAt DESC")
    List<ChatMessage> findAllByUser(@Param("userId") Long userId);

    /** The recipient's app has received everything addressed to them (e.g. it loaded the chat list). */
    @Modifying(flushAutomatically = true, clearAutomatically = true)
    @Query("UPDATE ChatMessage m SET m.deliveredAt = :now WHERE m.recipient.id = :me AND m.deliveredAt IS NULL")
    int markDelivered(@Param("me") Long recipientId, @Param("now") LocalDateTime now);

    /** The recipient opened the conversation with {@code other}: everything from that person is now read (and delivered). */
    @Modifying(flushAutomatically = true, clearAutomatically = true)
    @Query("UPDATE ChatMessage m SET m.isRead = true, m.readAt = :now, m.deliveredAt = COALESCE(m.deliveredAt, :now) " +
           "WHERE m.recipient.id = :me AND m.sender.id = :other AND m.isRead = false")
    int markRead(@Param("me") Long recipientId, @Param("other") Long senderId, @Param("now") LocalDateTime now);

    /** Who sent me something that has not reached my phone yet (used when I come online). */
    @Query("SELECT DISTINCT m.sender.id FROM ChatMessage m WHERE m.recipient.id = :me AND m.deliveredAt IS NULL")
    List<Long> findUndeliveredSenderIds(@Param("me") Long recipientId);

    /** One message reached the recipient's phone (no-op when it already counts as delivered). */
    @Modifying(flushAutomatically = true, clearAutomatically = true)
    @Query("UPDATE ChatMessage m SET m.deliveredAt = :now WHERE m.id = :id AND m.deliveredAt IS NULL")
    int markDeliveredById(@Param("id") Long id, @Param("now") LocalDateTime now);

    /** A message this person already sent with this app-made id (retry of a send whose reply got lost). */
    Optional<ChatMessage> findFirstBySenderIdAndClientId(Long senderId, String clientId);
}
