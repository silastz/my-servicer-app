package com.nearbyservices.repository;

import com.nearbyservices.model.OfferStatus;
import com.nearbyservices.model.PriceOffer;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Repository
public interface PriceOfferRepository extends JpaRepository<PriceOffer, Long> {

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select o from PriceOffer o where o.id = :id")
    Optional<PriceOffer> findByIdForUpdate(@Param("id") Long id);

    boolean existsByBuyerIdAndServiceIdAndStatusIn(Long buyerId, Long serviceId, Collection<OfferStatus> statuses);

    long countByBuyerIdAndCreatedAtAfter(Long buyerId, Instant since);

    List<PriceOffer> findTop100ByBuyerIdOrderByCreatedAtDesc(Long buyerId);

    List<PriceOffer> findTop100BySellerIdOrderByCreatedAtDesc(Long sellerId);

    /** Open offers whose deadline falls between now and the cutoff and that have not been reminded for this step. */
    @Query("select o from PriceOffer o where o.status in :statuses and o.reminderSent = false and o.expiresAt > :now and o.expiresAt <= :cutoff")
    List<PriceOffer> findDueForReminder(@Param("statuses") Collection<OfferStatus> statuses,
                                        @Param("now") Instant now, @Param("cutoff") Instant cutoff);

    /** Marks every open offer whose deadline has passed. */
    @Modifying
    @Query("update PriceOffer o set o.status = :to where o.status in :from and o.expiresAt < :now")
    int expireDue(@Param("to") OfferStatus to, @Param("from") Collection<OfferStatus> from, @Param("now") Instant now);
}
