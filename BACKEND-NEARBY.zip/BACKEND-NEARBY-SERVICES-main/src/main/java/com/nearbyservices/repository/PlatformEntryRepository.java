package com.nearbyservices.repository;

import com.nearbyservices.model.PlatformEntry;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.repository.query.Param;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Repository
public interface PlatformEntryRepository extends JpaRepository<PlatformEntry, Long> {
    /** Rows of [type, direction, sum(amount)]. FAILED withdrawals and REVERSED fees are not money and are left out. */
    @Query("select e.type, e.direction, coalesce(sum(e.amount), 0) from PlatformEntry e "
            + "where e.status not in ('FAILED', 'REVERSED') group by e.type, e.direction")
    List<Object[]> totals();

    List<PlatformEntry> findAllByOrderByCreatedAtDescIdDesc(Pageable pageable);

    boolean existsByTypeAndReference(String type, String reference);

    List<PlatformEntry> findByTypeAndStatusOrderByCreatedAtDescIdDesc(String type, String status, Pageable pageable);

    List<PlatformEntry> findByTypeOrderByCreatedAtDescIdDesc(String type, Pageable pageable);

    /** Row lock for completing / failing the admin's own withdrawal. */
    @Lock(jakarta.persistence.LockModeType.PESSIMISTIC_WRITE)
    @Query("select e from PlatformEntry e where e.type = :type and e.reference = :reference")
    Optional<PlatformEntry> findByTypeAndReferenceForUpdate(@Param("type") String type, @Param("reference") String reference);

    /** The fee lines booked for one withdrawal (same reference, other types). */
    List<PlatformEntry> findByReferenceAndTypeIn(String reference, Collection<String> types);
}
