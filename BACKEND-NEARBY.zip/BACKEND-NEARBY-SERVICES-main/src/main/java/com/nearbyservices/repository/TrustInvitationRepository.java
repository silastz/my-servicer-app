package com.nearbyservices.repository;

import com.nearbyservices.model.TrustInvitation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TrustInvitationRepository extends JpaRepository<TrustInvitation, Long> {
    List<TrustInvitation> findByInviterIdOrderByCreatedAtDesc(Long inviterId);
    List<TrustInvitation> findByInviteePhoneKeyOrderByCreatedAtDesc(String inviteePhoneKey);
    Optional<TrustInvitation> findByInviterIdAndCode(Long inviterId, String code);
    Optional<TrustInvitation> findFirstByInviteePhoneKeyAndCodeAndStatus(String inviteePhoneKey, String code, String status);
    Optional<TrustInvitation> findFirstByInviterIdAndInviteePhoneKeyAndStatus(Long inviterId, String inviteePhoneKey, String status);
    boolean existsByInviterIdAndCode(Long inviterId, String code);
    long countByInviterIdAndStatus(Long inviterId, String status);
    boolean existsByInviterIdAndInviteePhoneKeyAndStatus(Long inviterId, String inviteePhoneKey, String status);
}
