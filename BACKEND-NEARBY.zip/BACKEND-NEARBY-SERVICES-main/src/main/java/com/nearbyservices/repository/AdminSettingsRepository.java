package com.nearbyservices.repository;

import com.nearbyservices.model.AdminSettings;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AdminSettingsRepository extends JpaRepository<AdminSettings, Long> {
    /** The single settings row, locked: used to run platform withdrawals one at a time. */
    @org.springframework.data.jpa.repository.Lock(jakarta.persistence.LockModeType.PESSIMISTIC_WRITE)
    java.util.Optional<AdminSettings> findFirstByOrderByIdAsc();
}
