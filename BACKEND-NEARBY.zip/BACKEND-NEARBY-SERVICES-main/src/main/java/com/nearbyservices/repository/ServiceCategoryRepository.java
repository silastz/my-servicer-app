package com.nearbyservices.repository;

import com.nearbyservices.model.ServiceCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ServiceCategoryRepository extends JpaRepository<ServiceCategory, String> {
    List<ServiceCategory> findByActiveTrueOrderBySortOrderAscIdAsc();

    Optional<ServiceCategory> findByIdIgnoreCase(String id);
}
