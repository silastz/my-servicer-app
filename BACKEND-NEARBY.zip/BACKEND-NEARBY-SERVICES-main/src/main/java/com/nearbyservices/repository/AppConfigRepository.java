package com.nearbyservices.repository;

import com.nearbyservices.model.AppConfigEntry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AppConfigRepository extends JpaRepository<AppConfigEntry, String> {
}
