package com.nearbyservices.repository;

import com.nearbyservices.model.BoostPlan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BoostPlanRepository extends JpaRepository<BoostPlan, String> {
    List<BoostPlan> findByActiveTrueOrderByDaysAsc();
}
