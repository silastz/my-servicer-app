package com.nearbyservices.repository;

import com.nearbyservices.model.WalletTransaction;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Repository
public interface WalletTransactionRepository extends JpaRepository<WalletTransaction, Long> {
    List<WalletTransaction> findByUserIdOrderByCreatedAtDescIdDesc(Long userId, Pageable pageable);

    /** Every user withdrawal, newest first (admin payout queue). */
    List<WalletTransaction> findByTypeOrderByCreatedAtDescIdDesc(String type, Pageable pageable);

    List<WalletTransaction> findByTypeAndStatusOrderByCreatedAtDescIdDesc(String type, String status, Pageable pageable);

    /** Row lock: complete and fail on the same withdrawal cannot both run, and a failure refunds once. */
    @Lock(jakarta.persistence.LockModeType.PESSIMISTIC_WRITE)
    @Query("select t from WalletTransaction t where t.type = 'WITHDRAWAL' and t.reference = :reference")
    Optional<WalletTransaction> findWithdrawalForUpdate(@Param("reference") String reference);

    /**
     * Everything the user has asked to withdraw (the amount before fees) except failed requests.
     * A pending withdrawal counts: its money has already left the balance.
     */
    @Query("select coalesce(sum(t.amount), 0) from WalletTransaction t "
            + "where t.userId = :userId and t.type = 'WITHDRAWAL' and t.status <> 'FAILED'")
    BigDecimal sumWithdrawn(@Param("userId") Long userId);
}
