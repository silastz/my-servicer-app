package com.nearbyservices.repository;

import com.nearbyservices.model.ServiceFeeCredit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ServiceFeeCreditRepository extends JpaRepository<ServiceFeeCredit, Long> {
    boolean existsByReference(String reference);
}
