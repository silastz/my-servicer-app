package com.nearbyservices.repository;

import com.nearbyservices.model.VouchRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VouchRequestRepository extends JpaRepository<VouchRequest, Long> {
    List<VouchRequest> findByRequesterIdOrProviderIdOrderByCreatedAtDesc(Long requesterId, Long providerId);
    boolean existsByRequesterIdAndProviderIdAndStatus(Long requesterId, Long providerId, String status);
    long countByRequesterIdAndStatus(Long requesterId, String status);
}
