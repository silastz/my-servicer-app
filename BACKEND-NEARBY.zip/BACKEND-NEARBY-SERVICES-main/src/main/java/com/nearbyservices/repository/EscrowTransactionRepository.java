package com.nearbyservices.repository;

import com.nearbyservices.model.EscrowStatus;
import com.nearbyservices.model.EscrowTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EscrowTransactionRepository extends JpaRepository<EscrowTransaction, Long> {
    Optional<EscrowTransaction> findByTransactionRef(String transactionRef);
    /** Row lock: two taps on "pay" or "confirm" can never both move money. */
    @org.springframework.data.jpa.repository.Lock(jakarta.persistence.LockModeType.PESSIMISTIC_WRITE)
    @org.springframework.data.jpa.repository.Query("select t from EscrowTransaction t where t.transactionRef = :ref")
    Optional<EscrowTransaction> findByTransactionRefForUpdate(@org.springframework.data.repository.query.Param("ref") String ref);
    /** Bookings the provider asked to be paid whose deadline has passed. */
    List<EscrowTransaction> findByStatusAndPaymentDeadlineBefore(EscrowStatus status, java.time.LocalDateTime now);
    Optional<EscrowTransaction> findFirstByPaymentProofUrl(String paymentProofUrl);
    boolean existsByPaymentProofUrlAndTransactionRefNot(String paymentProofUrl, String transactionRef);
    List<EscrowTransaction> findByBuyerId(Long buyerId);
    List<EscrowTransaction> findBySellerId(Long sellerId);
    List<EscrowTransaction> findByBuyerIdAndStatus(Long buyerId, EscrowStatus status);
    List<EscrowTransaction> findBySellerIdAndStatus(Long sellerId, EscrowStatus status);
    /** Money held in bookings that are not finished yet. */
    @org.springframework.data.jpa.repository.Query("select coalesce(sum(t.amount), 0) from EscrowTransaction t where t.status in :statuses")
    java.math.BigDecimal sumAmountByStatusIn(@org.springframework.data.repository.query.Param("statuses") java.util.Collection<EscrowStatus> statuses);

    long countBySellerIdAndStatus(Long sellerId, EscrowStatus status);
    long countBySellerId(Long sellerId);
    long countByBuyerIdAndStatus(Long buyerId, EscrowStatus status);

    boolean existsByBuyerIdAndStatusIn(Long buyerId, java.util.Collection<EscrowStatus> statuses);
    boolean existsBySellerIdAndStatusIn(Long sellerId, java.util.Collection<EscrowStatus> statuses);
}
