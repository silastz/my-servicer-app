package com.nearbyservices.repository;

import com.nearbyservices.model.UserSearchTerm;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Repository
public interface UserSearchTermRepository extends JpaRepository<UserSearchTerm, Long> {
    Optional<UserSearchTerm> findByUserIdAndTerm(Long userId, String term);

    List<UserSearchTerm> findByUserIdOrderBySearchedAtDesc(Long userId);

    @Modifying
    @Query("delete from UserSearchTerm t where t.userId = :uid")
    int deleteByUserId(@Param("uid") Long userId);

    @Modifying
    @Query("delete from UserSearchTerm t where t.searchedAt < :before")
    int purgeBefore(@Param("before") Instant before);
}
