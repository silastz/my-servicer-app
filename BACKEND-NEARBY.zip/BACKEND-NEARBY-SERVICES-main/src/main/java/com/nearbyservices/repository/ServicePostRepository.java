package com.nearbyservices.repository;

import com.nearbyservices.model.ServicePost;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;

@Repository
public interface ServicePostRepository extends JpaRepository<ServicePost, Long>, JpaSpecificationExecutor<ServicePost> {
    Page<ServicePost> findByActiveTrue(Pageable pageable);
    List<ServicePost> findBySellerId(Long sellerId);
    boolean existsBySellerId(Long sellerId);
    long countByCategoryIgnoreCase(String category);
    /** Active services whose paid boost is still running at {@code now}. */
    List<ServicePost> findByActiveTrueAndBoostedUntilAfter(Instant now);
    List<ServicePost> findBySellerIdOrderByCreatedAtDesc(Long sellerId);
}
