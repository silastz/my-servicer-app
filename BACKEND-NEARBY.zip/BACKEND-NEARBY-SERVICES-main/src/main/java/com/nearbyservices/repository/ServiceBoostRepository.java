package com.nearbyservices.repository;

import com.nearbyservices.model.ServiceBoost;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ServiceBoostRepository extends JpaRepository<ServiceBoost, Long> {
    Optional<ServiceBoost> findByReference(String reference);
}
