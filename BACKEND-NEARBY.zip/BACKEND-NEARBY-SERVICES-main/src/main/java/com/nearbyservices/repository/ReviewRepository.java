package com.nearbyservices.repository;

import com.nearbyservices.model.Review;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {
    boolean existsByTransactionRefAndReviewerId(String transactionRef, Long reviewerId);

    List<Review> findByRevieweeIdOrderByCreatedAtDesc(Long revieweeId);

    List<Review> findByReviewerIdOrderByCreatedAtDesc(Long reviewerId);
    long countByReviewerIdAndFromBuyerTrue(Long reviewerId);

    /** What the public sees on a provider: only buyers' reviews of that provider. */
    List<Review> findByRevieweeIdAndFromBuyerTrueOrderByCreatedAtDesc(Long revieweeId, Pageable pageable);

    /** Row: [average, count]. Average is null when there are no reviews. */
    @Query("select avg(r.rating), count(r) from Review r where r.revieweeId = :id and r.fromBuyer = true")
    List<Object[]> providerStats(@Param("id") Long providerId);

    @Query("select avg(r.rating), count(r) from Review r where r.serviceId = :id and r.fromBuyer = true")
    List<Object[]> serviceStats(@Param("id") Long serviceId);
}
