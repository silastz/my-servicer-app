package com.nearbyservices.repository;

import com.nearbyservices.model.User;
import jakarta.persistence.LockModeType;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long>, JpaSpecificationExecutor<User> {
    /** Row lock, so two simultaneous publishes cannot spend the same credit. */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select u from User u where u.id = :id")
    Optional<User> findByIdForUpdate(@Param("id") Long id);

    Optional<User> findByUsername(String username);
    Optional<User> findByPhone(String phone);
    Optional<User> findByEmail(String email);
    boolean existsByUsername(String username);
    boolean existsByPhone(String phone);
    boolean existsByEmail(String email);
    boolean existsByNidaNumber(String nidaNumber);
    boolean existsByNidaNumberAndIdNot(String nidaNumber, Long id);
    java.util.List<User> findByPhoneEndingWith(String lastDigits);
    java.util.List<User> findByRole(com.nearbyservices.model.Role role);

    /**
     * Users who switched promo notifications on and were NOT sent a promo push since {@code cutoff}, in id order,
     * starting after {@code afterId} (so a caller can walk through them page by page).
     */
    @Query("select u from User u where u.notifPromos = true and u.id > :afterId "
            + "and not exists (select 1 from PromoPushLog l where l.userId = u.id and l.sentAt > :cutoff) "
            + "order by u.id")
    List<User> findPromoDue(@Param("cutoff") Instant cutoff, @Param("afterId") long afterId, Pageable pageable);
}
