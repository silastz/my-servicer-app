package com.nearbyservices.repository;

import com.nearbyservices.model.UserVerificationProfile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserVerificationProfileRepository extends JpaRepository<UserVerificationProfile, Long> {
    List<UserVerificationProfile> findByPhotoStatus(String photoStatus);
    List<UserVerificationProfile> findByBusinessStatus(String businessStatus);
}
