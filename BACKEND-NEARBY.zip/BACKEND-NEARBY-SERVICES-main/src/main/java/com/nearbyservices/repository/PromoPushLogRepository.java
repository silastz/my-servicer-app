package com.nearbyservices.repository;

import com.nearbyservices.model.PromoPushLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;

@Repository
public interface PromoPushLogRepository extends JpaRepository<PromoPushLog, Long> {

    /** What this user was already sent: rows of [serviceId, times sent, last sent]. */
    @Query("select l.serviceId, count(l), max(l.sentAt) from PromoPushLog l where l.userId = :userId group by l.serviceId")
    List<Object[]> historyOf(@Param("userId") Long userId);

    /** How often each service was pushed to anyone since a moment: rows of [serviceId, count]. */
    @Query("select l.serviceId, count(l) from PromoPushLog l where l.sentAt > :since group by l.serviceId")
    List<Object[]> countsSince(@Param("since") Instant since);

    @Modifying
    @Query("delete from PromoPushLog l where l.sentAt < :before")
    int purgeBefore(@Param("before") Instant before);
}
