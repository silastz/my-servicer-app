package com.nearbyservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NearByServicesApplication {

    public static void main(String[] args) {
        SpringApplication.run(NearByServicesApplication.class, args);
    }

}
