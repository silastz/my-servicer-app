package com.nearbyservices.verification;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminAuditEntryRepository extends JpaRepository<AdminAuditEntry, Long> {
}
