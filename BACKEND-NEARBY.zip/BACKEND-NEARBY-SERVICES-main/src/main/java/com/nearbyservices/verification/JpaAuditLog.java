package com.nearbyservices.verification;

import org.springframework.stereotype.Component;

@Component
public class JpaAuditLog implements AuditLog {
    private final AdminAuditEntryRepository repo;

    JpaAuditLog(AdminAuditEntryRepository repo) { this.repo = repo; }

    @Override
    public void record(long adminId, String action, String detail) {
        AdminAuditEntry e = new AdminAuditEntry();
        e.setAdminId(adminId);
        e.setAction(action);
        e.setDetail(detail == null ? "" : (detail.length() > 500 ? detail.substring(0, 500) : detail));
        repo.save(e);
    }
}
