package com.nearbyservices.verification;

/** The identity source could not answer (down, timeout, login rejected). Callers keep the name PENDING. */
public class IdentityServiceUnavailableException extends RuntimeException {
    public IdentityServiceUnavailableException(String message) { super(message); }
    public IdentityServiceUnavailableException(String message, Throwable cause) { super(message, cause); }
}
