package com.nearbyservices.verification;

import java.time.Instant;
import java.util.Optional;

/**
 * Where the admin-saved BRELA login lives (one row). The password arrives already encrypted by SecretBox.
 * Implement with your repository (JPA / JdbcTemplate), e.g. a table identity_lookup_settings(id, username,
 * password_cipher, updated_at, updated_by).
 */
public interface CredentialStore {
    record Stored(String username, String passwordCipher, Instant updatedAt, long updatedBy) {}

    Optional<Stored> load();

    void save(String username, String passwordCipher, long adminId);
}
