package com.nearbyservices.verification;

import org.springframework.data.jpa.repository.JpaRepository;

public interface IdentityLookupSettingsRepository extends JpaRepository<IdentityLookupSettings, Long> {
}
