package com.nearbyservices.verification;

/** Result of a NIN lookup. Never send this to the app: it holds the registered legal name. */
public record RegisteredName(boolean found, String firstName, String middleName, String surname) {
    public static RegisteredName notFound() { return new RegisteredName(false, "", "", ""); }
}
