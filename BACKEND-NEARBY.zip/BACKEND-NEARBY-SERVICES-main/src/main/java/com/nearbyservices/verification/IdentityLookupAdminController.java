package com.nearbyservices.verification;

import com.nearbyservices.security.CustomUserDetails;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Admin: change the BRELA login used for the NIN name check.
 * Locked twice: SecurityConfig (/api/admin/** needs ROLE_ADMIN) and @PreAuthorize here.
 * Never log request bodies on this controller: they hold the password.
 */
@RestController
@RequestMapping("/api/admin/identity-lookup")
@PreAuthorize("hasRole('ADMIN')")
public class IdentityLookupAdminController {
    private final IdentityLookupAdminService service;

    IdentityLookupAdminController(IdentityLookupAdminService service) { this.service = service; }

    @GetMapping
    ResponseEntity<Map<String, Object>> get() {
        return wrap(service.get());
    }

    @PutMapping
    ResponseEntity<Map<String, Object>> update(@AuthenticationPrincipal CustomUserDetails admin,
                                               @RequestBody Map<String, String> in) {
        return wrap(service.update(admin.getUser().getId(), in.get("username"), in.get("password")));
    }

    @PostMapping("/test")
    ResponseEntity<Map<String, Object>> test(@AuthenticationPrincipal CustomUserDetails admin) {
        return wrap(service.test(admin.getUser().getId()));
    }

    private static ResponseEntity<Map<String, Object>> wrap(IdentityLookupAdminService.Response r) {
        return ResponseEntity.status(r.http()).body(r.body());
    }
}
