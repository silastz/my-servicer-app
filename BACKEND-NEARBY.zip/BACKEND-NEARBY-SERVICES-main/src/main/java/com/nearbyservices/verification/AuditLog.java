package com.nearbyservices.verification;

/** Record who did what. Never put the username or password in `detail`. */
public interface AuditLog {
    void record(long adminId, String action, String detail);
}
