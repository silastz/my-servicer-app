package com.nearbyservices.verification;

import java.util.Optional;
import java.util.function.Supplier;

/**
 * Gives BrelaNinRegistry the current BRELA login: what the admin saved in the app, or, only when nothing
 * has been saved yet, an optional deployment fallback (environment variables) so the first install works.
 */
public class LookupCredentialProvider implements Supplier<BrelaNinRegistry.Credentials> {
    private final CredentialStore store;
    private final SecretBox box;
    private final BrelaNinRegistry.Credentials fallback; // may be null

    public LookupCredentialProvider(CredentialStore store, SecretBox box, BrelaNinRegistry.Credentials fallback) {
        this.store = store;
        this.box = box;
        this.fallback = fallback;
    }

    @Override
    public BrelaNinRegistry.Credentials get() {
        Optional<CredentialStore.Stored> s = store.load();
        if (s.isPresent()) {
            try {
                return new BrelaNinRegistry.Credentials(s.get().username(), box.decrypt(s.get().passwordCipher()));
            } catch (IllegalStateException e) {
                return new BrelaNinRegistry.Credentials("", ""); // wrong key / damaged value: treated as "not saved"
            }
        }
        return fallback != null ? fallback : new BrelaNinRegistry.Credentials("", "");
    }

    /** "ADMIN" (saved in the app), "CONFIG" (deployment fallback) or "NONE". */
    public String source() {
        if (store.load().isPresent()) return "ADMIN";
        return fallback != null && fallback.isComplete() ? "CONFIG" : "NONE";
    }
}
