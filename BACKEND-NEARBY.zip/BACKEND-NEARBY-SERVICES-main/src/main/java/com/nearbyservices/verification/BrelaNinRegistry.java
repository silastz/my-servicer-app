package com.nearbyservices.verification;

import java.io.IOException;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.regex.Pattern;

/**
 * NIN lookup through the BRELA ORS person search (the approach the loan system uses).
 * TLS verification stays ON (the JDK default). Credentials come from the admin settings, never from the app,
 * and are never logged. The session lives in memory and is renewed every 25 minutes or when BRELA ends it.
 *
 * jsonParser turns a JSON object into a Map; in Spring pass JsonParserFactory.getJsonParser()::parseMap.
 */
public class BrelaNinRegistry implements NinRegistry {

    private static final long SESSION_MILLIS = 25 * 60 * 1000L;
    private static final Pattern ERROR_132 = Pattern.compile("error\\s*:?\\s*132\\b", Pattern.CASE_INSENSITIVE);

    /** BRELA login. Read on every lookup, so an admin change takes effect without a restart. */
    public record Credentials(String username, String password) {
        public boolean isComplete() {
            return username != null && !username.isBlank() && password != null && !password.isBlank();
        }
    }

    /** Result of an admin "Test login". The message never contains credentials. */
    public record LoginCheck(boolean ok, String message) {}

    private final String base;
    private final Supplier<Credentials> credentials;
    private final Function<String, Map<String, Object>> jsonParser;
    private volatile Credentials loggedInWith;
    private final CookieManager cookies = new CookieManager(null, CookiePolicy.ACCEPT_ALL);
    private final HttpClient http;
    private volatile long loggedInAt = 0;

    public BrelaNinRegistry(String base, Supplier<Credentials> credentials,
                            Function<String, Map<String, Object>> jsonParser) {
        this.base = base.endsWith("/") ? base.substring(0, base.length() - 1) : base;
        this.credentials = credentials;
        this.jsonParser = jsonParser;
        this.http = HttpClient.newBuilder()
                .cookieHandler(cookies)
                .followRedirects(HttpClient.Redirect.NEVER)
                .connectTimeout(Duration.ofSeconds(8))
                .build();
    }

    /** Production constructor: credentials come from the admin settings (see LookupCredentialProvider). */
    public BrelaNinRegistry(Supplier<Credentials> credentials, Function<String, Map<String, Object>> jsonParser) {
        this("https://ors.brela.go.tz", credentials, jsonParser);
    }

    /** Fixed credentials (tests, or a deployment without the admin screen). */
    public BrelaNinRegistry(String base, String username, String password,
                            Function<String, Map<String, Object>> jsonParser) {
        this(base, () -> new Credentials(username, password), jsonParser);
    }

    @Override
    public RegisteredName lookup(String rawNin) {
        String nin = rawNin == null ? "" : rawNin.replaceAll("\\D+", "");
        if (nin.length() != 20) return RegisteredName.notFound();

        ensureSession(false);
        for (int attempt = 0; attempt < 2; attempt++) {
            HttpResponse<String> r = send(post("/ors/search/person/" + URLEncoder.encode(nin, StandardCharsets.UTF_8),
                    "{}", "application/json"));
            int code = r.statusCode();
            if (code == 303 || code == 401 || code == 403) { // session ended: log in again once
                ensureSession(true);
                continue;
            }
            if (code != 200) throw new IdentityServiceUnavailableException("lookup HTTP " + code);
            return parse(r.body());
        }
        throw new IdentityServiceUnavailableException("session could not be refreshed");
    }

    @SuppressWarnings("unchecked")
    private RegisteredName parse(String body) {
        Map<String, Object> root;
        try {
            root = jsonParser.apply(body);
        } catch (RuntimeException e) {
            throw new IdentityServiceUnavailableException("unreadable lookup response", e);
        }
        Object objRaw = root == null ? null : root.get("obj");
        Map<String, Object> obj = objRaw instanceof Map ? (Map<String, Object>) objRaw : Map.of();
        Object resRaw = obj.get("result");
        if (resRaw instanceof Map<?, ?> res && !res.isEmpty()) {
            return new RegisteredName(true, str(res.get("FIRSTNAME")), str(res.get("MIDDLENAME")), str(res.get("SURNAME")));
        }
        String err = str(obj.get("error"));
        // "Error:132" means NIDA has no such number; it is not a broken lookup.
        if (err.isEmpty() || ERROR_132.matcher(err).find()) return RegisteredName.notFound();
        throw new IdentityServiceUnavailableException("lookup error");
    }

    private static String str(Object o) { return o == null ? "" : o.toString().trim(); }

    /** Admin "Test login": forces a fresh login with the saved credentials. Sends no NIN. */
    public LoginCheck testLogin() {
        if (!credentials.get().isComplete()) {
            return new LoginCheck(false, "No BRELA username and password are saved yet.");
        }
        try {
            ensureSession(true);
            return new LoginCheck(true, "Login works.");
        } catch (IdentityServiceUnavailableException e) {
            String m = String.valueOf(e.getMessage());
            if (m.contains("rejected") || m.contains("not saved")) {
                return new LoginCheck(false, "BRELA rejected the username or password.");
            }
            return new LoginCheck(false, "Could not reach BRELA right now. Try again later.");
        }
    }

    private synchronized void ensureSession(boolean force) {
        Credentials c = credentials.get();
        if (c == null || !c.isComplete()) throw new IdentityServiceUnavailableException("credentials not saved");
        // A new username/password (changed by the admin) means the old session must go.
        boolean changed = !c.equals(loggedInWith);
        if (!force && !changed && loggedInAt != 0 && System.currentTimeMillis() - loggedInAt < SESSION_MILLIS) return;
        cookies.getCookieStore().removeAll();
        loggedInAt = 0;
        loggedInWith = null;
        // 1) open the login page to get the first cookies
        HttpResponse<String> page = send(get("/um/login?returnUrl=%2fbrela%2fprod%2fum"));
        if (page.statusCode() >= 500) throw new IdentityServiceUnavailableException("login page HTTP " + page.statusCode());
        // 2) post the credentials: BRELA answers 303 + Location on success
        String form = "username=" + URLEncoder.encode(c.username(), StandardCharsets.UTF_8)
                + "&password=" + URLEncoder.encode(c.password(), StandardCharsets.UTF_8);
        HttpResponse<String> login = send(post("/um/auth/login", form, "application/x-www-form-urlencoded"));
        if (login.statusCode() != 303) throw new IdentityServiceUnavailableException("login rejected");
        String location = login.headers().firstValue("Location").orElse("");
        if (location.isEmpty()) throw new IdentityServiceUnavailableException("login gave no redirect");
        // 3) follow the redirect so the session is fully established
        URI target = URI.create(base + "/").resolve(location);
        send(HttpRequest.newBuilder(target).GET().timeout(Duration.ofSeconds(20)).build());
        if (cookies.getCookieStore().getCookies().isEmpty()) throw new IdentityServiceUnavailableException("no session cookie");
        loggedInAt = System.currentTimeMillis();
        loggedInWith = c;
    }

    private HttpRequest get(String path) {
        return HttpRequest.newBuilder(URI.create(base + path)).GET().timeout(Duration.ofSeconds(20)).build();
    }

    private HttpRequest post(String path, String body, String contentType) {
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(base + path))
                .timeout(Duration.ofSeconds(20))
                .header("Content-Type", contentType)
                .POST(HttpRequest.BodyPublishers.ofString(body));
        if (contentType.startsWith("application/json")) {
            b.header("Accept", "application/json").header("X-Requested-With", "XMLHttpRequest");
        }
        return b.build();
    }

    private HttpResponse<String> send(HttpRequest req) {
        try {
            return http.send(req, HttpResponse.BodyHandlers.ofString());
        } catch (IOException e) {
            throw new IdentityServiceUnavailableException("registry unreachable", e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IdentityServiceUnavailableException("interrupted", e);
        }
    }
}
