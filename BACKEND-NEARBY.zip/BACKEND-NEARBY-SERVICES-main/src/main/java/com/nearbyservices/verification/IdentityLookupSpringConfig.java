package com.nearbyservices.verification;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.json.JsonParserFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Wiring for the admin-managed BRELA login. Settings (environment / secret store, never committed):
 *   UNGANA_SECRETS_KEY   REQUIRED. base64 of 32 random bytes; encrypts the BRELA password in the database.
 *                        Generate: openssl rand -base64 32   (losing it means the admin must re-enter the password)
 *   UNGANA_BRELA_USERNAME / UNGANA_BRELA_PASSWORD   OPTIONAL first-install fallback; the admin screen overrides them.
 */
@Configuration
public class IdentityLookupSpringConfig {

    @Bean
    SecretBox secretBox(@Value("${ungana.secrets.key}") String key) {
        return new SecretBox(key);
    }

    @Bean
    LookupCredentialProvider lookupCredentialProvider(CredentialStore store, SecretBox box,
            @Value("${ungana.brela.username:}") String user, @Value("${ungana.brela.password:}") String pass) {
        BrelaNinRegistry.Credentials fb = (user.isBlank() || pass.isBlank()) ? null : new BrelaNinRegistry.Credentials(user, pass);
        return new LookupCredentialProvider(store, box, fb);
    }

    @Bean
    BrelaNinRegistry brelaNinRegistry(LookupCredentialProvider credentials) {
        return new BrelaNinRegistry(credentials, JsonParserFactory.getJsonParser()::parseMap);
    }

    @Bean
    IdentityLookupAdminService identityLookupAdminService(CredentialStore store, SecretBox box,
            LookupCredentialProvider provider, BrelaNinRegistry registry, AuditLog audit) {
        return new IdentityLookupAdminService(store, box, provider, registry, audit);
    }
}
