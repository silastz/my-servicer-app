package com.nearbyservices.verification;

/** Official identity source: the name registered for a 20-digit NIN. */
public interface NinRegistry {
    /** @throws IdentityServiceUnavailableException if the source is down, slow or refuses our login */
    RegisteredName lookup(String nin);
}
