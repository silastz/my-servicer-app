package com.nearbyservices.verification;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/** The single row (id = 1) holding the admin-saved BRELA login. The password is stored encrypted (SecretBox). */
@Entity
@Table(name = "identity_lookup_settings")
@Getter
@Setter
@NoArgsConstructor
public class IdentityLookupSettings {
    static final long SINGLETON_ID = 1L;

    @Id
    private Long id = SINGLETON_ID;

    @Column(nullable = false, length = 100)
    private String username;

    @Column(name = "password_cipher", nullable = false, length = 1000)
    private String passwordCipher;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @Column(name = "updated_by", nullable = false)
    private long updatedBy;
}
