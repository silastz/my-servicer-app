package com.nearbyservices.verification;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.Optional;

@Component
public class JpaCredentialStore implements CredentialStore {
    private final IdentityLookupSettingsRepository repo;

    JpaCredentialStore(IdentityLookupSettingsRepository repo) { this.repo = repo; }

    @Override
    @Transactional(readOnly = true)
    public Optional<Stored> load() {
        return repo.findById(IdentityLookupSettings.SINGLETON_ID)
                .map(r -> new Stored(r.getUsername(), r.getPasswordCipher(), r.getUpdatedAt(), r.getUpdatedBy()));
    }

    @Override
    @Transactional
    public void save(String username, String passwordCipher, long adminId) {
        IdentityLookupSettings row = repo.findById(IdentityLookupSettings.SINGLETON_ID).orElseGet(IdentityLookupSettings::new);
        row.setId(IdentityLookupSettings.SINGLETON_ID);
        row.setUsername(username);
        row.setPasswordCipher(passwordCipher);
        row.setUpdatedAt(Instant.now());
        row.setUpdatedBy(adminId);
        repo.save(row);
    }
}
