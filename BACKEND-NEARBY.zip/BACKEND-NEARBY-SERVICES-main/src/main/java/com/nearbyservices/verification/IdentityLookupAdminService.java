package com.nearbyservices.verification;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;

/**
 * Admin screen backend: see and change the BRELA login used for the NIN name check.
 * Callers MUST already have checked ROLE_ADMIN (the controller does) and answer 403 to everyone else.
 *
 * The password is write-only: it is encrypted before saving and never returned. A missing or blank field on
 * update means "keep the saved one". Changes take effect on the next lookup, no restart needed.
 */
public class IdentityLookupAdminService {

    public record Response(int http, Map<String, Object> body) {
        static Response ok(Map<String, Object> b) { return new Response(200, b); }
        static Response error(int http, String code) { return new Response(http, Map.of("message", code)); }
    }

    // No spaces or control characters; BRELA usernames are short.
    private static final Pattern USER_OK = Pattern.compile("^[\\p{L}\\p{N}._@+\\-]{1,100}$");

    private final CredentialStore store;
    private final SecretBox box;
    private final LookupCredentialProvider provider;
    private final BrelaNinRegistry registry;
    private final AuditLog audit;

    public IdentityLookupAdminService(CredentialStore store, SecretBox box, LookupCredentialProvider provider,
                                      BrelaNinRegistry registry, AuditLog audit) {
        this.store = store;
        this.box = box;
        this.provider = provider;
        this.registry = registry;
        this.audit = audit;
    }

    /** GET: what the app shows. Never contains the password. */
    public Response get() {
        return Response.ok(view());
    }

    /** PUT {username?, password?}: change the login. */
    public Response update(long adminId, String username, String password) {
        String u = username == null ? "" : username.trim();
        String p = password == null ? "" : password; // do not trim: a password may contain spaces
        if (u.isEmpty() && p.isEmpty()) return Response.error(400, "NO_CHANGES");
        if (!u.isEmpty() && !USER_OK.matcher(u).matches()) return Response.error(422, "USERNAME_INVALID");
        if (!p.isEmpty() && (p.length() > 200 || p.chars().anyMatch(Character::isISOControl))) {
            return Response.error(422, "PASSWORD_INVALID");
        }

        // What is in effect now (saved in the app, or the deployment fallback). Blank fields keep it.
        BrelaNinRegistry.Credentials current = provider.get();
        String newUser = !u.isEmpty() ? u : current.username();
        String newPass = !p.isEmpty() ? p : current.password();
        if (newUser == null || newUser.isBlank() || newPass == null || newPass.isBlank()) {
            return Response.error(422, "CREDENTIALS_INCOMPLETE"); // a login needs both a username and a password
        }
        store.save(newUser, box.encrypt(newPass), adminId);
        // Audit what changed, never the values.
        audit.record(adminId, "IDENTITY_LOOKUP_CREDENTIALS_CHANGED",
                (u.isEmpty() ? "" : "username ") + (p.isEmpty() ? "" : "password"));
        return Response.ok(view());
    }

    /** POST /test: log in to BRELA with the saved credentials (sends no NIN). */
    public Response test(long adminId) {
        BrelaNinRegistry.LoginCheck r = registry.testLogin();
        audit.record(adminId, "IDENTITY_LOOKUP_TEST_LOGIN", r.ok() ? "ok" : "failed");
        Map<String, Object> b = new LinkedHashMap<>();
        b.put("success", r.ok());
        b.put("message", r.message());
        return Response.ok(b);
    }

    private Map<String, Object> view() {
        BrelaNinRegistry.Credentials c = provider.get();
        Optional<CredentialStore.Stored> s = store.load();
        Map<String, Object> b = new LinkedHashMap<>();
        b.put("username", c.username() == null ? "" : c.username());
        b.put("passwordSet", c.password() != null && !c.password().isBlank());
        b.put("source", provider.source());
        b.put("updatedAt", s.map(x -> x.updatedAt().toString()).orElse(null));
        return b;
    }
}
