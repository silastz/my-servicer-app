package com.nearbyservices.sms;

/**
 * The saved SMS settings, secrets already decrypted. Lives only in memory on the server:
 * it is never returned to a client (the admin view only says whether a secret is set) and never logged.
 */
public record SmsGatewayConfig(SmsProvider defaultProvider, boolean autoFailover, Meseji meseji, Beem beem) {

    public record Meseji(String apiKey, String senderId, String email, String password, double costPerSms) {
        public boolean complete() { return notBlank(apiKey) && notBlank(senderId); }
    }

    public record Beem(String apiKey, String secretKey, String senderId, double costPerSms) {
        public boolean complete() { return notBlank(apiKey) && notBlank(secretKey) && notBlank(senderId); }
    }

    public static final double DEFAULT_COST = 15;

    public static SmsGatewayConfig empty() {
        return new SmsGatewayConfig(SmsProvider.DEFAULT, true,
                new Meseji("", "", "", "", DEFAULT_COST),
                new Beem("", "", "INFO", DEFAULT_COST));
    }

    public boolean complete(SmsProvider p) {
        return p == SmsProvider.BEEM ? beem.complete() : meseji.complete();
    }

    public String senderId(SmsProvider p) {
        return p == SmsProvider.BEEM ? beem.senderId() : meseji.senderId();
    }

    private static boolean notBlank(String s) { return s != null && !s.isBlank(); }
}
