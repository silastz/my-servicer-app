package com.nearbyservices.sms;

import com.nearbyservices.verification.AuditLog;
import com.nearbyservices.service.AttemptLimiter;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Backend of the admin "SMS gateway" screen (docs/sms_gateway_api_contract.md).
 * Callers MUST already have checked ROLE_ADMIN (the controller does). Secrets are write-only:
 * they are encrypted before saving and never returned; a missing/blank secret on update keeps the saved one.
 */
@Service
public class SmsGatewayAdminService {

    public record Response(int http, Map<String, Object> body) {
        static Response ok(Map<String, Object> b) { return new Response(200, b); }
        static Response error(int http, String code) { return new Response(http, Map.of("message", code)); }
    }

    private static final Pattern BEEM_SENDER = Pattern.compile("^[A-Za-z0-9 ]{1,11}$");
    private static final Pattern MESEJI_SENDER = Pattern.compile("^[A-Za-z0-9 +\\-.]{1,20}$");
    private static final Pattern EMAIL = Pattern.compile("^[^\\s@]{1,64}@[^\\s@]{1,190}$");
    private static final double COST_MAX = 100_000;
    private static final int MAX_SECRET = 300;

    private final SmsGatewayStore store;
    private final SmsDispatcher dispatcher;
    private final SmsTransport transport;
    private final AuditLog audit;
    private final AttemptLimiter limiter;

    public SmsGatewayAdminService(SmsGatewayStore store, SmsDispatcher dispatcher, SmsTransport transport,
                                  AuditLog audit, AttemptLimiter limiter) {
        this.store = store;
        this.dispatcher = dispatcher;
        this.transport = transport;
        this.audit = audit;
        this.limiter = limiter;
    }

    public Response get() {
        return Response.ok(view(store.load()));
    }

    /** PUT. [in] may be wrapped as {"data": {...}}. Anything missing keeps its saved value. */
    @Transactional
    public Response update(long adminId, Map<String, Object> in) {
        Map<String, Object> d = in != null && in.get("data") instanceof Map<?, ?> w && in.size() == 1 ? asMap(w) : in;
        if (d == null) return Response.error(400, "INVALID_BODY");
        SmsGatewayConfig cur = store.load();
        StringBuilder changed = new StringBuilder();

        SmsProvider def = cur.defaultProvider();
        if (d.containsKey("defaultProvider")) {
            def = SmsProvider.parse(d.get("defaultProvider")).orElse(null);
            if (def == null) return Response.error(400, "INVALID_PROVIDER");
            if (def != cur.defaultProvider()) changed.append("defaultProvider ");
        }
        boolean failover = cur.autoFailover();
        if (d.containsKey("autoFailover")) {
            if (!(d.get("autoFailover") instanceof Boolean b)) return Response.error(400, "INVALID_AUTO_FAILOVER");
            if (b != failover) changed.append("autoFailover ");
            failover = b;
        }

        Object mo = d.get("meseji");
        if (mo != null && !(mo instanceof Map)) return Response.error(400, "INVALID_MESEJI");
        Object bo = d.get("beem");
        if (bo != null && !(bo instanceof Map)) return Response.error(400, "INVALID_BEEM");
        Map<String, Object> mj = mo == null ? Map.of() : asMap(mo);
        Map<String, Object> bm = bo == null ? Map.of() : asMap(bo);

        SmsGatewayConfig.Meseji m = cur.meseji();
        try {
            String key = secret(mj, "apiKey", m.apiKey());
            String pass = secret(mj, "password", m.password());
            String sender = text(mj, "senderId", m.senderId(), 20);
            String email = text(mj, "email", m.email(), 254);
            double cost = cost(mj, m.costPerSms());
            if (!sender.isEmpty() && !MESEJI_SENDER.matcher(sender).matches()) return Response.error(422, "MESEJI_SENDER_INVALID");
            if (!email.isEmpty() && !EMAIL.matcher(email).matches()) return Response.error(422, "MESEJI_EMAIL_INVALID");
            if (!key.equals(m.apiKey())) changed.append("meseji.apiKey ");
            if (!pass.equals(m.password())) changed.append("meseji.password ");
            if (!sender.equals(m.senderId()) || !email.equals(m.email()) || cost != m.costPerSms()) changed.append("meseji.settings ");
            m = new SmsGatewayConfig.Meseji(key, sender, email, pass, cost);
        } catch (IllegalArgumentException e) {
            return Response.error(422, "MESEJI_" + e.getMessage());
        }

        SmsGatewayConfig.Beem b = cur.beem();
        try {
            String key = secret(bm, "apiKey", b.apiKey());
            String sec = secret(bm, "secretKey", b.secretKey());
            String sender = text(bm, "senderId", b.senderId(), 11);
            double cost = cost(bm, b.costPerSms());
            if (!sender.isEmpty() && !BEEM_SENDER.matcher(sender).matches()) return Response.error(422, "BEEM_SENDER_INVALID");
            if (!key.equals(b.apiKey())) changed.append("beem.apiKey ");
            if (!sec.equals(b.secretKey())) changed.append("beem.secretKey ");
            if (!sender.equals(b.senderId()) || cost != b.costPerSms()) changed.append("beem.settings ");
            b = new SmsGatewayConfig.Beem(key, sec, sender, cost);
        } catch (IllegalArgumentException e) {
            return Response.error(422, "BEEM_" + e.getMessage());
        }

        SmsGatewayConfig next = new SmsGatewayConfig(def, failover, m, b);
        // Never make a provider the default while it could not send.
        if (!next.complete(def)) return Response.error(422, "DEFAULT_PROVIDER_INCOMPLETE");

        store.save(next, String.valueOf(adminId));
        // Audit what changed, never the values.
        audit.record(adminId, "SMS_CONFIG_CHANGED", changed.length() == 0 ? "no changes" : changed.toString().trim());
        return Response.ok(view(next));
    }

    /** POST /test-connection {provider}: logs in / reads the balance with the saved credentials, sends no SMS. */
    public Response testConnection(long adminId, Map<String, Object> in) {
        SmsProvider p = in == null ? null : SmsProvider.parse(in.get("provider")).orElse(null);
        if (p == null) return Response.error(400, "INVALID_PROVIDER");
        limiter.hit("sms-conn:" + adminId, 30, 3_600_000L);
        SmsGatewayConfig c = store.load();
        if (!c.complete(p)) return Response.ok(result(false, p + " is not fully set up yet. Save its credentials first."));
        SmsTransport.Result r = transport.checkConnection(p, c);
        audit.record(adminId, "SMS_TEST_CONNECTION", p + (r.ok() ? " ok" : " failed"));
        return Response.ok(result(r.ok(), r.message()));
    }

    /** POST /test-send {provider, phone}: one real SMS with exactly that provider (no failover). 5 per hour per admin. */
    public Response testSend(long adminId, Map<String, Object> in) {
        SmsProvider p = in == null ? null : SmsProvider.parse(in.get("provider")).orElse(null);
        if (p == null) return Response.error(400, "INVALID_PROVIDER");
        if (!(in.get("phone") instanceof String raw) || raw.isBlank()) return Response.error(400, "PHONE_REQUIRED");
        String phone = com.nearbyservices.service.SmsService.normalizePhoneNumber(raw.trim());
        limiter.hit("sms-test:" + adminId, 5, 3_600_000L);
        SmsGatewayConfig c = store.load();
        SmsDispatcher.Outcome o = dispatcher.sendWith(p, c, phone, "NearByServices: huu ni ujumbe wa majaribio kutoka kwa msimamizi. Test SMS from the admin.");
        audit.record(adminId, "SMS_TEST_SEND", p + " to " + mask(phone) + (o.ok() ? " ok" : " failed"));
        return Response.ok(result(o.ok(), o.ok() ? "Test SMS sent." : o.message()));
    }

    // ---------------------------------------------------------------- helpers

    private Map<String, Object> view(SmsGatewayConfig c) {
        Map<String, Object> mj = new LinkedHashMap<>();
        mj.put("apiKeySet", !c.meseji().apiKey().isBlank());
        mj.put("passwordSet", !c.meseji().password().isBlank());
        mj.put("senderId", c.meseji().senderId());
        mj.put("email", c.meseji().email());
        mj.put("costPerSms", c.meseji().costPerSms());
        Map<String, Object> bm = new LinkedHashMap<>();
        bm.put("apiKeySet", !c.beem().apiKey().isBlank());
        bm.put("secretSet", !c.beem().secretKey().isBlank());
        bm.put("senderId", c.beem().senderId());
        bm.put("costPerSms", c.beem().costPerSms());
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("defaultProvider", c.defaultProvider().name());
        out.put("autoFailover", c.autoFailover());
        out.put("meseji", mj);
        out.put("beem", bm);
        return out;
    }

    private static Map<String, Object> result(boolean ok, String message) {
        Map<String, Object> b = new LinkedHashMap<>();
        b.put("success", ok);
        b.put("message", message);
        return b;
    }

    /** Missing / null / blank = keep [current]. Not trimmed in the middle; control characters are refused. */
    private static String secret(Map<String, Object> m, String field, String current) {
        Object v = m.get(field);
        if (v == null) return current;
        if (!(v instanceof String s)) throw new IllegalArgumentException(field.toUpperCase() + "_INVALID");
        if (s.isBlank()) return current;
        String t = s.trim();
        if (t.length() > MAX_SECRET || t.chars().anyMatch(Character::isISOControl)) {
            throw new IllegalArgumentException(field.toUpperCase() + "_INVALID");
        }
        return t;
    }

    private static String text(Map<String, Object> m, String field, String current, int max) {
        if (!m.containsKey(field) || m.get(field) == null) return current;
        if (!(m.get(field) instanceof String s)) throw new IllegalArgumentException(field.toUpperCase() + "_INVALID");
        String t = s.trim();
        if (t.length() > max || t.chars().anyMatch(Character::isISOControl)) throw new IllegalArgumentException(field.toUpperCase() + "_INVALID");
        return t;
    }

    private static double cost(Map<String, Object> m, double current) {
        Object v = m.get("costPerSms");
        if (v == null) return current;
        double x;
        if (v instanceof Number n) x = n.doubleValue();
        else {
            try { x = Double.parseDouble(String.valueOf(v).trim().replace(',', '.')); }
            catch (NumberFormatException e) { throw new IllegalArgumentException("COST_INVALID"); }
        }
        if (Double.isNaN(x) || x < 0 || x > COST_MAX) throw new IllegalArgumentException("COST_INVALID");
        return x;
    }

    static String mask(String phone) {
        if (phone == null || phone.length() < 8) return "****";
        return phone.substring(0, 4) + "****" + phone.substring(phone.length() - 3);
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> asMap(Object o) {
        return (Map<String, Object>) o;
    }
}
