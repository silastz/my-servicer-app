package com.nearbyservices.sms;

/** Talks to one provider. Split from the rules so the failover logic can be tested without a network. */
public interface SmsTransport {

    /** [message] is a short text safe to show the admin and to log (never a secret, never the SMS text). */
    record Result(boolean ok, String message) {
        public static Result ok(String m) { return new Result(true, m); }
        public static Result fail(String m) { return new Result(false, m); }
    }

    /** Sends one SMS with [provider]'s own credentials and sender ID. [e164Phone] looks like +255712345678. */
    Result send(SmsProvider provider, SmsGatewayConfig config, String e164Phone, String text);

    /** Logs in / reads the balance with the saved credentials. Sends no SMS. */
    Result checkConnection(SmsProvider provider, SmsGatewayConfig config);
}
