package com.nearbyservices.sms;

import com.nearbyservices.security.CustomUserDetails;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Admin: SMS provider settings (docs/sms_gateway_api_contract.md in the app project, docs/SMS_GATEWAY.md here).
 * Locked twice: SecurityConfig (/api/admin/** needs ROLE_ADMIN) and @PreAuthorize here.
 * Never log request bodies on this controller: they hold API keys and passwords.
 */
@RestController
@RequestMapping("/api/admin/sms")
@PreAuthorize("hasRole('ADMIN')")
public class SmsGatewayAdminController {
    private final SmsGatewayAdminService service;

    SmsGatewayAdminController(SmsGatewayAdminService service) { this.service = service; }

    @GetMapping("/config")
    ResponseEntity<Map<String, Object>> get() {
        return wrap(service.get());
    }

    @PutMapping("/config")
    ResponseEntity<Map<String, Object>> update(@AuthenticationPrincipal CustomUserDetails admin,
                                               @RequestBody Map<String, Object> in) {
        return wrap(service.update(admin.getUser().getId(), in));
    }

    @PostMapping("/test-connection")
    ResponseEntity<Map<String, Object>> testConnection(@AuthenticationPrincipal CustomUserDetails admin,
                                                       @RequestBody Map<String, Object> in) {
        return wrap(service.testConnection(admin.getUser().getId(), in));
    }

    @PostMapping("/test-send")
    ResponseEntity<Map<String, Object>> testSend(@AuthenticationPrincipal CustomUserDetails admin,
                                                 @RequestBody Map<String, Object> in) {
        return wrap(service.testSend(admin.getUser().getId(), in));
    }

    private static ResponseEntity<Map<String, Object>> wrap(SmsGatewayAdminService.Response r) {
        return ResponseEntity.status(r.http()).body(r.body());
    }
}
