package com.nearbyservices.sms;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.regex.Pattern;

/**
 * Sends one SMS with the admin's chosen provider and, if that fails, once with the other provider
 * (its own sender ID) when autoFailover is on and the other provider's credentials are saved.
 * A bad phone number or an over-long message is rejected before any call, so it is never retried.
 */
@Service
public class SmsDispatcher {
    private static final Logger log = LoggerFactory.getLogger(SmsDispatcher.class);
    private static final Pattern E164 = Pattern.compile("^\\+[1-9]\\d{7,14}$");
    static final int MAX_MESSAGE_CHARS = 640;

    /** [provider] is the one that really sent it (null when nothing was sent). */
    public record Outcome(boolean ok, SmsProvider provider, boolean failedOver, String message) {}

    private final SmsGatewayStore store;
    private final SmsTransport transport;

    public SmsDispatcher(SmsGatewayStore store, SmsTransport transport) {
        this.store = store;
        this.transport = transport;
    }

    /** True when the admin saved settings and the chosen default provider is complete. Otherwise the old env settings are used. */
    public boolean isConfigured() {
        if (!store.hasSavedConfig()) return false;
        SmsGatewayConfig c = store.load();
        return c.complete(c.defaultProvider());
    }

    public Outcome send(String e164Phone, String text) {
        return send(store.load(), e164Phone, text);
    }

    Outcome send(SmsGatewayConfig c, String e164Phone, String text) {
        String bad = validate(e164Phone, text);
        if (bad != null) return new Outcome(false, null, false, bad);

        SmsProvider first = c.defaultProvider();
        String firstReason;
        if (c.complete(first)) {
            SmsTransport.Result r = transport.send(first, c, e164Phone, text);
            if (r.ok()) return new Outcome(true, first, false, r.message());
            firstReason = r.message();
        } else {
            firstReason = first + " is not fully set up.";
        }

        SmsProvider backup = first.other();
        if (!c.autoFailover() || !c.complete(backup)) {
            return new Outcome(false, null, false, firstReason);
        }
        log.warn("SMS failed with {}; trying {}", first, backup);
        SmsTransport.Result r2 = transport.send(backup, c, e164Phone, text);
        if (r2.ok()) {
            log.info("SMS sent by {} after {} failed", backup, first);
            return new Outcome(true, backup, true, r2.message());
        }
        return new Outcome(false, null, false, firstReason + " " + r2.message());
    }

    /** Sends with exactly one provider, no failover (the admin's test button). */
    public Outcome sendWith(SmsProvider provider, SmsGatewayConfig c, String e164Phone, String text) {
        String bad = validate(e164Phone, text);
        if (bad != null) return new Outcome(false, null, false, bad);
        if (!c.complete(provider)) return new Outcome(false, null, false, provider + " is not fully set up.");
        SmsTransport.Result r = transport.send(provider, c, e164Phone, text);
        return new Outcome(r.ok(), r.ok() ? provider : null, false, r.message());
    }

    private static String validate(String phone, String text) {
        if (phone == null || !E164.matcher(phone).matches()) return "The phone number is not valid.";
        if (text == null || text.isBlank()) return "The message is empty.";
        if (text.length() > MAX_MESSAGE_CHARS) return "The message is too long.";
        return null;
    }
}
