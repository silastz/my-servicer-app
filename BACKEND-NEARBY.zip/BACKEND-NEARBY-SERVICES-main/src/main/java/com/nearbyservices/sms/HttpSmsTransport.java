package com.nearbyservices.sms;

import com.nearbyservices.payment.MiniJson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The real calls:
 *   Beem   POST https://apisms.beem.africa/v1/send (Basic auth apiKey:secret), balance GET .../public/v1/vendors/balance
 *   Meseji POST {api-url}/sms/send with the x-api-key header
 * Never logs a key, a secret, a request body or the SMS text.
 */
@Component
public class HttpSmsTransport implements SmsTransport {
    private static final Logger log = LoggerFactory.getLogger(HttpSmsTransport.class);

    private final RestTemplate http;
    private final String mesejiApiUrl;
    private final String beemSendUrl;
    private final String beemBalanceUrl;

    public HttpSmsTransport(
            @Value("${app.sms.meseji.api-url:https://kzjgdeqfmxkmpmadtbpb.supabase.co/functions/v1/sms-api}") String mesejiApiUrl,
            @Value("${app.sms.beem.send-url:https://apisms.beem.africa/v1/send}") String beemSendUrl,
            @Value("${app.sms.beem.balance-url:https://apisms.beem.africa/public/v1/vendors/balance}") String beemBalanceUrl) {
        SimpleClientHttpRequestFactory f = new SimpleClientHttpRequestFactory();
        f.setConnectTimeout(5_000);
        f.setReadTimeout(15_000);
        this.http = new RestTemplate(f);
        this.mesejiApiUrl = mesejiApiUrl.endsWith("/") ? mesejiApiUrl.substring(0, mesejiApiUrl.length() - 1) : mesejiApiUrl;
        this.beemSendUrl = beemSendUrl;
        this.beemBalanceUrl = beemBalanceUrl;
    }

    @Override
    public Result send(SmsProvider provider, SmsGatewayConfig c, String phone, String text) {
        return provider == SmsProvider.BEEM ? sendBeem(c.beem(), phone, text) : sendMeseji(c.meseji(), phone, text);
    }

    @Override
    public Result checkConnection(SmsProvider provider, SmsGatewayConfig c) {
        return provider == SmsProvider.BEEM ? beemBalance(c.beem()) : mesejiCheck(c.meseji());
    }

    // ---------------------------------------------------------------- Beem

    private Result sendBeem(SmsGatewayConfig.Beem b, String phone, String text) {
        Map<String, Object> recipient = new LinkedHashMap<>();
        recipient.put("recipient_id", 1);
        recipient.put("dest_addr", phone.startsWith("+") ? phone.substring(1) : phone);
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("source_addr", b.senderId());
        body.put("schedule_time", "");
        body.put("encoding", 0);
        body.put("message", text);
        body.put("recipients", List.of(recipient));
        try {
            ResponseEntity<String> r = http.postForEntity(beemSendUrl, new HttpEntity<>(body, beemHeaders(b)), String.class);
            Object parsed = parse(r.getBody());
            if (parsed instanceof Map<?, ?> m && Boolean.FALSE.equals(m.get("successful"))) {
                return Result.fail("Beem refused the SMS" + reason(m));
            }
            return Result.ok("Sent with Beem.");
        } catch (HttpStatusCodeException e) {
            return Result.fail(httpFailure("Beem", e));
        } catch (RestClientException e) {
            return Result.fail("Beem could not be reached.");
        }
    }

    private Result beemBalance(SmsGatewayConfig.Beem b) {
        try {
            ResponseEntity<String> r = http.exchange(beemBalanceUrl, org.springframework.http.HttpMethod.GET,
                    new HttpEntity<>(beemHeaders(b)), String.class);
            Object parsed = parse(r.getBody());
            Object credit = null;
            if (parsed instanceof Map<?, ?> m) {
                Object data = m.get("data");
                credit = data instanceof Map<?, ?> dm ? dm.get("credit_balance") : m.get("credit_balance");
            }
            return Result.ok(credit == null ? "Beem connected." : "Beem connected. Balance: " + credit + " credits.");
        } catch (HttpStatusCodeException e) {
            return Result.fail(httpFailure("Beem", e));
        } catch (RestClientException e) {
            return Result.fail("Beem could not be reached.");
        }
    }

    private static HttpHeaders beemHeaders(SmsGatewayConfig.Beem b) {
        HttpHeaders h = new HttpHeaders();
        h.setContentType(MediaType.APPLICATION_JSON);
        String pair = b.apiKey() + ":" + b.secretKey();
        h.set(HttpHeaders.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString(pair.getBytes(StandardCharsets.UTF_8)));
        return h;
    }

    // -------------------------------------------------------------- Meseji

    private Result sendMeseji(SmsGatewayConfig.Meseji m, String phone, String text) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("phone_number", phone);
        body.put("message", text);
        body.put("sender_id", m.senderId());
        body.put("priority", 1);
        try {
            ResponseEntity<String> r = http.postForEntity(mesejiApiUrl + "/sms/send", new HttpEntity<>(body, mesejiHeaders(m)), String.class);
            Object parsed = parse(r.getBody());
            if (parsed instanceof Map<?, ?> map && Boolean.FALSE.equals(map.get("success"))) {
                return Result.fail("Meseji refused the SMS" + reason(map));
            }
            return Result.ok("Sent with Meseji.");
        } catch (HttpStatusCodeException e) {
            return Result.fail(httpFailure("Meseji", e));
        } catch (RestClientException e) {
            return Result.fail("Meseji could not be reached.");
        }
    }

    /**
     * Meseji's contract only names the send call, so there is no balance call to rely on. This asks
     * {api-url}/balance with the key: 2xx = connected, 401/403 = key refused, anything else = unknown
     * (the admin should use "Send test SMS" to be sure).
     */
    private Result mesejiCheck(SmsGatewayConfig.Meseji m) {
        try {
            ResponseEntity<String> r = http.exchange(mesejiApiUrl + "/balance", org.springframework.http.HttpMethod.GET,
                    new HttpEntity<>(mesejiHeaders(m)), String.class);
            Object parsed = parse(r.getBody());
            Object bal = null;
            if (parsed instanceof Map<?, ?> map) {
                Object data = map.get("data");
                bal = data instanceof Map<?, ?> dm ? (dm.get("balance") != null ? dm.get("balance") : dm.get("credit_balance")) : map.get("balance");
            }
            return Result.ok(bal == null ? "Meseji connected." : "Meseji connected. Balance: " + bal + " credits.");
        } catch (HttpStatusCodeException e) {
            int s = e.getStatusCode().value();
            if (s == 401 || s == 403) return Result.fail("Meseji refused the API key.");
            return Result.fail("Could not check Meseji (HTTP " + s + "). Use \"Send test SMS\" to confirm it works.");
        } catch (RestClientException e) {
            return Result.fail("Meseji could not be reached.");
        }
    }

    private static HttpHeaders mesejiHeaders(SmsGatewayConfig.Meseji m) {
        HttpHeaders h = new HttpHeaders();
        h.setContentType(MediaType.APPLICATION_JSON);
        h.set("x-api-key", m.apiKey());
        return h;
    }

    // ------------------------------------------------------------- helpers

    private static Object parse(String body) {
        if (body == null || body.isBlank()) return null;
        try {
            return MiniJson.parse(body);
        } catch (RuntimeException e) {
            return null; // a non-JSON 2xx answer still counts as accepted
        }
    }

    /** " (reason)" from the provider's own message field, trimmed; empty when there is none. */
    private static String reason(Map<?, ?> m) {
        Object msg = m.get("message");
        if (msg == null) msg = m.get("error");
        if (msg == null) return ".";
        String s = String.valueOf(msg).replaceAll("[\\r\\n]+", " ").trim();
        return s.isEmpty() ? "." : " (" + (s.length() > 120 ? s.substring(0, 120) : s) + ").";
    }

    private static String httpFailure(String name, HttpStatusCodeException e) {
        int s = e.getStatusCode().value();
        log.warn("{} answered HTTP {}", name, s);
        if (s == 401 || s == 403) return name + " refused the credentials.";
        return name + " rejected the request (HTTP " + s + ").";
    }
}
