package com.nearbyservices.sms;

import com.nearbyservices.model.AppConfigEntry;
import com.nearbyservices.repository.AppConfigRepository;
import com.nearbyservices.verification.SecretBox;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * Keeps the SMS settings in the app_config table, one row per field ("sms.beem.sender" ...).
 * Secrets (API keys, passwords) are encrypted with the same SecretBox as the BRELA login
 * (UNGANA_SECRETS_KEY) before they are saved. These rows are not reachable through any public route.
 */
@Component
public class SmsGatewayStore {
    private static final Logger log = LoggerFactory.getLogger(SmsGatewayStore.class);

    static final String DEFAULT = "sms.default";
    static final String FAILOVER = "sms.failover";
    static final String M_KEY = "sms.meseji.apikey";
    static final String M_PASS = "sms.meseji.password";
    static final String M_SENDER = "sms.meseji.sender";
    static final String M_EMAIL = "sms.meseji.email";
    static final String M_COST = "sms.meseji.cost";
    static final String B_KEY = "sms.beem.apikey";
    static final String B_SECRET = "sms.beem.secret";
    static final String B_SENDER = "sms.beem.sender";
    static final String B_COST = "sms.beem.cost";

    private final AppConfigRepository repo;
    private final SecretBox box;

    public SmsGatewayStore(AppConfigRepository repo, SecretBox box) {
        this.repo = repo;
        this.box = box;
    }

    public SmsGatewayConfig load() {
        SmsGatewayConfig d = SmsGatewayConfig.empty();
        return new SmsGatewayConfig(
                get(DEFAULT).flatMap(SmsProvider::parse).orElse(d.defaultProvider()),
                get(FAILOVER).map(v -> !v.equals("false")).orElse(true),
                new SmsGatewayConfig.Meseji(
                        secret(M_KEY), get(M_SENDER).orElse(""), get(M_EMAIL).orElse(""), secret(M_PASS),
                        cost(M_COST)),
                new SmsGatewayConfig.Beem(
                        secret(B_KEY), secret(B_SECRET), get(B_SENDER).orElse(d.beem().senderId()),
                        cost(B_COST)));
    }

    /** Saves every field of [c]. The caller has already validated it. */
    public void save(SmsGatewayConfig c, String adminName) {
        put(DEFAULT, c.defaultProvider().name(), adminName);
        put(FAILOVER, String.valueOf(c.autoFailover()), adminName);
        putSecret(M_KEY, c.meseji().apiKey(), adminName);
        putSecret(M_PASS, c.meseji().password(), adminName);
        put(M_SENDER, c.meseji().senderId(), adminName);
        put(M_EMAIL, c.meseji().email(), adminName);
        put(M_COST, String.valueOf(c.meseji().costPerSms()), adminName);
        putSecret(B_KEY, c.beem().apiKey(), adminName);
        putSecret(B_SECRET, c.beem().secretKey(), adminName);
        put(B_SENDER, c.beem().senderId(), adminName);
        put(B_COST, String.valueOf(c.beem().costPerSms()), adminName);
    }

    /** True once the admin has saved something (until then the old environment settings keep sending). */
    public boolean hasSavedConfig() {
        return repo.existsById(DEFAULT);
    }

    // ------------------------------------------------------------------

    private Optional<String> get(String key) {
        return repo.findById(key).map(AppConfigEntry::getValue);
    }

    private String secret(String key) {
        Optional<String> stored = get(key).filter(v -> !v.isBlank());
        if (stored.isEmpty()) return "";
        try {
            return box.decrypt(stored.get());
        } catch (IllegalStateException e) {
            // Wrong UNGANA_SECRETS_KEY or damaged value: treat as "not set" so the admin re-enters it.
            log.warn("Could not decrypt saved SMS secret {}; it must be entered again", key);
            return "";
        }
    }

    private double cost(String key) {
        try {
            return get(key).map(Double::parseDouble).orElse(SmsGatewayConfig.DEFAULT_COST);
        } catch (NumberFormatException e) {
            return SmsGatewayConfig.DEFAULT_COST;
        }
    }

    private void put(String key, String value, String by) {
        repo.save(new AppConfigEntry(key, value == null ? "" : value, by));
    }

    private void putSecret(String key, String plain, String by) {
        put(key, plain == null || plain.isEmpty() ? "" : box.encrypt(plain), by);
    }
}
