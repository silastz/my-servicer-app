package com.nearbyservices.sms;

import java.util.Locale;
import java.util.Optional;

/** The two providers the admin can choose from. MESEJI is the default when nothing is saved. */
public enum SmsProvider {
    MESEJI, BEEM;

    public static final SmsProvider DEFAULT = MESEJI;

    public SmsProvider other() {
        return this == MESEJI ? BEEM : MESEJI;
    }

    /** Exact names only (case does not matter): anything else is rejected, never guessed. */
    public static Optional<SmsProvider> parse(Object raw) {
        if (!(raw instanceof String s)) return Optional.empty();
        try {
            return Optional.of(valueOf(s.trim().toUpperCase(Locale.ROOT)));
        } catch (IllegalArgumentException e) {
            return Optional.empty();
        }
    }
}
