package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.ChatMessage;
import com.nearbyservices.model.ChatMute;
import com.nearbyservices.model.User;
import com.nearbyservices.repository.ChatMessageRepository;
import com.nearbyservices.repository.ChatMuteRepository;
import com.nearbyservices.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
@RequiredArgsConstructor
public class ChatService {

    private final ChatMessageRepository chatMessageRepository;
    private final UserRepository userRepository;
    private final UserBlockService userBlockService;
    private final ChatMuteRepository chatMuteRepository;
    private final PushService pushService;
    private final ChatSocketRegistry chatSocketRegistry;
    private final ChatDeliveryService deliveryService;

    @Transactional
    public Map<String, Object> sendMessage(User sender, Long recipientId, String messageText) {
        return sendMessage(sender, recipientId, messageText, null);
    }

    @Transactional
    public Map<String, Object> sendMessage(User sender, Long recipientId, String messageText, Long replyToId) {
        return sendMessage(sender, recipientId, messageText, replyToId, null);
    }

    @Transactional
    public Map<String, Object> sendMessage(User sender, Long recipientId, String messageText, Long replyToId, String clientId) {
        String cid = clientId == null || clientId.isBlank() ? null : (clientId.length() > 64 ? clientId.substring(0, 64) : clientId);
        if (cid != null) {
            // a retry of a message that was already saved: answer with the saved copy, send nothing twice
            Optional<ChatMessage> already = chatMessageRepository.findFirstBySenderIdAndClientId(sender.getId(), cid);
            if (already.isPresent()) return mapMessage(already.get(), sender.getId());
        }
        User recipient = userRepository.findById(recipientId)
                .orElseThrow(() -> new IllegalArgumentException("Recipient not found with ID: " + recipientId));

        if (userBlockService.isBlockedEitherWay(sender.getId(), recipient.getId())) {
            throw com.nearbyservices.exception.ApiException.forbidden("USER_BLOCKED");
        }

        if (messageText == null || messageText.isBlank()) throw ApiException.badRequest("INVALID_REQUEST");

        Long replyTo = null;
        if (replyToId != null) {
            ChatMessage original = chatMessageRepository.findById(replyToId)
                    .orElseThrow(() -> ApiException.notFound("MESSAGE_NOT_FOUND"));
            // you can only answer a message of this very conversation
            if (!inConversation(original, sender.getId(), recipient.getId())) throw ApiException.badRequest("INVALID_REQUEST");
            replyTo = original.getId();
        }

        ChatMessage msg = ChatMessage.builder()
                .sender(sender)
                .recipient(recipient)
                .message(messageText)
                .replyToId(replyTo)
                .clientId(cid)
                .isRead(false)
                .build();

        ChatMessage saved = chatMessageRepository.save(msg);
        notifyRecipient(sender, recipient, messageText);
        pushChat("message", sender.getId(), recipient.getId(), saved.getId());
        return mapMessage(saved, sender.getId());
    }

    /**
     * Tells both people's open apps that this conversation changed. Runs only AFTER the database
     * commit: the app re-reads the chat the moment it hears this, and must find the new data.
     */
    private void pushChat(String event, Long actorId, Long otherId) {
        pushChat(event, actorId, otherId, null);
    }

    /** [messageId] is given for a new message: if the recipient is online it counts as delivered at once. */
    private void pushChat(String event, Long actorId, Long otherId, Long messageId) {
        Runnable send = () -> {
            try {
                String json = ChatSocketRegistry.chatEvent(event, actorId, otherId);
                chatSocketRegistry.push(otherId, json);
                chatSocketRegistry.push(actorId, json); // my other phones
                if (messageId != null && chatSocketRegistry.isOnline(otherId)
                        && deliveryService.markMessageDelivered(messageId)) {
                    // second tick for the sender
                    chatSocketRegistry.push(actorId, ChatSocketRegistry.chatEvent("delivered", otherId, actorId));
                }
            } catch (RuntimeException ignored) {
                // live updates are a bonus: the app also re-reads on a timer
            }
        };
        if (TransactionSynchronizationManager.isSynchronizationActive()) {
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override
                public void afterCommit() {
                    send.run();
                }
            });
        } else {
            send.run();
        }
    }

    private static final java.time.Duration EDIT_WINDOW = java.time.Duration.ofMinutes(15);

    /** The sender changes the text of a message. Text only, own messages only, within 15 minutes. */
    @Transactional
    public Map<String, Object> editMessage(User me, Long messageId, String newText) {
        ChatMessage m = chatMessageRepository.findById(messageId).orElseThrow(() -> ApiException.notFound("MESSAGE_NOT_FOUND"));
        if (!m.getSender().getId().equals(me.getId())) throw ApiException.forbidden("NOT_YOUR_MESSAGE");
        if (hiddenFor(m, me.getId())) throw ApiException.notFound("MESSAGE_NOT_FOUND");
        String t = newText == null ? "" : newText.trim();
        if (t.isEmpty() || t.length() > 4000) throw ApiException.badRequest("INVALID_REQUEST");
        if (looksLikeAttachment(m.getMessage())) throw ApiException.badRequest("ONLY_TEXT_CAN_BE_EDITED");
        if (m.getCreatedAt() != null && java.time.LocalDateTime.now().isAfter(m.getCreatedAt().plus(EDIT_WINDOW))) {
            throw ApiException.badRequest("EDIT_WINDOW_PASSED");
        }
        if (userBlockService.isBlockedEitherWay(me.getId(), m.getRecipient().getId())) throw ApiException.forbidden("USER_BLOCKED");
        if (!t.equals(m.getMessage())) {
            m.setMessage(t);
            m.setEditedAt(java.time.LocalDateTime.now());
            chatMessageRepository.save(m);
            pushChat("edited", me.getId(), m.getRecipient().getId());
        }
        return mapMessage(m, me.getId());
    }

    /**
     * Delete a message "for me": it disappears from my view only. Once both people have deleted it,
     * it is deleted permanently from the database. Returns true when that happened.
     */
    @Transactional
    public boolean deleteMessage(User me, Long messageId) {
        ChatMessage m = chatMessageRepository.findById(messageId).orElseThrow(() -> ApiException.notFound("MESSAGE_NOT_FOUND"));
        boolean iAmSender = m.getSender().getId().equals(me.getId());
        boolean iAmRecipient = m.getRecipient().getId().equals(me.getId());
        if (!iAmSender && !iAmRecipient) throw ApiException.forbidden("NOT_YOUR_MESSAGE");
        if (iAmSender) m.setHiddenForSender(true);
        if (iAmRecipient) m.setHiddenForRecipient(true);
        Long otherId = iAmSender ? m.getRecipient().getId() : m.getSender().getId();
        if (m.isHiddenForSender() && m.isHiddenForRecipient()) {
            chatMessageRepository.delete(m);
            pushChat("deleted", me.getId(), otherId);
            return true;
        }
        chatMessageRepository.save(m);
        pushChat("deleted", me.getId(), otherId);
        return false;
    }

    private static boolean inConversation(ChatMessage m, Long a, Long b) {
        Long s = m.getSender().getId(), r = m.getRecipient().getId();
        return (s.equals(a) && r.equals(b)) || (s.equals(b) && r.equals(a));
    }

    private static boolean looksLikeAttachment(String text) {
        String t = text == null ? "" : text.trim();
        return t.contains("/uploads/") && t.chars().noneMatch(Character::isWhitespace);
    }

    private static boolean hiddenFor(ChatMessage m, Long userId) {
        return m.getSender().getId().equals(userId) ? m.isHiddenForSender() : m.isHiddenForRecipient();
    }

    /** Mute (or unmute) push notifications from one person. Messages keep arriving; idempotent. */
    @Transactional
    public void setMuted(User me, Long otherUserId, boolean muted) {
        if (me.getId().equals(otherUserId)) throw ApiException.badRequest("INVALID_REQUEST");
        if (!userRepository.existsById(otherUserId)) throw ApiException.notFound("USER_NOT_FOUND");
        if (!muted) {
            chatMuteRepository.deletePair(me.getId(), otherUserId);
            return;
        }
        if (chatMuteRepository.existsByUserIdAndMutedUserId(me.getId(), otherUserId)) return;
        try {
            chatMuteRepository.saveAndFlush(ChatMute.builder().userId(me.getId()).mutedUserId(otherUserId).build());
        } catch (DataIntegrityViolationException raced) {
            // a parallel request muted first: same result
        }
    }

    /** Push for a new message, unless the recipient muted the sender. Never breaks sending. */
    private void notifyRecipient(User sender, User recipient, String text) {
        try {
            if (chatMuteRepository.existsByUserIdAndMutedUserId(recipient.getId(), sender.getId())) return;
            String name = sender.getStageName() != null && !sender.getStageName().isBlank() ? sender.getStageName() : sender.getUsername();
            String[] preview = previewOf(text);
            pushService.toUser(recipient.getId(),
                    new PushService.Text(name, name),
                    new PushService.Text(preview[0], preview[1]),
                    Map.of("type", "message", "id", sender.getId().toString()));
        } catch (RuntimeException ignored) {
            // a notification problem must never fail the message itself
        }
    }

    /** {English, Swahili} one-line preview. Attachment links show a label instead of the link. */
    private static String[] previewOf(String text) {
        String t = text == null ? "" : text.trim();
        if (t.contains("/uploads/") && t.chars().noneMatch(Character::isWhitespace)) {
            if (t.contains("#k=a") || t.contains("&k=a")) return new String[]{"🎤 Voice message", "🎤 Ujumbe wa sauti"};
            if (t.contains("#k=f") || t.contains("&k=f") || t.contains("/uploads/chat/files/")) return new String[]{"📎 Document", "📎 Faili"};
            return new String[]{"📷 Photo", "📷 Picha"};
        }
        String cut = t.length() > 120 ? t.substring(0, 120) + "…" : t;
        return new String[]{cut, cut};
    }

    @Transactional
    public List<Map<String, Object>> getConversationMessages(User currentUser, Long otherUserId) {
        // Opening the conversation = the other person's messages are delivered and read.
        int newlyRead = chatMessageRepository.markRead(currentUser.getId(), otherUserId, java.time.LocalDateTime.now());
        if (newlyRead > 0) pushChat("read", currentUser.getId(), otherUserId); // their ticks turn to "read" at once
        List<ChatMessage> list = chatMessageRepository.findConversationBetween(currentUser.getId(), otherUserId);
        return list.stream()
                .filter(m -> !hiddenFor(m, currentUser.getId()))
                .map(m -> mapMessage(m, currentUser.getId())).toList();
    }

    @Transactional
    public List<Map<String, Object>> getUserConversations(User currentUser) {
        // The app just received the chat list: everything addressed to me has reached my phone.
        chatMessageRepository.markDelivered(currentUser.getId(), java.time.LocalDateTime.now());
        List<ChatMessage> allMessages = chatMessageRepository.findAllByUser(currentUser.getId());
        // People I blocked disappear from my list (the history stays stored; unblocking brings it back).
        java.util.Set<Long> iBlocked = userBlockService.blockedBy(currentUser.getId());
        allMessages = allMessages.stream().filter(m -> !hiddenFor(m, currentUser.getId())).filter(m -> {
            Long partnerId = m.getSender().getId().equals(currentUser.getId()) ? m.getRecipient().getId() : m.getSender().getId();
            return !iBlocked.contains(partnerId);
        }).toList();
        Map<Long, ChatMessage> latestByPartner = new LinkedHashMap<>();

        for (ChatMessage m : allMessages) {
            Long partnerId = m.getSender().getId().equals(currentUser.getId()) 
                    ? m.getRecipient().getId() 
                    : m.getSender().getId();
            if (!latestByPartner.containsKey(partnerId)) {
                latestByPartner.put(partnerId, m);
            }
        }

        List<Map<String, Object>> result = new ArrayList<>();
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("hh:mm a");

        for (Map.Entry<Long, ChatMessage> entry : latestByPartner.entrySet()) {
            ChatMessage latest = entry.getValue();
            User partner = latest.getSender().getId().equals(currentUser.getId())
                    ? latest.getRecipient()
                    : latest.getSender();

            Map<String, Object> conv = new HashMap<>();
            conv.put("id", partner.getId().toString());
            conv.put("conversationId", partner.getId().toString());
            conv.put("lastMessage", latest.getMessage());
            conv.put("time", latest.getCreatedAt() != null ? latest.getCreatedAt().format(timeFormatter) : "Recent");
            conv.put("unreadCount", (!latest.isRead() && latest.getRecipient().getId().equals(currentUser.getId())) ? 1 : 0);

            Map<String, Object> partnerMap = new HashMap<>();
            partnerMap.put("id", partner.getId());
            partnerMap.put("username", partner.getUsername());
            partnerMap.put("stageName", partner.getStageName() != null ? partner.getStageName() : partner.getUsername());
            // The chat list and the notification bell show the green dot from this (same flag PublicUserDto sends).
            partnerMap.put("isOnline", chatSocketRegistry.isOnline(partner.getId()));
            conv.put("recipient", partnerMap);

            result.add(conv);
        }

        return result;
    }

    private Map<String, Object> mapMessage(ChatMessage m, Long currentUserId) {
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("hh:mm a");
        Map<String, Object> map = new HashMap<>();
        map.put("id", m.getId());
        map.put("isMe", m.getSender().getId().equals(currentUserId));
        map.put("text", m.getMessage());
        map.put("content", m.getMessage());
        // For my own messages: "sent" (stored), "delivered" (reached their phone), "read" (they opened the chat).
        map.put("status", m.isRead() ? "read" : (m.getDeliveredAt() != null ? "delivered" : "sent"));
        map.put("isRead", m.isRead());
        if (m.getDeliveredAt() != null) map.put("deliveredAt", m.getDeliveredAt());
        if (m.getReadAt() != null) map.put("readAt", m.getReadAt());
        map.put("edited", m.getEditedAt() != null);
        if (m.getEditedAt() != null) map.put("editedAt", m.getEditedAt());
        if (m.getReplyToId() != null) {
            chatMessageRepository.findById(m.getReplyToId()).ifPresent(o -> {
                Map<String, Object> r = new HashMap<>();
                r.put("id", o.getId());
                r.put("senderId", o.getSender().getId());
                r.put("isMe", o.getSender().getId().equals(currentUserId));
                // a quoted message I deleted on my side shows as deleted in my view
                boolean gone = hiddenFor(o, currentUserId);
                r.put("deleted", gone);
                String t = gone ? "" : o.getMessage();
                r.put("text", t.length() > 300 ? t.substring(0, 300) : t);
                map.put("replyTo", r);
            });
        }
        map.put("senderId", m.getSender().getId());
        map.put("recipientId", m.getRecipient().getId());
        map.put("time", m.getCreatedAt() != null ? m.getCreatedAt().format(timeFormatter) : "Now");
        map.put("createdAt", m.getCreatedAt());
        return map;
    }
}
