package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.User;
import com.nearbyservices.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * An admin's own switches for the admin alerts (see {@link AdminAlerts}). Callers MUST already have checked
 * ROLE_ADMIN (the controller does). Each admin changes only their own switches.
 */
@Service
@RequiredArgsConstructor
public class AdminNotificationPrefsService {

    private final UserRepository userRepository;

    @Transactional(readOnly = true)
    public Map<String, Object> get(long adminId) {
        return json(load(adminId));
    }

    /**
     * Body: any of {reports, disputes, withdrawals, payments} as true/false. Not sent = unchanged; unknown keys are
     * ignored. A value that is not true/false answers 400 INVALID_PREFERENCE and changes nothing.
     */
    @Transactional
    public Map<String, Object> update(long adminId, Map<String, Object> body) {
        User u = load(adminId);
        Boolean reports = flag(body, "reports");
        Boolean disputes = flag(body, "disputes");
        Boolean withdrawals = flag(body, "withdrawals");
        Boolean payments = flag(body, "payments");
        if (reports != null) u.setNotifAdminReports(reports);
        if (disputes != null) u.setNotifAdminDisputes(disputes);
        if (withdrawals != null) u.setNotifAdminWithdrawals(withdrawals);
        if (payments != null) u.setNotifAdminPayments(payments);
        return json(userRepository.save(u));
    }

    private User load(long adminId) {
        return userRepository.findById(adminId).orElseThrow(() -> ApiException.notFound("USER_NOT_FOUND"));
    }

    private static Boolean flag(Map<String, Object> body, String key) {
        Object v = body == null ? null : body.get(key);
        if (v == null) return null;
        if (v instanceof Boolean b) return b;
        throw ApiException.badRequest("INVALID_PREFERENCE");
    }

    private static Map<String, Object> json(User u) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("reports", u.isNotifAdminReports());
        m.put("disputes", u.isNotifAdminDisputes());
        m.put("withdrawals", u.isNotifAdminWithdrawals());
        m.put("payments", u.isNotifAdminPayments());
        return m;
    }
}
