package com.nearbyservices.service;

import com.nearbyservices.dto.ProviderFeesDto;
import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.AdminSettings;
import com.nearbyservices.payment.PaymentGateway;
import com.nearbyservices.repository.AdminSettingsRepository;
import com.nearbyservices.verification.AuditLog;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Locale;

/** The two admin-controlled payment settings: which gateway is on, and the provider fees and withdrawal limits. */
@Service
@RequiredArgsConstructor
public class PaymentSettingsService {

    public static final long DEFAULT_WITHDRAW_MIN = 1000;

    private static final BigDecimal MAX_COLLECTION = new BigDecimal("20");
    private static final BigDecimal MAX_VAT = new BigDecimal("50");
    private static final long MAX_PAYOUT_FEE = 1_000_000;
    private static final long LIMIT_FLOOR = 100;
    private static final long LIMIT_CEILING = 100_000_000;

    private final AdminSettingsService adminSettingsService;
    private final AdminSettingsRepository adminSettingsRepository;
    private final List<PaymentGateway> gateways;
    private final AuditLog auditLog;

    @Value("${payments.snippe.fallback-email:no-reply@example.com}")
    private String configuredFallbackEmail;

    @Value("${payments.gateway:SANDBOX}")
    private String configuredGateway;

    // ---------------------------------------------------------------- gateway

    /** The gateway payments use right now: the admin's choice, else payments.gateway from the config. */
    public String activeGatewayId() {
        String chosen = adminSettingsService.getSettings().getPaymentGateway();
        return chosen != null && !chosen.isBlank() ? chosen : configuredGateway;
    }

    /** Only gateways that really have an implementation can be switched on. */
    public List<String> availableGateways() {
        return gateways.stream().map(PaymentGateway::id).map(i -> i.toUpperCase(Locale.ROOT)).sorted().toList();
    }

    @Transactional
    public String setGateway(long adminId, String requested) {
        String id = requested == null ? "" : requested.trim().toUpperCase(Locale.ROOT);
        if (!availableGateways().contains(id)) throw ApiException.badRequest("PAYMENT_GATEWAY_NOT_AVAILABLE");
        AdminSettings s = adminSettingsService.getSettings();
        String before = activeGatewayId();
        s.setPaymentGateway(id);
        adminSettingsRepository.save(s);
        auditLog.record(adminId, "PAYMENT_GATEWAY_CHANGED", before + " -> " + id);
        return id;
    }

    // ---------------------------------------------------------------- payer email

    /** The email sent to the gateway for a payer with no email: {email, source: admin|env}. */
    public java.util.Map<String, String> fallbackEmail() {
        String admin = adminSettingsService.getSettings().getPaymentFallbackEmail();
        boolean fromAdmin = admin != null && !admin.isBlank();
        return java.util.Map.of("email", fromAdmin ? admin : configuredFallbackEmail, "source", fromAdmin ? "admin" : "env");
    }

    @Transactional
    public java.util.Map<String, String> setFallbackEmail(long adminId, String email) {
        String before = fallbackEmail().get("email");
        adminSettingsService.updatePaymentFallbackEmail(email);
        java.util.Map<String, String> now = fallbackEmail();
        auditLog.record(adminId, "PAYMENT_EMAIL_CHANGED", before + " -> " + now.get("email"));
        return now;
    }

    // ---------------------------------------------------------------- card payments

    /** False until the admin switches card payments on. */
    public boolean cardEnabled() {
        return adminSettingsService.getSettings().isCardPaymentsEnabled();
    }

    @Transactional
    public boolean setCardEnabled(long adminId, boolean enabled) {
        AdminSettings s = adminSettingsService.getSettings();
        boolean before = s.isCardPaymentsEnabled();
        s.setCardPaymentsEnabled(enabled);
        adminSettingsRepository.save(s);
        auditLog.record(adminId, "CARD_PAYMENTS_CHANGED", before + " -> " + enabled);
        return enabled;
    }

    // ---------------------------------------------------------------- provider fees

    public ProviderFeesDto fees() {
        return toDto(adminSettingsService.getSettings());
    }

    /** Fields left out (null) keep their current value. Everything is validated before anything is saved. */
    @Transactional
    public ProviderFeesDto setFees(long adminId, ProviderFeesDto in) {
        AdminSettings s = adminSettingsService.getSettings();
        ProviderFeesDto before = toDto(s);

        BigDecimal collection = in.getCollectionPercent() != null ? in.getCollectionPercent() : s.getProviderCollectionPercent();
        BigDecimal vat = in.getVatPercent() != null ? in.getVatPercent() : s.getProviderVatPercent();
        long payout = in.getPayoutFee() != null ? in.getPayoutFee() : s.getProviderPayoutFee();
        long min = in.getWithdrawMin() != null ? in.getWithdrawMin() : s.getWithdrawMin();
        long max = in.getWithdrawMax() != null ? in.getWithdrawMax() : s.getWithdrawMax();

        if (collection.signum() < 0 || collection.compareTo(MAX_COLLECTION) > 0) throw ApiException.badRequest("INVALID_COLLECTION_PERCENT");
        if (vat.signum() < 0 || vat.compareTo(MAX_VAT) > 0) throw ApiException.badRequest("INVALID_VAT_PERCENT");
        if (payout < 0 || payout > MAX_PAYOUT_FEE) throw ApiException.badRequest("INVALID_PAYOUT_FEE");
        if (!validLimit(min)) throw ApiException.badRequest("INVALID_WITHDRAW_MIN");
        if (!validLimit(max)) throw ApiException.badRequest("INVALID_WITHDRAW_MAX");
        long effectiveMin = min > 0 ? min : DEFAULT_WITHDRAW_MIN;
        if (max > 0 && max < effectiveMin) throw ApiException.badRequest("WITHDRAW_MAX_BELOW_MIN");

        s.setProviderCollectionPercent(collection.setScale(2, java.math.RoundingMode.HALF_UP));
        s.setProviderVatPercent(vat.setScale(2, java.math.RoundingMode.HALF_UP));
        s.setProviderPayoutFee(payout);
        s.setWithdrawMin(min);
        s.setWithdrawMax(max);
        adminSettingsRepository.save(s);

        ProviderFeesDto after = toDto(s);
        auditLog.record(adminId, "PROVIDER_FEES_CHANGED", "before " + describe(before) + " after " + describe(after));
        return after;
    }

    /** The range a provider may withdraw at once, from the admin's current values. max = null means no maximum. */
    public record WithdrawLimits(long min, Long max) {}

    public WithdrawLimits withdrawLimits() {
        AdminSettings s = adminSettingsService.getSettings();
        return new WithdrawLimits(s.getWithdrawMin() > 0 ? s.getWithdrawMin() : DEFAULT_WITHDRAW_MIN,
                s.getWithdrawMax() > 0 ? s.getWithdrawMax() : null);
    }

    private static boolean validLimit(long v) {
        return v == 0 || (v >= LIMIT_FLOOR && v <= LIMIT_CEILING);
    }

    private static ProviderFeesDto toDto(AdminSettings s) {
        ProviderFeesDto d = new ProviderFeesDto();
        d.setCollectionPercent(s.getProviderCollectionPercent().stripTrailingZeros());
        d.setVatPercent(s.getProviderVatPercent().stripTrailingZeros());
        d.setPayoutFee(s.getProviderPayoutFee());
        d.setWithdrawMin(s.getWithdrawMin());
        d.setWithdrawMax(s.getWithdrawMax());
        return d;
    }

    private static String describe(ProviderFeesDto d) {
        return "collection=" + d.getCollectionPercent().toPlainString() + "% vat=" + d.getVatPercent().toPlainString()
                + "% payout=" + d.getPayoutFee() + " min=" + d.getWithdrawMin() + " max=" + d.getWithdrawMax();
    }
}
