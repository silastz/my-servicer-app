package com.nearbyservices.service;

import com.nearbyservices.dto.PublicUserDto;
import com.nearbyservices.dto.ServicePostRequest;
import com.nearbyservices.dto.ServicePostResponse;
import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.Role;
import com.nearbyservices.model.ServicePost;
import com.nearbyservices.model.User;
import com.nearbyservices.repository.ServicePostRepository;
import com.nearbyservices.repository.UserRepository;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Predicate;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

@Service
@RequiredArgsConstructor
public class ServiceMarketplaceService {

    private static final Set<String> PRICE_TYPES = Set.of("FIXED", "STARTING_FROM", "PER_HOUR");
    private static final Set<String> SERVICE_MODES = Set.of("customer_comes", "provider_travels", "both");
    private static final Pattern HHMM = Pattern.compile("^([01]\\d|2[0-3]):[0-5]\\d$");
    private static final int MAX_PAGE_SIZE = 50;

    private final ServicePostRepository servicePostRepository;
    private final VerificationService verificationService;
    private final UserRepository userRepository;
    private final ServiceFeeService serviceFeeService;
    private final ReviewService reviewService;
    private final UserBlockService userBlockService;
    private final ServiceCategoryAdminService categoryService;

    // ------------------------------------------------------------------------------------------
    // Publish / edit
    // ------------------------------------------------------------------------------------------

    @Transactional
    public ServicePostResponse createService(User seller, ServicePostRequest request) {
        // 402 when a per-service fee is due; otherwise counts this service and spends a credit if needed.
        seller = serviceFeeService.chargeForNewService(seller);
        if (seller.getRole() == Role.ROLE_BUYER) {
            seller.setRole(Role.ROLE_SELLER);
            userRepository.save(seller);
        }

        ServicePost post = ServicePost.builder()
                .seller(seller)
                .active(true)
                .build();
        applyRequest(post, request, true);
        seedCoordinatesFromSeller(post, seller);
        post.set18Plus(Boolean.TRUE.equals(request.getIs18Plus()) || seller.is18Plus());

        ServicePost saved = servicePostRepository.save(post);
        return mapToResponse(saved, seller, null, null);
    }

    @Transactional
    public ServicePostResponse updateService(Long id, User seller, ServicePostRequest request) {
        ServicePost post = servicePostRepository.findById(id)
                .orElseThrow(() -> ApiException.notFound("SERVICE_NOT_FOUND"));

        // Ensure user is the owner or an admin
        if (!post.getSeller().getId().equals(seller.getId()) && seller.getRole() != Role.ROLE_ADMIN) {
            throw ApiException.forbidden("NOT_SERVICE_OWNER");
        }

        applyRequest(post, request, false);
        seedCoordinatesFromSeller(post, post.getSeller());
        if (request.getIs18Plus() != null) {
            post.set18Plus(request.getIs18Plus() || post.getSeller().is18Plus());
        }

        ServicePost updated = servicePostRepository.save(post);
        return mapToResponse(updated, seller, null, null);
    }

    /**
     * The app does not send latitude/longitude with the service form. Without coordinates the service has no
     * distance and drops out of nearby search, so a service that still has none takes the provider's last
     * saved location (PUT /users/me/location). Coordinates the app does send are never overwritten.
     */
    private void seedCoordinatesFromSeller(ServicePost post, User seller) {
        if (post.getLatitude() != null && post.getLongitude() != null) return;
        if (seller == null || seller.getLastLatitude() == null || seller.getLastLongitude() == null) return;
        post.setLatitude(seller.getLastLatitude());
        post.setLongitude(seller.getLastLongitude());
    }

    /**
     * Copies the form onto the service.
     *
     * Fields the app ALWAYS sends (even empty, so clearing them on edit works) are written as they
     * come, null included. The other optional fields are only written when present, so an older
     * app that does not know them never wipes them.
     */
    private void applyRequest(ServicePost post, ServicePostRequest r, boolean creating) {
        post.setTitle(r.getTitle().trim());
        post.setDescription(r.getDescription().trim());
        // A NEW service (or a changed category) must use a category the admin keeps switched on.
        String category = r.getCategory().trim();
        if ((creating || !category.equalsIgnoreCase(post.getCategory())) && !categoryService.allowsNewService(category)) {
            throw ApiException.badRequest("INVALID_CATEGORY");
        }
        post.setCategory(categoryService.canonical(category));
        post.setPrice(r.getPrice());

        // Always-sent fields
        post.setShortDescription(blankToNull(r.getShortDescription()));
        post.setOtherLanguage(blankToNull(r.getOtherLanguage()));
        post.setDurationMinutes(r.getDurationMinutes());
        if (r.getFeatures() != null || creating) {
            replaceAll(post.getFeatures(), cleanTexts(r.getFeatures(), 100, 30));
        }
        if (r.getTasks() != null || creating) {
            replaceAll(post.getTasks(), cleanTasks(r.getTasks()));
        }
        applyPricing(post, r);

        // Optional fields: only when present
        if (r.getCity() != null) post.setCity(blankToNull(r.getCity()));
        if (r.getRegion() != null) post.setRegion(blankToNull(r.getRegion()));
        if (r.getArea() != null) post.setArea(blankToNull(r.getArea()));
        if (r.getLatitude() != null) {
            if (r.getLatitude() < -90 || r.getLatitude() > 90) throw ApiException.badRequest("INVALID_LATITUDE");
            post.setLatitude(r.getLatitude());
        }
        if (r.getLongitude() != null) {
            if (r.getLongitude() < -180 || r.getLongitude() > 180) throw ApiException.badRequest("INVALID_LONGITUDE");
            post.setLongitude(r.getLongitude());
        }
        if (r.getServiceRadiusKm() != null) post.setServiceRadiusKm(r.getServiceRadiusKm());

        if (r.getPriceType() != null && !r.getPriceType().isBlank()) {
            String pt = r.getPriceType().trim().toUpperCase(Locale.ROOT);
            if (!PRICE_TYPES.contains(pt)) throw ApiException.badRequest("INVALID_PRICE_TYPE");
            post.setPriceType(pt);
        }
        if (r.getServiceMode() != null && !r.getServiceMode().isBlank()) {
            String sm = r.getServiceMode().trim().toLowerCase(Locale.ROOT);
            if (!SERVICE_MODES.contains(sm)) throw ApiException.badRequest("INVALID_SERVICE_MODE");
            post.setServiceMode(sm);
        }
        if (r.getAvailableDays() != null) {
            replaceAll(post.getAvailableDays(), cleanTexts(r.getAvailableDays(), 20, 7));
        }
        if (r.getAvailableFrom() != null) post.setAvailableFrom(cleanTime(r.getAvailableFrom()));
        if (r.getAvailableTo() != null) post.setAvailableTo(cleanTime(r.getAvailableTo()));

        // Contacts. An empty text clears the contact; null (not sent) leaves it alone.
        if (r.getPhone() != null) post.setPhone(blankToNull(r.getPhone()));
        if (r.getWhatsappPhone() != null) post.setWhatsappPhone(blankToNull(r.getWhatsappPhone()));
        if (r.getEmail() != null) post.setEmail(blankToNull(r.getEmail()));
        if (r.getInstagramUsername() != null) post.setInstagramUsername(cleanHandle(r.getInstagramUsername()));
        if (r.getFacebookUsername() != null) post.setFacebookUsername(cleanHandle(r.getFacebookUsername()));
        if (r.getTiktokUsername() != null) post.setTiktokUsername(cleanHandle(r.getTiktokUsername()));
        if (r.getTwitterUsername() != null) post.setXUsername(cleanHandle(r.getTwitterUsername()));
        if (r.getYoutubeUsername() != null) post.setYoutubeUsername(cleanHandle(r.getYoutubeUsername()));
        if (r.getIsInfoLocked() != null) post.setIsInfoLocked(r.getIsInfoLocked());

        // Media
        if (r.getImageUrls() != null || creating) {
            replaceAll(post.getImageUrls(), cleanMediaUrls(r.getImageUrls()));
        }
        if (r.getVideoUrls() != null || creating) {
            replaceAll(post.getVideoUrls(), cleanMediaUrls(r.getVideoUrls()));
        }
        if (r.getFeaturedImageUrl() != null && !r.getFeaturedImageUrl().isBlank()) {
            post.setFeaturedImageUrl(r.getFeaturedImageUrl().trim());
        }
        // The featured picture must still be one of the service's pictures (it may have been removed).
        if (post.getFeaturedImageUrl() != null && !post.getImageUrls().contains(post.getFeaturedImageUrl())) {
            post.setFeaturedImageUrl(null);
        }
    }

    /** Discount and price offers. Always applied (the app sends them with every save). */
    private void applyPricing(ServicePost post, ServicePostRequest r) {
        Integer pct = r.getDiscountPercent();
        post.setDiscountPercent(pct);
        if (pct == null) {
            post.setDiscountValidUntil(null);
        } else {
            Instant until = r.getDiscountValidUntil();
            if (until != null && !until.isAfter(Instant.now())) {
                throw ApiException.badRequest("DISCOUNT_END_IN_PAST");
            }
            post.setDiscountValidUntil(until);
        }

        boolean allow = !Boolean.FALSE.equals(r.getAllowOffers());
        post.setAllowOffers(allow);

        BigDecimal min = positiveOrNull(r.getMinOfferPrice());
        BigDecimal auto = positiveOrNull(r.getAutoAcceptPrice());
        if (!allow) { // offers off: the private limits mean nothing
            min = null;
            auto = null;
        }
        if (min != null && min.compareTo(r.getPrice()) > 0) {
            throw ApiException.badRequest("MIN_OFFER_ABOVE_PRICE");
        }
        if (min != null && auto != null && auto.compareTo(min) < 0) {
            throw ApiException.badRequest("AUTO_ACCEPT_BELOW_MIN_OFFER");
        }
        post.setMinOfferPrice(min);
        post.setAutoAcceptPrice(auto);
    }

    // ------------------------------------------------------------------------------------------
    // Reading
    // ------------------------------------------------------------------------------------------

    @Transactional(readOnly = true)
    public Page<ServicePostResponse> getAllActiveServices(String query, String category, String city,
                                                          Double lat, Double lng, Integer radiusKm,
                                                          boolean includeSensitive,
                                                          User viewer, Pageable pageable) {
        // The sort is applied inside the specification below (boosted services first), so the page itself is unsorted.
        final Sort requestedSort = pageable.getSort().isSorted() ? pageable.getSort() : Sort.by(Sort.Direction.DESC, "createdAt");
        Pageable page = PageRequest.of(
                Math.max(0, pageable.getPageNumber()),
                Math.min(Math.max(1, pageable.getPageSize()), MAX_PAGE_SIZE));

        boolean hasFix = lat != null && lng != null
                && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180;

        // Providers the viewer blocked, or who blocked the viewer, never show up for that viewer.
        final Set<Long> hiddenSellers = viewer == null ? Set.of() : userBlockService.blockedEitherWay(viewer.getId());

        Specification<ServicePost> spec = (root, q, cb) -> {
            List<Predicate> p = new ArrayList<>();
            p.add(cb.isTrue(root.get("active")));
            // A provider an admin suspended disappears from search (the services stay in the database).
            p.add(cb.isNull(root.get("seller").get("suspendedAt")));
            if (!hiddenSellers.isEmpty()) {
                p.add(cb.not(root.get("seller").get("id").in(hiddenSellers)));
            }
            if (!includeSensitive) {
                p.add(cb.isFalse(root.get("is18Plus")));
            }
            if (category != null && !category.isBlank()) {
                p.add(cb.equal(cb.lower(root.get("category")), category.trim().toLowerCase(Locale.ROOT)));
            }
            if (city != null && !city.isBlank()) {
                p.add(cb.equal(cb.lower(root.get("city")), city.trim().toLowerCase(Locale.ROOT)));
            }
            if (query != null && !query.isBlank()) {
                String like = "%" + escapeLike(query.trim().toLowerCase(Locale.ROOT)) + "%";
                List<Predicate> any = new ArrayList<>();
                for (String field : new String[]{"title", "description", "shortDescription", "otherLanguage",
                        "category", "city", "area"}) {
                    Expression<String> e = cb.lower(root.<String>get(field));
                    any.add(cb.like(e, like, '\\'));
                }
                p.add(cb.or(any.toArray(new Predicate[0])));
            }
            if (hasFix && radiusKm != null && radiusKm > 0) {
                // Cheap box around the caller (exact distance is worked out for each result below).
                // Services that have no coordinates stay in: they are found by city instead.
                double dLat = radiusKm / 111.0;
                double dLng = radiusKm / (111.0 * Math.max(0.1, Math.cos(Math.toRadians(lat))));
                Predicate noCoords = cb.or(cb.isNull(root.get("latitude")), cb.isNull(root.get("longitude")));
                Predicate inBox = cb.and(
                        cb.between(root.<Double>get("latitude"), lat - dLat, lat + dLat),
                        cb.between(root.<Double>get("longitude"), lng - dLng, lng + dLng));
                p.add(cb.or(noCoords, inBox));
            }
            // Boosted services first on EVERY page (a boost that has ended counts as not boosted),
            // then the caller's sort, then id so pages never repeat or skip a row.
            // Only the data query is ordered; the count query behind the page total must not be.
            if (q.getResultType() != Long.class && q.getResultType() != long.class) {
                List<jakarta.persistence.criteria.Order> order = new ArrayList<>();
                order.add(cb.desc(cb.<Integer>selectCase()
                        .when(cb.greaterThan(root.<Instant>get("boostedUntil"), Instant.now()), 1)
                        .otherwise(0)));
                for (Sort.Order o : requestedSort) {
                    try {
                        jakarta.persistence.criteria.Path<Object> path = root.get(o.getProperty());
                        order.add(o.isAscending() ? cb.asc(path) : cb.desc(path));
                    } catch (IllegalArgumentException unknownProperty) {
                        // ignore a sort field that does not exist
                    }
                }
                order.add(cb.desc(root.get("id")));
                q.orderBy(order);
            }
            return cb.and(p.toArray(new Predicate[0]));
        };

        return servicePostRepository.findAll(spec, page)
                .map(post -> mapToResponse(post, viewer, hasFix ? lat : null, hasFix ? lng : null));
    }

    @Transactional(readOnly = true)
    public ServicePostResponse getServiceById(Long id, User viewer) {
        ServicePost post = servicePostRepository.findById(id)
                .orElseThrow(() -> ApiException.notFound("SERVICE_NOT_FOUND"));
        // A paused service is only visible to its owner / an admin.
        if (!post.isActive() && !isOwnerOrAdmin(post, viewer)) {
            throw ApiException.notFound("SERVICE_NOT_FOUND");
        }
        if (post.getSeller().isSuspended() && !isOwnerOrAdmin(post, viewer)) {
            throw ApiException.notFound("SERVICE_NOT_FOUND");
        }
        if (viewer != null && !isOwnerOrAdmin(post, viewer)
                && userBlockService.isBlockedEitherWay(viewer.getId(), post.getSeller().getId())) {
            throw ApiException.notFound("SERVICE_NOT_FOUND");
        }
        return mapToResponse(post, viewer, null, null);
    }

    @Transactional(readOnly = true)
    public List<ServicePostResponse> getSellerServices(User seller) {
        return servicePostRepository.findBySellerIdOrderByCreatedAtDesc(seller.getId()).stream()
                .map(p -> mapToResponse(p, seller, null, null))
                .toList();
    }

    /**
     * Builds the JSON for one service.
     *  - The owner (and admins) always see their own contacts, coordinates and private offer limits.
     *  - Everyone else sees contacts only when the service is not locked.
     */
    public ServicePostResponse mapToResponse(ServicePost post, User viewer, Double viewerLat, Double viewerLng) {
        PublicUserDto sellerDto = verificationService.mapToSellerDto(post.getSeller());
        ReviewService.Stats sellerStats = reviewService.statsForProvider(post.getSeller().getId());
        sellerDto.setRating(sellerStats.average());
        sellerDto.setReviewsCount(sellerStats.count());
        sellerDto.setBadges(BadgeRules.earned(sellerStats.average(), sellerStats.count()));
        ReviewService.Stats serviceStats = reviewService.statsForService(post.getId());

        boolean owner = isOwnerOrAdmin(post, viewer);
        boolean serviceLocked = Boolean.TRUE.equals(post.getIsInfoLocked());
        // Locked service OR locked provider profile: contacts stay hidden from the public.
        boolean locked = serviceLocked || post.getSeller().isProfileLocked();
        boolean showContacts = owner || !locked;
        // A service with no contact of its own uses the provider's profile contacts, but only while the profile is
        // unlocked (a locked profile never gives its phone or social links away, not even to its owner's preview).
        User profile = post.getSeller();
        boolean useProfile = showContacts && !profile.isProfileLocked();

        Double distanceKm = null;
        if (viewerLat != null && viewerLng != null && post.getLatitude() != null && post.getLongitude() != null) {
            double d = haversineKm(viewerLat, viewerLng, post.getLatitude(), post.getLongitude());
            // A locked service must not give away its exact spot through repeated distance checks.
            distanceKm = showContacts ? Math.round(d * 10.0) / 10.0 : Math.max(1.0, Math.ceil(d));
        }

        // Hide a finished discount from the public (the owner still sees it so they can change it).
        Integer pct = post.getDiscountPercent();
        Instant until = post.getDiscountValidUntil();
        boolean expired = until != null && !until.isAfter(Instant.now());
        if (!owner && expired) {
            pct = null;
            until = null;
        }

        Instant boostEnd = post.getBoostedUntil();
        if (boostEnd != null && !boostEnd.isAfter(Instant.now())) boostEnd = null;

        return ServicePostResponse.builder()
                .id(post.getId())
                .title(post.getTitle())
                .description(post.getDescription())
                .shortDescription(post.getShortDescription())
                .otherLanguage(post.getOtherLanguage())
                .category(post.getCategory())
                .price(post.getPrice())
                .discountPercent(pct)
                .discountValidUntil(until)
                .allowOffers(!Boolean.FALSE.equals(post.getAllowOffers()))
                .minOfferPrice(owner ? post.getMinOfferPrice() : null)
                .autoAcceptPrice(owner ? post.getAutoAcceptPrice() : null)
                .city(post.getCity())
                .region(post.getRegion())
                .area(post.getArea())
                .serviceRadiusKm(post.getServiceRadiusKm())
                .latitude(showContacts ? post.getLatitude() : null)
                .longitude(showContacts ? post.getLongitude() : null)
                .distanceKm(distanceKm)
                .priceType(post.getPriceType())
                .serviceMode(post.getServiceMode())
                .durationMinutes(post.getDurationMinutes())
                .availableDays(new ArrayList<>(post.getAvailableDays()))
                .availableFrom(post.getAvailableFrom())
                .availableTo(post.getAvailableTo())
                .features(new ArrayList<>(post.getFeatures()))
                .tasks(taskViews(post))
                .infoLocked(serviceLocked)
                .contactsVisible(showContacts)
                .phone(showContacts ? firstFilled(post.getPhone(), useProfile ? profile.getPhone() : null) : null)
                .whatsappPhone(showContacts ? firstFilled(post.getWhatsappPhone(), useProfile ? profile.getSocialWhatsapp() : null) : null)
                .email(showContacts ? post.getEmail() : null)
                .instagramUsername(showContacts ? firstFilled(post.getInstagramUsername(), useProfile ? profile.getSocialInstagram() : null) : null)
                .facebookUsername(showContacts ? firstFilled(post.getFacebookUsername(), useProfile ? profile.getSocialFacebook() : null) : null)
                .tiktokUsername(showContacts ? firstFilled(post.getTiktokUsername(), useProfile ? profile.getSocialTiktok() : null) : null)
                .twitterUsername(showContacts ? firstFilled(post.getXUsername(), useProfile ? profile.getSocialX() : null) : null)
                .youtubeUsername(showContacts ? firstFilled(post.getYoutubeUsername(), useProfile ? profile.getSocialYoutube() : null) : null)
                .adultOnly(post.is18Plus())
                .boostedUntil(boostEnd)
                .imageUrls(new ArrayList<>(post.getImageUrls()))
                .videoUrls(new ArrayList<>(post.getVideoUrls()))
                .featuredImageUrl(post.getFeaturedImageUrl())
                .rating(serviceStats.average())
                .reviewsCount(serviceStats.count())
                .seller(sellerDto)
                .active(post.isActive())
                .createdAt(post.getCreatedAt())
                .build();
    }

    // ------------------------------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------------------------------

    private static boolean isOwnerOrAdmin(ServicePost post, User viewer) {
        if (viewer == null) return false;
        return viewer.getRole() == Role.ROLE_ADMIN
                || (post.getSeller() != null && post.getSeller().getId().equals(viewer.getId()));
    }

    private static <T> void replaceAll(List<T> target, List<T> values) {
        target.clear();
        target.addAll(values);
    }

    private static String blankToNull(String v) {
        if (v == null) return null;
        String t = v.trim();
        return t.isEmpty() ? null : t;
    }

    /** "@name" -> "name"; empty -> null. */
    /** The first text that is not empty, or null. */
    private static String firstFilled(String own, String fallback) {
        if (own != null && !own.isBlank()) return own;
        return fallback == null || fallback.isBlank() ? null : fallback;
    }

    private static String cleanHandle(String v) {
        String t = v == null ? "" : v.trim().replaceFirst("^@+", "");
        return t.isEmpty() ? null : t;
    }

    private static String cleanTime(String v) {
        String t = v == null ? "" : v.trim();
        if (t.isEmpty()) return null;
        if (!HHMM.matcher(t).matches()) throw ApiException.badRequest("INVALID_TIME");
        return t;
    }

    private static BigDecimal positiveOrNull(BigDecimal v) {
        return v != null && v.signum() > 0 ? v : null;
    }

    /** Up to 3 tasks: a name (max 100 characters) and a price above zero. Anything else is refused. */
    private static List<com.nearbyservices.model.ServiceTask> cleanTasks(List<ServicePostRequest.TaskInput> raw) {
        List<com.nearbyservices.model.ServiceTask> out = new ArrayList<>();
        if (raw == null) return out;
        Set<String> seen = new LinkedHashSet<>();
        for (ServicePostRequest.TaskInput t : raw) {
            String name = t == null || t.getName() == null ? "" : t.getName().trim();
            if (name.isEmpty() && (t == null || t.getPrice() == null)) continue; // an empty row is just skipped
            if (name.isEmpty() || name.length() > 100) throw ApiException.badRequest("INVALID_TASK_NAME");
            if (t.getPrice() == null || t.getPrice().signum() <= 0
                    || t.getPrice().compareTo(new BigDecimal("1000000000")) > 0) {
                throw ApiException.badRequest("INVALID_TASK_PRICE");
            }
            if (!seen.add(name.toLowerCase(Locale.ROOT))) throw ApiException.badRequest("DUPLICATE_TASK");
            if (out.size() >= 3) throw ApiException.badRequest("TOO_MANY_TASKS");
            out.add(new com.nearbyservices.model.ServiceTask(name, t.getPrice()));
        }
        return out;
    }

    private static List<ServicePostResponse.TaskView> taskViews(ServicePost post) {
        List<ServicePostResponse.TaskView> out = new ArrayList<>();
        if (post.getTasks() == null) return out;
        for (com.nearbyservices.model.ServiceTask t : post.getTasks()) {
            out.add(new ServicePostResponse.TaskView(t.getName(), t.getPrice()));
        }
        return out;
    }

    /** Trimmed, de-duplicated (case-insensitive), blanks and too-long entries dropped, order kept. */
    private static List<String> cleanTexts(List<String> raw, int maxLen, int maxCount) {
        List<String> out = new ArrayList<>();
        if (raw == null) return out;
        Set<String> seen = new LinkedHashSet<>();
        for (String s : raw) {
            String t = s == null ? "" : s.trim();
            if (t.isEmpty() || t.length() > maxLen) continue;
            if (seen.add(t.toLowerCase(Locale.ROOT)) && out.size() < maxCount) out.add(t);
        }
        return out;
    }

    /** Pictures/videos must be our own uploads or https links; anything else (javascript:, file:, http:) is refused. */
    private static List<String> cleanMediaUrls(List<String> raw) {
        List<String> out = new ArrayList<>();
        if (raw == null) return out;
        Set<String> seen = new LinkedHashSet<>();
        for (String s : raw) {
            String t = s == null ? "" : s.trim();
            if (t.isEmpty()) continue;
            boolean ok = (t.startsWith("/uploads/") || t.startsWith("https://")) && t.length() <= 1000;
            if (!ok) throw ApiException.badRequest("INVALID_MEDIA_URL");
            if (seen.add(t)) out.add(t);
        }
        return out;
    }

    private static String escapeLike(String s) {
        return s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_");
    }

    private static double haversineKm(double lat1, double lon1, double lat2, double lon2) {
        double r = 6371.0;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        return 2 * r * Math.asin(Math.min(1.0, Math.sqrt(a)));
    }
}
