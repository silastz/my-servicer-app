package com.nearbyservices.service;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * The provider fee formula from PROVIDER_FEES_FLOW.md, in whole TSh with percentages rounded half up.
 * Pure arithmetic, no database: the same numbers as the app's ProviderFees class.
 *
 * <pre>
 * collection = round(amount * collectionPercent / 100)
 * pct        = round(amount * vatPercent / 100)
 * charge     = max(pct, payoutFee)        (0 when both vatPercent and payoutFee are 0)
 * payoutPart = payoutFee                  (0 when charge is 0)
 * vatPart    = charge - payoutPart
 * net        = amount - collection - charge
 * refund     = paid - charge              (no collection fee on refunds)
 * </pre>
 */
public final class ProviderFeeCalculator {

    private ProviderFeeCalculator() {}

    /** What one withdrawal costs. {@code net} can be zero or negative: callers reject {@code net <= 0}. */
    public record Withdrawal(long amount, long collection, long charge, long payoutPart, long vatPart, long net) {
        /** What the provider sees as the total fee. */
        public long totalFee() { return collection + charge; }
    }

    /** What a refund of a pocket-fund booking costs the buyer. {@code refund} is never below zero. */
    public record Refund(long paid, long charge, long payoutPart, long vatPart, long refund) {}

    public static Withdrawal withdrawal(long amount, BigDecimal collectionPercent, BigDecimal vatPercent, long payoutFee) {
        long collection = percentOf(amount, collectionPercent);
        long[] c = charge(amount, vatPercent, payoutFee);
        return new Withdrawal(amount, collection, c[0], c[1], c[2], amount - collection - c[0]);
    }

    public static Refund refund(long paid, BigDecimal vatPercent, long payoutFee) {
        long[] c = charge(paid, vatPercent, payoutFee);
        long charge = Math.min(c[0], paid);               // never take more than was paid
        long payoutPart = Math.min(c[1], charge);
        return new Refund(paid, charge, payoutPart, charge - payoutPart, paid - charge);
    }

    /** {charge, payoutPart, vatPart} */
    private static long[] charge(long amount, BigDecimal vatPercent, long payoutFee) {
        long pct = percentOf(amount, vatPercent);
        if (pct <= 0 && payoutFee <= 0) return new long[]{0, 0, 0};
        long charge = Math.max(pct, payoutFee);
        return new long[]{charge, payoutFee, charge - payoutFee};
    }

    private static long percentOf(long amount, BigDecimal percent) {
        if (percent == null || percent.signum() <= 0) return 0;
        return BigDecimal.valueOf(amount).multiply(percent).divide(BigDecimal.valueOf(100), 0, RoundingMode.HALF_UP).longValueExact();
    }
}
