package com.nearbyservices.service;

import com.nearbyservices.dto.PublicUserDto;
import com.nearbyservices.dto.ReviewRequest;
import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.EscrowStatus;
import com.nearbyservices.model.EscrowTransaction;
import com.nearbyservices.model.Review;
import com.nearbyservices.model.User;
import com.nearbyservices.repository.EscrowTransactionRepository;
import com.nearbyservices.repository.ReviewRepository;
import com.nearbyservices.repository.ServicePostRepository;
import com.nearbyservices.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Ratings. After a COMPLETED booking each side may rate the other once. Only buyers' ratings of the
 * provider feed the service / provider rating shown on the service page.
 */
@Service
@RequiredArgsConstructor
public class ReviewService {

    private static final int PUBLIC_LIMIT = 50;

    private final ReviewRepository reviewRepository;
    private final EscrowTransactionRepository escrowRepository;
    private final UserRepository userRepository;
    private final ServicePostRepository servicePostRepository;
    private final VerificationService verificationService;
    private final PushService pushService;

    public record Stats(Double average, Integer count) {}

    // ------------------------------------------------------------------ write

    @Transactional
    public Map<String, Object> submit(User reviewer, ReviewRequest r) {
        EscrowTransaction tx = escrowRepository.findByTransactionRef(r.getTransactionRef().trim())
                .orElseThrow(() -> ApiException.notFound("TRANSACTION_NOT_FOUND"));
        boolean isBuyer = tx.getBuyer().getId().equals(reviewer.getId());
        boolean isSeller = tx.getSeller().getId().equals(reviewer.getId());
        // 404, not 403: do not confirm that someone else's booking reference exists.
        if (!isBuyer && !isSeller) throw ApiException.notFound("TRANSACTION_NOT_FOUND");
        if (isBuyer && isSeller) throw ApiException.badRequest("CANNOT_REVIEW_YOURSELF");
        if (tx.getStatus() != EscrowStatus.COMPLETED) throw ApiException.conflict("TRANSACTION_NOT_COMPLETED");
        if (reviewRepository.existsByTransactionRefAndReviewerId(tx.getTransactionRef(), reviewer.getId())) {
            throw ApiException.conflict("ALREADY_REVIEWED");
        }

        User reviewee = isBuyer ? tx.getSeller() : tx.getBuyer();
        String comment = r.getComment() == null ? null : r.getComment().trim();
        Review review = Review.builder()
                .transactionRef(tx.getTransactionRef())
                .reviewerId(reviewer.getId())
                .revieweeId(reviewee.getId())
                .serviceId(tx.getService() != null ? tx.getService().getId() : null)
                .fromBuyer(isBuyer)
                .rating(r.getRating())
                .comment(comment == null || comment.isEmpty() ? null : comment)
                .build();
        try {
            review = reviewRepository.saveAndFlush(review);
        } catch (DataIntegrityViolationException twice) {
            throw ApiException.conflict("ALREADY_REVIEWED");
        }
        // Tell the person who was rated (sent after the commit; the Bookings switch decides whether they get it).
        pushService.toUser(reviewee.getId(),
                new PushService.Text("New review", "Maoni mapya"),
                new PushService.Text(r.getRating() + " star" + (r.getRating() == 1 ? "" : "s") + " from "
                        + reviewer.getStageName() + ".",
                        "Nyota " + r.getRating() + " kutoka kwa " + reviewer.getStageName() + "."),
                Map.of("type", "booking_review", "id", tx.getTransactionRef()));
        return toJson(review);
    }

    // ------------------------------------------------------------------ read

    @Transactional(readOnly = true)
    public List<Map<String, Object>> received(User me) {
        return reviewRepository.findByRevieweeIdOrderByCreatedAtDesc(me.getId()).stream().map(this::toJson).toList();
    }

    @Transactional(readOnly = true)
    public List<Map<String, Object>> written(User me) {
        return reviewRepository.findByReviewerIdOrderByCreatedAtDesc(me.getId()).stream().map(this::toJson).toList();
    }

    /** Public: buyers' reviews of one provider, newest first (max 50). */
    @Transactional(readOnly = true)
    public List<Map<String, Object>> forProvider(Long providerId) {
        return reviewRepository.findByRevieweeIdAndFromBuyerTrueOrderByCreatedAtDesc(providerId, PageRequest.of(0, PUBLIC_LIMIT))
                .stream().map(this::toJson).toList();
    }

    // ------------------------------------------------------------------ stats

    @Transactional(readOnly = true)
    public Stats statsForProvider(Long providerId) {
        return toStats(reviewRepository.providerStats(providerId));
    }

    @Transactional(readOnly = true)
    public Stats statsForService(Long serviceId) {
        if (serviceId == null) return new Stats(0.0, 0);
        return toStats(reviewRepository.serviceStats(serviceId));
    }

    private static Stats toStats(List<Object[]> rows) {
        if (rows.isEmpty() || rows.get(0)[0] == null) return new Stats(0.0, 0);
        double avg = ((Number) rows.get(0)[0]).doubleValue();
        return new Stats(Math.round(avg * 10.0) / 10.0, ((Number) rows.get(0)[1]).intValue());
    }

    // ------------------------------------------------------------------ json

    /** Shape the app reads: rating, comment, createdAt, reviewer{stageName}, service{title}, transactionRef. */
    private Map<String, Object> toJson(Review r) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", r.getId());
        m.put("transactionRef", r.getTransactionRef());
        m.put("rating", r.getRating());
        m.put("comment", r.getComment() == null ? "" : r.getComment());
        m.put("createdAt", r.getCreatedAt());
        m.put("reviewer", publicUser(r.getReviewerId()));
        m.put("reviewee", publicUser(r.getRevieweeId()));
        if (r.getServiceId() != null) {
            servicePostRepository.findById(r.getServiceId()).ifPresent(s ->
                    m.put("service", Map.of("id", s.getId(), "title", s.getTitle())));
        }
        return m;
    }

    /** Stage name only, never the real name, phone or NIDA data. */
    private PublicUserDto publicUser(Long id) {
        return userRepository.findById(id).map(verificationService::mapToPublicDto).orElse(null);
    }
}
