package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.AdminSettings;
import com.nearbyservices.repository.AdminSettingsRepository;
import com.nearbyservices.verification.AuditLog;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Admin switches the app reads from /api/app/policy: the four security switches and the wallet top-up limits.
 * In the body, a key that is absent = unchanged; a key set to null = back to "not set" (the app uses its default).
 */
@Service
@RequiredArgsConstructor
public class AppSecurityService {

    private static final String[] SWITCHES = {"screenCaptureAllowed", "blockCompromisedDevice", "playIntegrity", "blockVpn"};
    private static final long LIMIT_FLOOR = 100;
    private static final long LIMIT_CEILING = 100_000_000;

    private final AdminSettingsService adminSettingsService;
    private final AdminSettingsRepository repository;
    private final AuditLog auditLog;

    @Transactional(readOnly = true)
    public Map<String, Object> get() {
        return json(adminSettingsService.getSettings());
    }

    @Transactional
    public Map<String, Object> update(long adminId, Map<String, Object> body) {
        AdminSettings s = adminSettingsService.getSettings();
        String before = json(s).toString();
        for (String k : SWITCHES) {
            if (!body.containsKey(k)) continue;
            Boolean v = bool(body.get(k), k);
            switch (k) {
                case "screenCaptureAllowed" -> s.setScreenCaptureAllowed(v);
                case "blockCompromisedDevice" -> s.setBlockCompromisedDevice(v);
                case "playIntegrity" -> s.setPlayIntegrity(v);
                default -> s.setBlockVpn(v);
            }
        }
        if (body.containsKey("topUpMin")) s.setTopUpMin(limit(body.get("topUpMin"), "INVALID_TOPUP_MIN"));
        if (body.containsKey("topUpMax")) s.setTopUpMax(limit(body.get("topUpMax"), "INVALID_TOPUP_MAX"));
        if (s.getTopUpMin() != null && s.getTopUpMax() != null && s.getTopUpMin() > 0 && s.getTopUpMax() > 0
                && s.getTopUpMax() < s.getTopUpMin()) {
            throw ApiException.badRequest("TOPUP_MAX_BELOW_MIN");
        }
        repository.save(s);
        Map<String, Object> now = json(s);
        auditLog.record(adminId, "APP_SECURITY_CHANGED", "before " + before + " after " + now);
        return now;
    }

    private static Boolean bool(Object o, String key) {
        if (o == null) return null;
        if (o instanceof Boolean b) return b;
        String t = o.toString().trim().toLowerCase();
        if (t.equals("true")) return true;
        if (t.equals("false")) return false;
        throw ApiException.badRequest("INVALID_" + key.replaceAll("([A-Z])", "_$1").toUpperCase());
    }

    /** null or 0 = not set; otherwise a whole number between 100 and 100,000,000. */
    private static Long limit(Object o, String error) {
        if (o == null) return null;
        try {
            long v = new java.math.BigDecimal(o.toString().trim()).longValueExact();
            if (v == 0) return null;
            if (v < LIMIT_FLOOR || v > LIMIT_CEILING) throw new ArithmeticException();
            return v;
        } catch (ArithmeticException | NumberFormatException e) {
            throw ApiException.badRequest(error);
        }
    }

    private static Map<String, Object> json(AdminSettings s) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("screenCaptureAllowed", s.getScreenCaptureAllowed());
        m.put("blockCompromisedDevice", s.getBlockCompromisedDevice());
        m.put("playIntegrity", s.getPlayIntegrity());
        m.put("blockVpn", s.getBlockVpn());
        m.put("topUpMin", s.getTopUpMin());
        m.put("topUpMax", s.getTopUpMax());
        return m;
    }
}
