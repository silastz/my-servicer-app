package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.BoostPlan;
import com.nearbyservices.repository.BoostPlanRepository;
import com.nearbyservices.verification.AuditLog;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Comparator;
import java.util.regex.Pattern;

/**
 * Admin edits of the boost price list. Plans are never deleted (past purchases keep what they paid): an old
 * plan is switched off with active=false. A price or number of days is changed for FUTURE purchases only.
 * Two active plans may not share a price or a number of days, because a boost paid while the app was closed
 * is matched to its plan by price, and the app may ask for a plan by days.
 */
@Service
@RequiredArgsConstructor
public class BoostPlanAdminService {

    private static final Pattern ID = Pattern.compile("^[a-z0-9_]{3,50}$");
    private static final long MIN_PRICE = 100;
    private static final long MAX_PRICE = 10_000_000;
    private static final int MAX_DAYS = 365;

    private final BoostPlanRepository planRepository;
    private final AuditLog auditLog;

    @Transactional(readOnly = true)
    public List<Map<String, Object>> all() {
        return planRepository.findAll().stream()
                .sorted(Comparator.comparingInt(BoostPlan::getDays).thenComparing(BoostPlan::getId))
                .map(BoostPlanAdminService::json).toList();
    }

    @Transactional
    public Map<String, Object> create(long adminId, Map<String, Object> body) {
        String id = text(body.get("id")).toLowerCase();
        if (!ID.matcher(id).matches()) throw ApiException.badRequest("INVALID_PLAN_ID");
        if (planRepository.existsById(id)) throw ApiException.conflict("PLAN_ID_IN_USE");
        BoostPlan plan = BoostPlan.builder()
                .id(id).days(days(body.get("days"))).price(price(body.get("price")))
                .active(!Boolean.FALSE.equals(body.get("active"))).build();
        checkNoClash(plan);
        planRepository.save(plan);
        auditLog.record(adminId, "BOOST_PLAN_CREATED", describe(plan));
        return json(plan);
    }

    /** Only the fields present in the body change. */
    @Transactional
    public Map<String, Object> update(long adminId, String id, Map<String, Object> body) {
        BoostPlan plan = planRepository.findById(id).orElseThrow(() -> ApiException.notFound("PLAN_NOT_FOUND"));
        String before = describe(plan);
        if (body.get("days") != null) plan.setDays(days(body.get("days")));
        if (body.get("price") != null) plan.setPrice(price(body.get("price")));
        if (body.get("active") != null) plan.setActive(Boolean.parseBoolean(body.get("active").toString()));
        checkNoClash(plan);
        planRepository.save(plan);
        auditLog.record(adminId, "BOOST_PLAN_CHANGED", "before " + before + " after " + describe(plan));
        return json(plan);
    }

    private void checkNoClash(BoostPlan plan) {
        if (!plan.isActive()) return;
        for (BoostPlan other : planRepository.findByActiveTrueOrderByDaysAsc()) {
            if (other.getId().equals(plan.getId())) continue;
            if (other.getPrice() == plan.getPrice()) throw ApiException.conflict("PLAN_PRICE_IN_USE");
            if (other.getDays() == plan.getDays()) throw ApiException.conflict("PLAN_DAYS_IN_USE");
        }
    }

    private static int days(Object o) {
        long v = whole(o, "INVALID_DAYS");
        if (v < 1 || v > MAX_DAYS) throw ApiException.badRequest("INVALID_DAYS");
        return (int) v;
    }

    private static long price(Object o) {
        long v = whole(o, "INVALID_PRICE");
        if (v < MIN_PRICE || v > MAX_PRICE) throw ApiException.badRequest("INVALID_PRICE");
        return v;
    }

    /** Whole numbers only: 5000 or "5000" is fine, 5000.5 is not. */
    private static long whole(Object o, String error) {
        if (o == null) throw ApiException.badRequest(error);
        try {
            java.math.BigDecimal d = new java.math.BigDecimal(o.toString().trim());
            return d.longValueExact();
        } catch (ArithmeticException | NumberFormatException e) {
            throw ApiException.badRequest(error);
        }
    }

    private static String text(Object o) {
        return o == null ? "" : o.toString().trim();
    }

    private static String describe(BoostPlan p) {
        return p.getId() + " days=" + p.getDays() + " price=" + p.getPrice() + " active=" + p.isActive();
    }

    private static Map<String, Object> json(BoostPlan p) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", p.getId());
        m.put("days", p.getDays());
        m.put("price", p.getPrice());
        m.put("active", p.isActive());
        return m;
    }
}
