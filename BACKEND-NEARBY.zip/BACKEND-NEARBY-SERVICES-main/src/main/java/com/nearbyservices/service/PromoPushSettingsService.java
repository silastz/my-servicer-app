package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.AdminSettings;
import com.nearbyservices.repository.AdminSettingsRepository;
import com.nearbyservices.verification.AuditLog;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** The admin's two promo-push controls: on/off, and the least hours between two pushes to the same user. */
@Service
@RequiredArgsConstructor
public class PromoPushSettingsService {

    public static final int DEFAULT_INTERVAL_HOURS = 6;
    public static final int MIN_INTERVAL_HOURS = 1;
    public static final int MAX_INTERVAL_HOURS = 72;

    private final AdminSettingsService adminSettingsService;
    private final AdminSettingsRepository adminSettingsRepository;
    private final AuditLog auditLog;

    public boolean enabled() {
        return adminSettingsService.getSettings().isPromoPushEnabled();
    }

    /** Hours in force now. An old row without a valid value falls back to the default. */
    public int intervalHours() {
        int h = adminSettingsService.getSettings().getPromoPushIntervalHours();
        return h >= MIN_INTERVAL_HOURS && h <= MAX_INTERVAL_HOURS ? h : DEFAULT_INTERVAL_HOURS;
    }

    /** A null value leaves that control as it is. Nothing is changed when either value is refused. */
    @Transactional
    public void update(long adminId, Boolean enabled, Integer intervalHours) {
        if (intervalHours != null && (intervalHours < MIN_INTERVAL_HOURS || intervalHours > MAX_INTERVAL_HOURS)) {
            throw ApiException.badRequest("INVALID_PROMO_PUSH_INTERVAL");
        }
        AdminSettings s = adminSettingsService.getSettings();
        boolean beforeOn = s.isPromoPushEnabled();
        int beforeHours = intervalHours();
        if (enabled != null) s.setPromoPushEnabled(enabled);
        if (intervalHours != null) s.setPromoPushIntervalHours(intervalHours);
        adminSettingsRepository.save(s);
        auditLog.record(adminId, "PROMO_PUSH_SETTINGS_CHANGED",
                "enabled " + beforeOn + " -> " + s.isPromoPushEnabled() + ", hours " + beforeHours + " -> " + intervalHours());
    }
}
