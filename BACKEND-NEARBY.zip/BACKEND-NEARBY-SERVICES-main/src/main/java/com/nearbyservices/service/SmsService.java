package com.nearbyservices.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.nearbyservices.sms.SmsDispatcher;

import java.util.HashMap;
import java.util.Map;

/**
 * SmsService handles sending SMS and OTP codes across multiple switchable providers.
 * Supported providers:
 * - SMS_GATEWAY_PRO (https://smsgetway.techwareafrica.tech)
 * - SELANIM (https://bulksms.selanim.com)
 * - BEEM_AFRICA
 * - TWILIO
 */
@Service
@Slf4j
public class SmsService {

    private final RestTemplate restTemplate = new RestTemplate();

    /** Admin-managed Meseji / Beem sending with failover (docs/SMS_GATEWAY.md). Used once the admin saved a complete default provider. */
    private final SmsDispatcher dispatcher;

    public SmsService(SmsDispatcher dispatcher) {
        this.dispatcher = dispatcher;
    }

    @Value("${app.sms.active-provider:SMS_GATEWAY_PRO}")
    private String activeProvider;

    // SMS Gateway Pro configuration
    @Value("${app.sms.gateway-pro.url:https://kzjgdeqfmxkmpmadtbpb.supabase.co/functions/v1/sms-api/send}")
    private String gatewayProUrl;

    @Value("${app.sms.gateway-pro.api-key:}")
    private String gatewayProApiKey;

    // Commercial Aggregator (e.g. Selanim / Beem) configuration
    @Value("${app.sms.selanim.url:https://bulksms.selanim.com/api/v1/sms/send}")
    private String selanimUrl;

    @Value("${app.sms.selanim.api-key:}")
    private String selanimApiKey;

    @Value("${app.sms.sender-id:NEARBY}")
    private String senderId;

    /**
     * Sends an OTP verification SMS to the user's phone number asynchronously.
     */
    @Async
    public void sendOtpSms(String rawPhone, String stageName, String otp) {
        String cleanPhone = normalizePhoneNumber(rawPhone);
        String messageText = "NearByServices: Nambari yako ya siri ya uhakiki (OTP) ni " + otp + ". Nambari hii itaisha muda wake baada ya dakika 10. Usishirikishe mtu yeyote.";

        try {
            // New path: the provider chosen on the admin SMS screen, with automatic failover.
            if (dispatcher.isConfigured()) {
                SmsDispatcher.Outcome o = dispatcher.send(cleanPhone, messageText);
                if (o.ok()) {
                    log.info("OTP SMS sent by {}{}", o.provider(), o.failedOver() ? " (backup provider)" : "");
                } else {
                    log.error("OTP SMS could not be sent: {}", o.message());
                }
                return;
            }
            // Old path (environment settings) until the admin saves SMS settings.
            log.info("Sending OTP via provider [{}] to {}", activeProvider, cleanPhone);

            switch (activeProvider.toUpperCase()) {
                case "SELANIM":
                    sendViaSelanim(cleanPhone, messageText);
                    break;
                case "SMS_GATEWAY_PRO":
                default:
                    sendViaSmsGatewayPro(cleanPhone, messageText);
                    break;
            }
        } catch (Exception e) {
            log.error("Failed to send SMS to {} using {}: {}", cleanPhone, activeProvider, e.getMessage());
        }
    }

    /**
     * Dispatch SMS using SMS Gateway Pro (Supabase Edge Function)
     * Payload: { phone_number: "+255...", message: "...", priority: 1, metadata: {...} }
     */
    private void sendViaSmsGatewayPro(String phoneWithPlus, String message) {
        if (gatewayProApiKey == null || gatewayProApiKey.isBlank()) {
            log.error("SMS not sent: SMS_GATEWAY_PRO_API_KEY is not set (and no provider is saved on the admin SMS screen).");
            return;
        }
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("x-api-key", gatewayProApiKey);

        Map<String, Object> payload = new HashMap<>();
        payload.put("phone_number", phoneWithPlus);
        payload.put("message", message);
        payload.put("priority", 1);
        payload.put("metadata", Map.of("service", "NearByServices", "type", "OTP"));

        HttpEntity<Map<String, Object>> request = new HttpEntity<>(payload, headers);
        ResponseEntity<String> response = restTemplate.postForEntity(gatewayProUrl, request, String.class);

        log.info("SMS Gateway Pro response status: {} - body: {}", response.getStatusCode(), response.getBody());
    }

    /**
     * Dispatch SMS using Selanim Bulk SMS
     */
    private void sendViaSelanim(String phoneWithPlus, String message) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        if (selanimApiKey != null && !selanimApiKey.isBlank()) {
            headers.set("Authorization", "Bearer " + selanimApiKey);
        }

        String phoneClean = phoneWithPlus.startsWith("+") ? phoneWithPlus.substring(1) : phoneWithPlus;

        Map<String, Object> payload = new HashMap<>();
        payload.put("source", senderId);
        payload.put("message", message);
        payload.put("destinations", new Object[]{
                Map.of("recipient_id", "1", "dest_addr", phoneClean)
        });

        HttpEntity<Map<String, Object>> request = new HttpEntity<>(payload, headers);
        ResponseEntity<String> response = restTemplate.postForEntity(selanimUrl, request, String.class);

        log.info("Selanim SMS response status: {} - body: {}", response.getStatusCode(), response.getBody());
    }

    /**
     * Normalizes Tanzania phone numbers to standard E.164 (+255XXXXXXXXX)
     */
    public static String normalizePhoneNumber(String raw) {
        if (raw == null) return "";
        String digits = raw.replaceAll("[^0-9]", "");
        
        // Handle numbers starting with 2550... -> strip 0
        if (digits.startsWith("2550") && digits.length() == 13) {
            return "+255" + digits.substring(4);
        } else if (digits.startsWith("255") && digits.length() == 12) {
            return "+" + digits;
        } else if (digits.startsWith("0") && digits.length() == 10) {
            return "+255" + digits.substring(1);
        } else if (digits.length() == 9) {
            return "+255" + digits;
        } else if (!raw.startsWith("+")) {
            return "+" + digits;
        }
        return raw.trim();
    }
}
