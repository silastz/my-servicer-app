package com.nearbyservices.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Cluster-wide lock for scheduled jobs, built on PostgreSQL advisory locks (no extra table
 * or library). With more than one API instance, only the instance that gets the lock runs
 * a given job; the others skip that round. The lock belongs to the database session, so a
 * crashed instance releases it automatically.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class JobLock {

    private final DataSource dataSource;

    /** Runs {@code job} only if no other instance is running the job called {@code name}. */
    public void run(String name, Runnable job) {
        long key = key(name);
        try (Connection c = dataSource.getConnection()) {
            if (!tryLock(c, key)) {
                log.debug("Job {} is running on another instance; skipped", name);
                return;
            }
            try {
                job.run();
            } finally {
                unlock(c, key);
            }
        } catch (SQLException e) {
            // Could not reach the database for the lock: skip this round rather than risk a double run.
            log.warn("Job {} skipped, lock unavailable: {}", name, e.getMessage());
        }
    }

    private static boolean tryLock(Connection c, long key) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("select pg_try_advisory_lock(?)")) {
            ps.setLong(1, key);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getBoolean(1);
            }
        }
    }

    private static void unlock(Connection c, long key) {
        try (PreparedStatement ps = c.prepareStatement("select pg_advisory_unlock(?)")) {
            ps.setLong(1, key);
            ps.execute();
        } catch (SQLException ignored) {
            // The lock dies with the session anyway.
        }
    }

    /** Stable 64-bit key per job name, kept apart from other advisory-lock users by a prefix. */
    private static long key(String name) {
        return ("nearbyservices:job:" + name).hashCode() * 31L + 0x4E53L;
    }
}
