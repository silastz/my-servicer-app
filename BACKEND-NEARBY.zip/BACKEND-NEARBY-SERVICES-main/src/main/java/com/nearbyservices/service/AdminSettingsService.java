package com.nearbyservices.service;

import com.nearbyservices.model.AdminSettings;
import com.nearbyservices.repository.AdminSettingsRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

@Service
@RequiredArgsConstructor
public class AdminSettingsService {

    private final AdminSettingsRepository adminSettingsRepository;

    public AdminSettings getSettings() {
        return adminSettingsRepository.findAll().stream().findFirst()
                .orElseGet(() -> adminSettingsRepository.save(
                        AdminSettings.builder()
                                .sellerRegistrationFee(new BigDecimal("10000.00"))
                                .freeServicesQuota(2)
                                .combinedPackageCount(2)
                                .packagePrice(new BigDecimal("15000.00"))
                                .serviceFee(new BigDecimal("5000.00"))
                                .build()
                ));
    }

    private static final java.util.regex.Pattern SUPPORT_PHONE = java.util.regex.Pattern.compile("^\\+?[0-9]{9,15}$");
    private static final java.util.regex.Pattern SUPPORT_EMAIL = java.util.regex.Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$");

    /** A null argument leaves that contact as it is; an empty text clears it. Spaces and dashes in numbers are removed. */
    @Transactional
    public AdminSettings updateSupport(String phone, String whatsapp, String email) {
        AdminSettings settings = getSettings();
        if (phone != null) settings.setSupportPhone(cleanNumber(phone, "INVALID_SUPPORT_PHONE"));
        if (whatsapp != null) settings.setSupportWhatsapp(cleanNumber(whatsapp, "INVALID_SUPPORT_WHATSAPP"));
        if (email != null) {
            String e = email.trim().toLowerCase(java.util.Locale.ROOT);
            if (!e.isEmpty() && (e.length() > 120 || !SUPPORT_EMAIL.matcher(e).matches())) throw new IllegalArgumentException("INVALID_SUPPORT_EMAIL");
            settings.setSupportEmail(e.isEmpty() ? null : e);
        }
        return adminSettingsRepository.save(settings);
    }

    /** Empty text clears it (the env default is used again). Returns the saved settings. */
    @Transactional
    public AdminSettings updatePaymentFallbackEmail(String email) {
        AdminSettings settings = getSettings();
        String e = email == null ? "" : email.trim().toLowerCase(java.util.Locale.ROOT);
        if (!e.isEmpty() && (e.length() > 120 || !SUPPORT_EMAIL.matcher(e).matches())) throw new IllegalArgumentException("INVALID_PAYMENT_EMAIL");
        settings.setPaymentFallbackEmail(e.isEmpty() ? null : e);
        return adminSettingsRepository.save(settings);
    }

    private static String cleanNumber(String raw, String error) {
        String n = raw.replaceAll("[\\s-]", "");
        if (n.isEmpty()) return null;
        if (!SUPPORT_PHONE.matcher(n).matches()) throw new IllegalArgumentException(error);
        return n;
    }

    @Transactional
    public AdminSettings updateSettings(BigDecimal sellerRegistrationFee, Integer freeServicesQuota, Integer combinedPackageCount, BigDecimal packagePrice, BigDecimal serviceFee) {
        AdminSettings settings = getSettings();
        if (sellerRegistrationFee != null) {
            settings.setSellerRegistrationFee(sellerRegistrationFee);
        }
        if (freeServicesQuota != null) {
            settings.setFreeServicesQuota(freeServicesQuota);
        }
        if (combinedPackageCount != null) {
            settings.setCombinedPackageCount(combinedPackageCount);
        }
        if (packagePrice != null) {
            settings.setPackagePrice(packagePrice);
        }
        if (serviceFee != null) {
            if (serviceFee.signum() < 0) throw new IllegalArgumentException("INVALID_SERVICE_FEE");
            settings.setServiceFee(serviceFee);
        }
        if (freeServicesQuota != null && freeServicesQuota < 0) throw new IllegalArgumentException("INVALID_FREE_QUOTA");
        return adminSettingsRepository.save(settings);
    }
}
