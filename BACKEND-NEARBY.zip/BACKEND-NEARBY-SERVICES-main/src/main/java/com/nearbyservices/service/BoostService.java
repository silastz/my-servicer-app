package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.BoostPlan;
import com.nearbyservices.model.Payment;
import com.nearbyservices.model.PaymentPurpose;
import com.nearbyservices.model.PaymentStatus;
import com.nearbyservices.model.ServiceBoost;
import com.nearbyservices.model.ServicePost;
import com.nearbyservices.model.User;
import com.nearbyservices.repository.BoostPlanRepository;
import com.nearbyservices.repository.PaymentRepository;
import com.nearbyservices.repository.ServiceBoostRepository;
import com.nearbyservices.repository.ServicePostRepository;
import com.nearbyservices.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Paid boosts: a provider pays to have one service ranked first and tagged "Boosted" for some days.
 * The server prices from its own plan table (never the app's amount or days), checks that the
 * caller owns the service, verifies the payment (or debits the pocket fund in the same transaction)
 * and starts or extends the boost. A reference works once: repeating the call returns the first result.
 */
@Service
@RequiredArgsConstructor
public class BoostService {

    private static final Logger log = LoggerFactory.getLogger(BoostService.class);
    private static final Pattern BOOST_REFERENCE = Pattern.compile("^BOOST-(\\d{1,18})-(\\d{1,18})-");
    private static final Pattern REFERENCE = Pattern.compile("^[A-Za-z0-9_.:-]{6,100}$");
    private static final Set<String> METHODS = Set.of("MOBILE_MONEY", "CARD", "POCKET_FUND");

    private final BoostPlanRepository planRepository;
    private final ServiceBoostRepository boostRepository;
    private final ServicePostRepository servicePostRepository;
    private final UserRepository userRepository;
    private final PaymentRepository paymentRepository;
    private final WalletService walletService;

    @Transactional(readOnly = true)
    public List<Map<String, Object>> plans() {
        return planRepository.findByActiveTrueOrderByDaysAsc().stream().map(p -> {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", p.getId());
            m.put("days", p.getDays());
            m.put("price", p.getPrice());
            return m;
        }).toList();
    }

    @Transactional
    public Map<String, Object> activate(User caller, Long serviceId, String rawPlanId, Integer days,
                                        String rawMethod, String rawReference) {
        String method = rawMethod == null ? "" : rawMethod.trim().toUpperCase(Locale.ROOT);
        if (!METHODS.contains(method)) throw ApiException.badRequest("INVALID_PAYMENT_METHOD");
        if (serviceId == null) throw ApiException.badRequest("SERVICE_REQUIRED");
        BoostPlan plan = findPlan(rawPlanId, days);

        String ref = rawReference == null ? null : rawReference.trim();
        if (ref != null && ref.isEmpty()) ref = null;
        if (ref != null && !REFERENCE.matcher(ref).matches()) throw ApiException.badRequest("INVALID_REFERENCE");
        boolean pocket = method.equals("POCKET_FUND");
        if (!pocket && ref == null) throw ApiException.badRequest("REFERENCE_REQUIRED");
        String key = pocket
                ? "POCKET:" + caller.getId() + ":" + (ref == null ? UUID.randomUUID().toString() : ref)
                : ref;

        // One provider's boosts run one at a time, so two taps can never both extend or both charge.
        User user = userRepository.findByIdForUpdate(caller.getId())
                .orElseThrow(() -> ApiException.notFound("USER_NOT_FOUND"));

        // The app retries after a dropped connection: the same reference returns the first result.
        ServiceBoost existing = boostRepository.findByReference(key).orElse(null);
        if (existing != null) {
            boolean same = existing.getUserId().equals(user.getId())
                    && existing.getServiceId().equals(serviceId)
                    && existing.getPlanId().equals(plan.getId());
            if (!same) throw ApiException.conflict("REFERENCE_IN_USE");
            return json(existing);
        }

        ServicePost post = servicePostRepository.findById(serviceId)
                .orElseThrow(() -> ApiException.notFound("SERVICE_NOT_FOUND"));
        if (!post.getSeller().getId().equals(user.getId())) throw ApiException.forbidden("NOT_YOUR_SERVICE");
        if (!post.isActive()) throw ApiException.conflict("SERVICE_NOT_ACTIVE");

        BigDecimal price = BigDecimal.valueOf(plan.getPrice());
        if (pocket) {
            walletService.debitForPurchase(user, price, post.getTitle());
        } else {
            Payment pay = paymentRepository.findByReference(ref)
                    .filter(p -> p.getUserId().equals(user.getId()) && p.getPurpose() == PaymentPurpose.SERVICE_BOOST)
                    .orElseThrow(() -> ApiException.notFound("PAYMENT_NOT_FOUND"));
            String channel = method.equals("CARD") ? "CARD" : "MOBILE";
            if (!pay.getChannel().equals(channel)) throw ApiException.badRequest("PAYMENT_METHOD_MISMATCH");
            if (pay.getStatus() != PaymentStatus.PAID) throw ApiException.paymentRequired("PAYMENT_NOT_COMPLETED");
            if (pay.getAmount().compareTo(price) != 0) throw ApiException.badRequest("PAYMENT_AMOUNT_MISMATCH");
        }

        return json(startBoost(user, post, plan, method, key));
    }

    /** Extends (or starts) the boost and records the purchase. Callers have already checked owner, payment and idempotency. */
    private ServiceBoost startBoost(User user, ServicePost post, BoostPlan plan, String method, String key) {
        // A service that is already boosted gets the new days after the current end.
        Instant now = Instant.now();
        Instant current = post.getBoostedUntil();
        Instant start = current != null && current.isAfter(now) ? current : now;
        Instant end = start.plus(plan.getDays(), ChronoUnit.DAYS);
        post.setBoostedUntil(end);
        servicePostRepository.save(post);

        return boostRepository.save(ServiceBoost.builder()
                .serviceId(post.getId()).userId(user.getId()).planId(plan.getId())
                .days(plan.getDays()).price(plan.getPrice()).paymentMethod(method)
                .reference(key).startsAt(start).endsAt(end).build());
    }

    /**
     * Called when a SERVICE_BOOST payment turns PAID, so the boost still starts if the app was closed after
     * paying. The payment carries no service or plan, so both are read from what the app already sends:
     * the reference {@code BOOST-{serviceId}-{userId}-{millis}} and the amount (the one active plan with that price).
     * Anything that does not fit is skipped with a log line and the app's own /boosts/activate call still works.
     * Runs in its own transaction and never throws, so a problem here can never undo the PAID status.
     * Safe to repeat and safe next to the app's call: the payment reference is the boost's unique key.
     */
    @Transactional(propagation = org.springframework.transaction.annotation.Propagation.REQUIRES_NEW)
    public void activateFromPayment(Payment pay) {
        try {
            Matcher m = BOOST_REFERENCE.matcher(pay.getReference());
            if (!m.find()) return;
            long serviceId = Long.parseLong(m.group(1));
            long refUserId = Long.parseLong(m.group(2));
            if (refUserId != pay.getUserId()) {
                log.warn("Boost payment {} skipped: reference names another user", pay.getReference());
                return;
            }
            User user = userRepository.findByIdForUpdate(pay.getUserId()).orElse(null);
            if (user == null || boostRepository.findByReference(pay.getReference()).isPresent()) return;
            ServicePost post = servicePostRepository.findById(serviceId).orElse(null);
            if (post == null || !post.getSeller().getId().equals(user.getId()) || !post.isActive()) {
                log.warn("Boost payment {} skipped: service missing, not owned or not active", pay.getReference());
                return;
            }
            List<BoostPlan> sameCost = planRepository.findByActiveTrueOrderByDaysAsc().stream()
                    .filter(p -> BigDecimal.valueOf(p.getPrice()).compareTo(pay.getAmount()) == 0).toList();
            if (sameCost.size() != 1) {
                log.warn("Boost payment {} skipped: {} active plans cost {}", pay.getReference(), sameCost.size(), pay.getAmount());
                return;
            }
            startBoost(user, post, sameCost.get(0), "CARD".equals(pay.getChannel()) ? "CARD" : "MOBILE_MONEY", pay.getReference());
            log.info("Boost started from payment {}", pay.getReference());
        } catch (Exception e) {
            log.warn("Boost for payment {} not started here (the app can still activate it): {}", pay.getReference(), e.getMessage());
        }
    }

    private BoostPlan findPlan(String rawPlanId, Integer days) {
        List<BoostPlan> all = planRepository.findByActiveTrueOrderByDaysAsc();
        String id = rawPlanId == null ? "" : rawPlanId.trim();
        if (!id.isEmpty()) {
            return all.stream().filter(p -> p.getId().equals(id)).findFirst()
                    .orElseThrow(() -> ApiException.badRequest("INVALID_PLAN"));
        }
        if (days != null) {
            return all.stream().filter(p -> p.getDays() == days).findFirst()
                    .orElseThrow(() -> ApiException.badRequest("INVALID_PLAN"));
        }
        throw ApiException.badRequest("INVALID_PLAN");
    }

    private Map<String, Object> json(ServiceBoost b) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", b.getId());
        m.put("serviceId", b.getServiceId());
        m.put("planId", b.getPlanId());
        m.put("days", b.getDays());
        m.put("price", b.getPrice());
        m.put("paymentMethod", b.getPaymentMethod());
        m.put("startsAt", b.getStartsAt());
        m.put("boostedUntil", b.getEndsAt());
        return m;
    }
}
