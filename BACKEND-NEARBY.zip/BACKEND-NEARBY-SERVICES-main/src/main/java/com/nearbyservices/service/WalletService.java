package com.nearbyservices.service;

import com.nearbyservices.dto.WalletResponse;
import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.User;
import com.nearbyservices.model.Wallet;
import com.nearbyservices.dto.WalletTransactionResponse;
import com.nearbyservices.model.WalletTransaction;
import com.nearbyservices.repository.WalletRepository;
import com.nearbyservices.repository.WalletTransactionRepository;
import org.springframework.data.domain.PageRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
@RequiredArgsConstructor
public class WalletService {

    private final WalletRepository walletRepository;
    private final WalletTransactionRepository walletTransactionRepository;
    private final PaymentSettingsService paymentSettingsService;
    private final PlatformWalletService platformWallet;

    /** Optional: tells the admins about a withdrawal to pay out (null in unit tests). */
    @org.springframework.beans.factory.annotation.Autowired(required = false)
    private AdminAlerts adminAlerts;

    public Wallet getOrCreateWallet(User user) {
        return walletRepository.findByUser(user)
                .orElseGet(() -> walletRepository.save(Wallet.builder()
                        .user(user)
                        .balance(BigDecimal.ZERO)
                        .lockedEscrowBalance(BigDecimal.ZERO)
                        .build()));
    }

    public WalletResponse getWalletResponse(User user) {
        Wallet wallet = getOrCreateWallet(user);
        return mapToResponse(wallet);
    }

    /** Adds money that really arrived through a PAID payment (never called from a request body). */
    @Transactional
    public void creditFromPayment(User user, BigDecimal amount, String reference) {
        getOrCreateWallet(user);
        Wallet wallet = walletRepository.findByUserIdForUpdate(user.getId()).orElseThrow();
        wallet.setBalance(wallet.getBalance().add(amount));
        walletRepository.save(wallet);
        record(user.getId(), "DEPOSIT", "IN", amount, "COMPLETED", null, reference);
    }

    /**
     * Pays for something (a boost) out of the pocket fund. Locks the wallet row, checks the balance and
     * takes the money in the caller's transaction, so a failure later in that transaction gives it back.
     */
    @Transactional
    public void debitForPurchase(User user, BigDecimal amount, String title) {
        if (amount == null || amount.signum() <= 0) throw ApiException.badRequest("INVALID_AMOUNT");
        getOrCreateWallet(user);
        Wallet wallet = walletRepository.findByUserIdForUpdate(user.getId()).orElseThrow();
        if (wallet.getBalance().compareTo(amount) < 0) {
            throw ApiException.badRequest("INSUFFICIENT_BALANCE");
        }
        wallet.setBalance(wallet.getBalance().subtract(amount));
        walletRepository.save(wallet);
        record(user.getId(), "BOOST", "OUT", amount, "COMPLETED", title, null);
        platformWallet.income(PlatformWalletService.BOOST, amount, title, null);
    }

    /**
     * The provider withdraws {@code amount}: that is what leaves the wallet. The collection fee and the charge
     * (payout fee inside the VAT charge, see ProviderFeeCalculator) come out of it, from the admin's CURRENT
     * values, and the rest is what reaches the phone. The fees go to the platform wallet. The line is PENDING and
     * keeps the payout phone; an admin then completes it or fails it (WithdrawalAdminService), and a failure gives
     * the money back and reverses the fees.
     */
    @Transactional
    public WalletResponse withdraw(User user, com.nearbyservices.dto.WithdrawWalletRequest request) {
        if (request.getAmount() == null || request.getAmount().compareTo(BigDecimal.ZERO) <= 0) {
            throw ApiException.badRequest("INVALID_AMOUNT");
        }
        long amount;
        try {
            amount = request.getAmount().longValueExact();
        } catch (ArithmeticException e) {
            throw ApiException.badRequest("INVALID_AMOUNT");
        }
        String phone = PayoutPhone.normalize(request.getPhone());
        if (phone == null) throw ApiException.badRequest("INVALID_PHONE_NUMBER");
        var limits = paymentSettingsService.withdrawLimits();
        if (amount < limits.min()) throw ApiException.badRequest("WITHDRAW_BELOW_MIN");
        if (limits.max() != null && amount > limits.max()) throw ApiException.badRequest("WITHDRAW_ABOVE_MAX");

        var fees = paymentSettingsService.fees();
        var f = ProviderFeeCalculator.withdrawal(amount, fees.getCollectionPercent(), fees.getVatPercent(), fees.getPayoutFee());
        if (f.net() <= 0) throw ApiException.badRequest("WITHDRAW_TOO_SMALL_FOR_FEES");

        getOrCreateWallet(user);
        // Row lock: two simultaneous withdrawals cannot both pass the balance check.
        Wallet wallet = walletRepository.findByUserIdForUpdate(user.getId()).orElseThrow();
        if (wallet.getBalance().compareTo(request.getAmount()) < 0) {
            throw ApiException.badRequest("INSUFFICIENT_BALANCE");
        }
        wallet.setBalance(wallet.getBalance().subtract(request.getAmount()));
        Wallet saved = walletRepository.save(wallet);

        String ref = "WD-" + java.util.UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        walletTransactionRepository.save(WalletTransaction.builder()
                .userId(user.getId()).type("WITHDRAWAL").direction("OUT").amount(request.getAmount())
                .status("PENDING").reference(ref)
                .collectionFee(f.collection()).chargeFee(f.charge()).payoutPart(f.payoutPart())
                .vatPart(f.vatPart()).netAmount(f.net()).payoutPhone(phone).build());
        platformWallet.income(PlatformWalletService.COLLECTION_FEE, BigDecimal.valueOf(f.collection()), null, ref);
        platformWallet.income(PlatformWalletService.PAYOUT_FEE, BigDecimal.valueOf(f.payoutPart()), null, ref);
        platformWallet.income(PlatformWalletService.VAT, BigDecimal.valueOf(f.vatPart()), null, ref);

        if (adminAlerts != null) adminAlerts.withdrawalRequested(ref);

        WalletResponse out = mapToResponse(saved);
        out.setFee(f.totalFee());
        out.setNetAmount(f.net());
        out.setReference(ref);
        return out;
    }

    /** A booking refund: the buyer gets back {@code refund}; the charge is the platform's (see EscrowService). */
    @Transactional
    public void recordRefund(Long buyerId, BigDecimal refunded, String title, String reference) {
        if (refunded.signum() > 0) record(buyerId, "REFUND", "IN", refunded, "COMPLETED", title, reference);
    }

    /**
     * Adds one line to a user's wallet history. Joins the caller's transaction, so the line is saved
     * or rolled back together with the balance change it describes.
     */
    @Transactional
    public void record(Long userId, String type, String direction, BigDecimal amount, String status,
                       String title, String reference) {
        walletTransactionRepository.save(WalletTransaction.builder()
                .userId(userId).type(type).direction(direction).amount(amount)
                .status(status).title(title).reference(reference).build());
    }

    /** The caller's own history, newest first. Limit is clamped to 1..200. */
    @Transactional(readOnly = true)
    public List<WalletTransactionResponse> history(User user, int limit) {
        int n = Math.max(1, Math.min(limit, 200));
        return walletTransactionRepository.findByUserIdOrderByCreatedAtDescIdDesc(user.getId(), PageRequest.of(0, n))
                .stream()
                .map(t -> WalletTransactionResponse.builder()
                        .id(t.getId()).type(t.getType()).amount(t.getAmount()).status(t.getStatus())
                        .title(t.getTitle()).reference(t.getReference()).createdAt(t.getCreatedAt())
                        .direction(t.getDirection())
                        .fee(t.getCollectionFee() == null ? null : t.getCollectionFee() + (t.getChargeFee() == null ? 0 : t.getChargeFee()))
                        .netAmount(t.getNetAmount()).build())
                .toList();
    }

    public WalletResponse mapToResponse(Wallet wallet) {
        return WalletResponse.builder()
                .id(wallet.getId())
                .userId(wallet.getUser().getId())
                .balance(wallet.getBalance())
                .lockedEscrowBalance(wallet.getLockedEscrowBalance())
                .updatedAt(wallet.getUpdatedAt())
                .withdrawn(walletTransactionRepository.sumWithdrawn(wallet.getUser().getId()))
                .build();
    }
}
