package com.nearbyservices.service;

import com.nearbyservices.dto.NidaBlueTickRequest;
import com.nearbyservices.dto.NidaGreenBadgeRequest;
import com.nearbyservices.dto.PublicUserDto;
import com.nearbyservices.model.User;
import com.nearbyservices.model.VerificationBadge;
import com.nearbyservices.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class VerificationService {

    private final UserRepository userRepository;
    private final com.nearbyservices.repository.UserVerificationProfileRepository profileRepository;
    private final com.nearbyservices.repository.EscrowTransactionRepository escrowRepository;
    private final ChatSocketRegistry chatSocketRegistry;

    /**
     * Rule: Green Badge requires NIDA Number only.
     * NIDA official info is saved privately and NEVER exposed to the public.
     */
    @Transactional
    public PublicUserDto applyGreenBadge(User currentUser, NidaGreenBadgeRequest request) {
        // Green is now earned by Identity Verification (approved ID papers or a trusted invitation), never by typing a number.
        if (true) throw com.nearbyservices.exception.ApiException.gone("USE_IDENTITY_VERIFICATION");
        if (request.getNidaNumber() == null || request.getNidaNumber().trim().length() != 20) {
            throw new IllegalArgumentException("NIDA number must be 20 digits");
        }

        // Check if NIDA is already used by another user
        userRepository.findAll().stream()
                .filter(u -> !u.getId().equals(currentUser.getId()) && request.getNidaNumber().equals(u.getNidaNumber()))
                .findAny()
                .ifPresent(u -> {
                    throw new IllegalArgumentException("NIDA number is already verified for another account");
                });

        currentUser.setNidaNumber(request.getNidaNumber());
        currentUser.setNidaOfficialFirstName(request.getOfficialFirstName());
        currentUser.setNidaOfficialLastName(request.getOfficialLastName());

        // Elevate to Green Badge if not already Blue Tick
        if (currentUser.getVerificationBadge() == VerificationBadge.NONE) {
            currentUser.setVerificationBadge(VerificationBadge.GREEN_BADGE);
        }

        User updated = userRepository.save(currentUser);
        return mapToPublicDto(updated);
    }

    /**
     * Rule: Blue Tick requires NIDA ID + Photo with ID, OR invitation by an already verified Blue Tick member.
     */
    @Transactional
    public PublicUserDto applyBlueTick(User currentUser, NidaBlueTickRequest request) {
        // Blue is now Verified Business, approved by an admin. This old call trusted the app's own inviter id and photo links.
        if (true) throw com.nearbyservices.exception.ApiException.gone("USE_IDENTITY_VERIFICATION");
        // Path A: Verification via Invitation by another Blue Tick user
        if (request.getInviterUserId() != null) {
            User inviter = userRepository.findById(request.getInviterUserId())
                    .orElseThrow(() -> new IllegalArgumentException("Inviting user not found"));

            if (inviter.getVerificationBadge() != VerificationBadge.BLUE_TICK) {
                throw new IllegalStateException("Inviting user does not hold an active Blue Tick badge");
            }

            currentUser.setInvitedByUserId(inviter.getId());
            currentUser.setVerificationBadge(VerificationBadge.BLUE_TICK);
            User updated = userRepository.save(currentUser);
            return mapToPublicDto(updated);
        }

        // Path B: Verification via NIDA ID + Photo verification
        if (request.getIdPhotoUrl() == null || request.getIdPhotoUrl().isBlank()) {
            throw new IllegalArgumentException("NIDA ID photo is required for Blue Tick verification");
        }
        if (request.getSelfieWithIdUrl() == null || request.getSelfieWithIdUrl().isBlank()) {
            throw new IllegalArgumentException("Photo selfie holding NIDA ID is required for Blue Tick verification");
        }

        if (request.getNidaNumber() != null && !request.getNidaNumber().isBlank()) {
            currentUser.setNidaNumber(request.getNidaNumber());
        }

        currentUser.setNidaIdPhotoUrl(request.getIdPhotoUrl());
        currentUser.setNidaSelfiePhotoUrl(request.getSelfieWithIdUrl());
        currentUser.setVerificationBadge(VerificationBadge.BLUE_TICK);

        User updated = userRepository.save(currentUser);
        return mapToPublicDto(updated);
    }

    public PublicUserDto getPublicProfile(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found with id: " + userId));
        return mapToSellerDto(user);
    }

    /** The public DTO plus what a provider's page shows: member since, jobs done, bookings, online now. */
    public PublicUserDto mapToSellerDto(User user) {
        PublicUserDto dto = mapToPublicDto(user);
        dto.setCreatedAt(user.getCreatedAt());
        dto.setCompletedJobs((int) escrowRepository.countBySellerIdAndStatus(user.getId(), com.nearbyservices.model.EscrowStatus.COMPLETED));
        dto.setTotalBookings((int) escrowRepository.countBySellerId(user.getId()));
        dto.setOnline(chatSocketRegistry.isOnline(user.getId()));
        dto.setProfileLocked(user.isProfileLocked());
        return dto;
    }

    public PublicUserDto mapToPublicDto(User user) {
        com.nearbyservices.model.UserVerificationProfile vp = profileRepository.findById(user.getId()).orElse(null);
        boolean business = IdentityVerificationService.businessActive(vp);
        return PublicUserDto.builder()
                .businessVerified(business)
                .businessName(business ? vp.getBusinessName() : null)
                .id(user.getId())
                .stageName(user.getStageName())
                .verificationBadge(user.getVerificationBadge())
                .adultOnly(user.is18Plus())
                .avatarUrl(user.getAvatarUrl())
                .coverUrl(user.getCoverUrl())
                .bio(user.getBio())
                .build();
    }
}
