package com.nearbyservices.service;

import java.net.URI;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Checks the admin's own ("in-house") ads with the same rules as docs/ads_config_api_contract.md.
 * Returns an error code such as "INVALID_HOUSE_AD:promo-1:title", or null when every ad is fine.
 * It only checks: the document is stored exactly as sent, so keys it does not know (title_TZ ...) are never dropped.
 */
final class HouseAdsValidator {

    static final int MAX_ADS = 20;
    private static final Pattern ID = Pattern.compile("^[A-Za-z0-9_-]{1,40}$");
    private static final Pattern COUNTRY = Pattern.compile("^[A-Za-z]{2}$");
    private static final Set<String> FORMATS = Set.of("banner", "native", "rewarded");
    private static final Set<String> PLATFORMS = Set.of("android", "ios");
    private static final Set<String> TEXT_FIELDS = Set.of("title", "body", "cta");
    private static final Set<String> URL_FIELDS = Set.of("imageUrl", "url");

    private HouseAdsValidator() {
    }

    static String validate(Object house, Set<String> pages) {
        if (house == null) return null;
        if (!(house instanceof List<?> list)) return "INVALID_HOUSE_ADS";
        if (list.size() > MAX_ADS) return "TOO_MANY_HOUSE_ADS";
        Set<String> seen = new HashSet<>();
        for (int i = 0; i < list.size(); i++) {
            if (!(list.get(i) instanceof Map<?, ?> ad)) return "INVALID_HOUSE_AD:#" + (i + 1);
            Object rawId = ad.get("id");
            String id = rawId == null ? "" : String.valueOf(rawId).trim();
            if (!ID.matcher(id).matches()) return "INVALID_HOUSE_AD:#" + (i + 1) + ":id";
            if (!seen.add(id)) return "INVALID_HOUSE_AD:" + id + ":id_duplicate";
            String err = checkAd(id, ad, pages);
            if (err != null) return err;
        }
        return null;
    }

    private static String checkAd(String id, Map<?, ?> ad, Set<String> pages) {
        String p = "INVALID_HOUSE_AD:" + id + ":";
        // Required text and links.
        if (text(ad.get("title")).isEmpty() || text(ad.get("title")).length() > 60) return p + "title";
        if (text(ad.get("body")).length() > 140) return p + "body";
        if (text(ad.get("cta")).length() > 24) return p + "cta";
        if (!httpsLink(text(ad.get("imageUrl")))) return p + "imageUrl";
        if (!httpsLink(text(ad.get("url")))) return p + "url";

        // Lists of allowed values.
        if (!subset(ad.get("formats"), FORMATS, false)) return p + "formats";
        if (!subset(ad.get("pages"), pages, false)) return p + "pages";
        if (!subset(ad.get("platforms"), PLATFORMS, false)) return p + "platforms";
        Object countries = ad.get("countries");
        if (countries != null) {
            if (!(countries instanceof List<?> cl)) return p + "countries";
            for (Object c : cl) if (!COUNTRY.matcher(text(c)).matches()) return p + "countries";
        }

        // Text per country: title_TZ, body_KE, cta_TZ, imageUrl_KE, url_TZ follow the same rules as the plain field.
        for (Map.Entry<?, ?> e : ad.entrySet()) {
            String key = String.valueOf(e.getKey());
            int us = key.lastIndexOf('_');
            if (us <= 0 || key.length() - us - 1 != 2) continue;
            String base = key.substring(0, us);
            if (!COUNTRY.matcher(key.substring(us + 1)).matches()) continue;
            String v = text(e.getValue());
            if (v.isEmpty()) continue; // blank = use the plain field
            if (base.equals("title") && v.length() > 60) return p + key;
            if (base.equals("body") && v.length() > 140) return p + key;
            if (base.equals("cta") && v.length() > 24) return p + key;
            if (URL_FIELDS.contains(base) && !httpsLink(v)) return p + key;
        }

        // Numbers.
        if (ad.get("rewardSeconds") != null && !wholeBetween(ad.get("rewardSeconds"), 3, 30)) return p + "rewardSeconds";
        if (ad.get("weight") != null && !wholeBetween(ad.get("weight"), 1, 100)) return p + "weight";

        // Dates and the on/off flag.
        Instant start = null, end = null;
        if (ad.get("start") != null && !text(ad.get("start")).isEmpty()) {
            start = instant(text(ad.get("start")));
            if (start == null) return p + "start";
        }
        if (ad.get("end") != null && !text(ad.get("end")).isEmpty()) {
            end = instant(text(ad.get("end")));
            if (end == null) return p + "end";
        }
        if (start != null && end != null && !end.isAfter(start)) return p + "end";
        Object enabled = ad.get("enabled");
        if (enabled != null && !(enabled instanceof Boolean)) return p + "enabled";
        return null;
    }

    private static String text(Object o) {
        return o == null ? "" : String.valueOf(o).trim();
    }

    /** A full https link, at most 500 characters, with no user:pass@ in it. */
    static boolean httpsLink(String v) {
        if (v.isEmpty() || v.length() > 500) return false;
        try {
            URI u = new URI(v);
            return "https".equalsIgnoreCase(u.getScheme()) && u.getHost() != null && !u.getHost().isBlank() && u.getUserInfo() == null;
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean subset(Object value, Set<String> allowed, boolean allowEmpty) {
        if (value == null) return true;
        if (!(value instanceof List<?> l)) return false;
        if (l.isEmpty() && !allowEmpty) return false;
        for (Object o : l) if (!allowed.contains(text(o).toLowerCase(Locale.ROOT)) && !allowed.contains(text(o))) return false;
        return true;
    }

    private static boolean wholeBetween(Object o, int min, int max) {
        if (!(o instanceof Number n)) return false;
        double d = n.doubleValue();
        return d == Math.rint(d) && d >= min && d <= max;
    }

    private static Instant instant(String v) {
        try {
            return OffsetDateTime.parse(v).toInstant();
        } catch (Exception e) {
            try {
                return Instant.parse(v);
            } catch (Exception e2) {
                return null;
            }
        }
    }
}
