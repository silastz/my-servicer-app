package com.nearbyservices.service;

import com.nearbyservices.model.OfferStatus;
import com.nearbyservices.model.PriceOffer;
import com.nearbyservices.repository.PriceOfferRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Set;

/**
 * Every 10 minutes: an open offer with about two hours left gets one reminder to the person who must act.
 * Each step is reminded once (the flag is cleared when the offer moves on, so the booking deadline gets its own).
 * Expiry itself is still applied lazily on every offer call; this job only sends the reminders.
 * Written for ONE running server. With several, give each offer to one of them (a lock) or a reminder can go twice.
 */
@Component
@RequiredArgsConstructor
public class OfferReminderJob {

    private static final Logger log = LoggerFactory.getLogger(OfferReminderJob.class);
    private static final int HOURS_LEFT = 2;

    private final PriceOfferRepository offerRepository;
    private final OfferAlerts alerts;
    private final JobLock jobLock;

    @Scheduled(fixedDelay = 10 * 60 * 1000L, initialDelay = 60 * 1000L)
    @Transactional
    public void remind() {
        jobLock.run("offer-reminder", this::remindLocked);
    }

    private void remindLocked() {
        try {
            Instant now = Instant.now();
            List<PriceOffer> due = offerRepository.findDueForReminder(
                    Set.of(OfferStatus.OFFERED, OfferStatus.AGREED), now, now.plus(HOURS_LEFT, ChronoUnit.HOURS));
            for (PriceOffer o : due) {
                o.setReminderSent(true);
                offerRepository.save(o);
                alerts.expiringSoon(o);
            }
            if (!due.isEmpty()) log.info("Sent {} offer expiry reminders", due.size());
        } catch (Exception e) {
            log.warn("Offer reminder run failed: {}", e.getMessage());
        }
    }
}
