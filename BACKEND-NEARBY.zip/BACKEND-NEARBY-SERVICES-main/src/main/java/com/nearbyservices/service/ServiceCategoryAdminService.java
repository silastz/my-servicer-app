package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.ServiceCategory;
import com.nearbyservices.repository.ServiceCategoryRepository;
import com.nearbyservices.repository.ServicePostRepository;
import com.nearbyservices.verification.AuditLog;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Admin management of the service categories. The id (the key services are saved under) never changes; the
 * admin renames the display names, reorders, switches a category off, or deletes one that no service uses.
 * A switched-off category disappears from the app and is refused for NEW services; existing services keep it.
 */
@Service
@RequiredArgsConstructor
public class ServiceCategoryAdminService {

    private static final Pattern ID = Pattern.compile("^[A-Za-z][A-Za-z0-9 &'-]{1,59}$");

    private final ServiceCategoryRepository repo;
    private final ServicePostRepository posts;
    private final AuditLog auditLog;

    @Transactional(readOnly = true)
    public List<Map<String, Object>> all() {
        return repo.findAll().stream()
                .sorted(Comparator.comparingInt(ServiceCategory::getSortOrder).thenComparing(ServiceCategory::getId))
                .map(this::json).toList();
    }

    /** What the app shows: active categories only, in order. */
    @Transactional(readOnly = true)
    public List<Map<String, Object>> publicList() {
        return repo.findByActiveTrueOrderBySortOrderAscIdAsc().stream().map(c -> {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", c.getId());
            m.put("nameEn", c.getNameEn());
            m.put("nameSw", c.getNameSw());
            return m;
        }).toList();
    }

    /** True when a NEW service may use this category. With no categories saved at all, anything goes (old behaviour). */
    @Transactional(readOnly = true)
    public boolean allowsNewService(String category) {
        if (repo.count() == 0) return true;
        return repo.findByIdIgnoreCase(category.trim()).map(ServiceCategory::isActive).orElse(false);
    }

    /** The saved spelling of a category id (so "plumbing" is stored as "Plumbing"), or the input if unknown. */
    @Transactional(readOnly = true)
    public String canonical(String category) {
        String c = category.trim();
        return repo.findByIdIgnoreCase(c).map(ServiceCategory::getId).orElse(c);
    }

    /** Body: {id, nameEn?, nameSw?, sortOrder?, active?}. Missing names default to the id. */
    @Transactional
    public Map<String, Object> create(long adminId, Map<String, Object> body) {
        String id = text(body.get("id"));
        if (!ID.matcher(id).matches()) throw ApiException.badRequest("INVALID_CATEGORY_ID");
        if (repo.findByIdIgnoreCase(id).isPresent()) throw ApiException.conflict("CATEGORY_ID_IN_USE");
        String en = body.get("nameEn") == null ? id : name(body.get("nameEn"));
        String sw = body.get("nameSw") == null ? en : name(body.get("nameSw"));
        int order = body.get("sortOrder") == null ? repo.findAll().stream().mapToInt(ServiceCategory::getSortOrder).max().orElse(0) + 1
                : order(body.get("sortOrder"));
        ServiceCategory c = ServiceCategory.builder().id(id).nameEn(en).nameSw(sw).sortOrder(order)
                .active(!Boolean.FALSE.equals(body.get("active"))).build();
        repo.save(c);
        auditLog.record(adminId, "SERVICE_CATEGORY_CREATED", describe(c));
        return json(c);
    }

    /** Only the fields present in the body change. */
    @Transactional
    public Map<String, Object> update(long adminId, String id, Map<String, Object> body) {
        ServiceCategory c = repo.findById(id).orElseThrow(() -> ApiException.notFound("CATEGORY_NOT_FOUND"));
        String before = describe(c);
        if (body.get("nameEn") != null) c.setNameEn(name(body.get("nameEn")));
        if (body.get("nameSw") != null) c.setNameSw(name(body.get("nameSw")));
        if (body.get("sortOrder") != null) c.setSortOrder(order(body.get("sortOrder")));
        if (body.get("active") != null) c.setActive(Boolean.parseBoolean(body.get("active").toString()));
        repo.save(c);
        auditLog.record(adminId, "SERVICE_CATEGORY_CHANGED", "before " + before + " after " + describe(c));
        return json(c);
    }

    /** Only a category no service uses can be deleted; otherwise switch it off (active=false). */
    @Transactional
    public void delete(long adminId, String id) {
        ServiceCategory c = repo.findById(id).orElseThrow(() -> ApiException.notFound("CATEGORY_NOT_FOUND"));
        if (posts.countByCategoryIgnoreCase(c.getId()) > 0) throw ApiException.conflict("CATEGORY_IN_USE");
        repo.delete(c);
        auditLog.record(adminId, "SERVICE_CATEGORY_DELETED", describe(c));
    }

    private static String name(Object o) {
        String v = text(o);
        if (v.isEmpty() || v.length() > 80) throw ApiException.badRequest("INVALID_CATEGORY_NAME");
        return v;
    }

    private static int order(Object o) {
        try {
            int v = new java.math.BigDecimal(text(o)).intValueExact();
            if (v < 0 || v > 10_000) throw new ArithmeticException();
            return v;
        } catch (ArithmeticException | NumberFormatException e) {
            throw ApiException.badRequest("INVALID_SORT_ORDER");
        }
    }

    private static String text(Object o) {
        return o == null ? "" : o.toString().trim();
    }

    private static String describe(ServiceCategory c) {
        return c.getId() + " en=" + c.getNameEn() + " sw=" + c.getNameSw() + " order=" + c.getSortOrder() + " active=" + c.isActive();
    }

    private Map<String, Object> json(ServiceCategory c) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", c.getId());
        m.put("nameEn", c.getNameEn());
        m.put("nameSw", c.getNameSw());
        m.put("sortOrder", c.getSortOrder());
        m.put("active", c.isActive());
        m.put("services", posts.countByCategoryIgnoreCase(c.getId()));
        return m;
    }
}
