package com.nearbyservices.service;

import com.nearbyservices.model.EscrowTransaction;
import com.nearbyservices.model.Payment;
import com.nearbyservices.model.Report;
import com.nearbyservices.model.Role;
import com.nearbyservices.model.User;
import com.nearbyservices.repository.UserRepository;
import com.nearbyservices.service.PushService.Text;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Push alerts to the admins: a new report, a payment dispute, a withdrawal waiting to be paid out.
 *
 * Every active admin gets it (deleted and suspended accounts are skipped). The push `type` starts with "admin_" and
 * deliberately matches none of the user notification switches (bookings / messages / promos), so an admin alert is
 * never muted by them. Nothing here can break the request that caused it: failures are logged and swallowed.
 */
@Component
@RequiredArgsConstructor
public class AdminAlerts {

    private static final Logger log = LoggerFactory.getLogger(AdminAlerts.class);

    private final PushService push;
    private final UserRepository userRepository;

    /** When each alert key was last sent, so the same problem does not buzz the admins again and again. */
    private final Map<String, Long> lastSent = new ConcurrentHashMap<>();

    public void newReport(Report r) {
        String what = switch (r.getType() == null ? "" : r.getType()) {
            case "SERVICE" -> "a service";
            case "USER" -> "a user";
            default -> "a problem";
        };
        String whatSw = switch (r.getType() == null ? "" : r.getType()) {
            case "SERVICE" -> "huduma";
            case "USER" -> "mtumiaji";
            default -> "tatizo";
        };
        toAdmins(Category.REPORTS, new Text("New report", "Ripoti mpya"),
                new Text("A user reported " + what + ": " + r.getReason(), "Mtumiaji ameripoti " + whatSw + ": " + r.getReason()),
                data("admin_report", r.getId()));
    }

    /** The provider says the payment never arrived: the admin may have to decide. */
    public void paymentDispute(EscrowTransaction tx) {
        String ref = tx.getTransactionRef();
        toAdmins(Category.DISPUTES, new Text("Payment dispute", "Mgogoro wa malipo"),
                new Text("A provider says a payment did not arrive (booking " + ref + ").",
                        "Mtoa huduma anasema malipo hayajafika (ombi " + ref + ")."),
                data("admin_dispute", ref));
    }

    public void withdrawalRequested(String reference) {
        toAdmins(Category.WITHDRAWALS, new Text("Withdrawal to pay out", "Ombi la kutoa pesa"),
                new Text("A provider asked to withdraw money (" + reference + ").",
                        "Mtoa huduma ameomba kutoa pesa (" + reference + ")."),
                data("admin_withdrawal", reference));
    }

    /** The gateway said the payment FAILED (once per payment, however often the gateway repeats it). */
    public void paymentFailed(Payment p) {
        if (!allow("failed:" + p.getReference(), 24 * HOUR)) return;
        String what = p.getPurpose() + " " + p.getAmount().toPlainString() + " via " + p.getGateway();
        toAdmins(Category.PAYMENTS, new Text("Payment failed", "Malipo yameshindikana"),
                new Text("A payment failed: " + what + " (" + p.getReference() + ").",
                        "Malipo yameshindikana: " + what + " (" + p.getReference() + ")."),
                data("admin_pay_error", p.getReference()));
    }

    /** The payment gateway itself could not start a payment (down, refused our request, bad keys). At most one alert per 10 minutes per gateway. */
    public void paymentGatewayError(String gatewayId, String purpose, String reference, String problem) {
        if (!allow("gw:" + gatewayId, 10 * MINUTE)) return;
        toAdminsNow(Category.PAYMENTS, new Text("Payment gateway error", "Hitilafu ya mfumo wa malipo"),
                new Text(gatewayId + " could not start a " + purpose + " payment (" + problem + ", " + reference + ").",
                        gatewayId + " imeshindwa kuanza malipo ya " + purpose + " (" + problem + ", " + reference + ")."),
                data("admin_pay_error", reference));
    }

    /** A gateway event that does not match the payment (wrong amount or reference): worth a human look. */
    public void paymentMismatch(String reference, String problem) {
        if (!allow("mismatch:" + reference, HOUR)) return;
        toAdminsNow(Category.PAYMENTS, new Text("Payment does not match", "Malipo hayalingani"),
                new Text("A payment event did not match our records (" + problem + ", " + reference + "). Please check it.",
                        "Tukio la malipo halilingani na kumbukumbu zetu (" + problem + ", " + reference + "). Tafadhali liangalie."),
                data("admin_pay_error", reference));
    }

    private static final long MINUTE = 60_000L;
    private static final long HOUR = 60 * MINUTE;

    /** True when this key has not been sent within {@code windowMs}; records the send. */
    private boolean allow(String key, long windowMs) {
        long now = System.currentTimeMillis();
        if (lastSent.size() > 2000) lastSent.values().removeIf(t -> now - t > 24 * HOUR);
        Long prev = lastSent.put(key, now);
        if (prev != null && now - prev < windowMs) {
            lastSent.put(key, prev); // keep the first send's time, so the window does not slide forever
            return false;
        }
        return true;
    }

    /** The switches an admin can turn on or off (Admin > Notification Preferences). */
    public enum Category { REPORTS, DISPUTES, WITHDRAWALS, PAYMENTS }

    static boolean wants(User admin, Category c) {
        return switch (c) {
            case REPORTS -> admin.isNotifAdminReports();
            case DISPUTES -> admin.isNotifAdminDisputes();
            case WITHDRAWALS -> admin.isNotifAdminWithdrawals();
            case PAYMENTS -> admin.isNotifAdminPayments();
        };
    }

    private void toAdmins(Category c, Text title, Text body, Map<String, Object> data) {
        send(c, title, body, data, false);
    }

    /** For alerts raised while a request is failing (its transaction will roll back): sent immediately. */
    private void toAdminsNow(Category c, Text title, Text body, Map<String, Object> data) {
        send(c, title, body, data, true);
    }

    private void send(Category c, Text title, Text body, Map<String, Object> data, boolean now) {
        if (!push.enabled()) return;
        try {
            for (User admin : userRepository.findByRole(Role.ROLE_ADMIN)) {
                if (admin.getDeletedAt() != null || admin.isSuspended() || !wants(admin, c)) continue;
                if (now) push.toUserNow(admin.getId(), title, body, data);
                else push.toUser(admin.getId(), title, body, data);
            }
        } catch (RuntimeException e) {
            log.warn("Admin alert failed: {}", e.getClass().getSimpleName());
        }
    }

    private static Map<String, Object> data(String type, Object id) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("type", type);
        m.put("id", String.valueOf(id));
        return m;
    }
}
