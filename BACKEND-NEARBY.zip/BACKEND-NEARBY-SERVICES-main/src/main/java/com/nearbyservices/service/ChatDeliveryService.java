package com.nearbyservices.service;

import com.nearbyservices.repository.ChatMessageRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Delivery ticks. One tick = stored on the server, two ticks = the recipient's app is online and
 * has it, blue ticks = they opened the chat (see ChatService).
 * REQUIRES_NEW: these run right after another transaction committed (or from the socket thread).
 */
@Service
@RequiredArgsConstructor
public class ChatDeliveryService {

    private final ChatMessageRepository repository;

    /** True when this call is the one that marked it delivered. */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public boolean markMessageDelivered(Long messageId) {
        return repository.markDeliveredById(messageId, LocalDateTime.now()) > 0;
    }

    /** The user just came online: everything waiting for them is delivered. Returns the senders to tell. */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public List<Long> markAllDelivered(Long userId) {
        List<Long> senders = repository.findUndeliveredSenderIds(userId);
        if (!senders.isEmpty()) repository.markDelivered(userId, LocalDateTime.now());
        return senders;
    }
}
