package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.Report;
import com.nearbyservices.model.ServicePost;
import com.nearbyservices.model.User;
import com.nearbyservices.repository.ReportRepository;
import com.nearbyservices.repository.ServicePostRepository;
import com.nearbyservices.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class ReportService {

    private static final Set<String> TYPES = Set.of("SERVICE", "USER", "GENERAL");
    private static final Set<String> STATUSES = Set.of("OPEN", "REVIEWING", "RESOLVED", "DISMISSED");
    private static final int MAX_PER_DAY = 20;

    private final ReportRepository reportRepository;
    private final ServicePostRepository servicePostRepository;
    private final UserRepository userRepository;

    /** Optional: tells the admins about a new report (null in unit tests). */
    @org.springframework.beans.factory.annotation.Autowired(required = false)
    private AdminAlerts adminAlerts;

    @Transactional
    public Map<String, Object> submit(User reporter, String rawType, String rawReason, String rawDetails,
                                      Long serviceId, Long reportedUserId) {
        String type = rawType == null ? "" : rawType.trim().toUpperCase(Locale.ROOT);
        if (!TYPES.contains(type)) throw ApiException.badRequest("INVALID_REPORT_TYPE");
        String reason = rawReason == null ? "" : rawReason.trim();
        if (reason.isEmpty()) throw ApiException.badRequest("REASON_REQUIRED");
        if (reason.length() > 100) reason = reason.substring(0, 100);
        String details = rawDetails == null ? null : rawDetails.trim();
        if (details != null && details.isEmpty()) details = null;
        if (details != null && details.length() > 2000) throw ApiException.badRequest("DETAILS_TOO_LONG");

        Long targetService = null;
        Long targetUser = null;
        if (type.equals("SERVICE")) {
            if (serviceId == null) throw ApiException.badRequest("SERVICE_REQUIRED");
            ServicePost post = servicePostRepository.findById(serviceId)
                    .orElseThrow(() -> ApiException.notFound("SERVICE_NOT_FOUND"));
            if (post.getSeller().getId().equals(reporter.getId())) throw ApiException.badRequest("CANNOT_REPORT_YOURSELF");
            targetService = post.getId();
            targetUser = post.getSeller().getId(); // taken from the service, never trusted from the app
        } else if (type.equals("USER")) {
            if (reportedUserId == null) throw ApiException.badRequest("USER_REQUIRED");
            if (reportedUserId.equals(reporter.getId())) throw ApiException.badRequest("CANNOT_REPORT_YOURSELF");
            if (!userRepository.existsById(reportedUserId)) throw ApiException.notFound("USER_NOT_FOUND");
            targetUser = reportedUserId;
        }

        // The app may resend: the same open report is returned, not stored twice.
        if (type.equals("SERVICE") || type.equals("USER")) {
            var dup = reportRepository.findFirstByReporterIdAndTypeAndServiceIdAndReportedUserIdAndStatusIn(
                    reporter.getId(), type, targetService, targetUser, List.of("OPEN", "REVIEWING"));
            if (dup.isPresent()) return json(dup.get());
        }
        if (reportRepository.countByReporterIdAndCreatedAtAfter(reporter.getId(), LocalDateTime.now().minusDays(1)) >= MAX_PER_DAY) {
            throw ApiException.tooManyRequests("TOO_MANY_REPORTS");
        }

        Report saved = reportRepository.save(Report.builder()
                .reporterId(reporter.getId()).type(type).serviceId(targetService).reportedUserId(targetUser)
                .reason(reason).details(details).build());
        if (adminAlerts != null) adminAlerts.newReport(saved);
        return json(saved);
    }

    // ---------------------------------------------------------------- admin

    @Transactional(readOnly = true)
    public List<Map<String, Object>> list(String status, int limit) {
        var page = PageRequest.of(0, Math.min(Math.max(limit, 1), 200));
        List<Report> rows = (status == null || status.isBlank())
                ? reportRepository.findAllByOrderByCreatedAtDesc(page)
                : reportRepository.findByStatusOrderByCreatedAtDesc(status.trim().toUpperCase(Locale.ROOT), page);
        return rows.stream().map(r -> json(r, true)).toList();
    }

    @Transactional
    public Map<String, Object> setStatus(Long id, String status, String note) {
        String s = status == null ? "" : status.trim().toUpperCase(Locale.ROOT);
        if (!STATUSES.contains(s)) throw ApiException.badRequest("INVALID_STATUS");
        Report r = reportRepository.findById(id).orElseThrow(() -> ApiException.notFound("REPORT_NOT_FOUND"));
        r.setStatus(s);
        if (note != null) r.setAdminNote(note.trim().length() > 1000 ? note.trim().substring(0, 1000) : note.trim());
        return json(reportRepository.save(r), true);
    }

    private Map<String, Object> json(Report r) {
        return json(r, false);
    }

    private Map<String, Object> json(Report r, boolean admin) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", r.getId());
        m.put("type", r.getType());
        m.put("reason", r.getReason());
        m.put("details", r.getDetails() == null ? "" : r.getDetails());
        m.put("status", r.getStatus());
        m.put("createdAt", r.getCreatedAt());
        if (r.getServiceId() != null) m.put("serviceId", r.getServiceId());
        if (r.getReportedUserId() != null) m.put("reportedUserId", r.getReportedUserId());
        if (admin) {
            m.put("reporterId", r.getReporterId());
            m.put("adminNote", r.getAdminNote() == null ? "" : r.getAdminNote());
        }
        return m;
    }
}
