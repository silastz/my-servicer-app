package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.User;
import com.nearbyservices.model.UserBlock;
import com.nearbyservices.repository.UserBlockRepository;
import com.nearbyservices.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * Block list. A block works in both directions for contact: neither person can message or book the
 * other, and neither sees the other's services. Only the person who blocked sees it in their list,
 * so the blocked person is never told.
 */
@Service
@RequiredArgsConstructor
public class UserBlockService {

    private final UserBlockRepository blockRepository;
    private final UserRepository userRepository;

    @Transactional
    public void block(User me, Long targetId, String reason, String details) {
        if (me.getId().equals(targetId)) throw ApiException.badRequest("CANNOT_BLOCK_YOURSELF");
        if (!userRepository.existsById(targetId)) throw ApiException.notFound("USER_NOT_FOUND");
        if (blockRepository.existsByBlockerIdAndBlockedId(me.getId(), targetId)) return; // already blocked
        try {
            blockRepository.saveAndFlush(UserBlock.builder()
                    .blockerId(me.getId()).blockedId(targetId)
                    .reason(limit(reason, 100)).details(limit(details, 1000)).build());
        } catch (DataIntegrityViolationException raced) {
            // a parallel request blocked first: same result
        }
    }

    @Transactional
    public void unblock(User me, Long targetId) {
        blockRepository.deletePair(me.getId(), targetId);
    }

    @Transactional(readOnly = true)
    public List<Map<String, Object>> list(User me) {
        List<Map<String, Object>> out = new ArrayList<>();
        for (UserBlock b : blockRepository.findByBlockerIdOrderByCreatedAtDesc(me.getId())) {
            String name = userRepository.findById(b.getBlockedId())
                    .map(u -> u.getStageName() != null ? u.getStageName() : u.getUsername()).orElse("User");
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", b.getBlockedId());
            m.put("stageName", name);
            m.put("blockedAt", b.getCreatedAt());
            if (b.getReason() != null) m.put("reason", b.getReason());
            m.put("blockedUser", Map.of("id", b.getBlockedId(), "stageName", name));
            out.add(m);
        }
        return out;
    }

    /** People this user blocked. */
    @Transactional(readOnly = true)
    public Set<Long> blockedBy(Long userId) {
        return new HashSet<>(blockRepository.blockedIdsOf(userId));
    }

    /** People this user blocked plus people who blocked this user. */
    @Transactional(readOnly = true)
    public Set<Long> blockedEitherWay(Long userId) {
        Set<Long> s = new HashSet<>(blockRepository.blockedIdsOf(userId));
        s.addAll(blockRepository.blockerIdsOf(userId));
        return s;
    }

    @Transactional(readOnly = true)
    public boolean isBlockedEitherWay(Long a, Long b) {
        return blockRepository.existsByBlockerIdAndBlockedId(a, b) || blockRepository.existsByBlockerIdAndBlockedId(b, a);
    }

    private static String limit(String s, int max) {
        if (s == null) return null;
        String t = s.trim();
        if (t.isEmpty()) return null;
        return t.length() > max ? t.substring(0, max) : t;
    }
}
