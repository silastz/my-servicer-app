package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.Role;
import com.nearbyservices.model.User;
import com.nearbyservices.model.Wallet;
import com.nearbyservices.repository.ServicePostRepository;
import com.nearbyservices.repository.UserRepository;
import com.nearbyservices.repository.WalletRepository;
import jakarta.persistence.criteria.Predicate;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Admin: look up, suspend, reactivate and delete user accounts.
 *
 * Callers MUST already have checked ROLE_ADMIN (the controller does). Admin accounts can never be suspended or
 * deleted from here, so one admin cannot lock out another (or themselves). Nothing secret is returned: no password,
 * no OTP, no NIDA data, no GPS position.
 *
 * Suspending keeps the account and every record. The person cannot sign in (AuthService.login answers
 * 403 ACCOUNT_SUSPENDED), every token issued so far stops working (JwtService), and their services disappear from
 * search (ServiceMarketplaceService). Reactivating brings it all back.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class UserAdminService {

    public static final int MAX_PAGE_SIZE = 100;
    private static final int MAX_REASON = 500;

    private final UserRepository userRepository;
    private final WalletRepository walletRepository;
    private final ServicePostRepository servicePostRepository;
    private final AccountDeletionService accountDeletionService;

    /**
     * One page of accounts, newest first.
     *
     * @param q      text matched against stage name, username, phone and email, or an exact user id; null/blank = everyone
     * @param status ACTIVE, SUSPENDED, DELETED or ALL (default ALL)
     * @param role   ROLE_BUYER, ROLE_SELLER, ROLE_ADMIN (the ROLE_ prefix is optional); null/blank = any
     */
    @Transactional(readOnly = true)
    public List<Map<String, Object>> list(String q, String status, String role, int page, int size) {
        final String st = normaliseStatus(status);
        final Role roleFilter = parseRole(role);
        final String text = q == null ? "" : q.trim();
        PageRequest pageable = PageRequest.of(Math.max(0, page), Math.min(Math.max(1, size), MAX_PAGE_SIZE),
                Sort.by(Sort.Direction.DESC, "id"));

        Specification<User> spec = (root, query, cb) -> {
            List<Predicate> p = new ArrayList<>();
            switch (st) {
                case "ACTIVE" -> {
                    p.add(cb.isNull(root.get("deletedAt")));
                    p.add(cb.isNull(root.get("suspendedAt")));
                }
                case "SUSPENDED" -> {
                    p.add(cb.isNull(root.get("deletedAt")));
                    p.add(cb.isNotNull(root.get("suspendedAt")));
                }
                case "DELETED" -> p.add(cb.isNotNull(root.get("deletedAt")));
                default -> { /* ALL */ }
            }
            if (roleFilter != null) p.add(cb.equal(root.get("role"), roleFilter));
            if (!text.isEmpty()) {
                String like = "%" + escapeLike(text.toLowerCase(Locale.ROOT)) + "%";
                List<Predicate> any = new ArrayList<>();
                for (String field : new String[]{"stageName", "username", "phone", "email"}) {
                    any.add(cb.like(cb.lower(root.<String>get(field)), like, '\\'));
                }
                if (text.matches("\\d{1,18}")) any.add(cb.equal(root.get("id"), Long.parseLong(text)));
                p.add(cb.or(any.toArray(new Predicate[0])));
            }
            return cb.and(p.toArray(new Predicate[0]));
        };

        return userRepository.findAll(spec, pageable).stream().map(UserAdminService::summary).toList();
    }

    /** The summary plus what an admin needs before deciding: country, wallet, services. */
    @Transactional(readOnly = true)
    public Map<String, Object> detail(long id) {
        User u = userRepository.findById(id).orElseThrow(() -> ApiException.notFound("USER_NOT_FOUND"));
        Map<String, Object> m = new LinkedHashMap<>(summary(u));
        m.put("emailVerified", u.isEmailVerified());
        m.put("country", UserSettingsService.countryOf(u));
        m.put("currency", UserSettingsService.currencyOf(u));
        m.put("servicesPosted", u.getServicesPosted());
        m.put("activeServices", servicePostRepository.findBySellerId(id).stream().filter(s -> s.isActive()).count());
        Wallet w = walletRepository.findByUserId(id).orElse(null);
        m.put("walletBalance", w == null ? "0" : w.getBalance().toPlainString());
        m.put("walletLocked", w == null ? "0" : w.getLockedEscrowBalance().toPlainString());
        m.put("deletedAt", u.getDeletedAt() == null ? null : u.getDeletedAt().toString());
        return m;
    }

    /** Blocks the account. A reason is required (the admin's own record of why). Suspending twice just updates the reason. */
    @Transactional
    public Map<String, Object> suspend(long adminId, long targetId, String rawReason) {
        String reason = rawReason == null ? "" : rawReason.trim();
        if (reason.isEmpty()) throw ApiException.badRequest("REASON_REQUIRED");
        if (reason.length() > MAX_REASON) throw ApiException.badRequest("REASON_TOO_LONG");

        User u = lockedTarget(adminId, targetId);
        if (u.getSuspendedAt() == null) u.setSuspendedAt(Instant.now());
        u.setSuspendReason(reason);
        // Every login issued so far stays dead even after a later reactivation.
        u.setTokensValidFrom(Instant.now());
        userRepository.save(u);
        log.info("Account {} suspended by admin {}", targetId, adminId);
        return summary(u);
    }

    /** Lets a suspended account sign in again (a fresh login is needed: the old tokens stay dead). */
    @Transactional
    public Map<String, Object> reactivate(long adminId, long targetId) {
        User u = lockedTarget(adminId, targetId);
        if (u.getSuspendedAt() != null) {
            u.setSuspendedAt(null);
            u.setSuspendReason(null);
            userRepository.save(u);
            log.info("Account {} reactivated by admin {}", targetId, adminId);
        }
        return summary(u);
    }

    /** Deletes (anonymises) the account, same rules as the owner's own deletion: ApiException 409 with WALLET_NOT_EMPTY, OPEN_BOOKINGS... */
    @Transactional
    public Map<String, Object> delete(long adminId, long targetId) {
        if (adminId == targetId) throw ApiException.forbidden("ADMIN_ACCOUNT");
        User u = userRepository.findById(targetId).orElseThrow(() -> ApiException.notFound("USER_NOT_FOUND"));
        if (u.getRole() == Role.ROLE_ADMIN) throw ApiException.forbidden("ADMIN_ACCOUNT");
        accountDeletionService.deleteByAdmin(adminId, targetId);
        return summary(userRepository.findById(targetId).orElse(u));
    }

    // ------------------------------------------------------------------------------------------------------------

    private User lockedTarget(long adminId, long targetId) {
        if (adminId == targetId) throw ApiException.forbidden("ADMIN_ACCOUNT");
        User u = userRepository.findByIdForUpdate(targetId).orElseThrow(() -> ApiException.notFound("USER_NOT_FOUND"));
        if (u.getRole() == Role.ROLE_ADMIN) throw ApiException.forbidden("ADMIN_ACCOUNT");
        if (u.getDeletedAt() != null) throw ApiException.conflict("ACCOUNT_DELETED");
        return u;
    }

    static Map<String, Object> summary(User u) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", u.getId());
        m.put("stageName", u.getStageName());
        m.put("username", u.getUsername());
        m.put("phone", u.getPhone());
        m.put("email", u.getEmail());
        m.put("role", u.getRole() == null ? null : u.getRole().name());
        m.put("verificationBadge", u.getVerificationBadge() == null ? null : u.getVerificationBadge().name());
        m.put("phoneVerified", u.isPhoneVerified());
        m.put("status", statusOf(u));
        m.put("suspendReason", u.getSuspendReason());
        m.put("suspendedAt", u.getSuspendedAt() == null ? null : u.getSuspendedAt().toString());
        m.put("createdAt", u.getCreatedAt() == null ? null : u.getCreatedAt().toString());
        return m;
    }

    static String statusOf(User u) {
        if (u.getDeletedAt() != null) return "DELETED";
        return u.getSuspendedAt() != null ? "SUSPENDED" : "ACTIVE";
    }

    private static String normaliseStatus(String status) {
        String s = status == null ? "" : status.trim().toUpperCase(Locale.ROOT);
        return switch (s) {
            case "ACTIVE", "SUSPENDED", "DELETED" -> s;
            case "", "ALL" -> "ALL";
            default -> throw ApiException.badRequest("INVALID_STATUS");
        };
    }

    private static Role parseRole(String role) {
        if (role == null || role.isBlank()) return null;
        String r = role.trim().toUpperCase(Locale.ROOT);
        if (!r.startsWith("ROLE_")) r = "ROLE_" + r;
        try {
            return Role.valueOf(r);
        } catch (IllegalArgumentException e) {
            throw ApiException.badRequest("INVALID_ROLE");
        }
    }

    private static String escapeLike(String s) {
        return s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_");
    }
}
