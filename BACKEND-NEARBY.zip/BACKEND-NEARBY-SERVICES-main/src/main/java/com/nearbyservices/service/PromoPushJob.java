package com.nearbyservices.service;

import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Every 10 minutes: promote boosted services by push (one service per user per interval, see PromoPushService).
 * Written for ONE running server, like OfferReminderJob. With several, run this job on one of them only,
 * or a user could be sent two promos in the same minute.
 */
@Component
@RequiredArgsConstructor
public class PromoPushJob {

    private static final Logger log = LoggerFactory.getLogger(PromoPushJob.class);

    private final PromoPushService promoPush;
    private final SearchHistoryService searchHistory;
    private final JobLock jobLock;

    @Scheduled(fixedDelay = 10 * 60 * 1000L, initialDelay = 2 * 60 * 1000L)
    public void run() {
        jobLock.run("promo-push", this::runLocked);
    }

    private void runLocked() {
        try {
            promoPush.runOnce();
        } catch (Exception e) {
            log.warn("Promo push run failed: {}", e.getMessage());
        }
    }

    /** Daily, 03:30 server time. */
    @Scheduled(cron = "0 30 3 * * *")
    public void purge() {
        jobLock.run("promo-purge", this::purgeLocked);
    }

    private void purgeLocked() {
        try {
            int n = promoPush.purgeOldLogs();
            if (n > 0) log.info("Removed {} old promo push log rows", n);
            searchHistory.purgeOld();
        } catch (Exception e) {
            log.warn("Promo push log cleanup failed: {}", e.getMessage());
        }
    }
}
