package com.nearbyservices.service;

import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Every 5 minutes: a booking the provider asked to be paid (AWAITING_PAYMENT) whose deadline has passed is ended.
 * Each booking is handled in its own transaction, so one failure never blocks the others.
 * Written for ONE running server; with several, the booking lock makes a second run a harmless no-op.
 */
@Component
@RequiredArgsConstructor
public class PaymentDeadlineJob {

    private static final Logger log = LoggerFactory.getLogger(PaymentDeadlineJob.class);

    private final EscrowService escrowService;
    private final JobLock jobLock;

    @Scheduled(fixedDelay = 5 * 60 * 1000L, initialDelay = 90 * 1000L)
    public void run() {
        jobLock.run("payment-deadline", this::runLocked);
    }

    private void runLocked() {
        int ended = 0;
        try {
            for (String ref : escrowService.refsPastPaymentDeadline()) {
                try {
                    if (escrowService.expireAwaitingPayment(ref)) ended++;
                } catch (Exception e) {
                    log.warn("Could not end booking {} after its payment deadline: {}", ref, e.getMessage());
                }
            }
            if (ended > 0) log.info("Ended {} bookings whose payment deadline passed", ended);
        } catch (Exception e) {
            log.warn("Payment deadline run failed: {}", e.getMessage());
        }
    }
}
