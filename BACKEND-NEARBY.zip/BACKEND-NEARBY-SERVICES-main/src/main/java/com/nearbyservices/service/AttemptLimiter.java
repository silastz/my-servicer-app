package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import org.springframework.stereotype.Component;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Small in-memory sliding window: at most N attempts per key per window. Resets when the server restarts. */
@Component
public class AttemptLimiter {

    private final Map<String, Deque<Long>> hits = new ConcurrentHashMap<>();

    /** Counts one attempt; throws 429 TOO_MANY_ATTEMPTS when the key already used up its attempts in the window. */
    public void hit(String key, int max, long windowMillis) {
        long now = System.currentTimeMillis();
        Deque<Long> d = hits.computeIfAbsent(key, k -> new ArrayDeque<>());
        synchronized (d) {
            while (!d.isEmpty() && now - d.peekFirst() > windowMillis) d.pollFirst();
            if (d.size() >= max) throw ApiException.tooManyRequests("TOO_MANY_ATTEMPTS");
            d.addLast(now);
        }
        if (hits.size() > 20000) hits.entrySet().removeIf(e -> { synchronized (e.getValue()) { return e.getValue().isEmpty() || now - e.getValue().peekLast() > windowMillis; } });
    }

    /** Throws 429 TOO_MANY_ATTEMPTS when the key already has max failures in the window. Counts nothing. */
    public void check(String key, int max, long windowMillis) {
        Deque<Long> d = hits.get(key);
        if (d == null) return;
        long now = System.currentTimeMillis();
        synchronized (d) {
            while (!d.isEmpty() && now - d.peekFirst() > windowMillis) d.pollFirst();
            if (d.size() >= max) throw ApiException.tooManyRequests("TOO_MANY_ATTEMPTS");
        }
    }

    /** Counts one failure for the key and returns how many failures it now has in the window. */
    public int record(String key, long windowMillis) {
        long now = System.currentTimeMillis();
        Deque<Long> d = hits.computeIfAbsent(key, k -> new ArrayDeque<>());
        int size;
        synchronized (d) {
            while (!d.isEmpty() && now - d.peekFirst() > windowMillis) d.pollFirst();
            d.addLast(now);
            size = d.size();
        }
        if (hits.size() > 20000) hits.entrySet().removeIf(e -> { synchronized (e.getValue()) { return e.getValue().isEmpty() || now - e.getValue().peekLast() > windowMillis; } });
        return size;
    }

    /** Forgets the key (used after a correct code). */
    public void reset(String key) {
        hits.remove(key);
    }
}
