package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.AppConfigEntry;
import com.nearbyservices.payment.MiniJson;
import com.nearbyservices.repository.AppConfigRepository;
import com.nearbyservices.verification.AuditLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * The two public documents the app asks for as it opens (docs/ads_config_api_contract.md and
 * docs/app_version_api_contract.md): the ad settings and the "update available" info.
 * The admin writes them; everyone reads them. Documents are stored exactly as validated, so keys the
 * server does not know (title_TZ, cta_KE ...) are never dropped.
 */
@Service
public class AppConfigService {

    private static final Logger log = LoggerFactory.getLogger(AppConfigService.class);

    static final String ADS_KEY = "ads";
    private static final Set<String> PLATFORMS = Set.of("android", "ios", "web");
    private static final Set<String> PROVIDERS = Set.of("ADMOB", "FACEBOOK", "IRONSOURCE", "INHOUSE", "ALL");
    private static final Set<String> PAGES = Set.of("home", "serviceDetails", "search", "providerProfile", "chats", "videoReward");
    private static final Pattern ADMOB = Pattern.compile("^ca-app-pub-\\d{16}/\\d{10}$");
    private static final Pattern FACEBOOK = Pattern.compile("^(?:[A-Za-z0-9_]{3,40}#)?\\d{8,20}_\\d{8,20}$");
    private static final Pattern IRON_ID = Pattern.compile("^[A-Za-z0-9]{5,40}$");
    private static final Pattern IRON_PLACEMENT = Pattern.compile("^[A-Za-z0-9 _\\-]{1,40}$");
    private static final Pattern VERSION = Pattern.compile("^\\d+(\\.\\d+){0,3}$");

    private final AppConfigRepository repository;
    private final AuditLog audit;

    public AppConfigService(AppConfigRepository repository, AuditLog audit) {
        this.repository = repository;
        this.audit = audit;
    }

    // ------------------------------------------------------------------ ads

    /** The saved ad settings as JSON text, or "{}" when nothing was saved (the app then uses its defaults). */
    @Transactional(readOnly = true)
    public String adsJson() {
        return repository.findById(ADS_KEY).map(AppConfigEntry::getValue).orElse("{}");
    }

    @Transactional
    public String saveAds(String body, long adminId) {
        Map<String, Object> root = parseObject(body, "INVALID_ADS_JSON");
        // "{ data: {...} }" is accepted too; what is stored is the inner document.
        String stored = body;
        if (root.get("data") instanceof Map && root.size() == 1) {
            root = asMap(root.get("data"));
            stored = toJson(root);
        }
        validateAds(root);
        Map<String, Object> before = previousAds();
        repository.save(new AppConfigEntry(ADS_KEY, stored.trim(), String.valueOf(adminId)));
        // Who changed what: field names only, never values. Going from test to live is recorded on its own.
        audit.record(adminId, "ads.config.save", ConfigDiff.detail(ConfigDiff.changedPaths(before, root)));
        if (isTestMode(before) && !isTestMode(root)) audit.record(adminId, "ads.go_live", "testMode off");
        else if (!isTestMode(before) && isTestMode(root)) audit.record(adminId, "ads.test_mode_on", "testMode on");
        log.info("Ads settings saved by admin {} (testMode={})", adminId, root.get("testMode"));
        return stored.trim();
    }

    /** The ad settings before this save (empty when none, or when the old text cannot be read). */
    private Map<String, Object> previousAds() {
        try {
            return parseObject(adsJson(), "INVALID_ADS_JSON");
        } catch (RuntimeException e) {
            return Map.of();
        }
    }

    /** testMode missing or not false means test mode (the contract's safe default). */
    private static boolean isTestMode(Map<String, Object> d) {
        return !Boolean.FALSE.equals(d.get("testMode"));
    }

    private void validateAds(Map<String, Object> d) {
        checkProvider(d.get("defaultProvider"), false, "defaultProvider");
        Object pages = d.get("pages");
        if (pages != null) {
            Map<String, Object> pm = requireMap(pages, "pages");
            for (Map.Entry<String, Object> e : pm.entrySet()) {
                if (!PAGES.contains(e.getKey())) throw bad("UNKNOWN_AD_PAGE:" + e.getKey());
                if (e.getValue() != null) checkProvider(requireMap(e.getValue(), "pages." + e.getKey()).get("provider"), true, "pages." + e.getKey() + ".provider");
            }
        }
        Object units = d.get("units");
        if (units != null) {
            for (Map.Entry<String, Object> net : requireMap(units, "units").entrySet()) {
                String network = net.getKey().toLowerCase(Locale.ROOT);
                if (!Set.of("admob", "facebook", "ironsource").contains(network)) throw bad("UNKNOWN_AD_NETWORK:" + net.getKey());
                for (Map.Entry<String, Object> plat : requireMap(net.getValue(), "units." + net.getKey()).entrySet()) {
                    if (!PLATFORMS.contains(plat.getKey())) throw bad("UNKNOWN_AD_PLATFORM:" + plat.getKey());
                    for (Map.Entry<String, Object> f : requireMap(plat.getValue(), "units." + net.getKey() + "." + plat.getKey()).entrySet()) {
                        checkUnit(network, f.getKey(), f.getValue());
                    }
                }
            }
        }
        String houseError = HouseAdsValidator.validate(d.get("house"), PAGES);
        if (houseError != null) throw bad(houseError);
    }

    private void checkProvider(Object v, boolean allowDefault, String field) {
        if (v == null) return;
        String s = String.valueOf(v).trim().toUpperCase(Locale.ROOT);
        if (s.isEmpty() || (allowDefault && s.equals("DEFAULT"))) return;
        if (!PROVIDERS.contains(s)) throw bad("INVALID_PROVIDER:" + field);
    }

    private void checkUnit(String network, String field, Object raw) {
        if (raw == null) return;
        String v = String.valueOf(raw).trim();
        if (v.isEmpty()) return; // blank is always allowed
        if (v.length() > 64) throw bad("AD_ID_TOO_LONG:" + field);
        boolean ok;
        switch (network) {
            case "admob" -> ok = ADMOB.matcher(v).matches();
            case "facebook" -> ok = FACEBOOK.matcher(v).matches();
            default -> ok = field.equals("native") ? IRON_PLACEMENT.matcher(v).matches() : IRON_ID.matcher(v).matches();
        }
        if (!ok) throw bad("INVALID_AD_ID:" + network + "." + field);
    }

    // -------------------------------------------------------------- version

    /** The update info for a platform. Nothing saved yet: version 1.0.0, which never nags anyone. */
    @Transactional(readOnly = true)
    public String versionJson(String platform) {
        String p = normalizePlatform(platform);
        return repository.findById("version." + p)
                .map(AppConfigEntry::getValue)
                .orElse("{\"latestVersion\":\"1.0.0\",\"forceUpdate\":false}");
    }

    @Transactional
    public String saveVersion(String platform, String body, long adminId) {
        String p = normalizePlatform(platform);
        Map<String, Object> d = parseObject(body, "INVALID_VERSION_JSON");
        Object latest = d.get("latestVersion");
        if (latest == null || !VERSION.matcher(String.valueOf(latest).trim()).matches()) throw bad("INVALID_LATEST_VERSION");
        Object min = d.get("minVersion");
        if (min != null && !String.valueOf(min).isBlank() && !VERSION.matcher(String.valueOf(min).trim()).matches()) throw bad("INVALID_MIN_VERSION");
        Object store = d.get("storeUrl");
        if (store != null && !String.valueOf(store).isBlank() && !String.valueOf(store).startsWith("https://")) throw bad("INVALID_STORE_URL");
        repository.save(new AppConfigEntry("version." + p, body.trim(), String.valueOf(adminId)));
        audit.record(adminId, "app.version.save", p + ": latest " + String.valueOf(latest).trim());
        log.info("App version info for {} saved by admin {}", p, adminId);
        return body.trim();
    }

    private static String normalizePlatform(String platform) {
        String p = platform == null ? "android" : platform.trim().toLowerCase(Locale.ROOT);
        if (!PLATFORMS.contains(p)) throw bad("INVALID_PLATFORM");
        return p;
    }

    // -------------------------------------------------------------- helpers

    private static ApiException bad(String code) {
        return ApiException.badRequest(code);
    }

    private static Map<String, Object> parseObject(String body, String code) {
        if (body == null || body.isBlank()) throw bad(code);
        try {
            Object o = MiniJson.parse(body);
            if (!(o instanceof Map)) throw bad(code);
            return asMap(o);
        } catch (IllegalArgumentException e) {
            throw bad(code);
        }
    }

    private static Map<String, Object> requireMap(Object o, String field) {
        if (!(o instanceof Map)) throw bad("INVALID_FIELD:" + field);
        return asMap(o);
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> asMap(Object o) {
        return (Map<String, Object>) o;
    }

    /** Writes a parsed document back out (only used to unwrap a {"data": {...}} body). */
    private static String toJson(Object o) {
        StringBuilder sb = new StringBuilder();
        write(sb, o);
        return sb.toString();
    }

    private static void write(StringBuilder sb, Object o) {
        if (o == null) {
            sb.append("null");
        } else if (o instanceof Map<?, ?> m) {
            sb.append('{');
            boolean first = true;
            for (Map.Entry<?, ?> e : m.entrySet()) {
                if (!first) sb.append(',');
                first = false;
                sb.append(quote(String.valueOf(e.getKey()))).append(':');
                write(sb, e.getValue());
            }
            sb.append('}');
        } else if (o instanceof List<?> l) {
            sb.append('[');
            for (int i = 0; i < l.size(); i++) {
                if (i > 0) sb.append(',');
                write(sb, l.get(i));
            }
            sb.append(']');
        } else if (o instanceof Number || o instanceof Boolean) {
            sb.append(o);
        } else {
            sb.append(quote(String.valueOf(o)));
        }
    }

    private static String quote(String v) {
        StringBuilder sb = new StringBuilder("\"");
        for (char c : v.toCharArray()) {
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
                }
            }
        }
        return sb.append('"').toString();
    }
}
