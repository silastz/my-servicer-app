package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.EscrowStatus;
import com.nearbyservices.model.PaymentStatus;
import com.nearbyservices.model.Role;
import com.nearbyservices.model.ServicePost;
import com.nearbyservices.model.User;
import com.nearbyservices.model.VerificationBadge;
import com.nearbyservices.model.Wallet;
import com.nearbyservices.repository.EscrowTransactionRepository;
import com.nearbyservices.repository.LiveLocationRepository;
import com.nearbyservices.repository.PaymentRepository;
import com.nearbyservices.repository.ServicePostRepository;
import com.nearbyservices.repository.UserRepository;
import com.nearbyservices.repository.UserSearchTermRepository;
import com.nearbyservices.repository.UserVerificationProfileRepository;
import com.nearbyservices.repository.VerificationDocumentRepository;
import com.nearbyservices.repository.WalletRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

/**
 * In-app account deletion (required by Google Play and the App Store).
 *
 * The account is ANONYMISED, not dropped: payments, bookings, wallet entries and reviews of other people point at the
 * user row, and the law asks us to keep money records. Everything that identifies the person is erased or replaced:
 * name, phone, email, password, photos, bio, social links, ID papers and NIDA data, GPS position, search history.
 * The login can never be used again and the old phone number / email become free to register again.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AccountDeletionService {

    private static final List<EscrowStatus> OPEN_BOOKING = List.of(
            EscrowStatus.PENDING_ACCEPTANCE, EscrowStatus.ACCEPTED, EscrowStatus.FUNDED, EscrowStatus.DISPUTED,
            EscrowStatus.AWAITING_PAYMENT, EscrowStatus.PAYMENT_SENT, EscrowStatus.PAYMENT_DISPUTED);

    private static final long WINDOW_MS = 15 * 60_000L;

    private final UserRepository userRepository;
    private final WalletRepository walletRepository;
    private final EscrowTransactionRepository escrowRepository;
    private final PaymentRepository paymentRepository;
    private final ServicePostRepository servicePostRepository;
    private final VerificationDocumentRepository verificationDocumentRepository;
    private final UserVerificationProfileRepository verificationProfileRepository;
    private final UserSearchTermRepository searchTermRepository;
    private final LiveLocationRepository liveLocationRepository;

    /** Optional so existing unit tests that build this class by hand keep working. */
    @org.springframework.beans.factory.annotation.Autowired(required = false)
    private PortfolioService portfolioService;
    private final FileStorageService fileStorageService;
    private final PasswordEncoder passwordEncoder;
    private final AttemptLimiter limiter;

    /** What stops a deletion right now, or null when the account can be deleted. Lets the app explain before asking for the password. */
    @Transactional(readOnly = true)
    public String blocker(User caller) {
        User u = userRepository.findById(caller.getId()).orElseThrow(() -> ApiException.notFound("USER_NOT_FOUND"));
        return blockerOf(u);
    }

    private String blockerOf(User u) {
        if (u.getRole() == Role.ROLE_ADMIN) return "ADMIN_ACCOUNT";
        Wallet w = walletRepository.findByUserId(u.getId()).orElse(null);
        if (w != null && (w.getBalance().signum() > 0 || w.getLockedEscrowBalance().signum() > 0)) return "WALLET_NOT_EMPTY";
        if (escrowRepository.existsByBuyerIdAndStatusIn(u.getId(), OPEN_BOOKING)
                || escrowRepository.existsBySellerIdAndStatusIn(u.getId(), OPEN_BOOKING)) return "OPEN_BOOKINGS";
        if (paymentRepository.existsByUserIdAndStatus(u.getId(), PaymentStatus.PENDING)) return "PAYMENT_PENDING";
        return null;
    }

    /** Deletes (anonymises) the caller's account after checking the password. Throws ApiException with a stable code on refusal. */
    @Transactional
    public void delete(User caller, String password) {
        String key = "acct-delete:" + caller.getId();
        limiter.check(key, 5, WINDOW_MS);

        User u = userRepository.findByIdForUpdate(caller.getId()).orElseThrow(() -> ApiException.notFound("USER_NOT_FOUND"));
        if (u.getDeletedAt() != null) return; // already deleted: nothing more to do

        if (password == null || password.isEmpty() || !passwordEncoder.matches(password, u.getPassword())) {
            limiter.record(key, WINDOW_MS);
            throw ApiException.forbidden("WRONG_PASSWORD");
        }
        limiter.reset(key);

        String blocked = blockerOf(u);
        if (blocked != null) throw ApiException.conflict(blocked);

        anonymise(u);
        log.info("Account {} deleted by its owner", u.getId());
    }

    /**
     * An admin deletes (anonymises) someone else's account. Same rules as the owner's own deletion (no admin accounts,
     * nothing in the wallet, no open booking or payment), but no password: the admin acts on the person's behalf.
     * Throws ApiException with a stable code on refusal. Deleting an already deleted account does nothing.
     */
    @Transactional
    public void deleteByAdmin(long adminId, long targetId) {
        User u = userRepository.findByIdForUpdate(targetId).orElseThrow(() -> ApiException.notFound("USER_NOT_FOUND"));
        if (u.getDeletedAt() != null) return;

        String blocked = blockerOf(u);
        if (blocked != null) throw ApiException.conflict(blocked);

        anonymise(u);
        log.info("Account {} deleted by admin {}", targetId, adminId);
    }

    /** Erases everything that identifies the person and closes the login for good. The caller has already checked every rule. */
    private void anonymise(User u) {
        long id = u.getId();

        // 1. Services: switch off and wipe the contact details (their money history stays on the booking rows).
        for (ServicePost s : servicePostRepository.findBySellerId(id)) {
            s.setActive(false);
            s.setBoostedUntil(null);
            s.setPhone(null);
            s.setWhatsappPhone(null);
            s.setEmail(null);
            s.setInstagramUsername(null);
            s.setFacebookUsername(null);
            s.setTiktokUsername(null);
            s.setXUsername(null);
            s.setYoutubeUsername(null);
            servicePostRepository.save(s);
        }

        // 2. Files: profile pictures and the private ID papers.
        fileStorageService.deleteProfileImage(u.getAvatarUrl());
        fileStorageService.deleteProfileImage(u.getCoverUrl());
        verificationDocumentRepository.findByUserId(id).forEach(d -> fileStorageService.deletePrivateFile(d.getFileKey()));
        verificationDocumentRepository.deleteAll(verificationDocumentRepository.findByUserId(id));
        verificationProfileRepository.findById(id).ifPresent(p -> {
            fileStorageService.deleteProfileImage(p.getPhotoUrl());
            verificationProfileRepository.delete(p);
        });
        fileStorageService.deletePrivateFile(u.getNidaIdPhotoUrl());
        fileStorageService.deletePrivateFile(u.getNidaSelfiePhotoUrl());

        // 3. Behaviour data.
        searchTermRepository.deleteByUserId(id);
        liveLocationRepository.deleteByUserId(id);
        if (portfolioService != null) portfolioService.deleteAllFor(id);

        // 4. The user row itself: nothing that identifies the person is kept.
        u.setUsername("deleted-" + id);
        u.setPhone("deleted-" + id);
        u.setEmail(null);
        u.setEmailVerified(false);
        u.setPhoneVerified(false);
        u.setEmailOtp(null);
        u.setEmailOtpExpiry(null);
        u.setPhoneOtp(null);
        u.setPhoneOtpExpiry(null);
        u.setPassword(passwordEncoder.encode(UUID.randomUUID() + UUID.randomUUID().toString())); // nobody knows it
        u.setStageName("Deleted user");
        u.setBio(null);
        u.setAvatarUrl(null);
        u.setCoverUrl(null);
        u.setFcmToken(null);
        u.setVerificationBadge(VerificationBadge.NONE);
        u.setNidaNumber(null);
        u.setNidaOfficialFirstName(null);
        u.setNidaOfficialLastName(null);
        u.setNidaIdPhotoUrl(null);
        u.setNidaSelfiePhotoUrl(null);
        u.setSocialWhatsapp(null);
        u.setSocialInstagram(null);
        u.setSocialFacebook(null);
        u.setSocialX(null);
        u.setSocialTiktok(null);
        u.setSocialYoutube(null);
        u.setNotifBookings(false);
        u.setNotifMessages(false);
        u.setNotifPromos(false);
        u.setLastLatitude(null);
        u.setLastLongitude(null);
        u.setLocationUpdatedAt(null);
        u.setProfileLocked(true);
        u.setHideMyId(true);
        u.setTokensValidFrom(Instant.now()); // every login issued so far stops working
        u.setSuspendedAt(null);
        u.setSuspendReason(null);
        u.setDeletedAt(Instant.now());
        userRepository.save(u);
    }
}
