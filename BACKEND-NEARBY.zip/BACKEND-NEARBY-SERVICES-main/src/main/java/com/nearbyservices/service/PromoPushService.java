package com.nearbyservices.service;

import com.nearbyservices.model.PromoPushLog;
import com.nearbyservices.model.ServicePost;
import com.nearbyservices.model.User;
import com.nearbyservices.repository.PromoPushLogRepository;
import com.nearbyservices.repository.ServicePostRepository;
import com.nearbyservices.repository.UserBlockRepository;
import com.nearbyservices.repository.UserRepository;
import com.nearbyservices.service.PushService.Text;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.RoundingMode;
import java.time.Instant;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * Auto-promotion of boosted services by push (see PROMO_PUSH.md).
 *
 * Each run walks through the users who switched promo notifications on and have not had a promo push for the
 * admin's interval. Each of them gets exactly ONE boosted service, chosen by {@link PromoPicker}, so different
 * users get different services. Only between startHour and endHour on the user's own clock.
 * A run sends at most maxPerRun pushes; the users left over are simply picked up by the next run.
 */
@Service
@RequiredArgsConstructor
public class PromoPushService {

    private static final Logger log = LoggerFactory.getLogger(PromoPushService.class);
    private static final int PAGE = 200;
    private static final ZoneId EAT = ZoneId.of("Africa/Nairobi");   // Tanzania, Kenya, Uganda (UTC+3)
    private static final ZoneId CAT = ZoneId.of("Africa/Kigali");    // Rwanda, Burundi, DR Congo (UTC+2)

    @Value("${promo-push.start-hour:8}")
    private int startHour;
    @Value("${promo-push.end-hour:20}")
    private int endHour;
    @Value("${promo-push.max-per-run:500}")
    private int maxPerRun;

    private final PushService push;
    private final PromoPushSettingsService settings;
    private final UserRepository userRepository;
    private final ServicePostRepository servicePostRepository;
    private final PromoPushLogRepository logRepository;
    private final UserBlockRepository blockRepository;
    private final SearchHistoryService searchHistory;

    private final Random random = new Random();

    /** @return how many pushes were sent in this run */
    @Transactional
    public int runOnce() {
        if (!push.enabled() || !settings.enabled()) return 0;
        Instant now = Instant.now();
        if (!inWindowSomewhere(now)) return 0;

        List<ServicePost> boosted = servicePostRepository.findByActiveTrueAndBoostedUntilAfter(now).stream()
                .filter(s -> !s.is18Plus()) // 18+ services are never promoted by push
                .collect(java.util.stream.Collectors.toList());
        if (boosted.isEmpty()) return 0;

        Map<Long, ServicePost> byId = new HashMap<>();
        List<PromoPicker.Candidate> candidates = new ArrayList<>();
        for (ServicePost s : boosted) {
            byId.put(s.getId(), s);
            candidates.add(new PromoPicker.Candidate(s.getId(), s.getSeller().getId()));
        }
        Map<Long, Integer> recent = new HashMap<>();
        for (Object[] row : logRepository.countsSince(now.minus(24, ChronoUnit.HOURS))) {
            recent.put(((Number) row[0]).longValue(), ((Number) row[1]).intValue());
        }

        Instant cutoff = now.minus(settings.intervalHours(), ChronoUnit.HOURS);
        long afterId = 0;
        int sent = 0;
        while (sent < maxPerRun) {
            List<User> page = userRepository.findPromoDue(cutoff, afterId, PageRequest.of(0, PAGE));
            if (page.isEmpty()) break;
            for (User u : page) {
                afterId = u.getId();
                if (sent >= maxPerRun) break;
                if (!PromoPicker.inWindow(now.atZone(zoneOf(u)), startHour, endHour)) continue;

                Long serviceId = PromoPicker.pick(candidates, u.getId(), blockedWith(u.getId()),
                        searchedBy(u.getId(), boosted), historyOf(u.getId()), recent, random);
                if (serviceId == null) continue;

                ServicePost s = byId.get(serviceId);
                // Logged first, in the same transaction: the push itself only leaves after the commit.
                logRepository.save(PromoPushLog.builder().userId(u.getId()).serviceId(serviceId).sentAt(now).build());
                push.toUser(u.getId(), titleOf(s), bodyOf(s),
                        Map.of("type", "promo_service", "id", String.valueOf(serviceId)));
                recent.merge(serviceId, 1, Integer::sum);
                sent++;
            }
        }
        if (sent > 0) log.info("Sent {} promo pushes for {} boosted services", sent, candidates.size());
        return sent;
    }

    /** Logs older than 60 days are only history; dropping them restarts the rotation, which is harmless. */
    @Transactional
    public int purgeOldLogs() {
        return logRepository.purgeBefore(Instant.now().minus(60, ChronoUnit.DAYS));
    }

    // ---- helpers ------------------------------------------------------------------------------------

    private boolean inWindowSomewhere(Instant now) {
        return PromoPicker.inWindow(now.atZone(EAT), startHour, endHour)
                || PromoPicker.inWindow(now.atZone(CAT), startHour, endHour);
    }

    static ZoneId zoneOf(User u) {
        String c = u.getCountry() == null ? "TZ" : u.getCountry().toUpperCase(Locale.ROOT);
        return switch (c) {
            case "RW", "BI", "CD" -> CAT;
            default -> EAT;
        };
    }

    /** Boosted services that match something the user searched for. */
    private Set<Long> searchedBy(Long userId, List<ServicePost> boosted) {
        Set<Long> ids = new HashSet<>();
        for (String term : searchHistory.recentTerms(userId)) {
            for (ServicePost s : boosted) {
                if (matches(term, s)) ids.add(s.getId());
            }
        }
        return ids;
    }

    static boolean matches(String term, ServicePost s) {
        String hay = String.join(" ", nz(s.getTitle()), nz(s.getShortDescription()), nz(s.getOtherLanguage()),
                nz(s.getCategory()), nz(s.getDescription())).toLowerCase(Locale.ROOT);
        return hay.contains(term);
    }

    private static String nz(String v) {
        return v == null ? "" : v;
    }

    private Set<Long> blockedWith(Long userId) {
        Set<Long> ids = new HashSet<>(blockRepository.blockedIdsOf(userId));
        ids.addAll(blockRepository.blockerIdsOf(userId));
        return ids;
    }

    private Map<Long, PromoPicker.History> historyOf(Long userId) {
        Map<Long, PromoPicker.History> h = new HashMap<>();
        for (Object[] row : logRepository.historyOf(userId)) {
            h.put(((Number) row[0]).longValue(),
                    new PromoPicker.History(((Number) row[1]).intValue(), (Instant) row[2]));
        }
        return h;
    }

    static Text titleOf(ServicePost s) {
        String t = s.getTitle() == null ? "" : s.getTitle().trim();
        if (t.length() > 60) t = t.substring(0, 57).trim() + "...";
        return new Text(t, t);
    }

    static Text bodyOf(ServicePost s) {
        String category = s.getCategory() == null ? "" : s.getCategory().trim();
        String type = s.getPriceType() == null ? "" : s.getPriceType();
        String amount = money(s);
        String en = amount + switch (type) {
            case "PER_HOUR" -> " per hour";
            default -> "";
        };
        String sw = amount + switch (type) {
            case "PER_HOUR" -> " kwa saa";
            default -> "";
        };
        if (type.equals("STARTING_FROM")) {
            en = "from " + en;
            sw = "kuanzia " + sw;
        }
        return new Text("Featured in " + category + ": " + en + ". Tap to take a look.",
                "Inapendekezwa katika " + category + ": " + sw + ". Gusa kuangalia.");
    }

    private static String money(ServicePost s) {
        String code = s.getSeller() == null ? "TZS" : UserSettingsService.currencyOf(s.getSeller());
        String unit = code.equals("TZS") ? "TSh" : code;
        long v = s.getPrice().setScale(0, RoundingMode.HALF_UP).longValue();
        return unit + " " + String.format(Locale.US, "%,d", v);
    }
}
