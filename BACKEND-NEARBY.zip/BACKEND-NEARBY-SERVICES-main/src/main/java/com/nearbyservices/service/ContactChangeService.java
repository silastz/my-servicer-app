package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.ContactChangeRequest;
import com.nearbyservices.model.User;
import com.nearbyservices.repository.ContactChangeRequestRepository;
import com.nearbyservices.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Changing the registered phone or email. The new value must prove it belongs to the user: a 6-digit
 * code is sent to the NEW phone / email and the switch happens only when that code comes back.
 */
@Service
@RequiredArgsConstructor
public class ContactChangeService {

    public enum Kind { PHONE, EMAIL }

    private static final Pattern PHONE = Pattern.compile("^\\+[0-9]{10,14}$");
    private static final Pattern EMAIL = Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$");
    private static final int MAX_ATTEMPTS = 5;
    private static final int MINUTES_VALID = 10;
    private static final int SECONDS_BETWEEN_REQUESTS = 60;
    private static final SecureRandom RANDOM = new SecureRandom();

    private final ContactChangeRequestRepository requestRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final SmsService smsService;
    private final EmailService emailService;

    @Transactional
    public void request(User me, Kind kind, String rawValue) {
        String value = clean(kind, rawValue);
        User user = lockedUser(me);
        if (value.equals(current(user, kind))) throw ApiException.badRequest("SAME_AS_CURRENT");
        if (isTaken(kind, value, user.getId())) {
            throw ApiException.conflict(kind == Kind.PHONE ? "PHONE_ALREADY_USED" : "EMAIL_ALREADY_USED");
        }

        ContactChangeRequest existing = requestRepository.findByUserIdAndKind(user.getId(), kind.name()).orElse(null);
        if (existing != null && existing.getCreatedAt().plusSeconds(SECONDS_BETWEEN_REQUESTS).isAfter(LocalDateTime.now())) {
            throw ApiException.tooManyRequests("WAIT_BEFORE_NEW_CODE");
        }

        String otp = String.format("%06d", RANDOM.nextInt(1_000_000));
        ContactChangeRequest req = existing != null ? existing : ContactChangeRequest.builder()
                .userId(user.getId()).kind(kind.name()).build();
        req.setNewValue(value);
        req.setOtpHash(passwordEncoder.encode(otp));
        req.setCreatedAt(LocalDateTime.now());
        req.setExpiresAt(LocalDateTime.now().plusMinutes(MINUTES_VALID));
        req.setAttempts(0);
        try {
            requestRepository.saveAndFlush(req);
        } catch (DataIntegrityViolationException raced) {
            throw ApiException.tooManyRequests("WAIT_BEFORE_NEW_CODE");
        }

        if (kind == Kind.PHONE) smsService.sendOtpSms(value, user.getStageName(), otp);
        else emailService.sendOtpEmail(value, user.getStageName(), otp);
    }

    /** Returns the new value once it is the registered one. */
    @Transactional(noRollbackFor = ApiException.class)
    public String confirm(User me, Kind kind, String rawValue, String otp) {
        String value = clean(kind, rawValue);
        User user = lockedUser(me);
        ContactChangeRequest req = requestRepository.findByUserIdAndKind(user.getId(), kind.name())
                .filter(r -> r.getNewValue().equals(value))
                .orElseThrow(() -> ApiException.badRequest("NO_PENDING_CHANGE"));

        if (req.getExpiresAt().isBefore(LocalDateTime.now())) {
            requestRepository.delete(req);
            throw ApiException.badRequest("CODE_EXPIRED");
        }
        if (req.getAttempts() >= MAX_ATTEMPTS) {
            requestRepository.delete(req);
            throw ApiException.tooManyRequests("TOO_MANY_ATTEMPTS");
        }
        String code = otp == null ? "" : otp.trim();
        if (!code.matches("^[0-9]{6}$") || !passwordEncoder.matches(code, req.getOtpHash())) {
            req.setAttempts(req.getAttempts() + 1); // kept: noRollbackFor
            requestRepository.save(req);
            throw ApiException.badRequest("INVALID_CODE");
        }
        // Someone may have registered this value while the code was in the mail.
        if (isTaken(kind, value, user.getId())) {
            requestRepository.delete(req);
            throw ApiException.conflict(kind == Kind.PHONE ? "PHONE_ALREADY_USED" : "EMAIL_ALREADY_USED");
        }

        if (kind == Kind.PHONE) {
            user.setPhone(value);
            user.setPhoneVerified(true);
        } else {
            user.setEmail(value);
            user.setEmailVerified(true);
        }
        userRepository.save(user);
        requestRepository.delete(req);
        return value;
    }

    // ------------------------------------------------------------------ helpers

    private String clean(Kind kind, String raw) {
        if (raw == null || raw.isBlank()) throw ApiException.badRequest(kind == Kind.PHONE ? "INVALID_PHONE_NUMBER" : "INVALID_EMAIL");
        if (kind == Kind.PHONE) {
            String p = SmsService.normalizePhoneNumber(raw.trim());
            if (p == null || !PHONE.matcher(p).matches()) throw ApiException.badRequest("INVALID_PHONE_NUMBER");
            return p;
        }
        String e = raw.trim().toLowerCase(Locale.ROOT); // login looks emails up in lower case
        if (e.length() > 254 || !EMAIL.matcher(e).matches()) throw ApiException.badRequest("INVALID_EMAIL");
        return e;
    }

    private boolean isTaken(Kind kind, String value, Long myId) {
        var other = kind == Kind.PHONE ? userRepository.findByPhone(value) : userRepository.findByEmail(value);
        return other.isPresent() && !other.get().getId().equals(myId);
    }

    private static String current(User u, Kind kind) {
        return kind == Kind.PHONE ? u.getPhone() : (u.getEmail() == null ? null : u.getEmail().toLowerCase(Locale.ROOT));
    }

    /** Row lock so two parallel confirms cannot both run. */
    private User lockedUser(User me) {
        return userRepository.findByIdForUpdate(me.getId()).orElseThrow(() -> ApiException.notFound("USER_NOT_FOUND"));
    }
}
