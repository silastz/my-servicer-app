package com.nearbyservices.service;

import com.nearbyservices.dto.ServiceFeeStatusResponse;
import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.AdminSettings;
import com.nearbyservices.model.Role;
import com.nearbyservices.model.ServiceFeeCredit;
import com.nearbyservices.model.User;
import com.nearbyservices.repository.ServiceFeeCreditRepository;
import com.nearbyservices.repository.ServicePostRepository;
import com.nearbyservices.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Per-service fee. The registration fee covers the first {@code freeServicesQuota} services; every
 * service after that needs one paid fee (a credit). The limit, the credit and the amount all live
 * on the server; the app only asks.
 */
@Service
@RequiredArgsConstructor
public class ServiceFeeService {

    private final AdminSettingsService adminSettingsService;
    private final UserRepository userRepository;
    private final ServicePostRepository servicePostRepository;
    private final ServiceFeeCreditRepository creditRepository;

    @Transactional(readOnly = true)
    public ServiceFeeStatusResponse status(User user) {
        User fresh = userRepository.findById(user.getId()).orElse(user);
        return statusOf(fresh, adminSettingsService.getSettings());
    }

    /**
     * Called when a new service is created. Locks the provider row, refuses with HTTP 402 when a fee
     * is due, otherwise counts the service and spends one credit if it is beyond the free quota.
     * Returns the fresh provider row: callers must save THAT one, never the stale logged-in copy.
     */
    @Transactional
    public User chargeForNewService(User user) {
        User locked = userRepository.findByIdForUpdate(user.getId())
                .orElseThrow(() -> ApiException.notFound("USER_NOT_FOUND"));
        AdminSettings settings = adminSettingsService.getSettings();
        ServiceFeeStatusResponse s = statusOf(locked, settings);
        // Nobody publishes before the one-time registration fee is paid (admins never pay it).
        // Providers who already posted a service before this rule existed are treated as registered, so
        // nobody who is live today is locked out; their flag is set now and stays set.
        if (locked.getRole() != Role.ROLE_ADMIN && !locked.isRegistrationFeePaid()) {
            if (s.used() > 0) {
                locked.setRegistrationFeePaid(true);
            } else {
                throw ApiException.paymentRequired("REGISTRATION_FEE_REQUIRED");
            }
        }
        if (s.needsPayment()) {
            throw ApiException.paymentRequired("SERVICE_FEE_REQUIRED");
        }
        if (locked.getRole() != Role.ROLE_ADMIN) {
            if (s.used() >= s.freeLimit()) {
                locked.setServiceFeeCredits(locked.getServiceFeeCredits() - 1);
            }
            locked.setServicesPosted(s.used() + 1);
            userRepository.save(locked);
        }
        return locked;
    }

    /**
     * One PAID fee = one credit. Safe to call twice with the same payment reference: only the first
     * call adds a credit. Returns true when a credit was added. The payments part calls this when a
     * SERVICE_FEE payment turns PAID.
     */
    @Transactional
    public boolean addCredit(Long userId, String paymentReference) {
        if (paymentReference == null || paymentReference.isBlank()) {
            throw new IllegalArgumentException("INVALID_REFERENCE");
        }
        if (creditRepository.existsByReference(paymentReference)) return false;
        User locked = userRepository.findByIdForUpdate(userId)
                .orElseThrow(() -> ApiException.notFound("USER_NOT_FOUND"));
        try {
            creditRepository.saveAndFlush(ServiceFeeCredit.builder()
                    .reference(paymentReference).userId(userId).build());
        } catch (DataIntegrityViolationException duplicate) {
            return false;
        }
        locked.setServiceFeeCredits(locked.getServiceFeeCredits() + 1);
        userRepository.save(locked);
        return true;
    }

    private ServiceFeeStatusResponse statusOf(User u, AdminSettings settings) {
        int freeLimit = settings.getFreeServicesQuota();
        // The counter never goes down; the row count covers services posted before the counter existed.
        int used = Math.max(u.getServicesPosted(), servicePostRepository.findBySellerId(u.getId()).size());
        int credits = u.getServiceFeeCredits();
        boolean needsPayment = u.getRole() != Role.ROLE_ADMIN && used >= freeLimit && credits <= 0;
        return new ServiceFeeStatusResponse(freeLimit, used, credits, settings.getServiceFee(), needsPayment);
    }
}
