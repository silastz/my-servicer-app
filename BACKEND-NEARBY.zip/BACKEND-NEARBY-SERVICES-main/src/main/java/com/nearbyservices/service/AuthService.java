package com.nearbyservices.service;

import com.nearbyservices.dto.AuthResponse;
import com.nearbyservices.dto.LoginRequest;
import com.nearbyservices.dto.RegisterRequest;
import com.nearbyservices.model.Role;
import com.nearbyservices.model.User;
import com.nearbyservices.model.Wallet;
import com.nearbyservices.repository.UserRepository;
import com.nearbyservices.repository.WalletRepository;
import com.nearbyservices.security.CustomUserDetails;
import com.nearbyservices.security.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class AuthService {

    private static final SecureRandom OTP_RANDOM = new SecureRandom();

    /** 6-digit one-time code from a cryptographically secure source; covers 000000 to 999999. */
    /**
     * The username is only an internal label now: it is made by the server, never taken from the request,
     * and never used to sign in. "u_" plus random hex cannot look like an email or a phone number.
     */
    private String newInternalUsername() {
        String candidate;
        do {
            candidate = "u_" + java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 16);
        } while (userRepository.existsByUsername(candidate));
        return candidate;
    }

    private static String generateOtp() {
        return String.format("%06d", OTP_RANDOM.nextInt(1_000_000));
    }

    private final UserRepository userRepository;
    private final WalletRepository walletRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;
    private final EmailService emailService;
    private final SmsService smsService;
    private final AttemptLimiter limiter;
    private final SignupOtpChallenge signupChallenge;

    // ---- OTP protection -------------------------------------------------------------------------
    /** Wrong codes allowed per account before its code is burned and guessing is blocked. */
    private static final int OTP_MAX_WRONG = 5;
    private static final long OTP_WRONG_WINDOW_MS = 10 * 60_000L;
    /** Codes sent per phone/email: 3 per 10 minutes and 10 per day (stops SMS/email spam and SMS bill abuse). */
    private static final int OTP_SEND_SHORT_MAX = 3;
    private static final long OTP_SEND_SHORT_MS = 10 * 60_000L;
    private static final int OTP_SEND_DAY_MAX = 10;
    private static final long OTP_SEND_DAY_MS = 24 * 3_600_000L;

    // ---- Password rules ---------------------------------------------------------------------------
    // Any characters are allowed (letters, digits, symbols, spaces, emoji). Only the length is checked:
    // at least 4 characters, and at most 72 bytes because BCrypt cannot use more than that.
    private static final int PASSWORD_MIN_CHARS = 4;
    private static final int PASSWORD_MAX_BYTES = 72;

    private static void checkPasswordLength(String password) {
        if (password == null || password.codePointCount(0, password.length()) < PASSWORD_MIN_CHARS) {
            throw new IllegalArgumentException("PASSWORD_TOO_SHORT");
        }
        if (password.getBytes(java.nio.charset.StandardCharsets.UTF_8).length > PASSWORD_MAX_BYTES) {
            throw new IllegalArgumentException("PASSWORD_TOO_LONG");
        }
    }

    // ---- Login protection -------------------------------------------------------------------------
    /** Wrong passwords allowed per account; then login is refused (429) until the window passes or the password is reset. */
    private static final int LOGIN_MAX_WRONG = 5;
    private static final long LOGIN_WINDOW_MS = 30 * 60_000L;

    private static String phoneKey(String phone) {
        return "p:" + SmsService.normalizePhoneNumber(phone);
    }

    private static String emailKey(String email) {
        return "e:" + email.trim().toLowerCase();
    }

    /** Counts one code-sending request for this phone/email. Keyed by what was typed, so unknown accounts get the same 429. */
    private void limitOtpSend(String contactKey) {
        limiter.hit("otp-send-short:" + contactKey, OTP_SEND_SHORT_MAX, OTP_SEND_SHORT_MS);
        limiter.hit("otp-send-day:" + contactKey, OTP_SEND_DAY_MAX, OTP_SEND_DAY_MS);
    }

    /** Refuses (429) if this phone/email already used up its wrong-code attempts. Shared by verify and password reset. */
    private void checkOtpGuesses(String contactKey) {
        limiter.check("otp-guess:" + contactKey, OTP_MAX_WRONG, OTP_WRONG_WINDOW_MS);
    }

    /** Records a wrong code; returns true when this was the last allowed attempt (the stored code must then be erased). */
    private boolean recordWrongOtp(String contactKey) {
        return limiter.record("otp-guess:" + contactKey, OTP_WRONG_WINDOW_MS) >= OTP_MAX_WRONG;
    }

    private void otpAccepted(String contactKey) {
        limiter.reset("otp-guess:" + contactKey);
    }

    /**
     * Sign-up step 1. Saves NOTHING: no account, no pending record. It only checks the form, texts the code and
     * returns a signed challenge. The account is created in completeSignup(), when the code comes back right.
     */
    public AuthResponse register(RegisterRequest request) {
        // Public sign-up may only create buyers and sellers. Admin accounts are never self-service.
        if (request.getRole() != Role.ROLE_BUYER && request.getRole() != Role.ROLE_SELLER) {
            throw new IllegalArgumentException("ROLE_NOT_ALLOWED");
        }
        checkPasswordLength(request.getPassword());
        String cleanPhone = SmsService.normalizePhoneNumber(request.getPhone());
        if (cleanPhone.length() < 10 || cleanPhone.length() > 15 || !cleanPhone.matches("^\\+[0-9]{10,14}$")) {
            throw new IllegalArgumentException("INVALID_PHONE_NUMBER");
        }
        limitOtpSend("p:" + cleanPhone);
        boolean hasEmail = request.getEmail() != null && !request.getEmail().isBlank();
        if (hasEmail) {
            limitOtpSend(emailKey(request.getEmail()));
        }

        // The phone already belongs to an account: it is never touched from the public form.
        java.util.Optional<User> existingUserOpt = userRepository.findByPhone(cleanPhone)
                .or(() -> userRepository.findByPhone(request.getPhone()));
        if (existingUserOpt.isPresent()) {
            User existing = existingUserOpt.get();
            if (existing.isPhoneVerified() || existing.isEmailVerified()) {
                throw new IllegalArgumentException("PHONE_ALREADY_REGISTERED");
            }
            // An unconfirmed account row from an older version: not overwritten either. Its owner logs in
            // (the app then sends the SMS code) to finish verifying.
            throw new IllegalArgumentException("PHONE_VERIFICATION_PENDING");
        }
        String email = hasEmail ? request.getEmail().trim().toLowerCase() : null;
        if (email != null && userRepository.existsByEmail(email)) {
            throw new IllegalArgumentException("EMAIL_ALREADY_REGISTERED");
        }

        String phoneOtp = generateOtp();
        java.time.Instant expiresAt = java.time.Instant.now().plus(10, java.time.temporal.ChronoUnit.MINUTES);
        smsService.sendOtpSms(cleanPhone, request.getStageName(), phoneOtp);

        // No account, no id, no token.
        return AuthResponse.builder()
                .token(null)
                .phone(cleanPhone)
                .email(email)
                .emailVerified(false)
                .phoneVerified(false)
                .stageName(request.getStageName())
                .role(request.getRole())
                .country("TZ")
                .currency("TZS")
                .signupChallenge(signupChallenge.issue(cleanPhone, phoneOtp, expiresAt))
                .build();
    }

    /**
     * Sign-up step 2: the code and the form arrive together. Only if the code is right is the account
     * (User + Wallet) created, already phone-verified, and a token issued.
     */
    @Transactional
    public AuthResponse completeSignup(com.nearbyservices.dto.CompleteSignupRequest request) {
        if (request.getRole() != Role.ROLE_BUYER && request.getRole() != Role.ROLE_SELLER) {
            throw new IllegalArgumentException("ROLE_NOT_ALLOWED");
        }
        checkPasswordLength(request.getPassword());
        String cleanPhone = SmsService.normalizePhoneNumber(request.getPhone());
        if (!cleanPhone.matches("^\\+[0-9]{10,14}$")) {
            throw new IllegalArgumentException("INVALID_PHONE_NUMBER");
        }
        String key = "p:" + cleanPhone;
        checkOtpGuesses(key); // same wrong-guess lock as the other code checks
        String otp = request.getOtp() == null ? "" : request.getOtp().trim();
        if (otp.length() != 6 || !signupChallenge.matches(cleanPhone, otp, request.getChallenge())) {
            recordWrongOtp(key);
            throw new IllegalArgumentException("INVALID_OR_EXPIRED_OTP");
        }
        if (userRepository.findByPhone(cleanPhone).isPresent()) {
            throw new IllegalArgumentException("PHONE_ALREADY_REGISTERED");
        }
        String email = request.getEmail() != null && !request.getEmail().isBlank()
                ? request.getEmail().trim().toLowerCase() : null;
        if (email != null && userRepository.existsByEmail(email)) {
            throw new IllegalArgumentException("EMAIL_ALREADY_REGISTERED");
        }
        String emailOtp = email != null ? generateOtp() : null;

        User saved = userRepository.save(User.builder()
                .username(newInternalUsername())
                .phone(cleanPhone)
                .phoneVerified(true)
                .email(email)
                .emailVerified(false)
                .emailOtp(emailOtp)
                .emailOtpExpiry(emailOtp != null ? java.time.LocalDateTime.now().plusMinutes(10) : null)
                .password(passwordEncoder.encode(request.getPassword()))
                .stageName(request.getStageName())
                .role(request.getRole())
                .build());
        walletRepository.save(Wallet.builder()
                .user(saved)
                .balance(BigDecimal.ZERO)
                .lockedEscrowBalance(BigDecimal.ZERO)
                .build());
        otpAccepted(key);
        if (emailOtp != null) {
            emailService.sendOtpEmail(saved.getEmail(), saved.getStageName(), emailOtp);
        }

        String token = jwtService.generateToken(new CustomUserDetails(saved), Map.of(
                "role", saved.getRole().name(),
                "stageName", saved.getStageName(),
                "badge", saved.getVerificationBadge().name()
        ));
        return AuthResponse.builder()
                .token(token)
                .id(saved.getId())
                .username(saved.getUsername())
                .email(saved.getEmail())
                .emailVerified(saved.isEmailVerified())
                .phone(saved.getPhone())
                .phoneVerified(saved.isPhoneVerified())
                .stageName(saved.getStageName())
                .role(saved.getRole())
                .verificationBadge(saved.getVerificationBadge())
                .hideMyId(saved.isHideMyId())
                .profileLocked(saved.isProfileLocked())
                .country(UserSettingsService.countryOf(saved))
                .currency(UserSettingsService.currencyOf(saved))
                .build();
    }

    public AuthResponse login(LoginRequest request) {
        String loginId = request.getLogin() != null ? request.getLogin().trim() : "";
        String normalizedPhone = SmsService.normalizePhoneNumber(loginId);

        // One counter per ACCOUNT (not per typed text), so trying the email and then the phone of the same
        // account does not double the attempts. Unknown identifiers are counted too, so nothing leaks.
        String loginKey = "login:" + userRepository.findByEmail(loginId.toLowerCase())
                .or(() -> userRepository.findByPhone(loginId))
                .or(() -> userRepository.findByPhone(normalizedPhone))
                .map(u -> "u" + u.getId())
                .orElse(loginId.contains("@") ? emailKey(loginId) : phoneKey(loginId));
        try {
            limiter.check(loginKey, LOGIN_MAX_WRONG, LOGIN_WINDOW_MS);
        } catch (com.nearbyservices.exception.ApiException locked) {
            // The app sends the user to "forgot password" on this code.
            throw com.nearbyservices.exception.ApiException.tooManyRequests("TOO_MANY_LOGIN_ATTEMPTS");
        }
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(loginId, request.getPassword())
            );
        } catch (org.springframework.security.core.AuthenticationException wrong) {
            limiter.record(loginKey, LOGIN_WINDOW_MS);
            throw wrong;
        }
        limiter.reset(loginKey);

        User user = userRepository.findByEmail(loginId.toLowerCase())
                .or(() -> userRepository.findByPhone(loginId))
                .or(() -> userRepository.findByPhone(normalizedPhone))
                .orElseThrow(() -> new IllegalArgumentException("INVALID_CREDENTIALS"));

        // An admin suspended this account. Said only now, after the password was right, so it reveals nothing to a stranger.
        if (user.isSuspended()) {
            throw com.nearbyservices.exception.ApiException.forbidden("ACCOUNT_SUSPENDED");
        }

        // The account opens only after the phone code was confirmed. A verified email is not enough:
        // anyone can type a phone number and an email of their own at sign-up.
        if (!user.isPhoneVerified()) {
            throw new IllegalArgumentException("ACCOUNT_NOT_VERIFIED");
        }

        CustomUserDetails userDetails = new CustomUserDetails(user);
        String token = jwtService.generateToken(userDetails, Map.of(
                "role", user.getRole().name(),
                "stageName", user.getStageName(),
                "badge", user.getVerificationBadge().name()
        ));

        return AuthResponse.builder()
                .token(token)
                .id(user.getId())
                .username(user.getUsername())
                .email(user.getEmail())
                .emailVerified(user.isEmailVerified())
                // The app restores the registered phone on a new device from the login answer.
                .phone(user.getPhone())
                .phoneVerified(user.isPhoneVerified())
                .avatarUrl(user.getAvatarUrl())
                .stageName(user.getStageName())
                .role(user.getRole())
                .verificationBadge(user.getVerificationBadge())
                .hideMyId(user.isHideMyId())
                .profileLocked(user.isProfileLocked())
                .country(UserSettingsService.countryOf(user))
                .currency(UserSettingsService.currencyOf(user))
                .build();
    }

    @Transactional
    public boolean verifyEmailOtp(String email, String otp) {
        if (email == null || otp == null || otp.trim().length() != 6) return false;

        String key = emailKey(email);
        checkOtpGuesses(key);

        java.util.Optional<User> found = userRepository.findByEmail(email.trim().toLowerCase());
        if (found.isPresent()) {
            User user = found.get();
            if (user.getEmailOtp() != null
                    && user.getEmailOtp().equals(otp.trim())
                    && user.getEmailOtpExpiry() != null
                    && user.getEmailOtpExpiry().isAfter(java.time.LocalDateTime.now())) {
                user.setEmailVerified(true);
                user.setEmailOtp(null);
                user.setEmailOtpExpiry(null);
                userRepository.save(user);
                otpAccepted(key);
                return true;
            }
        }
        // Wrong code (or unknown email: counted the same, so nothing leaks). The last allowed miss erases the code.
        if (recordWrongOtp(key) && found.isPresent()) {
            User user = found.get();
            user.setEmailOtp(null);
            user.setEmailOtpExpiry(null);
            userRepository.save(user);
        }
        return false;
    }

    @Transactional
    public boolean resendEmailOtp(String email) {
        if (email == null || email.isBlank()) return false;
        limitOtpSend(emailKey(email));
        return userRepository.findByEmail(email.trim().toLowerCase())
                .map(user -> {
                    String otp = generateOtp();
                    user.setEmailOtp(otp);
                    user.setEmailOtpExpiry(java.time.LocalDateTime.now().plusMinutes(10));
                    userRepository.save(user);
                    emailService.sendOtpEmail(user.getEmail(), user.getStageName(), otp);
                    return true;
                }).orElse(false);
    }

    @Transactional
    public java.util.Optional<AuthResponse> verifyPhoneOtp(String phone, String otp) {
        if (phone == null || otp == null || otp.trim().length() != 6) return java.util.Optional.empty();

        String cleanPhone = SmsService.normalizePhoneNumber(phone);
        String key = "p:" + cleanPhone;
        checkOtpGuesses(key);

        java.util.Optional<User> found = userRepository.findByPhone(cleanPhone)
                .or(() -> userRepository.findByPhone(phone.trim()));
        java.util.Optional<AuthResponse> result = found
                .filter(user -> user.getPhoneOtp() != null
                        && user.getPhoneOtp().equals(otp.trim())
                        && user.getPhoneOtpExpiry() != null
                        && user.getPhoneOtpExpiry().isAfter(java.time.LocalDateTime.now()))
                .map(user -> {
                    user.setPhoneVerified(true);
                    user.setPhoneOtp(null);
                    user.setPhoneOtpExpiry(null);
                    User savedUser = userRepository.save(user);

                    CustomUserDetails userDetails = new CustomUserDetails(savedUser);
                    String token = jwtService.generateToken(userDetails, Map.of(
                            "role", savedUser.getRole().name(),
                            "stageName", savedUser.getStageName(),
                            "badge", savedUser.getVerificationBadge().name()
                    ));

                    return AuthResponse.builder()
                            .token(token)
                            .id(savedUser.getId())
                            .username(savedUser.getUsername())
                            .email(savedUser.getEmail())
                            .emailVerified(savedUser.isEmailVerified())
                            .phone(savedUser.getPhone())
                            .phoneVerified(savedUser.isPhoneVerified())
                            .stageName(savedUser.getStageName())
                            .role(savedUser.getRole())
                            .verificationBadge(savedUser.getVerificationBadge())
                            .hideMyId(savedUser.isHideMyId())
                            .profileLocked(savedUser.isProfileLocked())
                            .country(UserSettingsService.countryOf(savedUser))
                            .currency(UserSettingsService.currencyOf(savedUser))
                            .build();
                });

        if (result.isPresent()) {
            otpAccepted(key);
        } else if (recordWrongOtp(key) && found.isPresent()) {
            // Wrong code (or unknown phone: counted the same). The last allowed miss erases the code,
            // but not its expiry: the sign-up stays "claimed" until it would have expired (see register()).
            User user = found.get();
            user.setPhoneOtp(null);
            userRepository.save(user);
        }
        return result;
    }

    @Transactional
    public boolean resendPhoneOtp(String phone) {
        if (phone == null || phone.isBlank()) return false;

        String cleanPhone = SmsService.normalizePhoneNumber(phone);
        limitOtpSend("p:" + cleanPhone);
        return userRepository.findByPhone(cleanPhone)
                .or(() -> userRepository.findByPhone(phone.trim()))
                .map(user -> {
                    String otp = generateOtp();
                    user.setPhoneOtp(otp);
                    user.setPhoneOtpExpiry(java.time.LocalDateTime.now().plusMinutes(10));
                    userRepository.save(user);
                    smsService.sendOtpSms(user.getPhone(), user.getStageName(), otp);
                    return true;
                }).orElse(false);
    }

    /** Same reply for every outcome, so this endpoint cannot be used to find out who is registered. */
    private static final Map<String, Object> FORGOT_PASSWORD_REPLY = Map.of(
            "success", true,
            "message", "OTP_SENT_IF_ACCOUNT_EXISTS"
    );

    @Transactional
    public Map<String, Object> forgotPassword(com.nearbyservices.dto.ForgotPasswordRequest request) {
        String idStr = request.getIdentifier() != null ? request.getIdentifier().trim() : "";
        if (idStr.isEmpty()) {
            throw new IllegalArgumentException("REQUIRED_IDENTIFIER");
        }
        limitOtpSend(idStr.contains("@") ? emailKey(idStr) : phoneKey(idStr));

        // Only email or phone number identify an account here (never the username).
        // Unknown or unverified accounts get no code, but the caller sees the same reply as for a real one.
        if (idStr.contains("@")) {
            userRepository.findByEmail(idStr.toLowerCase())
                    .filter(u -> u.isPhoneVerified() || u.isEmailVerified())
                    .ifPresent(user -> {
                        String otp = generateOtp();
                        user.setEmailOtp(otp);
                        user.setEmailOtpExpiry(java.time.LocalDateTime.now().plusMinutes(10));
                        userRepository.save(user);
                        emailService.sendOtpEmail(user.getEmail(), user.getStageName(), otp);
                    });
        } else {
            String cleanPhone = SmsService.normalizePhoneNumber(idStr);
            userRepository.findByPhone(cleanPhone)
                    .or(() -> userRepository.findByPhone(idStr))
                    .filter(User::isPhoneVerified)
                    .ifPresent(user -> {
                        String otp = generateOtp();
                        user.setPhoneOtp(otp);
                        user.setPhoneOtpExpiry(java.time.LocalDateTime.now().plusMinutes(10));
                        userRepository.save(user);
                        smsService.sendOtpSms(user.getPhone(), user.getStageName(), otp);
                    });
        }
        return FORGOT_PASSWORD_REPLY;
    }

    // noRollbackFor: erasing a burned code after too many wrong guesses must be saved even though the call fails.
    @Transactional(noRollbackFor = IllegalArgumentException.class)
    public Map<String, Object> resetPassword(com.nearbyservices.dto.ResetPasswordRequest request) {
        String idStr = request.getIdentifier() != null ? request.getIdentifier().trim() : "";
        String otp = request.getOtp() != null ? request.getOtp().trim() : "";
        String newPassword = request.getNewPassword() != null ? request.getNewPassword().trim() : "";

        checkPasswordLength(newPassword);
        if (otp.length() != 6) {
            throw new IllegalArgumentException("INVALID_OTP_FORMAT");
        }

        boolean isEmail = idStr.contains("@");
        // Same counter as the verify endpoints, so the code cannot be guessed through either door.
        String key = isEmail ? emailKey(idStr) : phoneKey(idStr);
        checkOtpGuesses(key);

        User user;
        boolean codeOk;
        if (isEmail) {
            user = userRepository.findByEmail(idStr.toLowerCase()).orElse(null);
            codeOk = user != null && user.getEmailOtp() != null && user.getEmailOtp().equals(otp)
                    && user.getEmailOtpExpiry() != null
                    && !user.getEmailOtpExpiry().isBefore(java.time.LocalDateTime.now());
        } else {
            String cleanPhone = SmsService.normalizePhoneNumber(idStr);
            user = userRepository.findByPhone(cleanPhone)
                    .or(() -> userRepository.findByPhone(idStr))
                    .orElse(null);
            codeOk = user != null && user.getPhoneOtp() != null && user.getPhoneOtp().equals(otp)
                    && user.getPhoneOtpExpiry() != null
                    && !user.getPhoneOtpExpiry().isBefore(java.time.LocalDateTime.now());
        }

        if (!codeOk) {
            // Unknown account and wrong code look and count the same. The last allowed miss erases the code.
            if (recordWrongOtp(key) && user != null) {
                if (isEmail) {
                    user.setEmailOtp(null);
                    user.setEmailOtpExpiry(null);
                } else {
                    user.setPhoneOtp(null);
                    user.setPhoneOtpExpiry(null);
                }
                userRepository.save(user);
            }
            throw new IllegalArgumentException("INVALID_OR_EXPIRED_OTP");
        }

        otpAccepted(key);
        if (isEmail) {
            user.setEmailOtp(null);
            user.setEmailOtpExpiry(null);
            user.setEmailVerified(true);
        } else {
            user.setPhoneOtp(null);
            user.setPhoneOtpExpiry(null);
            user.setPhoneVerified(true);
        }

        user.setPassword(passwordEncoder.encode(newPassword));
        // Every login issued before this moment stops working (a stolen token cannot outlive the reset).
        user.setTokensValidFrom(java.time.Instant.now());
        userRepository.save(user);
        // A locked-out user who proved they own the account with the code can log in again at once.
        limiter.reset("login:u" + user.getId());

        return Map.of(
                "success", true,
                "message", "PASSWORD_RESET_SUCCESS"
        );
    }
}
