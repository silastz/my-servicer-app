package com.nearbyservices.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmailService {

    private final JavaMailSender mailSender;

    @Value("${spring.mail.username:karibuhuduma@gmail.com}")
    private String fromEmail;

    @Value("${app.frontend.url:https://nearbyservices.techwareafrica.tech}")
    private String baseUrl;

    @Async
    public void sendOtpEmail(String toEmail, String stageName, String otp) {
        try {
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");

            helper.setFrom(new InternetAddress(fromEmail, "NearByServices"));
            helper.setTo(toEmail);
            helper.setSubject("NearByServices Verification Code: " + otp);

            String html = "<div style=\"font-family: 'Segoe UI', Arial, sans-serif; max-width: 520px; margin: 0 auto; padding: 24px; border: 1px solid #e2e8f0; border-radius: 12px; background-color: #ffffff;\">"
                    + "<div style=\"text-align: center; margin-bottom: 24px;\">"
                    + "<h2 style=\"color: #2563eb; margin: 0; font-size: 24px; font-weight: 800;\">NearByServices</h2>"
                    + "<p style=\"color: #64748b; margin-top: 4px; font-size: 13px;\">Uthibitisho wa Barua Pepe / Email Verification</p>"
                    + "</div>"
                    + "<p style=\"font-size: 15px; color: #1e293b;\">Habari <strong>" + stageName + "</strong>,</p>"
                    + "<p style=\"font-size: 14px; color: #475569; line-height: 1.5;\">Nambari yako ya siri ya kuthibitisha akaunti yako kwenye NearByServices ni:</p>"
                    + "<div style=\"text-align: center; margin: 24px 0;\">"
                    + "<span style=\"display: inline-block; background-color: #f1f5f9; border: 1.5px dashed #2563eb; border-radius: 8px; padding: 12px 28px; font-size: 28px; font-weight: 800; letter-spacing: 6px; color: #2563eb;\">" + otp + "</span>"
                    + "</div>"
                    + "<p style=\"font-size: 12px; color: #64748b;\">Nambari hii itaisha muda wake baada ya dakika 10. Usishiriki nambari hii na mtu mwingine yeyote.</p>"
                    + "<hr style=\"border: none; border-top: 1px solid #f1f5f9; margin: 24px 0;\" />"
                    + "<p style=\"font-size: 11px; color: #94a3b8; text-align: center; margin: 0;\">© 2026 NearByServices. Haki zote zimehifadhiwa.</p>"
                    + "</div>";

            helper.setText(html, true);
            mailSender.send(mimeMessage);
            log.info("HTML OTP verification email sent successfully to {}", toEmail);
        } catch (Exception e) {
            log.error("Failed to send OTP email to {}: {}", toEmail, e.getMessage());
        }
    }
}
