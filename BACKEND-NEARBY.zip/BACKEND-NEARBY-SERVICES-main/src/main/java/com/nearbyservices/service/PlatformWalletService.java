package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.EscrowStatus;
import com.nearbyservices.model.PlatformEntry;
import com.nearbyservices.repository.AdminSettingsRepository;
import com.nearbyservices.repository.EscrowTransactionRepository;
import com.nearbyservices.repository.PlatformEntryRepository;
import com.nearbyservices.verification.AuditLog;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

/**
 * The platform's own wallet: what the app earns and what the admin takes out.
 * <ul>
 * <li>{@code balance} = income that can be withdrawn = money in (VAT left out) minus money out.</li>
 * <li>VAT is shown on its own and is never withdrawable: it is owed to the tax authority. Remitting it is not
 *     modelled here, so it keeps growing until you add that step.</li>
 * <li>{@code held} = money in bookings that are not finished yet (not the platform's to spend).</li>
 * </ul>
 */
@Service
@RequiredArgsConstructor
public class PlatformWalletService {

    public static final String REGISTRATION_FEE = "REGISTRATION_FEE";
    public static final String SERVICE_FEE = "SERVICE_FEE";
    public static final String BOOST = "BOOST";
    public static final String COLLECTION_FEE = "COLLECTION_FEE";
    public static final String PAYOUT_FEE = "PAYOUT_FEE";
    public static final String VAT = "VAT";
    public static final String WITHDRAWAL = "WITHDRAWAL";

    private static final long ADMIN_WITHDRAW_MIN = 1000;
    private static final Pattern REFERENCE = Pattern.compile("^[A-Za-z0-9_.:-]{6,100}$");

    private final PlatformEntryRepository entryRepository;
    private final EscrowTransactionRepository escrowRepository;
    private final AdminSettingsRepository adminSettingsRepository;
    private final AdminSettingsService adminSettingsService;
    private final AuditLog auditLog;

    /** Books money the platform earned. Zero or negative amounts are ignored. Joins the caller's transaction. */
    @Transactional
    public void income(String type, BigDecimal amount, String title, String reference) {
        if (amount == null || amount.signum() <= 0) return;
        entryRepository.save(PlatformEntry.builder()
                .type(type).direction("IN").amount(amount).title(title).reference(reference).build());
    }

    // ---------------------------------------------------------------- read

    @Transactional(readOnly = true)
    public Map<String, Object> summary() {
        BigDecimal in = BigDecimal.ZERO, out = BigDecimal.ZERO, vat = BigDecimal.ZERO;
        Map<String, BigDecimal> byType = new LinkedHashMap<>();
        for (Object[] row : entryRepository.totals()) {
            String type = (String) row[0];
            String direction = (String) row[1];
            BigDecimal sum = (BigDecimal) row[2];
            if ("IN".equals(direction)) {
                in = in.add(sum);
                byType.merge(type, sum, BigDecimal::add);
            } else {
                out = out.add(sum);
            }
        }
        vat = byType.getOrDefault(VAT, BigDecimal.ZERO);
        BigDecimal held = escrowRepository.sumAmountByStatusIn(List.of(
                EscrowStatus.PENDING_ACCEPTANCE, EscrowStatus.ACCEPTED, EscrowStatus.FUNDED, EscrowStatus.DISPUTED));

        Map<String, Object> income = new LinkedHashMap<>();
        income.put("registrationFees", byType.getOrDefault(REGISTRATION_FEE, BigDecimal.ZERO));
        income.put("serviceFees", byType.getOrDefault(SERVICE_FEE, BigDecimal.ZERO));
        income.put("boosts", byType.getOrDefault(BOOST, BigDecimal.ZERO));
        income.put("commissions", BigDecimal.ZERO);   // the platform takes no booking commission
        income.put("withdrawalFees", byType.getOrDefault(PAYOUT_FEE, BigDecimal.ZERO));
        income.put("collectionFees", byType.getOrDefault(COLLECTION_FEE, BigDecimal.ZERO));
        income.put("vat", vat);

        Map<String, Object> m = new LinkedHashMap<>();
        m.put("balance", in.subtract(vat).subtract(out));
        m.put("held", held);
        m.put("totalIn", in);
        m.put("totalOut", out);
        m.put("income", income);
        return m;
    }

    @Transactional(readOnly = true)
    public List<Map<String, Object>> transactions(int limit) {
        int n = Math.max(1, Math.min(limit, 200));
        return entryRepository.findAllByOrderByCreatedAtDescIdDesc(PageRequest.of(0, n)).stream().map(e -> {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", e.getId());
            m.put("type", e.getType());
            m.put("amount", e.getAmount());
            m.put("direction", e.getDirection());
            m.put("title", e.getTitle());
            m.put("status", e.getStatus());
            m.put("reference", e.getReference());
            m.put("createdAt", e.getCreatedAt());
            if (e.getFee() != null) m.put("fee", e.getFee());
            if (e.getNetAmount() != null) m.put("net", e.getNetAmount());
            if (e.getPhoneMasked() != null) m.put("phone", e.getPhoneMasked());
            if (e.getAdminId() != null) m.put("adminId", e.getAdminId());
            return m;
        }).toList();
    }

    // ---------------------------------------------------------------- admin withdrawal

    /**
     * Takes money out of the platform wallet. The fee is the flat payout fee from the admin's CURRENT provider-fee
     * setting (never from the request): the admin receives {@code amount - fee}. The fee is a payout cost, not income.
     * Runs one at a time (the settings row is locked), checks the withdrawable balance, and rejects a repeated reference.
     * The line is PENDING and keeps the payout phone until an admin completes or fails it (WithdrawalAdminService);
     * a failed one drops out of every total, so the balance is back.
     */
    @Transactional
    public Map<String, Object> adminWithdraw(long adminId, BigDecimal rawAmount, String rawPhone, String rawReference) {
        long amount = whole(rawAmount);
        if (amount < ADMIN_WITHDRAW_MIN) throw ApiException.badRequest("INVALID_AMOUNT");
        String phone = PayoutPhone.normalize(rawPhone);
        if (phone == null) throw ApiException.badRequest("INVALID_PHONE");
        String reference = rawReference == null || rawReference.isBlank()
                ? "AWD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase() : rawReference.trim();
        if (!REFERENCE.matcher(reference).matches()) throw ApiException.badRequest("INVALID_REFERENCE");

        adminSettingsService.getSettings();
        var settings = adminSettingsRepository.findFirstByOrderByIdAsc().orElseThrow();
        if (entryRepository.existsByTypeAndReference(WITHDRAWAL, reference)) throw ApiException.conflict("DUPLICATE_WITHDRAWAL");

        long fee = settings.getProviderPayoutFee();
        long net = amount - fee;
        if (net <= 0) throw ApiException.badRequest("WITHDRAW_TOO_SMALL_FOR_FEES");
        BigDecimal balance = (BigDecimal) summary().get("balance");
        if (BigDecimal.valueOf(amount).compareTo(balance) > 0) throw ApiException.badRequest("INSUFFICIENT_PLATFORM_BALANCE");

        entryRepository.save(PlatformEntry.builder()
                .type(WITHDRAWAL).direction("OUT").amount(BigDecimal.valueOf(amount)).status("PENDING")
                .reference(reference).fee(fee).netAmount(net).phoneMasked(mask(phone)).payoutPhone(phone).adminId(adminId).build());
        auditLog.record(adminId, "ADMIN_WALLET_WITHDRAWAL", reference + " amount=" + amount + " fee=" + fee);

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("fee", fee);
        out.put("netAmount", net);
        out.put("reference", reference);
        out.put("balance", balance.subtract(BigDecimal.valueOf(amount)));
        return out;
    }

    private static long whole(BigDecimal v) {
        if (v == null) throw ApiException.badRequest("INVALID_AMOUNT");
        try {
            return v.longValueExact();
        } catch (ArithmeticException e) {
            throw ApiException.badRequest("INVALID_AMOUNT");
        }
    }

    private static String mask(String phone) {
        return phone.length() <= 6 ? "***" : phone.substring(0, 4) + "****" + phone.substring(phone.length() - 2);
    }
}
