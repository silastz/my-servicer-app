package com.nearbyservices.service;

import com.nearbyservices.model.LiveLocation;
import com.nearbyservices.repository.LiveLocationRepository;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Where each person on an active booking is right now, so the other person can follow them on the map.
 *
 * Stored in the database (table live_locations), so positions survive a restart and every server instance sees
 * the same ones. Privacy: one row per person per booking that is overwritten on each update (no history), a position
 * counts only for {@link #TTL_MILLIS}, the row is deleted when sharing stops or the booking stops being active,
 * and a purge job removes anything older than the lifetime.
 *
 * put/remove run in their own transaction because the callers in EscrowService are read-only transactions.
 */
@Service
public class LiveLocationService {

    static final long TTL_MILLIS = 90_000;

    public record Point(double latitude, double longitude, Double heading, long atMillis) {}

    private final LiveLocationRepository repo;
    private final JobLock jobLock; // null in unit tests: the purge then runs directly

    public LiveLocationService(LiveLocationRepository repo) {
        this(repo, null);
    }

    @org.springframework.beans.factory.annotation.Autowired
    public LiveLocationService(LiveLocationRepository repo, JobLock jobLock) {
        this.repo = repo;
        this.jobLock = jobLock;
    }

    static String key(String ref, long userId) {
        return ref + ":" + userId;
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void put(String ref, long userId, double lat, double lng, Double heading) {
        repo.upsert(key(ref, userId), ref, userId, lat, lng, heading, System.currentTimeMillis());
    }

    /** The user's last position on this booking, only if it is still fresh. */
    @Transactional(readOnly = true)
    public Optional<Point> fresh(String ref, long userId) {
        return repo.findById(key(ref, userId))
                .filter(r -> System.currentTimeMillis() - r.getAtMillis() <= TTL_MILLIS)
                .map(LiveLocationService::toPoint);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void remove(String ref, long userId) {
        repo.deleteByKey(key(ref, userId));
    }

    /** Deletes positions older than the lifetime. */
    @Scheduled(fixedDelay = 60_000L, initialDelay = 60_000L)
    @Transactional
    public void purgeStale() {
        Runnable purge = () -> repo.deleteOlderThan(System.currentTimeMillis() - TTL_MILLIS);
        if (jobLock == null) purge.run();
        else jobLock.run("live-location-purge", purge);
    }

    private static Point toPoint(LiveLocation r) {
        return new Point(r.getLatitude(), r.getLongitude(), r.getHeading(), r.getAtMillis());
    }
}
