package com.nearbyservices.service;

import java.util.regex.Pattern;

/** The phone number a withdrawal is paid out to: digits with an optional leading +, 9 to 15 of them. */
final class PayoutPhone {

    private static final Pattern VALID = Pattern.compile("^\\+?[0-9]{9,15}$");

    private PayoutPhone() {}

    /** The number without spaces and dashes, or null when it is missing or not a phone number. */
    static String normalize(String raw) {
        if (raw == null) return null;
        String phone = raw.replaceAll("[\\s-]", "");
        return VALID.matcher(phone).matches() ? phone : null;
    }
}
