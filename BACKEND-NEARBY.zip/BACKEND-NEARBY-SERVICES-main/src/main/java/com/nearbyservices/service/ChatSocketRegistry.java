package com.nearbyservices.service;

import org.springframework.stereotype.Component;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Who is connected to the live chat socket. One user can have several phones connected at once.
 * Events are tiny "something changed" signals; the app then re-reads the conversation with its
 * normal authenticated REST call, so no message content ever travels over the socket.
 */
@Component
public class ChatSocketRegistry {

    private final Map<Long, Map<String, WebSocketSession>> sessions = new ConcurrentHashMap<>();

    public void add(Long userId, WebSocketSession session) {
        sessions.computeIfAbsent(userId, k -> new ConcurrentHashMap<>()).put(session.getId(), session);
    }

    public void remove(Long userId, String sessionId) {
        if (userId == null) return;
        Map<String, WebSocketSession> mine = sessions.get(userId);
        if (mine == null) return;
        mine.remove(sessionId);
        if (mine.isEmpty()) sessions.remove(userId, mine);
    }

    public boolean isOnline(Long userId) {
        Map<String, WebSocketSession> mine = sessions.get(userId);
        return mine != null && !mine.isEmpty();
    }

    /** Sends [json] to every open connection of the user. Never throws. */
    public void push(Long userId, String json) {
        Map<String, WebSocketSession> mine = sessions.get(userId);
        if (mine == null) return;
        TextMessage frame = new TextMessage(json);
        for (WebSocketSession s : mine.values()) {
            try {
                if (s.isOpen()) s.sendMessage(frame);
            } catch (Exception ignored) {
                // a dead connection is cleaned up when its close callback arrives
            }
        }
    }

    /** {"type":"chat","event":"message","from":1,"to":2}: only numbers and fixed words, nothing to escape. */
    public static String chatEvent(String event, Long from, Long to) {
        return "{\"type\":\"chat\",\"event\":\"" + event + "\",\"from\":" + from + ",\"to\":" + to + "}";
    }
}
