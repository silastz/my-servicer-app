package com.nearbyservices.service;

import java.util.ArrayList;
import java.util.List;

/** Badges a provider earns from their reviews. Same thresholds as the app's ServiceBadgeRules. */
public final class BadgeRules {
    private BadgeRules() {}

    public static List<String> earned(Double rating, Integer reviews) {
        double r = rating == null ? 0 : rating;
        int n = reviews == null ? 0 : reviews;
        List<String> out = new ArrayList<>();
        if (n >= 10 && r >= 4.8) out.add("TOP_RATED");
        if (n >= 5 && r >= 4.5) out.add("PROFESSIONAL");
        if (n >= 25 && r >= 4.6) out.add("CUSTOMER_FAVORITE");
        return out;
    }
}
