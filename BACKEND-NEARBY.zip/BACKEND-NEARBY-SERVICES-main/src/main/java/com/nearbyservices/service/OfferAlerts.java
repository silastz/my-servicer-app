package com.nearbyservices.service;

import com.nearbyservices.model.PriceOffer;
import com.nearbyservices.model.ServicePost;
import com.nearbyservices.model.User;
import com.nearbyservices.repository.ServicePostRepository;
import com.nearbyservices.repository.UserRepository;
import com.nearbyservices.service.PushService.Text;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Locale;
import java.util.Map;

/**
 * The wording of every offer alert (English and Swahili) and who gets it. Called by OfferService when an offer
 * changes and by OfferReminderJob when a deadline is close. Reads only; it never changes an offer.
 *
 * New offer -> seller. Auto-agreed -> seller (the buyer already has the answer on screen). Accepted / declined ->
 * buyer. Withdrawn -> seller. Two hours left -> whoever must act (seller on OFFERED, buyer on AGREED).
 */
@Component
@RequiredArgsConstructor
public class OfferAlerts {

    private final PushService push;
    private final UserRepository userRepository;
    private final ServicePostRepository servicePostRepository;

    public void newOffer(PriceOffer o) {
        Who w = who(o);
        send(o.getSellerId(), o, "OFFERED",
                new Text("New price offer", "Ofa mpya ya bei"),
                new Text(w.buyer.en + " offered " + money(o.getAmount()) + " for " + w.title + ". Reply within 24 hours.",
                        w.buyer.sw + " ametoa " + money(o.getAmount()) + " kwa " + w.title + ". Jibu ndani ya saa 24."));
    }

    public void autoAgreed(PriceOffer o) {
        Who w = who(o);
        send(o.getSellerId(), o, "AGREED",
                new Text("Offer accepted automatically", "Ofa imekubaliwa moja kwa moja"),
                new Text(w.buyer.en + "'s offer of " + money(o.getAmount()) + " for " + w.title + " met your auto-accept price. They can book now.",
                        "Ofa ya " + w.buyer.sw + " ya " + money(o.getAmount()) + " kwa " + w.title + " imefikia bei yako ya kukubali. Sasa wanaweza kuweka oda."));
    }

    public void accepted(PriceOffer o) {
        Who w = who(o);
        BigDecimal price = o.getAgreedAmount() != null ? o.getAgreedAmount() : o.getAmount();
        send(o.getBuyerId(), o, "AGREED",
                new Text("Your offer was accepted", "Ofa yako imekubaliwa"),
                new Text(w.seller.en + " agreed to " + money(price) + " for " + w.title + ". Book within 48 hours.",
                        w.seller.sw + " amekubali " + money(price) + " kwa " + w.title + ". Weka oda ndani ya saa 48."));
    }

    public void declined(PriceOffer o) {
        Who w = who(o);
        send(o.getBuyerId(), o, "REJECTED",
                new Text("Your offer was declined", "Ofa yako imekataliwa"),
                new Text(w.seller.en + " did not accept " + money(o.getAmount()) + " for " + w.title + ". You can try a different price.",
                        w.seller.sw + " hajakubali " + money(o.getAmount()) + " kwa " + w.title + ". Unaweza kujaribu bei nyingine."));
    }

    public void withdrawn(PriceOffer o) {
        Who w = who(o);
        send(o.getSellerId(), o, "WITHDRAWN",
                new Text("Offer withdrawn", "Ofa imeondolewa"),
                new Text(w.buyer.en + " withdrew the offer for " + w.title + ".",
                        w.buyer.sw + " ameondoa ofa ya " + w.title + "."));
    }

    /** About two hours left. OFFERED: the seller must answer. AGREED: the buyer must book. */
    public void expiringSoon(PriceOffer o) {
        Who w = who(o);
        if (o.getStatus() == com.nearbyservices.model.OfferStatus.OFFERED) {
            send(o.getSellerId(), o, "OFFERED",
                    new Text("Offer expires soon", "Ofa inakaribia kuisha"),
                    new Text(w.buyer.en + "'s offer of " + money(o.getAmount()) + " for " + w.title + " expires in about 2 hours. Accept or decline.",
                            "Ofa ya " + w.buyer.sw + " ya " + money(o.getAmount()) + " kwa " + w.title + " inaisha baada ya saa 2 hivi. Kubali au kataa."));
        } else {
            BigDecimal price = o.getAgreedAmount() != null ? o.getAgreedAmount() : o.getAmount();
            send(o.getBuyerId(), o, "AGREED",
                    new Text("Agreed price expires soon", "Bei mliyokubaliana inakaribia kuisha"),
                    new Text("Your agreed price of " + money(price) + " for " + w.title + " expires in about 2 hours. Book now.",
                            "Bei ya " + money(price) + " kwa " + w.title + " inaisha baada ya saa 2 hivi. Weka oda sasa."));
        }
    }

    // ----------------------------------------------------------------

    private void send(Long userId, PriceOffer o, String status, Text title, Text body) {
        try {
            push.toUser(userId, title, body, Map.of(
                    "type", "offer", "id", String.valueOf(o.getId()),
                    "status", status, "serviceId", String.valueOf(o.getServiceId())));
        } catch (Exception e) {
            // An alert must never break the offer itself.
        }
    }

    private static String money(BigDecimal v) {
        return "TSh " + String.format(Locale.US, "%,d", v.setScale(0, java.math.RoundingMode.HALF_UP).longValue());
    }

    private record Name(String en, String sw) {}

    private record Who(Name buyer, Name seller, String title) {}

    private Who who(PriceOffer o) {
        User b = userRepository.findById(o.getBuyerId()).orElse(null);
        User s = userRepository.findById(o.getSellerId()).orElse(null);
        String title = servicePostRepository.findById(o.getServiceId()).map(ServicePost::getTitle).orElse("your service");
        return new Who(name(b, "A customer", "Mteja"), name(s, "The provider", "Mtoa huduma"), title);
    }

    private static Name name(User u, String en, String sw) {
        String n = u == null ? null : u.getStageName();
        return n == null || n.isBlank() ? new Name(en, sw) : new Name(n.trim(), n.trim());
    }
}
