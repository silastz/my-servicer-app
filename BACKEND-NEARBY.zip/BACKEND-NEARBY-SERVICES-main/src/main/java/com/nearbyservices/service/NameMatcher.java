package com.nearbyservices.service;

import com.nearbyservices.verification.RegisteredName;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Does the name the user typed belong to the name registered for the NIN? (docs/invitation_api_contract.md)
 * Normalize (NFKD, no accents, lowercase, letters and spaces only), then compare as SETS of words so the
 * order does not matter: every registered first / surname word must be typed, and every typed word must be
 * one of the registered words (so middle names are optional, but a wrong extra word fails).
 * Never tell the user which part failed.
 */
public final class NameMatcher {

    private NameMatcher() {
    }

    public static String normalize(String s) {
        if (s == null) return "";
        String n = Normalizer.normalize(s, Normalizer.Form.NFKD).replaceAll("\\p{M}+", "");
        n = n.toLowerCase(Locale.ROOT).replaceAll("[^a-z ]", " ").replaceAll("\\s+", " ").trim();
        return n;
    }

    private static List<String> tokens(String s) {
        String n = normalize(s);
        return n.isEmpty() ? List.of() : List.of(n.split(" "));
    }

    public static boolean matches(String typed, RegisteredName reg) {
        if (reg == null || !reg.found()) return false;
        Set<String> typedSet = new LinkedHashSet<>(tokens(typed));
        if (typedSet.size() < 2) return false; // first and last name at least
        Set<String> required = new LinkedHashSet<>();
        required.addAll(tokens(reg.firstName()));
        required.addAll(tokens(reg.surname()));
        if (required.isEmpty()) return false;
        Set<String> all = new LinkedHashSet<>(required);
        all.addAll(tokens(reg.middleName()));
        return typedSet.containsAll(required) && all.containsAll(typedSet);
    }

    /** The registered spelling, e.g. "Amina Juma Mwanga", used once the names matched. */
    public static String registeredSpelling(RegisteredName reg) {
        List<String> parts = new ArrayList<>();
        for (String p : new String[]{reg.firstName(), reg.middleName(), reg.surname()}) {
            if (p != null && !p.isBlank()) parts.add(titleCase(p.trim()));
        }
        return String.join(" ", parts);
    }

    public static String titleCase(String s) {
        StringBuilder sb = new StringBuilder();
        boolean start = true;
        for (char c : s.toLowerCase(Locale.ROOT).toCharArray()) {
            sb.append(start ? Character.toUpperCase(c) : c);
            start = c == ' ' || c == '-' || c == '\'' || c == '.';
        }
        return sb.toString().replaceAll("\\s+", " ").trim();
    }
}
