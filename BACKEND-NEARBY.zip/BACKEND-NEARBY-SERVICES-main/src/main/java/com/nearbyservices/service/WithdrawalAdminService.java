package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.PlatformEntry;
import com.nearbyservices.model.Wallet;
import com.nearbyservices.model.WalletTransaction;
import com.nearbyservices.repository.PlatformEntryRepository;
import com.nearbyservices.repository.WalletRepository;
import com.nearbyservices.repository.WalletTransactionRepository;
import com.nearbyservices.verification.AuditLog;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

/**
 * The admin side of a payout. A withdrawal (a user's, or the admin's own from the platform wallet) is booked PENDING with
 * the payout phone. The admin sends the money outside the app, then marks the line COMPLETED, or FAILED when it could not
 * be sent. FAILED gives the money back: a user gets the full amount in the wallet and the fee lines booked for it are
 * REVERSED; a platform withdrawal simply stops counting. Each line moves out of PENDING once (the row is locked).
 */
@Service
@RequiredArgsConstructor
public class WithdrawalAdminService {

    static final String PENDING = "PENDING";
    static final String COMPLETED = "COMPLETED";
    static final String FAILED = "FAILED";
    static final String REVERSED = "REVERSED";
    private static final int MAX_REASON = 300;
    private static final List<String> FEE_TYPES = List.of(
            PlatformWalletService.COLLECTION_FEE, PlatformWalletService.PAYOUT_FEE, PlatformWalletService.VAT);

    private final WalletTransactionRepository walletTransactions;
    private final WalletRepository walletRepository;
    private final PlatformEntryRepository entries;
    private final AuditLog auditLog;

    /**
     * Withdrawals, newest first. {@code status}: PENDING (default), COMPLETED, FAILED or ALL.
     * Each row: {reference, kind: USER|PLATFORM, userId?, amount, fee, netAmount, phone, status, failReason?, createdAt}.
     * "phone" is the full payout number: this is the list the admin pays from.
     */
    @Transactional(readOnly = true)
    public List<Map<String, Object>> list(String rawStatus, int limit) {
        String status = rawStatus == null || rawStatus.isBlank() ? PENDING : rawStatus.trim().toUpperCase(Locale.ROOT);
        if (!status.equals("ALL") && !status.equals(PENDING) && !status.equals(COMPLETED) && !status.equals(FAILED)) {
            throw ApiException.badRequest("INVALID_STATUS");
        }
        var page = PageRequest.of(0, Math.max(1, Math.min(limit, 200)));
        List<WalletTransaction> users = status.equals("ALL")
                ? walletTransactions.findByTypeOrderByCreatedAtDescIdDesc("WITHDRAWAL", page)
                : walletTransactions.findByTypeAndStatusOrderByCreatedAtDescIdDesc("WITHDRAWAL", status, page);
        List<PlatformEntry> platform = status.equals("ALL")
                ? entries.findByTypeOrderByCreatedAtDescIdDesc(PlatformWalletService.WITHDRAWAL, page)
                : entries.findByTypeAndStatusOrderByCreatedAtDescIdDesc(PlatformWalletService.WITHDRAWAL, status, page);

        List<Map<String, Object>> rows = new ArrayList<>();
        users.forEach(t -> rows.add(row(t)));
        platform.forEach(e -> rows.add(row(e)));
        rows.sort(Comparator.comparing((Map<String, Object> m) -> (LocalDateTime) m.get("createdAt"),
                Comparator.nullsLast(Comparator.<LocalDateTime>reverseOrder())));
        return rows.size() > page.getPageSize() ? new ArrayList<>(rows.subList(0, page.getPageSize())) : rows;
    }

    /** The payout was sent. PENDING becomes COMPLETED. Anything else is 409 INVALID_STATUS:&lt;status&gt;. */
    @Transactional
    public Map<String, Object> complete(long adminId, String ref) {
        Optional<WalletTransaction> user = walletTransactions.findWithdrawalForUpdate(ref);
        if (user.isPresent()) {
            WalletTransaction t = user.get();
            requirePending(t.getStatus());
            t.setStatus(COMPLETED);
            auditLog.record(adminId, "WITHDRAWAL_COMPLETED", ref + " user=" + t.getUserId() + " amount=" + t.getAmount());
            return row(walletTransactions.save(t));
        }
        PlatformEntry e = platformWithdrawal(ref);
        requirePending(e.getStatus());
        e.setStatus(COMPLETED);
        auditLog.record(adminId, "ADMIN_WITHDRAWAL_COMPLETED", ref + " amount=" + e.getAmount());
        return row(entries.save(e));
    }

    /**
     * The payout could not be sent. A user's withdrawal gives the whole amount back to their wallet and reverses the
     * collection fee, payout fee and VAT lines booked for it. The admin's own withdrawal just stops counting, so the
     * platform balance is back. {@code reason} is optional (up to 300 characters).
     */
    @Transactional
    public Map<String, Object> fail(long adminId, String ref, String rawReason) {
        String reason = rawReason == null ? "" : rawReason.trim();
        if (reason.length() > MAX_REASON || reason.chars().anyMatch(c -> Character.isISOControl(c) && c != '\n')) {
            throw ApiException.badRequest("INVALID_REASON");
        }
        Optional<WalletTransaction> user = walletTransactions.findWithdrawalForUpdate(ref);
        if (user.isPresent()) {
            WalletTransaction t = user.get();
            requirePending(t.getStatus());
            Wallet wallet = walletRepository.findByUserIdForUpdate(t.getUserId()).orElseThrow();
            wallet.setBalance(wallet.getBalance().add(t.getAmount()));
            walletRepository.save(wallet);
            List<PlatformEntry> fees = entries.findByReferenceAndTypeIn(ref, FEE_TYPES);
            fees.forEach(f -> f.setStatus(REVERSED));
            entries.saveAll(fees);
            t.setStatus(FAILED);
            t.setFailReason(reason.isEmpty() ? null : reason);
            auditLog.record(adminId, "WITHDRAWAL_FAILED", ref + " user=" + t.getUserId() + " refunded=" + t.getAmount());
            return row(walletTransactions.save(t));
        }
        PlatformEntry e = platformWithdrawal(ref);
        requirePending(e.getStatus());
        e.setStatus(FAILED);
        e.setFailReason(reason.isEmpty() ? null : reason);
        auditLog.record(adminId, "ADMIN_WITHDRAWAL_FAILED", ref + " amount=" + e.getAmount());
        return row(entries.save(e));
    }

    private PlatformEntry platformWithdrawal(String ref) {
        return entries.findByTypeAndReferenceForUpdate(PlatformWalletService.WITHDRAWAL, ref)
                .orElseThrow(() -> ApiException.notFound("WITHDRAWAL_NOT_FOUND"));
    }

    private static void requirePending(String status) {
        if (!PENDING.equals(status)) throw ApiException.conflict("INVALID_STATUS:" + status);
    }

    private static Map<String, Object> row(WalletTransaction t) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("reference", t.getReference());
        m.put("kind", "USER");
        m.put("userId", t.getUserId());
        m.put("amount", t.getAmount());
        m.put("fee", (t.getCollectionFee() == null ? 0L : t.getCollectionFee()) + (t.getChargeFee() == null ? 0L : t.getChargeFee()));
        m.put("netAmount", t.getNetAmount());
        m.put("phone", t.getPayoutPhone()); // null for a withdrawal made before the number was stored
        m.put("status", t.getStatus());
        if (t.getFailReason() != null) m.put("failReason", t.getFailReason());
        m.put("createdAt", t.getCreatedAt());
        return m;
    }

    private static Map<String, Object> row(PlatformEntry e) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("reference", e.getReference());
        m.put("kind", "PLATFORM");
        if (e.getAdminId() != null) m.put("adminId", e.getAdminId());
        m.put("amount", e.getAmount());
        m.put("fee", e.getFee());
        m.put("netAmount", e.getNetAmount());
        m.put("phone", e.getPayoutPhone()); // null for a withdrawal made before the number was stored
        m.put("status", e.getStatus());
        if (e.getFailReason() != null) m.put("failReason", e.getFailReason());
        m.put("createdAt", e.getCreatedAt());
        return m;
    }
}
