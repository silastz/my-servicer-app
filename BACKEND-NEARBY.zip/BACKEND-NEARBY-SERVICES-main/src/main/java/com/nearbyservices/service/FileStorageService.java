package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * Saves the pictures and videos a provider adds to a service and gives back the public path
 * (served by WebConfig under /uploads/**).
 *
 * Safety rules: the stored name is always a random UUID (the client's file name is never used),
 * the extension must be on the allow-list AND the first bytes of the file must match that kind of
 * file, so a script renamed to .jpg is refused.
 */
@Service
public class FileStorageService {

    public enum Kind { IMAGE, VIDEO }

    private static final Set<String> IMAGE_EXT = Set.of("jpg", "jpeg", "png", "webp", "heic", "heif");
    private static final Set<String> VIDEO_EXT = Set.of("mp4", "mov", "m4v", "webm", "3gp");

    /** Documents and voice notes people send in a chat (the app's picker offers exactly these). */
    private static final Set<String> CHAT_DOC_EXT = Set.of("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "rtf", "odt", "ods", "zip");
    private static final Set<String> CHAT_AUDIO_EXT = Set.of("m4a", "aac", "mp3", "wav", "ogg", "opus", "amr");
    private static final long MAX_CHAT_FILE_BYTES = 25L * 1024 * 1024;

    private static final long MAX_IMAGE_BYTES = 10L * 1024 * 1024;   // the app also limits photos to 10 MB
    private static final long MAX_VIDEO_BYTES = 100L * 1024 * 1024;

    @Value("${app.upload.dir:uploads}")
    private String uploadDir;

    /** Where ID photos, selfies and business papers live. NOT under /uploads, so they are never served to the public. */
    @Value("${app.upload.private-dir:uploads-private}")
    private String privateDir;

    private Path root;
    private Path privateRoot;

    @PostConstruct
    void init() {
        root = Paths.get(uploadDir).toAbsolutePath().normalize();
        try {
            Files.createDirectories(root.resolve("services/images"));
            Files.createDirectories(root.resolve("services/videos"));
            Files.createDirectories(root.resolve("portfolio/images"));
            Files.createDirectories(root.resolve("portfolio/videos"));
            Files.createDirectories(root.resolve("chat/images"));
            Files.createDirectories(root.resolve("chat/files"));
            Files.createDirectories(root.resolve("profile/avatars"));
            Files.createDirectories(root.resolve("profile/covers"));
            Files.createDirectories(root.resolve("profile/verified"));
            privateRoot = Paths.get(privateDir).toAbsolutePath().normalize();
            Files.createDirectories(privateRoot.resolve("verification"));
        } catch (IOException e) {
            throw new IllegalStateException("Cannot create the upload folder " + root + ": " + e.getMessage(), e);
        }
    }

    public Path getRoot() {
        return root;
    }

    /** Stores the file and returns its public path, e.g. /uploads/services/images/3f2a....jpg */
    public String store(MultipartFile file, Kind kind) {
        return storeIn(file, kind, kind == Kind.IMAGE ? "services/images" : "services/videos");
    }

    /** A photo or video in a provider's portfolio. Same checks as service media. Returns /uploads/portfolio/... */
    public String storePortfolio(MultipartFile file, Kind kind) {
        return storeIn(file, kind, kind == Kind.IMAGE ? "portfolio/images" : "portfolio/videos");
    }

    /** Deletes a portfolio file. Touches nothing outside /uploads/portfolio/, whatever the stored text says. */
    public void deletePortfolioFile(String publicPath) {
        if (publicPath == null || !publicPath.startsWith("/uploads/portfolio/")) return;
        try {
            Path target = root.resolve(publicPath.substring("/uploads/".length())).normalize();
            if (target.startsWith(root.resolve("portfolio"))) Files.deleteIfExists(target);
        } catch (IOException | RuntimeException ignored) {
            // a leftover file is not worth failing the request
        }
    }

    /** A picture sent in a chat. Same checks as service pictures. Returns /uploads/chat/images/<uuid>.<ext> */
    public String storeChatImage(MultipartFile file) {
        return storeIn(file, Kind.IMAGE, "chat/images");
    }

    /**
     * A voice note or document sent in a chat. Only the types the app offers are accepted, and the first
     * bytes must match the extension. Returns /uploads/chat/files/<uuid>.<ext>
     */
    public String storeChatFile(MultipartFile file) {
        if (file == null || file.isEmpty()) throw ApiException.badRequest("FILE_EMPTY");
        if (file.getSize() > MAX_CHAT_FILE_BYTES) throw new ApiException(HttpStatus.PAYLOAD_TOO_LARGE, "FILE_TOO_LARGE");
        String ext = extensionOf(file.getOriginalFilename());
        if (!CHAT_DOC_EXT.contains(ext) && !CHAT_AUDIO_EXT.contains(ext)) {
            throw new ApiException(HttpStatus.UNSUPPORTED_MEDIA_TYPE, "FILE_TYPE_NOT_ALLOWED");
        }
        byte[] head = new byte[16];
        int read;
        try (InputStream in = file.getInputStream()) {
            read = in.readNBytes(head, 0, head.length);
        } catch (IOException e) {
            throw ApiException.badRequest("FILE_UNREADABLE");
        }
        if (!chatFileLooksLike(head, read, ext)) {
            throw new ApiException(HttpStatus.UNSUPPORTED_MEDIA_TYPE, "FILE_TYPE_NOT_ALLOWED");
        }
        String name = UUID.randomUUID().toString().replace("-", "") + "." + ext;
        Path target = root.resolve("chat/files").resolve(name).normalize();
        if (!target.startsWith(root)) throw ApiException.badRequest("FILE_UNREADABLE");
        try (InputStream in = file.getInputStream()) {
            Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            throw new IllegalStateException("Could not save the file");
        }
        return "/uploads/chat/files/" + name;
    }

    /** Profile photo ("avatars") or cover photo ("covers"). Same checks as service pictures. */
    public String storeProfileImage(MultipartFile file, String folder) {
        if (!folder.equals("avatars") && !folder.equals("covers") && !folder.equals("verified")) throw ApiException.badRequest("INVALID_REQUEST");
        return storeIn(file, Kind.IMAGE, "profile/" + folder);
    }

    /** Deletes an old profile picture. Touches nothing outside /uploads/profile/, whatever the stored text says. */
    public void deleteProfileImage(String publicPath) {
        if (publicPath == null || !publicPath.startsWith("/uploads/profile/")) return;
        try {
            Path target = root.resolve(publicPath.substring("/uploads/".length())).normalize();
            if (target.startsWith(root.resolve("profile"))) Files.deleteIfExists(target);
        } catch (IOException | RuntimeException ignored) {
            // an old picture that cannot be deleted is not worth failing the request
        }
    }

    /** A verification paper (ID, selfie, business document). Returns a private key; only admins can read the file. */
    public String storePrivateImage(MultipartFile file) {
        return storeIn(file, Kind.IMAGE, "verification", privateRoot, "");
    }

    /** Deletes a private verification file by its key. Touches nothing outside the verification folder. */
    public void deletePrivateFile(String key) {
        try {
            Path p = privateFile(key);
            if (p != null) Files.deleteIfExists(p);
        } catch (IOException | RuntimeException ignored) {
            // a file that cannot be deleted must not stop the account deletion
        }
    }

    /** The file behind a key returned by storePrivateImage, or null when the key is not one of ours. */
    public Path privateFile(String key) {
        if (key == null || key.isBlank() || privateRoot == null) return null;
        Path p = privateRoot.resolve(key).normalize();
        return p.startsWith(privateRoot.resolve("verification")) && Files.isRegularFile(p) ? p : null;
    }

    private String storeIn(MultipartFile file, Kind kind, String relDir) {
        return storeIn(file, kind, relDir, root, "/uploads/");
    }

    private String storeIn(MultipartFile file, Kind kind, String relDir, Path base, String urlPrefix) {
        if (file == null || file.isEmpty()) {
            throw ApiException.badRequest("FILE_EMPTY");
        }
        long max = kind == Kind.IMAGE ? MAX_IMAGE_BYTES : MAX_VIDEO_BYTES;
        if (file.getSize() > max) {
            throw new ApiException(HttpStatus.PAYLOAD_TOO_LARGE, "FILE_TOO_LARGE");
        }
        String ext = extensionOf(file.getOriginalFilename());
        Set<String> allowed = kind == Kind.IMAGE ? IMAGE_EXT : VIDEO_EXT;
        if (!allowed.contains(ext)) {
            throw new ApiException(HttpStatus.UNSUPPORTED_MEDIA_TYPE, "FILE_TYPE_NOT_ALLOWED");
        }

        byte[] head = new byte[16];
        int read;
        try (InputStream in = file.getInputStream()) {
            read = in.readNBytes(head, 0, head.length);
        } catch (IOException e) {
            throw ApiException.badRequest("FILE_UNREADABLE");
        }
        if (!looksLike(head, read, ext, kind)) {
            throw new ApiException(HttpStatus.UNSUPPORTED_MEDIA_TYPE, "FILE_TYPE_NOT_ALLOWED");
        }

        String name = UUID.randomUUID().toString().replace("-", "") + "." + ext;
        Path target = base.resolve(relDir).resolve(name).normalize();
        if (!target.startsWith(base)) { // belt and braces: the name is ours, but never write outside the folder
            throw ApiException.badRequest("FILE_UNREADABLE");
        }
        try (InputStream in = file.getInputStream()) {
            Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            throw new IllegalStateException("Could not save the file");
        }
        return urlPrefix + relDir + "/" + name;
    }

    private static boolean chatFileLooksLike(byte[] b, int n, String ext) {
        if (n <= 0) return false;
        switch (ext) {
            case "pdf":
                return n >= 4 && b[0] == '%' && b[1] == 'P' && b[2] == 'D' && b[3] == 'F';
            case "docx": case "xlsx": case "pptx": case "odt": case "ods": case "zip":
                return n >= 4 && b[0] == 'P' && b[1] == 'K' && b[2] == 3 && b[3] == 4;
            case "doc": case "xls": case "ppt": // old Office files (OLE2)
                return n >= 4 && (b[0] & 0xFF) == 0xD0 && (b[1] & 0xFF) == 0xCF && (b[2] & 0xFF) == 0x11 && (b[3] & 0xFF) == 0xE0;
            case "rtf":
                return n >= 5 && b[0] == '{' && b[1] == '\\' && b[2] == 'r' && b[3] == 't' && b[4] == 'f';
            case "txt": case "csv": // plain text: no binary (NUL) bytes
                for (int i = 0; i < n; i++) if (b[i] == 0) return false;
                return true;
            case "m4a": // also what phones record AAC voice notes as
                return n >= 8 && b[4] == 'f' && b[5] == 't' && b[6] == 'y' && b[7] == 'p';
            case "aac":
                return n >= 8 && ((b[4] == 'f' && b[5] == 't' && b[6] == 'y' && b[7] == 'p')
                        || ((b[0] & 0xFF) == 0xFF && (b[1] & 0xF0) == 0xF0)
                        || (b[0] == 'A' && b[1] == 'D' && b[2] == 'I' && b[3] == 'F'));
            case "mp3":
                return n >= 3 && ((b[0] == 'I' && b[1] == 'D' && b[2] == '3')
                        || ((b[0] & 0xFF) == 0xFF && (b[1] & 0xE0) == 0xE0));
            case "wav":
                return n >= 12 && b[0] == 'R' && b[1] == 'I' && b[2] == 'F' && b[3] == 'F'
                        && b[8] == 'W' && b[9] == 'A' && b[10] == 'V' && b[11] == 'E';
            case "ogg": case "opus":
                return n >= 4 && b[0] == 'O' && b[1] == 'g' && b[2] == 'g' && b[3] == 'S';
            case "amr":
                return n >= 5 && b[0] == '#' && b[1] == '!' && b[2] == 'A' && b[3] == 'M' && b[4] == 'R';
            default:
                return false;
        }
    }

    private static String extensionOf(String filename) {
        if (filename == null) return "";
        int dot = filename.lastIndexOf('.');
        if (dot < 0 || dot == filename.length() - 1) return "";
        return filename.substring(dot + 1).toLowerCase(Locale.ROOT);
    }

    private static boolean looksLike(byte[] b, int n, String ext, Kind kind) {
        if (n < 12) return false;
        if (kind == Kind.IMAGE) {
            switch (ext) {
                case "jpg":
                case "jpeg":
                    return (b[0] & 0xFF) == 0xFF && (b[1] & 0xFF) == 0xD8 && (b[2] & 0xFF) == 0xFF;
                case "png":
                    return (b[0] & 0xFF) == 0x89 && b[1] == 'P' && b[2] == 'N' && b[3] == 'G';
                case "webp":
                    return b[0] == 'R' && b[1] == 'I' && b[2] == 'F' && b[3] == 'F'
                            && b[8] == 'W' && b[9] == 'E' && b[10] == 'B' && b[11] == 'P';
                default: // heic / heif: ISO base media file, "ftyp" at byte 4
                    return b[4] == 'f' && b[5] == 't' && b[6] == 'y' && b[7] == 'p';
            }
        }
        if (ext.equals("webm")) {
            return (b[0] & 0xFF) == 0x1A && (b[1] & 0xFF) == 0x45 && (b[2] & 0xFF) == 0xDF && (b[3] & 0xFF) == 0xA3;
        }
        // mp4 / mov / m4v / 3gp: ISO base media file, "ftyp" at byte 4 (old .mov may start with moov/free/wide/mdat)
        boolean ftyp = b[4] == 'f' && b[5] == 't' && b[6] == 'y' && b[7] == 'p';
        boolean movAtom = (b[4] == 'm' && b[5] == 'o' && b[6] == 'o' && b[7] == 'v')
                || (b[4] == 'f' && b[5] == 'r' && b[6] == 'e' && b[7] == 'e')
                || (b[4] == 'w' && b[5] == 'i' && b[6] == 'd' && b[7] == 'e')
                || (b[4] == 'm' && b[5] == 'd' && b[6] == 'a' && b[7] == 't');
        return ftyp || (ext.equals("mov") && movAtom);
    }
}
