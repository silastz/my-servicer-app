package com.nearbyservices.service;

import com.nearbyservices.dto.CreateEscrowRequest;
import com.nearbyservices.dto.EscrowTransactionResponse;
import com.nearbyservices.dto.PublicUserDto;
import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.*;
import com.nearbyservices.repository.EscrowTransactionRepository;
import com.nearbyservices.repository.ServicePostRepository;
import com.nearbyservices.repository.UserRepository;
import com.nearbyservices.repository.WalletRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class EscrowService {

    private final EscrowTransactionRepository escrowRepository;
    private final UserBlockService userBlockService;
    private final UserRepository userRepository;
    private final WalletRepository walletRepository;
    private final ServicePostRepository servicePostRepository;
    private final WalletService walletService;
    private final VerificationService verificationService;
    private final OfferService offerService;
    private final PaymentSettingsService paymentSettingsService;
    private final PlatformWalletService platformWallet;
    private final com.nearbyservices.repository.UserVerificationProfileRepository verificationProfiles;
    private final PaymentService paymentService;
    private final PushService pushService;

    /** Optional: tells the admins about a payment dispute (null in unit tests). */
    @org.springframework.beans.factory.annotation.Autowired(required = false)
    private AdminAlerts adminAlerts;
    private final FileStorageService fileStorage;
    private final AttemptLimiter limiter;
    private final com.nearbyservices.repository.ReviewRepository reviewRepository;
    private final LiveLocationService liveLocationService;

    static final String PAID = "PAID";
    static final String UNPAID = "UNPAID";
    static final String PROOF_PREFIX = "/api/escrow/payment-proof/";

    private String titleOf(EscrowTransaction tx) {
        return tx.getService() != null ? tx.getService().getTitle() : null;
    }

    /** Service title for a push text; a plain word when the booking has no service. */
    private String requestLabel(EscrowTransaction tx) {
        return requestLabel(tx, false);
    }

    private String requestLabel(EscrowTransaction tx, boolean sw) {
        String t = titleOf(tx);
        return t == null || t.isBlank() ? (sw ? "huduma" : "a service") : t;
    }

    /**
     * Gives a pocket-fund booking back to the buyer. The locked amount is released; the buyer gets
     * {@code paid - charge} (the VAT charge, payout fee inside it, never more than was paid and no collection fee),
     * and the charge goes to the platform wallet. See PROVIDER_FEES_FLOW.md: a 10,000 booking returns 8,200.
     */
    private void refundBuyer(EscrowTransaction tx) {
        refundBuyer(tx, true);
    }

    /**
     * [fromLock] true: the money sits in the buyer's escrow lock (Pocket Fund). false: it was paid through the gateway, so the
     * platform holds it and nothing is locked; the refund is credited to the buyer's Pocket Fund (they can withdraw it).
     * Same fee rules either way.
     */
    private void refundBuyer(EscrowTransaction tx, boolean fromLock) {
        Wallet w = walletService.getOrCreateWallet(tx.getBuyer());
        BigDecimal paid = tx.getAmount();
        var fees = paymentSettingsService.fees();
        var r = ProviderFeeCalculator.refund(paid.setScale(0, java.math.RoundingMode.DOWN).longValue(),
                fees.getVatPercent(), fees.getPayoutFee());
        BigDecimal refunded = paid.subtract(BigDecimal.valueOf(r.charge()));

        if (fromLock) w.setLockedEscrowBalance(w.getLockedEscrowBalance().subtract(paid));
        w.setBalance(w.getBalance().add(refunded));
        walletRepository.save(w);

        walletService.recordRefund(tx.getBuyer().getId(), refunded, titleOf(tx), tx.getTransactionRef());
        platformWallet.income(PlatformWalletService.PAYOUT_FEE, BigDecimal.valueOf(r.payoutPart()), titleOf(tx), tx.getTransactionRef());
        platformWallet.income(PlatformWalletService.VAT, BigDecimal.valueOf(r.vatPart()), titleOf(tx), tx.getTransactionRef());
    }

    /** Money released to the seller: one BOOKING line (IN) in the seller's history. */
    private void recordPayout(EscrowTransaction tx) {
        walletService.record(tx.getSeller().getId(), "BOOKING", "IN", tx.getAmount(), "COMPLETED",
                titleOf(tx), tx.getTransactionRef());
    }

    /**
     * Lock funds into Escrow via DIRECT or POCKET_FUND
     */
    // ---- Live location: both people on an active booking can follow each other on the map ----

    /** A booking is active for tracking once the provider accepted (and the buyer paid, where payment is required). */
    private boolean trackingActive(EscrowTransaction tx) {
        return (tx.getStatus() == EscrowStatus.ACCEPTED && !isUnpaid(tx)) || tx.getStatus() == EscrowStatus.FUNDED;
    }

    private EscrowTransaction partyBooking(User me, String ref) {
        EscrowTransaction tx = escrowRepository.findByTransactionRef(ref)
                .orElseThrow(() -> ApiException.notFound("BOOKING_NOT_FOUND"));
        boolean party = tx.getBuyer().getId().equals(me.getId()) || tx.getSeller().getId().equals(me.getId());
        if (!party) throw ApiException.forbidden("NOT_YOUR_BOOKING");
        return tx;
    }

    /** The caller's own position. Only while the booking is active. */
    @Transactional(readOnly = true)
    public Map<String, Object> shareLiveLocation(User me, String ref, Double lat, Double lng, Double heading) {
        EscrowTransaction tx = partyBooking(me, ref);
        if (!trackingActive(tx)) {
            liveLocationService.remove(ref, me.getId());
            throw ApiException.conflict("TRACKING_NOT_ACTIVE");
        }
        if (lat == null || lng == null || lat < -90 || lat > 90 || lng < -180 || lng > 180 || (lat == 0.0 && lng == 0.0)) {
            throw ApiException.badRequest("INVALID_LOCATION");
        }
        liveLocationService.put(ref, me.getId(), lat, lng, heading);
        return Map.of("success", true);
    }

    /** The OTHER person's last position (never the caller's own), or {active:false}. */
    @Transactional(readOnly = true)
    public Map<String, Object> otherLiveLocation(User me, String ref) {
        EscrowTransaction tx = partyBooking(me, ref);
        Map<String, Object> out = new java.util.LinkedHashMap<>();
        if (!trackingActive(tx)) {
            liveLocationService.remove(ref, tx.getBuyer().getId());
            liveLocationService.remove(ref, tx.getSeller().getId());
            out.put("active", false);
            out.put("reason", "BOOKING_NOT_ACTIVE");
            return out;
        }
        boolean iAmBuyer = tx.getBuyer().getId().equals(me.getId());
        User other = iAmBuyer ? tx.getSeller() : tx.getBuyer();
        var p = liveLocationService.fresh(ref, other.getId());
        out.put("active", p.isPresent());
        if (p.isPresent()) {
            out.put("latitude", p.get().latitude());
            out.put("longitude", p.get().longitude());
            if (p.get().heading() != null) out.put("heading", p.get().heading());
            out.put("ageSeconds", (System.currentTimeMillis() - p.get().atMillis()) / 1000);
        } else {
            out.put("reason", "NOT_SHARING");
        }
        return out;
    }

    /** The caller stops sharing. */
    @Transactional(readOnly = true)
    public Map<String, Object> stopLiveLocation(User me, String ref) {
        partyBooking(me, ref);
        liveLocationService.remove(ref, me.getId());
        return Map.of("success", true);
    }

    /** Everything a dispute or scam report needs about one booking. Admin only (see AdminBookingEvidenceController). */
    @Transactional(readOnly = true)
    public java.util.Map<String, Object> evidence(String transactionRef) {
        EscrowTransaction tx = escrowRepository.findByTransactionRef(transactionRef)
                .orElseThrow(() -> ApiException.notFound("BOOKING_NOT_FOUND"));
        java.util.Map<String, Object> m = new java.util.LinkedHashMap<>();
        m.put("transactionRef", tx.getTransactionRef());
        m.put("status", tx.getStatus());
        m.put("amount", tx.getAmount());
        m.put("paymentMethod", tx.getPaymentMethod());
        m.put("createdAt", tx.getCreatedAt());
        m.put("scheduledAt", tx.getScheduledAt());
        m.put("buyerId", tx.getBuyer().getId());
        m.put("buyerPhone", tx.getBuyer().getPhone());
        m.put("sellerId", tx.getSeller().getId());
        m.put("sellerPhone", tx.getSeller().getPhone());
        m.put("serviceMode", tx.getServiceMode());
        m.put("place", tx.getPlace());
        m.put("customerAddress", tx.getCustomerAddress());
        m.put("buyerLatitude", tx.getBuyerLatitude());
        m.put("buyerLongitude", tx.getBuyerLongitude());
        m.put("buyerLocationAccuracyM", tx.getBuyerLocationAccuracyM());
        m.put("buyerLocationCapturedAt", tx.getBuyerLocationCapturedAt());
        m.put("notes", tx.getNotes());
        m.put("paymentDisputeReason", tx.getPaymentDisputeReason());
        return m;
    }

    private static String blankToNull(String s) {
        return s == null || s.trim().isEmpty() ? null : s.trim();
    }

    /** "Area, City" from what the provider made public on the service; null when neither is set. */
    private static String placeOf(ServicePost service) {
        String area = blankToNull(service.getArea());
        String city = blankToNull(service.getCity());
        if (area != null && city != null) return area + ", " + city;
        return area != null ? area : city;
    }

    @Transactional
    public EscrowTransactionResponse initiateEscrow(User buyer, CreateEscrowRequest request) {
        if (buyer.getId().equals(request.getSellerId())) {
            throw new IllegalArgumentException("Buyer and Seller cannot be the same account");
        }

        User seller = userRepository.findById(request.getSellerId())
                .orElseThrow(() -> new IllegalArgumentException("Seller not found"));
        // No booking between two people when either one blocked the other.
        if (userBlockService.isBlockedEitherWay(buyer.getId(), seller.getId())) {
            throw com.nearbyservices.exception.ApiException.forbidden("USER_BLOCKED");
        }

        // The appointment time must be sensible: not days in the past, not years ahead.
        java.time.LocalDateTime scheduledAt = request.getScheduledAt();
        if (scheduledAt != null) {
            java.time.LocalDateTime now = java.time.LocalDateTime.now();
            if (scheduledAt.isBefore(now.minusDays(1)) || scheduledAt.isAfter(now.plusYears(2))) {
                throw ApiException.badRequest("INVALID_SCHEDULE");
            }
        }

        // The customer's position: both coordinates or none, and real ones.
        Double buyerLat = request.getBuyerLatitude();
        Double buyerLng = request.getBuyerLongitude();
        if ((buyerLat == null) != (buyerLng == null)
                || (buyerLat != null && (buyerLat < -90 || buyerLat > 90 || buyerLng < -180 || buyerLng > 180
                        || (buyerLat == 0.0 && buyerLng == 0.0)))) {
            throw ApiException.badRequest("INVALID_LOCATION");
        }
        Double accuracy = request.getBuyerAccuracyMeters();
        if (accuracy != null && (accuracy < 0 || accuracy > 100000)) accuracy = null;

        // Booking with an agreed offer: the offer must be this buyer's, AGREED, unexpired and unused.
        PriceOffer offer = null;
        if (request.getOfferId() != null) {
            offer = offerService.claimForBooking(buyer, request.getOfferId(), request.getSellerId(), request.getServiceId());
        }

        // Every booking is for one real, active service that belongs to the seller. Nothing falls back to "no service".
        Long serviceId = offer != null ? offer.getServiceId() : request.getServiceId();
        if (serviceId == null) throw ApiException.badRequest("SERVICE_REQUIRED");
        ServicePost service = servicePostRepository.findById(serviceId)
                .orElseThrow(() -> ApiException.notFound("SERVICE_NOT_FOUND"));
        // A service of someone else answers like a missing one: the caller learns nothing about it.
        if (service.getSeller() == null || !service.getSeller().getId().equals(seller.getId())) {
            throw ApiException.notFound("SERVICE_NOT_FOUND");
        }
        if (!service.isActive()) throw ApiException.conflict("SERVICE_NOT_ACTIVE");

        // The price is always the server's: the agreed offer price, else the service's tasks (below), else the
        // service's current price (sale included). The amount the app sent is never used.
        BigDecimal amount = offer != null ? offer.getAgreedAmount() : offerService.currentPrice(service);

        // Tasks: the price comes from the service's own tasks, never from the app.
        java.util.List<ServiceTask> pickedTasks = new java.util.ArrayList<>();
        if (request.getTaskIndexes() != null && !request.getTaskIndexes().isEmpty()) {
            if (service == null || service.getTasks() == null || service.getTasks().isEmpty()) {
                throw ApiException.badRequest("INVALID_TASKS");
            }
            java.util.Set<Integer> seenIdx = new java.util.TreeSet<>();
            for (Integer i : request.getTaskIndexes()) {
                if (i == null || i < 0 || i >= service.getTasks().size() || !seenIdx.add(i)) {
                    throw ApiException.badRequest("INVALID_TASKS");
                }
            }
            BigDecimal sum = BigDecimal.ZERO;
            for (Integer i : seenIdx) {
                ServiceTask t = service.getTasks().get(i);
                pickedTasks.add(new ServiceTask(t.getName(), t.getPrice()));
                sum = sum.add(t.getPrice());
            }
            // An agreed offer keeps its own price; otherwise the tasks decide.
            if (offer == null) amount = sum;
        } else if (offer == null && service != null && service.getTasks() != null && !service.getTasks().isEmpty()) {
            // A service with tasks needs at least one picked (an older app that sends none keeps working
            // only for services without tasks).
            throw ApiException.badRequest("TASK_REQUIRED");
        }
        if (amount == null || amount.signum() <= 0) throw ApiException.badRequest("INVALID_AMOUNT");

        // Photos: our own uploads or https links only, at most 5.
        java.util.List<String> photos = new java.util.ArrayList<>();
        if (request.getPhotoUrls() != null) {
            for (String p : request.getPhotoUrls()) {
                String t = p == null ? "" : p.trim();
                if (t.isEmpty()) continue;
                if (!(t.startsWith("/uploads/") || t.startsWith("https://")) || t.length() > 1000) {
                    throw ApiException.badRequest("INVALID_MEDIA_URL");
                }
                if (photos.size() >= 5) throw ApiException.badRequest("TOO_MANY_PHOTOS");
                photos.add(t);
            }
        }
        boolean asap = Boolean.TRUE.equals(request.getAsap());

        if (request.getPaymentMethod() == PaymentMethod.POCKET_FUND) {
            Wallet buyerWallet = walletService.getOrCreateWallet(buyer);
            if (buyerWallet.getBalance().compareTo(amount) < 0) {
                throw ApiException.conflict("INSUFFICIENT_BALANCE");
            }

            // Deduct available balance and hold inside lockedEscrowBalance
            buyerWallet.setBalance(buyerWallet.getBalance().subtract(amount));
            buyerWallet.setLockedEscrowBalance(buyerWallet.getLockedEscrowBalance().add(amount));
            walletRepository.save(buyerWallet);
        }

        String ref = "ESC-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        EscrowTransaction transaction = EscrowTransaction.builder()
                .transactionRef(ref)
                .buyer(buyer)
                .seller(seller)
                .service(service)
                .amount(amount)
                .paymentMethod(request.getPaymentMethod())
                .status(EscrowStatus.PENDING_ACCEPTANCE)
                // Pocket Fund is locked right now (PAID). Pay-after-accept charges nothing until the buyer pays (UNPAID).
                // OFFLINE and legacy DIRECT carry no payment status.
                .paymentStatus(request.getPaymentMethod() == PaymentMethod.POCKET_FUND ? PAID
                        : request.getPaymentMethod() == PaymentMethod.PAY_AFTER_ACCEPT ? UNPAID : null)
                .paymentPreference(normalizePreference(request.getPaymentPreference()))
                .notes(request.getNotes())
                .scheduledAt(asap ? null : scheduledAt)
                .tasks(pickedTasks)
                .photoUrls(photos)
                .asap(asap ? Boolean.TRUE : null)
                // Mode and place come from the service itself, never from the app, so they can't be faked.
                .serviceMode(service != null ? blankToNull(service.getServiceMode()) : null)
                .place(service != null ? placeOf(service) : null)
                .customerAddress(blankToNull(request.getCustomerAddress()))
                .buyerLatitude(buyerLat)
                .buyerLongitude(buyerLng)
                .buyerLocationAccuracyM(buyerLat != null ? accuracy : null)
                .buyerLocationCapturedAt(buyerLat != null ? java.time.LocalDateTime.now() : null)
                .offerId(offer != null ? offer.getId() : null)
                .listedPrice(offer != null ? offer.getListedPrice() : null)
                .discountAmount(offer != null ? offer.getListedPrice().subtract(amount).max(BigDecimal.ZERO) : null)
                .build();

        EscrowTransaction saved = escrowRepository.save(transaction);
        if (request.getPaymentMethod() == PaymentMethod.POCKET_FUND) {
            walletService.record(buyer.getId(), "BOOKING", "OUT", amount, "COMPLETED", titleOf(saved), ref);
        }
        if (offer != null) offerService.markBooked(offer, ref);
        // The provider hears about the new request at once (push goes out after the booking is saved).
        notifyUser(seller.getId(), "New service request", "Ombi jipya la huduma",
                "You have a new request for " + requestLabel(saved) + ". Open it to accept or decline.",
                "Una ombi jipya la " + requestLabel(saved, true) + ". Lifungue ulikubali au ulikatae.", saved);
        return mapToResponse(saved);
    }

    /**
     * Seller accepts booking request:
     * Status moves to ACCEPTED, and seller's private contacts are now unlocked for the buyer.
     */
    @Transactional
    public EscrowTransactionResponse acceptRequest(User seller, String transactionRef) {
        // Locked: an accept that races a cancel or reject cannot overwrite a refund with ACCEPTED.
        EscrowTransaction transaction = lockedBooking(transactionRef);
        requireSeller(transaction, seller);
        requireStatus(transaction, EscrowStatus.PENDING_ACCEPTANCE);

        transaction.setStatus(EscrowStatus.ACCEPTED);
        if (transaction.getAcceptedAt() == null) transaction.setAcceptedAt(LocalDateTime.now());
        EscrowTransaction saved = escrowRepository.save(transaction);
        notifyUser(saved.getBuyer().getId(), "Request accepted", "Ombi limekubaliwa",
                isUnpaid(saved) ? "The provider accepted your request. Pay now to confirm the booking."
                                : "The provider accepted your request.",
                isUnpaid(saved) ? "Mtoa huduma amekubali ombi lako. Lipa sasa kuthibitisha."
                                : "Mtoa huduma amekubali ombi lako.", saved);
        return mapToResponse(saved);
    }

    /**
     * Seller declines or rejects booking request:
     * Funds held in Escrow are automatically refunded to Buyer.
     */
    @Transactional
    public EscrowTransactionResponse rejectRequest(User seller, String transactionRef) {
        EscrowTransaction transaction = lockedBooking(transactionRef); // locked: two taps refund once
        requireSeller(transaction, seller);
        requireCancellable(transaction);

        // Return funds back to buyer (only when something was really paid: an UNPAID booking holds nothing)
        if (transaction.getPaymentMethod() == PaymentMethod.POCKET_FUND && !isUnpaid(transaction)) {
            refundBuyer(transaction);
        }

        transaction.setStatus(EscrowStatus.REJECTED);
        transaction.setCompletedAt(LocalDateTime.now());
        EscrowTransaction saved = escrowRepository.save(transaction);
        notifyUser(saved.getBuyer().getId(), "Request declined", "Ombi limekataliwa",
                "The provider could not take your request" + (isUnpaid(saved) ? "." : ". Your funds are returned."),
                "Mtoa huduma hakuweza kupokea ombi lako" + (isUnpaid(saved) ? "." : ". Pesa zako zimerudishwa."), saved);
        return mapToResponse(saved);
    }

    /**
     * Buyer cancels booking request before seller accepts:
     * Locked escrow funds are immediately returned to buyer's available balance.
     */
    @Transactional
    public EscrowTransactionResponse cancelRequest(User buyer, String transactionRef) {
        EscrowTransaction transaction = lockedBooking(transactionRef); // locked: two taps refund once
        requireBuyer(transaction, buyer);
        requireCancellable(transaction);

        if (transaction.getPaymentMethod() == PaymentMethod.POCKET_FUND && !isUnpaid(transaction)) {
            refundBuyer(transaction);
        }

        transaction.setStatus(EscrowStatus.CANCELLED);
        transaction.setCompletedAt(LocalDateTime.now());
        EscrowTransaction saved = escrowRepository.save(transaction);
        notifyUser(saved.getSeller().getId(), "Request cancelled", "Ombi limefutwa",
                "The customer cancelled their request for " + requestLabel(saved) + ".",
                "Mteja amefuta ombi lake la " + requestLabel(saved, true) + ".", saved);
        return mapToResponse(saved);
    }

    /**
     * Buyer Satisfied / Mark Completed:
     * Seller receives payout into their wallet ONLY when buyer explicitly confirms.
     */
    @Transactional
    public EscrowTransactionResponse releaseFundsOnBuyerSatisfied(User buyer, String transactionRef) {
        EscrowTransaction transaction = lockedBooking(transactionRef); // locked: two taps pay the seller once
        requireBuyer(transaction, buyer);
        requireStatus(transaction, EscrowStatus.ACCEPTED, EscrowStatus.FUNDED);
        if (isUnpaid(transaction)) throw ApiException.paymentRequired("PAYMENT_REQUIRED");
        if (isOffline(transaction)) return completeWithoutMoney(transaction); // paid directly: nothing is held here

        // Payout to Seller
        Wallet sellerWallet = walletService.getOrCreateWallet(transaction.getSeller());
        sellerWallet.setBalance(sellerWallet.getBalance().add(transaction.getAmount()));
        walletRepository.save(sellerWallet);
        recordPayout(transaction);

        // If Buyer used POCKET_FUND, decrease their lockedEscrowBalance
        if (transaction.getPaymentMethod() == PaymentMethod.POCKET_FUND) {
            Wallet buyerWallet = walletService.getOrCreateWallet(buyer);
            buyerWallet.setLockedEscrowBalance(buyerWallet.getLockedEscrowBalance().subtract(transaction.getAmount()));
            walletRepository.save(buyerWallet);
        }

        transaction.setStatus(EscrowStatus.COMPLETED);
        transaction.setCompletedAt(LocalDateTime.now());
        EscrowTransaction saved = escrowRepository.save(transaction);

        return mapToResponse(saved);
    }

    /**
     * Admin override: Release funds to Seller
     */
    @Transactional
    public EscrowTransactionResponse adminReleaseFunds(String transactionRef) {
        EscrowTransaction transaction = lockedBooking(transactionRef); // locked: a double click pays once
        requireNotFinalized(transaction);
        if (isUnpaid(transaction)) throw ApiException.conflict("BOOKING_NOT_PAID"); // nothing was paid, so there is nothing to release
        if (isOffline(transaction)) return completeWithoutMoney(transaction);

        Wallet sellerWallet = walletService.getOrCreateWallet(transaction.getSeller());
        sellerWallet.setBalance(sellerWallet.getBalance().add(transaction.getAmount()));
        walletRepository.save(sellerWallet);
        recordPayout(transaction);

        if (transaction.getPaymentMethod() == PaymentMethod.POCKET_FUND) {
            Wallet buyerWallet = walletService.getOrCreateWallet(transaction.getBuyer());
            buyerWallet.setLockedEscrowBalance(buyerWallet.getLockedEscrowBalance().subtract(transaction.getAmount()));
            walletRepository.save(buyerWallet);
        }

        transaction.setStatus(EscrowStatus.COMPLETED);
        transaction.setCompletedAt(LocalDateTime.now());
        return mapToResponse(escrowRepository.save(transaction));
    }

    /**
     * Admin override: Refund escrow back to Buyer
     */
    @Transactional
    public EscrowTransactionResponse adminRefundBuyer(String transactionRef) {
        EscrowTransaction transaction = lockedBooking(transactionRef); // locked: a double click refunds once
        if (transaction.getStatus() == EscrowStatus.COMPLETED || transaction.getStatus() == EscrowStatus.REFUNDED) {
            throw ApiException.conflict("INVALID_STATUS:" + transaction.getStatus());
        }

        if (transaction.getPaymentMethod() == PaymentMethod.POCKET_FUND && !isUnpaid(transaction)) {
            refundBuyer(transaction);
        } else if (paidThroughGateway(transaction)) {
            refundBuyer(transaction, false); // no gateway refund call exists: the buyer gets it back in Pocket Fund
        }

        transaction.setStatus(EscrowStatus.REFUNDED);
        transaction.setCompletedAt(LocalDateTime.now());
        return mapToResponse(escrowRepository.save(transaction));
    }

    // =====================================================================================
    // Payment flow (docs/ESCROW_PAYMENT_FLOW.md)
    //   PENDING_ACCEPTANCE -> AWAITING_PAYMENT  request-payment   (provider)
    //   AWAITING_PAYMENT   -> PAYMENT_SENT      mark-paid         (buyer, offline)
    //   PAYMENT_SENT       -> ACCEPTED + PAID   confirm-payment   (provider only)
    //   PAYMENT_SENT       -> PAYMENT_DISPUTED  payment-not-received (provider)
    //   ACCEPTED/AWAITING  -> ACCEPTED + PAID   pay               (buyer, in the app)
    // =====================================================================================

    private static final int MAX_INSTRUCTIONS = 500;
    private static final int MAX_NOTE = 500;
    private static final int MAX_REFERENCE = 100;
    private static final int MAX_REASON = 300;
    private static final int DEFAULT_DEADLINE_MINUTES = 24 * 60;
    private static final int MIN_DEADLINE_MINUTES = 5;
    private static final int MAX_DEADLINE_MINUTES = 7 * 24 * 60;

    private EscrowTransaction lockedBooking(String ref) {
        return escrowRepository.findByTransactionRefForUpdate(ref)
                .orElseThrow(() -> ApiException.notFound("BOOKING_NOT_FOUND"));
    }

    private static void requireSeller(EscrowTransaction tx, User u) {
        if (!tx.getSeller().getId().equals(u.getId())) throw ApiException.forbidden("NOT_YOUR_BOOKING");
    }

    private static void requireBuyer(EscrowTransaction tx, User u) {
        if (!tx.getBuyer().getId().equals(u.getId())) throw ApiException.forbidden("NOT_YOUR_BOOKING");
    }

    private static void requireStatus(EscrowTransaction tx, EscrowStatus... allowed) {
        for (EscrowStatus a : allowed) if (tx.getStatus() == a) return;
        throw ApiException.conflict("INVALID_STATUS:" + tx.getStatus());
    }

    /** A request the buyer or provider may still call off (see {@link #cancellable}); otherwise 409 INVALID_STATUS. */
    private static void requireCancellable(EscrowTransaction tx) {
        if (!cancellable(tx)) throw ApiException.conflict("INVALID_STATUS:" + tx.getStatus());
    }

    /** Admin release needs a booking that is not already over. */
    private static void requireNotFinalized(EscrowTransaction tx) {
        switch (tx.getStatus()) {
            case COMPLETED, REFUNDED, REJECTED, CANCELLED -> throw ApiException.conflict("INVALID_STATUS:" + tx.getStatus());
            default -> { }
        }
    }

    /** Provider asks the buyer to pay before the booking is accepted. */
    @Transactional
    public EscrowTransactionResponse requestPayment(User seller, String ref, Map<String, Object> body) {
        EscrowTransaction tx = lockedBooking(ref);
        requireSeller(tx, seller);
        requireStatus(tx, EscrowStatus.PENDING_ACCEPTANCE);
        if (PAID.equals(paymentStatusOf(tx))) throw ApiException.conflict("ALREADY_PAID");

        Map<String, Object> b = body == null ? Map.of() : body;
        String mode = b.get("mode") instanceof String m ? m.trim().toUpperCase(java.util.Locale.ROOT) : "";
        if (!mode.equals("ONLINE") && !mode.equals("OFFLINE")) throw ApiException.badRequest("INVALID_MODE");
        String instructions = text(b.get("instructions"), MAX_INSTRUCTIONS, "INVALID_INSTRUCTIONS");
        if (mode.equals("OFFLINE") && instructions.isEmpty()) throw ApiException.badRequest("INSTRUCTIONS_REQUIRED");
        int minutes = DEFAULT_DEADLINE_MINUTES;
        if (b.get("deadlineMinutes") != null) {
            if (!(b.get("deadlineMinutes") instanceof Number n) || n.doubleValue() != Math.rint(n.doubleValue())
                    || n.intValue() < MIN_DEADLINE_MINUTES || n.intValue() > MAX_DEADLINE_MINUTES) {
                throw ApiException.badRequest("INVALID_DEADLINE");
            }
            minutes = n.intValue();
        }

        tx.setStatus(EscrowStatus.AWAITING_PAYMENT);
        tx.setPaymentStatus(UNPAID);
        tx.setPaymentMode(mode);
        tx.setPaymentInstructions(instructions.isEmpty() ? null : instructions);
        tx.setPaymentDeadline(LocalDateTime.now().plusMinutes(minutes));
        tx.setPaymentReference(null);
        tx.setPaymentNote(null);
        tx.setPaymentProofUrl(null);
        tx.setPaymentDisputeReason(null);
        EscrowTransaction saved = escrowRepository.save(tx);
        notifyUser(tx.getBuyer().getId(), "Payment requested", "Unaombwa kulipa",
                "The provider asks you to pay to continue your booking.", "Mtoa huduma anakuomba ulipe ili kuendelea na ombi lako.", saved);
        return mapToResponse(saved);
    }

    /** Buyer says they paid the provider directly. The provider still has to confirm. */
    @Transactional
    public EscrowTransactionResponse markPaid(User buyer, String ref, Map<String, Object> body) {
        EscrowTransaction tx = lockedBooking(ref);
        requireBuyer(tx, buyer);
        requireStatus(tx, EscrowStatus.AWAITING_PAYMENT, EscrowStatus.PAYMENT_DISPUTED);
        if (!"OFFLINE".equals(tx.getPaymentMode())) throw ApiException.conflict("NOT_AN_OFFLINE_PAYMENT"); // online payments are made in the app
        if (tx.getStatus() == EscrowStatus.AWAITING_PAYMENT && tx.getPaymentDeadline() != null
                && LocalDateTime.now().isAfter(tx.getPaymentDeadline())) {
            throw ApiException.conflict("PAYMENT_DEADLINE_PASSED");
        }

        Map<String, Object> b = body == null ? Map.of() : body;
        String reference = text(b.get("reference"), MAX_REFERENCE, "INVALID_REFERENCE");
        String note = text(b.get("note"), MAX_NOTE, "INVALID_NOTE");
        String proof = text(b.get("proofUrl"), 300, "INVALID_PROOF");
        if (!proof.isEmpty()) {
            // Only a picture uploaded through /payment-proof, and never one already used on another booking.
            String name = proof.startsWith(PROOF_PREFIX) ? proof.substring(PROOF_PREFIX.length()) : "";
            if (!PROOF_NAME.matcher(name).matches() || fileStorage.privateFile("verification/" + name) == null
                    || escrowRepository.existsByPaymentProofUrlAndTransactionRefNot(proof, ref)) {
                throw ApiException.badRequest("INVALID_PROOF");
            }
        }

        tx.setPaymentReference(reference.isEmpty() ? null : reference);
        tx.setPaymentNote(note.isEmpty() ? null : note);
        tx.setPaymentProofUrl(proof.isEmpty() ? null : proof);
        tx.setPaymentDisputeReason(null);
        tx.setStatus(EscrowStatus.PAYMENT_SENT);
        EscrowTransaction saved = escrowRepository.save(tx);
        notifyUser(tx.getSeller().getId(), "Payment sent", "Malipo yametumwa",
                "The buyer says they paid. Check and confirm.", "Mnunuzi anasema amelipa. Kagua na uthibitishe.", saved);
        return mapToResponse(saved);
    }

    /** Provider confirms the money arrived. Only the provider can do this, never the buyer. */
    @Transactional
    public EscrowTransactionResponse confirmPayment(User seller, String ref) {
        EscrowTransaction tx = lockedBooking(ref);
        requireSeller(tx, seller);
        requireStatus(tx, EscrowStatus.PAYMENT_SENT, EscrowStatus.PAYMENT_DISPUTED);
        if (!"OFFLINE".equals(tx.getPaymentMode())) throw ApiException.conflict("NOT_AN_OFFLINE_PAYMENT");
        tx.setPaymentStatus(PAID);
        tx.setPaidAt(LocalDateTime.now());
        tx.setPaymentDisputeReason(null);
        tx.setStatus(EscrowStatus.ACCEPTED);
        if (tx.getAcceptedAt() == null) tx.setAcceptedAt(LocalDateTime.now());
        EscrowTransaction saved = escrowRepository.save(tx);
        notifyUser(tx.getBuyer().getId(), "Payment confirmed", "Malipo yamethibitishwa",
                "The provider confirmed your payment. Your booking is accepted.", "Mtoa huduma amethibitisha malipo yako. Ombi limekubaliwa.", saved);
        return mapToResponse(saved);
    }

    /** Provider says the money did not arrive. The buyer can send proof again; an admin can also decide. */
    @Transactional
    public EscrowTransactionResponse paymentNotReceived(User seller, String ref, Map<String, Object> body) {
        EscrowTransaction tx = lockedBooking(ref);
        requireSeller(tx, seller);
        requireStatus(tx, EscrowStatus.PAYMENT_SENT);
        String reason = text(body == null ? null : body.get("reason"), MAX_REASON, "INVALID_REASON");
        tx.setPaymentDisputeReason(reason.isEmpty() ? null : reason);
        tx.setStatus(EscrowStatus.PAYMENT_DISPUTED);
        EscrowTransaction saved = escrowRepository.save(tx);
        if (adminAlerts != null) adminAlerts.paymentDispute(saved);
        notifyUser(tx.getBuyer().getId(), "Payment not received", "Malipo hayajapokelewa",
                "The provider says the payment did not arrive.", "Mtoa huduma anasema malipo hayajafika.", saved);
        return mapToResponse(saved);
    }

    /**
     * Buyer pays an existing booking in the app. paymentMethod:
     *   POCKET_FUND   the amount moves from the available balance to the escrow lock, like a normal Pocket Fund booking.
     *   MOBILE_MONEY / CARD   the gateway payment for this booking (purpose BOOKING, reference = the booking ref) must already
     *                         be PAID for the full amount.
     */
    @Transactional
    public EscrowTransactionResponse pay(User buyer, String ref, Map<String, Object> body) {
        EscrowTransaction tx = lockedBooking(ref);
        requireBuyer(tx, buyer);
        if (PAID.equals(paymentStatusOf(tx))) throw ApiException.conflict("ALREADY_PAID");
        boolean awaitingOnline = tx.getStatus() == EscrowStatus.AWAITING_PAYMENT && "ONLINE".equals(tx.getPaymentMode());
        boolean acceptedUnpaid = tx.getStatus() == EscrowStatus.ACCEPTED && isUnpaid(tx);
        if (!awaitingOnline && !acceptedUnpaid) throw ApiException.conflict("NOT_PAYABLE:" + tx.getStatus());
        if (awaitingOnline && tx.getPaymentDeadline() != null && LocalDateTime.now().isAfter(tx.getPaymentDeadline())) {
            throw ApiException.conflict("PAYMENT_DEADLINE_PASSED");
        }

        String method = body != null && body.get("paymentMethod") instanceof String m ? m.trim().toUpperCase(java.util.Locale.ROOT) : "";
        switch (method) {
            case "POCKET_FUND" -> {
                Wallet w = walletService.getOrCreateWallet(buyer);
                if (w.getBalance().compareTo(tx.getAmount()) < 0) {
                    throw ApiException.conflict("INSUFFICIENT_BALANCE");
                }
                w.setBalance(w.getBalance().subtract(tx.getAmount()));
                w.setLockedEscrowBalance(w.getLockedEscrowBalance().add(tx.getAmount()));
                walletRepository.save(w);
                walletService.record(buyer.getId(), "BOOKING", "OUT", tx.getAmount(), "COMPLETED", titleOf(tx), ref);
                // From now on it behaves exactly like a Pocket Fund booking (release and refund use the locked money).
                tx.setPaymentMethod(PaymentMethod.POCKET_FUND);
            }
            case "MOBILE_MONEY", "CARD" -> {
                if (!gatewayPaidInFull(tx)) throw ApiException.paymentRequired("PAYMENT_NOT_CONFIRMED");
            }
            default -> throw ApiException.badRequest("INVALID_PAYMENT_METHOD");
        }
        markPaidOnline(tx);
        EscrowTransaction saved = escrowRepository.save(tx);
        notifyUser(tx.getSeller().getId(), "Booking paid", "Ombi limelipiwa",
                "The buyer paid. The booking is confirmed.", "Mnunuzi amelipa. Ombi limethibitishwa.", saved);
        return mapToResponse(saved);
    }

    private void markPaidOnline(EscrowTransaction tx) {
        tx.setPaymentStatus(PAID);
        tx.setPaidAt(LocalDateTime.now());
        if (tx.getStatus() == EscrowStatus.AWAITING_PAYMENT) {
            tx.setStatus(EscrowStatus.ACCEPTED);
            if (tx.getAcceptedAt() == null) tx.setAcceptedAt(LocalDateTime.now());
        }
        // The buyer chose "pay the provider directly": nothing is held, the money goes to the provider's wallet now and
        // the booking is finished. Runs once only: callers reach here just for an UNPAID booking and it turns PAID first.
        if ("DIRECT".equals(tx.getPaymentPreference()) && !isOffline(tx)) {
            Wallet sellerWallet = walletService.getOrCreateWallet(tx.getSeller());
            sellerWallet.setBalance(sellerWallet.getBalance().add(tx.getAmount()));
            walletRepository.save(sellerWallet);
            recordPayout(tx);
            if (tx.getPaymentMethod() == PaymentMethod.POCKET_FUND) { // the buyer's amount was just locked: it leaves for good
                Wallet buyerWallet = walletService.getOrCreateWallet(tx.getBuyer());
                buyerWallet.setLockedEscrowBalance(buyerWallet.getLockedEscrowBalance().subtract(tx.getAmount()));
                walletRepository.save(buyerWallet);
            }
            tx.setStatus(EscrowStatus.COMPLETED);
            tx.setCompletedAt(LocalDateTime.now());
        }
    }

    private boolean gatewayPaidInFull(EscrowTransaction tx) {
        return paymentService.paidAmount(tx.getBuyer().getId(), PaymentPurpose.BOOKING, tx.getTransactionRef())
                .filter(a -> a.compareTo(tx.getAmount()) >= 0).isPresent();
    }

    /**
     * Mobile money / card payments finish on the gateway's side, so the booking learns about them when it is next read:
     * an unpaid online booking whose BOOKING payment is PAID in full becomes PAID. No money moves here (it is already
     * with the platform), so running it twice is harmless.
     */
    private void syncGatewayPayment(EscrowTransaction tx) {
        boolean waiting = (tx.getStatus() == EscrowStatus.ACCEPTED && isUnpaid(tx))
                || (tx.getStatus() == EscrowStatus.AWAITING_PAYMENT && "ONLINE".equals(tx.getPaymentMode()));
        if (!waiting || !gatewayPaidInFull(tx)) return;
        markPaidOnline(tx);
        escrowRepository.save(tx);
        notifyUser(tx.getSeller().getId(), "Booking paid", "Ombi limelipiwa",
                "The buyer paid. The booking is confirmed.", "Mnunuzi amelipa. Ombi limethibitishwa.", tx);
    }

    /**
     * Called by PaymentDeadlineJob. A booking still AWAITING_PAYMENT after its deadline is called off (REJECTED, nothing
     * to refund because nothing was paid) and both people are told. If the buyer's online payment arrived just in time,
     * the booking is accepted instead. Safe to run twice: the booking is locked and re-checked.
     * @return true when the booking was ended
     */
    @Transactional
    public boolean expireAwaitingPayment(String ref) {
        EscrowTransaction tx = lockedBooking(ref);
        if (tx.getStatus() != EscrowStatus.AWAITING_PAYMENT || tx.getPaymentDeadline() == null
                || LocalDateTime.now().isBefore(tx.getPaymentDeadline())) return false;
        if ("ONLINE".equals(tx.getPaymentMode()) && gatewayPaidInFull(tx)) {
            markPaidOnline(tx);
            escrowRepository.save(tx);
            notifyUser(tx.getSeller().getId(), "Booking paid", "Ombi limelipiwa",
                    "The buyer paid. The booking is confirmed.", "Mnunuzi amelipa. Ombi limethibitishwa.", tx);
            return false;
        }
        tx.setStatus(EscrowStatus.REJECTED);
        tx.setCompletedAt(LocalDateTime.now());
        tx.setPaymentDisputeReason("PAYMENT_DEADLINE_PASSED");
        escrowRepository.save(tx);
        notifyUser(tx.getBuyer().getId(), "Request ended", "Ombi limeisha",
                "The payment deadline passed, so the request was cancelled.", "Muda wa kulipa umeisha, kwa hiyo ombi limefutwa.", tx);
        notifyUser(tx.getSeller().getId(), "Request ended", "Ombi limeisha",
                "The buyer did not pay in time, so the request was cancelled.", "Mnunuzi hakulipa kwa wakati, kwa hiyo ombi limefutwa.", tx);
        return true;
    }

    public List<String> refsPastPaymentDeadline() {
        return escrowRepository.findByStatusAndPaymentDeadlineBefore(EscrowStatus.AWAITING_PAYMENT, LocalDateTime.now())
                .stream().map(EscrowTransaction::getTransactionRef).toList();
    }

    // ------------------------------------------------------------------ payment proof (picture)

    private static final java.util.regex.Pattern PROOF_NAME = java.util.regex.Pattern.compile("^[a-f0-9]{32}\\.(jpg|jpeg|png|webp)$");

    /** The buyer uploads a screenshot / receipt. Only someone with an offline payment to prove can upload. Returns {url}. */
    @Transactional(readOnly = true)
    public String uploadPaymentProof(User buyer, org.springframework.web.multipart.MultipartFile file) {
        limiter.hit("escrow-proof:" + buyer.getId(), 20, 3_600_000L);
        boolean hasOfflineDue = java.util.stream.Stream.of(EscrowStatus.AWAITING_PAYMENT, EscrowStatus.PAYMENT_DISPUTED)
                .flatMap(st -> escrowRepository.findByBuyerIdAndStatus(buyer.getId(), st).stream())
                .anyMatch(t -> "OFFLINE".equals(t.getPaymentMode()));
        if (!hasOfflineDue) throw ApiException.forbidden("NO_PAYMENT_TO_PROVE");
        String key = fileStorage.storePrivateImage(file); // "verification/<name>"
        String name = key.substring(key.lastIndexOf('/') + 1);
        return PROOF_PREFIX + name;
    }

    /** The picture behind a proof URL, for that booking's buyer and provider and for admins. Everyone else: 404. */
    @Transactional(readOnly = true)
    public java.nio.file.Path paymentProofFile(User viewer, String name, boolean admin) {
        if (name == null || !PROOF_NAME.matcher(name).matches()) throw ApiException.notFound("NOT_FOUND");
        EscrowTransaction tx = escrowRepository.findFirstByPaymentProofUrl(PROOF_PREFIX + name)
                .orElseThrow(() -> ApiException.notFound("NOT_FOUND"));
        boolean party = tx.getBuyer().getId().equals(viewer.getId()) || tx.getSeller().getId().equals(viewer.getId());
        if (!party && !admin) throw ApiException.notFound("NOT_FOUND");
        java.nio.file.Path p = fileStorage.privateFile("verification/" + name);
        if (p == null) throw ApiException.notFound("NOT_FOUND");
        return p;
    }

    // ------------------------------------------------------------------ helpers

    /** Paid in the app through mobile money / card (explicitly PAID), money with the platform, not yet released. */
    private static boolean paidThroughGateway(EscrowTransaction tx) {
        return PAID.equals(tx.getPaymentStatus()) && !isOffline(tx) && tx.getPaymentMethod() != PaymentMethod.POCKET_FUND;
    }

    private static boolean isUnpaid(EscrowTransaction tx) {
        return UNPAID.equals(tx.getPaymentStatus());
    }

    private static String paymentStatusOf(EscrowTransaction tx) {
        if (tx.getPaymentStatus() != null) return tx.getPaymentStatus();
        return tx.getPaymentMethod() == PaymentMethod.POCKET_FUND ? PAID : null;
    }

    /** Paid straight to the provider: this app holds no money for it. */
    private static boolean isOffline(EscrowTransaction tx) {
        return tx.getPaymentMode() != null ? "OFFLINE".equals(tx.getPaymentMode()) : tx.getPaymentMethod() == PaymentMethod.OFFLINE;
    }

    /** A request the buyer or provider may still call off. An accepted booking can only be called off while nothing was paid. */
    private static boolean cancellable(EscrowTransaction tx) {
        return switch (tx.getStatus()) {
            case PENDING_ACCEPTANCE, AWAITING_PAYMENT, PAYMENT_DISPUTED -> true;
            case ACCEPTED -> isUnpaid(tx);
            default -> false;
        };
    }

    private EscrowTransactionResponse completeWithoutMoney(EscrowTransaction tx) {
        tx.setStatus(EscrowStatus.COMPLETED);
        tx.setCompletedAt(LocalDateTime.now());
        return mapToResponse(escrowRepository.save(tx));
    }

    private static String normalizePreference(String raw) {
        if (raw == null) return null;
        String v = raw.trim().toUpperCase(java.util.Locale.ROOT);
        return v.equals("HELD") || v.equals("DIRECT") ? v : null;
    }

    /** Trimmed text, "" when missing; refuses non-text, control characters and over-long values. */
    private static String text(Object v, int max, String errorCode) {
        if (v == null) return "";
        if (!(v instanceof String s)) throw ApiException.badRequest(errorCode);
        String t = s.trim();
        if (t.length() > max || t.chars().anyMatch(c -> Character.isISOControl(c) && c != '\n')) throw ApiException.badRequest(errorCode);
        return t;
    }

    private void notifyUser(Long userId, String titleEn, String titleSw, String bodyEn, String bodySw, EscrowTransaction tx) {
        pushService.toUser(userId, new PushService.Text(titleEn, titleSw), new PushService.Text(bodyEn, bodySw),
                Map.of("type", "booking", "id", tx.getTransactionRef()));
    }

    public List<EscrowTransactionResponse> getAllTransactionsForAdmin() {
        return escrowRepository.findAll().stream()
                .map(this::mapToResponse)
                .toList();
    }

    @Transactional
    public List<EscrowTransactionResponse> getBuyerTransactions(User buyer) {
        return escrowRepository.findByBuyerId(buyer.getId()).stream()
                .peek(this::syncGatewayPayment)
                .map(this::mapToResponse)
                .toList();
    }

    @Transactional
    public List<EscrowTransactionResponse> getSellerTransactions(User seller) {
        return escrowRepository.findBySellerId(seller.getId()).stream()
                .peek(this::syncGatewayPayment)
                .map(this::mapToResponse)
                .toList();
    }

    public EscrowTransactionResponse mapToResponse(EscrowTransaction tx) {
        PublicUserDto buyerDto = verificationService.mapToPublicDto(tx.getBuyer());
        PublicUserDto sellerDto = verificationService.mapToSellerDto(tx.getSeller());

        // Contacts are unlocked if Seller accepted the request or Escrow is already funded/completed
        // An accepted booking the buyer has not paid yet keeps the contacts locked (the server decides, not the app).
        boolean isUnlocked = (tx.getStatus() == EscrowStatus.ACCEPTED && !isUnpaid(tx))
                || tx.getStatus() == EscrowStatus.FUNDED
                || tx.getStatus() == EscrowStatus.COMPLETED
                // Accepted and paid, then disputed: the two people still need each other's contact to sort it out.
                || (tx.getStatus() == EscrowStatus.DISPUTED && tx.getAcceptedAt() != null && !isUnpaid(tx));

        // Hide My ID: providers only ever get the stage name and the normal photo (the public DTO has nothing else).
        // The Safe badge is the server's decision: Hide My ID on AND a verified NIDA (green or blue).
        User bookingBuyer = tx.getBuyer();
        buyerDto.setHideMyId(bookingBuyer.isHideMyId());
        buyerDto.setSafeBadge(bookingBuyer.isHideMyId() && bookingBuyer.getVerificationBadge() != VerificationBadge.NONE);
        // Locked = the buyer keeps Profile Locked on AND the provider has not accepted yet.
        buyerDto.setProfileLocked(bookingBuyer.isProfileLocked() && !isUnlocked);
        // Customer page facts the provider sees: member since, bookings finished, reviews written.
        buyerDto.setCreatedAt(bookingBuyer.getCreatedAt());
        buyerDto.setCompletedBookings((int) escrowRepository.countByBuyerIdAndStatus(bookingBuyer.getId(), EscrowStatus.COMPLETED));
        buyerDto.setReviewsGiven((int) reviewRepository.countByReviewerIdAndFromBuyerTrue(bookingBuyer.getId()));
        // Legal name / verified photo only while Hide My ID is OFF and the server has VERIFIED them.
        if (!bookingBuyer.isHideMyId()) {
            com.nearbyservices.model.UserVerificationProfile vp = verificationProfiles.findById(bookingBuyer.getId()).orElse(null);
            if (vp != null) {
                if ("VERIFIED".equals(vp.getNameStatus())) buyerDto.setVerifiedName(vp.getVerifiedName());
                if ("VERIFIED".equals(vp.getPhotoStatus())) buyerDto.setVerifiedPhotoUrl(vp.getPhotoUrl());
            }
        }

        ServicePost service = tx.getService();
        String sellerPhone = null;
        String sellerWhatsapp = null;
        String sellerEmail = null;
        Double lat = null;
        Double lon = null;

        java.util.Map<String, String> sellerSocials = null;
        if (isUnlocked) {
            User provider = tx.getSeller();
            // The service's own contacts first, then the provider's profile ones. An accepted booking shows the profile
            // contacts even when the profile is Locked (that lock only hides them from people with no accepted booking).
            // The account email is never a fallback: it is the login identity, so only an email added to the service is shared.
            sellerPhone = firstFilled(service != null ? service.getPhone() : null, provider.getPhone());
            sellerWhatsapp = firstFilled(service != null ? service.getWhatsappPhone() : null, provider.getSocialWhatsapp());
            sellerEmail = firstFilled(service != null ? service.getEmail() : null, null);
            if (service != null) {
                lat = service.getLatitude();
                lon = service.getLongitude();
            }
            sellerSocials = new java.util.LinkedHashMap<>();
            sellerSocials.put("whatsapp", nullToEmpty(sellerWhatsapp));
            sellerSocials.put("instagram", nullToEmpty(firstFilled(service != null ? service.getInstagramUsername() : null, provider.getSocialInstagram())));
            sellerSocials.put("facebook", nullToEmpty(firstFilled(service != null ? service.getFacebookUsername() : null, provider.getSocialFacebook())));
            sellerSocials.put("x", nullToEmpty(firstFilled(service != null ? service.getXUsername() : null, provider.getSocialX())));
            sellerSocials.put("tiktok", nullToEmpty(firstFilled(service != null ? service.getTiktokUsername() : null, provider.getSocialTiktok())));
            sellerSocials.put("youtube", nullToEmpty(firstFilled(service != null ? service.getYoutubeUsername() : null, provider.getSocialYoutube())));
        }

        String serviceImage = null;
        Integer serviceDuration = null;
        if (service != null) {
            serviceDuration = service.getDurationMinutes();
            try {
                if (service.getImageUrls() != null && !service.getImageUrls().isEmpty()) {
                    serviceImage = service.getImageUrls().get(0);
                }
            } catch (RuntimeException ignored) {
                // image list not loadable here: the app shows its plain placeholder
            }
        }

        return EscrowTransactionResponse.builder()
                .id(tx.getId())
                .transactionRef(tx.getTransactionRef())
                .buyer(buyerDto)
                .seller(sellerDto)
                .serviceId(service != null ? service.getId() : null)
                .serviceTitle(service != null ? service.getTitle() : null)
                .service(service != null ? java.util.Map.of("id", service.getId(), "title", service.getTitle()) : null)
                .amount(tx.getAmount())
                .paymentMethod(tx.getPaymentMethod())
                .status(tx.getStatus())
                .notes(tx.getNotes())
                .customerNote(tx.getNotes())
                .scheduledAt(tx.getScheduledAt())
                .serviceMode(tx.getServiceMode())
                .place(tx.getPlace())
                .address(tx.getPlace())
                .customerAddress(isUnlocked ? tx.getCustomerAddress() : null)
                .serviceImage(serviceImage)
                .durationMinutes(serviceDuration)
                .offerId(tx.getOfferId())
                .listedPrice(tx.getListedPrice())
                .agreedAmount(tx.getOfferId() != null ? tx.getAmount() : null)
                .discountAmount(tx.getDiscountAmount())
                .paymentStatus(tx.getPaymentStatus() != null ? tx.getPaymentStatus()
                        : tx.getPaymentMethod() == PaymentMethod.POCKET_FUND ? PAID : null)
                .paymentMode(tx.getPaymentMode())
                .paymentInstructions(tx.getPaymentInstructions())
                .paymentDeadline(tx.getPaymentDeadline())
                .paymentReference(tx.getPaymentReference())
                .paymentNote(tx.getPaymentNote())
                .paymentProofUrl(tx.getPaymentProofUrl())
                .paymentPreference(tx.getPaymentPreference())
                .tasks(tx.getTasks() == null ? java.util.List.of() : tx.getTasks().stream()
                        .map(t -> new EscrowTransactionResponse.TaskView(t.getName(), t.getPrice())).toList())
                .photoUrls(tx.getPhotoUrls() == null ? java.util.List.of() : new java.util.ArrayList<>(tx.getPhotoUrls()))
                .asap(tx.getAsap())
                .paymentDisputeReason(tx.getPaymentDisputeReason())
                .completedAt(tx.getCompletedAt())
                .createdAt(tx.getCreatedAt())
                .contactsUnlocked(isUnlocked)
                .buyerPhone(isUnlocked ? tx.getBuyer().getPhone() : null)
                .sellerPhone(sellerPhone)
                .sellerWhatsappPhone(sellerWhatsapp)
                .sellerEmail(sellerEmail)
                .sellerSocials(sellerSocials)
                .sellerLatitude(lat)
                .sellerLongitude(lon)
                .build();
    }

    /** The first text that is not empty, or null. */
    private static String firstFilled(String own, String fallback) {
        if (own != null && !own.isBlank()) return own;
        return fallback == null || fallback.isBlank() ? null : fallback;
    }

    private static String nullToEmpty(String s) {
        return s == null ? "" : s;
    }
}
