package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.OfferStatus;
import com.nearbyservices.model.PriceOffer;
import com.nearbyservices.model.ServicePost;
import com.nearbyservices.model.User;
import com.nearbyservices.repository.PriceOfferRepository;
import com.nearbyservices.repository.ServicePostRepository;
import com.nearbyservices.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Price offers. The server decides everything that matters: the seller comes from the service, the
 * price the offer is checked against is the service's current (sale) price, the seller's private
 * minimum and auto-accept price are never revealed, and an offer can be used for one booking only.
 * Deadlines are applied at the start of every call, so a status is never stale when it is read.
 */
@Service
@RequiredArgsConstructor
public class OfferService {

    private static final Set<OfferStatus> OPEN = Set.of(OfferStatus.OFFERED, OfferStatus.AGREED);
    private static final int MAX_NEW_PER_DAY = 5;
    private static final int ANSWER_HOURS = 24;
    private static final int BOOKING_HOURS = 48;
    private static final BigDecimal MIN_SHARE = new BigDecimal("0.30");
    private static final String TOO_LOW = "This price is too low for the provider. Try a higher offer.";

    private final PriceOfferRepository offerRepository;
    private final ServicePostRepository servicePostRepository;
    private final UserRepository userRepository;
    private final UserBlockService userBlockService;
    private final OfferAlerts alerts;

    // ---------------------------------------------------------------- buyer

    @Transactional
    public Map<String, Object> create(User buyer, Long serviceId, BigDecimal rawAmount, String rawMessage) {
        expireDue();
        if (serviceId == null) throw ApiException.badRequest("SERVICE_REQUIRED");
        if (rawAmount == null || rawAmount.signum() <= 0) throw ApiException.badRequest("INVALID_AMOUNT");
        BigDecimal amount = rawAmount.setScale(2, RoundingMode.HALF_UP);
        String message = rawMessage == null ? null : rawMessage.trim();
        if (message != null && message.isEmpty()) message = null;
        if (message != null && message.length() > 500) message = message.substring(0, 500);

        ServicePost post = servicePostRepository.findById(serviceId)
                .filter(ServicePost::isActive)
                .orElseThrow(() -> ApiException.notFound("SERVICE_NOT_FOUND"));
        Long sellerId = post.getSeller().getId();
        if (sellerId.equals(buyer.getId())) throw ApiException.badRequest("CANNOT_OFFER_ON_OWN_SERVICE");
        // A blocked pair never sees each other's services, so this looks exactly like a missing service.
        if (userBlockService.isBlockedEitherWay(buyer.getId(), sellerId)) throw ApiException.notFound("SERVICE_NOT_FOUND");
        if (Boolean.FALSE.equals(post.getAllowOffers())) throw ApiException.badRequest("OFFERS_NOT_ALLOWED");

        BigDecimal current = currentPrice(post);
        if (amount.compareTo(current) > 0) throw ApiException.badRequest("OFFER_ABOVE_PRICE");
        // Same message for the 30% floor and the seller's private minimum: the minimum is never revealed.
        if (amount.compareTo(current.multiply(MIN_SHARE)) < 0
                || (post.getMinOfferPrice() != null && amount.compareTo(post.getMinOfferPrice()) < 0)) {
            throw ApiException.badRequest(TOO_LOW);
        }

        // One buyer's offers run one at a time, so two taps cannot both pass the checks below.
        userRepository.findByIdForUpdate(buyer.getId()).orElseThrow(() -> ApiException.notFound("USER_NOT_FOUND"));
        Instant now = Instant.now();
        if (offerRepository.existsByBuyerIdAndServiceIdAndStatusIn(buyer.getId(), serviceId, OPEN)) {
            throw ApiException.conflict("OFFER_ALREADY_OPEN");
        }
        if (offerRepository.countByBuyerIdAndCreatedAtAfter(buyer.getId(), now.minus(1, ChronoUnit.DAYS)) >= MAX_NEW_PER_DAY) {
            throw ApiException.tooManyRequests("TOO_MANY_OFFERS");
        }

        PriceOffer offer = PriceOffer.builder()
                .buyerId(buyer.getId()).sellerId(sellerId).serviceId(serviceId)
                .listedPrice(current).amount(amount).message(message)
                .createdAt(now).updatedAt(now)
                .status(OfferStatus.OFFERED).expiresAt(now.plus(ANSWER_HOURS, ChronoUnit.HOURS))
                .build();
        // At or above the seller's private auto-accept price the deal is made at once.
        if (post.getAutoAcceptPrice() != null && amount.compareTo(post.getAutoAcceptPrice()) >= 0) {
            offer.setStatus(OfferStatus.AGREED);
            offer.setAgreedAmount(amount);
            offer.setExpiresAt(now.plus(BOOKING_HOURS, ChronoUnit.HOURS));
        }
        PriceOffer saved = offerRepository.save(offer);
        if (saved.getStatus() == OfferStatus.AGREED) alerts.autoAgreed(saved); else alerts.newOffer(saved);
        return json(List.of(saved)).get(0);
    }

    @Transactional
    public Map<String, Object> withdraw(User buyer, Long id) {
        expireDue();
        PriceOffer o = lock(id);
        if (!o.getBuyerId().equals(buyer.getId())) throw ApiException.notFound("OFFER_NOT_FOUND");
        requireOffered(o);
        o.setStatus(OfferStatus.WITHDRAWN);
        Map<String, Object> out = save(o);
        alerts.withdrawn(o);
        return out;
    }

    @Transactional
    public List<Map<String, Object>> mine(User buyer) {
        expireDue();
        return json(offerRepository.findTop100ByBuyerIdOrderByCreatedAtDesc(buyer.getId()));
    }

    // ---------------------------------------------------------------- seller

    @Transactional
    public Map<String, Object> accept(User seller, Long id) {
        expireDue();
        PriceOffer o = lock(id);
        if (!o.getSellerId().equals(seller.getId())) throw ApiException.notFound("OFFER_NOT_FOUND");
        requireOffered(o);
        // If the seller lowered the price since the offer was made, the deal never costs more than the price now.
        BigDecimal agreed = o.getAmount();
        ServicePost post = servicePostRepository.findById(o.getServiceId()).orElse(null);
        if (post != null) agreed = agreed.min(currentPrice(post));
        Instant now = Instant.now();
        o.setStatus(OfferStatus.AGREED);
        o.setAgreedAmount(agreed);
        o.setExpiresAt(now.plus(BOOKING_HOURS, ChronoUnit.HOURS));
        o.setReminderSent(false); // the booking deadline gets its own reminder
        Map<String, Object> out = save(o);
        alerts.accepted(o);
        return out;
    }

    @Transactional
    public Map<String, Object> reject(User seller, Long id, String rawReason) {
        expireDue();
        PriceOffer o = lock(id);
        if (!o.getSellerId().equals(seller.getId())) throw ApiException.notFound("OFFER_NOT_FOUND");
        requireOffered(o);
        String reason = rawReason == null ? null : rawReason.trim();
        if (reason != null && reason.isEmpty()) reason = null;
        if (reason != null && reason.length() > 300) reason = reason.substring(0, 300);
        o.setStatus(OfferStatus.REJECTED);
        o.setRejectReason(reason);
        Map<String, Object> out = save(o);
        alerts.declined(o);
        return out;
    }

    @Transactional
    public List<Map<String, Object>> incoming(User seller) {
        expireDue();
        return json(offerRepository.findTop100BySellerIdOrderByCreatedAtDesc(seller.getId()));
    }

    // ---------------------------------------------------------------- booking (called by EscrowService)

    /**
     * Locks the offer for a booking and checks it: this buyer's, for this seller and service, AGREED,
     * not expired and not used. The caller charges agreedAmount and then calls {@link #markBooked}.
     */
    @Transactional
    public PriceOffer claimForBooking(User buyer, Long offerId, Long sellerId, Long serviceId) {
        expireDue();
        PriceOffer o = offerRepository.findByIdForUpdate(offerId)
                .filter(x -> x.getBuyerId().equals(buyer.getId()))
                .orElseThrow(() -> ApiException.notFound("OFFER_NOT_FOUND"));
        if ((sellerId != null && !o.getSellerId().equals(sellerId))
                || (serviceId != null && !o.getServiceId().equals(serviceId))) {
            throw ApiException.badRequest("OFFER_MISMATCH");
        }
        if (o.getStatus() == OfferStatus.BOOKED) throw ApiException.conflict("OFFER_ALREADY_USED");
        if (o.getStatus() == OfferStatus.EXPIRED) throw ApiException.conflict("OFFER_EXPIRED");
        if (o.getStatus() != OfferStatus.AGREED || o.getAgreedAmount() == null) throw ApiException.conflict("OFFER_NOT_AGREED");
        return o;
    }

    @Transactional
    public void markBooked(PriceOffer offer, String bookingRef) {
        offer.setStatus(OfferStatus.BOOKED);
        offer.setBookingRef(bookingRef);
        offer.setUpdatedAt(Instant.now());
        offerRepository.save(offer);
    }

    // ---------------------------------------------------------------- helpers

    private void expireDue() {
        offerRepository.expireDue(OfferStatus.EXPIRED, OPEN, Instant.now());
    }

    private PriceOffer lock(Long id) {
        if (id == null) throw ApiException.notFound("OFFER_NOT_FOUND");
        return offerRepository.findByIdForUpdate(id).orElseThrow(() -> ApiException.notFound("OFFER_NOT_FOUND"));
    }

    private void requireOffered(PriceOffer o) {
        if (o.getStatus() == OfferStatus.EXPIRED) throw ApiException.conflict("OFFER_EXPIRED");
        if (o.getStatus() != OfferStatus.OFFERED) throw ApiException.conflict("OFFER_NOT_OPEN");
    }

    private Map<String, Object> save(PriceOffer o) {
        o.setUpdatedAt(Instant.now());
        return json(List.of(offerRepository.save(o))).get(0);
    }

    /** What the service costs right now: the sale price (to the nearest TSh 100, like the app) while a sale runs. */
    BigDecimal currentPrice(ServicePost p) {
        BigDecimal price = p.getPrice();
        Integer pct = p.getDiscountPercent();
        Instant until = p.getDiscountValidUntil();
        boolean running = pct != null && pct > 0 && (until == null || until.isAfter(Instant.now()));
        if (!running) return price;
        BigDecimal sale = price.multiply(BigDecimal.valueOf(100 - Math.min(pct, 90)))
                .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
        BigDecimal step = BigDecimal.valueOf(100);
        BigDecimal rounded = sale.divide(step, 0, RoundingMode.HALF_UP).multiply(step);
        return rounded.signum() > 0 && rounded.compareTo(price) < 0 ? rounded : price;
    }

    /** The JSON the app reads, built for a whole list with one lookup of users and services. */
    private List<Map<String, Object>> json(List<PriceOffer> offers) {
        Set<Long> userIds = new LinkedHashSet<>();
        Set<Long> serviceIds = new LinkedHashSet<>();
        for (PriceOffer o : offers) {
            userIds.add(o.getBuyerId());
            userIds.add(o.getSellerId());
            serviceIds.add(o.getServiceId());
        }
        Map<Long, User> users = new HashMap<>();
        for (User u : userRepository.findAllById(userIds)) users.put(u.getId(), u);
        Map<Long, String> titles = new HashMap<>();
        for (ServicePost s : servicePostRepository.findAllById(serviceIds)) titles.put(s.getId(), s.getTitle());

        return offers.stream().map(o -> {
            User buyer = users.get(o.getBuyerId());
            User seller = users.get(o.getSellerId());
            Map<String, Object> b = new LinkedHashMap<>();
            b.put("id", o.getBuyerId());
            b.put("name", buyer == null || buyer.getStageName() == null || buyer.getStageName().isBlank()
                    ? "Customer" : buyer.getStageName());
            Map<String, Object> s = new LinkedHashMap<>();
            s.put("id", o.getSellerId());
            s.put("stageName", seller == null || seller.getStageName() == null ? "" : seller.getStageName());

            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", o.getId());
            m.put("status", o.getStatus().name());
            m.put("serviceId", o.getServiceId());
            m.put("serviceTitle", titles.getOrDefault(o.getServiceId(), ""));
            m.put("listedPrice", o.getListedPrice());
            m.put("amount", o.getAmount());
            if (o.getAgreedAmount() != null) m.put("agreedAmount", o.getAgreedAmount());
            m.put("message", o.getMessage() == null ? "" : o.getMessage());
            m.put("createdAt", o.getCreatedAt());
            m.put("expiresAt", o.getExpiresAt());
            if (o.getBookingRef() != null) m.put("bookingRef", o.getBookingRef());
            m.put("buyer", b);
            m.put("seller", s);
            return m;
        }).toList();
    }
}
