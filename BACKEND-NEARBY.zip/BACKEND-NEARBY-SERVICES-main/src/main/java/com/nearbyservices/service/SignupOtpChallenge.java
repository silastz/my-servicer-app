package com.nearbyservices.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.Base64;

/**
 * Lets the server check a sign-up code WITHOUT saving anything about the sign-up.
 *
 * When the code is texted, the server also returns a "challenge": the expiry plus an HMAC (made with a secret
 * only the server has) over phone + code + expiry. The app sends the challenge back together with the code and
 * the sign-up form; the server recomputes the HMAC. The challenge does not reveal the code (nobody can try
 * the 1,000,000 codes offline without the secret), and the expiry cannot be changed without breaking it.
 */
@Component
public class SignupOtpChallenge {

    private final byte[] key;

    public SignupOtpChallenge(@Value("${security.jwt.secret:404E635266556A586E3272357538782F413F4428472B4B6250645367566B5970}") String secret) {
        this.key = secret.getBytes(StandardCharsets.UTF_8);
    }

    /** Challenge for a code that is valid until {@code expiresAt}. */
    public String issue(String phone, String otp, Instant expiresAt) {
        long exp = expiresAt.getEpochSecond();
        return exp + "." + mac(phone, otp, exp);
    }

    /** True only if the challenge was issued for exactly this phone and this code, and has not expired. */
    public boolean matches(String phone, String otp, String challenge) {
        if (phone == null || otp == null || challenge == null) return false;
        int dot = challenge.indexOf('.');
        if (dot <= 0) return false;
        long exp;
        try {
            exp = Long.parseLong(challenge.substring(0, dot));
        } catch (NumberFormatException e) {
            return false;
        }
        if (exp < Instant.now().getEpochSecond()) return false;
        byte[] expected = mac(phone, otp, exp).getBytes(StandardCharsets.UTF_8);
        byte[] given = challenge.substring(dot + 1).getBytes(StandardCharsets.UTF_8);
        return MessageDigest.isEqual(expected, given);
    }

    private String mac(String phone, String otp, long exp) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(key, "HmacSHA256"));
            byte[] out = mac.doFinal(("signup-otp|" + phone + "|" + otp + "|" + exp).getBytes(StandardCharsets.UTF_8));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(out);
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(e);
        }
    }
}
