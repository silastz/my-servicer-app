package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.User;
import com.nearbyservices.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.LinkedHashMap;
import java.util.Map;

/** The signed-in user's public profile: display name, bio, profile photo and cover photo. */
@Service
@RequiredArgsConstructor
public class ProfileService {

    private static final int STAGE_MIN = 2;
    private static final int STAGE_MAX = 40;
    private static final int BIO_MAX = 500;

    private final UserRepository userRepository;
    private final FileStorageService fileStorageService;

    /** Changes only what was sent. An empty bio clears it; an empty stageName is refused. */
    @Transactional
    public Map<String, Object> update(User me, String stageName, String bio) {
        User user = fresh(me);
        if (stageName != null) {
            String s = stageName.trim().replaceAll("\\s+", " ");
            if (s.length() < STAGE_MIN || s.length() > STAGE_MAX) throw ApiException.badRequest("INVALID_STAGE_NAME");
            user.setStageName(s);
        }
        if (bio != null) {
            String b = bio.trim();
            if (b.length() > BIO_MAX) throw ApiException.badRequest("BIO_TOO_LONG");
            user.setBio(b.isEmpty() ? null : b);
        }
        return json(userRepository.save(user));
    }

    @Transactional
    public String setAvatar(User me, MultipartFile file) {
        User user = fresh(me);
        String url = fileStorageService.storeProfileImage(file, "avatars");
        String old = user.getAvatarUrl();
        user.setAvatarUrl(url);
        userRepository.save(user);
        fileStorageService.deleteProfileImage(old);
        return url;
    }

    @Transactional
    public void removeAvatar(User me) {
        User user = fresh(me);
        String old = user.getAvatarUrl();
        user.setAvatarUrl(null);
        userRepository.save(user);
        fileStorageService.deleteProfileImage(old);
    }

    @Transactional
    public String setCover(User me, MultipartFile file) {
        User user = fresh(me);
        String url = fileStorageService.storeProfileImage(file, "covers");
        String old = user.getCoverUrl();
        user.setCoverUrl(url);
        userRepository.save(user);
        fileStorageService.deleteProfileImage(old);
        return url;
    }

    @Transactional
    public void removeCover(User me) {
        User user = fresh(me);
        String old = user.getCoverUrl();
        user.setCoverUrl(null);
        userRepository.save(user);
        fileStorageService.deleteProfileImage(old);
    }

    /** Always work on the stored row: the logged-in object is a copy from the start of the request. */
    private User fresh(User me) {
        return userRepository.findById(me.getId()).orElseThrow(() -> ApiException.notFound("USER_NOT_FOUND"));
    }

    private Map<String, Object> json(User u) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("success", true);
        m.put("stageName", u.getStageName());
        m.put("bio", u.getBio() == null ? "" : u.getBio());
        m.put("avatarUrl", u.getAvatarUrl() == null ? "" : u.getAvatarUrl());
        m.put("coverUrl", u.getCoverUrl() == null ? "" : u.getCoverUrl());
        return m;
    }
}
