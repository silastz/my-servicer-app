package com.nearbyservices.service;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Names of the fields that differ between two JSON documents (never their values). Used for the audit entry. */
final class ConfigDiff {

    private ConfigDiff() {
    }

    static List<String> changedPaths(Map<String, Object> before, Map<String, Object> after) {
        Set<String> out = new LinkedHashSet<>();
        walk("", before == null ? Map.of() : before, after == null ? Map.of() : after, out);
        return new ArrayList<>(out);
    }

    @SuppressWarnings("unchecked")
    private static void walk(String prefix, Map<String, Object> a, Map<String, Object> b, Set<String> out) {
        Set<String> keys = new LinkedHashSet<>(a.keySet());
        keys.addAll(b.keySet());
        for (String k : keys) {
            Object x = a.get(k), y = b.get(k);
            String path = prefix.isEmpty() ? k : prefix + "." + k;
            if (x instanceof Map && y instanceof Map) {
                walk(path, (Map<String, Object>) x, (Map<String, Object>) y, out);
            } else if (!java.util.Objects.equals(x, y)) {
                out.add(path);
            }
        }
    }

    /** Fits the list into the audit column (500 characters). */
    static String detail(List<String> paths) {
        if (paths.isEmpty()) return "no field changed";
        String s = String.join(", ", paths);
        return s.length() <= 480 ? s : s.substring(0, 477) + "...";
    }
}
