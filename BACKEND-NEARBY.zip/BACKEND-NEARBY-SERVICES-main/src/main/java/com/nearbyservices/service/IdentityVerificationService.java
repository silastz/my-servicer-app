package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.TrustInvitation;
import com.nearbyservices.model.User;
import com.nearbyservices.model.UserVerificationProfile;
import com.nearbyservices.model.VerificationBadge;
import com.nearbyservices.model.VerificationDocument;
import com.nearbyservices.model.VouchRequest;
import com.nearbyservices.repository.TrustInvitationRepository;
import com.nearbyservices.repository.UserRepository;
import com.nearbyservices.repository.UserVerificationProfileRepository;
import com.nearbyservices.repository.VerificationDocumentRepository;
import com.nearbyservices.repository.VouchRequestRepository;
import com.nearbyservices.verification.IdentityServiceUnavailableException;
import com.nearbyservices.verification.NinRegistry;
import com.nearbyservices.verification.RegisteredName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * The identity checks behind Profile > Verify your identity: legal name, verified photo, ID papers,
 * Verified Business, trusted invitations and vouch requests. The server decides every status; the app only shows it.
 * Contracts: docs/verified_name_api_contract.md, verified_photo_api_contract.md, verified_business_api_contract.md,
 * invitation_api_contract.md.
 *
 * Green = identity (ID front + back + selfie approved by an admin, or a trusted invitation).
 * Blue  = Verified Business on top of Green (admin approved the business papers).
 */
@Service
public class IdentityVerificationService {

    private static final Logger log = LoggerFactory.getLogger(IdentityVerificationService.class);

    private static final long HOUR = 3_600_000L;
    private static final Pattern NAME_OK = Pattern.compile("^\\p{L}[\\p{L} .'\\-]{1,59}$");
    private static final Pattern NIN_OK = Pattern.compile("^\\d{20}$");
    private static final Set<String> ID_TYPES = Set.of("id_front", "id_back", "selfie_with_id");
    private static final Set<String> BUSINESS_REQUIRED = Set.of("business_registration", "tin_certificate", "business_license");
    private static final Set<String> BUSINESS_TYPES = Set.of("business_registration", "tin_certificate", "business_license", "location_permit");
    private static final Set<String> ID_KINDS = Set.of("nida", "voter", "driving_licence", "passport");
    private static final String CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    private static final int MAX_OPEN_INVITES = 5;
    private static final int INVITE_DAYS = 14;

    private final UserRepository users;
    private final UserVerificationProfileRepository profiles;
    private final VerificationDocumentRepository documents;
    private final TrustInvitationRepository invitations;
    private final VouchRequestRepository vouches;
    private final FileStorageService files;
    private final NinRegistry registry;
    private final AttemptLimiter limiter;
    private final SecureRandom random = new SecureRandom();

    public IdentityVerificationService(UserRepository users, UserVerificationProfileRepository profiles,
                                       VerificationDocumentRepository documents, TrustInvitationRepository invitations,
                                       VouchRequestRepository vouches, FileStorageService files, NinRegistry registry,
                                       AttemptLimiter limiter) {
        this.users = users;
        this.profiles = profiles;
        this.documents = documents;
        this.invitations = invitations;
        this.vouches = vouches;
        this.files = files;
        this.registry = registry;
        this.limiter = limiter;
    }

    // ================================================================== helpers

    private UserVerificationProfile profile(Long userId) {
        return profiles.findById(userId).orElseGet(() -> profiles.save(new UserVerificationProfile(userId)));
    }

    private User lock(User principal) {
        return users.findByIdForUpdate(principal.getId()).orElseThrow(() -> ApiException.notFound("USER_NOT_FOUND"));
    }

    private static boolean verified(User u) {
        return u.getVerificationBadge() != null && u.getVerificationBadge() != VerificationBadge.NONE;
    }

    private static String phoneKey(String phone) {
        String digits = phone == null ? "" : phone.replaceAll("\\D", "");
        if (digits.length() < 9 || digits.length() > 15) throw ApiException.badRequest("INVALID_PHONE");
        return digits.substring(digits.length() - 9);
    }

    private static Map<String, Object> map(Object... kv) {
        Map<String, Object> m = new LinkedHashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) if (kv[i + 1] != null) m.put(String.valueOf(kv[i]), kv[i + 1]);
        return m;
    }

    private static String maskNin(String nin) {
        return nin == null || nin.length() < 4 ? "****" : "****" + nin.substring(nin.length() - 4);
    }

    /** NIN registry answer, or null when the source is down (callers then keep things PENDING / answer 503). */
    private RegisteredName lookupOrNull(String nin) {
        try {
            return registry.lookup(nin);
        } catch (IdentityServiceUnavailableException e) {
            log.warn("Identity source unavailable: {}", e.getMessage());
            return null;
        }
    }

    // ================================================================== legal name

    @Transactional
    public Map<String, Object> getName(User principal) {
        UserVerificationProfile p = profile(principal.getId());
        boolean ok = "VERIFIED".equals(p.getNameStatus());
        return map("status", p.getNameStatus(),
                "name", ok ? p.getVerifiedName() : null,
                "reason", "REJECTED".equals(p.getNameStatus()) ? p.getNameReason() : null);
    }

    @Transactional
    public Map<String, Object> submitName(User principal, String fullName, String nidaNumber) {
        User user = lock(principal);
        UserVerificationProfile p = profile(user.getId());
        if ("VERIFIED".equals(p.getNameStatus())) throw ApiException.conflict("ALREADY_VERIFIED");

        String name = fullName == null ? "" : fullName.trim().replaceAll("\\s+", " ");
        if (!NAME_OK.matcher(name).matches()) throw ApiException.badRequest("NAME_INVALID");

        String nin = nidaNumber == null ? "" : nidaNumber.trim();
        if (!nin.isEmpty()) {
            if (!NIN_OK.matcher(nin).matches()) throw ApiException.badRequest("INVALID_NIN");
            if (users.existsByNidaNumberAndIdNot(nin, user.getId())) throw ApiException.conflict("NIN_ALREADY_USED");
        } else {
            nin = user.getNidaNumber() == null ? "" : user.getNidaNumber();
        }
        // Every attempt reveals "match yes / no", so it is limited per account and per NIN.
        limiter.hit("name:u" + user.getId(), 10, HOUR);
        if (!nin.isEmpty()) limiter.hit("name:nin" + nin, 10, HOUR);

        String status = "PENDING";
        String verifiedName = null;
        if (!nin.isEmpty()) {
            RegisteredName reg = lookupOrNull(nin);
            if (reg != null) {
                if (!reg.found()) throw ApiException.badRequest("NIN_NOT_FOUND");
                if (!NameMatcher.matches(name, reg)) {
                    log.info("Legal name check failed for user {} (NIN {})", user.getId(), maskNin(nin));
                    throw ApiException.badRequest("NAME_MISMATCH");
                }
                status = "VERIFIED";
                verifiedName = NameMatcher.registeredSpelling(reg);
            }
            user.setNidaNumber(nin);
            users.save(user);
        }
        p.setNameClaim(name);
        p.setNameStatus(status);
        p.setVerifiedName(verifiedName);
        p.setNameReason(null);
        profiles.save(p);
        log.info("Legal name for user {} is {} (NIN {})", user.getId(), status, maskNin(nin));
        return map("status", status);
    }

    // ================================================================== verified photo

    @Transactional
    public Map<String, Object> uploadPhoto(User principal, MultipartFile file) {
        UserVerificationProfile p = profile(principal.getId());
        String old = p.getPhotoUrl();
        String url = files.storeProfileImage(file, "verified");
        p.setPhotoUrl(url);
        p.setPhotoStatus("PENDING");
        p.setPhotoReason(null);
        profiles.save(p);
        files.deleteProfileImage(old); // the new photo replaces the old one (and starts again as PENDING)
        return map("status", "PENDING", "url", url);
    }

    @Transactional
    public Map<String, Object> getPhoto(User principal) {
        UserVerificationProfile p = profile(principal.getId());
        return map("status", p.getPhotoStatus(), "url", p.getPhotoUrl(),
                "reason", "REJECTED".equals(p.getPhotoStatus()) ? p.getPhotoReason() : null);
    }

    // ================================================================== documents

    @Transactional
    public Map<String, Object> uploadDocument(User principal, MultipartFile file, String rawType, String rawKind) {
        String type = rawType == null ? "" : rawType.trim().toLowerCase(Locale.ROOT);
        boolean idType = ID_TYPES.contains(type);
        if (!idType && !BUSINESS_TYPES.contains(type)) throw ApiException.badRequest("INVALID_DOCUMENT_TYPE");
        User user = lock(principal);
        UserVerificationProfile p = profile(user.getId());

        String kind = null;
        if (idType) {
            // The legal name and NIN come first (step 1), then the photos (step 2).
            if (p.getNameClaim() == null && !"VERIFIED".equals(p.getNameStatus())) throw ApiException.badRequest("NAME_REQUIRED");
            if (user.getNidaNumber() == null || user.getNidaNumber().isBlank()) throw ApiException.badRequest("NAME_REQUIRED");
            if (type.equals("id_front") || type.equals("id_back")) {
                kind = rawKind == null || rawKind.isBlank() ? "nida" : rawKind.trim().toLowerCase(Locale.ROOT);
                if (!ID_KINDS.contains(kind)) throw ApiException.badRequest("INVALID_ID_KIND");
            }
        } else {
            if (!verified(user)) throw ApiException.forbidden("IDENTITY_REQUIRED");
            if (p.getBusinessName() == null || p.getBusinessName().isBlank()) throw ApiException.badRequest("BUSINESS_NAME_REQUIRED");
            if ("VERIFIED".equals(p.getBusinessStatus())) throw ApiException.conflict("ALREADY_VERIFIED");
        }
        VerificationDocument doc = documents.findByUserIdAndType(user.getId(), type).orElseGet(VerificationDocument::new);
        if ("APPROVED".equals(doc.getStatus()) && idType) throw ApiException.conflict("DOCUMENT_LOCKED");

        String key = files.storePrivateImage(file); // old files are kept for audit
        doc.setUserId(user.getId());
        doc.setType(type);
        doc.setIdKind(kind);
        doc.setFileKey(key);
        doc.setStatus("PENDING");
        doc.setReason(null);
        doc.setReviewedAt(null);
        documents.save(doc);
        if (!idType) evaluateBusiness(user.getId());
        return map("type", type, "status", "PENDING");
    }

    @Transactional(readOnly = true)
    public List<Map<String, Object>> listDocuments(User principal) {
        List<Map<String, Object>> out = new ArrayList<>();
        for (VerificationDocument d : documents.findByUserId(principal.getId())) {
            out.add(map("type", d.getType(), "status", d.getStatus(),
                    "reason", "REJECTED".equals(d.getStatus()) ? d.getReason() : null));
        }
        return out;
    }

    // ================================================================== verified business

    @Transactional
    public Map<String, Object> getBusiness(User principal) {
        User user = lock(principal);
        UserVerificationProfile p = profile(user.getId());
        if ("VERIFIED".equals(p.getBusinessStatus()) && p.getBusinessExpiresAt() != null
                && p.getBusinessExpiresAt().isBefore(LocalDate.now())) {
            p.setBusinessStatus("EXPIRED"); // a lapsed licence stops being Verified Business, and so stops being Blue
            profiles.save(p);
            demoteBlue(user);
        }
        return map("status", p.getBusinessStatus(), "businessName", p.getBusinessName(),
                "reason", "REJECTED".equals(p.getBusinessStatus()) ? p.getBusinessReason() : null,
                "expiresAt", p.getBusinessExpiresAt() == null ? null : p.getBusinessExpiresAt().toString());
    }

    @Transactional
    public void saveBusiness(User principal, String businessName) {
        User user = lock(principal);
        if (!verified(user)) throw ApiException.forbidden("IDENTITY_REQUIRED");
        String n = businessName == null ? "" : businessName.trim().replaceAll("\\s+", " ");
        if (n.length() < 2 || n.length() > 120) throw ApiException.badRequest("BUSINESS_NAME_INVALID");
        UserVerificationProfile p = profile(user.getId());
        if ("VERIFIED".equals(p.getBusinessStatus())) throw ApiException.conflict("ALREADY_VERIFIED");
        p.setBusinessName(n);
        profiles.save(p);
        evaluateBusiness(user.getId());
    }

    /** All three required papers in (and none rejected) -> the application goes to the admin as PENDING. */
    private void evaluateBusiness(Long userId) {
        UserVerificationProfile p = profile(userId);
        String s = p.getBusinessStatus();
        if (!(s.equals("NONE") || s.equals("REJECTED") || s.equals("EXPIRED"))) return;
        if (p.getBusinessName() == null || p.getBusinessName().isBlank()) return;
        int ok = 0;
        for (VerificationDocument d : documents.findByUserId(userId)) {
            if (BUSINESS_REQUIRED.contains(d.getType()) && !"REJECTED".equals(d.getStatus())) ok++;
        }
        if (ok == BUSINESS_REQUIRED.size()) {
            p.setBusinessStatus("PENDING");
            p.setBusinessReason(null);
            profiles.save(p);
        }
    }

    private void demoteBlue(User user) {
        if (user.getVerificationBadge() == VerificationBadge.BLUE_TICK) {
            user.setVerificationBadge(VerificationBadge.GREEN_BADGE);
            users.save(user);
        }
    }

    // ================================================================== trusted invitations

    private void expireStale(Long inviterId) {
        LocalDateTime now = LocalDateTime.now();
        for (TrustInvitation i : invitations.findByInviterIdOrderByCreatedAtDesc(inviterId)) {
            if ("PENDING".equals(i.getStatus()) && i.getExpiresAt().isBefore(now)) {
                i.setStatus("EXPIRED");
                invitations.save(i);
            }
        }
    }

    @Transactional
    public Map<String, Object> createInvitation(User principal, String inviteePhone) {
        User inviter = lock(principal);
        if (!verified(inviter)) throw ApiException.forbidden("INVITER_NOT_VERIFIED");
        String key = phoneKey(inviteePhone);
        if (key.equals(phoneKey(inviter.getPhone()))) throw ApiException.badRequest("SELF_INVITE");
        for (User u : users.findByPhoneEndingWith(key)) {
            if (verified(u)) throw ApiException.conflict("ALREADY_VERIFIED");
        }
        expireStale(inviter.getId());
        if (invitations.existsByInviterIdAndInviteePhoneKeyAndStatus(inviter.getId(), key, "PENDING")) {
            throw ApiException.conflict("ALREADY_INVITED");
        }
        if (invitations.countByInviterIdAndStatus(inviter.getId(), "PENDING") >= MAX_OPEN_INVITES) {
            throw ApiException.tooManyRequests("INVITE_LIMIT_REACHED");
        }
        TrustInvitation inv = new TrustInvitation();
        inv.setInviterId(inviter.getId());
        inv.setCode(newCode(inviter.getId()));
        inv.setInviteePhone(inviteePhone.replaceAll("[^0-9]", ""));
        inv.setInviteePhoneKey(key);
        inv.setExpiresAt(LocalDateTime.now().plusDays(INVITE_DAYS));
        invitations.save(inv);
        log.info("User {} vouched for a new invitee (phone ending {})", inviter.getId(), key.substring(5));
        return map("code", inv.getCode(), "status", "PENDING", "expiresAt", inv.getExpiresAt().toString());
    }

    private String newCode(Long inviterId) {
        for (int attempt = 0; attempt < 20; attempt++) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 6; i++) sb.append(CODE_CHARS.charAt(random.nextInt(CODE_CHARS.length())));
            String code = sb.toString();
            // (inviter, code) must be unique: accept looks the pair up and expects exactly one row.
            if (!invitations.existsByInviterIdAndCode(inviterId, code)) return code;
        }
        throw ApiException.unavailable("INVITE_CODE_UNAVAILABLE");
    }

    @Transactional
    public List<Map<String, Object>> listInvitations(User principal) {
        expireStale(principal.getId());
        List<Map<String, Object>> out = new ArrayList<>();
        for (TrustInvitation i : invitations.findByInviterIdOrderByCreatedAtDesc(principal.getId())) {
            String name = users.findByPhoneEndingWith(i.getInviteePhoneKey()).stream().findFirst().map(User::getStageName).orElse(null);
            out.add(map("code", i.getCode(), "status", i.getStatus(), "direction", "SENT",
                    "phone", i.getInviteePhone(), "name", name));
        }
        String myKey;
        try {
            myKey = phoneKey(principal.getPhone());
        } catch (ApiException e) {
            return out;
        }
        LocalDateTime now = LocalDateTime.now();
        for (TrustInvitation i : invitations.findByInviteePhoneKeyOrderByCreatedAtDesc(myKey)) {
            String status = i.getStatus();
            if ("PENDING".equals(status) && i.getExpiresAt().isBefore(now)) status = "EXPIRED";
            String inviterName = users.findById(i.getInviterId()).map(User::getStageName).orElse(null);
            out.add(map("code", i.getInviterId() + "-" + i.getCode(), "status", status, "direction", "RECEIVED",
                    "inviterName", inviterName));
        }
        return out;
    }

    @Transactional
    public Map<String, Object> acceptInvitation(User principal, String rawCode) {
        User user = lock(principal);
        limiter.hit("invite:u" + user.getId(), 10, HOUR);

        String c = rawCode == null ? "" : rawCode.trim().toUpperCase(Locale.ROOT);
        int dash = c.indexOf('-');
        TrustInvitation inv;
        long inviterId;
        if (dash < 1) {
            // Typed without the inviter number: the code is only valid together with MY phone number.
            String key;
            try {
                key = phoneKey(user.getPhone());
            } catch (ApiException e) {
                throw ApiException.notFound("INVITE_INVALID");
            }
            inv = invitations.findFirstByInviteePhoneKeyAndCodeAndStatus(key, c, "PENDING")
                    .orElseThrow(() -> ApiException.notFound("INVITE_INVALID"));
            inviterId = inv.getInviterId();
        } else {
            try {
                inviterId = Long.parseLong(c.substring(0, dash));
            } catch (NumberFormatException e) {
                throw ApiException.notFound("INVITE_INVALID");
            }
            inv = invitations.findByInviterIdAndCode(inviterId, c.substring(dash + 1))
                    .orElseThrow(() -> ApiException.notFound("INVITE_INVALID"));
        }
        if (!"PENDING".equals(inv.getStatus()) || inv.getExpiresAt().isBefore(LocalDateTime.now())) {
            throw ApiException.notFound("INVITE_INVALID");
        }
        User inviter = users.findById(inviterId).orElseThrow(() -> ApiException.notFound("INVITE_INVALID"));
        if (!verified(inviter)) throw ApiException.notFound("INVITE_INVALID");

        String myKey;
        try {
            myKey = phoneKey(user.getPhone());
        } catch (ApiException e) {
            throw ApiException.forbidden("INVITE_PHONE_MISMATCH");
        }
        if (!myKey.equals(inv.getInviteePhoneKey())) throw ApiException.forbidden("INVITE_PHONE_MISMATCH");

        UserVerificationProfile p = profile(user.getId());
        String nin = user.getNidaNumber();
        if (p.getNameClaim() == null || nin == null || nin.isBlank()) throw ApiException.badRequest("NAME_REQUIRED");
        limiter.hit("invite:nin" + nin, 10, HOUR);

        RegisteredName reg = lookupOrNull(nin);
        if (reg == null) throw ApiException.unavailable("IDENTITY_SERVICE_UNAVAILABLE"); // nothing saved, invitation stays PENDING
        if (!reg.found()) throw ApiException.badRequest("NIN_NOT_FOUND");
        if (!NameMatcher.matches(p.getNameClaim(), reg)) {
            log.info("Invitation identity check failed: invitation {} user {} NIN {}", inv.getId(), user.getId(), maskNin(nin));
            throw ApiException.badRequest("NAME_MISMATCH");
        }
        // Passed: identity only (Green). An invitation never gives Blue, and never takes it away.
        if (user.getVerificationBadge() == VerificationBadge.NONE) user.setVerificationBadge(VerificationBadge.GREEN_BADGE);
        user.setInvitedByUserId(inviterId);
        users.save(user);
        p.setNameStatus("VERIFIED");
        p.setVerifiedName(NameMatcher.registeredSpelling(reg));
        p.setNameReason(null);
        profiles.save(p);
        inv.setStatus("ACCEPTED");
        inv.setAcceptedBy(user.getId());
        inv.setAcceptedAt(LocalDateTime.now());
        invitations.save(inv);
        log.info("Invitation {}: user {} vouched for by {} (NIN {}) PASS", inv.getId(), user.getId(), inviterId, maskNin(nin));
        return map("status", "ACCEPTED", "verificationBadge", user.getVerificationBadge().name());
    }

    // ================================================================== vouch requests

    @Transactional
    public Map<String, Object> requestVouch(User principal, String providerPhone) {
        User me = lock(principal);
        String key = phoneKey(providerPhone);
        if (key.equals(phoneKey(me.getPhone()))) throw ApiException.badRequest("SELF_INVITE");
        limiter.hit("vouch:u" + me.getId(), 10, HOUR);
        User provider = users.findByPhoneEndingWith(key).stream().filter(IdentityVerificationService::verified).findFirst()
                .orElseThrow(() -> ApiException.badRequest("PROVIDER_NOT_VERIFIED"));
        if (vouches.existsByRequesterIdAndProviderIdAndStatus(me.getId(), provider.getId(), "PENDING")) {
            throw ApiException.conflict("REQUEST_ALREADY_SENT");
        }
        VouchRequest r = new VouchRequest();
        r.setRequesterId(me.getId());
        r.setProviderId(provider.getId());
        r.setExpiresAt(LocalDateTime.now().plusDays(INVITE_DAYS));
        vouches.save(r);
        return map("id", String.valueOf(r.getId()), "status", "PENDING");
    }

    @Transactional
    public List<Map<String, Object>> listVouchRequests(User principal) {
        LocalDateTime now = LocalDateTime.now();
        List<Map<String, Object>> out = new ArrayList<>();
        for (VouchRequest r : vouches.findByRequesterIdOrProviderIdOrderByCreatedAtDesc(principal.getId(), principal.getId())) {
            if ("PENDING".equals(r.getStatus()) && r.getExpiresAt().isBefore(now)) {
                r.setStatus("EXPIRED");
                vouches.save(r);
            }
            boolean sent = r.getRequesterId().equals(principal.getId());
            User other = users.findById(sent ? r.getProviderId() : r.getRequesterId()).orElse(null);
            // Stage name only: never the legal name, NIN or ID photos.
            out.add(map("id", String.valueOf(r.getId()), "status", r.getStatus(), "direction", sent ? "SENT" : "RECEIVED",
                    "name", other == null ? null : other.getStageName(), "phone", other == null || other.isProfileLocked() ? null : other.getPhone())); // a locked profile keeps its number private
        }
        return out;
    }

    @Transactional
    public Map<String, Object> answerVouch(User principal, String id, boolean approve) {
        User provider = lock(principal);
        long rid;
        try {
            rid = Long.parseLong(id);
        } catch (NumberFormatException e) {
            throw ApiException.notFound("REQUEST_NOT_FOUND");
        }
        VouchRequest r = vouches.findById(rid).orElseThrow(() -> ApiException.notFound("REQUEST_NOT_FOUND"));
        if (!r.getProviderId().equals(provider.getId())) throw ApiException.notFound("REQUEST_NOT_FOUND"); // only the provider named in it
        if (!"PENDING".equals(r.getStatus()) || r.getExpiresAt().isBefore(LocalDateTime.now())) {
            throw ApiException.notFound("INVITE_INVALID");
        }
        if (!approve) {
            r.setStatus("DECLINED");
            vouches.save(r);
            return map("status", "DECLINED");
        }
        User requester = users.findById(r.getRequesterId()).orElseThrow(() -> ApiException.notFound("REQUEST_NOT_FOUND"));
        // A normal invitation for the requester's phone, with the same rules, expiry and audit row.
        Map<String, Object> inv;
        try {
            inv = createInvitation(provider, requester.getPhone());
        } catch (ApiException e) {
            if (!"ALREADY_INVITED".equals(e.getMessage())) throw e;
            TrustInvitation open = invitations.findFirstByInviterIdAndInviteePhoneKeyAndStatus(
                    provider.getId(), phoneKey(requester.getPhone()), "PENDING")
                    .orElseThrow(() -> ApiException.notFound("INVITE_INVALID"));
            inv = map("code", open.getCode(), "status", "PENDING");
        }
        r.setStatus("APPROVED");
        vouches.save(r);
        return map("status", "APPROVED", "code", inv.get("code"));
    }

    // ================================================================== admin review

    @Transactional(readOnly = true)
    public List<Map<String, Object>> adminDocuments(String status) {
        List<Map<String, Object>> out = new ArrayList<>();
        for (VerificationDocument d : documents.findByStatusOrderByCreatedAtAsc(status == null ? "PENDING" : status.toUpperCase(Locale.ROOT))) {
            UserVerificationProfile p = profiles.findById(d.getUserId()).orElse(null);
            User u = users.findById(d.getUserId()).orElse(null);
            out.add(map("id", d.getId(), "userId", d.getUserId(), "stageName", u == null ? null : u.getStageName(),
                    "type", d.getType(), "idKind", d.getIdKind(), "status", d.getStatus(),
                    "claimedName", p == null ? null : p.getNameClaim(),
                    "businessName", p == null ? null : p.getBusinessName(),
                    "uploadedAt", d.getCreatedAt() == null ? null : d.getCreatedAt().toString()));
        }
        return out;
    }

    @Transactional(readOnly = true)
    public java.nio.file.Path adminDocumentFile(long docId) {
        VerificationDocument d = documents.findById(docId).orElseThrow(() -> ApiException.notFound("DOCUMENT_NOT_FOUND"));
        java.nio.file.Path p = files.privateFile(d.getFileKey());
        if (p == null) throw ApiException.notFound("DOCUMENT_NOT_FOUND");
        return p;
    }

    /** legalName: the name an admin read from the approved ID (optional; the name the user typed is used if left out). */
    @Transactional
    public Map<String, Object> reviewDocument(long docId, boolean approve, String reason, String legalName) {
        VerificationDocument d = documents.findById(docId).orElseThrow(() -> ApiException.notFound("DOCUMENT_NOT_FOUND"));
        d.setStatus(approve ? "APPROVED" : "REJECTED");
        d.setReason(approve ? null : cut(reason, 200));
        d.setReviewedAt(LocalDateTime.now());
        documents.save(d);
        if (BUSINESS_TYPES.contains(d.getType())) {
            if (!approve) {
                UserVerificationProfile p = profile(d.getUserId());
                if ("PENDING".equals(p.getBusinessStatus())) {
                    p.setBusinessStatus("REJECTED");
                    p.setBusinessReason(cut(reason, 200));
                    profiles.save(p);
                }
            }
        } else if (approve) {
            afterIdApproved(d.getUserId(), legalName);
        }
        return map("id", d.getId(), "status", d.getStatus());
    }

    private void afterIdApproved(Long userId, String legalName) {
        Map<String, VerificationDocument> byType = new LinkedHashMap<>();
        for (VerificationDocument x : documents.findByUserId(userId)) byType.put(x.getType(), x);
        VerificationDocument front = byType.get("id_front");
        boolean frontOk = front != null && "APPROVED".equals(front.getStatus());
        boolean needsBack = front != null && !"passport".equals(front.getIdKind());
        VerificationDocument back = byType.get("id_back");
        boolean backOk = !needsBack || (back != null && "APPROVED".equals(back.getStatus()));
        if (!(frontOk && backOk)) return;

        // ID front (and back) approved: the legal name follows, the selfie is not needed for it.
        UserVerificationProfile p = profile(userId);
        if (!"VERIFIED".equals(p.getNameStatus())) {
            String n = legalName != null && !legalName.isBlank() ? legalName.trim() : p.getNameClaim();
            if (n != null && NAME_OK.matcher(n.replaceAll("\\s+", " ")).matches()) {
                p.setVerifiedName(NameMatcher.titleCase(n.replaceAll("\\s+", " ")));
                p.setNameStatus("VERIFIED");
                p.setNameReason(null);
                profiles.save(p);
            }
        }
        VerificationDocument selfie = byType.get("selfie_with_id");
        if (selfie != null && "APPROVED".equals(selfie.getStatus())) {
            users.findById(userId).ifPresent(u -> {
                if (u.getVerificationBadge() == VerificationBadge.NONE) {
                    u.setVerificationBadge(VerificationBadge.GREEN_BADGE);
                    users.save(u);
                }
            });
        }
    }

    @Transactional(readOnly = true)
    public List<Map<String, Object>> adminPhotos(String status) {
        List<Map<String, Object>> out = new ArrayList<>();
        for (UserVerificationProfile p : profiles.findByPhotoStatus(status == null ? "PENDING" : status.toUpperCase(Locale.ROOT))) {
            User u = users.findById(p.getUserId()).orElse(null);
            out.add(map("userId", p.getUserId(), "stageName", u == null ? null : u.getStageName(), "url", p.getPhotoUrl(), "status", p.getPhotoStatus()));
        }
        return out;
    }

    @Transactional
    public Map<String, Object> reviewPhoto(long userId, boolean approve, String reason) {
        UserVerificationProfile p = profiles.findById(userId).orElseThrow(() -> ApiException.notFound("USER_NOT_FOUND"));
        if (p.getPhotoUrl() == null) throw ApiException.badRequest("NO_PHOTO");
        p.setPhotoStatus(approve ? "VERIFIED" : "REJECTED");
        p.setPhotoReason(approve ? null : cut(reason, 200));
        profiles.save(p);
        return map("userId", userId, "status", p.getPhotoStatus());
    }

    @Transactional(readOnly = true)
    public List<Map<String, Object>> adminBusinesses(String status) {
        List<Map<String, Object>> out = new ArrayList<>();
        for (UserVerificationProfile p : profiles.findByBusinessStatus(status == null ? "PENDING" : status.toUpperCase(Locale.ROOT))) {
            User u = users.findById(p.getUserId()).orElse(null);
            out.add(map("userId", p.getUserId(), "stageName", u == null ? null : u.getStageName(),
                    "businessName", p.getBusinessName(), "status", p.getBusinessStatus()));
        }
        return out;
    }

    /** Approve needs the date the business licence runs out; VERIFIED gives the Blue badge, anything else takes it away. */
    @Transactional
    public Map<String, Object> reviewBusiness(long userId, boolean approve, String reason, String expiresAt) {
        UserVerificationProfile p = profiles.findById(userId).orElseThrow(() -> ApiException.notFound("USER_NOT_FOUND"));
        User u = users.findById(userId).orElseThrow(() -> ApiException.notFound("USER_NOT_FOUND"));
        if (approve) {
            LocalDate exp;
            try {
                exp = LocalDate.parse(expiresAt == null ? "" : expiresAt.trim());
            } catch (RuntimeException e) {
                throw ApiException.badRequest("EXPIRY_DATE_REQUIRED");
            }
            if (!exp.isAfter(LocalDate.now())) throw ApiException.badRequest("EXPIRY_DATE_PAST");
            if (!verified(u)) throw ApiException.badRequest("IDENTITY_REQUIRED");
            p.setBusinessStatus("VERIFIED");
            p.setBusinessReason(null);
            p.setBusinessExpiresAt(exp);
            u.setVerificationBadge(VerificationBadge.BLUE_TICK);
            users.save(u);
        } else {
            p.setBusinessStatus("REJECTED");
            p.setBusinessReason(cut(reason, 200));
            demoteBlue(u);
        }
        profiles.save(p);
        return map("userId", userId, "status", p.getBusinessStatus());
    }

    private static String cut(String s, int max) {
        if (s == null) return null;
        String t = s.trim();
        return t.length() > max ? t.substring(0, max) : t;
    }

    // ================================================================== what other people may see

    /** Verified Business is shown to customers only while it is VERIFIED and the licence has not lapsed. */
    @Transactional(readOnly = true)
    public UserVerificationProfile publicProfile(Long userId) {
        return profiles.findById(userId).orElse(null);
    }

    public static boolean businessActive(UserVerificationProfile p) {
        return p != null && "VERIFIED".equals(p.getBusinessStatus())
                && (p.getBusinessExpiresAt() == null || !p.getBusinessExpiresAt().isBefore(LocalDate.now()));
    }
}
