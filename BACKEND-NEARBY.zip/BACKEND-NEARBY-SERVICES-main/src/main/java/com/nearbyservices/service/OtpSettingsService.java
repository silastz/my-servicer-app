package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.AdminSettings;
import com.nearbyservices.repository.AdminSettingsRepository;
import com.nearbyservices.verification.AuditLog;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * The admin-controlled "pending minutes" of a sent code. The app keeps a half-finished sign-up / password reset
 * for this long, so a user who closes and reopens the app can type the same phone/email and land on the code
 * screen again. The app only DISPLAYS/uses this window; the code itself is still checked (and expires) here.
 */
@Service
@RequiredArgsConstructor
public class OtpSettingsService {

    public static final int DEFAULT_PENDING_MINUTES = 4;
    public static final int MIN_PENDING_MINUTES = 1;
    /** A code is valid for 10 minutes on the server, so a longer pending window would resume a dead code. */
    public static final int MAX_PENDING_MINUTES = 10;

    private final AdminSettingsService adminSettingsService;
    private final AdminSettingsRepository adminSettingsRepository;
    private final AuditLog auditLog;

    /** Minutes in force now. An old row without a valid value falls back to the default. */
    public int pendingMinutes() {
        int m = adminSettingsService.getSettings().getOtpPendingMinutes();
        return m >= MIN_PENDING_MINUTES && m <= MAX_PENDING_MINUTES ? m : DEFAULT_PENDING_MINUTES;
    }

    @Transactional
    public int setPendingMinutes(long adminId, Integer requested) {
        if (requested == null || requested < MIN_PENDING_MINUTES || requested > MAX_PENDING_MINUTES) {
            throw ApiException.badRequest("INVALID_OTP_PENDING_MINUTES");
        }
        AdminSettings s = adminSettingsService.getSettings();
        int before = s.getOtpPendingMinutes();
        s.setOtpPendingMinutes(requested);
        adminSettingsRepository.save(s);
        auditLog.record(adminId, "OTP_PENDING_MINUTES_CHANGED", before + " -> " + requested);
        return requested;
    }
}
