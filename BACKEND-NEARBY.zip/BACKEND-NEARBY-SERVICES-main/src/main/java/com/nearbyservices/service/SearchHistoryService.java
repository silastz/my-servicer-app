package com.nearbyservices.service;

import com.nearbyservices.model.UserSearchTerm;
import com.nearbyservices.repository.UserSearchTermRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Locale;

/** Remembers the last few things a signed-in user searched for, so promo pushes can follow what they look for. */
@Service
@RequiredArgsConstructor
public class SearchHistoryService {

    private static final Logger log = LoggerFactory.getLogger(SearchHistoryService.class);
    static final int KEEP = 20;
    static final int MAX_DAYS = 30;

    private final UserSearchTermRepository repo;

    /** Never throws: a failure here must not break a search. */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void record(Long userId, String rawQuery) {
        try {
            String term = normalize(rawQuery);
            if (userId == null || term == null) return;
            UserSearchTerm row = repo.findByUserIdAndTerm(userId, term)
                    .orElseGet(() -> UserSearchTerm.builder().userId(userId).term(term).build());
            row.setSearchedAt(Instant.now());
            repo.save(row);
            List<UserSearchTerm> all = repo.findByUserIdOrderBySearchedAtDesc(userId);
            if (all.size() > KEEP) repo.deleteAll(all.subList(KEEP, all.size()));
        } catch (RuntimeException e) {
            log.warn("Search history not saved: {}", e.getClass().getSimpleName());
        }
    }

    /** Terms searched in the last 30 days, newest first. */
    @Transactional(readOnly = true)
    public List<String> recentTerms(Long userId) {
        Instant since = Instant.now().minus(MAX_DAYS, ChronoUnit.DAYS);
        return repo.findByUserIdOrderBySearchedAtDesc(userId).stream()
                .filter(t -> t.getSearchedAt().isAfter(since)).map(UserSearchTerm::getTerm).toList();
    }

    @Transactional
    public int purgeOld() {
        return repo.purgeBefore(Instant.now().minus(MAX_DAYS, ChronoUnit.DAYS));
    }

    /** Lower case, trimmed, 2-100 characters; otherwise null (not worth remembering). */
    static String normalize(String q) {
        if (q == null) return null;
        String t = q.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
        return t.length() < 2 || t.length() > 100 ? null : t;
    }
}
