package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.PortfolioItem;
import com.nearbyservices.model.Role;
import com.nearbyservices.model.User;
import com.nearbyservices.repository.PortfolioItemRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

/** A provider's own portfolio: photos and videos shown on their profile, apart from their services. */
@Service
@RequiredArgsConstructor
public class PortfolioService {

    public static final int MAX_IMAGES = 40;
    public static final int MAX_VIDEOS = 10;
    private static final int MAX_CAPTION = 140;

    private final PortfolioItemRepository items;
    private final FileStorageService files;

    @Transactional(readOnly = true)
    public List<Map<String, Object>> list(Long ownerId) {
        return items.findByOwnerIdOrderByCreatedAtDescIdDesc(ownerId).stream().map(PortfolioService::toDto).toList();
    }

    @Transactional
    public Map<String, Object> add(User owner, MultipartFile file, String caption, PortfolioItem.Type type) {
        requireProvider(owner);
        int max = type == PortfolioItem.Type.IMAGE ? MAX_IMAGES : MAX_VIDEOS;
        if (items.countByOwnerIdAndType(owner.getId(), type) >= max) {
            throw ApiException.conflict(type == PortfolioItem.Type.IMAGE ? "PORTFOLIO_PHOTO_LIMIT" : "PORTFOLIO_VIDEO_LIMIT");
        }
        String url = files.storePortfolio(file, type == PortfolioItem.Type.IMAGE
                ? FileStorageService.Kind.IMAGE : FileStorageService.Kind.VIDEO);
        PortfolioItem saved = items.save(PortfolioItem.builder()
                .ownerId(owner.getId()).type(type).url(url).caption(cleanCaption(caption)).build());
        return toDto(saved);
    }

    @Transactional
    public Map<String, Object> setCaption(User owner, Long id, String caption) {
        PortfolioItem it = items.findByIdAndOwnerId(id, owner.getId()).orElseThrow(() -> ApiException.notFound("PORTFOLIO_ITEM_NOT_FOUND"));
        it.setCaption(cleanCaption(caption));
        return toDto(items.save(it));
    }

    @Transactional
    public void delete(User owner, Long id) {
        PortfolioItem it = items.findByIdAndOwnerId(id, owner.getId()).orElseThrow(() -> ApiException.notFound("PORTFOLIO_ITEM_NOT_FOUND"));
        items.delete(it);
        files.deletePortfolioFile(it.getUrl());
    }

    /** Called when an account is deleted: removes the rows and the files. */
    @Transactional
    public void deleteAllFor(Long ownerId) {
        for (PortfolioItem it : items.findByOwnerId(ownerId)) files.deletePortfolioFile(it.getUrl());
        items.deleteByOwnerId(ownerId);
    }

    private static void requireProvider(User u) {
        if (u == null || (u.getRole() != Role.ROLE_SELLER && u.getRole() != Role.ROLE_ADMIN)) {
            throw ApiException.forbidden("PROVIDER_ONLY");
        }
    }

    private static String cleanCaption(String c) {
        if (c == null) return null;
        String t = c.trim();
        if (t.isEmpty()) return null;
        return t.length() > MAX_CAPTION ? t.substring(0, MAX_CAPTION) : t;
    }

    private static Map<String, Object> toDto(PortfolioItem i) {
        Map<String, Object> m = new java.util.LinkedHashMap<>();
        m.put("id", i.getId());
        m.put("type", i.getType().name());
        m.put("url", i.getUrl());
        m.put("caption", i.getCaption());
        m.put("createdAt", i.getCreatedAt() == null ? null : i.getCreatedAt().toString());
        return m;
    }
}
