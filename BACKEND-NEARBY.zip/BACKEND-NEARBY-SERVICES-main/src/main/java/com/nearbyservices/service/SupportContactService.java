package com.nearbyservices.service;

import com.nearbyservices.model.AdminSettings;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * The support contacts shown on the app's Help screen. What the admin saved wins; the env vars
 * (SUPPORT_PHONE / SUPPORT_WHATSAPP / SUPPORT_EMAIL) are the default until the admin saves one.
 * Clearing a contact in the admin screen returns it to the env default.
 */
@Service
@RequiredArgsConstructor
public class SupportContactService {

    private final AdminSettingsService adminSettingsService;

    @Value("${app.support.phone:}")
    private String envPhone;
    @Value("${app.support.whatsapp:}")
    private String envWhatsapp;
    @Value("${app.support.email:}")
    private String envEmail;

    private static boolean notBlank(String v) {
        return v != null && !v.isBlank();
    }

    private static String pick(String admin, String env) {
        if (notBlank(admin)) return admin.trim();
        if (notBlank(env)) return env.trim();
        return null;
    }

    private static String source(String admin, String env) {
        if (notBlank(admin)) return "admin";
        return notBlank(env) ? "env" : "none";
    }

    /** Only the contacts that are set: {phone?, whatsapp?, email?}. What the app receives. */
    public Map<String, Object> effective() {
        AdminSettings s = adminSettingsService.getSettings();
        Map<String, Object> m = new LinkedHashMap<>();
        String phone = pick(s.getSupportPhone(), envPhone);
        String whatsapp = pick(s.getSupportWhatsapp(), envWhatsapp);
        String email = pick(s.getSupportEmail(), envEmail);
        if (phone != null) m.put("phone", phone);
        if (whatsapp != null) m.put("whatsapp", whatsapp);
        if (email != null) m.put("email", email);
        return m;
    }

    /** For the admin screen: every contact (null when unset) and where it comes from ("admin", "env" or "none"). */
    public Map<String, Object> forAdmin() {
        AdminSettings s = adminSettingsService.getSettings();
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("phone", pick(s.getSupportPhone(), envPhone));
        m.put("whatsapp", pick(s.getSupportWhatsapp(), envWhatsapp));
        m.put("email", pick(s.getSupportEmail(), envEmail));
        Map<String, Object> src = new LinkedHashMap<>();
        src.put("phone", source(s.getSupportPhone(), envPhone));
        src.put("whatsapp", source(s.getSupportWhatsapp(), envWhatsapp));
        src.put("email", source(s.getSupportEmail(), envEmail));
        m.put("source", src);
        return m;
    }
}
