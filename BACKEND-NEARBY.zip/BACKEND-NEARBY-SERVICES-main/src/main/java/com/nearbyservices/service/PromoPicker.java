package com.nearbyservices.service;

import java.time.Instant;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * Chooses ONE boosted service for ONE user. No database, no Spring: only the rules, so they can be tested alone.
 *
 * Order of preference (the first difference wins):
 *   0. a service that matches something this user searched for,
 *   1. a service this user was sent fewer times (never-seen services first),
 *   2. the one sent to this user longest ago,
 *   3. the one pushed to fewer people lately (so two users in a row get different services and every paying
 *      provider is shown about equally),
 *   4. a random pick among what is still tied.
 * Never the user's own service, never a service of someone who blocked them or whom they blocked.
 * 18+ services are never candidates (the caller leaves them out).
 */
final class PromoPicker {

    private PromoPicker() {}

    record Candidate(long serviceId, long sellerId) {}

    /** What this user was already sent for one service. */
    record History(int times, Instant last) {}

    private record Rank(int searched, int times, Instant last, int recent) implements Comparable<Rank> {
        @Override
        public int compareTo(Rank o) {
            int c = Integer.compare(searched, o.searched);
            if (c != 0) return c;
            c = Integer.compare(times, o.times);
            if (c != 0) return c;
            c = last.compareTo(o.last);
            if (c != 0) return c;
            return Integer.compare(recent, o.recent);
        }
    }

    /** The service id to push to this user, or null when nothing fits. */
    static Long pick(List<Candidate> candidates, long userId, Set<Long> blockedSellerIds,
                     Set<Long> searched, Map<Long, History> history, Map<Long, Integer> recentTotals, Random random) {
        List<Candidate> best = new ArrayList<>();
        Rank bestRank = null;
        for (Candidate c : candidates) {
            if (c.sellerId() == userId || blockedSellerIds.contains(c.sellerId())) continue;
            boolean matched = searched.contains(c.serviceId());
            History h = history.get(c.serviceId());
            Rank r = new Rank(matched ? 0 : 1, h == null ? 0 : h.times(),
                    h == null || h.last() == null ? Instant.MIN : h.last(),
                    recentTotals.getOrDefault(c.serviceId(), 0));
            int cmp = bestRank == null ? -1 : r.compareTo(bestRank);
            if (cmp < 0) {
                best.clear();
                best.add(c);
                bestRank = r;
            } else if (cmp == 0) {
                best.add(c);
            }
        }
        return best.isEmpty() ? null : best.get(random.nextInt(best.size())).serviceId();
    }

    /** True from startHour (inclusive) to endHour (exclusive), by the clock of the user's own time zone. */
    static boolean inWindow(ZonedDateTime localNow, int startHour, int endHour) {
        int h = localNow.getHour();
        return startHour <= endHour ? h >= startHour && h < endHour : h >= startHour || h < endHour;
    }
}
