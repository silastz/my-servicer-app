package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.*;
import com.nearbyservices.payment.PaymentGateway;
import com.nearbyservices.repository.PaymentRepository;
import com.nearbyservices.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Money in: creates payments, follows their status and applies their effect exactly once when PAID.
 * The server, not the app, decides the amount for fixed fees and which gateway is used.
 */
@Service
@RequiredArgsConstructor
public class PaymentService {

    private static final Logger log = LoggerFactory.getLogger(PaymentService.class);
    private static final Pattern REFERENCE = Pattern.compile("^[A-Za-z0-9_.:-]{6,100}$");
    private static final Pattern PHONE = Pattern.compile("^\\+?[0-9]{9,15}$");
    private static final BigDecimal MAX_AMOUNT = new BigDecimal("50000000");

    private final PaymentRepository paymentRepository;
    private final UserRepository userRepository;
    private final AdminSettingsService adminSettingsService;
    private final ServiceFeeService serviceFeeService;
    private final WalletService walletService;
    private final List<PaymentGateway> gateways;
    private final PaymentSettingsService paymentSettingsService;
    private final BoostService boostService;
    private final PlatformWalletService platformWallet;

    /** Optional: tells the admins when a payment fails (null in unit tests). */
    @org.springframework.beans.factory.annotation.Autowired(required = false)
    private AdminAlerts adminAlerts;

    // ---------------------------------------------------------------- registration fee

    public Map<String, Object> registrationFee(User user) {
        User fresh = userRepository.findById(user.getId()).orElse(user);
        boolean paid = fresh.isRegistrationFeePaid() || fresh.getRole() == Role.ROLE_ADMIN;
        return Map.of("paid", paid, "amount", adminSettingsService.getSettings().getSellerRegistrationFee());
    }

    // ---------------------------------------------------------------- start a payment

    @Transactional
    public Payment startMobile(User user, com.nearbyservices.dto.PaymentRequest r) {
        String phone = r.getPhone() == null ? "" : r.getPhone().replaceAll("[\\s-]", "");
        if (!PHONE.matcher(phone).matches()) throw ApiException.badRequest("INVALID_PHONE");
        return start(user, r, "MOBILE", phone);
    }

    @Transactional
    public Payment startCard(User user, com.nearbyservices.dto.PaymentRequest r) {
        if (!paymentSettingsService.cardEnabled()) throw ApiException.forbidden("CARD_PAYMENTS_DISABLED");
        String phone = r.getPhone() == null ? null : r.getPhone().replaceAll("[\\s-]", "");
        if (phone != null && !phone.isEmpty() && !PHONE.matcher(phone).matches()) phone = null;
        return start(user, r, "CARD", phone);
    }

    private Payment start(User user, com.nearbyservices.dto.PaymentRequest r, String channel, String phone) {
        PaymentPurpose purpose = parsePurpose(r.getPurpose());
        String reference = r.getReference().trim();
        if (!REFERENCE.matcher(reference).matches()) throw ApiException.badRequest("INVALID_REFERENCE");
        BigDecimal amount = expectedAmount(purpose, r.getAmount());

        Payment existing = paymentRepository.findByReferenceForUpdate(reference).orElse(null);
        if (existing != null) {
            // The app retries with the same reference; that is fine for the same payment, never for another.
            boolean same = existing.getUserId().equals(user.getId()) && existing.getPurpose() == purpose
                    && existing.getChannel().equals(channel) && existing.getAmount().compareTo(amount) == 0;
            if (!same) throw ApiException.conflict("REFERENCE_IN_USE");
            return existing;
        }

        PaymentGateway gateway;
        try {
            gateway = gateway();
        } catch (ApiException notConfigured) {
            // Every payment fails until an admin fixes the gateway setting: tell them.
            if (adminAlerts != null) {
                adminAlerts.paymentGatewayError(String.valueOf(paymentSettingsService.activeGatewayId()), purpose.name(),
                        reference, notConfigured.getMessage());
            }
            throw notConfigured;
        }
        Payment p = Payment.builder()
                .reference(reference).userId(user.getId()).purpose(purpose).channel(channel)
                .amount(amount).phone(phone).gateway(gateway.id()).build();
        try {
            paymentRepository.saveAndFlush(p);
        } catch (DataIntegrityViolationException raced) {
            throw ApiException.conflict("REFERENCE_IN_USE");
        }
        try {
            if (channel.equals("MOBILE")) {
                p.setGatewayReference(gateway.requestMobile(p));
            } else {
                PaymentGateway.Checkout c = gateway.createCheckout(p, r.getDescription());
                p.setGatewayReference(c.gatewayReference());
                p.setCheckoutUrl(c.checkoutUrl());
            }
        } catch (RuntimeException failed) {
            // Never put the exception text in the alert: it can hold phone numbers or keys. A code or the class name only.
            if (adminAlerts != null) {
                adminAlerts.paymentGatewayError(gateway.id(), purpose.name(), reference,
                        failed instanceof ApiException api ? api.getMessage() : failed.getClass().getSimpleName());
            }
            throw failed;
        }
        return paymentRepository.save(p);
    }

    /** Fixed fees come from the server's settings, whatever the app sent. Other purposes use the request. */
    private BigDecimal expectedAmount(PaymentPurpose purpose, BigDecimal requested) {
        AdminSettings s = adminSettingsService.getSettings();
        return switch (purpose) {
            case SERVICE_FEE -> s.getServiceFee();
            case PROVIDER_REGISTRATION -> s.getSellerRegistrationFee();
            default -> {
                if (requested == null || requested.signum() <= 0 || requested.compareTo(MAX_AMOUNT) > 0) {
                    throw ApiException.badRequest("INVALID_AMOUNT");
                }
                BigDecimal rounded = requested.setScale(2, java.math.RoundingMode.HALF_UP);
                if (purpose == PaymentPurpose.WALLET_TOPUP) {
                    if (s.getTopUpMin() != null && s.getTopUpMin() > 0 && rounded.compareTo(BigDecimal.valueOf(s.getTopUpMin())) < 0) {
                        throw ApiException.badRequest("TOPUP_BELOW_MIN");
                    }
                    if (s.getTopUpMax() != null && s.getTopUpMax() > 0 && rounded.compareTo(BigDecimal.valueOf(s.getTopUpMax())) > 0) {
                        throw ApiException.badRequest("TOPUP_ABOVE_MAX");
                    }
                }
                yield rounded;
            }
        };
    }

    private PaymentPurpose parsePurpose(String raw) {
        try {
            return PaymentPurpose.valueOf(raw.trim().toUpperCase(Locale.ROOT));
        } catch (Exception e) {
            throw ApiException.badRequest("INVALID_PURPOSE");
        }
    }

    private PaymentGateway gateway() {
        return gateways.stream().filter(g -> g.id().equalsIgnoreCase(paymentSettingsService.activeGatewayId())).findFirst()
                .orElseThrow(() -> ApiException.unavailable("PAYMENT_GATEWAY_NOT_CONFIGURED"));
    }

    // ---------------------------------------------------------------- status

    /** Status for the payer (or an admin). Unknown reference and someone else's reference both answer 404. */
    @Transactional
    public PaymentStatus statusFor(User viewer, String reference) {
        Payment p = paymentRepository.findByReference(reference)
                .filter(x -> x.getUserId().equals(viewer.getId()) || viewer.getRole() == Role.ROLE_ADMIN)
                .orElseThrow(() -> ApiException.notFound("PAYMENT_NOT_FOUND"));
        if (p.getStatus() == PaymentStatus.PENDING) {
            try {
                PaymentGateway g = gateways.stream().filter(x -> x.id().equalsIgnoreCase(p.getGateway())).findFirst().orElse(null);
                if (g != null) {
                    var asked = g.queryStatus(p);
                    if (asked.isPresent() && asked.get() != PaymentStatus.PENDING) {
                        return applyStatus(reference, asked.get(), null).getStatus();
                    }
                }
            } catch (RuntimeException e) {
                log.warn("Gateway status query failed for {}: {}", reference, e.getMessage());
            }
        }
        return p.getStatus();
    }

    // ---------------------------------------------------------------- settle

    /**
     * Records the gateway's verdict. PAID is final; a late PAID after FAILED/CANCELLED is accepted
     * (the money did arrive). The effect of PAID is applied once, in the same transaction.
     */
    @Transactional
    public Payment applyStatus(String reference, PaymentStatus newStatus, String gatewayReference) {
        Payment p = paymentRepository.findByReferenceForUpdate(reference)
                .orElseThrow(() -> ApiException.notFound("PAYMENT_NOT_FOUND"));
        if (p.getStatus() == PaymentStatus.PAID) return p;
        if (gatewayReference != null && !gatewayReference.isBlank()) p.setGatewayReference(gatewayReference);
        PaymentStatus before = p.getStatus();
        p.setStatus(newStatus);
        if (newStatus == PaymentStatus.FAILED && before != PaymentStatus.FAILED && adminAlerts != null) {
            adminAlerts.paymentFailed(p);
        }
        if (newStatus == PaymentStatus.PAID && !p.isSettled()) {
            settle(p);
            p.setSettled(true);
        }
        return paymentRepository.save(p);
    }

    /**
     * A verified gateway event. Unlike the shared-secret webhook, this checks that the event belongs to the gateway
     * and gateway reference the payment was created with, and that a PAID event carries exactly the amount we asked for.
     * An unknown reference answers 404 on purpose: the gateway retries, which covers an event that arrives before
     * the payment's own transaction has committed.
     */
    @Transactional
    public void applyGatewayEvent(String gatewayId, String reference, String gatewayReference,
                                  PaymentStatus status, BigDecimal amount) {
        Payment p = paymentRepository.findByReference(reference)
                .orElseThrow(() -> ApiException.notFound("PAYMENT_NOT_FOUND"));
        if (!p.getGateway().equalsIgnoreCase(gatewayId)) throw ApiException.conflict("GATEWAY_MISMATCH");
        if (gatewayReference != null && p.getGatewayReference() != null && !p.getGatewayReference().isBlank()
                && !p.getGatewayReference().equals(gatewayReference)) {
            log.error("Gateway reference mismatch for {}: expected {}, got {}", reference, p.getGatewayReference(), gatewayReference);
            if (adminAlerts != null) adminAlerts.paymentMismatch(reference, "wrong gateway reference");
            throw ApiException.conflict("GATEWAY_REFERENCE_MISMATCH");
        }
        if (status == PaymentStatus.PAID && (amount == null || amount.compareTo(p.getAmount()) != 0)) {
            log.error("PAID event for {} carries amount {} but the payment is {}", reference, amount, p.getAmount());
            if (adminAlerts != null) adminAlerts.paymentMismatch(reference, "wrong amount");
            throw ApiException.conflict("AMOUNT_MISMATCH");
        }
        if (status == PaymentStatus.PENDING) return;
        applyStatus(reference, status, gatewayReference);
    }

    private void settle(Payment p) {
        switch (p.getPurpose()) {
            case SERVICE_FEE -> {
                serviceFeeService.addCredit(p.getUserId(), p.getReference());
                platformWallet.income(PlatformWalletService.SERVICE_FEE, p.getAmount(), null, p.getReference());
            }
            case PROVIDER_REGISTRATION -> {
                userRepository.findByIdForUpdate(p.getUserId()).ifPresent(u -> {
                    u.setRegistrationFeePaid(true);
                    // Paying the provider registration fee makes the user a provider on the server too,
                    // so the role survives an app restart (admins keep their role).
                    if (u.getRole() == Role.ROLE_BUYER) u.setRole(Role.ROLE_SELLER);
                    userRepository.save(u);
                });
                platformWallet.income(PlatformWalletService.REGISTRATION_FEE, p.getAmount(), null, p.getReference());
            }
            case WALLET_TOPUP -> walletService.creditFromPayment(
                    userRepository.findById(p.getUserId()).orElseThrow(), p.getAmount(), p.getReference());
            case SERVICE_BOOST -> {
                platformWallet.income(PlatformWalletService.BOOST, p.getAmount(), null, p.getReference());
                boostService.activateFromPayment(p);
            }
            // BOOKING: the booking call checks isPaid(...) with this reference.
            default -> { }
        }
    }

    /** The amount of this user's PAID payment for this purpose and reference, or empty. Used to check a booking was paid in full. */
    @Transactional(readOnly = true)
    public java.util.Optional<BigDecimal> paidAmount(Long userId, PaymentPurpose purpose, String reference) {
        return paymentRepository.findByReference(reference)
                .filter(p -> p.getUserId().equals(userId) && p.getPurpose() == purpose && p.getStatus() == PaymentStatus.PAID)
                .map(Payment::getAmount);
    }

    /** For the boost / booking parts: true only when this user's payment for this purpose is PAID. */
    @Transactional(readOnly = true)
    public boolean isPaid(Long userId, PaymentPurpose purpose, String reference) {
        return paymentRepository.findByReference(reference)
                .filter(p -> p.getUserId().equals(userId) && p.getPurpose() == purpose
                        && p.getStatus() == PaymentStatus.PAID)
                .isPresent();
    }
}
