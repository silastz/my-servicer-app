package com.nearbyservices.service;

import com.nearbyservices.exception.ApiException;
import com.nearbyservices.model.EscrowStatus;
import com.nearbyservices.model.PaymentStatus;
import com.nearbyservices.model.User;
import com.nearbyservices.model.Wallet;
import com.nearbyservices.repository.EscrowTransactionRepository;
import com.nearbyservices.repository.PaymentRepository;
import com.nearbyservices.repository.ServicePostRepository;
import com.nearbyservices.repository.UserRepository;
import com.nearbyservices.repository.WalletRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * The signed-in user's own settings: Hide My ID, country / wallet currency, and last GPS position.
 * Every change loads the user fresh and changes that one field, never saving the stale logged-in copy.
 */
@Service
@RequiredArgsConstructor
public class UserSettingsService {

    /** The countries the app supports and the money each one uses. */
    private static final Map<String, String> CURRENCY_OF = Map.of(
            "TZ", "TZS", "KE", "KES", "UG", "UGX", "RW", "RWF", "BI", "BIF", "CD", "CDF");
    private static final List<EscrowStatus> OPEN_BOOKING = List.of(
            EscrowStatus.PENDING_ACCEPTANCE, EscrowStatus.ACCEPTED, EscrowStatus.FUNDED, EscrowStatus.DISPUTED,
            EscrowStatus.AWAITING_PAYMENT, EscrowStatus.PAYMENT_SENT, EscrowStatus.PAYMENT_DISPUTED);

    private final UserRepository userRepository;
    private final WalletRepository walletRepository;
    private final EscrowTransactionRepository escrowRepository;
    private final PaymentRepository paymentRepository;
    private final ServicePostRepository servicePostRepository;

    public static String countryOf(User u) {
        return u.getCountry() == null || u.getCountry().isBlank() ? "TZ" : u.getCountry();
    }

    public static String currencyOf(User u) {
        return u.getCurrency() == null || u.getCurrency().isBlank() ? "TZS" : u.getCurrency();
    }

    @Transactional
    public void setHideMyId(User caller, boolean hide) {
        User u = userRepository.findById(caller.getId()).orElseThrow(() -> ApiException.notFound("USER_NOT_FOUND"));
        u.setHideMyId(hide);
        userRepository.save(u);
    }

    @Transactional
    public void setProfileLocked(User caller, boolean locked) {
        User u = userRepository.findById(caller.getId()).orElseThrow(() -> ApiException.notFound("USER_NOT_FOUND"));
        u.setProfileLocked(locked);
        userRepository.save(u);
    }

    public static final java.util.List<String> SOCIAL_KEYS = java.util.List.of("whatsapp", "instagram", "facebook", "x", "tiktok", "youtube");

    /**
     * Saves the profile social links. A key that is not sent stays as it is; an empty text clears it.
     * Handles lose a leading @, are trimmed, may not contain spaces or control characters and are at most 100 characters.
     */
    @Transactional
    public Map<String, String> setSocials(User caller, Map<String, ?> body) {
        User u = userRepository.findById(caller.getId()).orElseThrow(() -> ApiException.notFound("USER_NOT_FOUND"));
        for (String key : SOCIAL_KEYS) {
            if (!body.containsKey(key)) continue;
            Object raw = body.get(key);
            String v = raw == null ? "" : raw.toString().trim().replaceFirst("^@+", "");
            if (v.length() > 100 || v.chars().anyMatch(Character::isISOControl)) throw ApiException.badRequest("INVALID_SOCIAL");
            if (!"whatsapp".equals(key) && v.matches(".*\\s.*")) throw ApiException.badRequest("INVALID_SOCIAL");
            String val = v.isEmpty() ? null : v;
            switch (key) {
                case "whatsapp" -> u.setSocialWhatsapp(val);
                case "instagram" -> u.setSocialInstagram(val);
                case "facebook" -> u.setSocialFacebook(val);
                case "x" -> u.setSocialX(val);
                case "tiktok" -> u.setSocialTiktok(val);
                default -> u.setSocialYoutube(val);
            }
        }
        userRepository.save(u);
        return socialsOf(u);
    }

    /** The user's own social links (never null values: an empty text where nothing is saved). */
    public static Map<String, String> socialsOf(User u) {
        Map<String, String> m = new java.util.LinkedHashMap<>();
        m.put("whatsapp", nz(u.getSocialWhatsapp()));
        m.put("instagram", nz(u.getSocialInstagram()));
        m.put("facebook", nz(u.getSocialFacebook()));
        m.put("x", nz(u.getSocialX()));
        m.put("tiktok", nz(u.getSocialTiktok()));
        m.put("youtube", nz(u.getSocialYoutube()));
        return m;
    }

    private static String nz(String s) { return s == null ? "" : s; }

    /** Saves the notification switches. A null value leaves that switch as it is. */
    @Transactional
    public User setNotificationPrefs(User caller, Boolean bookings, Boolean messages, Boolean promos) {
        User u = userRepository.findById(caller.getId()).orElseThrow(() -> ApiException.notFound("USER_NOT_FOUND"));
        if (bookings != null) u.setNotifBookings(bookings);
        if (messages != null) u.setNotifMessages(messages);
        if (promos != null) u.setNotifPromos(promos);
        return userRepository.save(u);
    }

    @Transactional
    public void setLocation(User caller, Double lat, Double lng) {
        boolean bad = lat == null || lng == null || lat.isNaN() || lng.isNaN() || lat.isInfinite() || lng.isInfinite()
                || lat < -90 || lat > 90 || lng < -180 || lng > 180
                || (lat == 0.0 && lng == 0.0); // a phone without a fix often reports exactly 0,0
        if (bad) throw ApiException.badRequest("INVALID_LOCATION");
        User u = userRepository.findById(caller.getId()).orElseThrow(() -> ApiException.notFound("USER_NOT_FOUND"));
        u.setLastLatitude(lat);
        u.setLastLongitude(lng);
        u.setLocationUpdatedAt(LocalDateTime.now());
        userRepository.save(u);
    }

    /**
     * The app never converts money, so the server only lets the country change when nothing is held in the old
     * money: no pocket fund balance, no booking in progress, no payment waiting, and no services priced in it.
     */
    @Transactional
    public void setCurrency(User caller, String rawCountry, String rawCurrency) {
        String country = rawCountry == null ? "" : rawCountry.trim().toUpperCase(Locale.ROOT);
        String currency = rawCurrency == null ? "" : rawCurrency.trim().toUpperCase(Locale.ROOT);
        if (!currency.equals(CURRENCY_OF.get(country))) throw ApiException.badRequest("INVALID_CURRENCY");

        User u = userRepository.findByIdForUpdate(caller.getId()).orElseThrow(() -> ApiException.notFound("USER_NOT_FOUND"));
        if (country.equals(countryOf(u))) return; // already this country

        Wallet w = walletRepository.findByUserId(u.getId()).orElse(null);
        if (w != null && (w.getBalance().signum() > 0 || w.getLockedEscrowBalance().signum() > 0)) {
            throw ApiException.conflict("Your pocket fund still holds money. Withdraw or spend it before changing country.");
        }
        if (escrowRepository.existsByBuyerIdAndStatusIn(u.getId(), OPEN_BOOKING)
                || escrowRepository.existsBySellerIdAndStatusIn(u.getId(), OPEN_BOOKING)) {
            throw ApiException.conflict("You still have bookings in progress. Finish them before changing country.");
        }
        if (paymentRepository.existsByUserIdAndStatus(u.getId(), PaymentStatus.PENDING)) {
            throw ApiException.conflict("A payment is still waiting. Try again when it is finished.");
        }
        if (servicePostRepository.existsBySellerId(u.getId())) {
            throw ApiException.conflict("Your services are priced in your current money. Remove them before changing country.");
        }
        u.setCountry(country);
        u.setCurrency(currency);
        userRepository.save(u);
    }
}
