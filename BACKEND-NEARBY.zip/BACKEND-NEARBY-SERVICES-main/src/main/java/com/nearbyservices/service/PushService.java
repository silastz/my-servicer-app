package com.nearbyservices.service;

import com.nearbyservices.model.User;
import com.nearbyservices.repository.UserRepository;
import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Push notifications through OneSignal. The app logs every device in with the app user id as OneSignal's
 * external id, so a push goes to a person by their user id. The REST key stays on the server (env ONESIGNAL_API_KEY).
 *
 * Rules: a push never slows down or breaks the request that caused it (it is sent on a background thread);
 * when the surrounding database transaction rolls back, nothing is sent (the push waits for the commit);
 * with no ONESIGNAL_APP_ID / ONESIGNAL_API_KEY configured it does nothing.
 */
@Service
public class PushService {

    private static final Logger log = LoggerFactory.getLogger(PushService.class);
    private static final URI ENDPOINT = URI.create("https://api.onesignal.com/notifications?c=push");

    @Value("${push.onesignal.app-id:}")
    private String appId;
    @Value("${push.onesignal.api-key:}")
    private String apiKey;

    @Autowired(required = false)
    private UserRepository userRepository;

    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    private final ExecutorService executor = Executors.newFixedThreadPool(2, r -> {
        Thread t = new Thread(r, "push-sender");
        t.setDaemon(true);
        return t;
    });

    public boolean enabled() {
        return appId != null && !appId.isBlank() && apiKey != null && !apiKey.isBlank();
    }

    /** One text in both languages. The device shows the one that matches its language, English otherwise. */
    public record Text(String en, String sw) {}

    /**
     * @param data  arrives in the app as additionalData, e.g. {type: "offer", id: "12"}; the app uses "type" to
     *              decide which notification switch (bookings / messages / promos) the push belongs to.
     */
    public void toUser(Long userId, Text title, Text body, Map<String, Object> data) {
        if (userId == null || !enabled()) return;
        Runnable send = () -> executor.execute(() -> {
            if (allowedByUser(userId, data)) post(userId, title, body, data);
        });
        if (TransactionSynchronizationManager.isSynchronizationActive()) {
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override
                public void afterCommit() {
                    send.run();
                }
            });
        } else {
            send.run();
        }
    }

    /**
     * Like {@link #toUser} but sent right away, without waiting for the surrounding transaction to commit. For alerts
     * about something that FAILS (the failing request rolls its transaction back, so a push that waited for the commit
     * would never leave).
     */
    public void toUserNow(Long userId, Text title, Text body, Map<String, Object> data) {
        if (userId == null || !enabled()) return;
        executor.execute(() -> {
            if (allowedByUser(userId, data)) post(userId, title, body, data);
        });
    }

    /** The notification switch a push belongs to. Same rule as the app's NotificationService._prefFor. */
    static String categoryOf(Map<String, Object> data) {
        Object raw = data == null ? null : data.get("type");
        String t = raw == null ? "" : String.valueOf(raw).toLowerCase(java.util.Locale.ROOT);
        if (t.isEmpty()) return null;
        if (t.contains("chat") || t.contains("message") || t.contains("call")) return "messages";
        if (t.contains("promo") || t.contains("news") || t.contains("announce")) return "promos";
        if (t.contains("booking") || t.contains("request") || t.contains("payment")
                || t.contains("escrow") || t.contains("offer")) return "bookings";
        return null; // unknown types are always sent
    }

    /**
     * False when the user switched this category off in Settings. Checked on the server so it also works when
     * the app is closed. If the check itself fails, the push is sent (a missed alert is worse than an extra one).
     */
    private boolean allowedByUser(Long userId, Map<String, Object> data) {
        String category = categoryOf(data);
        if (category == null || userRepository == null) return true;
        try {
            return userRepository.findById(userId).map(u -> switch (category) {
                case "messages" -> u.isNotifMessages();
                case "promos" -> u.isNotifPromos();
                default -> u.isNotifBookings();
            }).orElse(true);
        } catch (RuntimeException e) {
            log.warn("Push preference check failed for user {}: {}", userId, e.getClass().getSimpleName());
            return true;
        }
    }

    /** The JSON OneSignal receives. Package-visible so it can be checked without a network. */
    Map<String, Object> payload(Long userId, Text title, Text body, Map<String, Object> data) {
        Map<String, Object> p = new LinkedHashMap<>();
        p.put("app_id", appId);
        p.put("target_channel", "push");
        p.put("include_aliases", Map.of("external_id", List.of(String.valueOf(userId))));
        p.put("headings", Map.of("en", title.en(), "sw", title.sw()));
        p.put("contents", Map.of("en", body.en(), "sw", body.sw()));
        p.put("data", data == null ? Map.of() : data);
        return p;
    }

    private void post(Long userId, Text title, Text body, Map<String, Object> data) {
        try {
            HttpRequest req = HttpRequest.newBuilder(ENDPOINT)
                    .timeout(Duration.ofSeconds(15))
                    .header("Content-Type", "application/json; charset=utf-8")
                    .header("Authorization", "Key " + apiKey)
                    .POST(HttpRequest.BodyPublishers.ofString(json(payload(userId, title, body, data))))
                    .build();
            HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (res.statusCode() / 100 != 2) {
                log.warn("Push to user {} refused by OneSignal: HTTP {} {}", userId, res.statusCode(), abbreviate(res.body()));
            }
        } catch (Exception e) {
            log.warn("Push to user {} failed: {}", userId, e.getClass().getSimpleName());
        }
    }

    /**
     * Minimal JSON writer for the payload (strings, numbers, booleans, lists, maps). Written by hand so this
     * class does not depend on which Jackson version the framework ships.
     */
    static String json(Object v) {
        StringBuilder sb = new StringBuilder();
        write(sb, v);
        return sb.toString();
    }

    private static void write(StringBuilder sb, Object v) {
        if (v == null) {
            sb.append("null");
        } else if (v instanceof Number || v instanceof Boolean) {
            sb.append(v);
        } else if (v instanceof Map<?, ?> m) {
            sb.append('{');
            boolean first = true;
            for (Map.Entry<?, ?> e : m.entrySet()) {
                if (!first) sb.append(',');
                first = false;
                quote(sb, String.valueOf(e.getKey()));
                sb.append(':');
                write(sb, e.getValue());
            }
            sb.append('}');
        } else if (v instanceof Iterable<?> it) {
            sb.append('[');
            boolean first = true;
            for (Object x : it) {
                if (!first) sb.append(',');
                first = false;
                write(sb, x);
            }
            sb.append(']');
        } else {
            quote(sb, String.valueOf(v));
        }
    }

    private static void quote(StringBuilder sb, String s) {
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c)); else sb.append(c);
                }
            }
        }
        sb.append('"');
    }

    private static String abbreviate(String s) {
        return s == null ? "" : (s.length() > 200 ? s.substring(0, 200) : s);
    }

    @PreDestroy
    void stop() {
        executor.shutdown();
    }
}
