#!/bin/sh
# Nightly backup of the database and both upload volumes, kept for BACKUP_KEEP_DAYS days.
# Runs inside the "backup" service of docker-compose.yml. Files land in /backups.
set -eu

KEEP_DAYS="${BACKUP_KEEP_DAYS:-14}"
HOUR="${BACKUP_HOUR_UTC:-01}"

backup_once() {
  stamp="$(date -u +%Y%m%d-%H%M%S)"
  dir="/backups/$stamp"
  mkdir -p "$dir"
  echo "[backup] $stamp database"
  PGPASSWORD="$POSTGRES_PASSWORD" pg_dump -h postgres-db -U "$POSTGRES_USER" -Fc "$POSTGRES_DB" > "$dir/db.dump.tmp"
  mv "$dir/db.dump.tmp" "$dir/db.dump"
  echo "[backup] $stamp uploads"
  tar -czf "$dir/uploads.tar.gz" -C /data uploads
  tar -czf "$dir/uploads-private.tar.gz" -C /data uploads-private
  find /backups -mindepth 1 -maxdepth 1 -type d -mtime "+$KEEP_DAYS" -exec rm -rf {} +
  echo "[backup] $stamp done"
}

# Wait until the database answers, then take one backup at start and one every day at HOUR (UTC).
until PGPASSWORD="$POSTGRES_PASSWORD" pg_isready -h postgres-db -U "$POSTGRES_USER" >/dev/null 2>&1; do sleep 5; done
backup_once || echo "[backup] FAILED"
while true; do
  now_h="$(date -u +%H)"; now_m="$(date -u +%M)"
  if [ "$now_h" = "$HOUR" ] && [ "$now_m" = "00" ]; then
    backup_once || echo "[backup] FAILED"
    sleep 90
  fi
  sleep 30
done
