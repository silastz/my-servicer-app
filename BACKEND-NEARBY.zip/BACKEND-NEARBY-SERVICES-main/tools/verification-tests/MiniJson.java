import java.util.*;

/** Tiny JSON-object parser so the standalone tests need no libraries (production uses Spring's parser). */
final class MiniJson {
    private final String s; private int i;
    private MiniJson(String s) { this.s = s; }
    @SuppressWarnings("unchecked")
    static Map<String, Object> parse(String text) {
        MiniJson p = new MiniJson(text);
        Object v = p.value();
        if (!(v instanceof Map)) throw new IllegalArgumentException("not an object");
        return (Map<String, Object>) v;
    }
    private void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }
    private Object value() {
        ws();
        char c = s.charAt(i);
        if (c == '{') {
            Map<String, Object> m = new LinkedHashMap<>(); i++; ws();
            if (s.charAt(i) == '}') { i++; return m; }
            while (true) { ws(); String k = str(); ws(); i++; m.put(k, value()); ws(); if (s.charAt(i++) == '}') return m; }
        }
        if (c == '"') return str();
        int st = i; while (i < s.length() && ",}] ".indexOf(s.charAt(i)) < 0) i++;
        return s.substring(st, i);
    }
    private String str() {
        StringBuilder b = new StringBuilder(); i++;
        while (s.charAt(i) != '"') { if (s.charAt(i) == '\\') i++; b.append(s.charAt(i++)); }
        i++; return b.toString();
    }
}
