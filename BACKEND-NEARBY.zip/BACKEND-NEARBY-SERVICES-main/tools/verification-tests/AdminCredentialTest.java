import com.sun.net.httpserver.HttpServer;
import com.nearbyservices.verification.*;

import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

/** Admin changes the BRELA login: storage, encryption, write-only password, live effect on lookups. */
public class AdminCredentialTest {
    static int failed = 0, passed = 0;
    static void check(String what, boolean ok) { if (ok) passed++; else { failed++; System.out.println("FAIL: " + what); } }

    // fake BRELA whose accepted login can be changed
    static volatile String okUser = "bob", okPass = "secret1";
    static final AtomicInteger logins = new AtomicInteger();
    static final Set<String> liveSessions = Collections.synchronizedSet(new HashSet<>());
    static HttpServer fake() throws Exception {
        HttpServer srv = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        srv.createContext("/um/login", x -> { x.getResponseHeaders().add("Set-Cookie", "init=1; Path=/"); x.sendResponseHeaders(200, -1); x.close(); });
        srv.createContext("/um/auth/login", x -> {
            String body = new String(x.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
            if (body.contains("username=" + okUser + "&") && body.endsWith("password=" + okPass)) {
                String sid = "s" + logins.incrementAndGet(); liveSessions.add(sid);
                x.getResponseHeaders().add("Set-Cookie", "sid=" + sid + "; Path=/");
                x.getResponseHeaders().add("Location", "/brela/prod/um");
                x.sendResponseHeaders(303, -1);
            } else x.sendResponseHeaders(200, -1);
            x.close();
        });
        srv.createContext("/brela/prod/um", x -> { x.sendResponseHeaders(200, -1); x.close(); });
        srv.createContext("/ors/search/person/", x -> {
            String ck = x.getRequestHeaders().getFirst("Cookie");
            boolean ok = ck != null && liveSessions.stream().anyMatch(s -> ck.contains("sid=" + s));
            if (!ok) { x.getResponseHeaders().add("Location", "/um/login"); x.sendResponseHeaders(303, -1); x.close(); return; }
            byte[] b = "{\"obj\":{\"result\":{\"FIRSTNAME\":\"AMINA\",\"MIDDLENAME\":\"\",\"SURNAME\":\"MWANGA\"}}}".getBytes(StandardCharsets.UTF_8);
            x.sendResponseHeaders(200, b.length); x.getResponseBody().write(b); x.close();
        });
        srv.start(); return srv;
    }

    static class MemStore implements CredentialStore {
        Stored row; int saves;
        public Optional<Stored> load() { return Optional.ofNullable(row); }
        public void save(String u, String c, long admin) { row = new Stored(u, c, Instant.now(), admin); saves++; }
    }

    public static void main(String[] a) throws Exception {
        // ---- SecretBox ----
        String key = Base64.getEncoder().encodeToString(new byte[32]);
        SecretBox box = new SecretBox(key);
        String enc = box.encrypt("p@ss word");
        check("encrypt hides value", !enc.contains("p@ss"));
        check("round trip", box.decrypt(enc).equals("p@ss word"));
        check("random IV", !box.encrypt("x").equals(box.encrypt("x")));
        boolean threw = false;
        try { String t = enc.substring(0, enc.length() - 4) + "AAAA"; box.decrypt(t); } catch (IllegalStateException e) { threw = true; }
        check("tamper detected", threw);
        byte[] other = new byte[32]; other[0] = 1;
        threw = false; try { new SecretBox(Base64.getEncoder().encodeToString(other)).decrypt(enc); } catch (IllegalStateException e) { threw = true; }
        check("wrong key fails", threw);
        threw = false; try { new SecretBox("AAAA"); } catch (IllegalArgumentException e) { threw = true; }
        check("short key refused", threw);

        // ---- admin service + live registry ----
        HttpServer srv = fake();
        String base = "http://127.0.0.1:" + srv.getAddress().getPort();
        MemStore store = new MemStore();
        List<String> audit = new ArrayList<>();
        LookupCredentialProvider provider = new LookupCredentialProvider(store, box, null);
        BrelaNinRegistry reg = new BrelaNinRegistry(base, provider, MiniJson::parse);
        IdentityLookupAdminService admin = new IdentityLookupAdminService(store, box, provider, reg,
                (id, act, d) -> audit.add(id + "|" + act + "|" + d));
        String nin = "19900101141300000011";

        var g = admin.get();
        check("empty: not set up", g.http() == 200 && Boolean.FALSE.equals(g.body().get("passwordSet")) && "NONE".equals(g.body().get("source")));
        check("no login saved -> test says so", !(Boolean) admin.test(1).body().get("success"));
        threw = false; try { reg.lookup(nin); } catch (IdentityServiceUnavailableException e) { threw = true; }
        check("lookup without login -> unavailable (name stays PENDING)", threw);

        check("nothing sent", admin.update(1, "", "").http() == 400);
        check("bad username", "USERNAME_INVALID".equals(admin.update(1, "bob smith", "x").body().get("message")));
        check("username only on first save -> incomplete", "CREDENTIALS_INCOMPLETE".equals(admin.update(1, "bob", "").body().get("message")));
        check("nothing saved on error", store.saves == 0);

        var r = admin.update(7, "bob", "secret1");
        check("first save ok", r.http() == 200 && "bob".equals(r.body().get("username")) && Boolean.TRUE.equals(r.body().get("passwordSet")) && "ADMIN".equals(r.body().get("source")));
        check("password never returned", !r.body().toString().contains("secret1") && !r.body().containsKey("password"));
        check("password encrypted in store", store.row != null && !store.row.passwordCipher().contains("secret1") && box.decrypt(store.row.passwordCipher()).equals("secret1"));
        check("test login ok", (Boolean) admin.test(7).body().get("success"));
        check("lookup works with admin login", reg.lookup(nin).found());
        int before = logins.get();
        reg.lookup(nin);
        check("session reused", logins.get() == before);

        // admin rotates the password at BRELA and in the app
        okPass = "newpass2"; liveSessions.clear();
        check("old password now rejected by test", !(Boolean) admin.test(7).body().get("success"));
        check("rejected message is clear", String.valueOf(admin.test(7).body().get("message")).contains("rejected"));
        r = admin.update(7, "", "newpass2"); // username left blank = keep
        check("blank username keeps it", "bob".equals(r.body().get("username")));
        check("new password works with no restart", reg.lookup(nin).found());

        // change while a session is live: must log in again with the new login
        okUser = "alice"; okPass = "pw3";
        admin.update(7, "alice", "pw3");
        int b2 = logins.get();
        check("changed login used on next lookup", reg.lookup(nin).found() && logins.get() == b2 + 1);

        // blank password keeps the saved one
        admin.update(7, "alice", "");
        check("blank password kept", reg.lookup(nin).found() && box.decrypt(store.row.passwordCipher()).equals("pw3"));
        check("password with spaces ok", admin.update(7, "", "has space 1").http() == 200);
        check("control char refused", "PASSWORD_INVALID".equals(admin.update(7, "", "bad\npass").body().get("message")));

        // audit never holds values
        String all = String.join(";", audit);
        check("audit has actions", all.contains("IDENTITY_LOOKUP_CREDENTIALS_CHANGED") && all.contains("IDENTITY_LOOKUP_TEST_LOGIN"));
        check("audit has no secrets", !all.contains("secret1") && !all.contains("newpass2") && !all.contains("pw3") && !all.contains("has space"));

        // fallback from deployment config when nothing is saved
        okUser = "bob"; okPass = "secret1"; liveSessions.clear();
        MemStore empty = new MemStore();
        LookupCredentialProvider fbProv = new LookupCredentialProvider(empty, box, new BrelaNinRegistry.Credentials("bob", "secret1"));
        BrelaNinRegistry fbReg = new BrelaNinRegistry(base, fbProv, MiniJson::parse);
        IdentityLookupAdminService fbAdmin = new IdentityLookupAdminService(empty, box, fbProv, fbReg, (i, x, d) -> {});
        check("fallback works and is labelled CONFIG", fbReg.lookup(nin).found() && "CONFIG".equals(fbAdmin.get().body().get("source")));
        fbAdmin.update(1, "", "secret1"); // admin takes over, keeping the fallback username
        check("admin takes over from fallback", "ADMIN".equals(fbAdmin.get().body().get("source")) && "bob".equals(fbAdmin.get().body().get("username")));

        // wrong key / damaged cipher behaves like "not saved"
        MemStore bad = new MemStore(); bad.save("bob", "AAAAAAAAAAAAAAAAAAAAAAAA", 1);
        check("damaged secret -> not set", !((Boolean) new IdentityLookupAdminService(bad, box,
                new LookupCredentialProvider(bad, box, null), reg, (i, x, d) -> {}).get().body().get("passwordSet")));
        srv.stop(0);

        System.out.println(passed + " passed, " + failed + " failed");
        System.exit(failed == 0 ? 0 : 1);
    }
}
