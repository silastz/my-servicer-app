#!/bin/sh
# Compiles the standalone verification classes (no Spring) and runs the admin-login tests. Needs JDK 21.
set -e
cd "$(dirname "$0")"
SRC=../../src/main/java/com/nearbyservices/verification
OUT=/tmp/nearby_verif_out
rm -rf "$OUT" && mkdir "$OUT"
javac -Xlint:none -d "$OUT" \
  $SRC/SecretBox.java $SRC/CredentialStore.java $SRC/AuditLog.java $SRC/LookupCredentialProvider.java \
  $SRC/BrelaNinRegistry.java $SRC/IdentityLookupAdminService.java $SRC/NinRegistry.java \
  $SRC/RegisteredName.java $SRC/IdentityServiceUnavailableException.java \
  MiniJson.java AdminCredentialTest.java
java -cp "$OUT" AdminCredentialTest
