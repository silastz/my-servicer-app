# NearByServices Backend API 🚀

Mfumo wa RESTful Backend uliotengenezwa kwa **Spring Boot 4 / Java 21** kwa ajili ya kuendesha mfumo wa huduma za karibu (NearByServices), kuhakiki watumiaji (NIDA verification), kusimamia miamala ya mfuko salama (**Escrow & Pocket Fund**), na kulinda usiri wa watoa huduma.

---

## 🏛️ Muundo na Teknolojia (Tech Stack)

- **Lugha & Framework**: Java 21 LTS, Spring Boot 4
- **Hifadhidata**: PostgreSQL 16
- **Usalama & Auth**: Spring Security 6, JJWT (0.12.6), BCrypt
- **API Documentation**: SpringDoc OpenAPI / Swagger UI 2.8.5
- **Ufungashaji & Uwekaji**: Docker, Docker Compose, GitHub Container Registry (GHCR)
- **CI/CD**: GitHub Actions (Runner inajenga image, VPS inapull tu ili kuokoa RAM)
- **Server VPS**: Contabo VPS (`95.111.251.192`), Mtumiaji: `lwenaadam`, Mlango (Port): `3010`
- **Domain**: `https://nearbyservices.techwareafrica.tech` (Nginx + Let's Encrypt SSL)

---

## 🔒 Sheria za Kiutendaji (Business Rules)

1. **Usiri wa NIDA & Majina (Privacy 100%)**:
   - Majina halisi ya cheti cha NIDA na namba ya NIDA **kamwe hayachapishwi kwenye API za umma**.
   - Watumiaji wanaonekana kwa jina la kikazi pekee (**Stage Name**).
2. **Beji za Uhakiki (Verification Badges)**:
   - 🟢 `GREEN_BADGE`: Namba ya NIDA pekee.
   - 🔵 `BLUE_TICK`: Kadi ya NIDA + Picha/Selfie, **AU** kualikwa na mtumiaji mwingine mwenye Blue Tick (`invitedByUserId`).
3. **Ulinzi wa Mawasiliano (Locked vs Unlocked)**:
   - Ikiwa `infoLocked = true`, namba ya simu, WhatsApp, barua pepe, na Instagram havipelekwi kwa mnunuzi hadi pale ombi la huduma litakapokubaliwa.
4. **Escrow & Wallet (Pocket Fund)**:
   - Fedha zinalindwa kwenye Escrow wakati kazi inafanyika.
   - Pesa huhamishiwa kwa muuzaji pale tu mnunuzi anapothibitisha kuridhika na huduma (**Mark Completed / Satisfied**).

---

## 🌐 Endpoints Muhimu (Live API)

- **Swagger UI**: [https://nearbyservices.techwareafrica.tech/swagger-ui/index.html](https://nearbyservices.techwareafrica.tech/swagger-ui/index.html)
- **OpenAPI JSON Spec**: `https://nearbyservices.techwareafrica.tech/v3/api-docs`
- **Health Check**: `https://nearbyservices.techwareafrica.tech/api/health`
- **Orodha ya Huduma (Marketplace Feed)**: `GET https://nearbyservices.techwareafrica.tech/api/services`
- **Usajili / Kuingia**: `POST https://nearbyservices.techwareafrica.tech/api/auth/register`, `POST https://nearbyservices.techwareafrica.tech/api/auth/login`
- **Uhakiki wa NIDA**: `POST https://nearbyservices.techwareafrica.tech/api/verification/nida-number`, `POST https://nearbyservices.techwareafrica.tech/api/verification/nida-id`
- **Wallet & Escrow**: `GET https://nearbyservices.techwareafrica.tech/api/wallet`, `POST https://nearbyservices.techwareafrica.tech/api/escrow/create`, `POST https://nearbyservices.techwareafrica.tech/api/escrow/{id}/release`

---

## 🛠️ Uendeshaji & Deployment (Local & Server)

### Local Dev
```bash
./mvnw clean spring-boot:run
```

### Kujenga Docker Container
```bash
docker compose up -d --build
```
*(Port 3010 inafunguliwa kwa ajili ya Nginx reverse proxy).*

## Going live with payments

Out of the box `PAYMENTS_GATEWAY=SANDBOX`: no real money moves. For production set in `.env`:

```
PAYMENTS_GATEWAY=SNIPPE
SNIPPE_API_KEY=snp_...
SNIPPE_WEBHOOK_SECRET=whsec_...
PAYMENTS_PUBLIC_BASE_URL=https://your-api-domain
REQUIRE_LIVE_PAYMENTS=true
```

With `REQUIRE_LIVE_PAYMENTS=true` the server refuses to start on SANDBOX or when the Snippe keys are empty.
Only SNIPPE and SANDBOX exist on the server; DPO, Selcom, ClickPesa and Pesapal are not implemented.
