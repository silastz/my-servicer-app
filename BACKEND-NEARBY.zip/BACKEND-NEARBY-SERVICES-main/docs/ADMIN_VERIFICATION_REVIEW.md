# Identity verification: what the server does, and the admin review calls

Everything below is ADMIN only (`/api/admin/**`). There is no admin screen in the app for it yet: use Swagger
(`/swagger-ui/index.html`, Authorize with an admin token) or curl.

## What users do (all implemented, see docs in the app repo)
| Call | Result |
|---|---|
| `POST /api/users/me/verified-name` `{fullName, nidaNumber}` | NIN looked up in the official source: match -> `VERIFIED` at once (registered spelling), mismatch -> `NAME_MISMATCH`, source down -> `PENDING` |
| `GET /api/users/me/verified-name` | `{status, name?, reason?}` (name only when VERIFIED) |
| `POST/GET /api/users/me/verified-photo` | live photo, starts `PENDING`, admin decides |
| `POST/GET /api/verification/documents` | `id_front`, `id_back`, `selfie_with_id`, `business_registration`, `tin_certificate`, `business_license`, `location_permit`. Files are kept in a PRIVATE folder (`app.upload.private-dir`, default `uploads-private`), never under `/uploads` |
| `POST/GET /api/verification/business` | name + status; goes `PENDING` when the 3 required papers are in |
| invitations + vouch requests | exactly as `invitation_api_contract.md` (5 open invitations, 14 days, accept re-checks name vs NIN) |

## Review queue
| Call | What |
|---|---|
| `GET /api/admin/verification/documents?status=PENDING` | papers waiting (`claimedName` shows what the user typed) |
| `GET /api/admin/verification/documents/{id}/file` | the picture |
| `POST .../documents/{id}/approve` `{"legalName":"as read from the ID"}` | when `id_front` (+ `id_back`, not for passport) are approved the legal name becomes VERIFIED (your `legalName`, else what the user typed). When the selfie is approved too, the user gets **Green** |
| `POST .../documents/{id}/reject` `{"reason":"..."}` | user sees the reason |
| `GET /api/admin/verification/photos?status=PENDING`, `POST .../photos/{userId}/approve` or `/reject` | verified photo |
| `GET /api/admin/verification/business?status=PENDING` | business applications |
| `POST .../business/{userId}/approve` `{"expiresAt":"2027-01-31"}` | **Blue** (Verified Business); lapses to EXPIRED and drops to Green after that date |
| `POST .../business/{userId}/reject` `{"reason":"..."}` | rejected, Blue removed |

## Changes to old behaviour
- `POST /api/verification/green-badge` and `/blue-tick` now answer **410 `USE_IDENTITY_VERIFICATION`**. They granted badges from client-supplied data (a typed NIN, any inviter id).
- The seller object now carries `businessVerified` / `businessName`; a booking's buyer carries `verifiedName` / `verifiedPhotoUrl` only when Hide My ID is off and the check is VERIFIED.
- New tables (created by `ddl-auto: update`): `user_verification_profiles`, `verification_documents`, `trust_invitations`, `vouch_requests`.
- Back up the `uploads-private` folder with the database (it holds ID photos).
