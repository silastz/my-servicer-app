# Block list

| Call | Answer |
|---|---|
| `POST /api/users/{id}/block` (body optional `{reason, details}`) | `{success: true}`; blocking twice is fine; yourself = 400 `CANNOT_BLOCK_YOURSELF`; unknown user = 404 |
| `DELETE /api/users/{id}/block` | 204 (also when not blocked) |
| `GET /api/users/blocked` | `[{id, stageName, blockedAt, reason?, blockedUser:{id, stageName}}]` (only the people I blocked) |

What the server enforces, in both directions (I blocked them OR they blocked me):
- **Chat:** `POST /chats/send` answers 403 `USER_BLOCKED`. People I blocked disappear from my conversation list (history is kept; unblocking restores it).
- **Bookings:** `POST /escrow/create` answers 403 `USER_BLOCKED`, before any money is held.
- **Services:** the other person's services are missing from the list for the signed-in viewer and answer 404 on the detail call.

The blocked person is never told: they only see that messages / bookings fail, and cannot read the block list of anyone.
Blocking someone does not touch an existing booking that is already in progress.
