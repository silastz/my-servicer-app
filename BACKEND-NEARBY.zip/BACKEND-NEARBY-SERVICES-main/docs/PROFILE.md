# Public profile (`/api/users/me/...`)

| Call | Body | Answer |
|---|---|---|
| `PUT /users/me/profile` | `{stageName?, bio?}` | `{success, stageName, bio, avatarUrl, coverUrl}` |
| `POST /users/me/avatar` | multipart `file` | `{url, avatarUrl}` |
| `DELETE /users/me/avatar` | | 204 |
| `POST /users/me/cover` | multipart `file` | `{url, coverUrl}` |
| `DELETE /users/me/cover` | | 204 |

- Only what is sent changes. Stage name 2 to 40 characters (`INVALID_STAGE_NAME`), bio up to 500 (`BIO_TOO_LONG`); an empty bio clears it.
- Pictures use the same checks as service pictures (type allow-list, magic bytes, 10 MB, random file name) and are stored
  under `/uploads/profile/avatars|covers/`. The old picture is deleted when replaced or removed (only inside `/uploads/profile/`).
- `seller.avatarUrl`, `seller.coverUrl` and `seller.bio` now appear on every service JSON (and wherever a public user is shown).
  `POST /auth/login` returns `avatarUrl` so a new phone gets the photo back. `GET /users/me` returns bio, avatarUrl, coverUrl.
- Phone and email are deliberately NOT changeable here.

## Changing the registered phone / email
| Call | Body | Effect |
|---|---|---|
| `POST /users/me/phone/request-change` | `{phone}` | sends a 6-digit code by SMS to the NEW number |
| `POST /users/me/phone/confirm-change` | `{phone, otp}` | switches the phone, marks it verified |
| `POST /users/me/email/request-change` | `{email}` | sends the code to the NEW address |
| `POST /users/me/email/confirm-change` | `{email, otp}` | switches the email (stored lower case), marks it verified |

Errors (`message`): `INVALID_PHONE_NUMBER`, `INVALID_EMAIL`, `SAME_AS_CURRENT`, `PHONE_ALREADY_USED` / `EMAIL_ALREADY_USED` (409),
`WAIT_BEFORE_NEW_CODE` (429, one code per 60 s), `NO_PENDING_CHANGE`, `INVALID_CODE`, `CODE_EXPIRED`, `TOO_MANY_ATTEMPTS` (429, 5 tries).
The code is valid 10 minutes, is generated with SecureRandom and only its BCrypt hash is stored (`contact_change_requests`).
`PUT /users/profile` no longer changes phone or email (it used to, with no proof); it now changes the stage name only.
The login token is tied to the username, so changing the phone does not sign anyone out.

## Account settings (`PUT /api/users/me/...`)
| Call | Body | Answer |
|---|---|---|
| `PUT /users/me/privacy` | `{hideMyId?: bool, profileLocked?: bool}` (at least one) | `{success, hideMyId?, profileLocked?}`; neither sent: 400 `INVALID_REQUEST` |
| `PUT /users/me/currency` | `{country: "KE", currency: "KES"}` | `{success, country, currency}` |
| `PUT /users/me/location` | `{latitude, longitude}` | `{success}` |

- **Hide My ID** (default off). The booking's `buyer` (`tx.buyer`) now carries `hideMyId`, `safeBadge` and `profileLocked`.
  Providers only ever get the stage name and the normal profile photo (the public user JSON has no real name or verified photo).
  `safeBadge` is decided by the server: Hide My ID on AND a green or blue verification. `profileLocked` is true until the provider accepts.
- **Currency**: supported pairs are TZ/TZS, KE/KES, UG/UGX, RW/RWF, BI/BIF, CD/CDF (anything else 400 `INVALID_CURRENCY`).
  Null means TZ/TZS. Because the app never converts money, the change is refused with 409 and a readable message while the
  pocket fund holds money (balance or escrow), a booking is in progress (as buyer or provider), a payment is waiting,
  or the user still has services (their prices are in the old money). Choosing the current country is a no-op 2xx.
- **Location**: latitude -90..90, longitude -180..180, not 0,0 (400 `INVALID_LOCATION`). Stored on the user with a timestamp,
  never returned to anyone, not even in `GET /users/me`.
- `POST /auth/login`, the phone-verify answer and `POST /auth/register` now return `hideMyId`, `country` and `currency`.
  `GET /users/me` returns them too.
- Every change loads the user fresh and changes that one field; it never saves the stale logged-in copy.

## Profile social links (`PUT /api/users/me/socials`)
Body: any of `{whatsapp, instagram, facebook, x, tiktok, youtube}`. Not sent = unchanged, empty text = cleared, leading `@` removed,
max 100 characters, no spaces (except `whatsapp`), else 400 `INVALID_SOCIAL`. Answer: `{success, socials:{...}}`. `GET /users/me` returns `socials`.
- They are stored on the user and are the fallback for a service that has no contact of its own: `phone` falls back to the account phone,
  the social fields to these links. The fallback applies only while the profile is Unlocked and the viewer may see contacts
  (`ServiceMarketplaceService.mapToResponse`). A locked profile never gives them away, not even in its owner's preview.
- The account email is NOT used as a fallback.

## Contacts on a booking (`contactsUnlocked`)
- Unlocked when the booking is ACCEPTED and paid, FUNDED, COMPLETED, or DISPUTED after it was accepted (`acceptedAt` is set when the
  provider first accepts; older bookings without it keep the old rule).
- `sellerPhone`, `sellerWhatsappPhone`, `sellerEmail` and `sellerSocials{whatsapp,instagram,facebook,x,tiktok,youtube}` use the
  service's own value first, then the provider's profile value. A locked profile is still shared here: the lock only hides it from people
  with no accepted booking.
- The account email is never a fallback: only an email added to the service is shared.
- `GET /identity/vouch-requests` returns the other person's `phone` only when that person's profile is Unlocked.
