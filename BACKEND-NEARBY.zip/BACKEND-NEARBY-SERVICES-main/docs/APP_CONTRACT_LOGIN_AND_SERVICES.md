# App <-> backend contract: login and services

What the Flutter app (NEARBY-SERVICES v135) sends and reads, and where the backend now provides it.

## Errors (all endpoints)
`{timestamp, status, error, message}` where **message is always a string**.
- Wrong password / unknown user: **401** `INVALID_CREDENTIALS` (was 500, so the app said "server busy" and never counted the failed try).
- Unverified account: 400 `ACCOUNT_NOT_VERIFIED`.
- Validation (400): `message` = first problem as a sentence, `errors` = every field problem.
- 413 `FILE_TOO_LARGE`, 415 `FILE_TYPE_NOT_ALLOWED`, 404 `SERVICE_NOT_FOUND`, 403 `NOT_SERVICE_OWNER`.
- 500 is `SERVER_ERROR` only; the real cause is in the server log, never sent to the phone.

## Login
`POST /api/auth/login {login, password}` -> `{token, id, username, stageName, role, verificationBadge, email, emailVerified, phone, phoneVerified}`
The app also reads `avatarUrl`, `hideMyId`, `currency` when present. The backend has no such user fields yet, so the app keeps its local copy.

## Publish / edit a service
`POST /api/services`, `PUT /api/services/{id}` (signed-in only; GET stays public).
Fields saved: title, description (max 2000), category, price, city, region, area, latitude, longitude, serviceRadiusKm, priceType (FIXED|STARTING_FROM|PER_HOUR), serviceMode (customer_comes|provider_travels|both), durationMinutes, availableDays, availableFrom/To (HH:mm), phone, whatsappPhone, email, instagram/facebook/tiktok/x/youtube usernames, isInfoLocked, is18Plus, imageUrls (max 8), videoUrls (max 6), featuredImageUrl, shortDescription, otherLanguage, features (max 30), discountPercent (1-90), discountValidUntil, allowOffers, minOfferPrice, autoAcceptPrice.
On edit, the always-sent fields are written as sent (so clearing works); the rest only when present.
Media URLs must be `/uploads/...` or `https://...`.

`POST /api/services/images` and `/videos` (multipart field `file`) -> `{"url": "/uploads/services/images/<uuid>.jpg"}`.
Photos max 10 MB (jpg, jpeg, png, webp, heic, heif), videos max 100 MB (mp4, mov, m4v, webm, 3gp); the first bytes are checked, not just the name.
Files are served at `GET /uploads/**` and kept in `UPLOAD_DIR` (a Docker volume in docker-compose.yml).

## Service page / lists
`GET /api/services?query&category&city&lat&lng&radiusKm&includeSensitive&page&size` -> Spring `Page` (`content`, `last`).
`GET /api/services/{id}`, `GET /api/services/seller/my-services`.
- The owner always sees their own contacts, coordinates and the private `minOfferPrice` / `autoAcceptPrice`; nobody else ever gets those two.
- Locked services hide contacts and coordinates from everyone else; `distanceKm` for them is rounded up to whole km.
- `isInfoLocked` and `is18Plus` are now written with those exact keys (they were written as `infoLocked` / `18Plus`, so the app always read false).
- Paused services return 404 to everyone except the owner/admin.
- `includeSensitive=false` hides 18+ services (the app sends it on every list call).

## Not in the backend yet (the app calls these)
`/payments/service-fee` (+ 402 on POST /services), `/payments/*`, `/reviews*`, `/users/me/verified-photo`, `/users/me/verified-name`.
