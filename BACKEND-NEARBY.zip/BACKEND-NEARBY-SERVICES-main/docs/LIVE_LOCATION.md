# Live location on a booking

`POST|GET|DELETE /api/escrow/{ref}/live-location` (unchanged for the app).

Storage: table `live_locations` (created by `ddl-auto: update`), one row per person per booking, overwritten on every
update. Positions survive a server restart and work with several server instances.

Privacy: no location history is kept. A position counts for 90 seconds; the row is deleted when the person stops
sharing or the booking stops being active, and a job removes anything older than 90 seconds every minute.

Load: one small upsert per sharing person per update (the app sends about every few seconds while tracking).
