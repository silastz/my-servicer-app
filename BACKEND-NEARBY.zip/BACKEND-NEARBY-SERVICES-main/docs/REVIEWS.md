# Reviews and ratings

| Call | Who | Answer |
|---|---|---|
| `POST /api/reviews` `{transactionRef, rating 1-5, comment?}` | buyer or provider of that booking | the review |
| `GET /api/reviews/received` | signed in | reviews about me |
| `GET /api/reviews/written` | signed in | reviews I wrote (the app uses `transactionRef` to hide "to review") |
| `GET /api/users/{id}/reviews` | public | buyers' reviews of that provider, newest first, max 50 |

Review JSON: `{id, transactionRef, rating, comment, createdAt, reviewer{id,stageName,...}, reviewee{...}, service{id,title}}`.
Only the stage name is public, never the real name, phone or NIDA data.

Rules (server side)
- Booking must be `COMPLETED`; otherwise 409 `TRANSACTION_NOT_COMPLETED`.
- Only the booking's buyer or provider can review it (anyone else gets 404, so references are not revealed).
- One review per person per booking (unique `transaction_ref + reviewer_id`); a second one is 409 `ALREADY_REVIEWED`.
- Only buyer-to-provider reviews feed ratings. Provider-to-buyer reviews appear only in the buyer's "received" list.

Ratings on the service page: `ServicePostResponse.rating` / `reviewsCount` (this service) and
`seller.rating` / `seller.reviewsCount` (the provider, all services). Average rounded to 1 decimal; 0 / 0 when none.
Also: escrow bookings now carry `service: {id, title}` (the My Reviews screen reads it).
