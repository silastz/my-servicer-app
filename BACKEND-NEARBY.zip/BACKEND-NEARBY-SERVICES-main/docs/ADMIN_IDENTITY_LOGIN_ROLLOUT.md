# Admin BRELA login + admin lock-down: rollout notes

## Before deploying (one-time, on the VPS `.env`)
1. `UNGANA_SECRETS_KEY=$(openssl rand -base64 32)` - required; the app will not start without it
   (docker-compose refuses to start too). Back it up: if lost, the admin just re-enters the BRELA password.
2. Optional first-install login: `UNGANA_BRELA_USERNAME`, `UNGANA_BRELA_PASSWORD`.
3. **Set a real `JWT_SECRET`.** The default in application.yaml / docker-compose / deploy.sh is public in the repo;
   anyone who knows it can forge an admin token.

## Admin accounts
Public sign-up can no longer create `ROLE_ADMIN` (`ROLE_NOT_ALLOWED`). Promote someone by SQL:

    UPDATE users SET role = 'ROLE_ADMIN' WHERE username = '<name>';

**Audit existing admins now** (the old hole let anyone self-register as admin):

    SELECT id, username, phone FROM users WHERE role = 'ROLE_ADMIN';

Demote or delete any you do not recognise, and rotate the JWT secret so their tokens stop working.

## New endpoints (ROLE_ADMIN only, 403 otherwise)
GET/PUT `/api/admin/identity-lookup`, POST `/api/admin/identity-lookup/test`
(contract: app repo docs/identity_lookup_admin_api_contract.md).
New tables are created by Hibernate (`ddl-auto: update`): `identity_lookup_settings`, `admin_audit_log`.

## Tests (no Maven needed): `tools/verification-tests/run_tests.sh` (JDK 21)
