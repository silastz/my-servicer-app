# Admin: managing user accounts

All routes need `ROLE_ADMIN` (`/api/admin/**`). Every change is written to the admin audit log
(`USER_SUSPENDED`, `USER_REACTIVATED`, `USER_DELETED`, detail `user <id>`).

| Call | What it does |
| --- | --- |
| `GET /api/admin/users?q=&status=&role=&page=0&size=30` | Newest first. `q` = name, username, phone, email or exact id. `status` = ACTIVE, SUSPENDED, DELETED or ALL. `role` = BUYER, SELLER or ADMIN. `size` max 100. |
| `GET /api/admin/users/{id}` | Summary plus `emailVerified, country, currency, servicesPosted, activeServices, walletBalance, walletLocked, deletedAt`. |
| `POST /api/admin/users/{id}/suspend` `{reason}` | Reason required (max 500). |
| `POST /api/admin/users/{id}/reactivate` | The person can sign in again (needs a new login). |
| `POST /api/admin/users/{id}/delete` | Anonymises the account, same rules as the owner's own deletion. |

Errors: `400 REASON_REQUIRED / REASON_TOO_LONG / INVALID_STATUS / INVALID_ROLE`, `403 ADMIN_ACCOUNT`,
`404 USER_NOT_FOUND`, `409 ACCOUNT_DELETED / WALLET_NOT_EMPTY / OPEN_BOOKINGS / PAYMENT_PENDING`.

## What a suspension does

- Sign-in answers `403 ACCOUNT_SUSPENDED` (only after the password was right, so it leaks nothing).
- Every token issued before is refused (`JwtService.isTokenValid`), and stays dead after reactivation (`tokensValidFrom`).
- The provider's services disappear from search and from the service page for everyone except an admin.
- Nothing is deleted: bookings, wallet and reviews are untouched. Open bookings are NOT cancelled automatically.

Admin accounts can never be suspended or deleted from these routes.

## Admin alerts (push)

Every active admin (not deleted, not suspended) gets a OneSignal push when:

| Event | `type` | Opens in the app |
| --- | --- | --- |
| A user sends a report (service, user or general) | `admin_report` | Reports |
| A provider says a payment did not arrive | `admin_dispute` | All Bookings |
| A provider asks to withdraw money | `admin_withdrawal` | Admin Wallet |
| The gateway reports a payment as FAILED (once per payment) | `admin_pay_error` | Payment Gateway |
| The gateway cannot start a payment (down, refused, not configured). Max one alert per 10 min per gateway | `admin_pay_error` | Payment Gateway |
| A gateway event does not match the payment (wrong amount or reference) | `admin_pay_error` | Payment Gateway |

Payment alerts carry the payment reference, purpose, amount and gateway, never the payer's phone or the gateway's raw error text.
Alerts about a failing request are sent immediately (`PushService.toUserNow`), because that request's transaction rolls back and a push
that waited for the commit would never leave.

Needs `ONESIGNAL_APP_ID` / `ONESIGNAL_API_KEY` (same as the other pushes). The types match none of the user notification
switches, so an admin alert is never muted by them. See `AdminAlerts`.

## Admin notification preferences

Each admin has four switches, all on by default, kept on the server (columns `notif_admin_*` on `users`) so an alert
that is off is never sent, even when the app is closed. Each admin changes only their own.

- `GET /api/admin/notification-prefs` -> `{reports, disputes, withdrawals, payments}`
- `PUT /api/admin/notification-prefs` with any of those as true/false -> the full set. `400 INVALID_PREFERENCE` for anything else.

`reports` = new reports, `disputes` = payment disputes, `withdrawals` = withdrawals to pay out,
`payments` = failed payments, gateway errors and payment mismatches. In the app: Profile > Admin Notifications.
