# Reports

`POST /api/reports` `{type: SERVICE|USER|GENERAL, reason, details?, serviceId?, reportedUserId?}` -> `{id, type, reason, details, status, createdAt, serviceId?, reportedUserId?}`

- SERVICE needs `serviceId`; the reported provider is taken from the service (the app's `reportedUserId` is ignored there).
  USER needs `reportedUserId`. GENERAL needs neither. Reporting yourself or your own service is 400 `CANNOT_REPORT_YOURSELF`.
- `reason` required (max 100), `details` max 2000. Unknown service/user = 404.
- Sending the same open report again returns the first one (no duplicates). More than 20 reports in 24 h = 429 `TOO_MANY_REPORTS`.
- The reporter never sees admin notes, and the reported person is never told.

Admin (ROLE_ADMIN only, 403 for everyone else)
- `GET /api/admin/reports?status=OPEN&limit=50` -> list with `reporterId` and `adminNote`
- `POST /api/admin/reports/{id}/status` `{status: OPEN|REVIEWING|RESOLVED|DISMISSED, note?}`
