# Price offers

```
Service page -> Offer -> seller accepts (or auto-accept) -> AGREED -> buyer books with offerId -> BOOKED
```
Statuses: `OFFERED`, `AGREED`, `REJECTED`, `WITHDRAWN`, `EXPIRED`, `BOOKED`.

| Who | Call | Effect |
|---|---|---|
| Buyer | `POST /api/offers` `{serviceId, amount, message?}` | `OFFERED` (24 h to answer), or `AGREED` at once when `amount >= autoAcceptPrice` (48 h to book). `sellerId` and `listedPrice` from the app are ignored: the seller is the service's owner and the listed price is the server's current price. |
| Seller | `POST /api/offers/{id}/accept` | `OFFERED` -> `AGREED`; `agreedAmount` = the offer, never above the service's price now. |
| Seller | `POST /api/offers/{id}/reject` `{reason?}` | `OFFERED` -> `REJECTED`. The reason is stored, not returned. |
| Buyer | `POST /api/offers/{id}/withdraw` | `OFFERED` -> `WITHDRAWN` |
| Buyer | `GET /api/offers/mine` | offers I sent (newest first, max 100) |
| Seller | `GET /api/offers/incoming` | offers on my services (newest first, max 100) |

Offer JSON: `id, status, serviceId, serviceTitle, listedPrice, amount, agreedAmount?, message, createdAt, expiresAt, bookingRef?, buyer{id,name}, seller{id,stageName}`.

Rules enforced on the server
- Buyer is signed in, is not the owner (400 `CANNOT_OFFER_ON_OWN_SERVICE`) and is not blocked either way (looks like 404 `SERVICE_NOT_FOUND`).
- `allowOffers` must not be false (400 `OFFERS_NOT_ALLOWED`).
- `amount` > 0, not above the current price (the sale price while a sale runs, rounded to TSh 100) = 400 `OFFER_ABOVE_PRICE`,
  and at least 30% of it. Below that, or below the seller's private `minOfferPrice`: the SAME message
  ("This price is too low for the provider...") so the minimum is never revealed.
- One open offer (`OFFERED` or `AGREED`) per buyer per service = 409 `OFFER_ALREADY_OPEN`. More than 5 new offers in 24 h = 429 `TOO_MANY_OFFERS`.
- Only the service's seller can accept/reject and only the buyer can withdraw; anyone else gets 404 `OFFER_NOT_FOUND`.
  An offer that is not `OFFERED` = 409 `OFFER_NOT_OPEN` (or `OFFER_EXPIRED`).
- Deadlines: `OFFERED` 24 h, `AGREED` 48 h. They are applied at the start of EVERY offer call and every booking with an offer
  (one bulk update), so a status is never stale when read; there is no separate job.

Booking with an agreed offer: `POST /api/escrow/create` accepts `offerId`. The server then
- requires the offer to be this buyer's, for this seller (and service if sent), `AGREED`, not expired and unused
  (409 `OFFER_ALREADY_USED`, `OFFER_EXPIRED`, `OFFER_NOT_AGREED`; 400 `OFFER_MISMATCH`),
- ignores the app's `amount` and charges `agreedAmount` (Pocket Fund holds that amount),
- sets the offer `BOOKED` with `bookingRef`, in the same transaction. A cancelled or rejected booking leaves the offer `BOOKED`.
- The booking JSON gets `offerId, listedPrice, agreedAmount, discountAmount` (only for offer bookings).

Tables: `price_offers`; `escrow_transactions` gets `offer_id`, `listed_price`, `discount_amount`. Hibernate adds them.

## Offer alerts (push notifications)

The server sends a push through OneSignal. The app logs every device in with the app user id, so a push goes to a
person by user id. Set `ONESIGNAL_APP_ID` and `ONESIGNAL_API_KEY` (OneSignal dashboard -> Settings -> Keys & IDs; the
REST key stays on the server). With either one empty, pushes are off and nothing else changes.

| When | Who gets it |
|---|---|
| A new offer (`OFFERED`) | seller |
| An offer made at or above the auto-accept price (`AGREED` at once) | seller. The buyer already has the answer on screen, so they get no push |
| Seller accepts | buyer ("book within 48 hours") |
| Seller rejects | buyer (the reason is never sent) |
| Buyer withdraws | seller |
| About 2 hours left on an `OFFERED` offer | seller (accept or decline) |
| About 2 hours left on an `AGREED` offer | buyer (book now) |

- Every push has English and Swahili text; the phone shows the one that matches its language.
- `data` = `{type: "offer", id, status, serviceId}`. The app files `offer` under its Bookings switch, so a user who
  turned that switch off sees no banner while the app is open. (A push that arrives in the background is shown by the
  phone regardless: the server does not read that switch.)
- A push is sent only after the database change is saved, on a background thread, so a failed push never undoes or
  slows an offer. Failures are logged, never shown to the user.
- Reminders: `OfferReminderJob` runs every 10 minutes and reminds each step once (`price_offers.reminder_sent`, cleared
  when the offer moves from `OFFERED` to `AGREED`). Expiry itself is still applied on every offer call. The job assumes ONE
  running server; with several, a reminder could go twice until a lock is added.
- The app's bell list also shows offers now: new offers to a seller, accepted / declined to a buyer.
