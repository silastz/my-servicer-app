# SMS gateway (Meseji / Beem Africa)

Implements the app's `docs/sms_gateway_api_contract.md`. Admin only (`/api/admin/**` is ROLE_ADMIN in SecurityConfig, plus `@PreAuthorize` on the controller).

| Call | What it does |
|---|---|
| `GET /api/admin/sms/config` | Saved settings. Secrets are never returned, only `apiKeySet` / `passwordSet` / `secretSet`. |
| `PUT /api/admin/sms/config` | Saves settings. A missing or blank secret keeps the saved one. `{ "data": {...} }` is accepted. |
| `POST /api/admin/sms/test-connection` `{provider}` | Beem: reads the balance. Meseji: asks `{api-url}/balance` (see below). Sends no SMS. |
| `POST /api/admin/sms/test-send` `{provider, phone}` | One real SMS with exactly that provider, no failover. 5 per hour per admin. |

## Rules enforced
- `defaultProvider` must be `MESEJI` or `BEEM` (400 `INVALID_PROVIDER`).
- A provider cannot become the default while incomplete (422 `DEFAULT_PROVIDER_INCOMPLETE`). Meseji: api key + sender. Beem: api key + secret + sender.
- Beem sender: up to 11 letters, numbers, spaces. Meseji sender: up to 20 of letters, numbers, space, `+ - .`. Cost 0 to 100000.
- Secrets are encrypted with `UNGANA_SECRETS_KEY` (same as the BRELA password) in the `app_config` table (keys `sms.*`). If that key changes, saved secrets read as "not set" and must be entered again.
- Audit log records which fields changed, never values. Test SMS phone numbers are masked (`+255****678`).

## Sending
`SmsService.sendOtpSms` uses the admin settings once they are saved and the default provider is complete. Before that it keeps using the old environment settings (`ACTIVE_SMS_PROVIDER`, ...), so nothing changes until the admin saves.
With `autoFailover` on, a failed send is repeated once with the other provider and ITS OWN sender ID. A bad phone number or over-long message is refused before any call and is never retried. The log says which provider sent it and when the backup was used.

## Provider calls and assumptions to verify
- Beem: `POST https://apisms.beem.africa/v1/send` (Basic auth `apiKey:secret`), balance `GET https://apisms.beem.africa/public/v1/vendors/balance`.
- Meseji: `POST {MESEJI_API_URL}/sms/send` with `x-api-key`. `MESEJI_API_URL` defaults to the host of the old "SMS Gateway Pro" setting; **confirm it is your Meseji URL**.
- The Meseji body is `{phone_number, message, sender_id, priority}`. `sender_id` and the `{api-url}/balance` check are guesses: the contract names neither. If Meseji rejects `sender_id`, change `sendMeseji` in `HttpSmsTransport`.
- Meseji `email` / `password` are stored but not used yet (no login call is documented).
