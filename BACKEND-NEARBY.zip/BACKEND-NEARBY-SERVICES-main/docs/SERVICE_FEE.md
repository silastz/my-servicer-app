# Per-service fee (backend side of the app's SERVICE_FEE_FLOW.md)

- `GET /api/payments/service-fee` -> `{freeLimit, used, credits, amount, needsPayment}`
  `needsPayment = used >= freeLimit && credits <= 0` (admins are exempt).
- `POST /api/services` answers **HTTP 402** `{"message":"SERVICE_FEE_REQUIRED"}` when `needsPayment`; otherwise it
  creates the service, counts it (`users.services_posted`, never decreases) and spends one credit when beyond the free limit.
  The provider row is locked during the check, so two simultaneous publishes cannot spend one credit twice.
- Amount: `admin_settings.service_fee` (default 5000). Free limit: `admin_settings.free_services_quota` (default 2).
  Both editable with `PUT /api/admin/settings` (`serviceFee`, `freeServicesQuota`).
- Credits: `ServiceFeeService.addCredit(userId, paymentReference)` adds one credit, once per reference
  (table `service_fee_credits`, unique reference). **Nothing calls it yet**: the `/payments/*` part (mobile money /
  card with `purpose: "SERVICE_FEE"`) must call it when a payment turns PAID.
- Columns are added by Hibernate `ddl-auto: update` and also by the ALTER statements in `DataInitializer`.

## Registration fee is required before the first service

`POST /api/services` answers **HTTP 402 `REGISTRATION_FEE_REQUIRED`** when the provider has not paid the one-time
registration fee (`users.registration_fee_paid`, set only by a PAID `PROVIDER_REGISTRATION` payment). Admins are exempt.
The check runs first, under the same row lock as the service-fee check, so two quick taps cannot slip past it.
Providers who already posted a service before this rule are treated as registered (their flag is set on their next
publish), so nobody who is live today is locked out. Editing an existing service is not affected.
The service-fee 402 is still `SERVICE_FEE_REQUIRED`; the app tells them apart by the message.
