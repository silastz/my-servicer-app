# Provider portfolio

A provider's own photos and videos, shown on their profile. Separate from the pictures attached to a service.

| Method | Path | Who | Body / result |
|---|---|---|---|
| GET | `/api/portfolio/user/{userId}` | public | `[{id, type: IMAGE\|VIDEO, url, caption, createdAt}]`, newest first |
| POST | `/api/portfolio/images` | provider | multipart `file`, optional `caption`; returns the item |
| POST | `/api/portfolio/videos` | provider | multipart `file`, optional `caption`; returns the item |
| PUT | `/api/portfolio/{id}` | owner | `{"caption": "..."}`; returns the item |
| DELETE | `/api/portfolio/{id}` | owner | `{"deleted": true}`; the file is removed too |

Limits: 40 photos (10 MB each) and 10 videos (100 MB each) per provider; 140-character captions.
Errors: `PORTFOLIO_PHOTO_LIMIT` / `PORTFOLIO_VIDEO_LIMIT` (409), `PROVIDER_ONLY` (403), `PORTFOLIO_ITEM_NOT_FOUND` (404),
plus the usual upload errors (`FILE_TOO_LARGE`, `FILE_TYPE_NOT_ALLOWED`).
Files live under `/uploads/portfolio/{images,videos}` and are deleted with the item or the account.
