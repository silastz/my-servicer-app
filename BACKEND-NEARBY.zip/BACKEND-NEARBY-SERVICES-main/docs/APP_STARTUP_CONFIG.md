# Startup config the app reads on Home (ads + update dialog)

| Call | Who | Notes |
|---|---|---|
| `GET /api/app/ads?platform=` | public | Saved ad settings, `{}` if none saved (app keeps its defaults) |
| `GET /api/app/version?platform=` | public | Update dialog info; default `1.0.0` = never nags |
| `GET/PUT /api/admin/ads/config` | ADMIN | Validated per docs/ads_config_api_contract.md; stored exactly as sent |
| `GET/PUT /api/admin/app/version?platform=android\|ios` | ADMIN | `{ "latestVersion": "1.2.0", "minVersion": "1.0.5", "forceUpdate": false, "storeUrl": "https://...", "messageEn": "", "messageSw": "" }` |

Table `app_config` is created by `ddl-auto: update`. Before the first save the app simply uses its built-in defaults.

## Card payments (default OFF)
`GET/PUT /api/admin/payments/card` `{ "enabled": true }` (ADMIN). Stored in `admin_settings.card_payments_enabled`, default false.
`GET /api/app/policy` returns `data.payments.cardEnabled`; `POST /api/payments/card/checkout` answers 403 `CARD_PAYMENTS_DISABLED` while off.

## OTP pending minutes (default 4)
`GET/PUT /api/admin/otp-settings` `{ "pendingMinutes": 6 }` (ADMIN, 1-10, else 400 `INVALID_OTP_PENDING_MINUTES`; audited as `OTP_PENDING_MINUTES_CHANGED`).
Stored in `admin_settings.otp_pending_minutes` (default 4). `GET /api/app/policy` returns `data.auth.otpPendingMinutes`.
The app keeps a sent sign-up / password-reset code "pending" for that long: if the user closes and reopens the app in time,
typing the same phone/email opens the code screen again (no new SMS). The server is unchanged for the code itself (still 10 minutes).

## Support contacts (Help screen)
`GET /api/app/policy` returns `data.support { phone, whatsapp, email }` from the env vars `SUPPORT_PHONE`, `SUPPORT_WHATSAPP` and `SUPPORT_EMAIL`
(also passed through in docker-compose.yml) as the default. **What the admin saves wins over the env var**; clearing it in the admin screen returns to the env default.
Only the ones that are set are sent; the app hides the rest. Numbers: 9-15 digits, optional leading `+`.

| Call | Who | Notes |
|---|---|---|
| `GET /api/admin/support` | ADMIN | `{phone, whatsapp, email, source:{phone, whatsapp, email}}`; `source` is `admin`, `env` or `none` |
| `PUT /api/admin/support` | ADMIN | Any of `{phone, whatsapp, email}`; not sent = unchanged, empty text = cleared. 400 `INVALID_SUPPORT_PHONE` / `INVALID_SUPPORT_WHATSAPP` / `INVALID_SUPPORT_EMAIL`. Audited as `SUPPORT_CONTACTS_CHANGED` |

(`PUT /api/admin/settings {supportPhone, supportWhatsapp, supportEmail}` still works and saves the same values.)

**Set `SUPPORT_PHONE` and `SUPPORT_WHATSAPP` in the server `.env`.** Until then the app hides those two contacts (and `SUPPORT_EMAIL` the email row).

## Terms and Privacy Policy links (Help screen)
`GET /api/app/policy` returns `data.legal { termsUrl, privacyUrl }` from the env vars `APP_TERMS_URL` and `APP_PRIVACY_URL` (https links only; also passed
through in docker-compose.yml). The app opens the link in the browser. A link that is not set is left out, and the app then shows its short in-app text.

**The server now hosts these pages itself** (`LegalController`, wording in `src/main/resources/legal/*.html`):
`GET /legal/privacy`, `/legal/terms` and `/legal/delete-account` (public, no login). Set `APP_PUBLIC_BASE_URL=https://your.server` and, when
`APP_TERMS_URL` / `APP_PRIVACY_URL` are empty, the policy answer points to those pages. Also set `APP_OPERATOR_NAME` (your registered
company name), and bump `APP_LEGAL_UPDATED` whenever you change the wording. **Have a lawyer review the pages before release.**
Use `https://your.server/legal/privacy` as the Privacy Policy URL and `https://your.server/legal/delete-account` as the account-deletion URL
in the Play Console, and the privacy URL in App Store Connect. The contacts printed on the pages are the support contacts above.

## Account deletion (store requirement)
| Call | Who | What |
|---|---|---|
| `GET /api/users/me/delete-check` | signed in | `{canDelete: true}` or `{canDelete: false, reason}` with reason `WALLET_NOT_EMPTY`, `OPEN_BOOKINGS`, `PAYMENT_PENDING` or `ADMIN_ACCOUNT` |
| `DELETE /api/users/me` body `{password}` | signed in | Anonymises the account for good. 403 `WRONG_PASSWORD`, 409 with the same reason codes, 429 after 5 wrong passwords in 15 minutes |

The row is kept (payments, bookings and reviews of others point at it) but name, phone, email, password, photos, bio, social links, ID papers,
NIDA data, GPS position and search history are erased, services are switched off, and every token stops working (`users.deleted_at` is set).
The phone number and email become free to register again.

## Service categories (admin managed)
Table `service_categories` (created by `ddl-auto: update`, seeded once with Massage, Beauty, Barber, Cleaning, Plumbing, Electrical,
Mechanic, Photography, Repair, Food, General). The `id` is the key services are saved under and the app sends as `?category=`; it never changes.

| Call | Who | Notes |
|---|---|---|
| `GET /api/admin/categories` | ADMIN | All, incl. switched-off: `[{id, nameEn, nameSw, sortOrder, active, services}]` (`services` = how many use it) |
| `POST /api/admin/categories` | ADMIN | `{id, nameEn?, nameSw?, sortOrder?, active?}` -> 201. Errors `INVALID_CATEGORY_ID`, `CATEGORY_ID_IN_USE` (409, case-insensitive), `INVALID_CATEGORY_NAME` |
| `PUT /api/admin/categories/{id}` | ADMIN | Any of `{nameEn, nameSw, sortOrder, active}`. 404 `CATEGORY_NOT_FOUND` |
| `DELETE /api/admin/categories/{id}` | ADMIN | 204 only when no service uses it, else 409 `CATEGORY_IN_USE` (switch it off instead) |

`GET /api/app/policy` returns `data.categories = [{id, nameEn, nameSw}]` (active only, in order); left out while the table is empty, so the app keeps its built-in list.
`POST/PUT /api/services` with a category that is unknown or switched off (new service, or a changed category) answers 400 `INVALID_CATEGORY`;
a service that keeps its current category can still be edited. The category is saved with the spelling of its `id`. Every change is audited (`SERVICE_CATEGORY_CREATED/CHANGED/DELETED`).

## Required secrets / switches
- `JWT_SECRET` and `POSTGRES_PASSWORD` have no default in docker-compose.yml any more (the old JWT default was public). `deploy.sh` generates them on first run.
  The server also warns at start if `JWT_SECRET` is still the public default, and refuses to start with `REQUIRE_LIVE_PAYMENTS=true`.
- `/v3/api-docs` and `/swagger-ui` are off unless `SWAGGER_ENABLED=true`.
- Before release: replace Google's TEST AdMob app id in the app's `AndroidManifest.xml` with the real one.

## Payment email (payers with no email)
The gateway needs an email for every payer. A user without one gets the "payment email": what the admin saved, else `SNIPPE_FALLBACK_EMAIL`
(default `no-reply@example.com`, a placeholder: set a real mailbox you own).
`GET /api/admin/payments/fallback-email` -> `{email, source: admin|env}`; `PUT` `{email}` (empty = back to the env default; 400 `INVALID_PAYMENT_EMAIL`; audited as `PAYMENT_EMAIL_CHANGED`).

## Admin account (seeded from the environment)
Set `ADMIN_PHONE` and `ADMIN_PASSWORD` (min 10 characters; optional `ADMIN_EMAIL`, `ADMIN_NAME`) in `.env`. At start the server creates that account as ROLE_ADMIN
(phone already verified, empty wallet). There is no built-in password and sign-up can never create an admin.
If the phone already belongs to a normal account it is promoted to admin (password unchanged). If it is already an admin nothing changes, so a restart never resets
a password the admin changed. With no admin at all and nothing set, the log warns `NO ADMIN ACCOUNT` at every start. `deploy.sh` generates `ADMIN_PASSWORD`; you set `ADMIN_PHONE`.
Sign in with the phone (or email) and the password.

## App security switches and top-up limits
`GET/PUT /api/admin/security` (ADMIN) `{screenCaptureAllowed, blockCompromisedDevice, playIntegrity, blockVpn, topUpMin, topUpMax}`.
A switch that was never set is `null` and is left out of the policy (the app uses its build default). In a PUT: key absent = unchanged, `null` = back to default.
`GET /api/app/policy` returns `data.security {…}` and `data.fees.topUpMin/topUpMax`. Limits: whole TSh 100 - 100,000,000 (0/null = none), max >= min.
The server enforces the top-up limits: `POST /api/payments/mobile/request` and `/card/checkout` with `purpose=WALLET_TOPUP` answer 400 `TOPUP_BELOW_MIN` / `TOPUP_ABOVE_MAX`.
Audited as `APP_SECURITY_CHANGED`. NOTE: the server does not yet verify Play Integrity tokens (needs a Google service account); `playIntegrity` only tells the app to send them.
