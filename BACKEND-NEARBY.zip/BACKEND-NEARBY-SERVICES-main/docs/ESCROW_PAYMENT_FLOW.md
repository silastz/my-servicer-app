# Escrow payment flow

Implements the app's pay-first / offline flow (`api_service.dart`) and `PAY_AFTER_ACCEPT_FLOW.md`.

## Statuses
New: `AWAITING_PAYMENT`, `PAYMENT_SENT`, `PAYMENT_DISPUTED`. New payment methods: `OFFLINE`, `PAY_AFTER_ACCEPT`.
New booking fields (always in the JSON): `paymentStatus` (`UNPAID`/`PAID`), `paymentMode`, `paymentInstructions`, `paymentDeadline`, `paymentReference`, `paymentNote`, `paymentProofUrl`, `paymentPreference`, `paymentDisputeReason`.
Older Pocket Fund bookings show `paymentStatus: PAID`.

## Calls (all need login; the role is checked on the booking, not the app)
| Call | Who | From -> to |
|---|---|---|
| `POST /api/escrow/create` with `paymentMethod: PAY_AFTER_ACCEPT` | buyer | new booking `PENDING_ACCEPTANCE`, `UNPAID`, nothing charged. The server sets the price (agreed offer price, else the picked tasks, else the service's current price with any sale); the `amount` in the body is ignored. `serviceId` is required and must be an active service of `sellerId`: `SERVICE_REQUIRED`, `SERVICE_NOT_FOUND` (also for another seller's service), `SERVICE_NOT_ACTIVE` |
| `POST /api/escrow/accept/{ref}` | provider | `PENDING_ACCEPTANCE -> ACCEPTED` (stays `UNPAID`); buyer notified |
| `POST /api/escrow/request-payment/{ref}` `{mode, instructions, deadlineMinutes}` | provider | `PENDING_ACCEPTANCE -> AWAITING_PAYMENT`. mode `ONLINE`/`OFFLINE`; OFFLINE needs instructions; deadline 5 min to 7 days, default 24 h |
| `POST /api/escrow/mark-paid/{ref}` `{reference, note, proofUrl}` | buyer | `AWAITING_PAYMENT`/`PAYMENT_DISPUTED -> PAYMENT_SENT` (OFFLINE only, before the deadline) |
| `POST /api/escrow/confirm-payment/{ref}` | provider only | `PAYMENT_SENT`/`PAYMENT_DISPUTED -> ACCEPTED`, `PAID` |
| `POST /api/escrow/payment-not-received/{ref}` `{reason}` | provider | `PAYMENT_SENT -> PAYMENT_DISPUTED` |
| `POST /api/escrow/pay/{ref}` `{paymentMethod}` | buyer | `ACCEPTED`(UNPAID) or `AWAITING_PAYMENT`(ONLINE) -> `ACCEPTED`, `PAID` |
| `POST /api/escrow/payment-proof` (field `file`) -> `{url}` | buyer | only while an OFFLINE payment is due; 20 per hour |
| `GET /api/escrow/payment-proof/{name}` | that booking's buyer and provider, admins | everyone else gets 404 |

`pay` methods: `POCKET_FUND` moves the amount into the escrow lock (the booking then behaves like any Pocket Fund booking). `MOBILE_MONEY` / `CARD` require the gateway payment for this booking (purpose `BOOKING`, reference = the booking ref) to be PAID for at least the booking amount. The booking also notices such a payment by itself the next time the buyer or provider lists bookings.
Every transition locks the booking row, so a double tap can never move money twice.

## Rules
- Contacts and exact location unlock only when `ACCEPTED` and not `UNPAID` (the server decides).
- Cancel / reject (`/cancel`, `/reject`) now also work from `AWAITING_PAYMENT`, `PAYMENT_DISPUTED` and `ACCEPTED`+`UNPAID`, and never refund anything for an `UNPAID` booking. `PAYMENT_SENT` cannot be called off: the provider must confirm or dispute.
- Release (buyer) on an `UNPAID` booking: 402 `PAYMENT_REQUIRED`. On an offline-paid booking it just completes it: no money moves because the app holds none.
- Admin release/refund: refused on `UNPAID` (409 `BOOKING_NOT_PAID`) and on `REJECTED` bookings. Admin release of an offline booking completes it without moving money.
- Pushes (type `booking`) go to the other party on accept, request-payment, mark-paid, confirm, not-received and pay.

## Database
New nullable columns are added by `ddl-auto: update`. `DataInitializer` rebuilds the status and payment_method CHECK constraints so the new values are allowed.
Proof pictures are saved in the private upload volume (same as ID papers), never under `/uploads`.

## Payment preference
`HELD` (default): the money is held until the buyer confirms the job (`/release`). `DIRECT`: as soon as an online payment (Pocket Fund, mobile money, card) is PAID, the amount goes to the provider's wallet and the booking becomes `COMPLETED` in the same step (no release button). Offline payments are never held, so the preference makes no difference there. A booking already prepaid with Pocket Fund at creation keeps `HELD` behaviour.

## Refunds of mobile money / card bookings
No gateway refund call is used (the gateway interface has none, and I could not verify one for Snippe). Instead, when an admin refunds a booking that was paid by mobile money or card and not yet released, the money the platform holds is credited to the buyer's Pocket Fund, with the same fee rules as a Pocket Fund refund (see PROVIDER_FEES_FLOW.md). The buyer can withdraw it from there. The refund is locked per booking, so a double click refunds once. Tell the buyer it comes back as Pocket Fund balance, not to their phone or card.

## Payment deadlines
`PaymentDeadlineJob` runs every 5 minutes. A booking still `AWAITING_PAYMENT` after `paymentDeadline` becomes `REJECTED` (reason `PAYMENT_DEADLINE_PASSED`, nothing to refund) and both people get a push. If an online (mobile money / card) payment arrived in time, the booking is accepted instead. `mark-paid` and `pay` also refuse after the deadline. `PAYMENT_SENT` and `PAYMENT_DISPUTED` have no deadline: the provider must decide, or an admin resolves them.

## Known gaps
- A mobile money / card payment that completes AFTER the booking was ended is not matched back to it automatically; an admin has to refund it by hand.

## Concurrency and error codes

`accept`, `reject`, `cancel`, `release`, the admin release / refund and every payment-flow call read the booking with a row lock
(`findByTransactionRefForUpdate`), so two taps at the same time refund or pay once; the second one gets 409 `INVALID_STATUS:<status>`.
Errors are codes the app translates: `BOOKING_NOT_FOUND` (404), `NOT_YOUR_BOOKING` (403), `INVALID_STATUS:<status>` (409),
`INSUFFICIENT_BALANCE` (409 when booking or paying, 400 for a boost or withdrawal).
