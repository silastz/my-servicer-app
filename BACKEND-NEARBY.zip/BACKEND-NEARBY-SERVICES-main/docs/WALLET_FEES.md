# Provider fees, platform wallet and app policy

Follows `PROVIDER_FEES_FLOW.md` in the app repo. The fees start at 0 and are set on Admin -> Provider Fees
(`PUT /api/admin/payments/provider-fees`). With 0 everywhere nothing is taken.

## What is charged, and when

| Moment | What happens |
|---|---|
| A buyer pays a provider | The provider's wallet gets the **full** amount. No fee here. |
| `POST /api/wallet/withdraw {amount, phone}` | `amount` leaves the wallet. Collection fee and charge come out of it; the rest is `netAmount`. |
| A pocket-fund booking is refunded (seller rejects, buyer cancels, admin refunds) | The buyer gets `paid - charge` back. No collection fee. If the charge is more than was paid, the buyer gets 0. |

Formula (whole TSh, percent rounded half up), in `ProviderFeeCalculator`:
`collection = amount * collectionPercent`, `charge = max(amount * vatPercent, payoutFee)` (0 when both are 0),
`payoutPart = payoutFee`, `vatPart = charge - payoutPart`, `net = amount - collection - charge`.
Check (3 %, 18 %, 1,500): withdraw 20,000 -> 600 + 3,600 -> receives 15,800; refund 10,000 -> 8,200.

Withdrawal answer: `{..wallet.., fee, netAmount, reference}`. `fee` = collection + charge as ONE number; the payout / VAT
split is never sent to providers or buyers. `GET /wallet/transactions` carries the same `fee` and `netAmount` on
withdrawal lines. Errors (400): `WITHDRAW_TOO_SMALL_FOR_FEES` when `net <= 0`, `WITHDRAW_BELOW_MIN`, `WITHDRAW_ABOVE_MAX`,
`INVALID_AMOUNT` (whole shillings only), `INSUFFICIENT_BALANCE`. The fees taken are stored on the withdrawal row
(`wallet_transactions`), so changing the fees later never rewrites history. A change applies to later withdrawals and refunds.

## Platform wallet (table `platform_entries`)

Every line is written in the same transaction as the event. `(type, reference)` is unique, so an event cannot be booked twice.

| Type | Direction | Booked when |
|---|---|---|
| `REGISTRATION_FEE`, `SERVICE_FEE` | IN | the payment turns PAID |
| `BOOST` | IN | a boost payment turns PAID, or a boost is paid from the pocket fund |
| `COLLECTION_FEE` | IN | a provider withdraws |
| `PAYOUT_FEE` | IN | the flat part of a withdrawal or refund charge |
| `VAT` | IN | the rest of the charge. Owed to the tax authority: **not income, not withdrawable** |
| `WITHDRAWAL` | OUT | the admin withdraws |

| Call (ROLE_ADMIN only) | Answer |
|---|---|
| `GET /api/admin/wallet` | `{balance, held, totalIn, totalOut, income: {registrationFees, serviceFees, boosts, commissions, withdrawalFees, collectionFees, vat}}` |
| `GET /api/admin/wallet/withdrawals?status=PENDING&limit=50` | payout queue, newest first, users' and the admin's own: `[{reference, kind: USER\|PLATFORM, userId?, amount, fee, netAmount, phone, status, failReason?, createdAt}]`. `status` is `PENDING` (default), `COMPLETED`, `FAILED` or `ALL`. `phone` is the full payout number (`null` on withdrawals made before it was stored) |
| `POST /api/admin/wallet/withdrawals/{ref}/complete` | the payout was sent: `PENDING -> COMPLETED`. Answer: the row. Any other status: 409 `INVALID_STATUS:<status>` |
| `POST /api/admin/wallet/withdrawals/{ref}/fail {reason?}` | the payout could not be sent: `PENDING -> FAILED`. A user's withdrawal returns the whole `amount` to their wallet and its collection fee, payout fee and VAT lines become `REVERSED`; the admin's own withdrawal stops counting. 404 `WITHDRAWAL_NOT_FOUND`, 409 `INVALID_STATUS:<status>` |
| `GET /api/admin/wallet/transactions?limit=50` | newest first `[{id, type, amount, direction, title, status, reference, createdAt}]` (withdrawals also `fee`, `net`, masked `phone`, `adminId`) |
| `POST /api/admin/wallet/withdraw {amount, phone, reference?}` | `{fee, netAmount, reference, balance}` |

- `balance` = money in, minus VAT, minus money out = what the admin may withdraw. `held` = money in bookings that are not finished.
  `commissions` is always 0 (the platform takes no booking commission).
- Admin withdrawal: fee = the flat `payoutFee` from the CURRENT setting (never from the request), the admin receives `amount - fee`;
  minimum 1,000; `amount` must be within `balance` (400 `INSUFFICIENT_PLATFORM_BALANCE`); `net <= 0` is 400
  `WITHDRAW_TOO_SMALL_FOR_FEES`; a repeated `reference` is 409 `DUPLICATE_WITHDRAWAL`. The fee is a payout cost, not income.
  Withdrawals run one at a time (the settings row is locked) and are written to the audit log (`ADMIN_WALLET_WITHDRAWAL`).
- Money is only booked from this version on, so a wallet that already earned before it starts at 0.
- Remitting VAT to the tax authority is not modelled: the VAT line only grows.
- The app does not send the payout itself. A withdrawal (user or admin) is booked `PENDING` with its payout phone (digits, optional
  `+`, 9-15 of them; 400 `INVALID_PHONE_NUMBER` for a user, `INVALID_PHONE` for the admin). The admin pays it outside the app and then
  calls `complete`, or `fail` when it could not be sent. Each line leaves `PENDING` once (the row is locked). `FAILED` and `REVERSED`
  platform lines are kept for the record but count in no total, so the platform balance and income figures are back as if the
  withdrawal never happened. Users never see the payout phone of other people; their own history does not return it either.

## `GET /api/app/policy` (public)

`{data: {fees: {registrationFee, serviceFee, freeServiceLimit, boostPlans, provider: {collectionPercent, vatPercent, payoutFee,
withdrawMin, withdrawMax}}, payments: {gateway}}}`, all from the admin's settings. `payments.gateway` is sent only when it is one of
the five names the app knows (not SANDBOX). `topUpMin/Max` and `security` are not sent, so the app keeps its defaults.
