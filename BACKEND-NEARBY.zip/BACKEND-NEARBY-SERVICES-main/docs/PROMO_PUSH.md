# Promo push (auto-promotion of boosted services)

A boosted service (see BOOSTS.md) is pushed by itself to users, so they open it. **One service per user per interval, and
different users get different services.**

## Who gets a push
- Only users who switched **promo notifications** on (Settings > Notification Preferences; `users.notif_promos`, **default ON for new accounts**; the user can switch it off).
  The push is also checked again in `PushService`, so a user who turns it off stops at once.
- Never the owner of the service, never a seller who blocked the user or whom the user blocked.
- Never an 18+ service: those are left out of promo pushes completely, even if the user searched for them.
- Only between **08:00 and 20:00 on the user's own clock** (TZ, KE, UG: UTC+3; RW, BI, CD: UTC+2).

## Which service
`PromoPicker` picks ONE boosted, active service for the user. The first difference wins:
0. a service that matches something the user **searched for** (last 30 days, last 20 distinct searches; recorded when a signed-in
   user searches on page 1 of `GET /services?query=`; matched on title, descriptions, other-language words and category),
1. a service this user was sent fewer times (a service they never saw comes first),
2. the one sent to this user longest ago,
3. the one pushed to fewer people in the last 24 hours (so the next user gets another one and every paying provider is
   shown about equally),
4. random among what is still tied.

## When
`PromoPushJob` runs every 10 minutes. A user is due when no promo push was sent to them for `intervalHours`
(admin setting, 1-72, default 6). A run sends at most `promo-push.max-per-run` (500) pushes; users left over are served
by the next run. Nothing runs when OneSignal is not configured (nothing is logged either), or when the admin switched it off.

## What the user receives
Title: the service title. Body (English / Swahili): `Featured in {category}: TSh 20,000. Tap to take a look.`
Data: `{type: "promo_service", id: "<serviceId>"}`. Tapping opens that service (the app falls back to the Notifications
screen when the service no longer exists).

## Admin (ROLE_ADMIN only)
| Call | Body | Answer |
|---|---|---|
| `GET /api/admin/promo-push` | | `{enabled, intervalHours, min: 1, max: 72}` |
| `PUT /api/admin/promo-push` | any of `{enabled, intervalHours}` | same shape; 400 `INVALID_PROMO_PUSH_INTERVAL` outside 1-72 |

Every change is written to the admin audit log (`PROMO_PUSH_SETTINGS_CHANGED`). In the app: Profile > Admin > Promo Push.

## Tables and settings
`user_search_terms` (user_id, term, searched_at; kept 30 days), `promo_push_log` (user_id, service_id, sent_at; created by Hibernate; rows older than 60 days are removed every night),
`admin_settings.promo_push_enabled` / `promo_push_interval_hours`.
`application.yaml`: `promo-push.start-hour` (8), `end-hour` (20), `max-per-run` (500); env `PROMO_PUSH_START_HOUR`,
`PROMO_PUSH_END_HOUR`, `PROMO_PUSH_MAX_PER_RUN`.

Written for ONE running server, like `OfferReminderJob`: with several servers, run the job on one of them only.

## Promo notifications on by default
New accounts start with promos ON (server column default and the app's default). Rows that already exist keep their
stored value (a column default never changes old rows). The app sends its switches to the server at every start, and an
app user who never touched the switch now sends ON, so they are switched on at their next app start. Do not run a bulk
`UPDATE users SET notif_promos = true`: it would also switch on people who turned it off. 
