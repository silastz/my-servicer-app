# /api/payments/* (money in)

| Call | Answer |
|---|---|
| `GET /payments/registration-fee` | `{paid, amount}` (admins count as paid) |
| `POST /payments/mobile/request` `{amount, purpose, reference, phone}` | `{reference, status}` |
| `POST /payments/card/checkout` `{amount, purpose, reference, description, phone?}` | `{checkoutUrl, reference}` |
| `GET /payments/status/{ref}`, `GET /payments/card/status/{ref}` | `{status: PENDING\|PAID\|FAILED\|CANCELLED}` (payer or admin only, else 404) |
| `POST /payments/webhook/{gateway}` | gateway callback; needs header `X-Webhook-Secret` = `PAYMENTS_WEBHOOK_SECRET` (empty = disabled) |
| `POST /admin/payments/{ref}/status` `{status}` | admin override / sandbox confirmation |

Purposes: `PROVIDER_REGISTRATION`, `SERVICE_FEE`, `WALLET_TOPUP`, `SERVICE_BOOST`, `BOOKING`.

Rules enforced on the server
- SERVICE_FEE and PROVIDER_REGISTRATION amounts come from `admin_settings`, never from the app.
- The reference is unique. Same user + purpose + amount may retry it; anything else answers 409 `REFERENCE_IN_USE`.
- PAID is final and its effect is applied once (`payments.settled`): SERVICE_FEE adds a credit
  (`ServiceFeeService.addCredit`), PROVIDER_REGISTRATION sets `users.registration_fee_paid`, WALLET_TOPUP credits the wallet.
  BOOKING only records PAID; its own call must check `PaymentService.isPaid(userId, purpose, reference)`.
  SERVICE_BOOST also only records PAID: `POST /api/boosts/activate` verifies the payment (see BOOSTS.md).
- The gateway is chosen by `PAYMENTS_GATEWAY`, never by the app's `gateway` field.

## Gateways
`SANDBOX` (nothing is sent or charged; an admin or the webhook marks payments) and `SNIPPE` (real mobile money).
To add another provider, implement `payment.PaymentGateway` (DPO, Selcom, ClickPesa, Pesapal are not built) and
verify the amount in that provider's webhook before calling `applyStatus` (`PaymentService.applyGatewayEvent` does this).

### Snippe (`payment/SnippeGateway.java`, docs: https://docs.snippe.sh/docs/2026-01-25)
Turn it on: set `SNIPPE_API_KEY`, `SNIPPE_WEBHOOK_SECRET`, `PAYMENTS_PUBLIC_BASE_URL` (the public https address of this
server), then pick SNIPPE in the admin gateway screen or set `PAYMENTS_GATEWAY=SNIPPE`.

| Setting | Where it comes from |
|---|---|
| `SNIPPE_API_KEY` | Snippe dashboard, Settings, API Keys. Scopes: `collection:create` and `collection:read`. Empty = every Snippe call answers 503 `PAYMENT_GATEWAY_NOT_CONFIGURED`. |
| `SNIPPE_WEBHOOK_SECRET` | Snippe dashboard, Settings, Webhook Secret (`whsec_...`). Empty = the webhook answers 403. |
| `PAYMENTS_PUBLIC_BASE_URL` | Sent to Snippe as `{base}/api/payments/webhook/snippe`. Snippe requires https in production. |
| `SNIPPE_FALLBACK_EMAIL` | Snippe needs an email; used only for users who have none. Set it to an address you own. |

- **Pay by mobile money**: `POST /v1/payments` (`payment_type: mobile`, USSD push). Phone is sent as `255XXXXXXXXX`; minimum
  500 TZS (below that answers 400 `AMOUNT_BELOW_GATEWAY_MIN`). The `Idempotency-Key` is a hash of the payment reference
  (Snippe refuses keys over 30 characters), so a retry of the same payment never charges twice. The payment's own reference
  travels in Snippe's `metadata.reference`.
- **Webhook** `POST /api/payments/webhook/snippe` (no JWT): the signature `X-Webhook-Signature` =
  hex(HMAC-SHA256(signing key, `"{X-Webhook-Timestamp}.{raw body}"`)) is checked in constant time, and a timestamp more than
  5 minutes old is refused. `payment.completed` -> PAID, `payment.failed` -> FAILED, `payment.voided` / `payment.expired` -> CANCELLED.
  A PAID event must carry exactly the amount we asked for (else 409 `AMOUNT_MISMATCH`, logged as an error, nothing credited),
  and must match the gateway reference stored on the payment. Payout events are acknowledged and ignored. An event for a
  payment we do not know yet answers 404 so Snippe retries (it retries 5 times over about 45 minutes).
- **Status polling**: `GET /payments/status/{ref}` asks Snippe `GET /v1/payments/{reference}` while the payment is PENDING, so a
  lost webhook does not leave a payment stuck.
- **Card**: not offered. Snippe's documented API creates only `mobile` payments with an API key (its hosted sessions need a
  merchant login token), so `POST /payments/card/checkout` answers 503 `CARD_NOT_SUPPORTED`. Ask Snippe whether card is enabled for
  your account if you need it.
- **Withdrawals** are paid out by an admin, outside the app: the line is `PENDING` with the payout phone until the admin calls
  `POST /api/admin/wallet/withdrawals/{ref}/complete` or `.../fail` (a failure refunds the user and reverses the fees; see
  WALLET_FEES.md). Sending the payout automatically through `POST /v1/payouts/send` is still not built; the wallet-refund-on-failure
  step it needs now exists as `fail`.
- Not run against the live Snippe API (no key was available). The request and webhook shapes follow their published docs and
  were exercised against a local stand-in server. Try one real 500 TZS payment with a Snippe test/live key before going live.

## Wallet top-up (`POST /api/wallet/deposit`)
Closed: it used to add any amount for free. It now needs `{reference}` of the caller's own PAID `WALLET_TOPUP` payment,
answers 409 `PAYMENT_NOT_CONFIRMED` otherwise, and never adds money itself (the payment settlement credits the wallet once).
The app's body `{amount, reference, method}` still works unchanged. `withdraw` now locks the wallet row.

## Wallet history: `GET /api/wallet/transactions`

The caller's own pocket-fund history, newest first. Optional `?limit=` (default 100, max 200).
Answer: `[{id, type, amount, status, title, reference, createdAt, direction}]`.

| type | direction | written when |
|---|---|---|
| `DEPOSIT` | IN | a WALLET_TOPUP payment turns PAID (reference = payment reference) |
| `WITHDRAWAL` | OUT | `POST /wallet/withdraw` (status `PENDING` until an admin completes or fails it) |
| `BOOKING` | OUT | a booking is paid from the pocket fund (reference = `ESC-...`) |
| `BOOKING` | IN | the seller receives the released escrow (buyer confirmed, or admin release) |
| `REFUND` | IN | seller rejected, buyer cancelled, or admin refunded a pocket-fund booking |
| `BOOST` | OUT | a boost is paid from the pocket fund (title = the service) |

Rows live in table `wallet_transactions` (created by `ddl-auto: update`). Each row is written in the same
database transaction as the balance change, so the history cannot disagree with the money. A user only ever
sees their own rows. History starts from this version; money moved earlier has no lines.

## Admin: payment gateway and provider fees (ROLE_ADMIN only, 403 to everyone else)

| Call | Body | Answer |
|---|---|---|
| `GET /api/admin/payments/gateway` | | `{gateway, available: [...]}` |
| `PUT /api/admin/payments/gateway` | `{gateway: "SELCOM"}` | `{gateway}` |
| `GET /api/admin/payments/provider-fees` | | `{collectionPercent, vatPercent, payoutFee, withdrawMin, withdrawMax}` |
| `PUT /api/admin/payments/provider-fees` | same fields (a missing field keeps its value) | same shape |

- **Gateway.** Saved in `admin_settings.payment_gateway`. New payments use it at once; with nothing saved the
  server uses `payments.gateway` from `application.yaml`. `available` lists only gateways that have a
  `PaymentGateway` implementation on this server (today: SANDBOX); `PUT` of any other gateway answers 400
  `PAYMENT_GATEWAY_NOT_AVAILABLE`. A payment keeps the gateway it was created with.
- **Provider fees.** Limits: `collectionPercent` 0-20, `vatPercent` 0-50, `payoutFee` whole TSh 0-1,000,000,
  `withdrawMin` / `withdrawMax` 0 or 100-100,000,000, and `withdrawMax` not below the effective minimum.
  Errors are 400 with `INVALID_COLLECTION_PERCENT`, `INVALID_VAT_PERCENT`, `INVALID_PAYOUT_FEE`,
  `INVALID_WITHDRAW_MIN`, `INVALID_WITHDRAW_MAX` or `WITHDRAW_MAX_BELOW_MIN`. Nothing is saved when any field fails.
- **Withdrawal range is enforced.** `POST /wallet/withdraw` uses the admin's current values: `withdrawMin`
  (0 = 1,000) and `withdrawMax` (0 = no maximum); outside the range answers 400 `WITHDRAW_BELOW_MIN` / `WITHDRAW_ABOVE_MAX`.
- Every change is written to `admin_audit_log` (`PAYMENT_GATEWAY_CHANGED`, `PROVIDER_FEES_CHANGED`) with the admin id and old and new values.
- The fees start at **0**: nothing is charged until the admin sets them. They are charged on withdrawals and refunds, see `docs/WALLET_FEES.md`.
