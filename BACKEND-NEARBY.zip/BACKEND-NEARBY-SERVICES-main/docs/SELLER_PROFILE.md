# Seller profile fields (v49)

The `seller` object on services, bookings and `GET /api/verification/users/{id}/public` now carries what the app's
provider page reads:

| JSON key | Meaning |
|---|---|
| `createdAt` | Member since (app: "Member since") |
| `completedJobs` | Bookings with status COMPLETED |
| `totalBookings` | All bookings sent to this provider |
| `isOnline` | Connected to the live chat socket right now |

Built in `VerificationService.mapToSellerDto`. `mapToPublicDto` stays cheap for reviews and other lists.
## v50: profile lock and badges
- `users.profile_locked` (default true, same as the app). Set with `PUT /api/users/me/privacy {"profileLocked": bool}`
  (alone or with `hideMyId`); returned by `GET /users/me` and on login.
- The server now enforces it: a service's phone, social links and coordinates are hidden from the public while the
  service is locked OR the provider's profile is locked. `isInfoLocked` still means only the service's own lock.
  Existing providers start locked (column default), like the app's local default.
- `seller.profileLocked` and `seller.badges` (TOP_RATED 4.8/10, PROFESSIONAL 4.5/5, CUSTOMER_FAVORITE 4.6/25, same as the app).

## v51: invitations
- A code is unique per inviter (it was random with no check, so two rows could share one and accept would fail).
- `POST /verification/invitations/accept` also takes the bare 6-character code; it is then matched against the
  signed-in user's own phone, so it only works for the person the invitation was sent to.
- Approving a vouch request when the provider already has a pending invitation for that phone returns that
  invitation's code instead of failing with ALREADY_INVITED.
- App: INVITE_PHONE_MISMATCH (403) no longer shows "only verified providers can invite"; TOO_MANY_ATTEMPTS,
  INVALID_PHONE and REQUEST_NOT_FOUND now have their own messages.

## v52: customer (buyer) profile on a booking
The `buyer` object of a booking now carries what the provider's customer page reads:
`createdAt` (member since), `completedBookings`, `reviewsGiven`, and `profileLocked` = the buyer's own Profile Locked
setting AND the booking not yet accepted. The booking itself carries `buyerPhone`, sent only once the provider has
accepted (and the booking is paid when payment is required), the same rule as `sellerPhone`.
Not sent: the customer's city and position (the server stores no city for a user and the GPS fix is private).

## v53: booking, SMS, rating
- New booking status `CANCELLED`: a buyer who calls a request off now gets CANCELLED (the app already had a
  "Cancelled" label); REJECTED stays for the provider declining and for an unpaid booking that timed out. The
  database check on `escrow_transactions.status` allows it (DataInitializer) and `users.profile_locked` is added there too.
- A review now sends the rated person a push (type `booking_review`, follows their Bookings switch).
- App v163: an OFFLINE booking now shows "Confirm completed" to the buyer (the server already completes it without
  moving money). Before, it stayed ACCEPTED forever and could never be rated. A refused review shows the reason
  (already reviewed, not completed yet, bad rating).
- SMS: admin screen contract (config, test-connection, test-send) already matches. The server only sends SMS for
  one-time codes; booking events go by push only.

## Routes the app does not call

- `GET /api/verification/users/{id}/public` stays: a public, read-only profile (stage name, badges, rating), allowed without login in SecurityConfig.
- `PUT /api/users/profile` is deprecated (older app builds only); the app uses `PUT /api/users/me/profile`.
- `POST /api/users/fcm-token` was removed: push goes through OneSignal by user id, the token was never read.
