# Boosts

A provider pays to have one service ranked first (Home, Category, Search) and tagged "Boosted" for some days.

| Call | What it does |
|---|---|
| `GET /api/boosts/plans` | `[{id, days, price}]` from the `boost_plans` table (TZS). Seeded with `boost_1d` 2,000 / `boost_3d` 5,000 / `boost_7d` 10,000 when the table is empty. |
| `POST /api/payments/mobile/request` or `/card/checkout` | Existing endpoints, purpose `SERVICE_BOOST`. |
| `POST /api/boosts/activate` `{serviceId, planId, days?, paymentMethod: MOBILE_MONEY\|CARD\|POCKET_FUND, reference?}` | Starts or extends the boost -> `{id, serviceId, planId, days, price, paymentMethod, startsAt, boostedUntil}` |

Rules enforced on the server
- Price and days come from the plan table, found by `planId` (or by `days` when `planId` is missing). The app's amount is never used.
- The caller must own the service (403 `NOT_YOUR_SERVICE`); unknown service 404; a paused service 409 `SERVICE_NOT_ACTIVE`.
- `MOBILE_MONEY` / `CARD` need `reference`: a payment by this user, purpose `SERVICE_BOOST`, channel matching the method
  (MOBILE / CARD), status PAID, amount equal to the plan price. Not found 404 `PAYMENT_NOT_FOUND`; not PAID yet 402
  `PAYMENT_NOT_COMPLETED`; wrong amount 400 `PAYMENT_AMOUNT_MISMATCH`.
- `POCKET_FUND`: the wallet is debited in the same transaction as the boost. Too little money = 400 with a readable message.
- A reference works once. Repeating the same call returns the first result and adds no days; the same reference for a
  different service or plan is 409 `REFERENCE_IN_USE`. Pocket-fund calls without a `reference` cannot be de-duplicated.
- Already boosted: the new days start at the current `boostedUntil`. The boost ends by itself; nothing needs to run.
- One provider's boosts run one at a time (the user row is locked), so two taps cannot both charge or both extend.

Service JSON
- `boostedUntil` (ISO-8601) is sent on `GET /services`, `GET /services/{id}` and `GET /services/seller/my-services`,
  only while the boost is running.
- `GET /services` sorts boosted services first across ALL pages, then by the requested sort (default newest first), then id.

Tables: `boost_plans`, `service_boosts` (one row per purchase, unique `reference`), `services.boosted_until`. Hibernate creates them.

## Boost starts by itself when the payment turns PAID

If the app is closed right after the provider pays, the boost still starts: when a `SERVICE_BOOST` payment turns PAID
(webhook, status check or admin) the server starts it. It reads the service and user from the payment reference the
app already sends, `BOOST-{serviceId}-{userId}-{millis}`, and the plan from the amount (the one active plan with that
price). It starts only when the user in the reference is the payer, owns the service, the service is active, and exactly
one active plan has that price; otherwise it logs a warning and does nothing, and the app's own `POST /boosts/activate`
still works. The payment reference is the boost's unique key, so the app's later `activate` returns this same boost and
no days are added twice. This runs in its own transaction and cannot undo the PAID status.

## Admin: boost prices (ROLE_ADMIN only)

| Call | Body | Answer |
|---|---|---|
| `GET /api/admin/boosts/plans` | | `[{id, days, price, active}]`, including switched-off plans |
| `POST /api/admin/boosts/plans` | `{id, days, price, active?}` | the plan, HTTP 201 |
| `PUT /api/admin/boosts/plans/{id}` | any of `{days, price, active}` | the plan |

Plans are never deleted: switch one off with `active: false`. A change applies to future purchases only; past boosts
keep the price they paid. Limits: `id` 3-50 of `a-z 0-9 _`, `days` 1-365, `price` whole TSh 100-10,000,000. Two active
plans may not share a price (409 `PLAN_PRICE_IN_USE`) or days (409 `PLAN_DAYS_IN_USE`), because the payment-time match
above uses the price. Errors: 400 `INVALID_PLAN_ID` / `INVALID_DAYS` / `INVALID_PRICE`, 409 `PLAN_ID_IN_USE`, 404
`PLAN_NOT_FOUND`. Every change is written to the admin audit log (`BOOST_PLAN_CREATED`, `BOOST_PLAN_CHANGED`).

## Promo push

While a boost runs, the service is also pushed to users who switched promo notifications on: one service per user per
interval, different users get different services. See PROMO_PUSH.md.
